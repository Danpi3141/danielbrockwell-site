Rampart 1.0 for the Psion Organiser II (LZ and LZ64)
MIT licence: see LICENSE.

These are the program's files, ready for an Organiser: translated procedures (.OB3)
and the loader that copies them onto a pack over a Comms Link.

Loading them
  1. Unzip this folder on the PC.
  2. In Psi2Win, set Folder to this folder and click Start!.
  3. If RPBOOT is not on the Organiser yet: COMMS > RECEIVE > PROCEDURE, type RPBOOT,
     EXE. Then PROG > EDIT RPBOOT, MODE > TRAN.
  4. PROG > RUN RPBOOT. Choose the pack to copy the program to (B: or C: is best) and
     wait until it says NOW RUN B:RAMPART (or whichever pack you chose).
  5. PROG > RUN RAMPART on that pack.
  RPBOOT uses RPLOAD on an LZ or LZ64 and RPLOADCM on a CM, XP or LA. Delete A:RPLOAD
  afterwards to free its memory.

Files
  BREACH.OB3
  BUILD.OB3
  DRAWALL.OB3
  DRAWB.OB3
  ENDGAME.OB3
  GAME.OB3
  GFX.OB3
  HELP.OB3
  HELPK.OB3
  HISAVE.OB3
  HIT.OB3
  HUD.OB3
  INTER.OB3
  KEYS.OB3
  LOGO.OB3
  MSG.OB3
  NEWGAME.OB3
  OIL.OB3
  PAUSEM.OB3
  RAMPART.OB3
  RPBOOT.OPL
  RPDATA.ODB
  RPLOAD.OB3
  RPLOADCM.OB3
  RUNWAVE.OB3
  SELL.OB3
  SHOWHI.OB3
  TFIND_.OB3
  TITLE_.OB3
  UPGR.OB3
  VICTORY_.OB3
  WAVE.OB3
  WAVEEND.OB3

More: https://danielbrockwell.uk/psion/getting-started/
