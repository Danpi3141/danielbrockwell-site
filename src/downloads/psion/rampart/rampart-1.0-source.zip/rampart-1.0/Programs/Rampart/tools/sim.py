"""Rampart LZ balance simulator.

Mirrors the OPL rules in ../src (RUNWAVE, HIT, BREACH, WAVE, WAVEEND)
tick for tick, so wave tables can be tuned on a PC before typing.

    python sim.py            # run every stock strategy on every difficulty
    python sim.py -v greedy  # wave-by-wave log for one strategy
"""
import argparse
import random

# ---- tables (keep in step with NEWGAME.opl / WAVE.opl) -------------------
RG = {1: 1, 2: 2, 3: 1, 4: 2}            # range
RL = {1: 1, 2: 2, 3: 4, 4: 1}            # reload in turns
CO = {1: 10, 2: 25, 3: 30, 4: 45}        # cost
UC = {1: 15, 2: 30, 3: 30, 4: 50}        # upgrade cost
DM = {(1, 1): 1, (1, 2): 2, (2, 1): 3, (2, 2): 5,
      (3, 1): 1, (3, 2): 2, (4, 1): 2, (4, 2): 4}   # frost: freeze ticks
AR = [0, 0, 1]
BN = [2, 2, 5]
LV = [1, 1, 2]

HMA = [1, 2, 3]          # HP multiplier per act
TROLL, DRAGON = 25, 40   # boss base HP (x act multiplier)
TICKS = "::9988887777666"
SPECIAL = "000021110211113"


def wave_scripts(n, rnd):
    R = lambda s, k: s * k
    W = {
        1: (R("0...", 6), "", "GRUNTS"),
        2: (R("0...", 5), "......" + R("0...", 5), "TWO LANES"),
        3: (R("0...", 4) + R("1..", 3), R("0..", 6), "RUNNERS"),
        4: (R("0..", 8), R("1..", 4) + R("0..", 4), "PRESSURE"),
        5: ("0..0....3....0..0", R("1.", 6), "TROLL"),
        6: (R("2....", 3), R("0..", 6), "BRUTES"),
        7: (R("003....", 3), R("1.", 5), "SHAMANS"),
        8: (R("2..", 4), R("23....", 3), "HEALERS"),
        9: (R("1.", 10), R("0.", 10), "SWARM"),
        10: ("3....2..2", R("1.", 4) + "....3", "TWIN BOSS"),
        11: (R("230.0.0.0......", 2), R("1.", 8), "ACT THREE"),
        12: (R("2.", 6), R("003....", 3), "IRON WALL"),
        13: (R("11..", 7), "23...2....23...2", "SPEED"),
        14: ("0.1.2.0.1.3.0.2.1.0.0.1.2.3.0.1.0.2.1.0",
             "1.0.2.1.0.3.1.2.0.1.2.0.3.1.0.2.0.1.2.1", "ALL OUT"),
        15: (R("0..", 6) + "....3", R("2..", 6), "DRAGON"),
    }
    if n <= 15:
        a, b, name = W[n]
        tk = ord(TICKS[n - 1]) - 48
        sk = ord(SPECIAL[n - 1]) - 48
        hm = HMA[(n - 1) // 5]
    else:
        e = n - 15
        tk, hm, sk = 6, HMA[2] + e // 3, 1
        if e % 5 == 0:
            sk = 2

        def rch():
            r = rnd.random()
            if r < .5: return "."
            if r < .7: return "0"
            if r < .85: return "1"
            if r < .95: return "2"
            return "." if sk == 2 else "3"
        a = "".join(rch() for _ in range(30))
        b = "".join(rch() for _ in range(30))
        if sk == 2:
            a = a[:15] + "3" + a[15:]
            b = b[:10] + "3" + b[10:]
        name = "ENDLESS"
    hp = [2 * hm, hm, 6 * hm]
    if sk == 2:
        hp.append(TROLL * hm); ar4, bn4, lv4 = 1, 25, 5
    elif sk == 3:
        hp.append(DRAGON * hm); ar4, bn4, lv4 = 2, 0, 99
    else:
        hp.append(3 * hm); ar4, bn4, lv4 = 0, 4, 1
    hp = [min(x, 200) for x in hp]
    return dict(a=a, b=b, name=name, tk=tk, sk=sk, hm=hm, hp=hp,
                ar=AR + [ar4], bn=BN + [bn4], lv=LV + [lv4])


class Game:
    def __init__(self, df, rnd):
        self.df = df
        self.gold = {1: 60, 2: 40, 3: 30}[df]
        self.life = {1: 30, 2: 20, 3: 10}[df]
        self.towers = []        # dicts: x, b, t, l, c, s
        self.bank = {1: ["."] * 15, 2: ["."] * 15}
        self.sc = 0
        self.over = False
        self.rnd = rnd
        self.wv = 0
        self.log = []

    # --- player actions -------------------------------------------------
    def build(self, t, b, x):
        if self.bank[b][x - 1] != "." or len(self.towers) >= 12 or self.gold < CO[t]:
            return False
        self.towers.append(dict(x=x, b=b, t=t, l=1, c=0, s=CO[t]))
        self.bank[b][x - 1] = "ACFM"[t - 1]
        self.gold -= CO[t]
        return True

    def upgrade(self, tw):
        if tw["l"] == 2 or self.gold < UC[tw["t"]]:
            return False
        self.gold -= UC[tw["t"]]; tw["s"] += UC[tw["t"]]; tw["l"] = 2
        return True

    def sell(self, tw):
        self.gold = min(999, self.gold + tw["s"] // 2)
        i = self.towers.index(tw)
        self.towers[i] = self.towers[-1]
        self.towers.pop()
        self.bank[tw["b"]][tw["x"] - 1] = "."

    # --- one wave ---------------------------------------------------------
    def hit(self, W, l, p, n):
        e, h = self.e[l], self.h[l]
        g = e[p]
        h[p] -= n
        if h[p] < 1:
            e[p] = None
            self.gold = min(999, self.gold + W["bn"][g])
            self.sc += W["bn"][g]
            self.kills += 1

    def run_wave(self, use_oil=None):
        W = wave_scripts(self.wv, self.rnd)
        self.W = W
        self.e = {1: [None] * 20, 2: [None] * 20}   # index 1..19
        self.h = {1: [0] * 20, 2: [0] * 20}
        wsc = {1: W["a"], 2: W["b"]}
        wp = {1: 0, 2: 0}
        fz = {1: 0, 2: 0}
        flaw = True
        oil = True
        self.kills = 0
        lost = 0
        tn = 0
        while True:
            tn += 1
            for l in (1, 2):
                e, h = self.e[l], self.h[l]
                if fz[l]:
                    fz[l] -= 1
                    continue
                if e[1] is not None:                      # breach
                    g = e[1]
                    d = 999 if (g == 3 and W["sk"] == 3) else W["lv"][g]
                    self.life -= d; lost += min(d, 99)
                    flaw = False
                    if self.life <= 0:
                        self.life = 0; self.over = True
                s = None
                if wp[l] < len(wsc[l]):
                    c = wsc[l][wp[l]]; wp[l] += 1
                    if c != ".":
                        s = int(c)
                e[1:19] = e[2:20]; h[1:19] = h[2:20]
                e[19] = s; h[19] = W["hp"][s] if s is not None else 0
                # runner dash
                if 1 in e[1:]:
                    p = e.index(1, 1)
                    if p > 1 and e[p - 1] is None:
                        e[p - 1], e[p] = 1, None
                        h[p - 1], h[p] = h[p], 0
                # shaman heal
                if W["sk"] == 1 and 3 in e[1:]:
                    p = e.index(3, 1)
                    if p > 1 and e[p - 1] is not None:
                        g = e[p - 1]
                        if h[p - 1] + 1 <= W["hp"][g]:
                            h[p - 1] += 1
            if self.over:
                break
            # oil (player decision before towers fire)
            if oil and use_oil and use_oil(self):
                oil = False
                for l in (1, 2):
                    for p in range(1, 6):
                        if self.e[l][p] is not None:
                            self.hit(W, l, p, 3)
            # towers: every tower gets a turn each tick
            i = 1
            while i <= len(self.towers):
                tw = self.towers[i - 1]
                if tw["c"]:
                    tw["c"] -= 1
                else:
                    l = tw["b"]; x = tw["t"]; r = RG[x]
                    a = max(1, tw["x"] - r); bnd = tw["x"] + r
                    win = lambda L: any(self.e[L][p] is not None for p in range(a, bnd + 1))
                    if x == 4 and not win(l):
                        l = 3 - l
                    if win(l):
                        if x == 3:
                            if fz[l] == 0:
                                fz[l] = DM[(3, tw["l"])]
                                if W["sk"] > 1 and 3 in self.e[l][1:]:
                                    fz[l] = 1
                                tw["c"] = RL[3] - 1
                        else:
                            p = a
                            while self.e[l][p] is None:
                                p += 1
                            tw["c"] = RL[x] - 1
                            g = self.e[l][p]
                            n = DM[(x, tw["l"])]
                            if x != 2:
                                n -= W["ar"][g]
                            if n > 0:
                                self.hit(W, l, p, n)
                i += 1
            done = all(v is None for v in self.e[1][1:]) and all(v is None for v in self.e[2][1:]) \
                and wp[1] >= len(wsc[1]) and wp[2] >= len(wsc[2])
            if done:
                break
        secs = tn * W["tk"] * 0.05
        if self.over:
            return dict(lost=lost, ticks=tn, secs=secs)
        b = min(25, 5 + self.wv)
        i = 0 if self.df == 3 else min(5, self.gold // 10)
        self.gold = min(999, self.gold + b + 5 * flaw + i)
        self.sc += 50
        return dict(lost=lost, ticks=tn, secs=secs, flaw=flaw, interest=i)


# ---- stock strategies ------------------------------------------------------
# Each is called at every intermission and spends gold.

ORDER_BAL = [  # (type, bank, slot) a sensible balanced build plan
    (1, 1, 5), (1, 2, 5), (1, 1, 9), (1, 2, 9), (2, 1, 7), (2, 2, 7),
    (3, 1, 11), (3, 2, 11), (4, 1, 3), (2, 2, 3), (2, 1, 13), (2, 2, 13),
]


def strat_greedy(g):
    """Follow a balanced build order, then upgrade cannons/mages/archers."""
    for (t, b, x) in ORDER_BAL:
        if g.bank[b][x - 1] == ".":
            if not g.build(t, b, x):
                return
    for pref in (2, 4, 1, 3):
        for tw in g.towers:
            if tw["t"] == pref and tw["l"] == 1:
                if not g.upgrade(tw):
                    return


def strat_archers(g):
    """Lazy: only archers, upgraded when possible."""
    slots = [(b, x) for x in (5, 9, 3, 7, 11, 13) for b in (1, 2)]
    for b, x in slots:
        if g.bank[b][x - 1] == ".":
            if not g.build(1, b, x):
                break
    for tw in g.towers:
        g.upgrade(tw)


def strat_cannons(g):
    """Cannons everywhere."""
    slots = [(b, x) for x in (6, 10, 3, 13, 8, 12) for b in (1, 2)]
    for b, x in slots:
        if g.bank[b][x - 1] == ".":
            if not g.build(2, b, x):
                break
    for tw in g.towers:
        g.upgrade(tw)


def strat_saver(g):
    """Balanced build, but only spends above 50 gold after wave 3 (interest)."""
    reserve = 50 if g.wv > 3 else 0
    for (t, b, x) in ORDER_BAL:
        if g.bank[b][x - 1] == ".":
            if g.gold - CO[t] < reserve or not g.build(t, b, x):
                return
    for pref in (2, 4, 1, 3):
        for tw in g.towers:
            if tw["t"] == pref and tw["l"] == 1:
                if g.gold - UC[pref] < reserve or not g.upgrade(tw):
                    return


def strat_smart(g):
    """Balanced build; before a boss wave, swap archers on the boss lane for cannons."""
    strat_greedy(g)
    W = wave_scripts(g.wv, random.Random(0)) if g.wv <= 15 else None
    if not W or W["sk"] < 2:
        return
    for lane, script in ((1, W["a"]), (2, W["b"])):
        if "3" not in script:
            continue
        for tw in list(g.towers):
            if tw["b"] == lane and tw["t"] in (1, 3) and g.gold + tw["s"] // 2 >= CO[2]:
                x = tw["x"]
                g.sell(tw)
                g.build(2, lane, x)
        for tw in g.towers:
            if tw["b"] == lane and tw["t"] == 2:
                g.upgrade(tw)


EXPERT_PLAN = [  # final layout, in build order: cannons up top, cannon+mage below
    (2, 1, 7), (2, 2, 7), (2, 1, 11), (4, 2, 9), (2, 1, 3), (2, 2, 3),
    (2, 1, 9), (4, 2, 5), (2, 1, 5), (2, 2, 11), (2, 1, 13), (4, 2, 13),
]
EARLY = [(1, 1, 6), (1, 2, 6), (1, 1, 10), (1, 2, 10)]


def strat_expert(g):
    """Cheap archers first, then grow into a cannon/mage layout; upgrade early;
    sells the starter archers once the 12-tower cap is reached."""
    if g.wv <= 2:
        for t, b, x in EARLY:
            g.build(t, b, x)
    for t, b, x in EXPERT_PLAN:
        if g.bank[b][x - 1] == ".":
            if len(g.towers) >= 12:
                arch = [tw for tw in g.towers if (tw["t"], tw["b"], tw["x"]) not in EXPERT_PLAN]
                if arch and g.gold + arch[0]["s"] // 2 >= CO[t]:
                    g.sell(arch[0])
            if not g.build(t, b, x):
                break
        else:
            tw = next(tw for tw in g.towers if tw["b"] == b and tw["x"] == x)
            if tw["l"] == 1 and tw["t"] != 1:
                g.upgrade(tw)


STRATS = dict(expert=strat_expert, smart=strat_smart, greedy=strat_greedy, archers=strat_archers,
              cannons=strat_cannons, saver=strat_saver)


def oil_panic(g):
    """Pour oil when 3+ monsters sit in the first 5 cells."""
    n = sum(1 for l in (1, 2) for p in range(1, 6) if g.e[l][p] is not None)
    return n >= 3


def play(strat, df, seed=1, verbose=False, endless=0):
    g = Game(df, random.Random(seed))
    for wv in range(1, 16 + endless):
        g.wv = wv
        STRATS[strat](g)
        r = g.run_wave(oil_panic)
        if verbose:
            print(f"  wave {wv:2d} {g.W['name']:<10} lost {r['lost']:3d} lives {g.life:3d}"
                  f" gold {g.gold:4d} towers {len(g.towers):2d} {r['secs']:5.1f}s")
        if g.over:
            return wv, g
    return 15 + endless + 1, g


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-v", "--verbose", metavar="STRAT")
    ap.add_argument("-d", "--difficulty", type=int, default=2)
    ap.add_argument("--endless", type=int, default=0)
    a = ap.parse_args()
    if a.verbose:
        w, g = play(a.verbose, a.difficulty, verbose=True, endless=a.endless)
        print("result:", "WIN" if w > 15 else f"lost on wave {w}", "score", g.sc + 20 * g.life)
        return
    for df in (1, 2, 3):
        for s in STRATS:
            w, g = play(s, df)
            res = "WIN " if w > 15 else f"died w{w:<2d}"
            print(f"diff {df} {s:<8} {res} lives {g.life:2d} score {g.sc + 20 * g.life}")


if __name__ == "__main__":
    main()


def scenario(wave, layout, gold=500, df=2):
    """Fixed test: build layout (type,bank,slot[,upgrade]) then run one wave.
    Returns gold and lives after the wave-end bonuses, for checking the
    emulator against the simulator."""
    g = Game(df, random.Random(1))
    g.gold = gold
    g.wv = wave
    for item in layout:
        t, b, x = item[:3]
        g.build(t, b, x)
        if len(item) > 3:
            g.upgrade(g.towers[-1])
    g.run_wave(None)
    return g.gold, g.life
