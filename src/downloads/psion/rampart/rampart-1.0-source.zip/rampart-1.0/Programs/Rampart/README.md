# Rampart LZ

A real-time, two-lane tower defence game in OPL for the Psion Organiser II LZ64 (also runs on the 32K LZ).
Monsters march right to left along the two middle lines towards your castle wall; you build towers on the top and bottom lines to stop them.
15 waves in three acts, then an endless mode and a high-score table.

Built from the design spec *Rampart LZ — Tower Defence Game Spec for the Psion LZ64* (14 Nov 2026). Changes from the spec are listed at the end.

## Playing it

**Jape:** Select OPK file... → `RAMPART.opk` → type a name → Create → Slot B.
**Organiser:** Prog → Run, press MODE until the prompt shows `B:`, type `RAMPART`, EXE.

The high-score table is saved in a data file `A:RAMPHS` in internal memory.

### Putting it on a real Organiser with Psi2Win

Psi2Win can't write a pack image, but it can serve files to the Organiser's Comms Link. The `psion/` folder holds the 29 procedures already translated (`.OB3`), plus a loader that fetches them all with the Comms Link's `XTRECV:` command: `RPBOOT.OPL`, a small starter; `RPLOAD.OB3`, the loader itself, translated, with no source; and `RPDATA.ODB`, its list of files. (The loader is general-purpose; see `Tools/README.md`.) The game needs about 32K free on the pack you copy it to. Internal memory (`A:`) or a Rampak is best, because re-running the loader on a Datapak uses up space.

1. Run `python build.py --psion` (or use the `psion/` folder as it is). It only rewrites files that changed, so it's safe to run while Psi2Win is serving the folder; if a changed file is in use, it lists it and asks you to stop Psi2Win and run it again.
2. In Psi2Win, set **Folder** to `psion/`, pick the Comms Link port in **Setup**, and click **Start!**.
3. If `RPBOOT` isn't on the Organiser yet: **COMMS → RECEIVE → PROCEDURE**, type `RPBOOT`, EXE. Then **PROG → EDIT** `RPBOOT`, MODE → **TRAN**.
4. **PROG → RUN** `RPBOOT`. The first time, it fetches `RPLOAD` into `A:` and keeps it there. Choose the pack to copy the game to, and watch the progress bar until it says `NOW RUN B:RAMPART` (or whichever pack).
5. **PROG → RUN** `RAMPART` on that pack.

If `RAMPART` stops with an error, it restores the auto switch-off and key-repeat settings, then shows the Organiser's own error message, which names the procedure involved (for example `MISSING PROC` / `TITLE%`).

**Short of memory?** Point Psi2Win at `psion-small/` instead. It has the same procedures with the source text left out: about 14K instead of 32K, and it plays identically, but the procedures can't be edited on the Organiser. If you re-run the loader into internal memory, delete the old copies first, because replacing a file may need room for both copies at once.

If a transfer fails, the loader shows which file and the error. On the PC, procedure names ending in `%` are spelt with `_` (`TFIND_.OB3`, `TITLE_.OB3`, `VICTORY_.OB3`), as Comms Link expects.

**If `XTRECV:` won't work with Psi2Win:** `psion/opl/` has the 29 sources as plain text. Receive each one with COMMS → RECEIVE → PROCEDURE and translate it with PROG → EDIT → TRAN. The Organiser's translator gives exactly the code in `RAMPART.opk`. Receive the three `%` procedures as `TFIND_`, `TITLE_` and `VICTORY_` if Psi2Win doesn't map the name for you, then use PROG → COPY to give them their real names (`TFIND%`, `TITLE%`, `VICTORY%`).

### The screen

```
 ⁴ ⁴ ⁵  ⁶   ⁴   $ 42     top bank: 15 tower slots guarding lane A, gold
]  ⁰  ⁰*   ²    ¹  ⁰     lane A: monsters enter on the right
]    ¹   ⁰⁰     ²        lane B
   ⁴ ⁷     ⁵     oL18     bottom bank, oil ready (o), lives
```

Between waves, empty slots show as dots. The wall shows `!` when a monster gets through and `#` while Frost holds that lane. During a wave the cursor is a blinking block on its slot (the Organiser's own cursor is switched off, because it would chase every update round the screen).

### Keys

| Key | Action |
| --- | --- |
| LEFT / RIGHT | Move the cursor along a bank (wraps round) |
| UP / DOWN | Top bank / bottom bank |
| EXE | Empty slot: build menu. Tower: shows type, level, upgrade cost and sale value; then U upgrades, DEL sells |
| A C F M | Build an Archer, Cannon, Frost or Mage tower at the cursor |
| U | Upgrade the tower at the cursor |
| DEL | Sell the tower at the cursor (half of everything spent on it) |
| O | Boiling oil, once per wave: 3 damage to every monster in the 5 cells nearest the wall, ignoring armour |
| SPACE | Start the next wave |
| MODE | Key reminder |
| ON/CLEAR | Pause menu: Resume or Quit |

The wave freezes while the build menu, the inspect line or a help screen is open.

### Towers

| Tower | Cost | Upgrade | Damage L1/L2 | Range | Reload | Notes |
| --- | --- | --- | --- | --- | --- | --- |
| Archer | 10 | 15 | 1 / 2 | 1 | every tick | Armour blunts it |
| Cannon | 25 | 30 | 3 / 5 | 2 | every 2nd tick | Ignores armour |
| Frost | 30 | 30 | — | 1 | every 4th tick | Freezes its lane for 1 tick (L2: 2). Bosses only ever freeze for 1 |
| Mage | 45 | 50 | 2 / 4 | 2 | every tick | Shoots its own lane, else the other lane |

At most 12 towers at once. Range is in columns either side of the tower; every tower shoots the monster nearest the wall in its range.

### Monsters

| Monster | HP (x1, x2, x3 by act) | Armour | Gold | Lives lost |
| --- | --- | --- | --- | --- |
| Grunt | 2 | 0 | 2 | 1 |
| Runner | 1 (the leading runner sprints) | 0 | 2 | 1 |
| Brute | 6 | 1 | 5 | 2 |
| Shaman | 3 (heals the monster ahead of it) | 0 | 4 | 1 |
| Troll (waves 5, 10) | 25 | 1 | 25 | 5 |
| Dragon (wave 15) | 40 | 2 | 0 | all of them |

### Gold and score

You start with 40 gold and 20 lives (Easy 60/30, Hard 30/10 with no interest).
A cleared wave pays 5 + the wave number, +5 if no monster got through, plus interest of 1 per 10 gold you held at the end of the wave (max 5).
Score = gold earned from kills + 50 per wave cleared + 20 per life left.

## Files

| Path | What it is |
| --- | --- |
| `RAMPART.opk` | Release pack image (32K Datapak), translated procedures plus source (comment lines left out; `src/` has them) |
| `src/*.opl` | The 29 OPL procedures; `RAMPART` is the one to run |
| `build.py` | Builds `RAMPART.opk`; `--psion` also writes `psion/`; `--dev` builds `RAMPART-dev.opk` with debug aids; `--source-only` builds an untranslated pack for checking the Organiser's own translator |
| `psion/` | Files for a real Organiser via Psi2Win: the translated `.OB3` procedures, the loader (`RPBOOT.OPL`, `RPLOAD.OB3`) with its `RPDATA.ODB` file list, and the sources in `opl/` (made by `build.py --psion`) |
| `psion-small/` | The same procedures without source text (about 14K), plus the loader and file list |
| `tools/sim.py` | PC simulator of the game rules, used for balancing |
| `tests/` | `BENCH` speed benchmark, `RWBENCH` wave benchmark (12 upgraded towers against waves 13, 15 and 18, with per-phase timings and the resulting gold, lives and score; needs the dev build), `TUDG` display tests, `THI` high-score pruning harness, `TPEEK` settings check |
| `screenshots/` | The title screen and wave 8 in Jape |

```bash
python build.py
```
```bash
python tools/sim.py
```

The dev build keeps lines marked `REM DEBUG`: G adds 100 gold, W skips a wave between waves, and the wave-clear banner shows the slowest tick and the average firing time in frames.

## How it was tested

- Speed benchmarks in Jape (LZ64) before any game code: a string shift costs about 3 ms, drawing both lanes about 30 ms and a procedure call about 10 ms.
- `tools/sim.py` mirrors the OPL tick for tick. Three fixed scenarios (waves 8, 10 and 13 with mixed, upgraded towers) and a full 15-wave Normal campaign ended with exactly the gold and lives the simulator predicted.
- `RWBENCH` (12 level-2 towers, dev build) measures 5.0 to 5.5 frames of work per tick in waves 13, 15 and 18, slowest tick 8 frames, against the 6-frame act 3 tick. Finding targets with `LOC` on an occupancy string cut the firing phase by about a quarter, and the same benchmark gives identical gold, lives and score before and after that change.
- Every screen and path was driven by keypresses in Jape: title menu, help, sound toggle, all four towers, upgrade, sell, inspect, every refusal message, the 12-tower cap, boiling oil, the MODE help and ON/CLEAR pause menu mid-wave, defeat, victory with and without endless mode, quitting, name entry (including cancelling with ON/CLEAR), top-5 pruning and scrolling of the score table, and restoring `$7C`/`$77` on exit.
- On a real Organiser: loaded through Psi2Win with `RPBOOT`/`RPLOAD` from `psion-small/`, and played.
- The LZ64 ROM's own translator accepted all 29 procedures from source (Prog → Edit → Tran), and its object code was byte-for-byte identical to `RAMPART.opk`, so any procedure can be edited and re-translated on the Organiser. That check predates the speed pass (`RUNWAVE`, `WAVE`, `HIT`, `HUD`, `BREACH`, `RAMPART` changed since); `Tools/opltran.py`, which builds the pack, matches the ROM on its own test set.

## Changes from the spec

| Spec | Built | Why |
| --- | --- | --- |
| Towers act in two alternating halves, one turn every 2 ticks | Every tower acts every tick | The halves made towers too weak to balance with whole-number damage; OPL turned out fast enough once hits were inlined |
| `HIT:` procedure per shot | Hit code inlined in `RUNWAVE` (`HIT:` is still used by boiling oil) | A procedure call costs about 10 ms plus loading time; with 12 towers the tick took 1.25 s |
| Troll base HP 30 | 25 | In simulation even a good build always lost 5 lives to the first Troll |
| `KEYS:` handles every key | Arrow keys handled inline | Keeps the cursor responsive during a wave |
| High scores in `A:RAMPART` | `A:RAMPHS` | Avoids clashing with the `RAMPART` procedure if it is copied to `A:` |
| Title: monster walks across line 3 | Scrolling text on line 3 | The logo needs all eight UDGs |
| Lane freeze not shown | The wall shows `#` while a lane is frozen | So Frost visibly does something |
| `MENUN(1,"PLAY,SCORES,HELP,QUIT")` | Adds AUDIO (game sound on/off) | The spec's sound toggle needed a home |
| Ticks of 12 frames (wave 1) down to 7 (act 3 and endless) | 10 frames down to 6 | About 20% more steps per second; the faster targeting keeps a busy act 3 tick inside 6 frames |
| Grunts change walk frame once a tick | Twice a tick (stride when drawn, legs together half way through) | Smoother movement for no extra drawing |
| Cursor unspecified | Blinking block during waves, hardware cursor between waves and in prompts | The hardware cursor followed every PRINT and UDG write, flickering round the screen |
| Quit is unspecified | Quitting forfeits the score, except in endless mode, where it ends the game and records the score | A won campaign shouldn't be lost by quitting endless mode |
| A score of 0 could enter the table | Only scores above 0 are recorded | Empty games shouldn't fill the table |

## About this repository

One of the Psion Organiser II projects on Forgejo (`Daniel/Psion-*`). The build and test scripts expect the PsionII workspace layout:

```
PsionII/
  Emulator/          Jape, Jaap Scherphuis's emulator, with its ROM images (not in any repo:
                     https://www.jaapsch.net/psion/jape/jape.htm)
  Tools/             Daniel/Psion-Tools (opltran, opl2opk, RPBOOT/RPLOAD, ...)
  Programs/NAME/     this repository
```

`build/` is not committed: the build scripts recreate it.
