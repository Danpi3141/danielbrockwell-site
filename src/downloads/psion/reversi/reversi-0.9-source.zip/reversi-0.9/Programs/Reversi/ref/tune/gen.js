// Tuning data: self-play games from random openings (some random moves mixed in), every
// position written with the final margin (Solid minus Hollow).
// node ref/tune/gen.js games level out.jsonl
'use strict';
const os = require('os');
const fs = require('fs');
const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');
const { Engine, rnd } = require('../engine.js');

function game(seed, level, opts) {
  const e = new Engine(opts);
  e.seed = seed;
  const st = { seed: seed * 2654435761 & 0xffffff || 1 };
  const pos = [];
  let passes = 0, ply = 0;
  while (true) {
    const legal = e.legal();
    if (!legal.length) { e.pass(); if (++passes === 2) break; continue; }
    passes = 0;
    pos.push([Array.from(e.bd), e.side]);
    let mv;
    if (ply < 8 || rnd(st) < 20) mv = legal[(rnd(st) * legal.length) >> 8];
    else mv = e.think({ level }).move;
    e.make(mv); ply++;
  }
  const m = e.ns - e.nh;
  return pos.map(([bd, side]) => ({ b: bd.slice(11, 69).filter((v, i) => v !== 3 || false).join(''), s: side, m }));
}

if (!isMainThread) {
  const out = [];
  for (const sd of workerData.seeds) out.push(...game(sd, workerData.level));
  parentPort.postMessage(out);
} else {
  const n = +process.argv[2], level = +process.argv[3], file = process.argv[4];
  const nw = os.cpus().length;
  const parts = Array.from({ length: nw }, () => []);
  for (let g = 0; g < n; g++) parts[g % nw].push(1 + g * 97 + level * 1000003);
  Promise.all(parts.map(p => new Promise((res, rej) => {
    const w = new Worker(__filename, { workerData: { seeds: p, level } });
    w.on('message', res); w.on('error', rej);
  }))).then(rs => {
    const all = rs.flat();
    fs.writeFileSync(file, all.map(x => JSON.stringify(x)).join('\n') + '\n');
    console.log(`${n} games, ${all.length} positions -> ${file}`);
  });
}
