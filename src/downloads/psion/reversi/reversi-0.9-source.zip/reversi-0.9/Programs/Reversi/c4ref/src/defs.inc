; =====================================================================
; Connect 4 for the Psion Organiser II - shared definitions
; (system variables from the Technical Reference Manual: the same on
; the CM, XP, LA and LZ)
; =====================================================================

; ---- zero-page scratch (UTW_S0..S5). Clobbered by many OS calls.
T0      = $41
T1      = $42
T2      = $43
T3      = $44
T4      = $45
T5      = $46
T6      = $47
T7      = $48
T8      = $49
T9      = $4A
T10     = $4B
T11     = $4C

; ---- system variables and hardware
KBB_DLAY = $77                  ; key repeat delay (ticks)
KBB_REPT = $78                  ; key repeat rate (ticks)
KBB_STAT = $7B
KBB_CLIK = $20C0
TMB_MIN  = $20C9                ; clock minutes (then seconds at $20CA)
TMW_FRAM = $20CB                ; frame counter, +1 every 50 ms
TMW_TOUT = $007D                ; seconds left to auto switch-off
TMW_TCNT = $20CD                ; auto switch-off time in seconds
TMB_SWOF = $007C                ; auto switch-off flag
KBB_PKOF = $20C1                ; KB$TEST switches the packs off when set
LCD_CTRL = $0180
LCD_DATA = $0181
FRC      = $0009                ; the processor's free-running counter (2 bytes)
MODEL    = $FFE8                ; model byte: 0 CM, 1 XP, 2 LA, 13/14/29/30 four-line

; ---- key codes
K_ON    = 1
K_MODE  = 2
K_UP    = 3
K_DOWN  = 4
K_LEFT  = 5
K_RIGHT = 6
K_DEL   = 8
K_EXE   = 13
K_SPACE = 32

; ---- error codes returned to the launcher in X
E_OK     = 0
E_NOPACK = 1                    ; game files not found
E_FILES  = 2                    ; a block is missing or damaged

; ---- sides
SOLID   = 1
HOLLOW  = 2

; ---- commands returned by the play and menu screens (A), with B = column
C_NONE  = 0
C_DROP  = 1                     ; drop in column B
C_BACK  = 2                     ; take back
C_HINT  = 3
C_COACH = 4
C_LIST  = 5                     ; the move list
C_MENU  = 6
C_NEW   = 7                     ; new game, B = mode (0 one player, 1 two, 2 demo)
C_SWAP  = 8                     ; swap sides
C_SET   = 9                     ; settings (B = first item)
C_EXPORT = 10
C_IMPORT = 11
C_SETUP = 12
C_RESIGN = 13
C_LEAVE = 14
C_HELP  = 15
C_FLAG  = 16                    ; the side to move ran out of time

; ---- screen driver entries (a jump table at DRV)
DV_INIT   = 0                   ; glyphs, clear, panel positions (kv_plines, kv_ppos)
DV_GLYPHS = 3                   ; send the glyphs again (after switching on)
DV_CELL   = 6                   ; A = column, B = row: show that cell from the board
DV_BOARD  = 9                   ; show the whole board
DV_MARK   = 12                  ; A = side: A = the character for its disc in the panel

; ---- OV_GAME entries
G_LOAD  = 0                     ; the saved game, or the defaults and a new game
G_SAVE  = 1
G_NEWG  = 2                     ; a new game: B = mode
G_BACK  = 3                     ; take back
G_RSAVE = 4                     ; g_rec replayed (the history cleared) and saved: after import, set-up
G_REPLAY = 5                    ; g_rec replayed (the position as it was)
; ---- OV_BOOK and OV_COACH (one source)
B_TURN  = 0                     ; OV_BOOK: the Psion's turn: A = the book's column, or 7 (search set up)
B_COACH = 0                     ; OV_COACH: the coach's verdict on the panel
; ---- OV_EXPORT entries (its files are built and read in the driver's area: see there)
X_EXPORT = 0                    ; the game to the next A:C4Gn (menu, E on the result), then saved
X_READ  = 1                     ; X = n: read A:C4Gn into the game (from OV_IMPORT); 0: A:C4LAST
X_NEW   = 2                     ; (OV_END's E_NEW, the answer yes) the export, then OV_NEWG (kv_arg = mode)
X_END   = 3                     ; a result just counted (OV_RESULT): A:C4LAST, Keep All exports, then saved
ALA_FREE = $2040                ; the first byte above the allocated cells (files on A: among them)
; ---- OV_END entries
E_KEYS  = 0                     ; after the result: the keys
E_NEW   = 1                     ; the command C_NEW (kv_arg = mode): with Keep Ask, a result
                                ; not kept is asked about ("Export game?"); then the new game
; ---- OV_HELP entries
H_HELP  = 0
H_TALLY = 1                     ; after OV_RESULT: the tally (one player), then OV_END

; ---- OV_FX entries (stretch goals: animations)
X_FALL  = 0                     ; A = column: the disc falls (before it is made)
X_EMPTY = 1                     ; the board empties (a new game), then OV_GAME's G_NEWG
X_MARK  = 2                     ; after the Psion's move: a solved value into the history,
                                ; and (one player) its disc blinks twice
FX_FALL = 1                     ; build constants: 0 leaves an animation out
FX_EMPTY = 1

; ---- the review's tactics: OV_LIST (entry L_TACT) works out each move's
; and leaves them, 2 bits a move as the history, in the top 11 bytes of
; slot A, where OV_REVIEW (which then loads below them) reads them:
; 1 missed a win, 2 allows four, 3 allows a fork
L_TACT  = 1                     ; (RV_TAC = SLOTA+SLOTA_SIZE-11 in those two:
                                ; the bootstrap has no SLOTA)
L_DROP  = 2                     ; the command C_DROP (kv_arg = column): the coach's check, then cm_drop
P_WARN  = 2                     ; OV_PANEL: the check's mark (X = 1-3), EXE drops it
; ---- the result's last panel line (2 lines: how it ended; 4: "EXE new game"),
; kept by OV_RESULT in the top 12 bytes of slot A for OV_END's hints
; (RS_LINE = SLOTA+SLOTA_SIZE-12 in OV_RESULT, OV_HELP and OV_END)
