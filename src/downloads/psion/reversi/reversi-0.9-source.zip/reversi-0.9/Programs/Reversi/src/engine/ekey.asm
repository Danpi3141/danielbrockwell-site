; =====================================================================
; The position key and the search table (ref/engine.js key / ttIndex)
; 24 bits h = e_h (high), e_h+1, e_h+2 (low). Start $019DC5 (Solid to
; move) or $019DC6; then for each row 1-6, a-d then e-h: c = the four
; squares, 2 bits each, the first highest; h ^= c; h = h * $193 (24 bits).
; Index = (h >> 17) & 63 (64 entries), check = the low 16 bits.
; Entry (4 bytes): check high, check low, square 0-47 + kind * 64, score.
; =====================================================================

e_hash: ldd  #$019D
        std  e_h
        ldaa e_side
        adda #$C4
        staa e_h+2
        ldx  #e_bd+11
.row:   bsr  .four
        bsr  .four
        inx                     ; the border on the right and on the left
        inx
        cpx  #e_bd+71
        bne  .row
        rts
.four:  ldaa 0,x                ; c = the four squares, 2 bits each
        asla
        asla
        oraa 1,x
        asla
        asla
        oraa 2,x
        asla
        asla
        oraa 3,x
        ldab #4
        abx
        eora e_h+2              ; h ^= c
        staa e_h+2
        ldab #$93
        mul                     ; D = h0 * $93
        stab e_hn0              ; the new low byte
        tab
        clra
        addb e_h+2
        adca #0
        std  e_tw               ; P0 high + h0
        ldaa e_h+1
        ldab #$93
        mul                     ; D = h1 * $93
        std  e_hp1
        clra
        ldab e_hp1+1
        addd e_tw               ; A = the carry, B = the new middle byte
        stab e_hn1
        staa e_hc
        ldaa e_h
        ldab #$93
        mul                     ; B = lo(h2 * $93)
        addb e_hp1
        addb e_h+1
        addb e_hc
        stab e_h
        ldaa e_hn1
        staa e_h+1
        ldaa e_hn0
        staa e_h+2
        rts

; e_ttx: X = this position's entry (after e_hash)
e_ttx:  ldab e_h
        lsrb
        andb #63
        clra
        asld
        asld
        addd #E_TT
        xgdx
        rts

; e_sqof: B = square index -> B = 0-47
e_sqof: clra
.l:     subb #10
        bcs  .d
        inca
        bra  .l
.d:     addb #9                 ; the column 0-7
        deca                    ; the row 0-5
        asla
        asla
        asla
        aba
        tab
        rts

; e_idxof: B = 0-47 -> B = square index (11 + row*10 + column)
e_idxof:tba
        anda #7
        staa e_tw
        lsrb
        lsrb
        lsrb                    ; the row
        tba
        aslb
        aslb
        aba                     ; row * 5
        asla                    ; row * 10
        adda e_tw
        adda #11
        tab
        rts
