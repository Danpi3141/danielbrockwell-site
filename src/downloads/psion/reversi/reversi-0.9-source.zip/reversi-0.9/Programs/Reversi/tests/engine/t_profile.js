// Where the search's time goes on the 6303: every instruction's cycles credited to the routine it is
// in (labels from the engine's listing, local labels folded into their routine), over the speed
// test's 20 middle-game positions at level 6 and 10 exact endings at 12 empty squares (level 8).
// node t_profile.js [build: true]
'use strict';
const { Harness } = require('./harness.js');
const { Engine, LEVELS, rnd } = require('../../ref/engine.js');
function positions(n, lo, hi, seed) {
  const st = { seed }, pos = [];
  while (pos.length < n) {
    const e = new Engine();
    let passes = 0;
    const stop = lo + rnd(st) % (hi - lo + 1);
    while (e.empties() > stop) {
      const l = e.legal();
      if (!l.length) { e.pass(); if (++passes === 2) break; continue; }
      passes = 0;
      e.make(e.think({ level: 2, seed: rnd(st) }).move);
    }
    if (e.legal().length && e.empties() === stop) pos.push([Array.from(e.bd), e.side]);
  }
  return pos;
}
const h = new Harness({ build: process.argv[2] !== 'false' });
const syms = Object.entries(h.sym).filter(([n]) => h.seg[n] === 'rel' && !n.includes('.')).map(([n, v]) => [v + 0x3000, n]).sort((a, b) => a[0] - b[0]);
const owner = (pc) => { let lo = 0, hi = syms.length - 1, r = '?'; while (lo <= hi) { const m = (lo + hi) >> 1; if (syms[m][0] <= pc) { r = syms[m][1]; lo = m + 1; } else hi = m - 1; } return r; };
const cache = new Map();
const prof = {};
let lastPc = -1, lastCyc = 0, on = false;
h.m.dbg.setTrace((pc) => {
  const c = h.m.cycles();
  if (on && lastPc >= 0) { let o = cache.get(lastPc); if (!o) { o = owner(lastPc); cache.set(lastPc, o); } prof[o] = (prof[o] || 0) + (c - lastCyc); }
  lastPc = pc; lastCyc = c;
});
function run(label, pos, opts) {
  for (const k in prof) delete prof[k];
  let nodes = 0, cyc = 0;
  for (const [bd, side] of pos) {
    h.setPos(bd, side);
    on = true; lastPc = -1;
    const a = h.think(Object.assign({ seed: 1 }, opts));
    on = false;
    nodes += a.nodes; cyc += a.cycles;
  }
  const tot = Object.values(prof).reduce((s, v) => s + v, 0);
  console.log(`${label}: ${nodes} positions, ${(nodes / (cyc / 921600)).toFixed(1)} a second`);
  for (const [n, v] of Object.entries(prof).sort((a, b) => b[1] - a[1]).slice(0, 16)) console.log(`  ${n.padEnd(10)} ${(100 * v / tot).toFixed(1).padStart(5)}%`);
}
const L6 = LEVELS[6], L8 = LEVELS[8];
run('middle game, level 6', positions(20, 20, 28, 2026), { nodes: L6.nodes, exact: L6.exact });
run('exact endings, 12 empty', positions(10, 12, 12, 77), { nodes: L8.nodes, exact: L8.exact });
