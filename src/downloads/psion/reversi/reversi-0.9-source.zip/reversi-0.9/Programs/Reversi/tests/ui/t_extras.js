// Stretch goals through the keys: the corner handicap, player names (four-line panel, tally
// heading), the last-move marker (L), and the ripple leaving the board as the record says.
'use strict';
const { Game, assert } = require('./lib.js');

function settings(g, line) {        // MODE > Settings, to line n
  g.waitHuman();
  g.key('MODE', 0.6);
  for (let k = 0; k < 6; k++) g.key('DOWN', 0.2);
  g.key('EXE', 0.8);
  for (let k = 0; k < line; k++) g.key('DOWN', 0.2);
}

function run(model) {
  const g = new Game(model);
  g.start();
  const log = (m) => console.log(`[${model}] ${m}`);
  g.poke('st_level', 1);
  // names: Player 1 DAN, Player 2 (none)
  settings(g, 12);                        // (Names: after Coach, Auto, Demo H)
  assert(/>Names/.test(g.panel().join('|')), 'the Names line: ' + g.panel().join('|'));
  g.key('EXE', 0.6);
  assert(/Player 1/.test(g.text()), 'asks for player 1: ' + g.text());
  g.keys(['D', 'A', 'N', 'EXE'], 0.25);
  g.key('ON', 0.4);                    // player 2: no name
  g.key('ON', 0.6);                    // out of the settings
  const nm = g.bytes('g_names', 4);
  assert(nm[0] === 3 && String.fromCharCode(nm[1], nm[2], nm[3]) === 'DAN', 'name kept: ' + nm);
  log('names ok');
  // the handicap: 2 corners, a new game: you (Solid) have a1 and h6
  settings(g, 7);
  g.key('RIGHT', 0.3); g.key('RIGHT', 0.3);
  assert(g.peek('st_hcap') === 2, 'handicap 2: ' + g.peek('st_hcap'));
  g.key('ON', 0.6);
  g.waitHuman();
  g.key('MODE', 0.6); g.key('EXE', 1.5);     // New game
  g.waitHuman();
  const b = g.board();
  assert(b[0][0] === 'X' && b[5][7] === 'X' && g.peek('g_setup') === 2, 'corners for you:\n' + b.join('\n'));
  if (g.m.lines === 4) assert(/DAN/.test(g.panel()[0]), 'your name in the panel: ' + g.panel().join('|'));
  log('handicap ok' + (g.m.lines === 4 ? ', panel ' + g.panel()[0].trim() : ''));
  // a move, the Psion's reply, then L: the board flashes and is the same afterwards
  g.key('EXE', 1.0);
  g.waitHuman();
  const before = g.board().join('/');
  const glyphs = new Set();
  g.key('L', 0.05);
  for (let t = 0; t < 30; t++) { g.m.runSeconds(0.1); glyphs.add(JSON.stringify(g.m.udgs()) + g.m.cells().join(',')); }
  g.waitHuman();
  assert(g.board().join('/') === before, 'L leaves the board as it was');
  assert(glyphs.size > 1, 'L changed the screen while it flashed');
  log('last-move marker ok (' + glyphs.size + ' screens)');
  // the tally heading has the name
  g.key('MODE', 0.6);
  for (let k = 0; k < 8; k++) g.key('DOWN', 0.2);
  g.key('EXE', 0.8);
  assert(/DAN +W-D-L/.test(g.panel()[0]), 'tally heading: ' + g.panel()[0]);
  g.key('EXE', 0.5);
  log('tally heading ok');
}

for (const model of (process.argv[2] || 'cm,lz64').split(',')) run(model);
