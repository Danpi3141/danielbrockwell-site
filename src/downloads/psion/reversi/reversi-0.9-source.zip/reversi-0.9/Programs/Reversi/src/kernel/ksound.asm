; ---------------------------------------------------------------------
; Sound. BZ$TONE plays D = pitch (921,600 / (78 + 2D) Hz) for X ms.
; st_sound: 0 on, 1 off. A sound is a list of notes: pitch (word), ms
; (byte); pitch 0 ends it.
; ---------------------------------------------------------------------
snd_tick:   fdb  191                    ; a disc placed
            fcb  20
            fdb  0
snd_buzz:   fdb  3033                   ; refused
            fcb  150
            fdb  0
; (the win and lose tunes are OV_RESULT's)

; X = sound
snd_play:
        tst  st_sound
        bne  .x
.n:     ldd  0,x
        beq  .x
        pshx
        ldab 2,x
        clra
        pshb
        psha
        ldd  0,x
        pulx                    ; X = ms
        os   BZ$TONE
        pulx
        inx
        inx
        inx
        bra  .n
.x:     rts

buzz:   ldx  #snd_buzz
        bra  snd_play
