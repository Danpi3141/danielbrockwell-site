// The coach's check of your drop (19 Nov): with the coach on, a drop the review would mark
// (tests/ui/tactics.js: "Missed a win", "Allows four", "Allows fork") is named first, on the
// coach's line, with "EXE drops it" on line 2; EXE or DOWN drops it, any other key goes back to
// choosing. Any other drop goes straight in.
//  - one player (level 1, Pace Fast): marked and unmarked drops, EXE / DOWN / ON after a mark;
//  - the coach off: a marked drop goes straight in;
//  - two players: the same; and the move timer running out on a marked column drops it unasked.
//   node tests/ui/t_drop.js [models...] (default cm lz64)
'use strict';
const { Game, assert } = require('./lib');
const T = require('./tactics');
const models = process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'lz64'];
let rnd = 5; const rand = n => { rnd = (rnd * 1103515245 + 12345) & 0x7fffffff; return (rnd >> 8) % n; };
const KEY = 'UVWOPQI';
let total = 0;

for (const model of models) {
  const g = new Game(model).start(); g.waitHuman(60);
  const cl = g.m.lines === 4 ? 2 : 0;                       // the coach's line
  const pan = () => g.panel().map(s => s.trim());
  const marks = () => {
    const rec = g.rec(), b = T.board(rec), n = rec.length;
    const legal = [0, 1, 2, 3, 4, 5, 6].filter(c => b[c][5] === 0);
    return { legal, n, m: legal.map(c => [c, T.tactic(rec.concat(c), n + 1)]) };
  };
  const seen = { kinds: [0, 0, 0, 0], exe: 0, down: 0, back: 0, plain: 0 };
  // one turn: choose a column (marked when it can, half the time) and check what happens
  const turn = (how, preferMark) => {
    const { legal, n, m } = marks();
    const bad = m.filter(([, k]) => k), good = m.filter(([, k]) => !k);
    const pick = bad.length && (preferMark || rand(2)) ? bad[rand(bad.length)] : (good.length ? good : m)[rand((good.length ? good : m).length)];
    const [c, k] = pick;
    g.key(KEY[c], 0.1); g.key('EXE', 0.6);
    if (!k) {
      g.waitFor(() => g.peek('g_n') > n, 3, 0.02);
      assert(g.peek("g_n") > n && g.rec()[n] === c, `${model}: an unmarked drop (col ${c + 1}) goes straight in: rec ${g.recStr()} n ${n} mode ${g.peek("g_mode")} coach ${g.peek("st_coach")}
${g.text()}`);
      seen.plain++;
      return;
    }
    const p = pan();
    assert(g.peek('g_n') === n, `${model}: a marked drop waits (col ${c + 1}, ${T.TEXT[k]})`);
    assert(p[cl] === T.TEXT[k] && p[1] === 'EXE drops it', `${model}: col ${c + 1}: "${p[cl]}" / "${p[1]}", want "${T.TEXT[k]}"`);
    seen.kinds[k]++;
    const act = how || ['EXE', 'DOWN', 'ON'][rand(3)];
    g.key(act, 0.6);
    if (act === 'ON') {
      assert(g.waitFor(() => g.humanTurn(), 3, 0.05) && g.peek('g_n') === n, `${model}: ON goes back to choosing`);
      seen.back++;
      const ok = good.length ? good[rand(good.length)][0] : c;  // then a column it doesn't mark
      g.key(KEY[ok], 0.1); g.key('EXE', 0.6);
      if (ok === c) g.key('EXE', 0.6);
      g.waitFor(() => g.peek('g_n') > n, 3, 0.02);
      assert(g.rec()[n] === ok, `${model}: then col ${ok + 1} dropped`);
      return;
    }
    g.waitFor(() => g.peek('g_n') > n, 3, 0.02);
    assert(g.peek('g_n') > n && g.rec()[n] === c, `${model}: ${act} drops it (col ${c + 1})`);
    seen[act === 'EXE' ? 'exe' : 'down']++;
  };
  const newGame = () => { g.waitFor(() => g.peek('g_over') === 2, 30); g.m.runSeconds(1); g.key('EXE', 2); };

  // ---- one player, the coach on
  g.poke('st_level', 1); g.poke('st_you', 0); g.poke('st_pace', 1); g.poke('st_coach', 1);
  g.keys(['ON', 'N', 'EXE', 'EXE'], 1.0);
  const want = () => seen.kinds[2] < 2 || seen.exe < 2 || seen.down < 2 || seen.back < 2 || seen.plain < 5;
  for (let gi = 0; gi < 40 && want(); gi++) {
    const ps = g.peek('g_psion');
    while (!g.peek('g_over') && want()) {
      g.waitFor(() => g.peek('g_over') || (g.humanTurn() && (g.peek('g_n') % 2) + 1 !== ps), 60, 0.05);
      if (g.peek('g_over')) break;
      turn(null, false);
    }
    newGame();
  }
  assert(!want(), `${model}: one player, each case seen: ${JSON.stringify(seen)}`);
  console.log(`${model}: one player: ${JSON.stringify(seen)}`);
  total += seen.kinds.reduce((a, b) => a + b) + seen.plain;

  // ---- the coach off: a marked drop goes straight in
  g.poke('st_coach', 0);
  let off = false;
  for (let gi = 0; gi < 20 && !off; gi++) {
    const ps = g.peek('g_psion');
    while (!g.peek('g_over') && !off) {
      g.waitFor(() => g.peek('g_over') || (g.humanTurn() && (g.peek('g_n') % 2) + 1 !== ps), 60, 0.05);
      if (g.peek('g_over')) break;
      const { legal, n, m } = marks(), bad = m.filter(([, k]) => k);
      const c = bad.length ? bad[0][0] : legal[rand(legal.length)];
      g.key(KEY[c], 0.1); g.key('EXE', 0.6);
      g.waitFor(() => g.peek('g_n') > n, 3, 0.02);
      assert(g.rec()[n] === c, `${model}: coach off: col ${c + 1} straight in`);
      if (bad.length) off = true;
    }
    if (!off) newGame();
  }
  assert(off, `${model}: coach off: no marked drop met`);

  // ---- two players, the coach on
  g.poke('st_coach', 1); g.poke('st_clock', 0); g.poke('st_timer', 0); g.poke('st_swap', 0); g.poke('st_match', 0);
  const two = () => {
    g.keys(['ON', 'N', 'EXE'], 0.5);
    g.waitText(/One player/, 10);
    for (let i = 0; i < 3 && !g.text().includes('>Two players'); i++) g.key('DOWN', 0.3);
    g.key('EXE', 0.5); g.names();
    assert(g.peek('g_mode') === 1, `${model}: two players`);
  };
  two();
  let marked2 = 0;
  const more = () => marked2 < 3 || !seen.kinds[1];         // ("Missed a win": the Psion at level 1 never leaves one)
  for (let gi = 0; gi < 10 && more(); gi++) {
    while (!g.peek('g_over') && more()) {
      g.waitFor(() => g.peek('g_over') || g.humanTurn(), 10, 0.05);
      if (g.peek('g_over')) break;
      const before = seen.kinds.reduce((a, b) => a + b);
      turn('EXE', true);
      if (seen.kinds.reduce((a, b) => a + b) > before) marked2++;
    }
    if (more()) { newGame(); if (g.peek('g_mode') !== 1) two(); }
  }
  assert(!more(), `${model}: two players: ${marked2} marked drops, kinds ${seen.kinds}`);
  // the move timer runs out on a marked column: dropped unasked
  g.poke('st_timer', 1);                                     // 10 s a move
  two();
  let timed = false;
  for (let i = 0; i < 40 && !timed && !g.peek('g_over'); i++) {
    g.waitFor(() => g.humanTurn(), 10, 0.05);
    const { n, m } = marks(), bad = m.filter(([, k]) => k);
    if (!bad.length) { const c = m[rand(m.length)][0]; g.key(KEY[c], 0.1); g.key('EXE', 0.6); g.waitFor(() => g.peek('g_n') > n, 3, 0.02); continue; }
    const c = bad[0][0];
    g.key(KEY[c], 0.1);
    assert(g.waitFor(() => g.peek('g_n') > n, 14, 0.1), `${model}: the timer ran out on col ${c + 1}: no drop\n${g.text()}`);
    assert(g.rec()[n] === c && !pan().includes('EXE drops it'), `${model}: the timer's drop unasked (col ${c + 1})`);
    timed = true;
  }
  assert(timed, `${model}: no marked column met with the timer`);
  console.log(`${model}: two players: ${marked2} marked drops (kinds ${seen.kinds}), the timer's drop unasked`);
}
console.log(`drop check ok: ${total} drops`);
