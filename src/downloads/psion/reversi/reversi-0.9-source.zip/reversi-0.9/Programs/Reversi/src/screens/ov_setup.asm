; =====================================================================
; OV_SETUP: set up the board. The cursor moves freely with the four
; cursor keys (it flashes); SPACE steps its square through empty, Solid
; and Hollow; EXE finishes and asks which side moves; ON/CLEAR leaves the
; game as it was. The new game starts from that position (g_setup: never
; counted in the tally).
; =====================================================================
        include "../defs.inc"

        jmp  su_start
        jmp  su_hcap
        jmp  names

su_start:
        clr  kv_hon             ; (no hints while setting up)
        ldaa #11
        staa su_cur
.k:     jsr  pn_msg
        fcl  "Set up"
        jsr  su_key
        ldab su_cur
        ldaa su_k
        cmpa #K_SPACE
        bne  .n1
        ldx  #e_bd              ; empty, Solid, Hollow, empty...
        abx
        ldaa 0,x
        inca
        cmpa #3
        bne  .s
        clra
.s:     staa 0,x
        bra  .k
.n1:    ldab #-1
        cmpa #K_LEFT
        beq  .mv
        ldab #1
        cmpa #K_RIGHT
        beq  .mv
        ldab #-10
        cmpa #K_UP
        beq  .mv
        ldab #10
        cmpa #K_DOWN
        beq  .mv
        cmpa #K_EXE
        beq  .done
        cmpa #K_ON
        bne  .k
        jsr  pn_clear           ; the game as it was, replayed
        bra  su_rs
.mv:    addb su_cur             ; a square off the board: stays
        ldx  #e_bd
        abx
        ldaa 0,x
        cmpa #3
        beq  .k
        stab su_cur
        bra  .k
.done:  jsr  pn_msg
        fcl  "Who moves?"
        ldx  #su_who
        ldaa #2
        clrb
        jsr  menu
        cmpa #$FF
        beq  .k
        inca
        staa g_sside
        bsr  enc
        clr  g_n
        clr  g_over
        jsr  pn_clear
; the game replayed from its start position and saved (OV_GAME)
su_rs:  ldd  #OV_GAME*256+G_REPSV
        jmp  ov_call

; S_HCAP (stretch goal 5, the corner handicap): a new game's starting
; position (on the board) and the corners for the weaker side: two players
; Hollow, one player you. Counted in the tally (g_setup 2).
su_hcap:ldaa #HOLLOW
        tst  g_psion
        beq  .w
        ldaa g_you
.w:     ldx  #su_corn
        ldab st_hcap
.c:     pshb
        ldab 0,x
        pshx
        ldx  #e_bd
        abx
        staa 0,x
        pulx
        inx
        pulb
        decb
        bne  .c
        ldaa #SOLID
        staa g_sside
        bsr  enc
        inc  g_setup
        bra  su_rs
su_corn:fcb  11,68,18,61        ; a1, h6, h1, a6

; the board as the start position (2 bits a square, a1 first); g_setup 1
enc:    ldx  #g_start
.c:     clr  0,x
        inx
        cpx  #g_start+12
        bne  .c
        clr  su_sq
.e:     ldab su_sq
        jsr  e_idxof
        ldx  #e_bd
        abx
        ldaa 0,x                ; its two bits into place
        ldab su_sq
        andb #3
        eorb #3
.sh:    tstb
        beq  .v
        asla
        asla
        decb
        bra  .sh
.v:     psha
        ldab su_sq
        lsrb
        lsrb
        ldx  #g_start
        abx
        pula
        oraa 0,x
        staa 0,x
        inc  su_sq
        ldaa su_sq
        cmpa #48
        bne  .e
        ldaa #1
        staa g_setup
        rts

; a key, the cursor flashing (its square and the other look); su_k = key
su_key: ldaa #200
        staa su_n
.f:     ldx  #e_bd
        ldab su_cur
        abx
        ldaa 0,x                ; the square, then empty (or Solid when empty)
        ldab su_n
        andb #1
        beq  .o
        tsta
        beq  .so
        clra
        bra  .o
.so:    ldaa #SOLID
.o:     staa kv_ovv
        ldaa su_cur
        staa kv_ovs
        jsr  DRV+DV_SQ
        ldaa #3
        jsr  key_wait
        tstb
        bne  .k
        dec  su_n
        bne  .f
        clr  kv_ovs
        ldaa su_cur
        jsr  DRV+DV_SQ
        clra
        jsr  key_wait
.k:     stab su_k
        clr  kv_ovs
        ldaa su_cur
        jmp  DRV+DV_SQ

su_who: fcl  "Solid"
        fcl  "Hollow"
su_cur: fcb  0
su_k:   fcb  0
su_n:   fcb  0
su_sq:  fcb  0

MENU_V  = 0
        include "../kernel/kmenu.asm"

; S_NAMES (stretch goal 3, from the settings: kv_arg is its line, kept for
; OV_SET to start on)
; the names: "Player 1:" then "Player 2:", each up to 7 letters
names:  ldx  #g_names
        stx  se_np
        ldaa #'1'
        staa se_pn
.p:     jsr  lb_clr
        jsr  lb_s
        fcl  "Player "
        ldaa se_pn
        jsr  lb_ch
        ldaa #':'
        jsr  lb_ch
        clra
        jsr  lb_put
.ed:    jsr  lb_clr             ; the name so far and a cursor
        ldx  se_np
        jsr  lb_fcl
        ldaa #'_'
        jsr  lb_ch
        ldaa #1
        jsr  lb_put
        clra
        jsr  key_wait
        ldx  se_np
        cmpb #K_EXE
        beq  .nx
        cmpb #K_ON
        bne  .del
        clr  0,x                ; no name
        bra  .nx
.del:   cmpb #K_DEL
        bne  .l
        tst  0,x
        beq  .ed
        dec  0,x
        bra  .ed
.l:     cmpb #'A'
        blo  .ed
        cmpb #'Z'
        bhi  .ed
        ldaa 0,x
        cmpa #7
        bhs  .ed
        inc  0,x
        inca
        pshb
        tab
        abx
        pulb
        stab 0,x                ; the letter in its place
        bra  .ed
.nx:    ldab #8
        abx
        stx  se_np
        inc  se_pn
        ldaa se_pn
        cmpa #'3'
        bne  .p
        jsr  pn_clear           ; back to the settings, on the Names line
        ldd  #OV_SET*256
        jmp  ov_call
se_np:  fdb  0
se_pn:  fcb  0
