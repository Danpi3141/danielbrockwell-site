; =====================================================================
; OV_EXPORT (stretch goal 8, export): the game to the first free file
; A:RVGAME1..A:RVGAME99, one record of text that the Comms Link sends to a
; PC as a line (and a PC can send back for OV_IMPORT): the moves as squares,
; "d2c4e5..." (passes are not written: replaying finds them). A game from a
; set-up or handicap position starts with it: 48 characters, a1 to h1, then
; a2 to h2 ... ('-' empty, 'X' Solid, 'O' Hollow), a space, who moves first
; (X or O), a space. "Saved" over "RVGAME3", or "Cannot save" (no room, or 99
; files). A file is made only while the gap between the files and the array
; stays over KEEP_GAP, so the game can always start again.
; The name and the record are built in the screen driver's area, which is
; read in again afterwards (none of slot A is a buffer).
; =====================================================================
        include "../defs.inc"

FN      = DRV                   ; a file name, with its length
RD      = DRV+16                ; the record, with its length
KEEP_GAP = 256

        jmp  ex_start

ex_start:
        jsr  pn_clear
        ldab g_n
        bne  .go
        tst  g_setup
        bne  .go
        jsr  lb_s
        fcl  "No moves"
        bra  .say
.go:    ldaa #1
        staa ex_k
.find:  bsr  ex_name            ; the first free name
        clr  kv_pkok
        ldx  #FN
        os   FL$OPEN
        bcs  .free
        inc  ex_k
        ldaa ex_k
        cmpa #100
        bne  .find
        bra  .fail
.free:  ldd  kv_base            ; room: the gap below the array
        subd ALA_FREE
        bcs  .mk                ; (the array is not above the files: no limit)
        subd #KEEP_GAP
        bcs  .fail
.mk:    bsr  ex_rec
        ldx  #FN
        os   FL$CRET
        bcs  .fail
        tab
        os   FL$RECT
        ldx  #RD
        os   FL$WRIT
        bcs  .del
        jsr  lb_s               ; "Saved", then the name on the last line
        fcl  "Saved"
        ldaa kv_plines
        suba #2
        jsr  lb_put
        jsr  lb_clr
        ldab FN                 ; the name without "A:"
        subb #2
        stab FN+2
        ldx  #FN+2
        jsr  lb_fcl
        bra  .say
.del:   ldx  #FN                ; no room after all: the empty file goes again
        os   FL$DELN
.fail:  jsr  lb_clr
        jsr  lb_s
        fcl  "Cannot save"
.say:   clr  kv_pkok            ; the driver again (its area was the buffer)
        ldaa kv_drv
        jsr  ov_load
        ldaa kv_plines
        deca
        jsr  lb_put
        clra                    ; until a key
        jsr  key_wait
        jsr  pn_clear
        clra                    ; (no command)
        rts

; FN = "A:RVGAMEk", with its length (k = ex_k)
ex_name:
        ldd  #8
        std  T0
        ldx  #ex_fn
        ldd  #FN+1
        os   UT$CPYB
        ldx  #FN+9
        clra
        ldab ex_k
        os   UT$UTOB
        addb #8
        stab FN
        rts

; RD = the record: the set-up position if any, then the moves
ex_rec: ldx  #RD+1
        tst  g_setup
        beq  .mv
        clrb                    ; 48 squares, a1 first, 2 bits each in g_start
.s:     pshb
        pshx
        tba
        lsra
        lsra
        tab
        ldx  #g_start
        abx
        ldaa 0,x
        pulx
        pulb
        pshb
        andb #3
.sh:    tstb
        beq  .v
        asla
        asla
        decb
        bra  .sh
.v:     anda #$C0
        ldab #'-'
        cmpa #$40
        bne  .o
        ldab #'X'
.o:     cmpa #$80
        bne  .p
        ldab #'O'
.p:     stab 0,x
        inx
        pulb
        incb
        cmpb #48
        bne  .s
        ldd  #' '*256+'X'       ; who moves first
        std  0,x
        ldaa g_sside
        cmpa #SOLID
        beq  .x
        ldaa #'O'
        staa 1,x
.x:     ldaa #' '
        staa 2,x
        inx
        inx
        inx
.mv:    clrb                    ; the moves: "d2c4..."
.m:     cmpb g_n
        beq  .e
        pshb
        pshx
        ldx  #g_rec
        abx
        ldab 0,x                ; square 0-47: row*8 + column
        tba
        anda #7
        adda #'a'
        lsrb
        lsrb
        lsrb
        addb #'1'
        pulx
        staa 0,x
        stab 1,x
        inx
        inx
        pulb
        incb
        bra  .m
.e:     xgdx                    ; the length
        subd #RD+1
        stab RD
        rts

ex_fn:  fcc  "A:RVGAME"
ex_k:   fcb  0
