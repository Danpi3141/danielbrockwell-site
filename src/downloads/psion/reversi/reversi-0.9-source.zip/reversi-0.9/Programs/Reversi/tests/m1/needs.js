// The free RAM the game really needs on a CM, and whether REV's check is right. A test procedure
// FILL takes k*2 bytes, prints FREE and calls REV: once the real REV, once a copy without the
// check (n% is always 0 or less; its code has the same layout, which the variables kept in
// REV's code need: tools/build.py rev_hole). A binary search on k finds the least FREE (at FILL)
// with which each starts the game. REV must never start a game that cannot run (it would stop
// with OUT OF MEMORY): its threshold must be at or above the copy's, by the room it keeps for the
// save files (150 while there is no A:REVSAV) and a few bytes. Also FREE on a blank CM as a
// procedure like REV sees it. (From Connect 4's.)
'use strict';
const fs = require('fs'), path = require('path'), { execSync } = require('child_process');
const { Machine } = require('../../tools/emu');
const ROOT = path.join(__dirname, '..', '..');
const out = path.join(ROOT, 'build', 'needs');
fs.mkdirSync(out, { recursive: true });
const meta = JSON.parse(fs.readFileSync(path.join(ROOT, 'build', 'game', 'build.json'), 'utf8'));
const Tools = path.join(ROOT, '..', '..', 'Tools');
const TAG = [0x52, 0x56, 0x4B, 0x31];
const revg = fs.readFileSync(path.join(ROOT, 'build', 'game', 'REVG.opl'), 'latin1');
const rev = fs.readFileSync(path.join(ROOT, 'build', 'game', 'REV.opl'), 'latin1');
const revNoCheck = rev.replace(/n%=\d+\+/, 'n%=0+');
if (revNoCheck === rev) throw new Error('REV.opl: its check not found');

function pack(name, procs) {
  const files = procs.map(([n, src]) => { const f = path.join(out, n + '.opl'); fs.writeFileSync(f, src, 'latin1'); return '"' + f + '"'; });
  execSync(`python "${path.join(Tools, 'opl2opk.py')}" -f --target cm "${path.join(out, name)}" ${files.join(' ')}`, { stdio: 'pipe' });
  return path.join(out, name);
}
function boot(rom, p) {
  const m = new Machine({ rom, ram: 8 });
  m.boot();
  m.insertPack(p, 0);
  m.insertPack(path.join(ROOT, 'build', 'game', 'REV.opk'), 1);
  return m;
}
function attempt(k, rom, src) {
  const p = pack('t.opk', [['FILL', `FILL:\nLOCAL f%(${k})\nPRINT FREE :GET\nREV:\n`], ['REV', src], ['REVG', revg]]);
  const m = boot(rom, p);
  m.runProc('FILL', 'B');
  m.runSeconds(1.5);
  const free = +(m.screenText().match(/(\d+)/) || [0, -1])[1];
  m.press('EXE', 3, 10);
  m.runSeconds(4);
  const t = m.screenText();
  if (/MEMORY/.test(t) && src === rev) throw new Error(`${rom} k=${k}: REV let the game start without the memory: ${t}`);
  const ok = m.find(TAG, 0x2000, 0x4000) >= 0 && !/MEMORY|ERROR|NEEDS/.test(t);
  return { free, ok, text: t };
}
function least(rom, src) {
  let lo = 0, hi = 1500;
  while (hi - lo > 1) { const mid = (lo + hi) >> 1; if (attempt(mid, rom, src).ok) lo = mid; else hi = mid; }
  return attempt(lo, rom, src).free;
}

for (const rom of ['33-cm.rom', '24-cm.rom']) {
  const p = pack('f.opk', [['FR', 'FR:\nLOCAL n%\nPRINT FREE :GET\n']]);
  const m = boot(rom, p);
  m.runProc('FR', 'B');
  m.runSeconds(1.5);
  const blank = +(m.screenText().match(/(\d+)/) || [0, -1])[1];
  const real = least(rom, rev), need = least(rom, revNoCheck);
  const kept = real - need;
  if (kept < 150) throw new Error(`${rom}: REV keeps only ${kept} bytes in hand (the save files need 150)`);
  console.log(`${rom}: blank CM FREE ${blank}; the game fits from FREE ${need}; REV starts it from ${real} (keeping ${kept} in hand, 150 of them for the save files); ` +
    `spare on a blank CM before the first save ${blank - real}, after it about ${blank - real + 150 - 144}`);
}
