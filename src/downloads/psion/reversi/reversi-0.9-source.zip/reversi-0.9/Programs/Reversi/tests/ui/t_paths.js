// The rarer paths: winning (a set-up position), the menu's letter jump and UP round the top,
// Reset tally (asks first), a setting going round below its lowest, DEL in a name, the empty move
// list, help's UP, ON in set-up (the game as it was), the demo going on to a new game.
'use strict';
const { Game, assert } = require('./lib.js');
for (const model of (process.argv[2] || 'cm,lz64').split(',')) {
  const g = new Game(model);
  g.start(); g.poke('st_level', 1);
  const log = m => console.log(`[${model}] ${m}`);
  // the menu: UP from the top goes to Quit; a letter jumps
  g.waitHuman(); g.key('MODE', 0.5);
  g.key('UP', 0.3);
  assert(g.panel().some(l => l.includes('>Quit')), 'UP round to Quit: ' + g.panel().join('|'));
  g.key('S', 0.3);
  assert(g.panel().some(l => l.includes('>Swap sides')), 'S jumps to Swap sides: ' + g.panel().join('|'));
  g.key('S', 0.3);
  assert(g.panel().some(l => l.includes('>Settings')), 'S again: Settings: ' + g.panel().join('|'));
  g.key('ON', 0.5);
  log('menu keys ok');
  // the empty move list
  g.menu('Move list');
  assert(/No moves/.test(g.text()), 'no moves yet: ' + g.text());
  g.m.runSeconds(1.5);
  // settings: Level LEFT from 1 goes round to 8; a name with DEL; Reset tally asks
  g.poke('st_level', 1);
  g.menu('Settings');
  g.key('LEFT', 0.3);
  assert(g.peek('st_level') === 8, 'level round to 8: ' + g.peek('st_level'));
  g.key('RIGHT', 0.3);
  for (let k = 0; k < 12; k++) g.key('DOWN', 0.15);       // (Names: after Coach, Auto, Demo H)
  g.key('EXE', 0.5); g.keys(['A', 'B', 'DEL', 'C', 'EXE'], 0.2); g.key('ON', 0.4);
  const nm = g.bytes('g_names', 3);
  assert(nm[0] === 2 && nm[1] === 65 && nm[2] === 67, 'name AC after DEL: ' + nm);
  g.key('DOWN', 0.3); g.key('EXE', 0.5);
  assert(/Reset\? EXE/.test(g.prompt()), 'reset asks: ' + g.prompt());
  g.key('EXE', 0.8);
  g.key('ON', 0.6);
  log('settings paths ok');
  // help: DOWN then UP
  g.menu('Help');
  const h0 = g.panel().join('|');
  g.key('DOWN', 0.3); g.key('UP', 0.3);
  assert(g.panel().join('|') === h0, 'help UP back to the first page');
  g.key('ON', 0.5);
  // set up then ON: the game as it was
  const before = g.board().join('/');
  g.menu('Set up'); g.key('SPACE', 0.2); g.key('ON', 1.0);
  g.waitHuman();
  assert(g.board().join('/') === before, 'ON in set up: the game as it was');
  log('help and set-up ON ok');
  // a win: a1 Solid, b1 Hollow, you (Solid) play c1
  g.menu('New game');
  g.menu('Set up');
  g.key('SPACE', 0.2); g.key('RIGHT', 0.2); g.key('SPACE', 0.2); g.key('SPACE', 0.2);
  g.keys(['DOWN', 'DOWN', 'RIGHT', 'RIGHT'], 0.15);
  g.keys(['SPACE', 'RIGHT', 'SPACE', 'SPACE', 'DOWN', 'SPACE', 'LEFT', 'SPACE', 'SPACE'], 0.15);
  g.key('EXE', 0.8); g.key('EXE', 2.0);
  g.waitHuman(); g.key('EXE', 2.0);
  g.waitFor(() => g.over(), 20);
  assert(/You win \+3/.test(g.panel().join('|')), 'a win: ' + g.panel().join('|'));
  log('win ok');
  // the review of that set-up game: move 0 is the set-up position
  g.menu('Review');
  g.key('LEFT', 0.8);
  assert(g.panel()[0].includes('Move 0/1') && g.board()[0] === 'XO......' && g.board().slice(1).every(r => r === '........'),
    'review of a set-up game: ' + g.panel()[0] + ' ' + g.board().join('/'));
  g.key('ON', 1.0);                         // (back as it was)
  log('review of a set-up game ok');
  // the demo: after its result, a new game by itself
  g.poke('st_level', 1); g.poke('st_players', 2); g.poke('g_psion', 3);
  g.menu('New game');
  let games = 0, lastN = 0;
  for (let t = 0; t < 400 && games < 2; t++) { g.m.runSeconds(1); const n = g.peek('g_n'); if (n < lastN) games++; lastN = n; }
  assert(games >= 2, 'the demo went on to new games: ' + games);
  log('demo goes on ok');
}
