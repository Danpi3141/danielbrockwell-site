'use strict';
const { Game } = require('./lib.js');
const model = process.argv[2] || 'la', level = +(process.argv[3] || 5);
const g = new Game(model);
g.start();
g.poke('st_level', level);
let last = -1;
for (let t = 0; t < 400; t++) {
  g.waitFor(() => /EXE: menu/.test(g.prompt()) || (g.humanTurn() && g.peek('g_n') !== last), 120, 0.2);
  if (/EXE: menu/.test(g.prompt())) { console.log('done'); break; }
  const n = g.peek('g_n');
  if (n === last) {
    const d = g.m.dbg;
    console.log('stuck n', n, 'pc', d.pc().toString(16), 'sp', d.sp().toString(16), 'base', g.base.toString(16));
    console.log('res', g.peek('kv_res'), 'nodes', g.bytes('e_nodes', 3), 'abort?', 'side', g.peek('e_side'), 'psion', g.peek('g_psion'));
    const pcs = {}; d.setTrace(pc => { pcs[pc] = (pcs[pc] || 0) + 1; }); g.m.run(200000); d.setTrace(null);
    const top = Object.entries(pcs).sort((a, b) => b[1] - a[1]).slice(0, 12).map(([p, c]) => (+p - g.base).toString(16) + ':' + c);
    console.log('hot (offsets from base)', top.join(' '));
    console.log(g.text());
    break;
  }
  last = n;
  g.key('EXE', 0.3);
}
