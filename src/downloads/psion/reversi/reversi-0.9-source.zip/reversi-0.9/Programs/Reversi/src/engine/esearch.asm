; =====================================================================
; Search (ref/engine.js think / root / node / exact / thinkFixed)
; Fail-soft negamax with alpha-beta on explicit frames (E_FR, FSIZE bytes
; a ply). Scores are 16 bits: estimates within 1,000, finished games
; beyond 2,000; in the exact ending the score is the disc margin.
; A side with no move passes inside the same frame, the window turned
; round. Every move made counts one position.
; =====================================================================

INF     = 30000
NONE    = $FF
MAXD    = 12
F_A     = 0                     ; alpha (2)
F_B     = 2                     ; beta (2)
F_BEST  = 4                     ; (2)
F_BMV   = 6                     ; best move
F_I     = 7                     ; next candidate: 0 table, 1 killer, 2+ order or list
F_SQS   = 8                     ; e_sqs before the move (2)
F_FSP   = 10                    ; e_fsp before the move (2)
F_FL    = 12                    ; flags
F_MV    = 13                    ; the move being searched
F_TT    = 14                    ; the table's move
F_MOB   = 15                    ; the mover's moves (depth 1)
F_LP    = 16                    ; the sorted list (2)
F_KL    = 18                    ; the killer for this ply
FSIZE   = 19
FL_PASS = 1
FL_ANY  = 2
FL_LIST = 4
E_KIL   = E_FR+FSIZE*(MAXD+1)   ; killers, one a ply
ES      = E_KIL+MAXD+1          ; the search's own variables
e_dcur  = ES+0
e_iter1 = ES+1
e_abort = ES+2                  ; 1 the count ran out, 2 a key
e_exm   = ES+3                  ; the exact ending
e_fixm  = ES+4                  ; levels 1-2
e_fdone = ES+5                  ; the root finished a move
e_rties = ES+6
e_maxd  = ES+7
e_lim   = ES+8                  ; (3)
e_v     = ES+11                 ; (2)
e_mvt   = ES+13
e_pc    = ES+14
e_scnt  = ES+15
e_si    = ES+16
e_ss    = ES+17
e_sr    = ES+18
e_ssq   = ES+19                 ; (2)
e_sfs   = ES+21                 ; (2)
e_tsc   = ES+23                 ; (2)
e_tx    = ES+25                 ; (2)
e_skey  = ES+27                 ; 16
; the evaluation's and the key's working bytes (only used while the search runs)
e_pmob  = ES+43
e_emp0  = ES+44
e_wp    = ES+45                 ; (2)
e_ev    = ES+47                 ; (2)
e_cp    = ES+49                 ; (2)
e_c     = ES+51
e_x     = ES+52
e_k     = ES+53
e_dd    = ES+54
e_y     = ES+55
e_sg    = ES+56
e_h     = ES+57                 ; (3)
e_hn0   = ES+60
e_hn1   = ES+61
e_hc    = ES+62
e_hp1   = ES+63                 ; (2)
E_SCRATCH_END = ES+65

; ---------------------------------------------------------------------
; e_think: searches for the side to move, after e_pre (epre.asm, run from
; an overlay just before: the results cleared, the table cleared, the move
; count and the exact ending decided).
; In:  e_limit (2, positions; 0 none), e_fixd (depth for levels 1-2, 0
;      none), e_noise, e_exend (the exact ending from this many empty
;      squares), e_seed, e_poll (called every 64 positions; C set stops;
;      0 none)
; Out: e_move (square, NONE if no move), e_score (2), e_depth, e_exact
;      (0 estimate, 1 searched to the end, 2 exact margin), e_nodes (3)
; Levels 1-2 end in e_pick (epick.asm) at E_PICK.
; ---------------------------------------------------------------------
e_think:
        bsr  e_fresh
        ldaa e_exm
        bmi  .fin               ; no move
        beq  .nx
        clr  e_iter1            ; the exact ending
        clr  e_fixm
        jsr  e_root
        ldaa e_abort
        beq  .xdone
        cmpa #1
        beq  .drop
        tst  e_fdone            ; a key: the best so far, or the first in the list
        bne  .xdone
        ldx  #E_FR
        ldx  F_LP,x
        ldaa 0,x
        staa e_move
        rts
.xdone: bsr  e_res
        ldaa e_emp0
        staa e_depth
        ldaa #2
        staa e_exact
        rts
.drop:  bsr  e_fresh             ; over the count: an ordinary search
.nx:    clr  e_exm
        clr  e_lim
        ldd  e_limit
        std  e_lim+1
        ldaa e_fixd
        beq  .deep
        staa e_dcur             ; levels 1-2: every root move scored
        ldaa #1
        staa e_iter1
        staa e_fixm
        clr  e_rties
        jsr  e_root
        jmp  E_PICK
.deep:  clr  e_fixm
        ldaa e_emp0
        cmpa #MAXD
        bls  .m
        ldaa #MAXD
.m:     staa e_maxd
        ldaa #1
        staa e_dcur
.it:    clr  e_iter1
        ldaa e_dcur
        cmpa #1
        bne  .r
        inc  e_iter1
.r:     jsr  e_root
        tst  e_abort
        beq  .done
        tst  e_fdone
        beq  .fin
        bsr  e_res
.fin:   rts
.done:  bsr  e_res
        ldaa e_dcur
        staa e_depth
        cmpa e_emp0
        bhs  .ex
        ldd  e_score
        subd #2000
        bge  .ex
        ldd  e_score
        subd #-2000
        ble  .ex
        ldaa e_dcur
        inca
        staa e_dcur
        cmpa e_maxd
        bls  .it
        rts
.ex:    ldaa #1
        staa e_exact
        rts

; frame 0's best move and score are the result
e_res:  ldx  #E_FR
        ldaa F_BMV,x
        staa e_move
        ldd  F_BEST,x
        std  e_score
        rts

; a fresh count, no killers, the flip stack empty
e_fresh:clra
        clrb
        std  e_nodes
        staa e_nodes+2
        staa e_abort
        ldd  #E_FS
        std  e_fsp
        ldx  #E_KIL
        ldaa #NONE
.k:     staa 0,x
        inx
        cpx  #E_KIL+MAXD+1
        bne  .k
        rts

; e_count: one more position; the limit; the poll every 64
e_count:inc  e_nodes+2
        bne  .c
        inc  e_nodes+1
        bne  .c
        inc  e_nodes
.c:     tst  e_iter1
        bne  .p
        ldaa e_lim
        oraa e_lim+1
        oraa e_lim+2
        beq  .p
        ldd  e_nodes+1
        subd e_lim+1
        ldaa e_nodes
        sbca e_lim
        bcs  .p
        ldaa #1
        staa e_abort
.p:     ldaa e_nodes+2
        anda #63
        bne  .r
        ldx  e_poll
        beq  .r
        ldx  #$41               ; the zero-page variables, kept over the call
.sv:    ldaa 0,x
        psha
        inx
        cpx  #$4D
        bne  .sv
        ldx  e_poll
        jsr  0,x
        tpa
        staa e_pc
        ldx  #$4C
.rs:    pula
        staa 0,x
        dex
        cpx  #$40
        bne  .rs
        ldaa e_pc
        tap
        bcc  .r
        tst  e_iter1
        bne  .r
        ldaa #2
        staa e_abort
.r:     rts

; e_rnd: A = a random byte (24-bit Galois shift register, 8 steps)
e_rnd:  ldab #8
.l:     lsr  e_seed
        ror  e_seed+1
        ror  e_seed+2
        bcc  .n
        ldaa e_seed
        eora #$E1
        staa e_seed
.n:     decb
        bne  .l
        ldaa e_seed+2
        rts

; ---------------------------------------------------------------------
; e_root: one search from the root (frame 0) at e_dcur, or the exact
; ending. Returns with frame 0 holding the best move and score.
; ---------------------------------------------------------------------
e_root: ldx  #E_FR
        stx  e_fp
        clr  e_ply
        clr  e_fdone
        clr  e_rties
        ldd  #E_TT
        std  e_tx               ; levels 1-2: the end of the root's list
        ldd  #-INF
        std  F_A,x
        ldd  #INF
        std  F_B,x
        tst  e_exm
        beq  s_enter
        ldd  #-64
        std  F_A,x
        ldd  #64
        std  F_B,x
        ; (on into the machine)

; ---------------------------------------------------------------------
; The machine. s_enter: a new node at e_fp / e_ply, its window set.
; ---------------------------------------------------------------------
s_enter:ldx  e_fp
        clr  F_FL,x
        tst  e_abort
        beq  .go
        jmp  s_ret0
.go:    jsr  e_empt
        tst  e_ply
        bne  .np
        stab e_emp0
        jmp  s_setup            ; (the root always searches)
.np:    tst  e_exm
        beq  .norm
        tstb
        bne  .e1
        jsr  e_marg
        jmp  s_ret
.e1:    cmpb #1
        bne  s_setup
        jsr  e_last
        jmp  s_ret
.norm:  ldaa e_dcur
        suba e_ply
        bne  s_setup
        tstb
        bne  .ev
        jsr  e_final
        jmp  s_ret
.ev:    jsr  e_eval
        jmp  s_ret

; s_setup: X = the frame (again after a pass)
s_setup:ldaa #NONE
        staa F_TT,x
        staa F_KL,x
        tst  e_ply
        bne  .nr
        tst  e_exm              ; the root: the last depth's best first
        bne  .lst
        ldaa e_move
        staa F_TT,x
        bra  .mob
.nr:    tst  e_exm
        bne  .nk
        ldab e_ply              ; this ply's killer
        ldx  #E_KIL
        abx
        ldaa 0,x
        ldx  e_fp
        staa F_KL,x
.nk:    tim  #FL_PASS,F_FL,x
        bne  .mob
        jsr  e_empt             ; the table where 3 or more remain
        tst  e_exm
        bne  .te
        ldaa e_dcur
        suba e_ply
        tab
.te:    cmpb #3
        blo  .mob
        jsr  e_probe
        bcc  .mob
        jmp  s_ret              ; (the exact ending: a stored result)
.mob:   ldx  e_fp
        tst  e_exm
        bne  .ex
        ldaa e_dcur
        suba e_ply
        cmpa #1
        bne  .init
        ldaa e_side
        jsr  e_cmob
        ldx  e_fp
        stab F_MOB,x
        bra  .init
.ex:    tst  e_ply              ; the exact ending: the root always sorts,
        beq  .lst               ; other nodes from 5 empty squares
        jsr  e_empt
        cmpb #5
        blo  .init
.lst:   jsr  e_sort
        tst  e_abort
        beq  .init
        jmp  s_ret0
.init:  ldx  e_fp
        clr  F_I,x
        ldd  #-INF
        std  F_BEST,x
        ldaa #NONE
        staa F_BMV,x
        aim  #$FF-FL_ANY,F_FL,x

s_loop: ldx  e_fp
        jsr  e_next
        tstb
        bne  .c
        jmp  s_none
.c:     stab e_mvt
        ldx  #e_bd
        abx
        tst  0,x
        bne  s_loop
        ldab e_mvt
        jsr  e_make
        tstb
        beq  s_loop
        ldx  e_fp               ; (only a legal move: the score and the flip
        ldd  e_sqo              ; stack as they were before it)
        std  F_SQS,x
        ldd  e_fs0
        std  F_FSP,x
        ldaa e_mvt
        staa F_MV,x
        oim  #FL_ANY,F_FL,x
        jsr  e_count
        ldx  e_fp
        ldaa F_MOB,x
        staa e_pmob
        ldd  F_B,x
        jsr  e_negd
        std  FSIZE+F_A,x
        ldd  F_A,x
        jsr  e_negd
        std  FSIZE+F_B,x
        ldab #FSIZE
        abx
        stx  e_fp
        inc  e_ply
        jmp  s_enter

; s_ret: D = the node's score for its side to move. Back to the parent.
s_ret0: clra
        clrb
s_ret:  ldx  e_fp
        std  e_v
        tim  #FL_LIST,F_FL,x    ; its sorted list off the stack
        beq  .nl
        ldd  F_LP,x
        std  e_fsp
.nl:    tim  #FL_PASS,F_FL,x    ; a pass in this frame: the side put back
        beq  .np                ; (also when the search stops inside it)
        jsr  e_pass
.np:    ldd  e_v
        tst  e_ply
        bne  .up
        rts
.up:    std  e_v
        dec  e_ply
        xgdx
        subd #FSIZE
        xgdx
        stx  e_fp
        ldd  F_FSP,x
        std  e_fs0
        ldd  F_SQS,x
        std  e_sqs
        ldab F_MV,x
        jsr  e_undo
        tst  e_abort
        bne  s_ret0
        ldd  e_v
        jsr  e_negd
        tst  e_ply
        bne  s_val
        jmp  r_val

; s_val: D = the score of this frame's move F_MV
s_val:  std  e_v
        ldx  e_fp
        subd F_BEST,x
        ble  .nb
        ldd  e_v
        std  F_BEST,x
        ldaa F_MV,x
        staa F_BMV,x
.nb:    ldd  e_v
        subd F_A,x
        ble  .na
        ldd  e_v
        std  F_A,x
.na:    ldd  F_A,x
        subd F_B,x
        bge  .cut
        jmp  s_loop
.cut:   tst  e_exm
        bne  s_done
        ldaa F_MV,x             ; the killer for this ply
        ldab e_ply
        ldx  #E_KIL
        abx
        staa 0,x

; s_done: every move tried, or a cut-off
s_done: ldx  e_fp
        ldd  F_BEST,x
        tim  #FL_PASS,F_FL,x
        bne  s_unp
        tst  e_ply
        beq  .r
        jsr  e_store
        ldx  e_fp
        ldd  F_BEST,x
.r:     jmp  s_ret

; s_none: no candidate left
s_none: ldx  e_fp
        tim  #FL_ANY,F_FL,x
        bne  s_done
        tim  #FL_PASS,F_FL,x
        bne  .over
        oim  #FL_PASS,F_FL,x    ; a pass: the other side, the window turned round
        tim  #FL_LIST,F_FL,x
        beq  .p
        ldd  F_LP,x
        std  e_fsp
        aim  #$FF-FL_LIST,F_FL,x
.p:     jsr  e_pass
        ldx  e_fp
        ldd  F_A,x
        std  e_v
        ldd  F_B,x
        jsr  e_negd
        std  F_A,x
        ldd  e_v
        jsr  e_negd
        std  F_B,x
        jmp  s_setup
.over:  tst  e_exm              ; neither can move: the game is over
        beq  .f
        jsr  e_marg
        bra  s_unp
.f:     jsr  e_final
; back from a passed frame: the score turned round (s_ret puts the side back)
s_unp:  jsr  e_negd
        jmp  s_ret

; r_val: D = the score of a root move (not stopped)
r_val:  std  e_v
        ldx  e_fp
        ldaa #1
        staa e_fdone
        tst  e_fixm
        beq  .nf
        ldaa F_MV,x             ; levels 1-2: kept in the list
        ldx  e_tx
        staa 0,x
        ldd  e_v
        std  1,x
        inx
        inx
        inx
        stx  e_tx
        ldx  e_fp
        ldd  e_v
        subd F_BEST,x
        ble  .fx
        ldd  e_v
        std  F_BEST,x
.fx:    jmp  s_loop
.nf:    ldd  e_v
        subd F_BEST,x
        blt  .wa
        bgt  .nw
        inc  e_rties            ; a tie: replaces the best with chance 1/ties
        jsr  e_rnd
        ldab e_rties
        mul
        tsta
        bne  .wa
        bra  .tk
.nw:    ldaa #1
        staa e_rties
        ldd  e_v
        std  F_BEST,x
.tk:    ldx  e_fp
        ldaa F_MV,x
        staa F_BMV,x
.wa:    ldx  e_fp
        ldd  F_BEST,x
        subd #1
        std  F_A,x
        jmp  s_loop

; e_next: X = the frame (e_fp). B = the next candidate square (0: none left).
e_next: ldab F_I,x
        inc  F_I,x
        tstb
        bne  .s1
        ldab F_TT,x
        cmpb #NONE
        beq  e_next
        rts
.s1:    cmpb #1
        bne  .s2
        ldab F_KL,x
        cmpb #NONE
        beq  e_next
        cmpb F_TT,x
        beq  e_next
        rts
.s2:    subb #2
        tim  #FL_LIST,F_FL,x
        beq  .ord
        ldx  F_LP,x
        abx
        ldab 0,x
        ldx  e_fp
        cmpb #NONE
        beq  .none
        cmpb F_TT,x
        beq  e_next
        rts
.ord:   cmpb #48
        bhs  .none
        ldx  #e_order
        abx
.o:     ldab 0,x                ; the next square in the order
        stx  e_onp
        ldx  #e_bd
        abx
        tst  0,x
        beq  .e
        ldx  e_fp               ; taken: on past it here (not back to s_loop)
        inc  F_I,x
        ldx  e_onp
        inx
        cpx  #e_order+48
        bne  .o
        bra  .none
.e:     ldx  e_fp               ; empty: a candidate
        cmpb F_TT,x
        beq  e_next
        cmpb F_KL,x
        beq  e_next
        rts
.none:  clrb
        rts

; e_probe: the table entry for this position (e_hash first). Sets F_TT.
; The exact ending only: C set and D = the score if the entry settles it.
e_probe:tst  e_fixm             ; (not at a fixed depth: e_tx is the root's list
        bne  .miss              ; then; levels 1-2 never get here)
        jsr  e_hash
        jsr  e_ttx
        stx  e_tx
        ldaa 0,x
        cmpa e_h+1
        bne  .miss
        ldaa 1,x
        cmpa e_h+2
        bne  .miss
        ldab 2,x
        andb #63
        jsr  e_idxof
        ldx  e_fp
        stab F_TT,x
        tst  e_exm
        beq  .miss
        ldx  e_tx
        ldab 3,x                ; the score
        jsr  e_sxb
        std  e_tsc
        ldaa 2,x
        rola
        rola
        rola
        anda #3                 ; the kind: 1 upper, 2 lower, 3 exact
        beq  .miss
        ldx  e_fp
        cmpa #3
        beq  .cut
        cmpa #2
        bne  .up
        ldd  e_tsc              ; lower bound: cut if score >= beta
        subd F_B,x
        bge  .cut
        bra  .miss
.up:    ldd  e_tsc              ; upper bound: cut if score <= alpha
        subd F_A,x
        bgt  .miss
.cut:   ldd  e_tsc
        sec
        rts
.miss:  clc
        rts

; e_store: the frame's result into the table (not the root, not after a
; pass). The ordinary search keeps the move; the exact ending also the
; kind and score.
e_store:tst  e_fixm             ; (not at a fixed depth: the root's list is in
        bne  .r                 ; the table's space; levels 1-2 never get here)
        jsr  e_empt
        tst  e_exm
        bne  .te
        ldaa e_dcur
        suba e_ply
        tab
.te:    cmpb #3
        blo  .r
        jsr  e_hash
        jsr  e_ttx
        stx  e_tx
        ldaa e_h+1
        staa 0,x
        ldaa e_h+2
        staa 1,x
        ldx  e_fp
        ldab F_BMV,x
        jsr  e_sqof
        stab e_mvt
        tst  e_exm
        beq  .nk
        ldd  F_BEST,x           ; the kind: against the window it was given:
        std  e_tsc              ; alpha was minus the parent's beta
        ldx  e_fp
        xgdx
        subd #FSIZE
        xgdx
        ldd  F_B,x
        addd e_tsc              ; best <= -beta(parent): upper bound
        bgt  .k2
        ldab #1*64
        bra  .k
.k2:    ldx  e_fp
        ldd  e_tsc
        subd F_B,x
        blt  .k3
        ldab #2*64              ; best >= beta: lower bound
        bra  .k
.k3:    ldab #3*64
.k:     orab e_mvt
        stab e_mvt
        ldx  e_tx
        ldaa e_tsc+1
        staa 3,x
.nk:    ldx  e_tx
        ldab e_mvt
        stab 2,x
.r:     rts

; e_sort: the side to move's moves, fewest replies first (equal counts
; keep the order table's order), built on the flip stack (each trial move's
; flips go just past the list so far), NONE after the last. Each trial move
; counts a position.
e_sort: clr  e_scnt
        clr  e_si
        ldx  e_fp
        ldd  e_fsp
        std  F_LP,x
        oim  #FL_LIST,F_FL,x
.l:     ldab e_si
        cmpb #48
        beq  .done
        inc  e_si
        ldx  #e_order
        abx
        ldab 0,x
        stab e_ss
        ldx  #e_bd
        abx
        tst  0,x
        bne  .l
        ldd  e_sqs
        std  e_ssq
        bsr  .end               ; the flips past the list
        stx  e_fsp
        stx  e_sfs
        ldab e_ss
        jsr  e_make
        tstb
        beq  .l
        jsr  e_count
        ldaa e_side
        jsr  e_cmob
        stab e_sr
        ldd  e_sfs
        std  e_fs0
        ldab e_ss
        jsr  e_undo
        ldd  e_ssq
        std  e_sqs
        ldab e_scnt             ; insert after every count not greater
.in:    tstb
        beq  .put
        ldx  #e_skey-1
        abx
        ldaa 0,x
        cmpa e_sr
        bls  .put
        staa 1,x                ; (its key and its move up one)
        pshb
        decb
        bsr  .lp
        ldaa 0,x
        staa 1,x
        pulb
        decb
        bra  .in
.put:   ldx  #e_skey
        abx
        ldaa e_sr
        staa 0,x
        bsr  .lp
        ldaa e_ss
        staa 0,x
        inc  e_scnt
        bra  .l
.done:  bsr  .end
        ldaa #NONE
        staa 0,x
        inx
        stx  e_fsp
        rts
; X = the list's end (its start + e_scnt)
.end:   ldab e_scnt
; X = the list's entry B
.lp:    ldx  e_fp
        ldx  F_LP,x
        abx
        rts

; e_last: one empty square left: D = the margin, the flips only counted
e_last: ldx  #e_order
.f:     ldab 0,x
        inx
        pshx
        ldx  #e_bd
        abx
        tst  0,x
        pulx
        bne  .f
        stab e_ss
        ldaa e_side
        jsr  e_flips
        tstb
        beq  .o
        stab e_sr
        jsr  e_count
        jsr  e_marg             ; own - opp + 2n + 1
        addb e_sr
        adca #0
        addb e_sr
        adca #0
        addd #1
        rts
.o:     ldaa e_side
        eora #3
        ldab e_ss
        jsr  e_flips
        tstb
        beq  .z
        stab e_sr
        jsr  e_count
        jsr  e_marg             ; own - opp - 2n - 1
        subb e_sr
        sbca #0
        subb e_sr
        sbca #0
        subd #1
        rts
.z:     jmp  e_marg
