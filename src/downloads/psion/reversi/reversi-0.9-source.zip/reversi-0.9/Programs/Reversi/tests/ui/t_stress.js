// Stress test: random keys on every ROM, checking the game never breaks (from Connect 4's).
//   node tests/ui/t_stress.js [all | rom ...] [emulated minutes per ROM, default 10] [sN seed]
// Random presses (weighted to the game's keys, with bursts, long holds, SHIFT, and idle spells
// long enough for the Organiser to switch itself off: its idle time is set to 20 s). Checks:
//  - every time the game waits for a key: the kernel and engine code are unchanged;
//  - on the play screen: the board is the move record replayed (from the set-up position if
//    there is one, passes found on the way), g_n <= 44, the game not over, the stack where it
//    was the last time;
//  - on the result screen: neither side can move in the position;
//  - the game keeps reaching a key wait (no hang) and no OS error appears; when it is left
//    (Quit) it is started again and must resume the same record.
'use strict';
const fs = require('fs'), path = require('path');
const { Game, ROMS, ROOT } = require('./lib');
const R = require('../../ref/rules.js');

const args = process.argv.slice(2);
const roms = !args[0] || args[0] === 'all' ? Object.keys(ROMS) : args.filter(a => /\.rom$/.test(a));
const minutes = +(args.find(a => /^\d+(\.\d+)?$/.test(a)) || 10);
const seed0 = +(args.find(a => /^s\d+$/.test(a)) || 's1').slice(1);
let seed = seed0;
const rand = n => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return (seed >> 8) % n; };
const ids = Object.fromEntries(fs.readFileSync(path.join(ROOT, 'build', 'game', 'gen', 'ids.inc'), 'utf8')
  .split('\n').map(l => l.match(/^(\w+) = (\d+)/)).filter(Boolean).map(m => [m[1], +m[2]]));
const KEYS = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'U', 'V', 'W', 'O', 'P', 'Q', 'LEFT', 'RIGHT', 'UP', 'DOWN', 'EXE', 'DEL', 'MODE', 'SPACE', 'ON', 'S', 'T', 'L'];
const WEIGHT = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 4, 4, 3, 3, 8, 2, 2, 1, 3, 1, 1, 1];
const LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
const pick = () => {
  if (rand(12) === 0) return LETTERS[rand(26)];
  let t = rand(WEIGHT.reduce((a, b) => a + b, 0));
  for (let i = 0; i < KEYS.length; i++) { t -= WEIGHT[i]; if (t < 0) return KEYS[i]; }
  return 'EXE';
};
// the position from the game's record: the start (or the set-up position), the moves, passes
function replay(g) {
  const b = R.newBoard();
  let side = 1;
  if (g.peek('g_setup')) {
    const st = g.bytes('g_start', 12);
    for (let sq = 0; sq < 48; sq++) { const v = (st[sq >> 2] >> (2 * (3 - (sq & 3)))) & 3; b[R.idxOf(sq)] = v === 3 ? 0 : v; }
    side = g.peek('g_sside');
  }
  for (const sq of g.rec()) {
    if (!R.legalMoves(b, side).length) side = 3 - side;
    const s = R.idxOf(sq);
    if (!R.flipsFor(b, s, side).length) return null;
    R.play(b, s, side);
    side = 3 - side;
  }
  return { b, side };
}
const regs = m => { const a = []; m.cpu.getSnapshotData(a); return { pc: a[5] << 8 | a[6], sp: a[7] << 8 | a[8], sleep: a[9] }; };

let failures = 0;
for (const rom of roms) {
  seed = seed0 * 1000003 + [...rom].reduce((h, c) => (h * 31 + c.charCodeAt(0)) & 0xffffff, 7);
  const t0 = Date.now();
  let g = null, kimg = null, kwAddr = 0, sp0 = {}, lastRec = null, asize = 0;
  let left = false, counter = null, quitRec = null;
  const hist = [];
  const press = (k, h, gp) => { if (!left) { hist.push(k); g.m.press(k, h, gp); } };
  const st = { keys: 0, waits: 0, plays: 0, results: 0, leaves: 0, units: new Set() };
  const fail = (msg) => { throw new Error(`${rom}: ${msg}\n${g ? g.text() : ''}`); };
  const start = (fresh) => {
    if (fresh) g = new Game(rom);
    g.start();
    if (g.base < 0) fail('no kernel after starting');
    g.m.poke(0x20CD, 0); g.m.poke(0x20CE, 20);                 // switch off after 20 s idle
    const s = g.sym, vend = g.base + s.kv_first[0];
    g.sync();                                           // (the LZ64: not while another bank is in)
    kimg = g.m.read(g.base, vend - g.base);
    kwAddr = g.base + s.key_wait[0];
    asize = g.peekw('kv_size');
    const qAddr = g.base + s.quit[0];
    left = false; counter = null;
    g.m.dbg.setTrace((pc) => {
      if (pc === qAddr && !left) { left = true; quitRec = g.rec().join(','); }
      if (counter) counter(pc);
    });
    sp0 = {};
  };
  try {
    start(true);
    g.poke('st_level', 1 + rand(4));                       // (quick levels: more games)
    let quietS = 0, emuS = 0;
    while (emuS < minutes * 60) {
      const r = rand(100);
      let spent = 0;
      const play = Math.floor(emuS / 90) % 2 === 1;     // every other 90 s: mostly EXE, so games end
      if (play && r < 85) { press(r < 80 ? 'EXE' : pick(), 3, 4 + rand(10)); st.keys++; spent = 0.6; }
      else if (r < 70) { const k = pick(); const h = 2 + rand(5), gp = rand(20); press(k, h, gp); st.keys++; spent = (h + gp) * 0.05; }
      else if (r < 80) { const n = 5 + rand(10); for (let i = 0; i < n; i++) { press(pick(), 2, rand(3)); st.keys++; } spent = n * 0.2; }
      else if (r < 85) { const k = ['LEFT', 'RIGHT', 'DEL', 'U', 'EXE', 'UP', 'DOWN'][rand(7)], h = 20 + rand(40); press(k, h, 5); st.keys++; spent = h * 0.05; }
      else if (r < 90) { const s = 1 + rand(30); g.m.runSeconds(s); spent = s; }
      else if (r < 95) { g.m.keyDown('SHIFT'); g.m.runTicks(1); press(pick(), 3, 1); g.m.keyUp('SHIFT'); g.m.runTicks(3); st.keys++; spent = 0.4; }
      else { press('ON', 3, 10); press(pick(), 3, 10); st.keys += 2; spent = 1; }
      emuS += spent;
      const hit = g.m.runTo([kwAddr], 921600);
      let alive = hit === kwAddr && !left;
      if (!alive && !left) {
        let inArr = 0;
        counter = (pc) => { if (pc >= g.base && pc < g.base + asize) inArr++; };
        for (let tries = 0; tries < 2 && !inArr; tries++) {
          if (!g.text().trim() || regs(g.m).sleep) { g.m.press('ON', 3, 10); st.keys++; }
          for (let i = 0; i < 6 && !inArr; i++) g.m.runSeconds(0.5);
        }
        counter = null;
        alive = inArr > 0;
      }
      if (!alive) {
        const t = g.text();
        if (/REV ERROR|NEEDS/.test(t)) fail('stopped: ' + t);
        st.leaves++;                                       // left to the OS (Quit)
        if (process.env.STRESS_DEBUG) console.log('left: quit seen', left, 'screen', JSON.stringify(t), 'keys', hist.slice(-15).join(' '));
        g.m.poke(0x20CD, 1); g.m.poke(0x20CE, 44);         // (5 minutes while it is started again)
        for (let i = 0; i < 4; i++) { g.m.press('ON', 3, 10); g.m.runSeconds(0.3); }
        start(false);
        for (let i = 0; i < 30; i++) {
          if (g.m.runTo([kwAddr], 921600) === kwAddr && ![0, ids.OV_GAME].includes(g.peek('kv_res'))) break;
          g.m.cpu.execute(1);
        }
        const was = quitRec !== null ? quitRec : lastRec;
        if (was !== null) {
          const rec = g.rec().join(',');
          if (!rec.startsWith(was) || (rec !== was && g.peek('g_psion') === 0)) fail(`resumed record ${rec}, was ${was} when it left`);
        }
        quitRec = null;
        continue;
      }
      if (/ERROR|MISSING|BATTERY|STACK|OUT OF/i.test(g.text())) fail('an error message');
      if (hit !== kwAddr) {
        quietS += 1 + spent;
        if (quietS > 600) fail(`no key wait for ${quietS.toFixed(0)} s: PC ${regs(g.m).pc.toString(16)} kv_res ${g.peek('kv_res')}`);
        continue;
      }
      quietS = 0;
      st.waits++;
      g.sync();
      const now = g.m.read(g.base, kimg.length);
      for (let i = 0; i < kimg.length; i++) if (now[i] !== kimg[i]) fail(`kernel byte ${i} (${i.toString(16)}) changed from ${kimg[i]} to ${now[i]}`);
      const res = g.peek('kv_res'), n = g.peek('g_n'), over = g.peek('g_over');
      st.units.add(res);
      if (n > 44) fail(`g_n ${n}`);
      lastRec = g.rec().join(',');
      if (res === ids.OV_PLAY) {
        st.plays++;
        if (over) fail('the play screen with the game over');
        const p = replay(g);
        if (!p) fail('the record does not replay: ' + lastRec);
        const bd = g.bytes('e_bd', 80);
        for (const s of R.SQUARES) {
          const v = bd[s] === 3 ? 0 : bd[s];          // (a hint square)
          if (v !== p.b[s]) fail(`square ${R.name(s)} is ${bd[s]}, the record gives ${p.b[s]}`);
        }
        const [ns, nh] = R.count(p.b);
        if (g.peek('e_ns') !== ns || g.peek('e_nh') !== nh) fail(`counts ${g.peek('e_ns')}/${g.peek('e_nh')}, the record gives ${ns}/${nh}`);
        const sp = regs(g.m).sp, ret = g.m.peekw(sp + 1);   // (by the call site: the return address)
        if (!(ret in sp0)) sp0[ret] = sp; else if (sp !== sp0[ret]) fail(`stack at ${sp.toString(16)}, was ${sp0[ret].toString(16)} (called from ${ret.toString(16)})`);
      } else if (res === ids.OV_RESULT) {
        st.results++;
        if (over !== 2) fail(`result screen with g_over ${over}`);
        const p = replay(g);
        if (!p) fail('the record does not replay: ' + lastRec);
        if (R.legalMoves(p.b, 1).length || R.legalMoves(p.b, 2).length) fail('a result with a move still to make');
      }
    }
    console.log(`${rom.padEnd(14)} ok   ${minutes} min, ${st.keys} keys, ${st.waits} key waits checked (${st.plays} on the play screen, ${st.results} on a result), ${st.leaves} leaves, overlays seen ${[...st.units].sort((a, b) => a - b).join(',')}, ${((Date.now() - t0) / 1000).toFixed(0)} s`);
  } catch (e) {
    failures++;
    console.log(`${rom.padEnd(14)} FAIL ${e.message.split('\n')[0].replace(rom + ': ', '')}\n${e.message.split('\n').slice(1).join('\n')}`);
  }
}
console.log(failures ? `${failures} ROMs FAILED` : `all ${roms.length} ROMs passed`);
process.exit(failures ? 1 : 0);
