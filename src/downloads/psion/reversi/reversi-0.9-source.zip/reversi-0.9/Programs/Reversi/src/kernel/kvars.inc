; ---------------------------------------------------------------------
; Kernel variables: cleared at the start (kinit), not stored on the pack.
; Most live outside the array, in the launchers' translated code that never
; runs again once the game has started (tools/build.py finds it in their
; object code, and tests/ui/t_hidden.js checks it on every ROM):
; KH: REVG's code before its USR call (which includes the bootstrap string),
;     below the array: the working variables and the save record;
; KR: REV's code before its call of REVG, above the array: the engine's
;     variables but the board.
; REV's two bytes after that call and REVG's code after USR stay intact:
; they run when the game ends. Only the board is in the array: the start-up
; code is stored there on the pack and copied to slot A at the start.
; ---------------------------------------------------------------------
kh_first = KH
kv_vptr   = KH+0                ; (2) ADDR(v%())
kv_sp     = KH+2                ; (2) the stack at entry
kv_base   = KH+4                ; (2) the array's address
kv_size   = KH+6                ; (2)
kv_dev    = KH+8                ; (1) 0 A:, 1 B:, 2 C:
kv_pkok   = KH+9                ; (1) the game's device is selected (0 at the start)
kv_pa     = KH+10               ; (3) pack address
kv_dir    = KH+13               ; (6) where blocks 0 (overlays) and 1 (the book) start
kv_t0     = KH+19               ; (2)
kv_t1     = KH+21               ; (2)
kv_t2     = KH+23               ; (2)
kv_t3     = KH+25               ; (2)
kv_fo     = KH+27               ; (2)
kv_res    = KH+29               ; (1) the overlay in slot A (0 none)
kv_drv    = KH+30               ; (1) the screen driver's unit (DRV2 or DRV4)
kv_rx     = KH+31               ; (2)
kv_rtgt   = KH+33               ; (2)
kv_four   = KH+35               ; (1) 1: four-line display (mode changed)
kv_omode  = KH+36               ; (1) the display mode we found
kv_left   = KH+37               ; (1)
kv_aidle  = KH+38               ; (2)
kv_afr    = KH+40               ; (1)
kv_ppos   = KH+41               ; (4) the panel lines' screen positions
kv_lb     = KH+45               ; (11) a line being built
kv_lp     = KH+56               ; (1)
kv_nbl    = KH+57               ; (1) (length of kv_nb)
kv_nb     = KH+58               ; (6) number digits
kv_arg    = KH+64               ; (1)
kv_ovs    = KH+65               ; (1) a square the driver shows as kv_ovv (0 none)
kv_ovv    = KH+66               ; (1)
kv_cur    = KH+67               ; (1) the cursor (OV_PLAY), kept for the tip
kv_lmv    = KH+68               ; (1) the last move (0 none, $FF a pass)
kv_lfl    = KH+69               ; (1) and the discs it flipped
kv_lwho   = KH+70               ; (1) and who made it (1, 2)
kv_tip    = KH+71               ; (1) the tip's square for OV_PLAY (0 none)
kv_plines = KH+72               ; (1) panel lines: 2 or 4
kv_hon    = KH+73               ; (1) standing hints shown (your turn, Hints on)
kv_hph    = KH+74               ; (1) four lines: their slow flash (0 empty, 1 the disc)

; the save record (OV_GAME): its length, a tag and version, the bytes
; (settings, then the game), a checksum
sv_rec    = KH+75
sv_tag    = KH+76               ; (2)
sv_first  = KH+78
st_level  = KH+78               ; 1-8
st_players = KH+79              ; 0 one, 1 two, 2 demo
st_you    = KH+80               ; 0 Solid, 1 Hollow, 2 turn about
st_confirm = KH+81              ; 0 on, 1 off
st_book   = KH+82               ; 0 on, 1 off
st_sound  = KH+83               ; 0 on, 1 off
st_final  = KH+84               ; 0 discs, 1 winner takes the empty squares
st_hcap   = KH+85               ; corner handicap: 0-4 corners for the weaker side
st_hints  = KH+86               ; standing hints: 0 off, 1 on
st_coach  = KH+87               ; the coach: 0 off, 1 on
st_auto   = KH+88               ; auto level: 0 off, 1 on (a win: up one, a loss: down one)
st_dlev   = KH+89               ; a demo: Hollow's level (0: Level, as Solid's)
st_last   = KH+90
g_psion   = KH+90               ; the side(s) the Psion plays: 0 none, 1, 2, 3 both
g_you     = KH+91               ; turn about: the side you had last (1, 2)
g_over    = KH+92               ; 0 playing, 1 over, 2 over and in the tally
g_setup   = KH+93               ; the game starts from g_start: 1 set up, 2 a handicap
g_sside   = KH+94               ; and the side to move there
g_start   = KH+95               ; (12) set-up position: 2 bits a square, a1 first
g_n       = KH+107              ; moves made
g_rec     = KH+108              ; (44) the moves: squares 0-47 (a pass is not stored)
g_seed    = KH+152              ; (3) the random seed as saved
g_names   = KH+155              ; (16) the players' names: length (0 none) and 7 letters
                                ; each: player 1 (you; two players Solid), player 2
sv_end    = KH+171
sv_chk    = KH+171
kh_end    = KH+172

; the engine's variables but the board (src/engine/evars.inc), then bytes
; kept while an overlay gives slot A up and is read in again (ov_resume)
EV        = KR
kr_first  = KR
kv_cont   = KR+EV_LEN           ; (2) the overlay and entry to go on with
co_you    = KR+EV_LEN+2         ; the coach: your move (board index)
co_best   = KR+EV_LEN+3         ; the move its search preferred
co_sb     = KR+EV_LEN+4         ; (2) and that move's score
co_sg     = KR+EV_LEN+6         ; 1: the second search is yours (the Psion passes)
kr_end    = KR+EV_LEN+7

; in the array: the board
kv_first:
EV_BD:  rmb  80
kv_end:
        include "../engine/evars.inc"
