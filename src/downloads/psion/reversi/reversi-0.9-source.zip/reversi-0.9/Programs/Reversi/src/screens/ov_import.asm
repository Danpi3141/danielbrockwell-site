; =====================================================================
; OV_IMPORT (stretch goal 8, import): a game from a file A:RVGAMEn (from
; OV_EXPORT, or sent from a PC through the Comms Link). The files there in
; turn: "RVGAME3" and "EXE: load"; UP/DOWN the previous or next, EXE loads
; it, ON/CLEAR goes back. The record is read as OV_EXPORT writes it, and
; read leniently: a set-up position first if its first 48 characters are
; all '-', '.', 'X' or 'O' (then a space and X or O, who moves first);
; then every square in it ("d2", "D2": a letter a-h and a row 1-6) is a
; move, whatever is between them ("d2c4", "1. d2 c4", one a line...). It
; becomes the record and OV_GAME replays it (G_IMP: passes found, every
; move checked): a good game is kept and saved; a bad one comes back here
; (I_BAD): "Bad game", and the game as it was is loaded again (G_LOAD: it
; was saved after its last move). The name and the record are in the screen
; driver's area, which is read in again afterwards.
; =====================================================================
        include "../defs.inc"

FN      = DRV                   ; a file name, with its length
RD      = DRV+16                ; the record, with its length

        jmp  im_start
        jmp  im_bad

im_start:
        clr  im_k               ; the first file there
        ldab #1
        bsr  im_step
        bcc  .show
        jsr  pn_msg
        fcl  "No games"
        clra
        jsr  key_wait
        bra  im_out
.show:  jsr  lb_clr             ; "RVGAME3", then "EXE: load"
        ldab FN
        subb #2
        stab FN+2
        ldx  #FN+2
        jsr  lb_fcl
        ldaa kv_plines
        suba #2
        jsr  lb_put
        jsr  pn_msg
        fcl  "EXE: load"
.k:     clra
        jsr  key_wait
        cmpb #K_ON
        beq  im_out
        cmpb #K_EXE
        beq  im_load
        cmpb #K_UP
        beq  .up
        cmpb #K_DOWN
        bne  .k
        ldab #1
        bra  .st
.up:    ldab #-1
.st:    bsr  im_step
        bra  .show              ; (none further that way: the same one)

; the driver again (its area held the name and the record); no command
im_out: clr  kv_pkok
        ldaa kv_drv
        jsr  ov_load
        jsr  pn_clear
        clra
        rts

; B = 1 or -1: im_k moved to the next file there that way (1-99), its name
; in FN and its record in RD; C set (im_k as it was) if there is none
im_step:stab im_d
        ldaa im_k
        staa im_o
.n:     ldaa im_k
        adda im_d
        staa im_k
        beq  .no
        cmpa #100
        beq  .no
        bsr  im_read
        bcs  .n
        rts
.no:    ldaa im_o               ; none: the one before, read again
        staa im_k
        beq  .x
        bsr  im_read
        sec
        rts
.x:     sec
        rts

; A:RVGAMEk (k = im_k) into RD; C set if it is not there
im_read:ldd  #8
        std  T0
        ldx  #im_fn
        ldd  #FN+1
        os   UT$CPYB
        ldx  #FN+9
        clra
        ldab im_k
        os   UT$UTOB
        addb #8
        stab FN
        clr  kv_pkok
        ldx  #FN
        os   FL$OPEN
        bcs  .x
        tab
        os   FL$RECT
        clra
        clrb
        os   FL$SETP
        ldd  #1
        os   FL$RSET
        bcs  .x
        ldx  #RD
        os   FL$READ
.x:     rts

; EXE: the record into the game, checked by replaying it
im_load:clr  g_setup
        clr  g_n
        clr  g_over
        ldx  #RD+1
        ldab RD
        abx
        stx  im_e               ; the record's end
        ldab RD
        cmpb #50
        blo  .mv
        ldx  #RD+1              ; a set-up position: 48 squares, a1 first?
.c:     ldaa 0,x
        bsr  im_sqv
        bcs  .mv                ; no: only moves
        inx
        cpx  #RD+49
        bne  .c
        ldx  #g_start           ; yes: 2 bits a square into g_start
.z:     clr  0,x
        inx
        cpx  #g_start+12
        bne  .z
        clr  im_i
.s:     ldab im_i
        ldx  #RD+1
        abx
        ldaa 0,x
        bsr  im_sqv             ; A = 0 empty, 1 Solid, 2 Hollow
        ldab im_i               ; into its two bits: A << (6 - 2 x its place)
        andb #3
        aslb
        negb
        addb #6
.sh:    tstb
        beq  .o
        asla
        decb
        bra  .sh
.o:     psha
        ldab im_i
        lsrb
        lsrb
        ldx  #g_start
        abx
        pula
        oraa 0,x
        staa 0,x
        inc  im_i
        ldaa im_i
        cmpa #48
        bne  .s
        ldaa RD+50              ; who moves first: X or O
        bsr  im_sqv
        bcs  .bad
        tsta
        beq  .bad
        staa g_sside
        inc  g_setup
        ldx  #RD+51
        bra  .mv2
.mv:    ldx  #RD+1              ; the moves: every square in the record
.mv2:   cpx  im_e
        bhs  .chk
        pshx                    ; (a square needs two characters)
        inx
        cpx  im_e
        pulx
        bhs  .chk
        ldaa 0,x
        oraa #$20               ; (a capital too)
        suba #'a'
        cmpa #8
        bhs  .nx
        ldab 1,x
        subb #'1'
        cmpb #6
        bhs  .nx
        aslb                    ; square = row*8 + column
        aslb
        aslb
        aba
        ldab g_n
        cmpb #44
        bhs  .bad
        pshx
        ldx  #g_rec
        abx
        staa 0,x
        pulx
        inc  g_n
        inx
.nx:    inx
        bra  .mv2
.chk:   ldab g_n                ; something there?
        bne  .r
        tst  g_setup
        beq  .bad
.r:     bsr  im_drv             ; replayed by OV_GAME: kept and saved if every
        ldd  #OV_GAME*256+G_IMP ; move is legal, or back here (I_BAD)
        jmp  ov_call
.bad:   bsr  im_drv
; I_BAD: "Bad game", then the game as it was saved
im_bad: jsr  pn_msg
        fcl  "Bad game"
        clra
        jsr  key_wait
        ldd  #OV_GAME*256+G_LOAD
        jmp  ov_call

im_drv: clr  kv_pkok
        ldaa kv_drv
        jmp  ov_load

; A = a character of a set-up position: A = 0 ('-' or '.'), 1 ('X'), 2
; ('O'); C set if it is none of them
im_sqv: oraa #$20
        cmpa #'x'
        beq  .s
        cmpa #'o'
        beq  .h
        cmpa #'-'               ; ('-' and '.' already have bit 5 set)
        beq  .e
        cmpa #'.'
        beq  .e
        sec
        rts
.s:     ldaa #1
        clc
        rts
.h:     ldaa #2
        clc
        rts
.e:     clra
        clc
        rts

im_fn:  fcc  "A:RVGAME"
im_k:   fcb  0
im_o:   fcb  0
im_d:   fcb  0
im_i:   fcb  0
im_e:   fdb  0

