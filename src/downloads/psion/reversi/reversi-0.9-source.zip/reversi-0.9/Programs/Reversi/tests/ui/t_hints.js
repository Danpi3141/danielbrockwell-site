// Standing hints: with Hints on the screen shows the legal squares (two lines: a dot; four
// lines: a slow flash); with it off it doesn't; no hints during the Psion's turn.
'use strict';
const { Game, assert } = require('./lib.js');
for (const model of (process.argv[2] || 'cm,lz64').split(',')) {
  const g = new Game(model);
  g.start();
  g.waitHuman();
  const pix = () => g.m.pixels().join('');
  const off = new Set(); for (let i = 0; i < 20; i++) { g.m.runSeconds(0.1); off.add(pix()); }
  g.poke('st_hints', 1);
  g.key('MODE', 0.5); g.key('ON', 1.0);       // the menu and back: the panel drawn again
  g.waitHuman();
  assert(g.peek('kv_hon') === 1, 'hints on at your turn');
  const on = new Set(); for (let i = 0; i < 40; i++) { g.m.runSeconds(0.1); on.add(pix()); }
  const extra = [...on].filter(p => !off.has(p)).length;
  assert(extra > 0, 'the hints change the screen');
  // two lines: the dot pattern in the glyphs (bottom-right dot of a cell)
  if (g.m.lines === 2) {
    const u = g.m.udgs().flat();
    assert(u.some(b => b === 0x08 || b === 0x01 || b === 0x09), 'a hint dot in the glyphs');
  }
  g.key('EXE', 0.3);                           // play: during the Psion's turn no hints
  g.waitFor(() => /\[/.test(g.prompt()), 10, 0.05);
  assert(g.peek('kv_hon') === 0, 'no hints while the Psion thinks');
  g.waitHuman();
  assert(g.peek('kv_hon') === 1, 'hints back at your turn');
  console.log(`[${model}] hints ok (${off.size} screens without, ${on.size} with)`);
}
