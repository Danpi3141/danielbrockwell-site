# Hardware test plan

Checks that only a real Organiser can answer: the spec's hardware milestone ("Loads from a real pack and plays a full game on the CM and the LZ64") and the emulator's blind spots.

## Getting the pack onto the machines

1. Burn `build/game/REV.opk` to a 16K (or 32K) Datapak with a pack writer. Or, on an LZ64 with a Comms Link, send the files in `psion/` to a Datapak with RPLOAD (`Tools/README.md`).
   A Datapak cannot be erased without ultraviolet light, so use a finished build.
2. Put the Datapak in slot B of the LZ64 and run **Prog → Run → B:REV**. Then move it to the CM and do the same.
   This answers whether a Datapak written on the LZ64 reads on the CM.

## On the CM (two-line screen)

| Check | How | Pass |
|---|---|---|
| Free RAM | Run REV on a CM with nothing on A: | The title appears (the emulator: 6,506 bytes free, REV needs 5,694 before its save files exist). If "NEEDS n BYTES" appears, note n and what is on A: |
| The eighth dot row | Play a disc on row 3 or row 6 | Those squares are 2 by 2 dots like the others (they use the glyphs' dot rows 7 and 8) |
| Solid and Hollow | Play a few moves | Solid (a 2 by 2 square) and Hollow (a diagonal pair) are easy to tell apart, and from an empty square |
| The gap between lines | Look at rows 3 and 4 (the two screen lines) | The squares look evenly spaced across the gap; note how it looks |
| Display timing | Play a quick game, use the menus, turn the hints on | No glyph is garbled (that would mean the display chip was still busy) |
| Cursor and ripple | Wait on your move; play a move that flips several discs | The cursor flashes about 3 times a second; the flipped discs turn ring by ring, then the new disc flashes twice |
| Standing hints | Settings → Hints On | A single dot on each legal square |
| Speed | Level 6, mid-game: time the thinking bar | About 18.5 s for its 3,000 positions (the emulator gives 160 positions a second) |
| Switch off | Leave it on your move for the Organiser's switch-off time | It switches off (after the cursor's 30 s of flashing); ON brings the board back, glyphs and all |
| Thinking display | Level 7 or 8: watch the line above the bar | "Depth n" rising and the best move so far; the bar's next block flashes about 2-3 times a second |
| Quit and resume | Menu → Quit, then run REV again; do it a few times, with games saved in between | The same position each time; back to the Prog menu cleanly, no OPL error. (Some variables live in the launchers' own code while the game runs, which the emulator shows to be safe on every ROM: a crash or garbage here would mean the real OPL lays its procedures out differently) |
| REV ERROR 3 | Run B:REVG by itself | "REV ERROR 3", then the menu after a key (REVG must be run by REV); and REV itself never shows it |

## On the LZ64 (four-line screen)

| Check | How | Pass |
|---|---|---|
| Four lines | Run REV | The board on lines 1-3, `ABCDEFGH` under it, the panel at the right; the title's discs fall into place |
| Discs | Play a few moves | Solid filled, Hollow a ring; each character shows the right pair of squares |
| Hints | Settings → Hints On | The legal squares flash slowly with the mover's disc |
| Leaving | Menu → Quit | The Organiser's own screen comes back normally, including its top line (in the emulator the OS redefines its glyphs) |
| The same pack | Use the Datapak written for the CM | It runs unchanged |
| Export to a PC | Menu → Export ("Saved", RVGAME1); then the Comms Link's Transmit (File) of A:RVGAME1 to a PC terminal or file | The game arrives as one line of squares, such as `d2c4e5f6`; a set-up game starts with its 48-character board |
| Import from a PC | Edit that line on the PC (or type a game, "1. d2 c4 ..."), Receive it on the Organiser as a file A:RVGAME2, then Menu → Import → RVGAME2 | The game is loaded and can be played on (a wrong move: "Bad game", and the game as it was) |
| Coach | Settings → Coach On; play a few moves at level 1 | After each of your moves "Coach c4 +3" or "Coach: good" for 2 s, within about 2-6 s |

## Worth noting either way

- How the thinking bar, the cursor flash and the ripple look on the real display (it is slow to change).
- Whether the two-line board is easy to read; whether the hint dots help or clutter.
