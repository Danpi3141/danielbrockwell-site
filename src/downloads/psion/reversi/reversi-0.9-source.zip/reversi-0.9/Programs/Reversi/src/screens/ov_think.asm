; =====================================================================
; OV_THINK: the search's poll (e_poll = its first byte), read in to the
; top of slot A above the search's working space by think_run, and the end
; of a level 1-2 search (e_pick, at THINKAT+2: E_PICK). Called
; every 64 positions with the engine's zero page saved.
; The thinking bar "[====     ]": a block for each tenth of the level's
; positions (e_limit; e_bstep from OV_BOOK), the next one flashing at
; every poll; above it "Depth 7  e5": the depth being searched and the
; best move of the last depth finished (in the exact ending the depth is
; the empty squares: it searches to the end).
; ON/CLEAR stops the search (the best move so far is played); in a demo
; any key stops it (and is left for the demo to see); other keys are
; ignored.
; C set: stop.
; =====================================================================
        include "../defs.inc"

        bra  ot_poll            ; (THINKAT: e_poll)
        include "../engine/epick.asm"   ; (THINKAT+2: E_PICK)

ot_poll:
        ldx  TMW_TCNT           ; no switching off while it thinks
        stx  TMW_TOUT
        os   KB$TEST
        tstb
        beq  .show
        ldaa g_psion            ; a demo: any key
        cmpa #3
        beq  .stop
        os   KB$GETK
        cmpb #K_ON
        bne  .show
.stop:  sec
        rts
.show:  ldd  e_limit            ; (no bar for levels 1-2 and the coach)
        beq  .x
.b:     ldaa ot_bk              ; a block for each e_bstep positions (OV_BOOK:
        cmpa #9                 ; a tenth of the level's), at most 9 (reached
        beq  .dr                ; before the count passes 16 bits)
        ldd  e_nodes+1
        subd ot_th
        subd e_bstep
        bcs  .dr
        inc  ot_bk
        ldd  ot_th
        addd e_bstep
        std  ot_th
        bra  .b
.dr:    jsr  lb_clr             ; "[====     ]", the next block flashing
        ldaa #'['
        jsr  lb_ch
        ldab ot_bk
.e:     beq  .f
        pshb
        ldaa #'='
        jsr  lb_ch
        pulb
        decb
        bra  .e
.f:     com  ot_ph
        beq  .g
        ldaa #'='
        jsr  lb_ch
.g:     ldaa #10
        jsr  lb_at
        ldaa #']'
        jsr  lb_ch
        jsr  pn_last
        jsr  lb_clr             ; the line above: "Depth 7  e5", the best move
        jsr  lb_s               ; of the last depth finished (in the exact
        fcl  "Depth "           ; ending the depth is the empty squares)
        ldab e_dcur
        tst  e_exm
        beq  .dp
        ldab e_emp0
.dp:    clra
        jsr  lb_num
        ldab e_move
        cmpb #NONE
        beq  .p
        ldaa #9
        jsr  lb_at
        ldab e_move
        jsr  lb_sq
.p:     ldaa kv_plines
        suba #2
        jsr  lb_put
.x:     clc
        rts

ot_th:  fdb  0                  ; (read in afresh for each search)
ot_bk:  fcb  0
ot_ph:  fcb  0
