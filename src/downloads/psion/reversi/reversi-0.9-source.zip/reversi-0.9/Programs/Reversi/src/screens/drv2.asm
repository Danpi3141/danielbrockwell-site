; =====================================================================
; Two-line screen driver (CM, XP, LA). Loaded at DRV.
; The whole board is the 8 glyphs, a block 4 characters wide and 2 high
; at the left of the screen: glyph g holds columns 2*(g&3)+1 and +2, rows
; 3*(g/4)+1 to +3. A square is 2x2 dots with a one-dot gap: Solid all
; four, Hollow the top-left and bottom-right, a hint the bottom-right.
; Column 5 is blank; the panel is 11 characters from column 6.
; =====================================================================
        include "../defs.inc"

        jmp  d2_init
        jmp  d2_board           ; (the glyphs again: the whole board)
        jmp  d2_sq
        jmp  d2_board
        rts                     ; (leaving: nothing to undo)

d2_init:
        ldaa #2
        staa kv_plines
        ldd  #$0515             ; the panel at column 6: positions 5, 21
        std  kv_ppos
        clra
        clrb
        os   DP$STAT            ; cursor off
        ldaa #12
        os   DP$EMIT
        bsr  d2_board
        ldx  #d2_top            ; the block: glyphs 0-3 over 4-7
        ldab #4
        os   DP$PRNT
        ldaa #16
        clrb
        os   DP$STAT
        ldx  #d2_top+4
        ldab #4
        os   DP$PRNT
        rts
d2_top: fcb  0,1,2,3,4,5,6,7

; the whole board: every glyph rebuilt and sent
d2_board:
        clra
.g:     psha
        bsr  d2_glyph
        pula
        inca
        cmpa #8
        bne  .g
        rts

lcd_cmd:ldaa LCD_CTRL
        bmi  lcd_cmd
        stab LCD_CTRL
        rts
lcd_dat:ldaa LCD_CTRL
        bmi  lcd_dat
        stab LCD_DATA
        rts

; A = square index: the glyph holding it, rebuilt and sent
d2_sq:  clrb                    ; B = the row, A = the column
.l:     suba #10
        bcs  .d
        incb
        bra  .l
.d:     adda #9                 ; column - 1
        lsra                    ; glyph = (column-1)/2 + 4*((row-1)/3)
        cmpb #4
        blo  d2_glyph
        adda #4
; A = glyph (0-7): its 8 dot rows built from its 6 squares and sent to the
; display chip (no copy is kept)
d2_glyph:
        staa d2_g
        ldx  #d2_buf
.z:     clr  0,x
        inx
        cpx  #d2_buf+8
        bne  .z
        clr  d2_i               ; squares 0-5: column (i & 1), row (i >> 1) of the glyph
.c:     ldaa d2_g               ; the square: 10*(3*(g/4) + i/2 + 1) + 2*(g&3) + (i&1) + 1
        anda #4
        beq  .t
        ldaa #3
.t:     ldab d2_i
        lsrb
        stab d2_r               ; the glyph's square row 0-2
        aba
        inca                    ; the board row
        ldab #10
        mul                     ; (B = row * 10)
        ldaa d2_g
        anda #3
        asla
        aba
        ldab d2_i
        andb #1
        stab d2_odd
        aba
        inca                    ; A = the square
        tab
        ldx  #e_bd
        abx
        ldaa 0,x                ; 0 empty, 1 Solid, 2 Hollow
        bne  .h
        tst  kv_hon             ; an empty square: a hint (a dot) where the side
        beq  .h                 ; to move can play
        jsr  d_hint
.h:     cmpb kv_ovs
        bne  .v
        ldaa kv_ovv             ; (the cursor, a flash)
.v:     tsta
        beq  .nx
        asla                    ; 2 * value + right-hand square
        adda d2_odd
        asla
        tab
        ldx  #d2_pat-4
        abx
        ldd  0,x
        std  d2_p               ; its top and bottom dot rows
        ldab d2_r               ; dot row = 3 * square row
        tba
        aslb
        aba
        tab
        ldx  #d2_buf
        abx
        ldaa 0,x
        oraa d2_p
        staa 0,x
        ldaa 1,x
        oraa d2_p+1
        staa 1,x
.nx:    inc  d2_i
        ldaa d2_i
        cmpa #6
        bne  .c
        ldab d2_g               ; into the chip: CG RAM $40 + glyph * 8
        aslb
        aslb
        aslb
        orab #$40
        bsr  lcd_cmd
        ldx  #d2_buf
.s:     ldab 0,x
        bsr  lcd_dat
        inx
        cpx  #d2_buf+8
        bne  .s
        rts

; B = an empty square: A = 3 (a hint) if the side to move can play there,
; else 0; B kept
d_hint: pshb
        ldaa e_side
        jsr  e_flips
        ldaa e_side             ; (e_me/e_op back for the side to move)
        pshb
        jsr  e_sides
        pula
        pulb
        tsta
        beq  .x
        ldaa #3
.x:     rts

; dot rows (top, bottom) for Solid, Hollow, a hint: left square, right square
d2_pat: fcb  $18,$18, $03,$03, $10,$08, $02,$01, 0,$08, 0,$01

d2_g:   fcb  0
d2_i:   fcb  0
d2_r:   fcb  0
d2_odd: fcb  0
d2_p:   fdb  0
d2_buf: rmb  8
