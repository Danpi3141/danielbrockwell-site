// Makes the opening book (data/book.bin, and data/book.json for the PC tools) by deep analysis
// with the reference engine on all cores.
//   node tools/book/gen_book.js [--nodes N] [--depth D] [--solid4 K] [--out data/book]
// Trees (the book is one-sided: only the Psion's replies are stored, keyed by the opponent's
// moves): 0 the Psion Solid having opened d2, 1 having opened c3, 2 the Psion Hollow (the
// opponent opened d2 or c3). Games opening e5 / f4 are the same turned half round.
// Every opponent move is expanded for D moves; for the Psion Solid's trees only the K likeliest
// at the last of them (by a quick search's ranking; 99 = all).
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');
const R = require('../../ref/rules.js');
const { Engine } = require('../../ref/engine.js');

const ROOT = path.join(__dirname, '..', '..');

function posOf(seq) {
  const e = new Engine();
  for (const s of seq) { if (!e.legal().length) e.pass(); e.make(s); }
  return e;
}

if (!isMainThread) {
  parentPort.on('message', (job) => {
    const out = [];
    for (const seq of job.seqs) {
      const e = posOf(seq);
      const t = Date.now();
      const r = e.think({ nodes: job.nodes, exact: 18, seed: 1 });
      // the opponent's likely replies afterwards: a quick ranking of its moves (for pruning)
      out.push({ key: seq.join(','), reply: r.move, score: r.score, depth: r.depth, ms: Date.now() - t });
    }
    parentPort.postMessage(out);
  });
} else {
  const args = process.argv.slice(2);
  const opt = (n, d) => { const i = args.indexOf('--' + n); return i >= 0 ? args[i + 1] : d; };
  const NODES = +opt('nodes', 2000000), DEPTH = +opt('depth', 4), SOLID4 = +opt('solid4', 99);
  const OUT = path.join(ROOT, opt('out', 'data/book'));
  const cacheFile = OUT + '_cache.json';
  const cache = fs.existsSync(cacheFile) ? JSON.parse(fs.readFileSync(cacheFile, 'utf8')) : {};
  const nw = os.cpus().length;
  const workers = Array.from({ length: nw }, () => new Worker(__filename));

  // analyse every sequence (the opponent has just moved; the Psion to reply), with the cache
  async function analyse(seqs) {
    const todo = seqs.filter(s => !cache[s.join(',') + '@' + NODES]);
    const parts = Array.from({ length: nw }, () => []);
    todo.forEach((s, i) => parts[i % nw].push(s));
    const rs = await Promise.all(parts.map((p, i) => new Promise(res => {
      if (!p.length) return res([]);
      workers[i].once('message', res);
      workers[i].postMessage({ seqs: p, nodes: NODES });
    })));
    for (const r of rs.flat()) cache[r.key + '@' + NODES] = r;
    fs.writeFileSync(cacheFile, JSON.stringify(cache));
    return seqs.map(s => cache[s.join(',') + '@' + NODES]);
  }

  // quick ranking of the opponent's moves (likeliest first): a level-4 search's score after each
  function rank(seq) {
    const e = posOf(seq);
    return e.legal().map(m => {
      const e2 = posOf([...seq, m]);
      const r = e2.legal().length ? e2.think({ level: 4, seed: 1 }) : { score: 0 };
      return [m, -r.score];
    }).sort((a, b) => b[1] - a[1]).map(x => x[0]);
  }

  (async () => {
    const t0 = Date.now();
    // a node: { opp, reply, kids: [] }; trees: arrays of nodes (the root groups)
    const trees = [[], [], []];
    // frontier: [tree, prefix sequence (opponent to move), group array, level]
    let frontier = [
      [0, [R.parse('d2')], trees[0], 1],
      [1, [R.parse('c3')], trees[1], 1],
    ];
    // tree 2: the opponent's first move is d2 or c3
    for (const op of ['d2', 'c3']) frontier.push([2, [], trees[2], 1, [R.parse(op)]]);
    for (let level = 1; level <= DEPTH && frontier.length; level++) {
      const items = [];
      for (const [t, pre, group, lv, only] of frontier) {
        const e = posOf(pre);
        let moves = only || e.legal();
        if (t < 2 && level === DEPTH && SOLID4 < 99 && !only) moves = rank(pre).slice(0, SOLID4);
        for (const m of moves) {
          const seq = [...pre, m];
          const e2 = posOf(seq);
          if (!e2.legal().length) continue;       // the Psion would pass: not in the book
          items.push({ t, seq, group });
        }
      }
      const res = await analyse(items.map(x => x.seq));
      const next = [];
      items.forEach((it, i) => {
        const node = { opp: it.seq[it.seq.length - 1], reply: res[i].reply, score: res[i].score, kids: [] };
        it.group.push(node);
        if (level < DEPTH) {
          const seq2 = [...it.seq, res[i].reply];
          if (posOf(seq2).legal().length) next.push([it.t, seq2, node.kids, level + 1]);
        }
      });
      const ms = res.reduce((s, r) => s + r.ms, 0);
      console.log(`level ${level}: ${items.length} positions (${(ms / 1000).toFixed(0)} s of analysis), ${((Date.now() - t0) / 1000).toFixed(0)} s so far`);
      frontier = next;
    }
    workers.forEach(w => w.terminate());
    // encode (tools/book/encode.js: format 2, 2 bytes a position)
    const { encode, count } = require('./encode.js');
    const bin = encode(trees);
    fs.writeFileSync(OUT + '.bin', bin);
    fs.writeFileSync(OUT + '.json', JSON.stringify({ nodes: NODES, depth: DEPTH, solid4: SOLID4, trees }, null, 0));
    console.log(`book: ${trees.map(count).join(' + ')} positions, ${bin.length} bytes -> ${OUT}.bin (${((Date.now() - t0) / 1000).toFixed(0)} s)`);
  })();
}
