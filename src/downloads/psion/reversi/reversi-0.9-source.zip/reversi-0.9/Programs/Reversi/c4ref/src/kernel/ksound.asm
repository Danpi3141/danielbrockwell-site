; ---------------------------------------------------------------------
; Sound (from Chess). BZ$TONE plays D = pitch (921,600 / (78 + 2D) Hz)
; for X ms. st_sound: 0 all, 1 ticks only, 2 off. A sound is a list of
; notes: pitch (word), ms (byte); pitch 0 ends it. Bit 7 of the first byte
; marks a "full" sound (not a tick).
; ---------------------------------------------------------------------
snd_tick:   fcb  $00                    ; a disc lands
            fdb  191
            fcb  25
            fdb  0
snd_buzz:   fcb  $80                    ; refused
            fdb  3033
            fcb  150
            fdb  0
snd_win:    fcb  $80                    ; four in a row
            fdb  842
            fcb  90
            fdb  660
            fcb  90
            fdb  549
            fcb  90
            fdb  401
            fcb  180
            fdb  0

; X = sound
snd_play:
        ldab st_sound
        cmpb #2
        beq  .x
        tstb
        beq  .go
        tst  0,x                ; ticks only: skip the full sounds
        bmi  .x
.go:    inx
.n:     ldd  0,x
        beq  .x
        pshx
        ldab 2,x
        clra
        pshb
        psha
        ldd  0,x
        pulx                    ; X = ms
        os   BZ$TONE
        pulx
        inx
        inx
        inx
        bra  .n
.x:     rts
