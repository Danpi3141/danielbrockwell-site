// Review mode and the history behind it. One-player games against random replies:
//  - every value the history holds (the book's, a solved search's) agrees with the PC solver;
//  - MODE on the result screen opens the review: each step back shows the position after that
//    many moves, the move's side and column, and the verdict the rules give from the history,
//    and every verdict shown is true (the solver's values before and after the move);
//  - UP goes to the start; DOWN to the next marked move (a verdict worse than "Still", or a
//    tactic; 19 Nov), and from the last to the end; leaving puts the position back, the result is not
//    counted again;
//  - where there is no verdict, or "Still a loss", the move's tactic (tests/ui/tactics.js) if any;
//  - from the menu in the middle of a game: the review, then the game goes on as it was.
//   node tests/ui/t_review.js [models...] (default cm lz64)
'use strict';
const { Game, assert } = require('./lib');
const S = require('../../tools/solver/solver');
S.ttInit();
const W = require('../../tools/book/walk');
const T = require('./tactics');
const models = process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'lz64'];
let rnd = 7; const rand = n => { rnd = (rnd * 1103515245 + 12345) & 0x7fffffff; return rnd % n; };

const hvOf = (g) => { const b = g.bytes('g_hv', 11); return p => (b[p >> 2] >> ((p & 3) * 2)) & 3; };
const val = w => (w > 0 ? 1 : w === 0 ? 2 : 3);           // solver sign -> 1 win, 2 draw, 3 loss
const TEXT = { '1,1': 'Still a win', '2,2': 'Still a draw', '3,3': 'Still a loss', '1,2': 'Win -> draw', '1,3': 'Win -> loss', '2,3': 'Draw -> loss' };

function rowsOf(rec) {     // the board as the engine holds it: rows top-down, . S H
  const ht = [0, 0, 0, 0, 0, 0, 0], bd = Array.from({ length: 6 }, () => '.......'.split(''));
  rec.forEach((c, i) => { bd[ht[c]++][c] = i % 2 ? 'H' : 'S'; });
  return bd.reverse().map(r => r.join(''));
}
function wonBy(rec, r) {   // did move r (1-based) make four?
  const p = S.fromMoves(rec.slice(0, r - 1));
  return S.isWinningMove(p, rec[r - 1]);
}
// the verdict OV_REVIEW gives for move r, from the history (null: none)
function verdict(hv, rec, r) {
  if (r === 0) return null;
  const rec1 = hv(r - 1);
  let bef = rec1 || (r >= 2 && hv(r - 2) ? 4 - hv(r - 2) : 0);
  let aft;
  if (wonBy(rec, r)) aft = 1;
  else if (r === 42) aft = 2;
  else if (hv(r)) aft = 4 - hv(r);
  else aft = rec1 ? bef : 0;
  if (!bef || !aft) return null;
  return { bef, aft, text: aft <= bef ? TEXT[aft + ',' + aft] : TEXT[bef + ',' + aft] };
}
// the value of a position for its side to move: the PC solver from 10 discs (fewer take it far
// too long); before that the PC's book walk (itself checked against Tromp's database): the
// Psion's turn: its book entry; your turn after the Psion's book move: the opposite. Else null.
let psion = 0;
function valueAt(seq) {
  if (seq.length >= 10) return val(S.solve(S.fromMoves(seq), true));
  const first = psion === 1;
  if ((seq.length % 2) + 1 === psion) { const c = W.walk(seq, first); return c ? (c < 8 ? 1 : c < 15 ? 2 : 3) : null; }
  if (!seq.length) return null;
  const prev = seq.slice(0, -1), c = W.walk(prev, first);
  if (!c || W.codeCol(c, prev, first) !== seq[seq.length - 1]) return null;
  return 4 - (c < 8 ? 1 : c < 15 ? 2 : 3);
}
// the true values for the side that made move r: before it and after it (null: not checked)
function truth(rec, r) {
  const bef = valueAt(rec.slice(0, r - 1));
  let aft;
  if (wonBy(rec, r)) aft = 1;
  else if (r === 42) aft = 2;
  else { const v = valueAt(rec.slice(0, r)); aft = v === null ? null : 4 - v; }
  return { bef, aft };
}
// your reply: a win if there is one, else a random move after which the Psion cannot win at
// once (so games last into the solved endings)
function reply(rec) {
  const p = S.fromMoves(rec), legal = [0, 1, 2, 3, 4, 5, 6].filter(c => S.canPlay(p, c));
  const w = legal.find(c => S.isWinningMove(p, c));
  if (w !== undefined) return w;
  const safe = legal.filter(c => {                    // the Psion cannot win at once after it
    const q = S.fromMoves(rec.concat([c]));
    return ![0, 1, 2, 3, 4, 5, 6].some(d => S.canPlay(q, d) && S.isWinningMove(q, d));
  });
  const pool = safe.length ? safe : legal;
  return pool[rand(pool.length)];
}
const moveText = (rec, r) => r === 0 ? 'Start' : `${r % 2 ? 'Solid' : 'Hollow'} col`;

let histKnown = 0, late = 0, verdicts = 0, tactics = 0, downs = 0;   // (verdicts: those checked against the true values)
for (const model of models) {
  const g = new Game(model).start();
  g.waitHuman(60);
  g.poke('st_level', 5);
  g.poke('st_you', 0);                      // you first: the Psion is Hollow, the book's second table
  g.poke('st_pace', 1);
  g.keys(['ON', 'EXE', 'EXE'], 1.5);        // New game, One player
  // a whole game: random replies (your turn: by the move count, as the panel lags)
  const ps = g.peek('g_psion');
  const yours = () => g.humanTurn() && (g.peek('g_n') % 2) + 1 !== ps;
  for (let guard = 0; guard < 60 && !g.peek('g_over'); guard++) {
    g.waitFor(() => g.peek('g_over') || yours(), 300, 0.1);
    if (g.peek('g_over')) break;
    const n = g.peek('g_n');
    const c = reply(g.rec());
    g.key('UVWOPQI'[c], 0.1);
    g.key('EXE', 0.3);
    g.waitFor(() => g.peek('g_n') > n, 5, 0.02);
  }
  assert(g.waitFor(() => g.peek('g_over') === 2, 30), 'the result counted');
  g.m.runSeconds(1);
  const rec = g.rec(), n = rec.length;
  psion = g.peek('g_psion');
  const tally = g.panel()[2];               // (four lines: the tally, from A:C4TAL)
  if (g.m.lines === 4) {                    // a fresh Organiser: this game is the tally's only one
    const t = (tally.match(/W(\d+) D(\d+) L(\d+)/) || []).slice(1).map(Number);
    assert(t.length === 3 && t[0] + t[1] + t[2] === 1, `${model}: the tally after one game: "${tally}"`);
  }
  // the history against the solver
  const hv = hvOf(g);
  let known = 0;
  for (let p = 0; p <= n; p++) {
    const v = hv(p);
    if (!v) continue;
    const psionToMove = (p % 2) + 1 === psion;
    assert(psionToMove, `${model}: history at ply ${p}, your turn`);
    const want = valueAt(rec.slice(0, p));
    assert(want !== null && v === want, `${model}: history at ply ${p} is ${v}, the solver says ${want} (${rec.slice(0, p).map(c => c + 1).join('')})`);
    known++;
    if (p >= 10) late++;
  }
  assert(known >= 3, `${model}: only ${known} values in the history`);
  histKnown += known;
  // the review from the result screen
  g.key('MODE', 0.8);
  const marked = [];
  for (let r = n; r >= 0; r--) {
    const pan = g.panel().map(s => s.trim());
    assert(pan[0].includes(moveText(rec, r)), `${model}: step ${r}: line 1 "${pan[0]}"`);
    if (r) assert(pan[0].endsWith(String(rec[r - 1] + 1)), `${model}: step ${r}: column in "${pan[0]}"`);
    assert(g.board().join('/') === rowsOf(rec.slice(0, r)).join('/'), `${model}: step ${r}: board ${g.board().join('/')}`);
    const v0 = verdict(hv, rec, r), tc = T.tactic(rec, r);
    const v = tc && (!v0 || v0.text === 'Still a loss') ? { text: T.TEXT[tc], tactic: true } : v0;
    if (v && (v.tactic || v.text.includes('->'))) marked.unshift(r);
    if (v && v.tactic) {
      assert(pan[1] === v.text, `${model}: step ${r}: "${pan[1]}", want the tactic "${v.text}"`);
      tactics++;
    } else if (v) {
      assert(pan[1] === v.text, `${model}: step ${r}: verdict "${pan[1]}", want "${v.text}"`);
      const t = truth(rec, r);
      if (t.bef !== null && t.aft !== null) {
        assert(t.bef === v.bef && t.aft === v.aft, `${model}: step ${r}: verdict ${v.text} but the solver says ${t.bef} -> ${t.aft}`);
        verdicts++;
      }
    } else if (g.m.lines === 2) {
      assert(pan[1] === `Move ${r}/${n}`, `${model}: step ${r}: line 2 "${pan[1]}"`);
    } else {
      assert(pan[1] === '' && pan[2] === `Move ${r}/${n}`, `${model}: step ${r}: lines 2-3 "${pan[1]}" "${pan[2]}"`);
    }
    if (r) g.key('LEFT', 0.3);
  }
  g.key('LEFT', 0.3);                       // (stays at the start)
  assert(g.panel()[0].trim() === 'Start', `${model}: past the start`);
  for (const r of [...marked.filter(r => r < n), n]) {   // DOWN: each marked move, then the end
    g.key('DOWN', 2.5);
    assert(g.board().join('/') === rowsOf(rec.slice(0, r)).join('/') && g.panel()[0].trim().includes(moveText(rec, r)), `${model}: DOWN to move ${r} (marked ${marked})`);
  }
  g.key('DOWN', 0.5);
  assert(g.panel()[0].trim().includes(moveText(rec, n)), `${model}: DOWN stays at the end`);
  downs += marked.length;
  g.key('UP', 0.3);
  assert(g.panel()[0].trim() === 'Start', `${model}: UP goes to the start`);
  g.key('RIGHT', 0.3);
  assert(g.board().join('/') === rowsOf(rec.slice(0, 1)).join('/'), `${model}: RIGHT one move on`);
  g.key('EXE', 1.5);                        // leave: the position back, the result again
  {                                         // (the winning four may be blinking: up to 4 cells blank)
    const got = g.board().join(''), want = rowsOf(rec).join('');
    const off = [...want].filter((ch, i) => got[i] !== ch && !(got[i] === '.' && ch !== '.')).length;
    const blank = [...want].filter((ch, i) => got[i] === '.' && ch !== '.').length;
    assert(off === 0 && blank <= 4 && g.peek('e_n') === n, `${model}: the position after leaving: ${g.board().join('/')}`);
  }
  assert(g.peek('g_over') === 2 && g.peek('g_n') === n, `${model}: the game as it was`);
  assert(g.panel()[2] === tally, `${model}: the result counted again: ${g.panel()[2]} was ${tally}`);
  assert(/win|draw/i.test(g.panel().join('|')), `${model}: the result screen again: ${g.panel().join('|')}`);
  // from the menu in the middle of a game
  g.key('EXE', 2);                          // a new game
  const ps2 = g.peek('g_psion');
  const yours2 = () => g.humanTurn() && (g.peek('g_n') % 2) + 1 !== ps2;
  for (let i = 0; i < 3; i++) {
    g.waitFor(yours2, 120, 0.1);
    const k = g.peek('g_n');
    g.key('UVWOPQI'[i + 1], 0.1);
    g.key('EXE', 0.3);
    g.waitFor(() => g.peek('g_n') > k, 5, 0.02);
  }
  g.waitFor(yours2, 120, 0.1);
  const rec2 = g.rec();
  g.keys(['ON', 'R', 'EXE'], 0.6);          // the menu: "Review game"
  assert(g.panel()[0].includes(moveText(rec2, rec2.length)), `${model}: review from the menu: ${g.panel().join('|')}`);
  g.key('LEFT', 0.3);
  assert(g.board().join('/') === rowsOf(rec2.slice(0, rec2.length - 1)).join('/'), `${model}: menu review, one back`);
  g.key('ON', 1);
  g.waitHuman(10);
  assert(g.board().join('/') === rowsOf(rec2).join('/') && g.peek('g_over') === 0, `${model}: back in the game`);
  console.log(`${model}: ${n} moves reviewed (${rec.map(c => c + 1).join("")}), ${known} history values right, verdicts checked so far ${verdicts}`);
}
assert(late > 0, 'no solved search reached the history');
console.log(`review ok: ${histKnown} history values agree with the solver or book (${late} from solved searches), ${verdicts} verdicts true, ${tactics} tactics shown, DOWN stopped at ${downs} marked moves`);
