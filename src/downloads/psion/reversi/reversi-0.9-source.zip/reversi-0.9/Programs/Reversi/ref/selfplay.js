// Plays engine games and checks every move is legal; prints node, time and result stats.
// node ref/selfplay.js [games] [levelA] [levelB]
'use strict';
const R = require('./rules.js');
const { Engine } = require('./engine.js');

function playGame(la, lb, seed, opts) {
  const e = new Engine(opts);
  e.seed = seed;
  let passes = 0, moves = 0;
  const stats = { nodes: [0, 0], thinks: [0, 0], maxFlips: 0, maxNodes: [0, 0] };
  while (true) {
    const legal = e.legal();
    if (!legal.length) {
      e.pass();
      if (++passes === 2) break;
      continue;
    }
    passes = 0;
    const lv = e.side === 1 ? la : lb;
    const r = e.think({ level: lv });
    const who = e.side - 1;
    stats.nodes[who] += r.nodes; stats.thinks[who]++;
    if (r.nodes > stats.maxNodes[who]) stats.maxNodes[who] = r.nodes;
    if (e.maxFlips > stats.maxFlips) stats.maxFlips = e.maxFlips;
    if (!legal.includes(r.move)) throw new Error('illegal move ' + r.move);
    e.make(r.move);
    moves++;
  }
  return { ns: e.ns, nh: e.nh, moves, stats };
}

if (require.main === module) {
  const games = +(process.argv[2] || 10), la = +(process.argv[3] || 3), lb = +(process.argv[4] || 3);
  let sw = 0, hw = 0, dr = 0, nodes = 0, thinks = 0, maxN = 0, maxF = 0;
  const t = Date.now();
  for (let g = 0; g < games; g++) {
    const r = playGame(la, lb, 1 + g * 7919);
    if (r.ns > r.nh) sw++; else if (r.nh > r.ns) hw++; else dr++;
    nodes += r.stats.nodes[0] + r.stats.nodes[1];
    thinks += r.stats.thinks[0] + r.stats.thinks[1];
    maxN = Math.max(maxN, ...r.stats.maxNodes);
    maxF = Math.max(maxF, r.stats.maxFlips);
  }
  const ms = Date.now() - t;
  console.log(`L${la} v L${lb}: Solid ${sw} Hollow ${hw} draw ${dr}; ${nodes} nodes in ${thinks} thinks ` +
    `(max ${maxN}), max flips ${maxF}; ${ms} ms, ${Math.round(nodes / ms)}k nodes/s`);
}
module.exports = { playGame };
