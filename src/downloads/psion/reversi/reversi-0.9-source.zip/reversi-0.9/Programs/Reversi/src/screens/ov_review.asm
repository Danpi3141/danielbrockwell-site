; =====================================================================
; OV_REVIEW (stretch goal 6, game review): the game's positions in turn.
; LEFT / RIGHT a move back / on, UP the start, DOWN the end; MODE or
; ON/CLEAR go back to the game as it was; EXE too at the end, or earlier
; "Go on? EXE": EXE plays on from the position shown (the moves after it
; are gone), another key stays in the review. Each position is replayed
; from the start (or the set-up position), passes found on the way. The
; panel: "Move 12/30", and the move that led there ("Solid d2 +3").
; =====================================================================
        include "../defs.inc"

        jmp  rv_start

rv_start:
        clr  kv_hon             ; (no hints here)
        ldaa g_n
        staa rv_k
.show:  ldab rv_k
        jsr  rp_to
        jsr  DRV+DV_BOARD
        jsr  pn_clear
        jsr  lb_clr             ; "Move 12/30"
        jsr  lb_s
        fcl  "Move "
        clra
        ldab rv_k
        jsr  lb_num
        ldaa #'/'
        jsr  lb_ch
        clra
        ldab g_n
        jsr  lb_num
        clra
        jsr  lb_put
        jsr  lb_clr             ; the move: "Solid d2 +3"
        ldab kv_lmv
        beq  .l2
        ldaa kv_lwho
        cmpa #SOLID
        bne  .h
        jsr  lb_s
        fcl  "Solid "
        bra  .sq
.h:     jsr  lb_s
        fcl  "Hollow "
.sq:    ldab kv_lmv
        jsr  lb_sq
        jsr  lb_sp
        ldaa #'+'
        jsr  lb_ch
        clra
        ldab kv_lfl
        jsr  lb_num
.l2:    ldaa #1
        jsr  lb_put
.k:     clra
        jsr  key_wait
        ldaa rv_k
        cmpb #K_LEFT
        bne  .r
        tsta
        beq  .k
        deca
        bra  .go
.r:     cmpb #K_RIGHT
        bne  .u
        cmpa g_n
        beq  .k
        inca
        bra  .go
.u:     clra
        cmpb #K_UP
        beq  .go
        ldaa g_n
        cmpb #K_DOWN
        beq  .go
        cmpb #K_EXE
        beq  .go_on
        cmpb #K_MODE
        beq  .x
        cmpb #K_ON
        beq  .x
        jmp  .k
.go_on: ldaa rv_k               ; EXE: at the end, back; earlier, play on from
        cmpa g_n
        beq  .x                 ; here (asked first)
        jsr  pn_msg
        fcl  "Go on? EXE"
        clra
        jsr  key_wait
        ldaa rv_k
        cmpb #K_EXE
        bne  .go
        staa g_n                ; the moves after it gone; replayed and saved
        ldd  #OV_GAME*256+G_REPSV
        jmp  ov_call
.x:     ldab g_n                ; back to the game as it was
        jsr  rp_to
        jsr  DRV+DV_BOARD
        jmp  pn_clear
.go:    staa rv_k
        bra  .show

rv_k:   fcb  0

; replaying the record (rp_to), with the engine's start and set-up
        include "replay.inc"
