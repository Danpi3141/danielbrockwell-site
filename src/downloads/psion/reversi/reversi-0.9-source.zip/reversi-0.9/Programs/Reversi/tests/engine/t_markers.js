// The spec's working-space check: marker bytes either side of the search's working space (and
// past the flip stack's 244 bytes) are untouched after many searches, normal and exact.
'use strict';
const { Harness } = require('./harness.js');
const { Engine, LEVELS, rnd } = require('../../ref/engine.js');
const h = new Harness({ build: false });
const lo = h.a('E_TT') - 8, fsEnd = h.a('E_FS') + 244, frm = h.a('E_FR'), end = h.a('E_SCRATCH_END');
const marks = [[lo, 8], [fsEnd, frm - fsEnd], [end, 8]];
const put = () => marks.forEach(([a, n]) => { for (let i = 0; i < n; i++) h.m.poke(a + i, 0xA5 ^ i); });
const ok = () => marks.every(([a, n]) => { for (let i = 0; i < n; i++) if (h.m.peek(a + i) !== (0xA5 ^ i)) return false; return true; });
put();
const st = { seed: 31337 };
let n = 0, maxFs = 0;
for (let g = 0; g < 12; g++) {
  const e = new Engine();
  let passes = 0;
  while (true) {
    const l = e.legal();
    if (!l.length) { e.pass(); if (++passes === 2) break; continue; }
    passes = 0;
    if (rnd(st) < 70) {
      const lv = 3 + rnd(st) % 4, L = LEVELS[lv];
      h.setPos(e.bd, e.side);
      h.think({ nodes: L.nodes, exact: L.exact + 2, seed: n });
      n++;
      if (!ok()) { console.log('a marker changed after search', n); process.exit(1); }
    }
    e.make(l[(rnd(st) * l.length) >> 8]);
  }
}
console.log(`${n} searches (normal and exact endings from up to 12 empty squares): the markers are untouched`);
