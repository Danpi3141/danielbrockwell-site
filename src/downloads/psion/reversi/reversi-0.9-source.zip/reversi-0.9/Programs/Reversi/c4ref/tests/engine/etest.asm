; Engine test image for harness.js: the engine, its variables and test drivers.
E_FR    = $6000
E_TT    = $6800
        include "engine.asm"
        include "evars.inc"
; the kernel's hook: never stop
t_poll: clc
        rts
