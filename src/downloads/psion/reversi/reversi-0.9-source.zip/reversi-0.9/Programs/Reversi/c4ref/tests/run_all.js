// Runs every test: node tests/run_all.js [--quick]
// (Quick: fewer games and models. The full run takes about 40 minutes.)
'use strict';
const { spawnSync } = require('child_process');
const path = require('path');
const quick = process.argv.includes('--quick');
const R = path.join(__dirname, '..');
const runs = [
  ['python', ['tools/build.py']],
  ['node', ['ref/test_engine.js', quick ? '300' : '2000', quick ? '30' : '100']],
  ['node', ['ref/test_forced.js', quick ? '150' : '1500']],
  ['node', ['tests/engine/t_match.js', quick ? '20' : '100', quick ? '40' : '160']],
  ['node', ['tools/book/check_book.js']],
  ['node', ['tools/book/test_walk.js']],
  ['node', ['tests/ui/t_twoplayer.js', ...(quick ? ['cm', 'lz64'] : ['cm', 'cm24', 'xp', 'la', 'lz', 'lz64'])]],
  ['node', ['tests/ui/t_features.js', ...(quick ? ['cm', 'lz64'] : ['cm', 'xp', 'la', 'lz', 'lz64'])]],
  ['node', ['tests/ui/t_modes.js', ...(quick ? ['cm', 'lz64'] : ['cm', 'xp', 'la', 'lz', 'lz64'])]],
  ['node', ['tests/ui/t_glyphs.js', 'cm', 'lz64']],
  ['node', ['tests/ui/t_list.js', 'cm', 'lz64']],
  ['node', ['tests/ui/t_review.js', 'cm', 'lz64']],
  ['node', ['tests/ui/t_tactics.js', 'cm', 'lz64', quick ? 'games=3' : 'games=10']],
  ['node', ['tests/ui/t_tally.js', 'lz64']],
  ['node', ['tests/ui/t_keep.js', 'cm', 'lz64']],
  ['node', ['tests/ui/t_forced.js', 'cm', 'lz64']],
  ['node', ['tests/ui/t_drop.js', 'cm', 'lz64']],
  ['node', ['tests/ui/t_autooff.js', 'cm']],
  ['node', ['tests/ui/t_autooff.js', 'lz64']],
  ['node', ['tests/ui/t_book.js', 'cm', quick ? '4' : '12']],
  ['node', ['tests/ui/t_search.js', 'cm', quick ? '2' : '4', '5']],
  ['node', ['tests/ui/t_lowmem.js']],
  ['node', ['tests/m1/holeprobe.js', ...(quick ? ['24-cm.rom', '46-lz64i.rom'] : [])]],
  ['node', ['tests/ui/t_thinkshow.js']],
  ['node', ['tests/ui/t_resign2.js']],
  ['node', ['tests/ui/t_selfplay.js', 'lz64', quick ? '1' : '2', '5', '5']],
  ['node', ['tests/ui/t_soak.js', 'cm', quick ? '6' : '20']],
  ['node', ['tests/ui/t_soak.js', 'lz64', quick ? '6' : '20']],
];
let failed = 0;
for (const [cmd, args] of runs) {
  const t0 = Date.now();
  const r = spawnSync(cmd, args, { cwd: R, encoding: 'utf8' });
  const ok = r.status === 0;
  if (!ok) failed++;
  const out = (r.stdout + r.stderr).trim().split('\n');
  console.log(`${ok ? 'ok  ' : 'FAIL'} ${args[0]} (${((Date.now() - t0) / 1000).toFixed(0)} s): ${ok ? out[out.length - 1] : out.slice(-6).join('\n      ')}`);
}
console.log(failed ? `${failed} FAILED` : 'all passed');
process.exit(failed ? 1 : 0);
