; =====================================================================
; OV_MENU: the menu (ON/CLEAR). Returns a command in A, B its argument.
; =====================================================================
        include "../defs.inc"

        jmp  mu_start

mu_start:
        ldx  #mu_items
        ldaa #15
        clrb
        jsr  menu
        psha                    ; (four lines: no menu lines left under what comes next)
        jsr  pn_clear
        pula
        cmpa #$FF
        beq  .none
        tab
        ldx  #mu_cmds
        abx
        ldaa 0,x
        bpl  .cmd
        ldd  #OV_LIST*256+L_TACT    ; the review (it returns no command)
        jmp  ov_call
.cmd:   cmpa #C_HINT            ; hints off: a buzz, no command
        bne  .c2
        tst  st_hints
        beq  .c2
        ldx  #snd_buzz
        jsr  snd_play
        clra
        rts
.c2:    cmpa #C_NEW
        bne  .arg
        ldx  #mu_modes          ; new game: which kind
        ldaa #3
        ldab g_mode
        jsr  menu
        psha
        jsr  pn_clear
        pula
        cmpa #$FF
        beq  .none
        tab
        cmpb #1                 ; two players: their names
        bne  .nw
        pshb
        jsr  mu_names
        pulb
.nw:    ldaa #C_NEW
        rts
.arg:   clrb                    ; (settings and level: from the first line)
        cmpa #C_COACH
        bne  .x
        clr  kv_arg             ; the coach, asked
.x:     rts
.none:  clra
        rts

; stretch goal 7: each player types a name of up to 6 letters (DEL rubs
; out, EXE takes it, ON/CLEAR: no name). With no name the side's own name
; (Solid, Hollow) is shown.
mu_names:
        ldx  #g_names
        stx  mu_np
        ldaa #'1'
        staa mu_pn
.p:     jsr  lb_clr
        jsr  lb_s
        fcl  "Player "
        ldaa mu_pn
        jsr  lb_ch
        ldaa #':'
        jsr  lb_ch
        clra
        jsr  lb_put
.ed:    jsr  lb_clr             ; the name so far and a cursor
        ldx  mu_np
        jsr  lb_fcl
        ldaa #'_'
        jsr  lb_ch
        ldaa #1
        jsr  lb_put
        clra
        jsr  key_wait
        ldx  mu_np
        cmpb #K_EXE
        beq  .nx
        cmpb #K_ON
        bne  .del
        clr  0,x                ; no name
        bra  .nx
.del:   cmpb #K_DEL
        bne  .l
        tst  0,x
        beq  .ed
        dec  0,x
        bra  .ed
.l:     cmpb #'A'
        blo  .ed
        cmpb #'Z'
        bhi  .ed
        ldaa 0,x
        cmpa #6
        bhs  .ed
        inc  0,x
        inca
        pshb
        tab
        abx
        pulb
        stab 0,x                ; the letter in its place
        bra  .ed
.nx:    ldab #7
        abx
        stx  mu_np
        inc  mu_pn
        ldaa mu_pn
        cmpa #'3'
        bne  .p
        rts

mu_cmds: fcb C_NEW,C_SET,C_BACK,C_HINT,C_SWAP,C_COACH,C_LIST,$80,C_EXPORT,C_IMPORT,C_SETUP,C_SET,C_HELP,C_RESIGN,C_LEAVE
mu_items:
        fcl  "New game"
        fcl  "Level"
        fcl  "Take back"
        fcl  "Hint"
        fcl  "Swap sides"
        fcl  "Coach"
        fcl  "Move list"
        fcl  "Review game"
        fcl  "Export game"
        fcl  "Import game"
        fcl  "Set up"
        fcl  "Settings"
        fcl  "Help"
        fcl  "Resign"
        fcl  "Leave"
mu_np:  fdb  0
mu_pn:  fcb  0
mu_modes:
        fcl  "One player"
        fcl  "Two players"
        fcl  "Demo"

MENU_V  = 0
        include "../kernel/kmenu.asm"
