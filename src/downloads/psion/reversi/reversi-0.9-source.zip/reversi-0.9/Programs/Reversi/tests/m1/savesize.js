// What A:REVSAV and A:REVTAL take: FREE on a blank CM, then after a game was saved and one
// counted in the tally.
'use strict';
const path = require('path'), fs = require('fs'), { execSync } = require('child_process');
const { Game } = require('../ui/lib.js');
const ROOT = path.join(__dirname, '..', '..'), out = path.join(ROOT, 'build', 'needs');
const Tools = path.join(ROOT, '..', '..', 'Tools');
fs.writeFileSync(path.join(out, 'FR.opl'), 'FR:\nLOCAL n%\nPRINT FREE :GET\n', 'latin1');
execSync(`python "${path.join(Tools, 'opl2opk.py')}" -f --target cm "${path.join(out, 'f.opk')}" "${path.join(out, 'FR.opl')}"`, { stdio: 'pipe' });
const g = new Game('cm');
g.m.insertPack(path.join(out, 'f.opk'), 1);
const free = () => { g.toTop(); g.m.runProc('FR', 'C'); g.m.runSeconds(1.5); const f = +(g.text().match(/(\d+)/) || [0, -1])[1]; g.m.press('EXE', 3, 10); g.m.runSeconds(0.5); return f; };
const f0 = free();
g.start(); g.waitHuman();
console.log('before menu:', g.panel().join('|'), 'res', g.peek('kv_res'), 'over', g.peek('g_over'), 'n', g.peek('g_n')); g.menu('Quit'); g.m.runSeconds(1);
const f1 = free();
// a finished game: the tally file too
g.start(); g.poke('st_level', 1);
while (!g.over()) { g.waitFor(() => g.over() || g.humanTurn(), 300, 0.2); if (g.over()) break; g.key('EXE', 0.4); }
console.log('before menu:', g.panel().join('|'), 'res', g.peek('kv_res'), 'over', g.peek('g_over'), 'n', g.peek('g_n')); g.menu('Quit'); g.m.runSeconds(1);
const f2 = free();
console.log(`FREE blank ${f0}; after the first save ${f1} (REVSAV ${f0 - f1}); with the tally ${f2} (REVTAL ${f1 - f2}); both ${f0 - f2}`);
