// The coach (stretch goal 7) against the reference engine: one-player games with Coach on; after
// each of your moves the verdict on the prompt line ("Coach c4 +3" or "Coach: good") must be the
// reference's: the same fixed-depth searches (3, or to the end in the last 7 empty squares) on the
// position before your move and after it, the scores in discs as OV_COACH converts them. The
// square must be one of the equal best (the Psion breaks ties at random). With one legal move
// there is no verdict.
//   node tests/ui/t_coach.js [models cm,lz64] [games 2]
'use strict';
const { Game, assert } = require('./lib.js');
const R = require('../../ref/rules.js');
const { Engine } = require('../../ref/engine.js');

const WIN = 2000;
function conv(s, eb) {
  if (s >= WIN) return s - WIN;
  if (s <= -WIN) return s + WIN;
  const k = eb > 30 ? 107 : eb > 12 ? 46 : 25, a = Math.abs(s);
  const d = (((a & 255) * k + 128) >> 8) + (a >> 8) * k;
  return s < 0 ? -d : d;
}
function engineAt(rec) {                 // the position after the record (passes found)
  const e = new Engine();
  for (const sq of rec) { if (!e.legal().length) e.pass(); e.make(R.idxOf(sq)); }
  return e;
}
// the verdict for playing `move` (board index) after `rec`: null (one move), {good} or {best: [..], d}
function verdict(rec, move) {
  const e = engineAt(rec);
  const legal = e.legal();
  if (!legal.length) e.pass();
  if (e.legal().length < 2) return null;
  const you = e.side, eb = e.empties();
  const d1 = eb <= 7 ? eb : 3;
  const r1 = e.think({ depth: d1, noise: 0, exact: 0 });
  const sB = Math.max(...r1.scores.map(x => x[1]));
  const best = r1.scores.filter(x => x[1] === sB).map(x => x[0]);
  e.make(move);
  let yours;
  const ea = e.empties();
  const d2 = ea <= 6 ? ea : 2;
  if (e.legal().length) yours = conv(-e.think({ depth: d2, noise: 0, exact: 0 }).score, eb);
  else {
    e.pass();
    if (e.legal().length) yours = conv(e.think({ depth: d2, noise: 0, exact: 0 }).score, eb);
    else { const m = e.ns - e.nh; yours = you === 1 ? m : -m; }
  }
  const diff = Math.min(99, conv(sB, eb) - yours);
  return diff <= 0 ? { good: true } : { best, d: diff };
}

const models = (process.argv[2] || 'cm,lz64').split(',');
const games = +(process.argv[3] || 2);
for (const model of models) {
  let checked = 0, goods = 0, nones = 0;
  for (let gi = 0; gi < games; gi++) {
    const g = new Game(model);
    g.start(); g.poke('st_level', 1); g.poke('st_coach', 1);
    g.poke('st_you', gi & 1);                  // Solid, then Hollow
    g.menu('New game');
    const hits = {}; if (process.env.COACH_DEBUG) { const S = g.sym.SLOTA[0]; g.m.dbg.setTrace(pc => { const o = pc - g.base - S; if (g.m.peek(g.base + g.sym.kv_res[0]) === 15 && (o === 0 || o === 3 || o === 6)) { hits[o] = (hits[o] || 0) + 1; if (o === 3) hits.mv = [g.m.peek(g.base + g.sym.e_move[0]), g.m.peekw(g.base + g.sym.e_score[0]), g.m.peek(g.base + g.sym.e_fixd[0]), g.m.peek(g.base + g.sym.e_side[0])]; } }); }
    for (let t = 0; t < 40; t++) {
      if (!g.waitFor(() => g.over() || g.turn(), 300, 0.1)) throw new Error('no turn: ' + g.text());
      if (g.over()) break;
      if (/Pass: EXE/.test(g.prompt())) { g.key('EXE', 0.5); continue; }
      const rec = g.rec();
      const n = rec.length;
      g.key('EXE', 0.1);                       // the cursor's square
      g.waitFor(() => g.peek('g_n') === n + 1, 10, 0.02);
      const move = R.idxOf(g.rec()[n]);
      const want = verdict(rec, move);
      let seen = null;
      let lastP = null;
      g.waitFor(() => { const p = g.prompt(); if (process.env.COACH_DEBUG && p !== lastP) { lastP = p; console.log('   prompt', JSON.stringify(p), g.m.cycles()); } if (/Coach (good|[a-h][1-6])|Coach: good/.test(p)) { g.m.runSeconds(0.2); seen = g.prompt().trim(); }   /* (the whole line printed) */ return seen || g.peek('kv_lwho') !== g.peek('e_side') ? !!seen : false; }, want ? 30 : 4, 0.05);
      if (process.env.COACH_DEBUG) console.log(n, R.name(move), JSON.stringify(want && (want.good ? "good" : want.best.map(R.name).join("/") + " +" + want.d)), "seen", seen, "cmob", engineAt(rec).legal().length, JSON.stringify(hits)); for (const k in hits) delete hits[k];
      if (!want) { assert(!seen, `${model}: a verdict with one move: ${seen}`); nones++; continue; }
      assert(seen, `${model}: no verdict after ${R.name(move)} (want ${JSON.stringify(want)}): ${g.text()}`);
      if (want.good) { assert(seen === 'Coach: good', `${model} after ${rec.length} moves, ${R.name(move)}: "${seen}", want good`); goods++; }
      else {
        const m = seen.match(/^Coach ([a-h][1-6]) ?\+(\d+)$/);
        assert(m, `${model}: "${seen}", want ${want.best.map(R.name)} +${want.d}`);
        assert(want.best.includes(R.parse(m[1])) && +m[2] === want.d,
          `${model} after ${rec.join(',')} you ${R.name(move)}: "${seen}", want ${want.best.map(R.name).join('/')} +${want.d}`);
      }
      checked++;
      g.m.runSeconds(2.2);
    }
  }
  console.log(`[${model}] ${checked} verdicts as the reference (${goods} "good"), ${nones} turns with one move`);
}
