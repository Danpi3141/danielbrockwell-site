; =====================================================================
; Engine calls for the kernel
; =====================================================================

; eng_reset: the starting position, Solid to move
eng_reset:
        ldx  #e_bd
.c:     ldaa #3
        staa 0,x
        inx
        cpx  #e_bd+80
        bne  .c
        ldx  #e_bd+11
.r:     ldab #8
.e:     clr  0,x
        inx
        decb
        bne  .e
        inx
        inx
        cpx  #e_bd+71
        bne  .r
        ldaa #2
        staa e_bd+34            ; Hollow d3 e4, Solid e3 d4
        staa e_bd+45
        ldaa #1
        staa e_bd+35
        staa e_bd+44
        staa e_side
        ; (on)

        include "esetup.asm"
