// Engine matches over varied openings, sides swapped, on all cores.
//   const { match } = require('./match.js');
//   await match({ a: {level:5, opts:{...}}, b: {level:5, opts:{...}}, openings: 100, plies: 6 })
// Each opening is played twice (A Solid, then B Solid). Returns A's score (win 1, draw 0.5).
'use strict';
const os = require('os');
const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');
const R = require('./rules.js');
const { Engine, rnd } = require('./engine.js');

// distinct random openings: `plies` random legal moves from the start (passes not allowed)
function openings(n, plies, seed = 0x5eed) {
  const st = { seed };
  const out = [], seen = new Set();
  let guard = 0;
  while (out.length < n && guard++ < n * 100) {
    const e = new Engine();
    const seq = [];
    let ok = true;
    for (let i = 0; i < plies; i++) {
      const l = e.legal();
      if (!l.length) { ok = false; break; }
      const s = l[(rnd(st) * l.length) >> 8];
      e.make(s); seq.push(s);
    }
    const k = seq.join(',');
    if (ok && !seen.has(k)) { seen.add(k); out.push(seq); }
  }
  return out;
}

function playFrom(seq, cfgS, cfgH, seed) {
  const es = new Engine(cfgS.opts), eh = new Engine(cfgH.opts);
  for (const s of seq) { es.make(s); eh.make(s); }
  es.seed = seed; eh.seed = seed ^ 0x777;
  let passes = 0;
  const moves = [];
  while (true) {
    const e = es.side === 1 ? es : eh;
    const legal = e.legal();
    if (!legal.length) {
      es.pass(); eh.pass();
      if (++passes === 2) break;
      continue;
    }
    passes = 0;
    const cfg = es.side === 1 ? cfgS : cfgH;
    const r = e.think(Object.assign({}, cfg.think || {}, { level: cfg.level }));
    if (!legal.includes(r.move)) throw new Error('illegal');
    moves.push(r.move);
    es.make(r.move); eh.make(r.move);
  }
  return { ns: es.ns, nh: es.nh, moves };
}

function runJobs(jobs) {
  const out = [];
  for (const j of jobs) {
    const g = playFrom(j.seq, j.aSolid ? j.a : j.b, j.aSolid ? j.b : j.a, j.seed);
    const d = g.ns - g.nh;
    const aWins = j.aSolid ? d > 0 : d < 0;
    const draw = d === 0;
    out.push({ i: j.i, score: draw ? 0.5 : aWins ? 1 : 0, margin: j.aSolid ? d : -d, ns: g.ns, nh: g.nh, seq: j.seq, moves: g.moves, aSolid: j.aSolid });
  }
  return out;
}

if (!isMainThread && workerData && workerData.jobs) {
  parentPort.postMessage(runJobs(workerData.jobs));
}

function match(cfg) {
  const ops = cfg.seqs || openings(cfg.openings || 100, cfg.plies || 6, cfg.oseed);
  const jobs = [];
  ops.forEach((seq, i) => {
    jobs.push({ i: 2 * i, seq, a: cfg.a, b: cfg.b, aSolid: true, seed: 1 + i });
    jobs.push({ i: 2 * i + 1, seq, a: cfg.a, b: cfg.b, aSolid: false, seed: 1 + i });
  });
  const nw = Math.min(cfg.workers || os.cpus().length, jobs.length);
  const parts = Array.from({ length: nw }, () => []);
  jobs.forEach((j, k) => parts[k % nw].push(j));
  return Promise.all(parts.map(p => new Promise((res, rej) => {
    const w = new Worker(__filename, { workerData: { jobs: p } });
    w.on('message', res); w.on('error', rej);
  }))).then(rs => {
    const all = rs.flat().sort((x, y) => x.i - y.i);
    const score = all.reduce((s, r) => s + r.score, 0);
    const margin = all.reduce((s, r) => s + r.margin, 0);
    return { games: all.length, score, pct: 100 * score / all.length, margin: margin / all.length, results: all };
  });
}

module.exports = { match, openings, playFrom };

if (require.main === module && isMainThread) {
  // node ref/match.js levelA levelB [openings]
  const la = +(process.argv[2] || 4), lb = +(process.argv[3] || 3), n = +(process.argv[4] || 100);
  const t = Date.now();
  match({ a: { level: la }, b: { level: lb }, openings: n }).then(r =>
    console.log(`L${la} v L${lb}: ${r.pct.toFixed(1)}% (${r.score}/${r.games}), mean margin ${r.margin.toFixed(2)}, ${Date.now() - t} ms`));
}
