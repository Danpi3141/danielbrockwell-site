// Turns a fit into engine weights at a scale and matches it against the current ones.
// node ref/tune/try.js data.jsonl scale levels openings
'use strict';
const { fit, NQ } = require('./fit.js');
const { match } = require('../match.js');
function toOpts(w, scale) {
  const q = [0, ...w.slice(0, NQ)].map(x => Math.round(x * scale));
  const quarter = [q.slice(0, 4), q.slice(4, 8), q.slice(8, 12)];
  const names = ['mob', 'corner', 'edge', 'par', 'disc'];
  const weights = {};
  names.forEach((n, k) => { weights[n] = [0, 1, 2].map(st => Math.round(w[NQ + st * 5 + k] * scale)); });
  return { quarter, weights };
}
module.exports = { toOpts };
if (require.main === module) {
  (async () => {
    const { w } = fit(process.argv[2]);
    const levels = (process.argv[4] || '4,6').split(',').map(Number);
    for (const scale of (process.argv[3] || '8').split(',').map(Number)) {
      const o = toOpts(w, scale);
      console.log('scale', scale, JSON.stringify(o));
      for (const lv of levels) {
        const r = await match({ a: { level: lv, opts: o }, b: { level: lv }, openings: +(process.argv[5] || 300) });
        console.log(`  L${lv}: ${r.pct.toFixed(1)}% margin ${r.margin.toFixed(2)}`);
      }
    }
  })();
}
