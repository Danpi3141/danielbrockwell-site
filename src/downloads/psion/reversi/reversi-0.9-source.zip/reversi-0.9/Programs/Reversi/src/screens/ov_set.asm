; =====================================================================
; OV_SET: the settings. UP/DOWN choose, LEFT/RIGHT change, EXE or
; ON/CLEAR go back. kv_arg = the line to start on. The last two lines
; are actions: Names (stretch goal 3: each player types up to 7 letters,
; DEL rubs out, EXE takes it, ON/CLEAR: no name) and Reset tally (asks
; first, EXE yes).
; =====================================================================
        include "../defs.inc"

N_SET   = 14
N_VAL   = 12                    ; lines with values

        jmp  se_start

se_start:
        ldab kv_arg
.again: stab se_i
        ldaa #1
        staa mn_lr
        ldx  #se_val
        stx  mn_val
        ldx  #se_items
        ldaa #N_SET
        jsr  menu_v
        cmpa #$FF
        beq  .x                 ; ON: done
        cmpb #N_SET-1           ; Reset tally: any of EXE, LEFT, RIGHT asks
        beq  .rst
        cmpb #N_VAL             ; Names (OV_SETUP, which reads this in again)
        bne  .v
        stab kv_arg
        ldd  #OV_SETUP*256+S_NAMES
        jmp  ov_call
.v:
        cmpa #$FD
        blo  .x                 ; EXE: done
        stab se_i
        ldx  #st_level          ; the setting's byte
        abx
        stx  se_p
        aslb                    ; its range: min, max
        ldx  #se_rng
        abx
        ldab 0,x
        stab se_min
        ldab 1,x
        stab se_max
        ldx  se_p
        ldab 0,x
        cmpa #$FE
        beq  .dn
        incb                    ; RIGHT: up, round to the lowest
        cmpb se_max
        bls  .st
        ldab se_min
        bra  .st
.dn:    decb                    ; LEFT: down, round to the highest
        cmpb se_min
        bge  .st
        ldab se_max
.st:    stab 0,x
        ldab se_i
        bra  .again
.x:     jmp  pn_clear
.rst:   jsr  pn_msg
        fcl  "Reset? EXE"
        clra
        jsr  key_wait
        cmpb #K_EXE
        bne  .no
        clr  kv_pkok            ; (the file services select A:)
        ldx  #se_tal
        os   FL$DELN
        clr  kv_pkok
.no:    ldab #N_SET-1
        bra  .again

; A = item: its value, at the right of the line
se_val: cmpa #N_VAL
        bhs  .x
        tab
        ldx  #st_level
        abx
        ldaa 0,x                ; the value
        aslb
        ldx  #se_txt
        abx
        ldx  0,x                ; its words, or 0: a digit
        bne  .w
        adda #'0'
        psha
        ldaa #10
        jsr  lb_at
        pula
        jmp  lb_ch
.w:     tsta                    ; the value's word
        beq  .p
        ldab 0,x
        incb
        abx
        deca
        bra  .w
.p:     ldaa #11
        suba 0,x
        pshx
        jsr  lb_at
        pulx
        jmp  lb_fcl
.x:     rts

se_tal: fcl  "A:REVTAL"
se_items:
        fcl  "Level"
        fcl  "Play"
        fcl  "You"
        fcl  "Conf"
        fcl  "Book"
        fcl  "Sound"
        fcl  "Score"
        fcl  "Corners"
        fcl  "Hints"
        fcl  "Coach"
        fcl  "Auto"
        fcl  "Demo H"
        fcl  "Names"
        fcl  "Reset tally"
se_rng: fcb  1,8, 0,2, 0,2, 0,1, 0,1, 0,1, 0,1, 0,4, 0,1, 0,1, 0,1, 0,8
se_txt: fdb  0, se_ply, se_you, se_on, se_on, se_on, se_fin, 0, se_off, se_off, se_off, 0
se_ply: fcl  "One"
        fcl  "Two"
        fcl  "Demo"
se_you: fcl  "Solid"
        fcl  "Hollow"
        fcl  "Turns"
se_on:  fcl  "On"
se_off: fcl  "Off"
        fcl  "On"
se_fin: fcl  "Disc"
        fcl  "Wins"
se_i:   fcb  0
se_p:   fdb  0
se_min: fcb  0
se_max: fcb  0

MENU_V  = 1
        include "../kernel/kmenu.asm"
