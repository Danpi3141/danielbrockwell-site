// The coach's "by how many discs": how the depth-3 score of a position (the side to move's view,
// in the evaluation's units) relates to the final disc margin. Self-play games at level 5 from
// varied openings; at every third position the depth-3 score is set against the margin the game
// ended with. A fit through the origin per stage (the evaluation's own: more than 30 empty
// squares, 13-30, 12 or fewer) gives discs per unit; the coach shows (best - yours) * that.
//   node ref/tune/coachcal.js [openings 300]
'use strict';
const os = require('os');
const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');
const { Engine } = require('../engine.js');

if (!isMainThread) {
  const out = [];
  for (const seq of workerData.cseqs) {
    const e = new Engine();
    for (const s of seq) e.make(s);
    e.seed = seq.length * 31 + seq[0];
    const pts = [];
    let passes = 0, k = 0;
    while (passes < 2) {
      const l = e.legal();
      if (!l.length) { e.pass(); passes++; continue; }
      passes = 0;
      if (k++ % 3 === 0 && e.empties() > 7) {
        const c = new Engine();
        c.bd.set(e.bd); c.ns = e.ns; c.nh = e.nh; c.side = e.side; c.sqs = e.sqs;
        const r = c.think({ depth: 3, noise: 0, seed: 1 });
        if (Math.abs(r.score) < 1000) pts.push({ side: e.side, emp: e.empties(), s: r.score });
      }
      const r = e.think({ level: 5 });
      e.make(r.move);
    }
    const m = e.ns - e.nh;
    for (const p of pts) out.push({ emp: p.emp, s: p.s, m: p.side === 1 ? m : -m });
  }
  parentPort.postMessage(out);
} else {
  const { openings } = require('../match.js');
  const n = +(process.argv[2] || 300);
  const seqs = openings(n, 6, 4242);
  const nw = Math.min(os.cpus().length, seqs.length);
  const parts = Array.from({ length: nw }, () => []);
  seqs.forEach((s, i) => parts[i % nw].push(s));
  Promise.all(parts.map(p => new Promise((res, rej) => {
    const w = new Worker(__filename, { workerData: { cseqs: p } });
    w.on('message', res); w.on('error', rej);
  }))).then(rs => {
    const pts = rs.flat();
    for (const [name, lo, hi] of [['>30 empty', 31, 99], ['13-30', 13, 30], ['8-12', 8, 12]]) {
      const q = pts.filter(p => p.emp >= lo && p.emp <= hi);
      const sxy = q.reduce((a, p) => a + p.s * p.m, 0), sxx = q.reduce((a, p) => a + p.s * p.s, 0);
      const k = sxy / sxx;
      const err = Math.sqrt(q.reduce((a, p) => a + (p.m - k * p.s) ** 2, 0) / q.length);
      console.log(`${name}: ${q.length} positions, ${k.toFixed(4)} discs a unit (x256 = ${Math.round(k * 256)}), rms ${err.toFixed(1)} discs`);
    }
  });
}
