; =====================================================================
; OV_FX: the board's animations, from the last move: kv_lmv its square,
; kv_lwho the side that made it, BUF its flipped squares (kv_lfl of them,
; as e_make or a replay left them).
; X_MOVE  (stretch goal 1, flip ripple) the board as it was, the new disc,
;         then the flipped discs turning a ring at a time outward from it;
;         then the new disc flashes twice.
; X_LAST  (stretch goal 2, last-move marker: L) the last move and the discs
;         it flipped flash, as they were and as they are, three times.
; =====================================================================
        include "../defs.inc"

        jmp  fx_move
        jmp  fx_last

fx_move:
        ldab kv_lmv             ; (nothing if there is no move)
        beq  .x
        cmpb #$FF
        beq  .x
        bsr  before             ; the board as it was
        jsr  DRV+DV_BOARD
        ldab kv_lmv             ; the new disc
        ldaa kv_lwho
        jsr  set
        ldaa #1
        staa fx_d
.ring:  clr  fx_any             ; the flips at this distance turn
        ldx  #BUF
.f:     stx  fx_p
        cpx  fx_end
        beq  .e
        ldab 0,x
        stab fx_t
        jsr  dist
        cmpa fx_d
        bne  .n
        inc  fx_any
        ldab fx_t
        ldaa kv_lwho
        jsr  set
.n:     ldx  fx_p
        inx
        bra  .f
.e:     tst  fx_any
        beq  .z
        ldaa #2
        jsr  pause
.z:     inc  fx_d
        ldaa fx_d
        cmpa #8
        bne  .ring
        ldab #4                 ; the new disc flashes twice
.fl:    pshb
        ldaa kv_lwho
        andb #1
        beq  .o
        clra
.o:     ldab kv_lmv
        jsr  set
        ldaa #3
        jsr  pause
        pulb
        decb
        bne  .fl
        ldaa kv_lwho
        ldab kv_lmv
        jsr  set
        tst  st_coach           ; the coach (stretch goal 7): after your own
        beq  .x                 ; move in a one-player game
        ldaa g_psion
        beq  .x
        cmpa #3
        beq  .x
        anda kv_lwho
        bne  .x
        ldd  #OV_COACH*256
        jmp  ov_call
.x:     rts

; X_LAST: as it was, as it is, three times
fx_last:
        ldab kv_lmv
        beq  .no
        cmpb #$FF
        beq  .no
        ldaa #6
        staa fx_d
.l:     ldaa fx_d
        bita #1
        bne  .now
        bsr  before
        bra  .d
.now:   bsr  after
.d:     jsr  DRV+DV_BOARD
        ldaa #6
        jsr  pause
        dec  fx_d
        bne  .l
        rts
.no:    jmp  buzz

; the board before the last move (its square empty, its flips the other side's)
before: clra
        ldab kv_lmv
        bsr  put
        ldaa kv_lwho
        eora #3
        bra  flips
; and after it
after:  ldaa kv_lwho
        ldab kv_lmv
        bsr  put
        ldaa kv_lwho
; A = a side: every flipped square holds it
flips:  staa fx_s
        ldab kv_lfl
        ldx  #BUF
        abx
        stx  fx_end
        ldx  #BUF
.l:     cpx  fx_end
        beq  .x
        ldab 0,x
        pshx
        ldaa fx_s
        bsr  put
        pulx
        inx
        bra  .l
.x:     rts

; B = square, A = side: into the board
put:    ldx  #e_bd
        abx
        staa 0,x
        rts
; and shown
set:    pshb
        bsr  put
        pula
        jmp  DRV+DV_SQ

; B = a square: A = its distance from the move's (the larger of the row and
; column differences)
dist:   bsr  rc
        stab fx_c
        staa fx_r
        ldab kv_lmv
        bsr  rc
        subb fx_c
        bcc  .c
        negb
.c:     suba fx_r
        bcc  .r
        nega
.r:     cba
        bhs  .x
        tba
.x:     rts
; B = a square index: A = its row, B = its column
rc:     clra
.l:     subb #10
        bcs  .d
        inca
        bra  .l
.d:     addb #10
        rts

fx_d:   fcb  0
fx_any: fcb  0
fx_t:   fcb  0
fx_s:   fcb  0
fx_r:   fcb  0
fx_c:   fcb  0
fx_p:   fdb  0
fx_end: fdb  0
