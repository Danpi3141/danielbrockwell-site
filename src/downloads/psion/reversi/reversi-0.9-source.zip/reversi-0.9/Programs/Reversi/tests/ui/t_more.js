// More paths: S (the legal squares flash, the cursor stays), ON then "Leave? EXE" (and resuming),
// a drawn result, the tally counting two games (its file read back), names with two players.
'use strict';
const { Game, assert } = require('./lib.js');
for (const model of (process.argv[2] || 'cm,lz64').split(',')) {
  const g = new Game(model);
  g.start(); g.poke('st_level', 1);
  const log = m => console.log(`[${model}] ${m}`);
  // S
  g.waitHuman(); g.key('RIGHT', 0.3);
  const cur = g.prompt(), seen = new Set();
  g.key('S', 0.05);
  for (let i = 0; i < 20; i++) { g.m.runSeconds(0.05); seen.add(JSON.stringify([g.m.udgs(), g.m.cells()])); }
  g.waitHuman();
  assert(seen.size > 2 && g.prompt() === cur, `S flashed (${seen.size} screens), the cursor stays: ${g.prompt()} was ${cur}`);
  log('show ok');
  // ON, Leave? EXE, then resume
  g.key('EXE', 1); g.waitHuman();
  const n = g.peek('g_n');
  g.key('ON', 0.5);
  assert(/Leave\? EXE/.test(g.prompt()), 'Leave? ' + g.prompt());
  g.key('DEL', 0.5);                             // any other key: back
  assert(g.humanTurn(), 'back to the move: ' + g.prompt());
  g.key('ON', 0.5); g.key('EXE', 1.5);
  assert(!g.humanTurn() && !/Leave/.test(g.text()), 'left: ' + g.text());
  g.start(); g.waitHuman();
  assert(g.peek('g_n') === n, 'resumed at ' + g.peek('g_n'));
  log('leave and resume ok');
  // a draw: a1 Solid, h6 Hollow and nothing else: neither can move
  g.menu('New game');
  g.menu('Set up');
  g.key('SPACE', 0.2);                            // a1 Solid
  g.keys(['DOWN', 'DOWN', 'RIGHT', 'RIGHT', 'RIGHT'], 0.15);
  g.keys(['SPACE', 'RIGHT', 'SPACE', 'SPACE', 'DOWN', 'SPACE', 'LEFT', 'SPACE', 'SPACE'], 0.15);   // d3 e3 e4 d4 empty
  for (let i = 0; i < 4; i++) g.key('RIGHT', 0.1);
  g.keys(['DOWN', 'DOWN', 'RIGHT', 'RIGHT'], 0.15);   // to h6
  g.key('SPACE', 0.2); g.key('SPACE', 0.2);        // h6 Hollow
  assert(g.board().join('') === 'X' + '.'.repeat(46) + 'O', 'the draw board: ' + g.board().join('/'));
  g.key('EXE', 0.8); g.key('EXE', 2.0);
  g.waitFor(() => g.over(), 20);
  assert(/Draw 1-1/.test(g.panel().join('|')), 'a draw: ' + g.panel().join('|'));
  log('draw ok');
  // two games counted at level 1
  for (let k = 0; k < 2; k++) {
    g.menu('New game');
    g.playOut();
    g.m.runSeconds(1);
  }
  g.menu('Tally');
  const t = g.panel().join('|');
  const m = t.match(/L1 (\d+)-(\d+)-(\d+)/);
  assert(m && (+m[1] + +m[2] + +m[3]) === 2, 'two games at level 1: ' + t);
  g.key('EXE', 0.5);
  log('tally ok: ' + m[0]);
  // two players with names: the panel and the result use them
  g.poke('st_players', 1);
  g.menu('Settings');
  for (let k = 0; k < 12; k++) g.key('DOWN', 0.15);       // (Names: after Coach, Auto, Demo H)
  g.key('EXE', 0.5); g.keys(['A', 'N', 'N', 'EXE'], 0.2); g.keys(['B', 'O', 'B', 'EXE'], 0.2);
  g.key('ON', 0.6);
  g.menu('New game');
  g.waitHuman();
  if (g.m.lines === 4) assert(/ANN/.test(g.panel()[0]) && /BOB/.test(g.panel()[1]), 'names in the panel: ' + g.panel().join('|'));
  log('names with two players ok');
}
