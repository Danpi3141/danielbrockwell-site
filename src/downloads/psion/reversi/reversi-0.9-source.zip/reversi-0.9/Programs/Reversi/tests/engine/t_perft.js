// Move counts on the 6303 (the spec's check: to depth 6, 7,892) and the board after them.
'use strict';
const { Harness } = require('./harness.js');
const want = [4, 12, 56, 244, 1380, 7892, 51246, 346758, 2523782];
const h = new Harness();
const maxd = +(process.argv[2] || 6);
const start = JSON.stringify(h.state());
let ok = true;
for (let d = 1; d <= maxd; d++) {
  const r = h.call('t_perft', d);
  const n = h.p24('t_cnt');
  const same = JSON.stringify(h.state()) === start;
  const good = n === want[d - 1] && same;
  ok = ok && good;
  console.log(`depth ${d}: ${n} ${n === want[d - 1] ? 'ok' : 'WANT ' + want[d - 1]}${same ? '' : ' BOARD CHANGED'} (${(r.cycles / 921600).toFixed(2)} s)`);
}
process.exit(ok ? 0 : 1);
