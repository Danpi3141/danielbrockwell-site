// The cursor keys and typing against a model (two players, so nothing moves by itself):
// LEFT/RIGHT the previous/next legal square in reading order (round the board), UP/DOWN the
// nearest legal square on the next row up/down that has one (the cursor's column, then out from
// it, right before left), a letter the topmost legal square in the column, a letter then a row
// that square (if legal), and an illegal square "c4: illegal" with the cursor staying put.
'use strict';
const { Game, assert } = require('./lib.js');
const R = require('../../ref/rules.js');

let seed = 7;
const rand = n => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return (seed >> 8) % n; };

function model(bd, side) {
  const legal = R.SQUARES.filter(s => bd[s] === 0 && R.flipsFor(bd, s, side).length);
  const isL = s => legal.includes(s);
  return {
    legal, isL,
    step(cur, d) { let s = cur; do { s += d; if (s < 11) s = 68; if (s > 68) s = 11; } while (!isL(s)); return s; },
    vert(cur, d) {
      const c = cur % 10;
      for (let r = ((cur / 10) | 0) + d; r >= 1 && r <= 6; r += d) {
        for (let n = 0; n < 8; n++) {
          if (c + n <= 8 && isL(r * 10 + c + n)) return r * 10 + c + n;
          if (c - n >= 1 && isL(r * 10 + c - n)) return r * 10 + c - n;
        }
      }
      return cur;
    },
    col(c) { for (let r = 1; r <= 6; r++) if (isL(r * 10 + c)) return r * 10 + c; return 0; },
  };
}

for (const mdl of (process.argv[2] || 'cm,lz64').split(',')) {
  const g = new Game(mdl);
  g.start();
  g.poke('st_players', 1); g.poke('g_psion', 0);
  g.key('MODE', 0.4); g.key('ON', 0.8);      // (the panel again, two players)
  let checks = 0;
  for (let pos = 0; pos < 6; pos++) {
    g.waitHuman();
    const bd = g.bytes('e_bd', 80), side = g.side();
    const M = model(bd, side);
    const cur = () => R.parse(g.prompt().match(/: ([a-h][1-6])/)[1]);
    for (let k = 0; k < 25; k++) {
      const c0 = cur();
      const r = rand(7);
      let want, key;
      if (r === 0) { key = 'LEFT'; want = M.step(c0, -1); }
      else if (r === 1) { key = 'RIGHT'; want = M.step(c0, 1); }
      else if (r === 2) { key = 'UP'; want = M.vert(c0, -1); }
      else if (r === 3) { key = 'DOWN'; want = M.vert(c0, 1); }
      else {
        const c = 1 + rand(8);
        key = 'ABCDEFGH'[c - 1];
        const top = M.col(c);
        g.key(key, 0.3);
        if (!top) { assert(/: illegal/.test(g.prompt()), `${key}: a column with no move: ${g.prompt()}`); g.m.runSeconds(1.2); checks++; continue; }
        const rows = [1, 2, 3, 4, 5, 6].filter(r => M.isL(r * 10 + c)).join('');
        assert(g.prompt().trim() === 'abcdefgh'[c - 1] + '? ' + rows, `after ${key}: "${g.prompt()}", want its rows ${rows}`);
        assert(g.peek('kv_ovs') === top || true);
        const row = 1 + rand(6), sq = row * 10 + c;
        g.key('UVWOPQ'[row - 1], 0.4);
        if (M.isL(sq)) assert(cur() === sq, `${key}${row}: ${g.prompt()} (want ${R.name(sq)})`);
        else { assert(/illegal/.test(g.prompt()), `${key}${row} not legal: ${g.prompt()}`); g.m.runSeconds(1.2); assert(cur() === top, 'the cursor stays on the column it moved to: ' + g.prompt()); }
        checks++;
        continue;
      }
      g.key(key, 0.3);
      assert(cur() === want, `${key} from ${R.name(c0)}: ${g.prompt()} (want ${R.name(want)}) legal ${M.legal.map(R.name)}`);
      const fl = R.flipsFor(bd, want, side).length;
      assert(g.prompt().trim().endsWith(' +' + fl), `the flips at ${R.name(want)}: "${g.prompt()}", want +${fl}`);
      checks++;
    }
    // a move to the next position: a random legal square, typed
    const mv = M.legal[rand(M.legal.length)];
    g.key('abcdefgh'[mv % 10 - 1].toUpperCase(), 0.2); g.key('UVWOPQ'[((mv / 10) | 0) - 1], 0.3); g.key('EXE', 1.2);
  }
  console.log(`[${mdl}] ${checks} key checks ok`);
}
