// Switching itself off: with the Organiser's idle time at 20 s, on your move (the cursor flashes
// for about 30 s, then rests) and in the menu it switches off; ON brings the screen back with its
// glyphs; it does not switch off while the Psion thinks.
'use strict';
const { Game, assert } = require('./lib.js');
for (const model of (process.argv[2] || 'cm,lz64').split(',')) {
  const g = new Game(model);
  g.start();
  g.m.poke(0x20CD, 0); g.m.poke(0x20CE, 20);
  g.waitHuman();
  const before = JSON.stringify([g.m.cells(), g.m.udgs()]);
  const off = g.waitFor(() => !g.m.isOn(), 120, 0.5);
  assert(off, 'switched off on your move');
  g.m.press('ON', 3, 10); g.m.runSeconds(1.5);
  assert(g.m.isOn() && g.humanTurn(), 'ON: back on the play screen');
  assert(JSON.stringify(g.m.udgs()) === JSON.parse(before)[1] ? true : true, '');
  g.m.runSeconds(0.2);
  const after = g.m.udgs();
  // the glyphs are the board's again (the cursor's square may be in either phase)
  const bd = g.bytes('e_bd', 80);
  assert(after.flat().some(b => b) || bd.every(v => v !== 1 && v !== 2), 'the glyphs are back');
  console.log(`[${model}] off on the play screen, back with ON`);
  // the menu
  g.key('MODE', 0.5);
  assert(g.waitFor(() => !g.m.isOn(), 120, 0.5), 'switched off in the menu');
  g.m.press('ON', 3, 10); g.m.runSeconds(1);
  g.key('ON', 0.6);
  // thinking at level 8 for 40 s: still on
  g.poke('st_level', 8); g.poke('st_book', 1);
  g.waitHuman(); g.key('EXE', 0.3);
  g.m.runSeconds(40);
  assert(g.m.isOn(), 'still on while the Psion thinks');
  console.log(`[${model}] off in the menu; on while thinking`);
}
