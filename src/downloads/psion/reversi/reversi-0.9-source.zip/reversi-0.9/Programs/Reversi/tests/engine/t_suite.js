// The spec's suite: 500 positions (from random games, every stage), each searched at one level
// (1-7 in turn) on the 6303 and by the reference: the same move, score, depth, positions and
// seed, and the board unchanged after the search. Writes data/suite.json (position, level, seed,
// move, positions) for later checks.
'use strict';
const fs = require('fs'), path = require('path');
const { Harness } = require('./harness.js');
const { Engine, LEVELS, rnd } = require('../../ref/engine.js');
const N = +(process.argv[2] || 500);
const h = new Harness({ build: false });
const st = { seed: 500500 };
const suite = [];
let bad = 0, nodes = 0, cyc = 0;
while (suite.length < N) {
  const e = new Engine();
  const stop = 4 + (rnd(st) % 42);
  let passes = 0;
  for (let ply = 0; ply < stop; ply++) {
    const l = e.legal();
    if (!l.length) { e.pass(); if (++passes === 2) break; continue; }
    passes = 0;
    e.make(l[(rnd(st) * l.length) >> 8]);
  }
  if (!e.legal().length) continue;
  const lv = 1 + (suite.length % 7), L = LEVELS[lv], seed = 1 + suite.length * 13;
  const bd = Array.from(e.bd), side = e.side;
  const r = e.think({ level: lv, seed });
  h.setPos(bd, side);
  const before = JSON.stringify(h.state());
  const a = h.think({ nodes: L.nodes, depth: L.depth, noise: L.noise, exact: L.exact, seed });
  const ex = r.margin ? 2 : r.exact ? 1 : 0;
  const ok = a.move === r.move && a.score === r.score && a.nodes === r.nodes && a.exact === ex &&
    (ex === 2 || a.depth === r.depth) && a.seed === e.seed && JSON.stringify(h.state()) === before;
  if (!ok) { bad++; console.log('differs', suite.length, lv, JSON.stringify(a), r.move, r.score, r.nodes); }
  nodes += a.nodes; cyc += a.cycles;
  suite.push({ bd: bd.join(''), side, level: lv, seed, move: r.move, score: r.score, nodes: r.nodes });
}
fs.writeFileSync(path.join(__dirname, '..', '..', 'data', 'suite.json'), JSON.stringify(suite));
console.log(`${N} suite positions, levels 1-7: ${bad} differ; ${nodes} positions in ${(cyc / 921600).toFixed(0)} s emulated (${(nodes / (cyc / 921600)).toFixed(0)} a second)`);
process.exit(bad ? 1 : 0);
