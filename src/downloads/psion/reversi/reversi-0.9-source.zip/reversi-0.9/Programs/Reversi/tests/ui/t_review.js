// Game review: after some moves, every step (LEFT, RIGHT, UP, DOWN) shows the position after that
// many moves (the reference replays them) and "Move k/n"; leaving restores the game.
'use strict';
const { Game, assert } = require('./lib.js');
const R = require('../../ref/rules.js');
function rows(rec, k) {
  const b = R.newBoard(); let side = 1;
  for (const sq of rec.slice(0, k)) { if (!R.legalMoves(b, side).length) side = 3 - side; R.play(b, R.idxOf(sq), side); side = 3 - side; }
  const out = []; for (let r = 1; r <= 6; r++) { let s = ''; for (let c = 1; c <= 8; c++) s += '.XO'[b[r * 10 + c]]; out.push(s); }
  return out.join('/');
}
for (const model of (process.argv[2] || 'cm,lz64').split(',')) {
  const g = new Game(model);
  g.start(); g.poke('st_level', 1);
  for (let i = 0; i < 6; i++) { g.waitHuman(); g.key('EXE', 1.0); }
  g.waitHuman();
  const rec = g.rec(), n = rec.length, live = g.board().join('/');
  g.menu('Review');
  let k = n;
  const seen = (want) => {
    assert(g.board().join('/') === rows(rec, want), `review at ${want}: ${g.board().join('/')} want ${rows(rec, want)}`);
    assert(g.panel()[0].includes(`Move ${want}/${n}`), `the panel: ${g.panel()[0]}`);
  };
  seen(n);
  for (const [key, d] of [['LEFT', -1], ['LEFT', -1], ['RIGHT', 1], ['UP', 'start'], ['RIGHT', 1], ['DOWN', 'end'], ['RIGHT', 0], ['UP', 'start'], ['LEFT', 0]]) {
    g.key(key, 0.8);
    k = d === 'start' ? 0 : d === 'end' ? n : Math.max(0, Math.min(n, k + d));
    seen(k);
  }
  g.key('ON', 1.0);                         // (back as it was; EXE earlier would ask "Go on?")
  g.waitHuman();
  assert(g.board().join('/') === live && g.peek('g_n') === n, 'leaving the review restores the game');
  console.log(`[${model}] review ok over ${n} moves`);
}
