// Set up board through the keys: a1 a Hollow, b1 Hollow, c1 Solid, the centre emptied; Solid
// (you) to move has no move: "Pass: EXE"; the Psion plays d1 and the game is over (Hollow 4-0),
// not counted in the tally. Then the tally and help views. node t_setup.js [models]
'use strict';
const { Game, assert } = require('./lib.js');

function run(model) {
  const g = new Game(model);
  g.start();
  const log = (m) => console.log(`[${model}] ${m}`);
  g.waitHuman();
  g.key('MODE', 0.6);
  for (let k = 0; k < 7; k++) g.key('DOWN', 0.2);
  g.key('EXE', 0.8);
  assert(/Set up/.test(g.prompt()), 'set up prompt: ' + g.prompt());
  const sp = (n) => { for (let i = 0; i < n; i++) g.key('SPACE', 0.25); };
  sp(2); g.key('RIGHT', 0.2);              // a1 Hollow
  sp(2); g.key('RIGHT', 0.2);              // b1 Hollow
  sp(1);                                   // c1 Solid
  g.keys(['DOWN', 'DOWN', 'RIGHT'], 0.2);  // d3: Hollow -> empty
  sp(1); g.key('RIGHT', 0.2);              // e3: Solid -> empty
  sp(2); g.key('DOWN', 0.2);               // e4: Hollow -> empty
  sp(1); g.key('LEFT', 0.2);               // d4: Solid -> empty
  sp(2);
  const bd = g.board();
  assert(bd[0] === 'OOX.....' && bd[2] === '........' && bd[3] === '........', 'the set-up board\n' + bd.join('\n'));
  g.key('EXE', 0.8);                       // who moves: Solid
  g.key('EXE', 2.0);
  g.waitFor(() => /Pass: EXE/.test(g.prompt()), 20);
  assert(/Pass: EXE/.test(g.prompt()), 'you must pass: ' + g.prompt());
  assert(g.peek('g_setup') === 1, 'a set-up game');
  log('set up and pass prompt ok');
  g.key('EXE', 1.0);
  g.waitFor(() => g.over(), 60);
  const p = g.panel().join('|');
  assert(/You lose 4|Psion|H 4|lose/.test(p), 'the result: ' + p);
  assert(g.board()[0] === 'OOOO....', 'the Psion played d1: ' + g.board()[0]);
  log('result ok: ' + p);
  // the tally: no game counted (set-up)
  g.key('EXE', 0.8);                       // the menu
  for (let k = 0; k < 8; k++) g.key('DOWN', 0.2);
  g.key('EXE', 1.0);
  const t = g.panel().join('|');
  assert(/Tally W-D-L/.test(t), 'the tally: ' + t);
  for (let k = 0; k < 3; k++) g.key('DOWN', 0.3);
  const t2 = g.panel().join('|');
  assert(!/[1-9]-|-[1-9]/.test(t2.replace(/L\d/g, '')), 'nothing counted: ' + t2);
  g.key('EXE', 0.6);
  log('tally ok: ' + t + ' / ' + t2);
  // help: eight pages, DOWN to the last, EXE back
  g.key('MODE', 0.6);
  for (let k = 0; k < 13; k++) g.key('DOWN', 0.2);
  g.key('EXE', 0.8);
  const h1 = g.panel().join('|');
  for (let k = 0; k < 16; k++) g.key('DOWN', 0.2);
  const h2 = g.panel().join('|');
  assert(/Play a disc/.test(h1) && /Comms Link/.test(h2), 'help pages: ' + h1 + ' ... ' + h2);
  g.key('EXE', 0.6);
  log('help ok: ' + h1 + ' ... ' + h2);
  // the move list: the game's moves, two a line
  g.menu('Move list');
  const ml = g.panel().join('|');
  assert(/ 1 d1/.test(ml), 'the move list: ' + ml);
  g.key('EXE', 0.5);
  log('move list ok: ' + ml);
}

for (const model of (process.argv[2] || 'cm,lz64').split(',')) run(model);
