// Decision matches: variants of the engine against the default at the same level.
'use strict';
const { match } = require('./match.js');
const variants = {
  noTT: { tt: 0 },
  noKiller: { killer: false },
  tt64: { tt: 64 },
  tt256: { tt: 256 },
};
(async () => {
  const levels = (process.argv[3] || '4,6,7').split(',').map(Number);
  for (const name of (process.argv[2] || Object.keys(variants).join(',')).split(',')) {
    for (const lv of levels) {
      const t = Date.now();
      const r = await match({ a: { level: lv, opts: variants[name] }, b: { level: lv }, openings: +(process.argv[4] || 300), plies: 6 });
      console.log(`${name} L${lv}: ${r.pct.toFixed(1)}% of ${r.games}, margin ${r.margin.toFixed(2)} (${Date.now() - t} ms)`);
    }
  }
})();
