// The spec's memory check: REV starts on a blank CM, and with about 100 bytes too few it says
// how many it needs and stops cleanly (no OUT OF MEMORY, back to the menu after a key).
'use strict';
const fs = require('fs'), path = require('path'), { execSync } = require('child_process');
const { Machine } = require('../../tools/emu');
const ROOT = path.join(__dirname, '..', '..');
const out = path.join(ROOT, 'build', 'needs');
fs.mkdirSync(out, { recursive: true });
const Tools = path.join(ROOT, '..', '..', 'Tools');
function run(k, rom) {
  fs.writeFileSync(path.join(out, 'LM.opl'), `LM:\nLOCAL f%(${k})\nREV:\n`, 'latin1');
  fs.copyFileSync(path.join(ROOT, 'build', 'game', 'REV.opl'), path.join(out, 'REV.opl'));
  execSync(`python "${path.join(Tools, 'opl2opk.py')}" -f --target cm "${path.join(out, 'lm.opk')}" "${path.join(out, 'LM.opl')}" "${path.join(out, 'REV.opl')}"`, { stdio: 'pipe' });
  const m = new Machine({ rom, ram: 8 });
  m.boot();
  m.insertPack(path.join(out, 'lm.opk'), 0);
  m.insertPack(path.join(ROOT, 'build', 'game', 'REV.opk'), 1);
  m.runProc('LM', 'B');
  m.runSeconds(3);
  return m;
}
for (const rom of ['33-cm.rom', '24-cm.rom']) {
  let found = null;
  for (let k = 300; k < 800 && !found; k += 5) {
    const m = run(k, rom);
    const t = m.screenText(), mm = t.match(/NEEDS\s*(\d+)/);
    if (/MEMORY|ERROR/.test(t)) throw new Error(`${rom} k=${k}: ${t}`);
    if (mm && +mm[1] >= 95) {
      m.press('EXE', 3, 10); m.runSeconds(1);
      const back = m.screenText();
      found = { k, need: +mm[1], text: t.replace(/\n/g, '|'), back: back.replace(/\n/g, '|') };
      if (/NEEDS/.test(back) || /MEMORY|ERROR/.test(back)) throw new Error('did not stop cleanly: ' + back);
    }
  }
  if (!found) throw new Error(rom + ': never short');
  console.log(`${rom}: with ${found.need} bytes too few: "${found.text}"; after a key: "${found.back}"`);
}
