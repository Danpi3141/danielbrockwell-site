// Adjacent-level matches for a candidate budget table: node ref/tune/levels.js "300,600,1000,2000,5000,15000" openings
'use strict';
const { match } = require('../match.js');
const { LEVELS } = require('../engine.js');
(async () => {
  const b = (process.argv[2] || '300,450,750,1500,4500,15000').split(',').map(Number);
  const n = +(process.argv[3] || 500);
  const lv = (k) => k <= 2 ? { level: k } : { level: k, think: { nodes: b[k - 3] } };
  for (let k = 3; k <= 8; k++) {
    const r = await match({ a: lv(k), b: lv(k - 1), openings: n, plies: 8, oseed: 0x1EE7 + k });
    console.log(`L${k} (${k > 2 ? b[k - 3] : '-'}) v L${k - 1}: ${r.pct.toFixed(1)}% of ${r.games} ${r.pct >= 60 ? 'pass' : 'FAIL'}`);
  }
})();
