// The report's screens (docs/report.html), captured from the emulator: each one the display's
// characters and its 8 custom glyphs, on a two-line CM and a four-line LZ64.
//   node tools/report_screens.js  ->  build/report_screens.json
'use strict';
const fs = require('fs'), path = require('path');
const { Game, ROOT } = require('../tests/ui/lib.js');

const out = [];
function snap(g, model, name, caption) {
  const cols = g.m.lines === 4 ? 20 : 16;
  const cells = g.m.cells();
  const lines = [];
  for (let l = 0; l < g.m.lines; l++) lines.push(cells.slice(l * cols, (l + 1) * cols));
  out.push({ model, name, caption, lines, udg: g.m.udgs() });
  if (process.env.SHOT_DEBUG) console.log('snap', model, name, JSON.stringify(g.text()));
}
const at = (g, pred, s = 30) => g.waitFor(pred, s, 0.02);

for (const model of ['cm', 'lz64']) {
  const two = model === 'cm';
  const g = new Game(model);
  g.start({ title: false });
  g.m.runSeconds(2.0);
  snap(g, model, 'title', 'The title (the four discs drop into place)');
  g.waitFor(() => g.turn(), 10, 0.1);
  g.poke('st_level', 1); g.poke('st_book', 1);
  for (let i = 0; i < 5; i++) { g.waitFor(() => g.turn(), 30, 0.1); g.key('EXE', 0.8); }
  g.waitFor(() => g.turn(), 30, 0.1);
  g.m.runSeconds(0.3);
  // the cursor shown as the disc (its flash's "on" phase)
  at(g, () => g.peek('kv_ovv') !== 0, 3);
  snap(g, model, 'move', 'Your move: the cursor\'s square and the discs it would turn');
  const col = g.prompt().match(/: ([a-h])[1-6]/)[1];        // (a column that has a legal square)
  g.key(col.toUpperCase(), 0.4);
  snap(g, model, 'column', 'A column typed: its legal rows');
  g.key('ON', 0.4);
  // the Psion thinking, level 6
  g.poke('st_level', 6);
  g.waitFor(() => g.turn(), 10, 0.1);
  g.key('EXE', 0.1);
  at(g, () => /Depth [5-9]/.test(g.panel().join('|')), 60);
  snap(g, model, 'think', 'The Psion thinking: depth, best move so far, the bar');
  g.waitFor(() => g.turn(), 120, 0.1);
  g.poke('st_level', 1);
  // the coach
  g.poke('st_coach', 1);
  g.key('EXE', 0.1);
  at(g, () => /Coach [a-h][1-6]|Coach: good/.test(g.prompt()), 30); g.m.runSeconds(0.2);
  snap(g, model, 'coach', 'Coach on: its verdict on your move');
  g.poke('st_coach', 0);
  g.waitFor(() => g.turn(), 60, 0.1);
  // the menu and settings
  g.key('MODE', 0.6);
  snap(g, model, 'menu', 'The menu (MODE)');
  g.key('ON', 0.6);
  g.menu('Settings');
  for (let k = 0; k < 11; k++) g.key('DOWN', 0.15);       // (Demo H: Auto above it)
  g.m.runSeconds(0.3);
  snap(g, model, 'settings', 'Settings: Auto level and the demo\'s level for Hollow');
  g.key('ON', 0.6);
  // review: "Go on? EXE"
  g.menu('Review');
  g.key('LEFT', 0.6); g.key('LEFT', 0.6); g.key('EXE', 0.6);
  snap(g, model, 'review', 'Review, EXE on an earlier position');
  g.key('ON', 0.4); g.key('ON', 0.8);
  // export
  g.waitFor(() => g.turn(), 30, 0.1);
  g.menu('Export');
  at(g, () => /RVGAME/.test(g.text()), 5);
  snap(g, model, 'export', 'Export: the game to A:RVGAME1');
  g.key('EXE', 0.6);
  // help
  g.menu('Help');
  snap(g, model, 'help', 'Help, the first page');
  g.key('ON', 0.6);
  // the result
  g.playOut(600);
  g.m.runSeconds(1);
  snap(g, model, 'result', 'The result');
}
const f = path.join(ROOT, 'build', 'report_screens.json');
fs.writeFileSync(f, JSON.stringify(out));
console.log(out.length + ' screens -> ' + f);
for (const s of out) console.log(s.model, s.name.padEnd(9), s.lines.map(l => l.map(c => c < 8 ? '#' : String.fromCharCode(c)).join('')).join(' | '));
