// Speed: 20 middle-game positions (from engine games, 20-28 empty squares) searched at level 6
// with the OS's interrupts running, as in the game. Positions a second, per ROM given.
'use strict';
const { Harness } = require('./harness.js');
const { Engine, LEVELS, rnd } = require('../../ref/engine.js');
const st = { seed: 2026 };
const pos = [];
while (pos.length < 20) {
  const e = new Engine();
  let passes = 0;
  const stop = 20 + rnd(st) % 9;
  while (e.empties() > stop) {
    const l = e.legal();
    if (!l.length) { e.pass(); if (++passes === 2) break; continue; }
    passes = 0;
    e.make(e.think({ level: 2, seed: rnd(st) }).move);
  }
  if (e.legal().length) pos.push([Array.from(e.bd), e.side]);
}
for (const [rom, ram] of (process.argv[2] ? [[process.argv[2], +process.argv[3]]] : [['33-cm.rom', 8], ['46a-lz64.rom', 64]])) {
  const h = new Harness({ rom, ram, ints: true, build: false });
  let nodes = 0, cyc = 0;
  const L = LEVELS[6];
  for (const [bd, side] of pos) {
    h.setPos(bd, side);
    const a = h.think({ nodes: L.nodes, exact: L.exact, seed: 1 });
    nodes += a.nodes; cyc += a.cycles;
  }
  console.log(`${rom}: ${nodes} positions in ${(cyc / 921600).toFixed(1)} s: ${(nodes / (cyc / 921600)).toFixed(1)} positions a second (level 6, interrupts on)`);
}
