// Turn about (you change sides each new game; the Psion opens when you are Hollow), the score
// "Wins" (the winner takes the empty squares), and the Psion passing ("Psion pass").
'use strict';
const { Game, assert } = require('./lib.js');

// set up a1 a1v, b1 b1v, c1 c1v, the centre emptied; who moves (0 Solid, 1 Hollow)
function setup(g, a1, b1, c1, who) {
  g.menu('Set up');
  const sp = (n) => { for (let i = 0; i < n; i++) g.key('SPACE', 0.25); };
  sp(a1); g.key('RIGHT', 0.2); sp(b1); g.key('RIGHT', 0.2); sp(c1);
  g.keys(['DOWN', 'DOWN', 'RIGHT'], 0.2); sp(1); g.key('RIGHT', 0.2); sp(2); g.key('DOWN', 0.2); sp(1); g.key('LEFT', 0.2); sp(2);
  g.key('EXE', 0.8);
  if (who) g.key('DOWN', 0.3);
  g.key('EXE', 2.0);
}

for (const model of (process.argv[2] || 'cm,lz64').split(',')) {
  const g = new Game(model);
  g.start();
  g.poke('st_level', 1);
  // turn about
  g.poke('st_you', 2);
  g.menu('New game');
  const y1 = g.peek('g_you');
  g.menu('New game');
  const y2 = g.peek('g_you');
  assert(y1 !== y2, `turn about: you had ${y1} then ${y2}`);
  if (y2 === 2) { g.waitHuman(); assert(g.peek('g_n') === 1, 'the Psion opened'); }
  g.poke('st_you', 0);
  g.menu('New game');
  console.log(`[${model}] turn about ok (${y1}, ${y2})`);
  // the Psion passes: a1, b1 Solid, c1 Hollow, Hollow (the Psion) to move
  setup(g, 1, 1, 2, 1);
  g.waitFor(() => /Psion pass/.test(g.prompt()) || g.humanTurn(), 10, 0.05);
  const saw = /Psion pass/.test(g.prompt());
  g.waitHuman();
  assert(saw || g.peek('kv_lmv') === 255, 'Psion pass shown');
  assert(g.side() === 1, 'your turn after the pass');
  console.log(`[${model}] Psion pass ok`);
  // Wins: you (Solid) have no move, the Psion plays d1 and has 4, the 44 empties are its
  g.poke('st_final', 1);
  g.menu('New game');
  setup(g, 2, 2, 1, 0);
  g.waitFor(() => /Pass: EXE/.test(g.prompt()), 10);
  g.key('EXE', 1.5);
  g.waitFor(() => g.over(), 60);
  const p = g.panel().join('|');
  assert(/You lose 48/.test(p), 'the winner takes the empties: ' + p);
  console.log(`[${model}] Wins score ok: ${p}`);
}
