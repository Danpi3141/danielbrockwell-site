; =====================================================================
; Reversi 8x6 for the Psion Organiser II - shared definitions
; (system variables from the Technical Reference Manual: the same on
; the CM, XP, LA and LZ)
; =====================================================================

; ---- zero-page scratch (UTW_S0..S5). Clobbered by many OS calls; the
; engine keeps its busiest variables here while it runs.
T0      = $41
T1      = $42
T2      = $43
T3      = $44
T4      = $45
T5      = $46
T6      = $47
T7      = $48
T8      = $49
T9      = $4A
T10     = $4B
T11     = $4C

; ---- system variables and hardware
KBB_DLAY = $77                  ; key repeat delay (ticks)
KBB_REPT = $78                  ; key repeat rate (ticks)
KBB_STAT = $7B
TMB_MIN  = $20C9                ; clock minutes (then seconds at $20CA)
TMW_FRAM = $20CB                ; frame counter, +1 every 50 ms
TMW_TOUT = $007D                ; seconds left to auto switch-off
TMW_TCNT = $20CD                ; auto switch-off time in seconds
LCD_CTRL = $0180
LCD_DATA = $0181
FRC      = $0009                ; the processor's free-running counter (2 bytes)
MODEL    = $FFE8                ; model byte: 0 CM, 1 XP, 2 LA, 13/14/29/30 four-line
ALA_FREE = $2040                ; the first byte above the allocated cells

; ---- key codes
K_ON    = 1
K_MODE  = 2
K_UP    = 3
K_DOWN  = 4
K_LEFT  = 5
K_RIGHT = 6
K_DEL   = 8
K_EXE   = 13
K_SPACE = 32

; ---- error codes returned to the launcher in X
E_OK     = 0
E_NOPACK = 1                    ; game files not found
E_FILES  = 2                    ; a block is missing or damaged
E_RUN    = 3                    ; REVG run by itself (run REV): no REV above the array

; ---- sides
SOLID   = 1
HOLLOW  = 2

; ---- commands returned by the play screen and the menu (A), with B = argument
C_NONE  = 0
C_MOVE  = 1                     ; play square B (board index)
C_BACK  = 2                     ; take back
C_TIP   = 3
C_MENU  = 4
C_NEW   = 5                     ; new game
C_SWAP  = 6                     ; swap sides
C_LEVEL = 7                     ; settings from the level (B = first item)
C_PLAYERS = 8
C_SET   = 9                     ; settings
C_SETUP = 10
C_TALLY = 11
C_HELP  = 12
C_LEAVE = 13                    ; save and leave
C_PASS  = 14                    ; the side to move passes (it has no move)
C_SHOW  = 15                    ; the legal squares shown (OV_PANEL P_SHOW)
C_MARK  = 16                    ; L: the last move and its flips flash (OV_FX X_LAST)
C_LIST  = 17                    ; the move list (OV_HELP H_LIST)
C_REVIEW = 18                   ; the game review (OV_REVIEW)
C_EXPORT = 19                   ; the game to A:RVGAMEn (OV_EXPORT)
C_IMPORT = 20                   ; a game from A:RVGAMEn (OV_IMPORT)
C_HPASS = 21                    ; your turn with no move: "Pass: EXE" (OV_PANEL P_HPASS)
C_LEAVEQ = 22                   ; ON on your turn: "Leave? EXE" (OV_PANEL P_LEAVE)
C_LAST  = 22

; ---- screen driver entries (a jump table at DRV)
DV_INIT   = 0                   ; glyphs, clear, panel positions (kv_ppos)
DV_GLYPHS = 3                   ; send the glyphs again (after switching on)
DV_SQ     = 6                   ; A = square: show it (kv_ovs/kv_ovv may stand in for it)
DV_BOARD  = 9                   ; the whole board
DV_DONE   = 12                  ; leaving (the four-line mode is restored by the kernel)

; ---- OV_GAME entries
G_LOAD  = 0                     ; the saved game, or the defaults and a new game
G_SAVE  = 1
G_NEWG  = 2                     ; a new game
G_BACK  = 3                     ; take back
G_REPLAY = 4                    ; the position rebuilt from g_rec
G_MOVE  = 5                     ; kv_arg = square: the side to move plays it, shown, saved
G_REPSV = 6                     ; replayed and saved (after set-up, the handicap)
G_LEAVE = 7                     ; saved, then out of the game
G_MARK  = 8                     ; L: the last move's flips found again, then shown (OV_FX)
G_IMP   = 9                     ; an imported record replayed: saved, or OV_IMPORT I_BAD
I_BAD   = 1                     ; OV_IMPORT: "Bad game", then the game as saved (G_LOAD)
; ---- OV_BOOK entries
B_TURN  = 0                     ; the Psion's turn: A = the book's square, or 0 (search set up)
B_TIP   = 1                     ; the tip's search set up
B_PRE   = 2                     ; the search's start (e_pre), just before think_run's e_think
; ---- OV_SETUP entries
S_SETUP = 0
S_HCAP  = 1
S_NAMES = 2                     ; the players' names (the settings' Names line)
; ---- OV_FX entries
X_MOVE  = 0                     ; the move just made: the ripple, the new disc flashing
X_LAST  = 1                     ; the last move and its flips flash
; ---- OV_PANEL entries
P_DRAW  = 0
P_SHOW  = 1
P_PASS  = 2                     ; the Psion has no move: "Psion pass"
P_HPASS = 3                     ; your turn with no move: "Pass: EXE"
P_LEAVE = 4                     ; "Leave? EXE"
; ---- OV_HELP entries
H_HELP  = 0
H_TALLY = 1
H_LIST  = 2
; ---- OV_RESULT entries
R_SHOW  = 0                     ; the result (counted in the tally once), then the menu
