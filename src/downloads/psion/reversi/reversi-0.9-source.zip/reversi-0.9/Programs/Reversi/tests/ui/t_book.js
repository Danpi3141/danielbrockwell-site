// The opening book in the game: you play moves the book knows (or any, sometimes), the Psion's
// replies must be the book's (tools/book/walk.js walks it as OV_BOOK does) while the game is in
// it: its four openings when it is Solid, and at levels 3-4 only its first two replies.
// node t_book.js [model] [games]
'use strict';
const fs = require('fs'), path = require('path');
const { Game, assert, ROOT } = require('./lib.js');
const R = require('../../ref/rules.js');
const { bookReply } = require('../../tools/book/walk.js');
const bin = fs.readFileSync(path.join(ROOT, 'data', 'book.bin'));
const model = process.argv[2] || 'cm', games = +(process.argv[3] || 6);
let seed = 99;
const rand = n => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return (seed >> 8) % n; };
const g = new Game(model);
g.start();
let inBook = 0, checked = 0, openings = new Set();
for (let gi = 0; gi < games; gi++) {
  const level = [3, 5, 8, 4, 6, 7][gi % 6], you = gi % 2;          // you Solid, then Hollow
  g.poke('st_level', level); g.poke('st_you', you); g.poke('st_book', 0);
  g.menu('New game');
  const reps = level <= 4 ? 2 : 99;
  for (let ply = 0; ply < 14; ply++) {
    g.waitFor(() => g.humanTurn() || g.over(), 600, 0.2);
    if (g.over()) break;
    const rec = g.rec(), psion = g.peek('g_psion');
    // the Psion's last move: was it the book's?
    if (rec.length && ((rec.length - 1) % 2 === 0 ? 1 : 2) === psion) {
      const want = bookReply(bin, rec.slice(0, -1), psion, reps);
      const got = R.idxOf(rec[rec.length - 1]);
      if (Array.isArray(want)) { assert(want.includes(got), `opening ${R.name(got)} not one of the four`); openings.add(got); inBook++; }
      else if (want) { assert(got === want, `move ${rec.length}: the Psion played ${R.name(got)}, the book says ${R.name(want)} (L${level})`); inBook++; }
      checked++;
    }
    // your move: one the book follows (a group's alternative) if it can, else any legal one
    const bd = g.bytes('e_bd', 80), side = g.side();
    const legal = R.SQUARES.filter(s => bd[s] === 0 && R.flipsFor(bd, s, side).length);
    if (!legal.length) { g.key('EXE', 1); continue; }
    let mv = legal[rand(legal.length)];
    const known = legal.filter(s => bookReply(bin, [...rec, R.sqOf(s)], 3 - side, 99));
    if (known.length && rand(5)) mv = known[rand(known.length)];
    g.key('ABCDEFGH'[mv % 10 - 1], 0.2); g.key('UVWOPQ'[((mv / 10) | 0) - 1], 0.3); g.key('EXE', 0.8);
  }
}
console.log(`[${model}] ${checked} Psion moves checked, ${inBook} from the book, openings seen ${[...openings].map(R.name).join(' ')}`);
