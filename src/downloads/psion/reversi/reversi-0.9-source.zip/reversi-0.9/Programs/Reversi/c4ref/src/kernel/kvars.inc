; ---------------------------------------------------------------------
; Kernel variables: cleared at the start (kinit), not stored on the pack.
; The kernel's working ones live in C4G's copy of the bootstrap string (KH,
; from the build: 196 bytes below the array, the same on every ROM): C4G stays
; in RAM all game, and once the bootstrap has run nothing reads those bytes
; again. Only the string: C4G's code after the USR call must stay intact.
; ---------------------------------------------------------------------
kh_first = KH
kv_vptr   = KH+0                ; (2) ADDR(v%())
kv_sp     = KH+2                ; (2) the stack at entry
kv_base   = KH+4                ; (2) the array's address
kv_size   = KH+6                ; (2)
kv_dev    = KH+8                ; (1) 0 A:, 1 B:, 2 C:
kv_pkok   = KH+9                ; (1) the game's device is selected
kv_pa     = KH+10               ; (3) pack address
kv_dir    = KH+13               ; (6) where blocks C4B0 and C4B1 start
kv_t0     = KH+19               ; (2)
kv_t1     = KH+21               ; (2)
kv_t2     = KH+23               ; (2)
kv_t3     = KH+25               ; (2)
kv_fo     = KH+27               ; (2)
kv_res    = KH+29               ; (1) the overlay in slot A (0 none)
kv_drv    = KH+30               ; (1) the screen driver's unit (DRV2 or DRV4)
kv_rx     = KH+31               ; (2)
kv_rtgt   = KH+33               ; (2)
kv_four   = KH+35               ; (1) 1: four-line display (mode changed)
kv_omode  = KH+36               ; (1) the display mode we found
kv_left   = KH+37               ; (1)
kv_aidle  = KH+38               ; (2)
kv_afr    = KH+40               ; (1)
kv_seed   = KH+41               ; (2) random seed
kv_plines = KH+43               ; (1) panel lines (2 or 4)
kv_ppos   = KH+44               ; (4) their screen positions
kv_lb     = KH+48               ; (12) a line being built
kv_lp     = KH+60               ; (1)
kv_nbl    = KH+61               ; (1) (length of kv_nb)
kv_nb     = KH+62               ; (6) number digits
kv_arg    = KH+68               ; (1)
kv_col    = KH+69               ; (1)
kv_kstop  = KH+70               ; (1)
kv_flash  = KH+71               ; (1) fast blinks left (after a hint)
kv_xsc    = KH+72               ; (1) the last solved score (+128), 0 none
g_chosen  = KH+73               ; (1) the chosen column for the side to move
g_cv      = KH+74               ; (1) the coach's last verdict for you (1 win, 2 draw, 3 loss; 0 none)
kh_end    = KH+75

; the rest are in the array
kv_first:
; ---- the saved part: settings, then the game, as the save file's record:
; its length, a tag and version, the bytes, a checksum
sv_rec: rmb  1
sv_tag: rmb  2
sv_first:
st_level: rmb 1                 ; 1-8, 9 Auto
st_you: rmb  1                  ; 0 first, 1 second, 2 alternate
st_coach: rmb 1                 ; 0 off, 1 on
st_hints: rmb 1                 ; 0 allowed, 1 not
st_back: rmb 1                  ; 0 allowed, 1 not
st_keep: rmb 1                  ; finished games: 0 ask before a new game, 1 export all, 2 off
st_pace: rmb 1                  ; 0 natural, 1 fast
st_sound: rmb 1                 ; 0 all, 1 ticks only, 2 off
st_digits: rmb 1                ; 0 off, 1 the digit keys drop
st_who: rmb  1                  ; two players: 0 alternate, 1 loser starts, 2 winner starts
st_swap: rmb 1                  ; 0 off, 1 on
st_timer: rmb 1                 ; 0 off, 1-3: 10, 20, 30 s a move
st_match: rmb 1                 ; 0 single game, 1-3: first to 3, 5, 10
st_clock: rmb 1                 ; 0 none, 1-4: 1, 3, 5, 10 minutes a side
st_dlv1: rmb 1                  ; demo levels for Solid and Hollow
st_dlv2: rmb 1
st_last:
g_mode: rmb  1
g_psion: rmb 1
g_alt:  rmb  1
g_alv:  rmb  1                  ; the Auto level
g_over: rmb  1
g_res:  rmb  1
g_score: rmb 2                  ; match: games won by player 1, 2
g_p1:   rmb  1                  ; two players: the side player 1 has (1 or 2)
g_swq:  rmb  1                  ; the swap rule was offered this game
g_clk:  rmb  4                  ; seconds left: Solid, Hollow
g_names: rmb 14                 ; two players' names: length (0: none) and 6 letters each
g_n:    rmb  1
g_rec:  rmb  21                 ; the moves, two a byte (src/screens/krec.asm)
g_hv:   rmb  11                 ; history: 2 bits a ply, the value for the side to move there
                                ; when the book or a solved search knew it (0 not known, 1 win,
                                ; 2 draw, 3 loss); for the review (src/screens/khist.asm)
sv_end:
sv_chk: rmb  1
        include "../engine/evars.inc"
kv_end:
