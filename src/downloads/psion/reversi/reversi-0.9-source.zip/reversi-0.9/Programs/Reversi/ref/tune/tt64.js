// The search table at 64 entries against 128, 2 x openings games at each level.
'use strict';
const { match } = require('../match.js');
(async () => {
  for (const lv of (process.argv[2] || '5,6,7,8').split(',').map(Number)) {
    const t = Date.now();
    const r = await match({ a: { level: lv, opts: { tt: 64 } }, b: { level: lv }, openings: +(process.argv[3] || 1000), plies: 8, oseed: 0x7777 });
    console.log(`tt64 v tt128 L${lv}: ${r.pct.toFixed(1)}% of ${r.games}, margin ${r.margin.toFixed(2)} (${Date.now() - t} ms)`);
  }
})();
