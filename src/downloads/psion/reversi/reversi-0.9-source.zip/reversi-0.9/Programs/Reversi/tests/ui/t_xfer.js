// Export and import (stretch goal 8). Export: "No moves" with nothing to write; a game to
// A:RVGAME1, then A:RVGAME2 ("Saved RVGAME1"), its record the squares ("d2c4..."; on the CM also
// found in RAM as written); a set-up game with its position first. Import: the files in turn
// (DOWN, UP), EXE loads one: the record replayed into the game; a set-up record gives the
// set-up position; capitals and other characters between the squares are read too (a file made
// by an OPL program, as a PC would send through the Comms Link); a move that is not legal gives
// "Bad game" and the game as it was.
//   node tests/ui/t_xfer.js [models cm,lz64]
'use strict';
const fs = require('fs'), path = require('path'), { execSync } = require('child_process');
const { Game, assert, ROOT } = require('./lib.js');
const R = require('../../ref/rules.js');

const Tools = path.join(ROOT, '..', '..', 'Tools');
const out = path.join(ROOT, 'build', 'xfer');
fs.mkdirSync(out, { recursive: true });
const sqName = (s) => 'abcdefgh'[s & 7] + ((s >> 3) + 1);

// a pack with MKF: makes A:RVGAME<n> holding one record (as the Comms Link would)
function mkPack(n, text) {
  const f = path.join(out, 'MKF.opl');
  fs.writeFileSync(f, `MKF:\nCREATE "A:RVGAME${n}",A,L$\nA.L$="${text}"\nAPPEND\nCLOSE\n`, 'latin1');
  const p = path.join(out, 'mkf.opk');
  execSync(`python "${path.join(Tools, 'opl2opk.py')}" -f --target cm "${p}" "${f}"`, { stdio: 'pipe' });
  return p;
}
function findText(g, text) {
  const b = Buffer.from(text, 'latin1');
  for (let a = 0x2000; a < 0x8000 - b.length; a++) {
    let ok = true;
    for (let i = 0; i < b.length && ok; i++) if (g.m.peek(a + i) !== b[i]) ok = false;
    if (ok) return a;
  }
  return -1;
}

for (const model of (process.argv[2] || 'cm,lz64').split(',')) {
  const log = m => console.log(`[${model}] ${m}`);
  const g = new Game(model);
  g.start(); g.poke('st_level', 1);
  // nothing to write yet
  g.menu('Export');
  assert(g.waitFor(() => /No moves/.test(g.text()), 3), 'no moves: ' + g.text());
  g.key('EXE', 0.6);
  // a game of a few moves, exported twice
  for (let i = 0; i < 3; i++) { g.waitHuman(); g.key('EXE', 0.6); }
  g.waitHuman();
  const rec1 = g.rec().slice();
  g.menu('Export');
  assert(g.waitFor(() => /Saved/.test(g.text()) && /RVGAME1/.test(g.text()), 3), 'saved 1: ' + g.text());
  g.key('EXE', 0.6);
  const text1 = rec1.map(sqName).join('');
  if (model === 'cm') assert(findText(g, text1) >= 0, 'the record in RAM: ' + text1);
  g.waitHuman(); g.key('EXE', 0.6); g.waitHuman();
  const rec2 = g.rec().slice();
  g.menu('Export');
  assert(g.waitFor(() => /Saved/.test(g.text()) && /RVGAME2/.test(g.text()), 3), 'saved 2: ' + g.text());
  g.key('EXE', 0.6);
  log(`exported ${text1} and ${rec2.length} moves`);
  // import: RVGAME1, DOWN to 2, UP back to 1, EXE
  g.menu('New game');
  g.waitHuman();
  g.menu('Import');
  assert(g.waitFor(() => g.panel().some(l => /RVGAME1/.test(l)), 3), 'the first file: ' + g.text());
  g.key('DOWN', 0.6);
  assert(g.panel().some(l => /RVGAME2/.test(l)), 'DOWN: the second: ' + g.text());
  g.key('DOWN', 0.6);
  assert(g.panel().some(l => /RVGAME2/.test(l)), 'DOWN again: still the second: ' + g.text());
  g.key('UP', 0.6);
  assert(g.panel().some(l => /RVGAME1/.test(l)), 'UP: the first: ' + g.text());
  g.key('EXE', 1.5);
  g.waitFor(() => g.peek('kv_res') === 5 || g.humanTurn(), 30);
  assert(g.rec().slice(0, rec1.length).join(',') === rec1.join(','), 'imported 1: ' + g.rec() + ' want ' + rec1);   // (then the Psion may reply)
  log('imported RVGAME1');
  // a file from an OPL program: capitals, spaces, numbering ("1. D2 c4")
  const b = R.newBoard(); const m1 = R.legalMoves(b, 1)[0]; R.play(b, m1, 1); const m2 = R.legalMoves(b, 2)[1];
  const t3 = `1. ${R.name(m1).toUpperCase()} ${R.name(m2)}`;
  g.menu('Quit'); g.m.runSeconds(1); g.toTop(); g.m.insertPack(mkPack(3, t3), 1); g.m.runProc('MKF', 'C'); g.m.runSeconds(2);
  g.start(); g.menu('Import');
  g.key('DOWN', 0.6); g.key('DOWN', 0.6);
  assert(g.panel().some(l => /RVGAME3/.test(l)), 'the third: ' + g.text());
  g.key('EXE', 1.5);
  g.waitFor(() => g.peek('kv_res') === 5 || g.humanTurn(), 30);
  assert(g.rec().slice(0, 2).map(s => R.idxOf(s)).join(',') === [m1, m2].join(','), `"${t3}": ` + g.rec());
  log(`imported "${t3}"`);
  // a bad game: the game as it was
  const before = g.rec().join(',');
  g.menu('Quit'); g.m.runSeconds(1); g.toTop(); g.m.insertPack(mkPack(4, 'd2 a1'), 1); g.m.runProc('MKF', 'C'); g.m.runSeconds(2);
  g.start(); g.menu('Import');
  for (let k = 0; k < 3; k++) g.key('DOWN', 0.6);
  assert(g.panel().some(l => /RVGAME4/.test(l)), 'the fourth: ' + g.text());
  g.key('EXE', 0.8);
  assert(g.waitFor(() => /Bad game/.test(g.text()), 5), 'bad game: ' + g.text());
  g.key('EXE', 1.5);
  g.waitFor(() => g.peek('kv_res') === 5 || g.humanTurn(), 30);
  assert(g.rec().join(',') === before, 'the game as it was: ' + g.rec() + ' want ' + before);
  log('bad game ok');
  // a set-up game: exported with its position, imported back
  g.menu('New game');
  g.menu('Set up');
  g.key('SPACE', 0.2); g.key('RIGHT', 0.2); g.key('SPACE', 0.2); g.key('SPACE', 0.2);
  g.key('EXE', 0.8); g.key('EXE', 2.0);                      // Solid moves first
  g.waitHuman();
  const start = g.bytes('g_start', 12).join(','), side = g.peek('g_sside');
  g.menu('Export');
  assert(g.waitFor(() => /Saved/.test(g.text()) && /RVGAME5/.test(g.text()), 3), 'saved 5: ' + g.text());
  g.key('EXE', 0.6);
  if (model === 'cm') assert(findText(g, 'XO----') >= 0, 'the set-up record in RAM');
  g.menu('New game'); g.waitHuman();
  g.menu('Import');
  for (let k = 0; k < 4; k++) g.key('DOWN', 0.6);
  assert(g.panel().some(l => /RVGAME5/.test(l)), 'the fifth: ' + g.text());
  g.key('EXE', 1.5);
  g.waitFor(() => g.peek('kv_res') === 5 || g.humanTurn(), 30);
  assert(g.peek('g_setup') === 1 && g.bytes('g_start', 12).join(',') === start && g.peek('g_sside') === side,
    'the set-up position imported: ' + g.bytes('g_start', 12) + ' want ' + start);
  log('set-up game ok');
}
