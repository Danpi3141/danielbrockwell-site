; =====================================================================
; OV_PLAY: the side to move's turn on the keys. Returns a command (A) and
; its argument (B).
; A move is a column letter A-H then a row 1-6 (U V W O P Q need no SHIFT;
; the digits work too), or the cursor keys and EXE. The cursor only rests
; on legal squares (it starts on the first from the last move on) and
; flashes the mover's disc; the prompt shows the discs it would turn. S
; shows every legal square, T asks for a tip, DEL takes back, MODE opens
; the menu, ON/CLEAR cancels a half-typed square or asks whether to leave
; (OV_PANEL). With no move: C_HPASS (OV_PANEL's "Pass: EXE").
; =====================================================================
        include "../defs.inc"

        jmp  pl_start

pl_start:
        clr  pl_col
        jsr  first              ; no legal square: a pass ("Pass: EXE": OV_PANEL)
        bne  .some
        ldaa #C_HPASS
        rts
.some:  stab pl_cur              ; the first legal square from the last move on, or the tip's
        ldab kv_tip
        beq  .loop
        stab pl_cur
        clr  kv_tip
.loop:  jsr  prompt
        jsr  pl_key             ; B = key (the cursor flashing meanwhile)
        cmpb #K_EXE
        bne  .n1
.play:  ldaa #C_MOVE
        ldab pl_cur
        rts
.n1:    cmpb #'A'               ; a column
        blo  .n2
        cmpb #'H'
        bhi  .n2
        subb #'A'-11            ; its top square: row 1
        stab pl_t
.cl:    jsr  legal
        bne  .cf
        ldab pl_t
        addb #10
        stab pl_t
        cmpb #69
        blo  .cl
        ldab pl_t               ; none: "c: illegal"
        jsr  illegal
        bra  .loop
.cf:    ldaa pl_t
        staa pl_cur
        bsr  colof
        staa pl_col
        bra  .loop
.n2:    jsr  rowkey             ; a row: A = 1-6, or 0
        beq  .n3
        ldab #10
        mul
        ldaa pl_col             ; in the typed column, or the cursor's
        bne  .tc
        pshb
        ldaa pl_cur
        bsr  colof
        pulb
.tc:    aba
        tab
        stab pl_t
        jsr  legal
        bne  .ok
        ldab pl_t
        jsr  illegal
        clr  pl_col
        bra  .loop
.ok:    ldab pl_t
        stab pl_cur
        clr  pl_col
        tst  st_confirm         ; Confirm moves off: played at once
        bne  .play
        bra  .loop
.n3:    cmpb #K_LEFT
        bne  .n4
        ldaa #-1
        bra  .step
.n4:    cmpb #K_RIGHT
        bne  .n5
        ldaa #1
.step:  staa pl_d               ; the previous or next legal square, in reading order
        ldab pl_cur
.st:    addb pl_d
        cmpb #11
        bhs  .s1
        ldab #68
.s1:    cmpb #68
        bls  .s2
        ldab #11
.s2:    stab pl_t
        jsr  legal
        ldab pl_t
        tsta
        beq  .st
        stab pl_cur
        clr  pl_col
        bra  .loop
.n5:    cmpb #K_UP
        bne  .n6
        ldaa #-10
        bra  .vert
.n6:    cmpb #K_DOWN
        bne  .n7
        ldaa #10
.vert:  staa pl_d               ; the nearest legal square on the next row up or down
        ldaa pl_cur             ; that has one: the cursor's column, then out from it
        bsr  colof
        staa pl_c               ; its column 1-8
        stab pl_t               ; its row * 10
.vr:    ldab pl_t
        addb pl_d
        stab pl_t
        cmpb #10
        blo  .vx
        cmpb #60
        bhi  .vx
        clr  pl_n
.vo:    ldab pl_c
        addb pl_n
        cmpb #8
        bhi  .v2
        bsr  .try
        bne  .vf
.v2:    ldab pl_c
        subb pl_n
        beq  .v3
        bmi  .v3
        bsr  .try
        bne  .vf
.v3:    inc  pl_n
        ldaa pl_n
        cmpa #8
        bne  .vo
        bra  .vr
.vf:    stab pl_cur
        clr  pl_col
.vx:    jmp  .loop
; B = a column: Z clear and B = its square on row pl_t if legal there
.try:   addb pl_t
        stab pl_u
        jsr  legal
        ldab pl_u
        tsta
        rts
.n7:    ldaa #C_MARK            ; L: the last move flashes (OV_FX), then back
        cmpb #'L'
        beq  .back
        ldaa #C_SHOW            ; S: the legal squares shown (OV_PANEL), then back
        cmpb #'S'               ; to this square
        bne  .n8
.back:  ldab pl_cur
        stab kv_tip
        rts
.n8:    ldaa #C_TIP
        cmpb #'T'
        beq  .r
        ldaa #C_BACK
        cmpb #K_DEL
        beq  .r
        ldaa #C_MENU
        cmpb #K_MODE
        beq  .r
        cmpb #K_ON
        bne  .bz
        tst  pl_col             ; a half-typed square: cancelled
        beq  .lv
        clr  pl_col
        bra  .loop
.lv:    ldaa #C_LEAVEQ          ; leave? (OV_PANEL asks), then back to this square
        jmp  .back
.bz:    jsr  buzz
        bra  .loop
.r:     rts

; A = a square index: A = its column 1-8, B = its row * 10
colof:  clrb
.l:     cmpa #10
        blo  .x
        suba #10
        addb #10
        bra  .l
.x:     rts

; B = key: A = 1-6 for a row key (U V W O P Q or a digit), else 0 (Z
; set); B kept
rowkey: ldx  #rk_tab
        clra
.l:     inca
        cmpb 0,x
        beq  .y
        cmpb 6,x
        beq  .y
        inx
        cmpa #6
        bne  .l
        clra
.y:     tsta
        rts
rk_tab: fcc  "UVWOPQ123456"

; B = a square index: A = flips there for the side to move (Z set: not legal)
legal:  ldx  #e_bd               ; (any index below 80: the border is not empty)
        abx
        tst  0,x
        bne  .no
        ldaa e_side             ; (e_flips sets e_me/e_op for this side)
        jsr  e_flips
        tba
        rts
.no:    clra
        rts

; the first legal square at or after the last move in reading order (a1
; on after h6; from a1 with no last move): B = it, Z set if there is none
first:  ldab kv_lmv
        beq  .a1
        cmpb #$FF
        bne  .s
.a1:    ldab #11
.s:     ldaa #58                ; (every square once)
        staa pl_d
.l:     stab pl_t
        bsr  legal
        bne  .y
        ldab pl_t
        incb
        cmpb #69
        blo  .n
        ldab #11
.n:     dec  pl_d
        bne  .l
        clrb
        rts
.y:     ldab pl_t
        rts

; B = a square: a buzz and "c4: illegal" (just "c: illegal" past the board)
illegal:pshb
        jsr  lb_clr
        pulb
        cmpb #69
        blo  .sq
.c:     subb #10                ; (a column with no legal square: its letter)
        cmpb #69
        bhs  .c
        subb #10
.cl:    subb #10
        bcc  .cl
        addb #'a'+9
        tba
        jsr  lb_ch
        bra  .t
.sq:    jsr  lb_sq
.t:     jsr  lb_s
        fcl  ": illegal"
        jsr  pn_last
        jsr  buzz
        ldaa #20
        jmp  pause

; the prompt: "You: d2 +4" (two players "S: d2 +4", "H: d2 +4"): the
; cursor's square and the discs it would turn; with a column typed and no
; row yet, "d? 236": its legal rows
prompt: jsr  lb_clr
        ldab pl_col
        beq  .who
        tba
        adda #'a'-1
        jsr  lb_ch
        ldaa #'?'
        jsr  lb_ch
        jsr  lb_sp
        clr  pl_n               ; rows 1-6
.r:     inc  pl_n
        ldaa pl_n
        cmpa #7
        beq  .p
        ldab #10
        mul
        addb pl_col
        bsr  legal
        beq  .r
        ldaa pl_n
        adda #'0'
        jsr  lb_ch
        bra  .r
.who:   ldaa e_side
        tst  g_psion
        beq  .two
        jsr  lb_s
        fcl  "You"
        bra  .c
.two:   ldab #'S'
        cmpa #SOLID
        beq  .s
        ldab #'H'
.s:     tba
        jsr  lb_ch
.c:     jsr  lb_s
        fcl  ": "
        ldab pl_cur
        jsr  lb_sq
        jsr  lb_s
        fcl  " +"
        ldab pl_cur
        bsr  legal
        tab
        clra
        jsr  lb_num
.p:     jmp  pn_last

; a key, the cursor flashing the mover's disc about three times a second
; (for about 30 s; then it rests on the disc so the Organiser can switch
; itself off). B = the key.
pl_key: ldaa pl_cur
        staa kv_ovs
        ldaa #200
        staa pl_n
.f:     ldaa e_side             ; disc, then empty
        ldab pl_n
        andb #1
        beq  .o
        clra
.o:     staa kv_ovv
        ldaa kv_ovs
        jsr  DRV+DV_SQ
        ldaa #3
        jsr  key_wait
        tstb
        bne  .k
        ldaa pl_n               ; four lines, hints on: they flash slowly
        anda #7
        bne  .nh
        tst  kv_hon
        beq  .nh
        tst  kv_four
        beq  .nh
        com  kv_hph
        jsr  DRV+DV_BOARD
.nh:    dec  pl_n
        bne  .f
        ldaa e_side             ; resting: the disc shown, no time limit
        staa kv_ovv
        ldaa kv_ovs
        jsr  DRV+DV_SQ
        clra
        jsr  key_wait
.k:     pshb
        clr  kv_ovs
        ldaa pl_cur
        jsr  DRV+DV_SQ
        pulb
        rts

pl_cur: fcb  0
pl_col: fcb  0
pl_t:   fcb  0
pl_u:   fcb  0
pl_c:   fcb  0
pl_d:   fcb  0
pl_n:   fcb  0
pl_p:   fdb  0
