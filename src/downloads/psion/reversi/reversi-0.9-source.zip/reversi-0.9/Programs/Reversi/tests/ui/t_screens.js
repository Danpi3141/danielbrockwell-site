// The play screen and the thinking display (20 Nov): at your turn the cursor starts on the first
// legal square from the Psion's last move on (reading order, round from h6 to a1) and the prompt
// gives the discs it would turn; while the Psion thinks, the line above the bar says
// "Depth n" (rising) and, once a depth is done, the best move so far, and the bar's next block
// flashes.
//   node tests/ui/t_screens.js [models cm,lz64]
'use strict';
const { Game, assert } = require('./lib.js');
const R = require('../../ref/rules.js');

for (const model of (process.argv[2] || 'cm,lz64').split(',')) {
  const log = m => console.log(`[${model}] ${m}`);
  const g = new Game(model);
  g.start(); g.poke('st_level', 5); g.poke('st_book', 1);
  let starts = 0, depths = new Set(), bests = 0, flashes = 0;
  for (let t = 0; t < 6; t++) {
    g.waitFor(() => g.turn(), 300, 0.1);
    if (g.over() || /Pass/.test(g.prompt())) break;
    // the cursor's start
    const bd = g.bytes('e_bd', 80), side = g.side(), lmv = g.peek('kv_lmv');
    const legal = R.SQUARES.filter(s => bd[s] === 0 && R.flipsFor(bd, s, side).length);
    let s = (lmv && lmv !== 0xFF) ? lmv : 11;
    for (let k = 0; k < 58 && !legal.includes(s); k++) s = s >= 68 ? 11 : s + 1;
    const m = g.prompt().match(/: ([a-h][1-6]) \+(\d+)/);
    assert(m && R.parse(m[1]) === s, `the cursor starts on ${R.name(s)} (last move ${lmv ? R.name(lmv) : '-'}): ${g.prompt()}`);
    assert(+m[2] === R.flipsFor(bd, s, side).length, `its flips: ${g.prompt()}`);
    starts++;
    // your move, then the Psion's thinking
    g.key('EXE', 0.1);
    g.waitFor(() => g.prompt().includes('['), 10, 0.02);
    let lastBar = null;
    while (g.prompt().includes('[')) {
      g.m.runSeconds(0.2);
      const p = g.panel(), bar = p[p.length - 1], above = p[p.length - 2];
      const d = above.match(/^Depth (\d+)/);
      if (d) { depths.add(+d[1]); if (/ [a-h][1-6]\s*$/.test(above)) bests++; }
      if (lastBar && bar.includes('[') && lastBar !== bar) flashes++;
      lastBar = bar;
    }
  }
  assert(starts >= 4, 'turns checked: ' + starts);
  assert(depths.size >= 3, 'depths shown: ' + [...depths]);
  assert(bests > 0, 'a best move shown');
  assert(flashes > 3, 'the bar flashing: ' + flashes);
  log(`cursor start and flips ok (${starts} turns); depths shown ${[...depths].sort((a, b) => a - b).join(',')}, a best move ${bests} times, the bar changed ${flashes} times`);
}
