; =====================================================================
; OV_HELP: H_HELP six short pages of help; H_TALLY wins, draws and
; losses at each level (A:REVTAL). DOWN and UP turn the pages (as many
; lines as the panel has), EXE, ON/CLEAR or MODE go back.
; =====================================================================
        include "../defs.inc"

        jmp  hp_help
        jmp  hp_tally
        jmp  hp_list

hp_help:
        ldx  #hp_line
        stx  hp_fn
        ldaa #32
        bra  view

; H_LIST (stretch goal 6, the move list): the game's moves, two a line:
; " 1 d2  2 c4"
hp_list:ldx  #hp_mline
        stx  hp_fn
        ldaa g_n
        inca
        lsra
        bne  view
        jsr  pn_msg             ; (no moves yet)
        fcl  "No moves"
        ldaa #20
        jmp  pause

; A = line: moves 2A+1 and 2A+2
hp_mline:
        asla
        bsr  .mv
        ldaa hp_k
        inca
        cmpa g_n
        bhs  .x
        psha
        jsr  lb_sp
        pula
.mv:    staa hp_k               ; move A+1 (if there is one): its number and square
        inca
        tab
        clra
        cmpb #10
        bhs  .n
        pshb
        jsr  lb_sp
        pulb
.n:     clra
        jsr  lb_num
        jsr  lb_sp
        ldab hp_k
        ldx  #g_rec
        abx
        ldab 0,x
        jsr  e_idxof
        jmp  lb_sq
.x:     rts

hp_tally:
        clr  kv_pkok            ; the tally, or none
        ldx  #hp_buf+1
.z:     clr  0,x
        inx
        cpx  #hp_buf+26
        bne  .z
        ldx  #hp_fn_t
        os   FL$OPEN
        bcs  .sh
        tab
        os   FL$RECT
        clra
        clrb
        os   FL$SETP
        ldd  #1
        os   FL$RSET
        ldx  #hp_buf
        os   FL$READ
.sh:    clr  kv_pkok
        ldx  #hp_tline
        stx  hp_fn
        ldaa #9
; A = lines, hp_fn = a routine that builds line A in kv_lb
view:   staa hp_n
        clr  hp_top
.d:     clr  hp_ln
.ln:    jsr  lb_clr
        ldaa hp_top
        adda hp_ln
        cmpa hp_n
        bhs  .put
        ldx  hp_fn
        jsr  0,x
.put:   ldaa hp_ln
        jsr  lb_put
        inc  hp_ln
        ldaa hp_ln
        cmpa kv_plines
        bne  .ln
.k:     clra
        jsr  key_wait
        ldaa hp_top
        cmpb #K_DOWN
        bne  .u
        adda kv_plines
        cmpa hp_n
        bhs  .k
        bra  .go
.u:     cmpb #K_UP
        bne  .x
        suba kv_plines
        bcs  .k
.go:    staa hp_top
        bra  .d
.x:     cmpb #K_EXE
        beq  .r
        cmpb #K_ON
        beq  .r
        cmpb #K_MODE
        bne  .k
.r:     jmp  pn_clear

; A = line: the help text's line A
hp_line:ldx  #hp_text
.l:     tsta
        beq  .x
        ldab 0,x
        incb
        abx
        deca
        bra  .l
.x:     jmp  lb_fcl

; A = line: the tally's: a heading, then "L3 12-1-4" for each level
hp_tline:
        tsta
        bne  .lv
        ldx  #g_names           ; player 1's name, or "Tally"
        tst  0,x
        bne  .nm
        jsr  lb_s
        fcl  "Tally"
        bra  .w
.nm:    jsr  lb_fcl
.w:     ldaa #5                 ; (at most 5 letters of it) then " W-D-L"
        cmpa kv_lp
        bhs  .s
        staa kv_lp
.s:     jsr  lb_at
        jsr  lb_s
        fcl  " W-D-L"
        rts
.lv:    psha
        ldaa #'L'
        jsr  lb_ch
        pula
        psha
        adda #'0'
        jsr  lb_ch
        jsr  lb_sp
        pula
        deca
        ldab #3
        mul
        ldx  #hp_buf+2
        abx
        stx  hp_p
        bsr  .n
        bsr  .dash
        bsr  .n
        bsr  .dash
.n:     ldx  hp_p
        ldab 0,x
        inx
        stx  hp_p
        clra
        jmp  lb_num
.dash:  ldaa #'-'
        jmp  lb_ch

hp_fn_t:fcl  "A:REVTAL"
hp_text:
        fcl  "Play a disc"
        fcl  "so it traps"
        fcl  "a line of"
        fcl  "the other's"
        fcl  "discs: they"
        fcl  "all turn."
        fcl  "Solid first"
        fcl  "Most wins."
        fcl  "Keys: A-H a"
        fcl  "column, UVW"
        fcl  "OPQ rows."
        fcl  "EXE plays."
        fcl  "Arrows move"
        fcl  "S shows all"
        fcl  "T a tip"
        fcl  "DEL undoes"
        fcl  "No move:"
        fcl  "pass (EXE)."
        fcl  "Neither can"
        fcl  "move: end."
        fcl  "Level 1-8:"
        fcl  "how deep."
        fcl  "Score Wins:"
        fcl  "+ the gaps"
        fcl  "Coach On:"
        fcl  "after your"
        fcl  "move, names"
        fcl  "a better +n"
        fcl  "Export and"
        fcl  "Import use"
        fcl  "A:RVGAMEn"
        fcl  "Comms Link."
hp_fn:  fdb  0
hp_n:   fcb  0
hp_top: fcb  0
hp_ln:  fcb  0
hp_p:   fdb  0
hp_k:   fcb  0
hp_buf: rmb  26
