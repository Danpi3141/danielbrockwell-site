# Reversi 8x6 for the Psion Organiser II

Reversi on a board 8 squares wide and 6 high, in 6303 machine code, for every Organiser II from the 8K CM to the LZ64, built from *Reversi 8 by 6 for the Psion Organiser II: design spec* (19 Nov 2026).
One 16K Datapak serves every model: the launcher reads the model byte and loads the screen code for a two-line or a four-line display. Everything else is shared, so the game plays the same, at the same strength, on every model.

(The project grew out of the Connect 4 build: its tools, emulator rig and kernel patterns were copied into this folder; Connect 4 itself is untouched. `c4ref/` keeps the copied Connect 4 sources for reference.)

## Status (20 Nov 2026)

- **The core game is complete** and tested in the emulator on the CM, XP, LA, LZ and LZ64; it starts and survives random keys on all 29 Organiser ROMs the emulator has (*Stress test*, below).
- **Both screens:** two-line (the whole board in the 8 glyphs, squares of 2 by 2 dots) and four-line (one character a column, two stacked discs of 5 by 3 dots, ABCDEFGH underneath).
- **Modes:** one player (levels 1-8), two players, demo.
- **Play:** typing a square (a column letter, then the row on U V W O P Q without SHIFT, or the digits), the cursor keys, EXE; Confirm moves on or off; passes ("Pass: EXE", "Psion pass"); take back; tip; show the legal squares; swap sides; set up the board; save and resume after every move; the tally for each level; six pages of help.
- **The engine** is 6303 machine code, matched position for position against a JavaScript reference engine (`ref/engine.js`): the same move, score, depth and position count on every search tested.
- **The opening book** was made by deep analysis on the PC (`tools/book`), as the spec plans: there is no published result for 8 by 6.
- **Stretch goals:** 9 of the 10 (below): all but region parity, which measured no gain. The coach and export/import were added on 20 Nov, after the memory and pack savings (*Where the bytes go*) made room; the book gave up 242 bytes to fit them, and then came back in full in a denser format (*The opening book*).
- **Not done:** the checks that need a real Organiser (*Still to check*).

## Stretch goals

| | Goal | Where |
|---|---|---|
| 1 | Flip ripple: the flipped discs turn a ring at a time, outward from the new disc (then it flashes twice) | OV_FX |
| 2 | Last-move marker: L flashes the last move and the discs it flipped | OV_FX |
| 3 | Player names: up to 7 letters (Settings, Names); in the four-line panel, the two-player result and the tally's heading | OV_SET, OV_PANEL, OV_HELP |
| 4 | Standing hints (Settings, Hints): a dot on each legal square on two lines, a slow flash on four | the drivers, OV_PLAY |
| 5 | Corner handicap (Settings, Corners 0-4): the weaker side (you, or Hollow in a two-player game) starts with that many corners | OV_SETUP |
| 6 | Move list and game review (menu): the moves two a line; the positions in turn (LEFT, RIGHT, UP start, DOWN end); EXE on an earlier position asks "Go on? EXE" and plays on from there (the moves after it are gone) | OV_HELP, OV_REVIEW |
| 7 | Coach (Settings, Coach): after your move in a one-player game, "Coach c4 +3" (the move a deeper search preferred, about 3 discs better) or "Coach: good" | OV_COACH (OV_FX calls it) |
| 8 | Export and import (menu): the game as a line of text in A:RVGAME1-99 ("d2c4e5...", a set-up position first), for the Comms Link to send to a PC; Import reads one back (from Export, or sent from a PC), every move checked | OV_EXPORT, OV_IMPORT |
| 9 | Title drop: the four starting discs fall into place on the title | start-up code |

Not done: 10 region parity: it costs RAM on the CM and (measured) does not win games.

**The coach** runs two searches at a fixed depth (3 plies; to the end of the game in the last 7 empty squares), every root move scored exactly: the best move from the position before yours, then the reply to your move a ply shallower, which is the score your move had in the first. The difference is shown in discs: exact in the endgame, otherwise the evaluation's units scaled by the stage (`ref/tune/coachcal.js`: from self-play, one unit is about 0.42 discs with more than 30 empty squares, 0.18 with 13-30, 0.10 below; these are rough, so "about"). It takes about 2.5 s, at most about 6 s. With one legal move it says nothing.

**Export and import.** Export writes the game to the first free A:RVGAME1..A:RVGAME99 as one record of text, the moves as squares ("d2c4e5f6...", the usual transcript form; passes are found again by replaying), with a set-up or handicap game's position first (48 characters, a1 to h1 then a2 ... with `-` empty, `X` Solid, `O` Hollow, a space, X or O to move first, a space). The Comms Link's own Transmit sends such a file to a PC as a line of text, and Receive brings one back. Import shows the files there in turn (UP/DOWN, EXE loads one): it takes every square it finds, in capitals or not, whatever is between them (so "1. d2 c4" works, or one move a line), replays it with every move checked, and keeps it (saved) or says "Bad game" and keeps the game as it was. Export makes a file only while at least 256 bytes would stay free between the files and the game, so REV can always start again.

## Build

```bash
python tools/build.py
```

This writes `build/game/REV.opk` (a 16K Datapak image: REV, REVG and REVK, below) and `build/game/budget.txt` (the RAM and pack budget). `python tools/build.py --psion` also writes `psion/`: the pack's files as .OB3 procedures, with RPLOAD's list, for sending to a Datapak through a Comms Link.

The engine's tables (`src/engine/etab.inc`) come from the reference engine: `node tools/gen_tables.js`. The book (`data/book.bin`) is made by

```bash
node tools/book/gen_book.js --nodes 12000000 --depth 4
```

(on all cores; its analyses are cached in `data/book_cache.json`, so it can be stopped and run again) and checked by `node tools/book/check_book.js`. `node tools/book/encode.js` re-encodes `data/book.bin` from `data/book.json` without the analysis.

## The opening book

Format 3 (20 Nov, `tools/book/encode.js`) is a bit stream that stores moves as indexes among the legal moves. A group of the opponent's moves is one bit when every legal move is there (most groups), or a bit for each legal move. Each reply is its index among the Psion's legal moves, usually 2-3 bits. A position with positions beneath has a bit for it, and a 12-bit jump over them when they are longer than 32 bits. The full book, every opponent move for four moves both ways round (1,298 positions), takes 896 bytes. In format 2 it took 2,701; the 16K pack had held a trimmed 818 positions in 1,731 bytes.

The walk (OV_WALK, handed the tree by OV_BOOK) plays the line on the engine's board to know the legal moves. It keeps the game's position in the screen driver's area meanwhile, and reads past moves that are not the game's by their jumps, or by reading through them. That makes a lookup slower than before, so a book move now shows after at least half a second (it was a fixed half-second pause):

| Jump past groups longer than | Book | Pack used | Slowest book move |
|---|---|---|---|
| 24 bits | 1,010 bytes | 16,182 | 0.76 s |
| **32 bits (used)** | **896 bytes** | **16,068 (16,128 since the speed tuning)** | **0.90 s** |
| 48 bits | 830 bytes | 16,002 | 1.17 s |

(The slowest from counting the work for every position in the book on the PC, `tools/book/walk.js`, and timing the worst line in the emulator. Most book moves show after 0.58 s.) Measured with `ref/tune/bookgain.js`: the full book against the trimmed one is worth up to about 1 point in 100 games.

## Review, auto level and the demo's levels (20 Nov)

- **Play on from Review.** EXE at the last position goes back to the game, as before; on an earlier one it asks "Go on? EXE", and EXE makes that position the game (the record cut there, replayed and saved; any other key stays in the review). As with take back, a finished game played on is counted again when it ends.
- **Auto level** (Settings, Auto): after a one-player game that counts in the tally, the level goes up one for a win (to 8 at most) and down one for a loss (to 1 at least), for the next game.
- **Demo H** (Settings): in a demo Hollow searches at this level, Solid at Level (0: both at Level).

Room: the two settings needed two bytes in the save record (version 3: an older save starts a new game), made by moving the coach's seven working bytes from REVG's code to REV's (they are not saved); the names editor moved from OV_SET to OV_SETUP (S_NAMES), leaving Settings room for its two lines. No RAM; 140 bytes of pack. Tested by `tests/ui/t_options.js` (and `t_review.js`, `t_paths.js`, which now leave the review with ON/CLEAR).

## The play screen and the thinking display (20 Nov)

At your turn the prompt shows the discs the cursor's square would turn ("You: d2 +4"; with two players "S:" or "H:", since "Hollow: d2 +12" would not fit the panel's 11 characters), after a column letter that column's legal rows ("d? 236"), and the cursor starts on the first legal square from the Psion's last move on. While the Psion thinks, the line above the bar shows the depth being searched and the best move so far, and the bar's next block flashes at every poll, so a long search is visibly alive (at level 8 the first block used to take 12 s). The bar's arithmetic became a running count against a tenth of the level's positions worked out by OV_BOOK, which made OV_THINK 16 bytes smaller even with the new line; "Pass: EXE" and "Leave? EXE" moved from OV_PLAY to OV_PANEL to make room there. RAM: 4 bytes (two command-table entries); pack: 72 bytes. (A cursor start on the nearest legal square by distance was tried: 47 bytes over the slot, so 47 bytes of RAM; the reading-order rule fits.) Tested by `tests/ui/t_screens.js` and `t_keys.js`.

## Speed tuning (20 Nov)

The engine's hot paths were rewritten with play unchanged: the same move, score, depth and position count on every search (the 500-position suite gives the same 752,427 positions, and every other engine test is identical). Profiled with `tests/engine/t_profile.js`: in the middle game most of the time was in the direction checks (e_dirs), walking runs of enemy discs (e_walk) and counting moves (e_cmob); in exact endings, the position key (e_hash) and the move picker (e_next).
- Each direction check now steps straight onto the enemy disc next to the square (ABX), and the positive directions walk with ABX keeping the enemy's colour in a register (8 cycles a step, was 18); a run that is not bracketed returns at once. Flipping and counting keep their old code, so the flip stack's order is the same.
- The search saves a move's undo information (square score, flip stack) only after the move proves legal, most tries being illegal; e_make sets the sides inline, after its "square taken" check.
- e_next skips taken squares in a tight loop of its own instead of handing each back to the search loop.
- The key's four-square loop is unrolled; the move counter tests a square with LDAB (4 cycles), not TST (6).

| | Before | After |
|---|---|---|
| Middle game (level 6) | 149.3 positions a second | 162.9 (+9%) |
| Exact endings (12 empty) | 210.7 a second | 251.0 (+19%) |
| Speed test (`t_speed.js`, LZ64, interrupts on) | 147.5 | 159.9 (+8%) |
| Engine (RAM) | 2,885 bytes | 2,953 (+68) |
| Pack | 16,068 | 16,128 (+60) |

Unrolling the direction walks fully (a fixed offset for every step) would be faster still, but costs about 300 bytes of RAM, well over the budget of 100.

## Where the bytes go

**The pack** (16,384 bytes; the same on every model): 16,340 used, 44 free.

| File | Bytes | What |
|---|---|---|
| REV | 99 of code | the launcher: checks FREE, then calls REVG ("NEEDS n BYTES" if short) |
| REVG | 228 of code | declares the array m%(), pokes in the bootstrap (a 76-byte string) and runs it |
| REVK | 15,930 of data | the kernel and engine (4,035) with the start-up code (364), the fixer (217) and its exception list (142); then block 0, the overlays and screen drivers (10,280, each with its fix-up list); then block 1, the book (896) |

(Both launchers are stored without their OPL source: the Organiser runs only the object code.)

**RAM** (the array, the same on every model): 5,214 bytes.

| Part | Bytes |
|---|---|
| Engine code and tables | 2,953 |
| Kernel code | 1,082 |
| Variables in the array (the board) | 80 |
| Screen driver | 319 |
| Slot A (one overlay at a time; or, during a search, its working space of 825 bytes with OV_THINK, 273, at the top) | 780 |

REV needs 5,544 bytes free (5,694 before the save files exist), counted from inside REV. A blank CM has 6,506 free, so (measured through REV, `tests/m1/needs.js`) 704 bytes are spare before the first save and about 709 after it (68 fewer since the speed tuning, 4 since the play screen); REV refuses 162 bytes before the game would really stop fitting (150 of them kept for the save files).

The other kernel variables (204 bytes) are kept outside the array, in the launchers' translated code that never runs again once the game has started (`src/kernel/kvars.inc`):
- **KH:** REVG's code before its USR call, just below the array: the working variables and the save record.
- **KR:** REV's code before its call of REVG, just above the array: the engine's variables other than the board.

REVG's code from USR on, and REV's two bytes after the call, run when the game ends; they stay intact. The build finds both holes in the translated code. The start-up code checks that REV is there: REVG run on its own stops with "REV ERROR 3". `tests/ui/t_hidden.js` checks the layout on all 29 ROMs.

**The savings of 20 Nov** (from 16,266 bytes of pack and a 5,554-byte array):

| Change | Pack | RAM |
|---|---|---|
| Launchers stored without their OPL source | −413 | |
| Book format 2: 2 bytes a position, with a jump count only past more than 8 positions (the walk no slower: 24-49 ms) | −794 (the book −851, OV_BOOK +57) | |
| One data file (REVK) instead of three | −107 | |
| The kernel relocated by decoding its instructions (the fixer, run once: 237 ms at the start) instead of a list of 750 fix-ups | −99 | |
| The levels 1-2 move picker in OV_THINK (in its 87 spare bytes); the search's start (e_pre) run from OV_BOOK | +43 | −138 |
| Rarely used commands moved from the kernel into overlays (new game and handicap, set up, leave, L, applying the players, Psion pass, the tip's check; the clock seed into the start-up code, the result tunes into OV_RESULT) | −13 | −180 |
| Variables kept in the launchers' code (above) | +11 | −129 |
| The start-up code finds the blocks from where the bootstrap stopped reading (no second FL$BOPN), and checks that REV is there | −28 | |
| A key in a demo while the Psion thinks: no longer flushed, so it stops the demo (an old bug: such a key was lost) | +7 | +7 |
| **Total** | **−1,393** | **−440** |

Not done, on purpose: the overlays could be relocated by decoding too (their lists would go from 579 bytes to about 180), but the decoder would then have to stay resident, about 50 bytes more than today's loader: pack bought with RAM.

## Run

In Jape: **Select OPK file** → `build/game/REV.opk` → **Create** → **Slot B**, then **Prog → Run → B:REV**.
On a real Organiser, burn the image to a 16K or 32K Datapak (`docs/hardware-test-plan.md`).

## Keys

| On your move | |
|---|---|
| A to H, then 1 to 6 | the square: the letter puts the cursor on that column's topmost legal square and the prompt lists that column's legal rows ("d? 236"), the row (U V W O P Q, no SHIFT; the digits work too) on that square ("c4: illegal" and a buzz if it isn't legal). With Confirm moves Off the row plays it at once |
| LEFT, RIGHT | the previous or next legal square in reading order |
| UP, DOWN | the nearest legal square on the next row up or down that has one |
| EXE | play the square under the cursor (the cursor only rests on legal squares; it starts on the first one from the Psion's last move on, in reading order). The prompt shows the square and the discs it would turn: "You: d2 +4" (two players "S: d2 +4", "H: d2 +4") |
| S | every legal square shows your disc, flashing, for a second |
| T | a tip: a 300-position search (about 2 s); the cursor goes to its square |
| L | the last move and the discs it flipped flash |
| DEL | take back (your move and the Psion's reply; one move with two players) |
| MODE | the menu |
| ON/CLEAR | cancel a half-typed square; otherwise "Leave? EXE" |
| with no move | "Pass: EXE": only EXE (pass) and MODE (the menu) |
| while the Psion thinks | the bar fills a block for each tenth of the level's positions, the next block flashing; above it "Depth 7  e5", the depth being searched and the best move of the last depth finished (in an exact ending the depth is the empty squares). ON/CLEAR plays its best move so far; other keys are ignored (in a demo any key stops it) |

In menus: UP/DOWN move, a letter jumps to the next item starting with it, EXE takes it, ON/CLEAR goes back. In the settings LEFT/RIGHT change a value.

The menu: New game, Take back, Tip, Swap sides, Level, Players, Settings, Set up, Tally, Move list, Review, Export, Import, Help, Quit.
The settings: Level 1-8, Play (One, Two, Demo), You (Solid, Hollow, Turns), Conf (confirm moves), Book, Sound, Score (Disc: count the discs; Wins: the winner takes the empty squares), Corners (the handicap, 0-4), Hints, Coach, Auto (auto level: after a counted one-player game the level goes up one for a win, down one for a loss), Demo H (in a demo, Hollow's level; 0: the same as Level, which Solid plays at), Names, Reset tally.

## Measured

| | |
|---|---|
| Rules | the spec's move counts to depth 9 in the reference (2,523,782), and on the 6303 to depth 7 (51,246; the spec asks for 6) |
| Engine v reference | the same move, score, depth, position count and random seed on every search: the spec's 500-position suite (levels 1-7), 200 exact endings at 8 empty squares (also equal to a plain minimax to the end), level 8 searches; the board unchanged after every search; marker bytes round the working space untouched |
| Speed | 160 positions a second with the OS's interrupts running (the spec expected 135; 147.5 before the speed tuning of 20 Nov), the same on every model; exact endings about 250 a second (210 before) |
| Strength (matches) | each level against the one below, 1,000 games from 500 openings, sides swapped (`ref/tune/levels.js`): 3 v 2 76.8%, 4 v 3 65.0%, 5 v 4 61.9%, 6 v 5 61.1%, 7 v 6 60.1%, 8 v 7 61.5%; 2 v 1 85.8% (200 games) |
| Discs given away | every move made with 14 or fewer empty squares solved exactly, by level (`ref/strength.js`, about 2,200 moves a level): 3.28, 2.55, 1.70, 1.37, 1.25, 0.89, 0.65, 0.29 a move for levels 1-8: falling at every level, as the spec asks (with the spec's budgets it was 3.28, 2.55, 1.56, 1.48, 1.11, 0.94, 0.65, 0.42) |
| Evaluation | the spec's numbers tuned by self-play (two rounds of SPSA, `ref/tune/spsa.js`): the first round scored 57-59% against the spec's values at levels 3, 5 and 7, the second 51-52% against the first (2,000 games each) |
| Search table | 64 entries play as well as 128 (49.5-50.1% at levels 5-7, 2,000 games each): 256 bytes are used, not the spec's 512 |
| Region parity | 49.3% and 49.9% against the plain engine (levels 4 and 6, 2,000 games each): not worth its RAM; left out |
| Opening book | 1,298 positions, 896 bytes (format 3, `tools/book/encode.js`): every opponent move for four moves, the Psion Solid or Hollow; each reply from a 12-million-position search on the PC; 2,596 lines replay legally both ways round; in the game the Psion's book moves are the walk's. A book move shows after 0.58 s, the slowest about 0.9 s |
| RAM | an array of 5,214 bytes on every model; REV needs 5,544 free (5,694 before the save files exist). A blank CM has 6,506 free (6,540 on ROM 2.4); measured through REV (`tests/m1/needs.js`), 704 bytes are spare before the first save and about 709 after it (A:REVSAV takes 109, A:REVTAL 38). Before the savings of 20 Nov: an array of 5,554 and, measured the same way, 364 and 370 (the earlier figures here, 627 and 483, left out REV's own 110 or so bytes) |
| Pack | 16,340 of 16,384 bytes (16,266 before the savings of 20 Nov, 14,873 after them, 16,311 with the coach and export/import and a trimmed book, then the dense book, the speed tuning, the play screen and the review, auto level and demo options) |
| Start | the fixer relocates the kernel in 237 ms (it decodes the instructions) |
| Waits | level 3 about 2 s, 4 about 4 s, 5 about 7.5 s, 6 about 18.5 s, 7 about 50 s, 8 about 2 min 30 s; the tip 2 s (before the speed tuning: 6 about 20 s, 7 about 55 s, 8 about 2 min 45 s). Exact endings at 12 empty squares (level 8): about 15,500 positions on average, 33,000 the most seen |

## Where it differs from the spec

- **Level budgets.** The spec's 300, 450, 750, 1,500, 4,500 and 15,000 positions left levels 4, 6 and 7 under the 60% each must score against the one below. As the spec says, they were moved apart until each passed: 300, 600, 1,200, 3,000, 8,000, 24,000. So the top levels think longer than the spec's table (level 8 about 2 min 45 s, not 1 min 50 s).
- **Weights.** Tuned by self-play from the spec's starting values (the spec plans this): corner 19, X square -23, mobility 4-6 by stage (`ref/engine.js`).
- **Search table and working space.** 64 entries (256 bytes), as strong as 128; the working space is 825 bytes: table 256, flip stack 244 (the most that 12 plies of 14 flips and the exact ending's sorted lists can need), 13 frames of 19 bytes, killers, the search's variables.
- **Two-line result.** The spec's "You lose -12" is 12 characters and the panel has 11, so a loss reads "You lose 12". Two players: "Solid +4" (or the winner's name).
- **Menu letters.** A letter jumps to the next item starting with it (several share one: Take back, Tip, Tally; Settings, Set up, Swap sides); EXE takes it.
- **The demo** goes on to a new game 3 s after each result, until a key.
- **Book header.** Three trees (the Psion Solid having opened d2, having opened c3; the Psion Hollow) in a 7-byte header, then bit streams (*The opening book*); OV_BOOK picks the Psion's own opening at random.
- **Engine size.** 2,953 bytes of code and tables resident, against the spec's 2,650; the start-of-game routines, the search's start and the levels 1-2 move picker live in the overlays that need them.
- **RAM margin.** About 709 bytes spare on a blank CM once the save files exist, just more than the spec's about 700 (370 before the savings of 20 Nov, measured the same way; 781 before the speed tuning).
- **Coach and export/import RAM.** The spec plans no memory for them; they take 26 bytes: `ov_resume` (an overlay that gives slot A up to a search is read in again after it), two command-table entries, and 10 bytes so that the engine leaves its table alone at a fixed depth (where the root's list is kept: deeper than 3 plies the two collided; levels 1-2 never got there). The save record has the Coach setting (version 2: an older save starts a new game).

## Tests

`node tests/run_all.js [--quick]` runs them all. The main ones:

| | |
|---|---|
| `node ref/rules.js 9` | the spec's move counts |
| `node tests/engine/t_perft.js 7` | the move counts on the 6303, and the board as it was after them |
| `node tests/engine/t_state.js` | random games: board, counts, square score, evaluation, key, move count v the reference after every move |
| `node tests/engine/t_search.js 60 1,2,3,4,5,6,7,8` | searches v the reference (move, score, depth, positions, seed), the board unchanged |
| `node tests/engine/t_suite.js 500` | the spec's 500-position suite |
| `node tests/engine/t_endings.js 200 8` | 200 exact endings v the reference and a plain minimax |
| `node tests/engine/t_markers.js` | marker bytes round the working space |
| `node tests/engine/t_ints.js 36-la.rom 32` | the engine with the OS's interrupts running |
| `node tests/engine/t_speed.js` | positions a second at level 6 |
| `node tests/engine/t_profile.js` | where the search's time goes, by routine |
| `node tools/book/check_book.js` | every book line replays legally, both ways round |
| `node tests/ui/t_features.js cm,lz64` | save and resume, take back, tip, illegal squares, confirm off, swap sides, two players, demo |
| `node tests/ui/t_setup.js`, `t_misc.js`, `t_more.js` | set up and passing (yours and the Psion's), results (win, draw, Wins scoring), tally, help, move list, show, leave and resume, names |
| `node tests/ui/t_keys.js` | the cursor keys and typing against a model, the flips and the column's rows in the prompt |
| `node tests/ui/t_options.js` | play on from Review, auto level (a loss and a win), the demo's level for each side |
| `node tests/ui/t_screens.js` | the cursor's start, the thinking display (depth, best move, the flashing bar) |
| `node tests/ui/t_glyphs.js` | the screen against the board, both displays |
| `node tests/ui/t_extras.js`, `t_hints.js`, `t_review.js` | the stretch goals |
| `node tests/ui/t_book.js cm 8` | the Psion's book moves in the game |
| `node tests/ui/t_think.js`, `t_autooff.js` | ON/CLEAR while it thinks; switching off |
| `node tests/ui/t_game.js lz64 8` | a whole game at a level, the board v the record |
| `node tests/ui/t_stress.js all 10 s2` | random keys on all 29 ROMs |
| `node tests/m1/needs.js`, `savesize.js`, `lowmem.js` | the CM's RAM: what the game needs and that REV's check covers it, the save files, the shortfall message |
| `node tests/engine/t_fixed.js` | fixed-depth searches (levels 1-2, the coach) v the reference, to the end of the game too |
| `node tests/ui/t_coach.js cm,lz64 3` | the coach's verdict after every move of whole games v the reference's |
| `node tests/ui/t_xfer.js cm,lz64` | export (the record's text), import (stepping through files, capitals and separators, a set-up game, a bad game) |
| `node tests/ui/t_hidden.js all` | the variables kept in the launchers' code: the code that must stay is intact where the build says, leaving is clean, starting again resumes; on all 29 ROMs |
| `REV_COVER=build/cover node tests/ui/...`, then `node tests/coverage.js build/cover` | the instructions the tests ran |

## Stress test

`tests/ui/t_stress.js` presses random keys (weighted to the game's keys, with bursts, long holds, SHIFT, idle spells long enough to switch off, and spells of mostly EXE so games finish) on every Organiser ROM the emulator has: CM 2.4, 2.6, 3.3, 3.3 French, 3.6 French; XP 2.4, 2.6, 3.1; LA 3.0 (HP), 3.3, 3.4 German, 3.6, 3.6 French, 3.6 German, 3.7 multilingual; LZ 4.2, 4.4, 4.5, 4.5 Italian/Spanish, 4.5 Swedish/Danish, 4.6, 4.6 Italian/Spanish; LZ64 4.3, 4.4, 4.5, 4.6a, 4.6b, 4.6 Italian/Spanish, 4.6 Swedish/Danish. At every key wait it checks that the kernel and engine code are unchanged, that the board is the move record replayed (from a set-up position too, passes found), that the stack is where it was, and that a result really has no move left; a game left and started again must resume the same record. The feature, set-up, review, stretch-goal and "more" tests also ran on all 29 ROMs.

The latest run (seed 2, 10 emulated minutes a ROM, the build with the coach, export/import, the dense book, the speed tuning, the new play screen and thinking display, and the review, auto level and demo options): 21,027 random keys, 5,936 key waits checked, every ROM passed; `t_hidden.js` and `t_xfer.js` also passed on all 29. After the savings of 20 Nov, before those two: 20,831 keys, 6,093 key waits, every ROM passed. The run before the savings: 20,940 keys, 6,020 key waits, every ROM passed. (The German LA 3.6 first stopped on the harness, not the game: random keys typed as the game quit had taken the OS into its program editor, whose German menu and "J/N" question the harness did not know; with that fixed it passed the same seed.) An earlier run on a build without the move list, review and title drop passed too (20,309 keys).

Bugs these tests found, all fixed in this build: a search stopped inside a passed frame left the wrong side to move (the board then drifted from the record); the zero-page copies of the mover's colour were clobbered by OS calls between moves; a start-of-game routine wrote into the search's scratch, which lies over slot A; a held ON key counted twice after stopping a search; the Organiser could switch itself off during a long search; the demo stopped at its first result; a key pressed in a demo while the Psion thought was flushed, so it did not stop the demo (found on 20 Nov); a search at a fixed depth deeper than 3 plies (the coach's, near the end) let the table overwrite the list of root moves (found on 20 Nov by `t_coach.js`; levels 1-2 never search that deep).

## Still to check (need a real Organiser)

See `docs/hardware-test-plan.md`: loading from a real Datapak on the CM and the LZ64 (and whether a Datapak written on the LZ64 reads on the CM), the two-line glyphs' eighth dot row and the gap between the lines, the display chip's timing, how the flashes and the ripple look, and the real speed.

## About this repository

One of the Psion Organiser II projects on Forgejo (`Daniel/Psion-*`). The build and test scripts expect the PsionII workspace layout:

```
PsionII/
  Emulator/          Jape, Jaap Scherphuis's emulator, with its ROM images (not in any repo:
                     https://www.jaapsch.net/psion/jape/jape.htm)
  Tools/             Daniel/Psion-Tools (opltran, opl2opk, RPBOOT/RPLOAD, ...)
  Programs/NAME/     this repository
```

`build/` is not committed: the build scripts recreate it.

Also kept out of the repository (large, downloaded or third-party):

- `data/tune_l5.jsonl` - the 59 MB of self-play positions from the second SPSA tuning round (`ref/tune/`).
