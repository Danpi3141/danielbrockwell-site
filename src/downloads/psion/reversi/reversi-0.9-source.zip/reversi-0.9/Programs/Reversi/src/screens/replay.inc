; =====================================================================
; rp_to: B = moves: the position after that many of g_rec, from the start
; or the set-up position (g_setup), passes found on the way; kv_lmv,
; kv_lfl, kv_lwho the last move. C set if a move is not a square or not
; legal (an imported game). The board is not drawn. For OV_REVIEW,
; OV_COACH and OV_EXPORT; the engine's start and set-up (eapi) with it.
; =====================================================================
rp_to:  stab rp_n
        jsr  eng_reset
        clr  kv_lmv
        tst  g_setup
        beq  .go
        clr  rp_i               ; the set-up position: 2 bits a square, a1 first
.s:     ldab rp_i
        lsrb
        lsrb
        ldx  #g_start
        abx
        ldaa 0,x
        ldab rp_i
        andb #3
.sh:    tstb
        beq  .v
        asla
        asla
        decb
        bra  .sh
.v:     rola
        rola
        rola
        anda #3
        cmpa #3
        bne  .p
        clra
.p:     psha
        ldab rp_i
        jsr  e_idxof
        ldx  #e_bd
        abx
        pula
        staa 0,x
        inc  rp_i
        ldaa rp_i
        cmpa #48
        bne  .s
        ldaa g_sside
        staa e_side
        jsr  eng_setup
.go:    clr  rp_i
.l:     ldab rp_i
        cmpb rp_n
        beq  .d
        ldx  #g_rec
        abx
        ldab 0,x
        cmpb #48
        bhs  .bad               ; not a square
        jsr  e_idxof
        stab rp_sq
        jsr  status             ; a pass first if the side to move has no move
        cmpa #1
        bne  .m
        jsr  e_pass
.m:     ldx  #BUF
        stx  e_fsp
        ldaa e_side
        staa kv_lwho
        ldab rp_sq
        stab kv_lmv
        jsr  e_make
        stab kv_lfl
        tstb
        beq  .bad               ; not legal
        inc  rp_i
        bra  .l
.d:     clc
        rts
.bad:   sec
        rts

rp_n:   fcb  0
rp_i:   fcb  0
rp_sq:  fcb  0

        include "../engine/eapi.asm"
