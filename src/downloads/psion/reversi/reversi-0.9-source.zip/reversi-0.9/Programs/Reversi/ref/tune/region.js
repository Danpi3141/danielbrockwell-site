// Region parity (the spec's stretch goal 10) against the plain engine, 2 x openings games a level.
'use strict';
const { match } = require('../match.js');
(async () => {
  for (const lv of (process.argv[2] || '4,6').split(',').map(Number)) {
    const r = await match({ a: { level: lv, opts: { region: 1 } }, b: { level: lv }, openings: +(process.argv[3] || 1000), plies: 8, oseed: 0x4242 });
    console.log(`region parity v plain L${lv}: ${r.pct.toFixed(1)}% of ${r.games}, margin ${r.margin.toFixed(2)}`);
  }
})();
