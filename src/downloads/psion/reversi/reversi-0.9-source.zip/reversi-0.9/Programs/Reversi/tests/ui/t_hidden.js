// The variables kept outside the array (src/kernel/kvars.inc), in the launchers' code that never
// runs again once the game has started: KH in REVG's code before its USR call (below the array),
// KR in REV's code before its call of REVG (above it). Checked on every ROM: the launchers' code
// that does run again (REVG from USR on, REV's 84 7B after the call) is in RAM where the build
// says, intact, after some play; leaving goes back to the OS cleanly (no "REV ERROR", no OPL
// error), and starting again resumes the same game.
//   node tests/ui/t_hidden.js [all | rom,rom...]
'use strict';
const fs = require('fs'), path = require('path');
const { Game, ROMS, assert, ROOT } = require('./lib.js');

const bdir = path.join(ROOT, 'build', 'game');
const meta = JSON.parse(fs.readFileSync(path.join(bdir, 'build.json'), 'utf8'));
const opk = fs.readFileSync(path.join(bdir, 'REV.opk'));
function qcode(name) {
  const i = opk.indexOf(Buffer.from(name.padEnd(8)));
  const b = i + 9 + 4, ol = opk[b] << 8 | opk[b + 1];
  const obj = opk.slice(b + 2, b + 2 + ol), ql = obj[2] << 8 | obj[3];
  return obj.slice(obj.length - ql);
}
const qg = qcode('REVG'), qr = qcode('REV');
const keepG = qg.slice(meta.kh_len);                       // REVG from USR on
const keepR = qr.slice(meta.kr_len - (meta.kr - meta.total) + (meta.kr - meta.total), meta.kr_len + 2);
const arg = process.argv[2] || 'all';
const roms = arg === 'all' ? Object.keys(ROMS) : arg.split(',');
let bad = 0;
for (const rom of roms) {
  try {
    const g = new Game(rom);
    g.start(); g.poke('st_level', 1);
    const check = (when) => {
      g.sync();
      const ga = g.base + meta.kh + meta.kh_len;
      const got = g.m.read(ga, keepG.length);
      assert(got.every((v, i) => v === keepG[i]), `${when}: REVG's code from USR on at ${meta.kh + meta.kh_len}: ` + Buffer.from(got).toString('hex'));
      const ra = g.base + meta.kr + meta.kr_len;
      const gr = g.m.read(ra, 2);
      assert(gr[0] === 0x84 && gr[1] === 0x7B, `${when}: REV's 84 7B at ${meta.kr + meta.kr_len}: ` + gr.map(v => v.toString(16)).join(' '));
    };
    check('at the start');
    g.play('d2'); g.waitHuman(120); g.play(g.prompt().match(/: ([a-h][1-6])/)[1]); g.waitHuman(120);
    check('after play');
    const rec = g.rec().join(',');
    g.menu('Quit');
    assert(g.waitFor(() => !/REV ERROR|ERROR|FEHLER|ERREUR|ERRORE|FEL/.test(g.text()) && g.findBase() >= 0, 2, 0.1), 'after leaving: ' + g.text());
    g.m.runSeconds(1.5);
    assert(!/ERROR|FEHLER|ERREUR|ERRORE|FEL/.test(g.text()), 'an error after leaving: ' + g.text());
    g.start(); g.waitHuman(60);
    assert(g.rec().join(',') === rec, 'resumed: ' + g.rec().join(',') + ' (was ' + rec + ')');
    check('after starting again');
    console.log(`${rom.padEnd(14)} ok   (moves ${rec})`);
  } catch (e) {
    bad++;
    console.log(`${rom.padEnd(14)} FAIL ${e.message.split('\n').slice(0, 3).join(' | ')}`);
  }
}
console.log(bad ? `${bad} ROMs FAILED` : `all ${roms.length} ROMs ok`);
process.exit(bad ? 1 : 0);
