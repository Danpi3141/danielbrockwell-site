// Fixed-depth searches (levels 1-2 use depths 1-2; the coach 3, or to the end in the last 7 empty
// squares) on the 6303 against the reference: the score must be the same (the move one of the
// equal best: ties are broken at random), at depths 1-7 and depths reaching the end of the game.
// node t_fixed.js [positions 40]
'use strict';
const { Harness } = require('./harness.js');
const { Engine, rnd } = require('../../ref/engine.js');
const h = new Harness();
const npos = +(process.argv[2] || 40);
const st = { seed: 777 };
const pos = [];
while (pos.length < npos) {
  const e = new Engine();
  const stop = 20 + (rnd(st) % 28);
  let passes = 0;
  for (let ply = 0; ply < stop; ply++) {
    const l = e.legal();
    if (!l.length) { e.pass(); if (++passes === 2) break; continue; }
    passes = 0;
    e.make(l[(rnd(st) * l.length) >> 8]);
  }
  if (e.legal().length) pos.push([Array.from(e.bd), e.side, e.empties()]);
}
let bad = 0, n = 0;
for (const [bd, side, emp] of pos) {
  const depths = emp <= 7 ? [emp, Math.max(1, emp - 1)] : [3, 4];
  for (const d of depths) {
    const e = new Engine();
    e.setBoard(bd, side);
    const r = e.think({ depth: d, noise: 0, exact: 0, seed: 5 });
    const best = r.scores.filter(x => x[1] === r.score).map(x => x[0]);
    h.setPos(bd, side);
    const a = h.think({ nodes: 0, depth: d, noise: 0, exact: 0, seed: 5 });
    n++;
    if (a.score !== r.score || !best.includes(a.move)) { bad++; console.log(`depth ${d}, ${emp} empty: 6303 ${a.move} ${a.score}, reference ${best} ${r.score}`); }
  }
}
console.log(`${n} fixed-depth searches, ${bad} differ`);
process.exit(bad ? 1 : 0);
