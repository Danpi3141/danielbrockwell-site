// Random games: after every move the 6303's board, counts, side, square score, evaluation,
// key and move count must equal the reference's.
'use strict';
const { Harness } = require('./harness.js');
const { Engine, rnd } = require('../../ref/engine.js');
const h = new Harness();
const games = +(process.argv[2] || 20);
let checks = 0, bad = 0;
const st = { seed: 777 };
for (let g = 0; g < games; g++) {
  const e = new Engine();
  h.call('eng_reset');
  let passes = 0;
  while (true) {
    const s = h.state();
    const fail = (what, a, b) => { bad++; if (bad < 10) console.log(`game ${g} ${what}: 6303 ${JSON.stringify(a)} ref ${JSON.stringify(b)}`); };
    if (JSON.stringify(s.bd) !== JSON.stringify(Array.from(e.bd))) fail('board', s.bd.join(''), e.bd.join(''));
    if (s.ns !== e.ns || s.nh !== e.nh || s.side !== e.side || s.sqs !== e.sqs) fail('counts', s, { ns: e.ns, nh: e.nh, side: e.side, sqs: e.sqs });
    const pm = rnd(st) % 18;
    const ev = h.call('t_eval', pm).d;
    if (ev !== e.evaluate(pm)) fail('eval', ev, e.evaluate(pm));
    h.call('e_hash');
    const k = h.p24('e_h');
    if (k !== e.key()) fail('key', k.toString(16), e.key().toString(16));
    const cm = h.call('t_cmob').b;
    if (cm !== e.countMoves(e.side)) fail('cmob', cm, e.countMoves(e.side));
    checks++;
    const legal = e.legal();
    if (!legal.length) {
      e.pass(); h.call('e_pass');
      if (++passes === 2) break;
      continue;
    }
    passes = 0;
    const mv = legal[(rnd(st) * legal.length) >> 8];
    const n = e.make(mv);
    const r = h.call('t_make', 0, mv);
    if (r.b !== n) fail('flips', r.b, n);
    // an illegal square leaves everything alone
  }
}
console.log(`${games} games, ${checks} positions checked, ${bad} differences`);
process.exit(bad ? 1 : 0);
