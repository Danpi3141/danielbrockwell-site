// Reversi 8x6 rules, mailbox board exactly as the Psion engine keeps it.
// Board: 80 bytes, 10 columns x 8 rows, index = row*10 + col; playable rows 1-6, cols 1-8.
// 0 empty, 1 Solid, 2 Hollow, 3 border. a1 = 11, h6 = 68. Half turn: s -> 79-s.
// Square numbers (book, move list): sq 0-47 = (row-1)*8 + (col-1); half turn sq -> 47-sq.
'use strict';

const EMPTY = 0, SOLID = 1, HOLLOW = 2, BORDER = 3;
const DIRS = [-11, -10, -9, -1, 1, 9, 10, 11];

function idxOf(sq) { return 11 + ((sq >> 3) * 10) + (sq & 7); }
function sqOf(idx) { return ((((idx / 10) | 0) - 1) << 3) + (idx % 10) - 1; }
function name(idx) { return 'abcdefgh'[idx % 10 - 1] + ((idx / 10) | 0); }
function parse(s) { return ((s.charCodeAt(1) - 48) * 10) + (s.charCodeAt(0) - 96); }

const SQUARES = [];
for (let r = 1; r <= 6; r++) for (let c = 1; c <= 8; c++) SQUARES.push(r * 10 + c);

function newBoard() {
  const b = new Uint8Array(80).fill(BORDER);
  for (const s of SQUARES) b[s] = EMPTY;
  b[34] = HOLLOW; b[45] = HOLLOW; // d3 e4
  b[35] = SOLID; b[44] = SOLID;   // e3 d4
  return b;
}

// Flips for a move at s by side p; returns array of flipped squares (empty if illegal).
function flipsFor(b, s, p) {
  if (b[s] !== EMPTY) return [];
  const o = 3 - p, out = [];
  for (const d of DIRS) {
    let t = s + d;
    if (b[t] !== o) continue;
    const run = [];
    while (b[t] === o) { run.push(t); t += d; }
    if (b[t] === p) out.push(...run);
  }
  return out;
}

function legalMoves(b, p, order = SQUARES) {
  const ms = [];
  for (const s of order) if (b[s] === EMPTY && flipsFor(b, s, p).length) ms.push(s);
  return ms;
}

function play(b, s, p) {
  const f = flipsFor(b, s, p);
  if (!f.length) throw new Error('illegal ' + name(s));
  b[s] = p;
  for (const t of f) b[t] = p;
  return f;
}

function count(b) {
  let s = 0, h = 0;
  for (const q of SQUARES) { if (b[q] === SOLID) s++; else if (b[q] === HOLLOW) h++; }
  return [s, h];
}

function show(b) {
  const ch = ['.', 'X', 'O', '#'];
  let out = '';
  for (let r = 1; r <= 6; r++) {
    let line = r + ' ';
    for (let c = 1; c <= 8; c++) line += ch[b[r * 10 + c]];
    out += line + '\n';
  }
  return out + '  abcdefgh\n';
}

// Perft with a pass counted as a move; a finished game counts as a leaf only at full depth
// (a sequence that ends early is not extended).
function perft(b, p, depth, passed = false) {
  if (depth === 0) return 1;
  const ms = legalMoves(b, p);
  if (!ms.length) {
    if (passed) return 0; // game over before depth
    return perft(b, 3 - p, depth - 1, true);
  }
  let n = 0;
  for (const s of ms) {
    const f = flipsFor(b, s, p);
    b[s] = p; for (const t of f) b[t] = p;
    n += perft(b, 3 - p, depth - 1, false);
    b[s] = EMPTY; for (const t of f) b[t] = 3 - p;
  }
  return n;
}

module.exports = { EMPTY, SOLID, HOLLOW, BORDER, DIRS, SQUARES, idxOf, sqOf, name, parse,
  newBoard, flipsFor, legalMoves, play, count, show, perft };

if (require.main === module) {
  const want = [4, 12, 56, 244, 1380, 7892, 51246, 346758, 2523782];
  const maxd = +(process.argv[2] || 9);
  let ok = true;
  for (let d = 1; d <= maxd; d++) {
    const t = Date.now();
    const n = perft(newBoard(), SOLID, d);
    const good = n === want[d - 1];
    ok = ok && good;
    console.log(`depth ${d}: ${n} ${good ? 'ok' : 'WANT ' + want[d - 1]} (${Date.now() - t} ms)`);
  }
  process.exit(ok ? 0 : 1);
}
