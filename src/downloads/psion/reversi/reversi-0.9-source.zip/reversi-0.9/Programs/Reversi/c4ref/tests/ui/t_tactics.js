// The review's tactics ("Missed a win", "Allows four", "Allows fork"):
//  - the C4G2 game (you Solid at level 8, a deliberate blunder at move 9): move 3 "Win -> loss"
//    (from the history), move 9 "Allows fork", move 11 nothing new (any move lost at once);
//  - two-player games of random moves (no history: every verdict is a tactic or the move
//    number), reviewed from the result screen: each step's line 2 against tests/ui/tactics.js;
//  - the time the tactics take on the way into a 42-move review.
//   node tests/ui/t_tactics.js [models...] (default cm lz64) [games=N]
'use strict';
const { Game, assert } = require('./lib');
const T = require('./tactics');
const args = process.argv.slice(2);
const games = +((args.find(a => a.startsWith('games=')) || 'games=4').slice(6));
const models = args.filter(a => !a.includes('=')).length ? args.filter(a => !a.includes('=')) : ['cm', 'lz64'];
let rnd = 11; const rand = n => { rnd = (rnd * 1103515245 + 12345) & 0x7fffffff; return (rnd >> 8) % n; };
const line2 = (g) => g.panel().map(s => s.trim())[1];
let shown = 0, steps = 0, downs = 0;
const kinds = [0, 0, 0, 0];

for (const model of models) {
  // ---- C4G2
  const g = new Game(model).start();
  g.waitHuman(60);
  g.poke('st_level', 8); g.poke('st_you', 0); g.poke('st_pace', 1);
  g.keys(['ON', 'EXE', 'EXE'], 1.5);
  const ps = g.peek('g_psion');
  for (const c of [3, 0, 3, 4, 1, 0]) {
    g.waitFor(() => g.peek('g_over') || (g.humanTurn() && (g.peek('g_n') % 2) + 1 !== ps), 300, 0.1);
    const n = g.peek('g_n');
    g.key('UVWOPQI'[c], 0.1); g.key('EXE', 0.3);
    g.waitFor(() => g.peek('g_n') > n, 5, 0.02);
  }
  g.waitFor(() => g.peek('g_over') === 2, 60);
  g.m.runSeconds(1);
  assert(g.recStr() === '441443532215', `${model}: C4G2 replayed: ${g.recStr()}`);
  g.key('MODE', 0.8);
  const want = { 3: 'Win -> loss', 9: 'Allows fork', 11: 'Still a loss' };
  for (let r = 12; r >= 1; r--) {
    if (want[r]) assert(line2(g) === want[r], `${model}: C4G2 move ${r}: "${line2(g)}", want "${want[r]}"`);
    g.key('LEFT', 0.3);
  }
  g.key('EXE', 1.5);
  // ---- two players, random moves
  g.poke('st_clock', 0); g.poke('st_timer', 0); g.poke('st_swap', 0); g.poke('st_match', 0);
  for (let gi = 0; gi < games; gi++) {
    g.keys(['ON', 'N', 'EXE'], 0.5);
    g.waitText(/One player/, 10);
    for (let i = 0; i < 3 && !g.text().includes('>Two players'); i++) g.key('DOWN', 0.3);
    g.key('EXE', 0.5); g.names();
    assert(g.peek('g_mode') === 1, `${model}: two players`);
    while (!g.peek('g_over')) {
      const rec = g.rec(), b = T.board(rec);
      const legal = [0, 1, 2, 3, 4, 5, 6].filter(c => b[c][5] === 0);
      g.drop(legal[rand(legal.length)]);
    }
    g.waitFor(() => g.peek('g_over') === 2, 30);
    g.waitText(/in \d+ moves|draw/i, 20);             // the result screen up (MODE: the review)
    g.m.runSeconds(0.5);
    const rec = g.rec(), n = rec.length;
    g.key('MODE', 0.1);
    let waited = 0.1;                                  // the tactics, then the last move's step
    while (!/(Solid|Hollow) col ?\d/.test(g.panel()[0]) && waited < 10) { g.m.runSeconds(0.05); waited += 0.05; }
    g.m.runSeconds(0.3);                               // (the rest of the panel)
    if (n >= 30) console.log(`${model}: game ${gi + 1}, ${n} moves: the review up in ${waited.toFixed(2)} s`);
    for (let r = n; r >= 1; r--) {
      const tc = T.tactic(rec, r), got = line2(g);
      const exp = tc ? T.TEXT[tc] : g.m.lines === 2 ? `Move ${r}/${n}` : '';
      assert(got === exp, `${model}: game ${rec.map(c => c + 1).join('')}, move ${r}: "${got}", want "${exp}"`);
      if (tc) { shown++; kinds[tc]++; }
      steps++;
      g.key('LEFT', 0.25);
    }
    // DOWN from the start: each marked move in turn (here the tactics), then the end (19 Nov)
    for (const r of [...Array.from({ length: n }, (_, i) => i + 1).filter(r => r < n && T.tactic(rec, r)), n]) {
      g.key('DOWN', 2.5);
      const p = g.panel()[0].trim(), want = ((r - 1) % 2 ? 'Hollow' : 'Solid');
      assert(p.includes(want) && p.endsWith(String(rec[r - 1] + 1)) && g.peek('e_n') === r, `${model}: DOWN to move ${r}: "${p}", e_n ${g.peek('e_n')}`);
      downs++;
    }
    g.key('EXE', 1.5);
  }
  console.log(`${model}: C4G2 and ${games} two-player games reviewed`);
}
assert(kinds[1] && kinds[2] && kinds[3], 'each kind shown: ' + kinds);
console.log(`tactics ok: ${steps} steps, ${shown} tactics (missed ${kinds[1]}, four ${kinds[2]}, fork ${kinds[3]}) as the model; DOWN stopped ${downs} times`);
