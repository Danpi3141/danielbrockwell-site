; =====================================================================
; Moves (ref/engine.js make / undo / canMove / countMoves / flipCount)
;
; e_bd    80 bytes, 10 columns by 8 rows, index row*10+col: 0 empty,
;         1 Solid, 2 Hollow, 3 the border. a1 = 11, h6 = 68.
; e_dirs  checks the eight directions round the square at e_base+11
;         (e_base = e_bd + square - 11, so every neighbour is a positive
;         offset 0-22 from it). A direction whose neighbour is not an enemy
;         disc costs one compare and a branch; the rest go on from that
;         neighbour: e_wkp with ABX for the positive steps (the enemy's
;         colour kept in A), e_wkn for the negative ones.
; Modes (e_mode): 0 make (flip, push on the flip stack, add up values),
;         1 count (e_cnt += the run), $80 test (stop at the first bracket:
;         C set, straight back to e_dirs' caller).
; =====================================================================

DIRP    macro off,step          ; a direction with a positive step
        cmpa \off,x
        bne  .n\@
        ldab #\off
        abx                     ; X = the enemy disc next to the square
        ldab #\step
        jsr  e_wkp
        ldx  e_base
        ldaa e_op
.n\@:
        endm
DIRN    macro off,step          ; a negative step (off 0: X is already there)
        cmpa \off,x
        bne  .n\@
        if   \off
        ldab #\off
        abx
        endif
        ldd  #\step
        jsr  e_wkn
        ldx  e_base
        ldaa e_op
.n\@:
        endm

; e_dirs: X = e_base. A is clobbered. C clear at the end (test mode: C
; set means a bracket was found, returned from the walk).
e_dirs: ldaa e_op
        DIRN 0,-11
        DIRN 1,-10
        DIRN 2,-9
        DIRN 10,-1
        DIRP 12,1
        DIRP 20,9
        DIRP 21,10
        DIRP 22,11
        clc
        rts

; e_wkn: X = the enemy disc next to the square, D = the step (negative).
; Walks on while enemy discs continue; on a friendly disc the run is
; bracketed (e_br2), else nothing.
e_wkn:  std  e_dst
        stx  e_t
.l:     xgdx
        addd e_dst
        xgdx
        ldaa 0,x
        cmpa e_op
        beq  .l
        cmpa e_me
        bne  e_rts
        bra  e_br2
; e_wkp: the same with B = the step (positive), A = e_op: on with ABX
e_wkp:  stx  e_t
.l:     abx
        cmpa 0,x
        beq  .l
        ldaa 0,x
        cmpa e_me
        bne  e_rts
        clra                    ; D = the step
; a bracket: X = the friendly disc, D = the step, e_t the first enemy disc
e_brk:  std  e_dst
e_br2:  ldaa e_mode
        bne  .nf
.fl:    xgdx                    ; flip back to the first enemy disc
        subd e_dst
        xgdx
        ldaa e_me
        staa 0,x
        xgdx
        subd #e_bd              ; B = the square
        ldx  e_fsp
        stab 0,x
        inx
        stx  e_fsp
        ldx  #e_valu            ; its value (+128) into the sum
        abx
        ldaa 0,x
        adda e_acc+1
        staa e_acc+1
        bcc  .c
        inc  e_acc
.c:     ldx  #e_bd
        abx
        cpx  e_t
        bne  .fl
        rts
.nf:    bmi  .tst
.cn:    xgdx                    ; count mode: the run's length
        subd e_dst
        xgdx
        inc  e_cnt
        cpx  e_t
        bne  .cn
        rts
.tst:   ins                     ; test mode: a bracket, back to e_dirs' caller
        ins
        sec
e_rts:  rts

; e_sides: A = the side to move (1 or 2): sets e_me and e_op
e_sides:staa e_me
        eora #3
        staa e_op
        rts

; ---------------------------------------------------------------------
; e_make: B = square. The side to move (e_side) plays it.
; Returns B = the discs flipped (0: not legal, nothing changed).
; ---------------------------------------------------------------------
e_make: stab e_sq
        ldx  #e_bd-11
        abx
        tst  11,x
        bne  .ill
        ldaa e_side             ; (e_me/e_op are on the zero page: OS calls clobber them)
        staa e_me
        eora #3
        staa e_op
        stx  e_base
        ldd  e_fsp
        std  e_fs0
        clra
        clrb
        std  e_acc
        staa e_mode
        jsr  e_dirs
        ldd  e_fsp
        subd e_fs0
        tstb
        bne  .ok
.ill:   clrb
        rts
.ok:    stab e_n                ; flips
        ldx  e_base
        ldaa e_me
        staa 11,x               ; the new disc
        ldx  #e_ns-1            ; counts: the mover's + n + 1, the other's - n
        ldab e_me
        abx
        ldaa 0,x
        adda e_n
        inca
        staa 0,x
        ldx  #e_ns-1
        ldab e_op
        abx
        ldaa 0,x
        suba e_n
        staa 0,x
        ; square score: dv = (sum - 128n) * 2 + V[s]; Solid adds it, Hollow takes it away
        ldaa e_n
        clrb
        lsra
        rorb                    ; D = n * 128
        std  e_tw
        ldd  e_acc
        subd e_tw
        asld
        std  e_tw
        ldx  #e_valu
        ldab e_sq
        abx
        ldab 0,x
        clra
        subd #128               ; V[s], signed
        addd e_tw
        std  e_tw
        ldaa e_me
        cmpa #1
        beq  .s1
        clra
        clrb
        subd e_tw
        bra  .s
.s1:    ldd  e_tw
.s:     ldx  e_sqs              ; (the score before: e_sqo, for the search)
        stx  e_sqo
        addd e_sqs
        std  e_sqs
        jsr  e_pass             ; the other side to move
        ldab e_n
        rts

; e_pass: the other side to move
e_pass: ldaa e_side
        eora #3
        staa e_side
        bra  e_sides

; ---------------------------------------------------------------------
; e_undo: B = the square of the last move, e_fs0 = the flip stack as it
; was before it. Puts the board, counts and side back (not e_sqs: the
; search keeps a copy).
; ---------------------------------------------------------------------
e_undo: stab e_sq
        jsr  e_pass             ; the mover to move again
        ldx  #e_bd
        ldab e_sq
        abx
        clr  0,x
        ldd  e_fsp
        subd e_fs0
        stab e_n
        ldaa e_op
        ldx  e_fsp
.p:     cpx  e_fs0
        beq  .d
        dex
        ldab 0,x
        stx  e_fsp
        ldx  #e_bd
        abx
        staa 0,x
        ldx  e_fsp
        bra  .p
.d:     ldx  #e_ns-1
        ldab e_me
        abx
        ldaa 0,x
        suba e_n
        deca
        staa 0,x
        ldx  #e_ns-1
        ldab e_op
        abx
        ldaa 0,x
        adda e_n
        staa 0,x
        rts

; ---------------------------------------------------------------------
; e_cmob: A = side. B = how many legal moves it has (the board is scanned
; a1..h6 through e_base). e_me/e_op are left set for that side.
; ---------------------------------------------------------------------
e_cmob: jsr  e_sides
        ldaa #$80
        staa e_mode
        clr  e_cnt
        ldx  #e_bd
.l:     ldab 11,x
        bne  .n
        stx  e_base
        jsr  e_dirs
        bcc  .nb
        inc  e_cnt
.nb:    ldx  e_base
.n:     inx
        cpx  #e_bd+58
        bne  .l
        ldab e_cnt
        rts

; e_flips: B = square, A = side. B = the discs that side would flip there
; (counted only); e_me/e_op are left set for that side.
e_flips:stab e_sq
        jsr  e_sides
        ldaa #1
        staa e_mode
        clr  e_cnt
        ldx  #e_bd-11
        ldab e_sq
        abx
        stx  e_base
        jsr  e_dirs
        ldab e_cnt
        rts
