// While the Psion thinks (level 8): other keys are ignored, ON/CLEAR makes it play its best move
// so far at once (fewer positions than the level's budget); the thinking bar grows meanwhile.
'use strict';
const { Game, assert } = require('./lib.js');
for (const model of (process.argv[2] || 'cm,lz64').split(',')) {
  const g = new Game(model);
  g.start(); g.poke('st_level', 8); g.poke('st_book', 1);
  for (let i = 0; i < 3; i++) {
    g.waitHuman();
    const n = g.peek('g_n');
    g.key('EXE', 0.2);
    g.waitFor(() => /\[/.test(g.prompt()), 10, 0.05);
    g.m.runSeconds(4);
    g.key('E', 0.3); g.key('DOWN', 0.3);          // ignored
    g.m.runSeconds(6);
    const bar = g.prompt();
    if (g.peek('g_n') !== n + 1 || !/\[/.test(bar)) { console.log(`[${model}] (that search ended by itself)`); continue; }
    g.key('ON', 0.2);
    assert(g.waitFor(() => g.peek('g_n') === n + 2, 3, 0.05), 'ON: the Psion moved at once');
    const nodes = g.bytes('e_nodes', 3), cnt = nodes[0] << 16 | nodes[1] << 8 | nodes[2];
    assert(cnt < 15000, 'stopped short of the budget: ' + cnt);
    console.log(`[${model}] stopped after ${cnt} positions, bar was ${bar.trim()}`);
  }
}
