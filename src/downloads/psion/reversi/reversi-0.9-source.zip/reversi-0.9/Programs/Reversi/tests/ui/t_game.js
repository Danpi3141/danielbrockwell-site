// A whole one-player game through the keys: EXE on the cursor's square each turn, the Psion at
// a level; then the record replayed by the reference must give the board shown.
// node t_game.js [model] [level]
'use strict';
const { Game, assert } = require('./lib.js');
const R = require('../../ref/rules.js');
const model = process.argv[2] || 'cm', level = +(process.argv[3] || 1);
const g = new Game(model);
g.start();
g.poke('st_level', level);
const t0 = g.m.cycles();
let turns = 0, last = -1, same = 0;
while (true) {
  g.waitFor(() => g.over() || (g.humanTurn() && (g.peek('g_n') !== last || /Pass/.test(g.prompt()))), 900, 0.2);
  if (g.over()) break;
  const n = g.peek('g_n');
  same = n === last && !/Pass/.test(g.prompt()) ? same + 1 : 0;
  if (same > 3) throw new Error('stuck at move ' + n + ' ' + JSON.stringify(g.rec()) + '\n' + g.text());
  last = n;
  g.key('EXE', 0.3);
  turns++;
}
const rec = g.rec();
const b = R.newBoard();
let side = 1;
for (const sq of rec) {
  const s = R.idxOf(sq);
  if (!R.legalMoves(b, side).length) side = 3 - side;
  R.play(b, s, side);
  side = 3 - side;
}
const rows = [];
for (let r = 1; r <= 6; r++) { let s = ''; for (let c = 1; c <= 8; c++) s += '.XO'[b[r * 10 + c]]; rows.push(s); }
assert(JSON.stringify(rows) === JSON.stringify(g.board()), 'board differs\n' + rows.join('\n') + '\n' + g.board().join('\n'));
const [ns, nh] = R.count(b);
console.log(`${model} L${level}: ${rec.length} moves, ${turns} turns, Solid ${ns} Hollow ${nh}, ${((g.m.cycles() - t0) / 921600).toFixed(0)} s emulated`);
console.log(g.text());
