// Checks the book: every line replays legally (as stored and turned half round), the walk finds
// every stored reply, positions beneath each are counted right, and (with the .json) each reply
// is the generator's analysis.
// node tools/book/check_book.js [data/book]
'use strict';
const fs = require('fs');
const path = require('path');
const R = require('../../ref/rules.js');
const { bookReply, lines } = require('./walk.js');

const base = path.join(__dirname, '..', '..', process.argv[2] || 'data/book');
const bin = fs.readFileSync(base + '.bin');
let bad = 0, n = 0;
for (const seq of lines(bin)) {
  for (const turn of [0, 1]) {
    const s = seq.map(q => turn ? 47 - q : q);
    const b = R.newBoard();
    let side = 1, ok = true;
    for (const q of s) {
      const idx = R.idxOf(q);
      if (!R.legalMoves(b, side).length) { ok = false; break; }        // no passes in the book
      if (!R.flipsFor(b, idx, side).length) { ok = false; break; }
      R.play(b, idx, side);
      side = 3 - side;
    }
    if (!ok) { bad++; console.log('illegal line', s.map(q => R.name(R.idxOf(q))).join(' ')); continue; }
    const psion = (s.length & 1) ? 1 : 2;              // the reply's side
    const got = bookReply(bin, s.slice(0, -1), psion);
    if (got !== R.idxOf(s[s.length - 1])) { bad++; console.log('walk', s.join(','), got); }
    n++;
  }
}
console.log(`${n} lines checked (both ways round), ${bad} problems; ${bin.length} bytes`);
process.exit(bad ? 1 : 0);
