; ---------------------------------------------------------------------
; The game loop
; g_psion the side(s) the Psion plays: 0 none, 1 Solid, 2 Hollow, 3 both
; g_over  0 playing, 1 over, 2 over and counted in the tally
; The position is e_bd / e_side; the moves are g_rec (passes not stored:
; replaying finds them).
; ---------------------------------------------------------------------

gm_main:
        lds  kv_sp              ; (every command comes back here)
        tst  g_over
        bne  .res
        jsr  status             ; A = 0 a move, 1 a pass, 2 the end
        cmpa #2
        bne  .on
        inc  g_over             ; neither side can move
.res:   ldd  #OV_PANEL*256      ; the result shown, counted, and the game saved
        jsr  ov_call
        ldd  #OV_RESULT*256+R_SHOW
        jsr  ov_call            ; returns a command
        psha
        pshb
        jsr  save
        pulb
        pula
        bra  gm_cmd
.on:    psha
        jsr  psion_turn
        pula
        beq  .human
        tsta
        beq  .pm
        ldd  #OV_PANEL*256+P_PASS   ; the Psion has no move
        jsr  ov_call
        bra  gm_main
.pm:    jsr  psion_move
        bra  gm_main
.human: ldd  #OV_PANEL*256      ; your move: the panel, then OV_PLAY
        jsr  ov_call
        ldd  #OV_PLAY*256
        jsr  ov_call            ; returns a command
gm_cmd: jsr  do_cmd
        bra  gm_main

; status: A = 0 if the side to move has a move, 1 if only the other side
; has (a pass), 2 if neither (the game is over)
status: ldaa e_side
        jsr  e_cmob
        clra
        tstb
        bne  .x
        ldaa e_side
        eora #3
        jsr  e_cmob
        ldaa #1
        tstb
        bne  .x
        inca
.x:     psha                    ; (e_cmob set e_me/e_op for its side)
        ldaa e_side
        jsr  e_sides
        pula
        rts

; Z clear if the Psion plays the side to move
psion_turn:
        ldaa e_side
        anda g_psion
        rts

; do_cmd: A = command, B = argument (also in kv_arg). The table holds a
; kernel routine's address, or (below $2000, where no RAM is) an overlay's
; id and entry to call.
do_cmd: cmpa #C_LAST
        bhi  .x
        stab kv_arg
        asla
        tab
        ldx  #cmd_tab
        abx
        ldd  0,x
        cmpa #$20
        bhs  .k
        jmp  ov_call            ; an overlay: A = its id, B = the entry
.k:     xgdx
        ldab kv_arg
        jmp  0,x
.x:     rts

cmd_tab: fdb  gm_x, cm_move, OV_GAME*256+G_BACK, cm_tip, cm_menu, OV_GAME*256+G_NEWG, cm_swap, cm_set
         fdb  cm_set, cm_set, OV_SETUP*256+S_SETUP, OV_HELP*256+H_TALLY, OV_HELP*256+H_HELP, OV_GAME*256+G_LEAVE, cm_pass, OV_PANEL*256+P_SHOW, OV_GAME*256+G_MARK, OV_HELP*256+H_LIST, OV_REVIEW*256
         fdb  OV_EXPORT*256, OV_IMPORT*256, OV_PANEL*256+P_HPASS, OV_PANEL*256+P_LEAVE
gm_x:   rts

; a move (kv_arg): played and saved (OV_GAME), then shown (OV_FX)
cm_move:
        clr  kv_hon
        ldd  #OV_GAME*256+G_MOVE
        jsr  ov_call
        bcs  .x
        ldd  #OV_FX*256+X_MOVE
        jmp  ov_call
.x:     rts
cm_menu:
        ldd  #OV_MENU*256
        jsr  ov_call
        jmp  do_cmd
; C_LEVEL (B = 0), C_PLAYERS (B = 1), C_SET (B = 0): the settings from that
; line, then saved (saving applies the players: OV_GAME)
cm_set: ldd  #OV_SET*256
        jsr  ov_call
        jmp  save
; the Psion takes over the side to move: one player, you the other side
cm_swap:
        ldaa e_side
        eora #3
        staa g_you
        clr  st_players
        jmp  save
; you have no move: the other side moves again
cm_pass:
        ldaa #$FF
        staa kv_lmv
        clr  kv_lfl
        ldaa e_side
        staa kv_lwho
        jmp  e_pass
; the tip: a short search; its square becomes the cursor's (OV_BOOK
; refuses, C set, unless it is your turn with a move)
cm_tip: ldd  #OV_BOOK*256+B_TIP
        jsr  ov_call
        bcs  .x
        jsr  think_run
        ldaa e_move
        staa kv_tip
.x:     rts

; save the game, the players applied (OV_GAME)
save:   ldd  #OV_GAME*256+G_SAVE
        jmp  ov_call

; ---------------------------------------------------------------------
; The Psion's turn: OV_BOOK gives the book's square, or sets up the
; search; the move is played by OV_GAME. In a demo any key stops it.
; ---------------------------------------------------------------------
psion_move:
        ldd  #OV_PANEL*256      ; the counts and the last move, then the bar
        jsr  ov_call
        ldd  #OV_BOOK*256+B_TURN
        jsr  ov_call            ; A = a square from the book, or 0
        tsta
        bne  .play
        jsr  think_run
        ldaa e_move
.play:  staa kv_arg
        jsr  cm_move
; a demo stops at a key: the menu
demo_key:
        ldaa g_psion
        cmpa #3
        bne  .x
        os   KB$TEST
        tstb
        beq  .x
        os   KB$FLSH
        jmp  cm_menu
.x:     rts

