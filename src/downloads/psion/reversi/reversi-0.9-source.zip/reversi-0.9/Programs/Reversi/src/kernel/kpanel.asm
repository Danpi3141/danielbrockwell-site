; ---------------------------------------------------------------------
; The text panel: 11 characters wide, kv_plines lines (2 or 4), at the
; screen positions the driver gave (kv_ppos). Lines are built in kv_lb
; and sent through the OS.
; ---------------------------------------------------------------------
PW      = 11

; lb_clr: an empty line buffer
lb_clr: ldx  #kv_lb
        ldab #PW
        ldaa #' '
.l:     staa 0,x
        inx
        decb
        bne  .l
        clr  kv_lp
        rts

; lb_ch: A = a character, appended (dropped past the end)
lb_ch:  ldab kv_lp
        cmpb #PW
        bhs  .x
        ldx  #kv_lb
        abx
        staa 0,x
        inc  kv_lp
.x:     rts

; lb_fcl: X = a string with a leading length, appended
lb_fcl: ldab 0,x
        beq  .x
.l:     inx
        pshb
        pshx
        ldaa 0,x
        bsr  lb_ch
        pulx
        pulb
        decb
        bne  .l
.x:     rts

; lb_s: the string after the call (with a leading length) is appended
lb_s:   pulx
        pshx
        bsr  lb_fcl
        pulx                    ; past the string
        ldab 0,x
        incb
        abx
        jmp  0,x

; lb_num: D = an unsigned number, appended in decimal
lb_num: ldx  #kv_nb
        os   UT$UTOB            ; digits at X, B = how many
        ldx  #kv_nb-1
        stab 0,x                ; (kv_nb-1 is kv_nbl: a length byte)
        bra  lb_fcl

; lb_sq: B = a square index: its name appended ("e5")
lb_sq:  clra
.l:     subb #10
        bcs  .d
        inca
        bra  .l
.d:     addb #'a'+9             ; the column letter
        psha
        tba
        bsr  lb_ch
        pula
        adda #'0'               ; the row digit
        bra  lb_ch

; lb_sp: one space
lb_sp:  ldaa #' '
        bra  lb_ch

; lb_at: A = column: spaces up to it
lb_at:  cmpa kv_lp
        bls  .x
        psha
        bsr  lb_sp
        pula
        bra  lb_at
.x:     rts

; lb_put: A = panel line (0..3): kv_lb shown there
lb_put: ldx  #kv_lb
; pn_put: A = line, X = 11 characters (lines past the panel are ignored)
pn_put: cmpa kv_plines
        bhs  .x
        stx  kv_t0
        tab
        ldx  #kv_ppos
        abx
        ldaa 0,x                ; the line's screen position
        clrb                    ; cursor off
        os   DP$STAT
        ldx  kv_t0
        ldab #PW
        os   DP$PRNT
.x:     rts

; pn_clear: the whole panel blank
pn_clear:
        jsr  lb_clr
        clra
.l:     psha
        jsr  lb_put
        pula
        inca
        cmpa #4
        bne  .l
        rts

; pn_msg: the string after the call on the panel's last line (the prompt)
pn_msg: jsr  lb_clr
        pulx
        pshx
        jsr  lb_fcl
        pulx
        ldab 0,x
        incb
        abx
        pshx
pn_last:ldaa kv_plines
        deca
        bra  lb_put
