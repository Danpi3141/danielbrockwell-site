; =====================================================================
; Evaluation (ref/engine.js evaluate / final / margin), the side to
; move's view. e_pmob = the moves the parent's mover had.
;   squares  e_sqs, less the values of corner neighbours whose corner is taken
;   corners  each taken corner: its weight plus the edge weight for every
;            disc of the same colour running on along either edge
;   discs    weight * (Solid - Hollow)
;   moves    weight * (own moves now - e_pmob)
;   parity   weight when the empty squares are odd
; Weights by stage (e_wt rows of 5: moves, corner, edge, parity, discs):
; more than 30 empty, 13-30, 12 or fewer. Clamped to +-1000.
; =====================================================================
W_MOB   = 0
W_CORN  = 1
W_EDGE  = 2
W_PAR   = 3
W_DISC  = 4

; e_empt: B = the empty squares
e_empt: ldab #48
        subb e_ns
        subb e_nh
        stab e_emp
        rts

e_eval: bsr  e_empt
        ldx  #e_wt
        cmpb #30
        bhi  .w
        ldx  #e_wt+5
        cmpb #13
        bhs  .w
        ldx  #e_wt+10
.w:     stx  e_wp
        ldd  e_sqs
        std  e_ev
        ldx  #e_ctab
.cl:    stx  e_cp
        ldab 0,x                ; the corner
        stab e_c
        ldx  #e_bd
        abx
        ldaa 0,x
        beq  .cn
        staa e_x
        clr  e_k                ; the edge runs
        ldx  e_cp
        ldaa 1,x
        bsr  e_run
        ldx  e_cp
        ldaa 2,x
        bsr  e_run
        ldx  e_wp
        ldaa e_k
        ldab W_EDGE,x
        jsr  e_smul
        std  e_tw
        ldx  e_wp
        ldab W_CORN,x
        jsr  e_sxb
        addd e_tw
        std  e_tw
        ldaa e_x                ; Solid adds, Hollow takes away
        cmpa #1
        beq  .sa
        ldd  e_ev
        subd e_tw
        bra  .sv
.sa:    ldd  e_ev
        addd e_tw
.sv:    std  e_ev
        ldx  e_cp               ; its three neighbours lose their values
        ldab 0,x
        addb 1,x
        bsr  e_nfix
        ldx  e_cp
        ldab 0,x
        addb 2,x
        bsr  e_nfix
        ldx  e_cp
        ldab 0,x
        addb 1,x
        addb 2,x
        bsr  e_nfix
.cn:    ldx  e_cp
        inx
        inx
        inx
        cpx  #e_ctab+12
        bne  .cl
        ldaa e_ns               ; discs
        suba e_nh
        ldx  e_wp
        ldab W_DISC,x
        jsr  e_smul
        addd e_ev
        std  e_ev
        ldaa e_side             ; to the side to move's view
        cmpa #1
        beq  .s1
        ldd  e_ev
        jsr  e_negd
        std  e_ev
.s1:
        ldaa e_side             ; moves
        jsr  e_cmob
        subb e_pmob
        tba
        ldx  e_wp
        ldab W_MOB,x
        jsr  e_smul
        addd e_ev
        std  e_ev
        ldaa e_emp              ; parity
        bita #1
        beq  .np
        ldx  e_wp
        ldab W_PAR,x
        jsr  e_sxb
        addd e_ev
        std  e_ev
.np:    ldd  e_ev               ; clamp to +-1000
        subd #1000
        ble  .c1
        ldd  #1000
        rts
.c1:    ldd  e_ev
        subd #-1000
        bge  .c2
        ldd  #-1000
        rts
.c2:    ldd  e_ev
        rts

; e_run: A = step; e_k += the discs of colour e_x running on from e_c
e_run:  staa e_dd
        ldab e_c
.l:     addb e_dd
        ldx  #e_bd
        abx
        ldaa 0,x
        cmpa e_x
        bne  .e
        inc  e_k
        bra  .l
.e:     rts

; e_nfix: B = a corner's neighbour: a Solid disc there takes its value off
; e_ev, a Hollow one puts it back
e_nfix: ldx  #e_bd
        abx
        ldaa 0,x
        beq  .r
        staa e_y
        ldx  #e_valu
        abx
        ldab 0,x
        clra
        subd #128               ; D = its value
        std  e_tw
        ldaa e_y                ; Solid: take it off
        cmpa #1
        bne  .h
        ldd  e_tw
        jsr  e_negd
        bra  .a
.h:     ldd  e_tw
.a:     addd e_ev
        std  e_ev
.r:     rts

; e_negd: D = -D. Keeps nothing else.
e_negd: coma
        comb
        addd #1
        rts

; e_sxb: D = B sign-extended
e_sxb:  clra
        tstb
        bpl  .r
        coma
.r:     rts

; e_smul: D = A * B, both signed bytes
e_smul: clr  e_sg
        tsta
        bpl  .a
        nega
        com  e_sg
.a:     tstb
        bpl  .b
        negb
        com  e_sg
.b:     mul
        tst  e_sg
        beq  .r
        bsr  e_negd
.r:     rts

; e_marg: D = the disc margin for the side to move
e_marg: ldab e_ns
        subb e_nh
        ldaa e_side
        cmpa #1
        beq  .s
        negb
.s:     bra  e_sxb

; e_final: D = a finished game's score for the side to move: 2,000 plus
; the margin for a win, -2,000 plus it for a loss, 0 for a draw
e_final:bsr  e_marg
        tsta
        bmi  .l
        tstb
        beq  .r
        addd #2000
        rts
.l:     subd #2000
.r:     rts
