; =====================================================================
; Reversi 8x6 engine (matched to ref/engine.js position for position).
; Needs from the includer: E_TT (256-byte table), E_FS (244-byte flip
; stack), E_FR (frames, killers and the search's variables: up to
; E_SCRATCH_END). Never touches the screen; calls the kernel only
; through e_poll.
; =====================================================================
; Busy working variables on the zero page, in the OS's utility scratch
; UTW_S0-S5 ($41-$4C); the OS uses them in its services, so e_count keeps
; them on the stack while e_poll runs.
e_me    = $41                   ; the side moving (1 Solid, 2 Hollow)
e_op    = $42                   ; the other side
e_base  = $43                   ; (2) e_bd + square - 11
e_dst   = $45                   ; (2) a direction's step
e_fsp   = $47                   ; (2) the flip stack's top
e_t     = $49                   ; (2) a walk's first enemy disc
e_fp    = $4B                   ; (2) the search's frame

eng_start:
        include "emove.asm"
        include "eeval.asm"
        include "ekey.asm"
        include "esearch.asm"
        include "etab.inc"
eng_end:
