// SPSA tuning of the evaluation by self-play: theta+ against theta- at a level, on all cores.
// node ref/tune/spsa.js iterations level gamesPerIter out.json [start.json]
// Writes the running theta to out.json after every iteration.
'use strict';
const fs = require('fs');
const os = require('os');
const { Worker, isMainThread, parentPort } = require('worker_threads');
const { QUARTER, WEIGHTS } = require('../engine.js');
const { openings, playFrom } = require('../match.js');

const NAMES = ['mob', 'corner', 'edge', 'par', 'disc'];
function toVec(q, w) { return [...q.flat(), ...NAMES.flatMap(n => w[n])]; }
function toOpts(v) {
  const r = v.map(x => Math.round(x));
  const quarter = [r.slice(0, 4), r.slice(4, 8), r.slice(8, 12)];
  const weights = {};
  NAMES.forEach((n, k) => { weights[n] = r.slice(12 + k * 3, 15 + k * 3); });
  return { quarter, weights };
}

if (!isMainThread) {
  parentPort.on('message', (job) => {
    const out = [];
    for (const g of job.games) {
      const a = { level: job.level, opts: job.a }, b = { level: job.level, opts: job.b };
      const r = playFrom(g.seq, g.aSolid ? a : b, g.aSolid ? b : a, g.seed);
      const d = r.ns - r.nh;
      out.push(d === 0 ? 0.5 : (g.aSolid ? d > 0 : d < 0) ? 1 : 0);
    }
    parentPort.postMessage(out);
  });
} else {
  const iters = +process.argv[2], level = +process.argv[3], per = +process.argv[4], file = process.argv[5];
  let theta = process.argv[6] ? JSON.parse(fs.readFileSync(process.argv[6], 'utf8')).theta : toVec(QUARTER, WEIGHTS);
  const n = theta.length;
  const ops = openings(4000, 8, 0xabcde);
  const nw = os.cpus().length;
  const workers = Array.from({ length: nw }, () => new Worker(__filename));
  const run = (a, b, games) => {
    const parts = Array.from({ length: nw }, () => []);
    games.forEach((g, i) => parts[i % nw].push(g));
    return Promise.all(parts.map((p, i) => new Promise(res => {
      if (!p.length) return res([]);
      workers[i].once('message', res);
      workers[i].postMessage({ a, b, level, games: p });
    }))).then(r => r.flat());
  };
  let seed = 12345;
  const rand = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x80000000; };
  (async () => {
    const c0 = theta.map(x => Math.max(1, Math.abs(x) * 0.15));
    for (let k = 0; k < iters; k++) {
      const ck = c0.map(c => c / Math.pow(k + 1, 0.101));
      const ak = 2.0 / Math.pow(k + 1 + 50, 0.602);
      const delta = theta.map(() => (rand() < 0.5 ? -1 : 1));
      const tp = theta.map((t, i) => t + ck[i] * delta[i]);
      const tm = theta.map((t, i) => t - ck[i] * delta[i]);
      const games = [];
      for (let g = 0; g < per / 2; g++) {
        const seq = ops[(k * per / 2 + g) % ops.length];
        games.push({ seq, aSolid: true, seed: k * 1000 + g }, { seq, aSolid: false, seed: k * 1000 + g });
      }
      const res = await run(toOpts(tp), toOpts(tm), games);
      const sc = res.reduce((s, x) => s + x, 0) / res.length - 0.5;
      theta = theta.map((t, i) => t + ak * sc * ck[i] * delta[i] / ck[i] * c0[i] * 4);
      fs.writeFileSync(file, JSON.stringify({ iter: k + 1, level, theta, opts: toOpts(theta) }));
      if ((k + 1) % 25 === 0) console.log(`iter ${k + 1} score ${sc.toFixed(3)} ${JSON.stringify(toOpts(theta))}`);
    }
    workers.forEach(w => w.terminate());
  })();
}
module.exports = { toOpts, toVec };
