; =====================================================================
; OV_PANEL: the panel above the prompt line.
; Two lines:  line 1 "S12 H14  e5" (the counts and the last move: "--" a
;             pass, "END" when over); line 2 the result when over.
; Four lines: line 1 Solid's mark, name and count, line 2 Hollow's, line 3
;             the last move ("Psion e5 +3"), or the result when over.
; Names: one player "You" / "Psion", otherwise "Solid" / "Hollow".
; =====================================================================
        include "../defs.inc"

        jmp  pn_draw
        jmp  show
        jmp  pn_pass
        jmp  pn_hpas
        jmp  pn_leav

; P_HPASS: your turn and no move: "Pass: EXE" (EXE passes, MODE the menu)
pn_hpas:jsr  pn_msg
        fcl  "Pass: EXE"
        clra
        jsr  key_wait
        cmpb #K_EXE
        bne  .m
        jmp  cm_pass
.m:     cmpb #K_MODE
        bne  .b
        jmp  cm_menu
.b:     jsr  buzz
        bra  pn_hpas

; P_LEAVE: ON on your turn: "Leave? EXE" (saved and out), anything else back
pn_leav:jsr  pn_msg
        fcl  "Leave? EXE"
        clra
        jsr  key_wait
        cmpb #K_EXE
        bne  .x
        ldd  #OV_GAME*256+G_LEAVE
        jmp  ov_call
.x:     rts

; P_PASS: the Psion has no move: "Psion pass" for a second, the other side
; again (a key cuts it short; in a demo it stops it: the menu)
pn_pass:jsr  cm_pass
        bsr  pn_draw
        jsr  pn_msg
        fcl  "Psion pass"
        ldaa #20
        jsr  key_wait
        tstb
        bne  .k
        jmp  demo_key
.k:     ldaa g_psion
        cmpa #3
        bne  .x
        jmp  cm_menu
.x:     rts

pn_draw:
        clr  kv_hon             ; standing hints (stretch goal 4): on your turn
        tst  st_hints
        beq  .nh
        tst  g_over
        bne  .nh
        jsr  psion_turn
        bne  .nh
        inc  kv_hon
        jsr  DRV+DV_BOARD
.nh:    tst  kv_four
        bne  .four
        jsr  lb_clr             ; "S12 H14  e5"
        ldaa #'S'
        jsr  lb_ch
        ldab e_ns
        bsr  num2
        jsr  lb_sp
        ldaa #'H'
        jsr  lb_ch
        ldab e_nh
        bsr  num2
        tst  g_over
        beq  .lm
        ldaa #8
        jsr  lb_at
        jsr  lb_s
        fcl  "END"
        bra  .l1
.lm:    ldaa #9
        jsr  lb_at
        bsr  lastsq
.l1:    clra
        jsr  lb_put
        tst  g_over
        beq  .x
        jsr  lb_clr
        jsr  pr_res
        ldaa #1
        jmp  lb_put
.x:     rts
.four:  ldaa #SOLID             ; lines 1 and 2: the sides
        bsr  side_ln
        ldaa #HOLLOW
        bsr  side_ln
        jsr  lb_clr             ; line 3: the last move, or the result
        tst  g_over
        beq  .mv
        jsr  pr_res
        bra  .p3
.mv:    ldab kv_lmv
        beq  .p3
        ldaa kv_lwho
        tst  g_psion
        beq  .mk                ; two players, demo: the side's mark
        ldab g_psion
        cmpb #3
        beq  .mk
        jsr  pr_name
        bra  .sp
.mk:    jsr  mark
        jsr  lb_ch
.sp:    jsr  lb_sp
        ldab kv_lmv
        cmpb #$FF
        bne  .sq
        jsr  lb_s
        fcl  "pass"
        bra  .p3
.sq:    bsr  lastsq
        jsr  lb_sp
        ldaa #'+'
        jsr  lb_ch
        clra
        ldab kv_lfl
        jsr  lb_num
.p3:    ldaa #2
        jmp  lb_put

; A = side: its line (Solid line 1, Hollow line 2): mark, name, count
side_ln:psha
        jsr  lb_clr
        pula
        psha
        bsr  mark
        jsr  lb_ch
        pula
        psha
        bsr  pr_name
        ldaa #9
        jsr  lb_at
        pula
        psha
        ldx  #e_ns-1
        tab
        abx
        ldab 0,x
        bsr  num2
        pula
        deca
        jmp  lb_put

; A = side: its mark in the panel (the four-line glyph 1 Solid, 4 Hollow)
mark:   cmpa #SOLID
        beq  .s
        ldaa #4
        rts
.s:     ldaa #1
        rts

; A = side: its name: one player "You" (or player 1's name) / "Psion";
; two players player 1's / player 2's name, or "Solid" / "Hollow"; the
; demo "Solid" / "Hollow"
pr_name:ldab g_psion
        cmpb #3
        beq  .side
        ldx  #g_names
        tstb
        beq  .two
        anda g_psion
        bne  .ps
        tst  0,x                ; you: your name
        bne  .nm
        jsr  lb_s
        fcl  "You"
        rts
.two:   cmpa #SOLID             ; two players: the side's player's name
        beq  .t1
        ldx  #g_names+8
.t1:    tst  0,x
        beq  .side
.nm:    jmp  lb_fcl
.ps:    jsr  lb_s
        fcl  "Psion"
        rts
.side:  cmpa #SOLID
        bne  .h
        jsr  lb_s
        fcl  "Solid"
        rts
.h:     jsr  lb_s
        fcl  "Hollow"
        rts

; B = 0-48: two characters, right-aligned
num2:   cmpb #10
        bhs  .n
        pshb
        jsr  lb_sp
        pulb
.n:     clra
        jmp  lb_num

; the last move's square ("--" a pass, nothing before the first move)
lastsq: ldab kv_lmv
        beq  .x
        cmpb #$FF
        bne  .s
        jsr  lb_s
        fcl  "--"
.x:     rts
.s:     jmp  lb_sq

; the result, as the panel shows it: "You win +4", "You lose 12",
; "Solid +4", "Hollow +4" (or the players' names), "Draw 24-24". With Final score "Winner takes
; empties" the empty squares go to the winner.
pr_res: ldaa e_ns
        ldab e_nh
        tst  st_final
        beq  .c
        cba
        beq  .c
        psha
        ldaa #48                ; the empty squares
        suba e_ns
        suba e_nh
        staa kv_t0
        pula
        cba
        bhi  .sw
        addb kv_t0              ; Hollow wins: the empties are Hollow's
        bra  .c
.sw:    adda kv_t0
.c:     staa kv_t1              ; Solid's and Hollow's final counts
        stab kv_t1+1
        cba
        bne  .w
        jsr  lb_s               ; "Draw 24-24"
        fcl  "Draw "
        clra
        ldab kv_t1
        jsr  lb_num
        ldaa #'-'
        jsr  lb_ch
        clra
        ldab kv_t1+1
        jmp  lb_num
.w:     ldaa #SOLID             ; the winner, and by how much
        ldab kv_t1
        subb kv_t1+1
        bcc  .m
        ldaa #HOLLOW
        negb
.m:     stab kv_t0
        ldab g_psion
        beq  .two
        cmpb #3
        beq  .two
        anda g_psion
        bne  .lose
        jsr  lb_s
        fcl  "You win +"
        bra  .n
.lose:  jsr  lb_s
        fcl  "You lose "
        bra  .n
.two:   jsr  pr_name            ; "Solid +4"
        jsr  lb_sp
        ldaa #'+'
        jsr  lb_ch
.n:     clra
        ldab kv_t0
        jmp  lb_num

; S: every legal square shows the mover's disc, flashing, for a second
show:   ldx  #BUF               ; the legal squares
        stx  sh_p
        ldab #10
.l:     incb
        cmpb #69
        beq  .e
        stab sh_t
        bsr  legal
        ldab sh_t
        tsta
        beq  .l
        ldx  sh_p
        stab 0,x
        inx
        stx  sh_p
        bra  .l
.e:     ldaa #6
        staa sh_n
.f:     ldaa sh_n               ; on, off, on ...
        anda #1
        beq  .on
        clra
        bra  .w
.on:    ldaa e_side
.w:     ldx  #BUF
.s:     cpx  sh_p
        beq  .d
        ldab 0,x
        pshx
        ldx  #e_bd
        abx
        staa 0,x
        pulx
        inx
        bra  .s
.d:     jsr  DRV+DV_BOARD
        ldaa #3
        jsr  pause
        dec  sh_n
        bne  .f
        rts

; B = a square index: A = flips there for the side to move (Z set: not legal)
legal:  ldx  #e_bd
        abx
        tst  0,x
        bne  .no
        ldaa e_side
        jsr  e_flips
        ldaa e_side             ; (e_flips set e_me/e_op for its side)
        pshb
        jsr  e_sides
        pula
        tsta
        rts
.no:    clra
        rts

sh_t:   fcb  0
sh_n:   fcb  0
sh_p:   fdb  0
