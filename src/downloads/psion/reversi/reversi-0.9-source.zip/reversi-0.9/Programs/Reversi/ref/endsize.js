// Exact ending sizes (positions counted as the engine counts them) from positions in engine games.
'use strict';
const { Engine, rnd } = require('./engine.js');
const st = { seed: 4321 };
for (const E of (process.argv[2] || '8,10,11,12,13').split(',').map(Number)) {
  const sizes = [];
  while (sizes.length < (+process.argv[3] || 60)) {
    const e = new Engine();
    let passes = 0;
    while (e.empties() > E) {
      const l = e.legal();
      if (!l.length) { e.pass(); if (++passes === 2) break; continue; }
      passes = 0;
      e.make(e.think({ level: 3, seed: rnd(st) }).move);
    }
    if (e.empties() !== E || !e.legal().length) continue;
    sizes.push(e.think({ nodes: 0, exact: E, seed: 1 }).nodes);
  }
  sizes.sort((a, b) => a - b);
  const avg = sizes.reduce((a, b) => a + b, 0) / sizes.length;
  console.log(`${E} empty: average ${avg.toFixed(0)}, 9 in 10 within ${sizes[Math.floor(sizes.length * 0.9)]}, most ${sizes[sizes.length - 1]} (${(avg / 146).toFixed(1)} s at 146/s)`);
}
