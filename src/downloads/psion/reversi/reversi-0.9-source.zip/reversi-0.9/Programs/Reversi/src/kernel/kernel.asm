; =====================================================================
; Reversi kernel: stays in RAM while the game runs. Assembled at offset
; 0 of the game's array m%(); the bootstrap has added the array's address
; to every fix-up. The engine is part of this image.
;
; Array: kernel + engine code and tables | variables | screen driver (DRV)
;        | slot A (overlays). While the engine searches, its table (E_TT,
;        256), flip stack (E_FS, 244) and scratch (E_FR) cover the driver
;        and slot A, except OV_THINK at the top of slot A; the driver and the
;        overlay are read in again afterwards.
;
; Entry (from the bootstrap): D = ADDR(v%()): 0 array address, 2 array
; size, 4 device. Returns to the launcher with X = result code (E_*).
; =====================================================================
        include "../defs.inc"

entry:  jmp  start              ; must be the first instruction
        fcc  "RVK1"             ; kernel format tag

        include "ids.inc"

E_TT    = TTBASE                ; (= DRV)
E_FS    = TTBASE+256
E_FR    = SCRATCH               ; (= DRV + 500)
E_PICK  = THINKAT+2             ; e_pick: in OV_THINK, after its first instruction

start:  pshb                    ; D = ADDR(v%()): for the start-up code
        psha
        ldd  #INIT_LEN          ; the start-up code (kinit.asm) up into slot A
        std  T0
        ldx  #kv_first
        ldd  #SLOTA
        os   UT$CPYB
        jmp  SLOTA
; it comes back here, the variables set up and the title shown
kinit_done:
        ldd  #OV_GAME*256+G_LOAD  ; the saved game, or a new one
        jsr  ov_call
        jmp  gm_main

; leave the game from any depth: B = result code
quit:   lds  kv_sp
        pshb
        os   PK$PKOF
        ldaa #12
        os   DP$EMIT
        tst  kv_four            ; back to the display mode we found
        beq  .d
        ldaa kv_omode
        os   DP$MSET
.d:     os   KB$FLSH
        pulb
        clra
        xgdx
        rts

; ---------------------------------------------------------------------
; ov_call: A = overlay id, B = entry: load the overlay into slot A (if it
; isn't there) and call the entry with X unchanged. Registers come back
; from the overlay.
; ---------------------------------------------------------------------
ov_call:
        stx  kv_rx
        pshb
        jsr  ov_load
        pulb
        ldaa #3
        mul
        addd #SLOTA
        std  kv_rtgt
        ldx  kv_rtgt
        pshx
        ldx  kv_rx
        rts                     ; into the entry; its rts returns to our caller

; ov_resume: ov_call kv_cont (id, entry). An overlay that has to give slot
; A up (to a search: think_run) sets kv_cont, pushes this address and jumps:
; it is read in again afterwards and goes on at that entry.
ov_resume:
        ldd  kv_cont
        jmp  ov_call

; ---------------------------------------------------------------------
; think_run: the search (e_limit etc. set by OV_BOOK) with the thinking
; bar: OV_BOOK starts it (e_pre), then OV_THINK is read in to the top of
; slot A, above the search's working space: it is the poll, and has the
; end of a level 1-2 search (e_pick). The driver and the overlay are gone afterwards:
; the driver is read in again.
; ---------------------------------------------------------------------
think_run:
        ldd  #OV_BOOK*256+B_PRE ; the search's start, from OV_BOOK (still in slot A)
        jsr  ov_call
        ldaa #OV_THINK
        jsr  ov_load
        clr  kv_res
        jsr  e_think
        ldaa e_abort            ; stopped by a key: let it go first, or the press
        cmpa #2                 ; counts again after the flush
        bne  .f
        ldaa #6
        jsr  pause
.f:     ldaa g_psion            ; (a demo: the key is left for demo_key, which
        cmpa #3                 ; stops it)
        beq  .d
        os   KB$FLSH
.d:
        ldaa kv_drv             ; the search covered the driver: read it in again
        jmp  ov_load

; the units' offsets in block 0 (filled in by the build)
ovtab:  rmb  2*N_UNITS

        include "kpack.asm"
        include "kkeys.asm"
        include "kpanel.asm"
        include "ksound.asm"
        include "kcore.asm"
        include "../engine/engine.asm"
        include "kvars.inc"
kernel_end:
