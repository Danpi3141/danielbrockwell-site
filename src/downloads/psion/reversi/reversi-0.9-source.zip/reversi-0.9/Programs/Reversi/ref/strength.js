// The spec's strength measures. node ref/strength.js [openings] [levels e.g. 2-8]
// 1. Matches: each level plays the one below over 2 x openings games (sides swapped); a level
//    passes at 60%.
// 2. Discs given away: in those games, every move made with 14 or fewer empty squares is solved
//    exactly (every legal move); the average margin it lost against the best, by level.
'use strict';
const os = require('os');
const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');
const { match } = require('./match.js');
const { Engine } = require('./engine.js');

function lossesOf(game) {        // [ [level side, loss] ... ] for moves at 14 or fewer empty
  const e = new Engine();
  for (const s of game.seq) e.make(s);
  const out = [];
  let passes = 0, i = 0;
  while (i < game.moves.length) {
    const l = e.legal();
    if (!l.length) { e.pass(); if (++passes === 2) break; continue; }
    passes = 0;
    const mv = game.moves[i++];
    if (e.empties() <= 14 && l.length > 1) {
      let best = -99, got = 0;
      for (const m of l) {
        const c = new Engine(); c.setBoard(e.bd, e.side); c.make(m);
        const v = -solve(c);
        if (v > best) best = v;
        if (m === mv) got = v;
      }
      out.push([e.side, best - got]);
    }
    e.make(mv);
  }
  return out;
}
function solve(c) {   // exact margin for the side to move in c
  c.tt = new Uint32Array(64); c.ttS = new Int8Array(64); c.nodes = 0; c.abort = false; c.limit = 0; c.iter1 = false;
  return c.exact(-64, 64, false);
}
if (!isMainThread) {
  parentPort.postMessage(workerData.games.map(lossesOf));
} else {
  (async () => {
    const n = +(process.argv[2] || 100);
    const [lo, hi] = (process.argv[3] || '2-8').split('-').map(Number);
    const lost = {};
    for (let lv = lo; lv <= hi; lv++) {
      const t = Date.now();
      const r = await match({ a: { level: lv }, b: { level: lv - 1 }, openings: n, plies: 8, oseed: 0x600D + lv });
      // discs given away: by level (the mover's)
      const nw = os.cpus().length, parts = Array.from({ length: nw }, () => []);
      r.results.forEach((g, k) => parts[k % nw].push(g));
      const res = await Promise.all(parts.map(p => new Promise((ok, no) => {
        const w = new Worker(__filename, { workerData: { games: p } });
        w.on('message', ok); w.on('error', no);
      })));
      for (const p of parts) for (const g of p) {
        const ls = res[parts.indexOf(p)][p.indexOf(g)];
        const aSide = g.aSolid ? 1 : 2;
        for (const [side, loss] of ls) {
          const L = side === aSide ? lv : lv - 1;
          (lost[L] = lost[L] || []).push(loss);
        }
      }
      console.log(`L${lv} v L${lv - 1}: ${r.pct.toFixed(1)}% of ${r.games} ${r.pct >= 60 ? 'pass' : 'FAIL'} (mean margin ${r.margin.toFixed(1)}), ${((Date.now() - t) / 1000).toFixed(0)} s`);
    }
    for (const L of Object.keys(lost).sort((a, b) => a - b)) {
      const a = lost[L];
      console.log(`level ${L}: ${a.length} moves at 14 or fewer empty, ${(a.reduce((s, x) => s + x, 0) / a.length).toFixed(2)} discs given away a move`);
    }
  })();
}
