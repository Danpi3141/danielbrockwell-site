// UI test helpers: the game on an emulated Organiser (tools/emu.js), its variables read from RAM
// through the build's symbol table (the kernel is found by its "RVK1" tag). From Connect 4's.
'use strict';
const fs = require('fs'), path = require('path');
const { Machine } = require('../../tools/emu');

const ROOT = path.join(__dirname, '..', '..');
const TAG = [0x52, 0x56, 0x4B, 0x31];   // "RVK1"
const MODELS = {
  cm: { rom: '33-cm.rom', ram: 8 }, cm24: { rom: '24-cm.rom', ram: 8 }, cm26: { rom: '26-cm.rom', ram: 8 },
  xp: { rom: '31-xp.rom', ram: 16 }, xp24: { rom: '24-xp.rom', ram: 16 }, xp26: { rom: '26-xp.rom', ram: 16 },
  la: { rom: '36-la.rom', ram: 32 }, lz: { rom: '46-lz.rom', ram: 32 }, lz64: { rom: '46a-lz64.rom', ram: 64 },
};

// every Organiser ROM the emulator has (not the POS terminals), and its RAM in K
const ROMS = {
  '24-cm.rom': 8, '26-cm.rom': 8, '33-cm.rom': 8, '33-cmf.rom': 8, '36-cmf.rom': 8,
  '24-xp.rom': 16, '26-xp.rom': 16, '31-xp.rom': 16,
  '30-lahp.rom': 32, '33-la.rom': 32, '34-lag.rom': 32, '36-la.rom': 32, '36-laf.rom': 32, '36-lag.rom': 32, '37-lam.rom': 32,
  '42-lz.rom': 32, '44-lz.rom': 32, '45-lz.rom': 32, '45-lzi.rom': 32, '45-lzs.rom': 32, '46-lz.rom': 32, '46-lzi.rom': 32,
  '43-lz64.rom': 64, '44-lz64.rom': 64, '45-lz64.rom': 64, '46a-lz64.rom': 64, '46b-lz64.rom': 64, '46-lz64i.rom': 64, '46-lz64s.rom': 64,
};

class Game {
  constructor(model, opts = {}) {
    this.model = model;
    const mm = MODELS[model] || (ROMS[model] ? { rom: model, ram: ROMS[model] } : null);
    if (!mm) throw new Error('no model ' + model);
    this.opts = opts;
    this.m = new Machine({ rom: mm.rom, ram: mm.ram });
    const bdir = opts.build || path.join(ROOT, 'build', 'game');
    this.sym = JSON.parse(fs.readFileSync(path.join(bdir, 'kernel.sym.json'), 'utf8'));
    this.meta = JSON.parse(fs.readFileSync(path.join(bdir, 'build.json'), 'utf8'));
    if (opts.boot !== false) this.m.boot();
    if (opts.boot !== false) this.m.insertPack(opts.pack || path.join(bdir, 'REV.opk'), 0);
    this.base = -1;
    if (process.env.REV_COVER) this.cover(process.env.REV_COVER, bdir);
  }
  // coverage (env REV_COVER=<folder>): every instruction the game executes, credited to its unit
  // (the kernel, the driver, the overlay in slot A by kv_res, OV_THINK while a search runs);
  // written to <folder>/cov_<pid>_<n>.json when the process ends (tests/coverage.js reads them)
  cover(dir, bdir) {
    const s = this.sym, DRV = s.DRV[0], SLOTA = s.SLOTA[0], THINKAT = s.THINKAT[0];
    const RES = s.kv_res[0], KDRV = s.kv_drv[0];
    const ids = Object.fromEntries(fs.readFileSync(path.join(bdir, 'gen', 'ids.inc'), 'utf8')
      .split(/\r?\n/).map(l => l.match(/^(\w+) = (\d+)/)).filter(Boolean).map(m => [+m[2], m[1]]));
    const size = this.meta.total;
    const cov = {}, self = this, dbg = this.m.dbg;
    let user = null;
    const add = (u, o) => { (cov[u] || (cov[u] = new Set())).add(o); };
    dbg.setTrace((pc) => {
      const b = self.base;
      if (b >= 0 && pc >= b && pc < b + size) {
        const o = pc - b;
        if (o < DRV) add('kernel', o);
        else if (o < SLOTA) add(ids[self.m.peek(b + KDRV)] || 'DRV?', o - DRV);
        else {
          const r = self.m.peek(b + RES);
          if (o >= THINKAT && (r === 0 || ids[r] === 'OV_THINK')) add('OV_THINK', o - THINKAT);
          else add(r ? ids[r] || 'u' + r : 'kinit', o - SLOTA);
        }
      }
      if (user) user(pc);
    });
    dbg.setTrace = (f) => { user = f; };
    const n = (Game._covN = (Game._covN || 0) + 1);
    process.on('exit', () => {
      fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(path.join(dir, `cov_${process.pid}_${n}.json`), JSON.stringify(Object.fromEntries(Object.entries(cov).map(([u, v]) => [u, [...v]]))));
    });
  }
  // run REV from the Prog menu and wait for the game (past the title)
  // back to the top-level menu from wherever the OS is (switched off, a menu, the editor)
  toTop() {
    const top = () => /Find|FIND/.test(this.text()) && /Prog|PROG/.test(this.text());
    for (let i = 0; i < 12 && !top(); i++) {
      const t = this.text();
      if (process.env.TOP_DEBUG) console.log('  toTop', i, this.m.isOn(), JSON.stringify(t));
      const w = (t.split(String.fromCharCode(10))[0] || '').trim().split(/\s+/);
      if (/^(Tran|TRAN|UEBERS|TRAD|Trad)/.test(w[0] || '') && w.length >= 3) { this.m.press(w[2][0].toUpperCase(), 3, 10); }   // the editor's menu: its third item, Quit (AUFG, ABAN...)
      else if (/([YJO])\/N/.test(t)) { this.m.press(t.match(/([YJO])\/N/)[1], 3, 10); }   // yes/no: Y, J(a), O(ui)
      else if (/^\w+:/.test(t) || /LOCAL|PRINT/.test(t)) { this.m.press('MODE', 3, 10); }   // the editor
      else this.m.press('ON', 3, 10);
      this.m.runSeconds(0.4);
    }
  }
  start(opts = {}) {
    this.toTop();
    for (let a; (a = this.m.find(TAG, 0x2000, 0x8000)) >= 0;) this.m.poke(a, 0);
    this.base = -1;
    this.m.runProc('REV', 'B');
    this.waitFor(() => this.findBase() >= 0 && this.peek('kv_plines') > 0, 8);
    if (opts.title !== false) {
      this.m.runSeconds(2.6);                                   // the title
      // then the game itself (its settings loaded, so pokes after this stick): your turn,
      // the Psion thinking, a pass or a result
      this.waitFor(() => this.humanTurn() || /\[|pass/.test(this.prompt()) || this.over(), 10, 0.1);
    }
    return this;
  }
  findBase() {
    const a = this.m.find(TAG, 0x2000, 0x8000);
    this.base = a < 0 ? -1 : a - 3;
    return this.base;
  }
  a(name) {
    const v = this.sym[name];
    if (!v) throw new Error('no symbol ' + name);
    return v[1] === 'rel' ? this.base + v[0] : v[0];
  }
  // On the LZ64 the array is in the banked window $4000-$7FFF: while the OS has another bank
  // in, reads show other RAM. Run on until the kernel's tag is back before trusting a read.
  sync() {
    if (this.base < 0) return;
    const ok = () => TAG.every((b, i) => this.m.peek(this.base + 3 + i) === b);
    for (let i = 0; i < 2000 && !ok(); i++) this.m.run(200);
  }
  peek(n, o = 0) { this.sync(); return this.m.peek(this.a(n) + o); }
  poke(n, v, o = 0) { this.sync(); this.m.poke(this.a(n) + o, v); }
  peekw(n, o = 0) { this.sync(); return this.m.peekw(this.a(n) + o); }
  bytes(n, k, o = 0) { this.sync(); return this.m.read(this.a(n) + o, k); }
  rec() { const n = this.peek('g_n'); return this.bytes('g_rec', n); }
  screen() { return this.m.screen(); }
  text() { return this.m.screenText(); }
  // the panel's lines (11 characters from column 6 / column 10)
  panel() {
    const s = this.screen(), four = this.m.lines === 4;
    return four ? s.map(l => l.slice(9, 20)) : s.map(l => l.slice(5, 16));
  }
  prompt() { const p = this.panel(); return p[p.length - 1]; }
  waitFor(pred, maxS = 30, step = 0.1) {
    for (let t = 0; t < maxS; t += step) { if (pred()) return true; this.m.runSeconds(step); }
    return pred();
  }
  waitText(re, maxS = 30) {
    if (!this.waitFor(() => re.test(this.text()), maxS)) throw new Error('timed out waiting for ' + re + '\n' + this.text());
  }
  key(k, after = 0.4) { this.m.press(k, 3, 3); this.m.runSeconds(after); }
  keys(list, after = 0.4) { for (const k of list) this.key(k, after); }
  // a human's turn on the play screen: "You: e5 +3", "S: d2 +4" (two players), "Pass: EXE"
  humanTurn() { return /: [a-h][1-6]|Pass: EXE/.test(this.prompt()); }
  // and waiting for a key there: OV_PLAY (5), or OV_PANEL's "Pass: EXE"
  turn() { return this.humanTurn() && (this.peek('kv_res') === 5 || /Pass: EXE/.test(this.prompt())); }
  waitHuman(maxS = 600) {
    if (!this.waitFor(() => this.humanTurn(), maxS, 0.2)) throw new Error('no human turn\n' + this.text());
  }
  // play a square ("e5") by typing it, confirmed with EXE
  play(sq) {
    this.waitHuman();
    this.key(sq[0].toUpperCase(), 0.2);
    this.key('UVWOPQ'[+sq[1] - 1], 0.2);
    if (this.peek('st_confirm') === 0) this.key('EXE', 0.8);
    else this.m.runSeconds(0.8);
  }
  // the engine's board as rows: . X (Solid) O (Hollow)
  board() {
    const bd = this.bytes('e_bd', 80), rows = [];
    for (let r = 1; r <= 6; r++) { let s = ''; for (let c = 1; c <= 8; c++) s += '.XO#'[bd[r * 10 + c]]; rows.push(s); }
    return rows;
  }
  side() { return this.peek('e_side'); }
  // play the game out with EXE on your turns only (OV_PLAY waiting), until the result
  playOut(maxS = 3000) {
    const play = 5;
    for (let t = 0; t < 200; t++) {
      if (!this.waitFor(() => this.over() || this.turn(), maxS, 0.2)) throw new Error('no turn: ' + this.text());
      if (this.over()) return;
      this.key('EXE', 0.4);
    }
  }
  // MODE (or EXE on a result), then a menu item by moving down to it, EXE
  menu(item) {
    const items = ['New game', 'Take back', 'Tip', 'Swap sides', 'Level', 'Players', 'Settings', 'Set up', 'Tally', 'Move list', 'Review', 'Export', 'Import', 'Help', 'Quit'];
    const i = items.indexOf(item);
    if (i < 0) throw new Error('no menu item ' + item);
    const open = () => this.panel().some(l => /^>/.test(l));
    this.waitFor(() => open() || this.turn() || this.over(), 900, 0.2);
    this.m.runSeconds(1);                          // (a key still in the buffer acts first)
    if (!open()) this.key(this.over() ? 'EXE' : 'MODE', 0.2);
    for (let k = 0; k < 12 && !this.panel().some(l => l.includes('>New game')); k++) this.key('UP', 0.15);
    if (!this.waitFor(() => this.panel().some(l => l.includes('>New game')), 5, 0.1)) throw new Error('no menu: ' + this.text());
    for (let k = 0; k < i; k++) this.key('DOWN', 0.15);
    if (!this.panel().some(l => l.includes('>' + item.slice(0, 10)))) throw new Error('menu not on ' + item + ': ' + this.text());
    this.key('EXE', 0.8);
  }
  // the result is on the screen (counted: g_over 2)
  over() { return this.peek('g_over') === 2 && (this.m.lines === 2 || /EXE: menu/.test(this.prompt())); }
}

function assert(cond, msg) { if (!cond) throw new Error('FAIL: ' + msg); }

module.exports = { Game, MODELS, ROMS, assert, ROOT };
