; =====================================================================
; OV_RESULT: after OV_PANEL has shown the result. The first time (g_over
; 1): the sound, and a one-player game (not a set-up one) counted in the
; tally for its level (A:REVTAL: one record, 'T' then wins, draws and
; losses for levels 1-8). Then (four lines) the prompt "EXE: menu": EXE,
; MODE or ON/CLEAR open the menu with New game first; DEL takes back.
; A demo's result stays 3 s, then the next game starts (a key: the menu).
; Returns a command.
; =====================================================================
        include "../defs.inc"

TAL_LEN = 25

        jmp  rs_show

rs_show:
        ldaa g_over
        cmpa #1
        bne  .keys
        inc  g_over             ; (counted: not again)
        jsr  winner             ; A = 1 Solid, 2 Hollow, 0 a draw
        ldab g_psion
        beq  .two
        cmpb #3
        beq  .two
        tsta
        beq  .draw
        anda g_psion            ; one player: the Psion's side won?
        beq  .won
        ldab #2                 ; a loss: the third count
        ldx  #snd_lose
        bra  .tal
.won:   clrb
        ldx  #snd_win
        bra  .tal
.draw:  ldab #1
        ldx  #snd_lose
.tal:   pshb
        jsr  snd_play
        pulb
        ldaa g_setup            ; (a set-up game is not counted; a handicap one is)
        cmpa #1
        beq  .keys
        pshb
        jsr  tally              ; B = 0 win, 1 draw, 2 loss
        pulb
        tst  st_auto            ; auto level: a win up one, a loss down one
        beq  .keys
        ldaa st_level
        tstb
        bne  .lo
        cmpa #8
        beq  .keys
        inca
        bra  .sl
.lo:    cmpb #2
        bne  .keys
        cmpa #1
        beq  .keys
        deca
.sl:    staa st_level
        bra  .keys
.two:   ldx  #snd_win
        jsr  snd_play
.keys:  ldaa g_psion            ; a demo goes on: the result for 3 s, then a new
        cmpa #3                 ; game; a key stops it (the menu)
        bne  .kk
        ldaa #60
        jsr  key_wait
        ldaa #C_MENU
        tstb
        bne  .x
        ldaa #C_NEW
        rts
.kk:    tst  kv_four            ; (two lines: the result stays on line 2)
        beq  .k
        jsr  pn_msg
        fcl  "EXE: menu"
.k:     clra
        jsr  key_wait
        ldaa #C_BACK
        cmpb #K_DEL
        beq  .x
        ldaa #C_MENU
        cmpb #K_EXE
        beq  .x
        cmpb #K_MODE
        beq  .x
        cmpb #K_ON
        bne  .k
.x:     rts

; A = the winner: 1 Solid, 2 Hollow, 0 a draw
winner: ldaa e_ns
        cmpa e_nh
        beq  .d
        bhi  .s
        ldaa #HOLLOW
        rts
.s:     ldaa #SOLID
        rts
.d:     clra
        rts

; B = 0 win, 1 draw, 2 loss: added for the level (counts stop at 255)
tally:  stab rs_k
        clr  kv_pkok            ; (the file services select A:)
        ldx  #rs_buf+1          ; a fresh tally if there is none
.z:     clr  0,x
        inx
        cpx  #rs_buf+TAL_LEN+1
        bne  .z
        ldaa #'T'
        staa rs_buf+1
        ldx  #rs_fn
        os   FL$OPEN
        bcs  .new
        tab
        os   FL$RECT
        clra
        clrb
        os   FL$SETP
        ldd  #1
        os   FL$RSET
        ldx  #rs_buf
        os   FL$READ
        bcs  .er
        ldaa rs_buf             ; a damaged record: start again
        cmpa #TAL_LEN
        bne  .zer
        ldaa rs_buf+1
        cmpa #'T'
        beq  .add
.zer:   ldx  #rs_buf+2
.z2:    clr  0,x
        inx
        cpx  #rs_buf+TAL_LEN+1
        bne  .z2
        ldaa #'T'
        staa rs_buf+1
.add:   os   FL$ERAS
        bra  .w
.er:    os   FL$ERAS
        bra  .w
.new:   ldx  #rs_fn
        os   FL$CRET
        bcs  .x
        tab
        os   FL$RECT
.w:     ldaa st_level           ; the count: 3 * (level - 1) + k
        deca
        ldab #3
        mul
        addb rs_k
        ldx  #rs_buf+2
        abx
        inc  0,x
        bne  .wr
        dec  0,x
.wr:    ldaa #TAL_LEN
        staa rs_buf
        ldx  #rs_buf
        os   FL$WRIT
.x:     clr  kv_pkok
        rts

rs_fn:  fcl  "A:REVTAL"
rs_k:   fcb  0
rs_buf: rmb  TAL_LEN+1

snd_win:    fdb  842                    ; you win
            fcb  90
            fdb  660
            fcb  90
            fdb  549
            fcb  90
            fdb  401
            fcb  180
            fdb  0
snd_lose:   fdb  549                    ; you lose (and a draw)
            fcb  120
            fdb  842
            fcb  250
            fdb  0
