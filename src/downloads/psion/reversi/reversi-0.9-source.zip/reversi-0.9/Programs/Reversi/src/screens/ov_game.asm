; =====================================================================
; OV_GAME: the save file, a new game, take back, replaying the record,
; playing a move. The save file A:REVSAV is one record: length, 'R',
; version, the bytes sv_first..sv_end, a checksum, read and written in
; place. A game is kept as its moves; loading replays them, which checks
; them too (a move that is not legal: a new game).
; =====================================================================
        include "../defs.inc"

SV_VER  = 3                     ; (2: the coach setting; 3: auto level, the demo level; 20 Nov)
SV_LEN  = sv_end-sv_first

        jmp  g_load
        jmp  g_save
        jmp  g_newg
        jmp  g_back
        jmp  g_replay
        jmp  g_move
        jmp  g_repsv
        jmp  g_leave
        jmp  g_mark
        jmp  g_imp

fn_sav: fcl  "A:REVSAV"

; open the save file: C clear if it is there; its record 1 current
sv_open:
        clr  kv_pkok            ; (the file services select A:)
        ldx  #fn_sav
        os   FL$OPEN
        bcs  .x
        tab
        os   FL$RECT
        clra
        clrb
        os   FL$SETP
        ldd  #1
        os   FL$RSET
.x:     rts

; B = checksum of the saved bytes
sv_sum: ldx  #sv_first
        clrb
.l:     addb 0,x
        inx
        cpx  #sv_end
        bne  .l
        rts

; G_LOAD: the record is read straight into place, then checked
g_load: bsr  sv_open
        bcs  .new
        ldx  #sv_rec
        os   FL$READ
        bcs  .new
        ldaa sv_rec
        cmpa #SV_LEN+3
        bne  .new
        ldd  sv_tag
        subd #'R'*256+SV_VER
        bne  .new
        bsr  sv_sum
        cmpb sv_chk
        bne  .new
        ldaa g_n
        cmpa #44
        bhi  .new
        clr  kv_pkok
        ldd  g_seed             ; the seed as it was
        std  e_seed
        ldaa g_seed+2
        staa e_seed+2
        ldaa g_over             ; (kept: a counted result is not counted again)
        psha
        jsr  g_replay
        pula
        bcs  .new
        staa g_over
        rts
.new:   clr  kv_pkok
        ldx  #sv_first          ; the defaults and a new game
.z:     clr  0,x
        inx
        cpx  #sv_end
        bne  .z
        ldaa #3
        staa st_level
        ldaa #SOLID
        staa g_you
; ---------------------------------------------------------------------
; G_NEWG: a new game with the players and level in force; with the corner
; handicap (not in a demo) its corners put on the board by OV_SETUP, which
; has it replayed and saved (G_REPSV)
; ---------------------------------------------------------------------
g_newg: ldd  FRC                ; a new game stirs the seed (the demo has no keys)
        eora e_seed+1
        eorb e_seed+2
        std  e_seed+1
        ldaa st_you             ; turn about: the other side this time
        cmpa #2
        beq  .t
        inca
        bra  .y
.t:     ldaa g_you
        eora #3
.y:     staa g_you
        bsr  g_psn
        clr  g_n
        clr  g_over
        clr  g_setup
        bsr  g_replay
        bsr  g_save
        tst  st_hcap
        beq  .x
        ldaa g_psion
        cmpa #3
        beq  .x
        ldd  #OV_SETUP*256+S_HCAP
        jmp  ov_call
.x:     rts

; g_psion from the players (one: the side you don't play)
g_psn:  ldab st_players
        clra
        decb
        beq  .p                 ; two: none
        ldaa #3
        tstb
        bpl  .p                 ; demo: both
        ldaa g_you
        eora #3
.p:     staa g_psion
        rts

; G_LEAVE: saved, then out of the game
g_leave:bsr  g_save
        clrb                    ; (E_OK)
        jmp  quit

; G_IMP: an imported record (OV_IMPORT) replayed: saved if every move is
; legal, or OV_IMPORT says it was bad (and loads the game as it was saved)
g_imp:  jsr  g_replay
        bcc  g_save
        ldd  #OV_IMPORT*256+I_BAD
        jmp  ov_call

; G_REPSV: the game replayed (from the set-up or handicap position) and saved
g_repsv:jsr  g_replay
; G_SAVE: the game saved, the players applied first (they may have changed)
g_save: bsr  g_psn
        ldd  e_seed
        std  g_seed
        ldaa e_seed+2
        staa g_seed+2
        ldaa #SV_LEN+3          ; the record, in place
        staa sv_rec
        ldd  #'R'*256+SV_VER
        std  sv_tag
        bsr  sv_sum
        stab sv_chk
        jsr  sv_open
        bcc  .old
        ldx  #fn_sav            ; no file yet
        os   FL$CRET
        bcs  .x
        tab
        os   FL$RECT
        bra  .w
.old:   os   FL$ERAS
.w:     ldx  #sv_rec
        os   FL$WRIT
.x:     clr  kv_pkok
        clra                    ; (no command)
        rts

; ---------------------------------------------------------------------
; G_BACK: take back one move in a two-player game; in a one-player game
; back to your previous turn (your move and the Psion's reply)
; ---------------------------------------------------------------------
g_back: ldaa g_psion
        cmpa #3
        beq  .no                ; (the demo)
        tst  g_n
        beq  .no
.one:   dec  g_n
        bsr  g_replay
        tst  g_n
        beq  .s
        tst  g_psion            ; two players: one move
        beq  .s
        jsr  status             ; one player: back to your turn (or the start)
        tsta
        bne  .one               ; (a pass: back further)
        jsr  psion_turn
        bne  .one
.s:     clr  g_over
        jmp  g_save
.no:    jmp  buzz

; G_MARK (L): the last move's flips found again by replaying, then shown
g_mark: bsr  g_replay
        ldd  #OV_FX*256+X_LAST
        jmp  ov_call

; ---------------------------------------------------------------------
; G_REPLAY: the position rebuilt from the start (or the set-up position)
; and g_rec, passes found on the way; the board redrawn. C set if a move
; is not legal (the record is damaged).
; ---------------------------------------------------------------------
g_replay:
        jsr  eng_reset
        clr  g_over
        clr  kv_lmv
        clr  kv_tip
        tst  g_setup
        beq  .go
        clr  kv_t2              ; the set-up position: 2 bits a square, a1 first
.s:     ldab kv_t2
        lsrb
        lsrb
        ldx  #g_start
        abx
        ldaa 0,x
        ldab kv_t2
        andb #3
.sh:    tstb
        beq  .v
        asla
        asla
        decb
        bra  .sh
.v:     rola                    ; the top two bits
        rola
        rola
        anda #3
        cmpa #3
        bne  .p
        clra
.p:     psha
        ldab kv_t2
        jsr  e_idxof
        ldx  #e_bd
        abx
        pula
        staa 0,x
        inc  kv_t2
        ldaa kv_t2
        cmpa #48
        bne  .s
        ldaa g_sside
        staa e_side
        jsr  eng_setup
.go:    clr  kv_t2
.l:     ldab kv_t2
        cmpb g_n
        beq  .d
        ldx  #g_rec
        abx
        ldab 0,x
        cmpb #48
        bhs  .bad
        jsr  e_idxof
        stab kv_t1
        jsr  status             ; a pass first if the side to move has no move
        cmpa #1
        bne  .m
        jsr  cm_pass
.m:     ldx  #BUF
        stx  e_fsp
        ldab kv_t1
        jsr  e_make
        tstb
        beq  .bad
        bsr  g_last
        inc  kv_t2
        bra  .l
.d:     jsr  DRV+DV_BOARD
        clc
        rts
.bad:   clr  g_n                ; damaged: a new game
        sec
        rts
; the last move: B = its flips, kv_t1 its square
g_last: stab kv_lfl
        ldaa kv_t1
        staa kv_lmv
        ldaa e_side
        eora #3
        staa kv_lwho
        rts

; ---------------------------------------------------------------------
; G_MOVE: kv_arg = a legal square for the side to move: played (its flips
; in BUF for OV_FX, which shows it), recorded, saved. C set if refused.
; ---------------------------------------------------------------------
g_move: ldab kv_arg
        stab kv_t1
        ldx  #BUF
        stx  e_fsp
        jsr  e_make
        tstb
        beq  .x
        jsr  g_last
        ldab kv_arg             ; into the record
        jsr  e_sqof
        ldx  #g_rec
        pshb
        ldab g_n
        abx
        pulb
        stab 0,x
        inc  g_n
        clr  kv_tip
        jsr  g_save
        clc
        rts
.x:     jsr  buzz
        sec
        rts

; the starting position and setting up from the board (from the engine: only needed here)
        include "../engine/eapi.asm"
