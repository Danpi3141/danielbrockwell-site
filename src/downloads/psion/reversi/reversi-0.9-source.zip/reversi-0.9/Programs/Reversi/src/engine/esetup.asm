; (from eapi.asm: OV_COACH needs only this)
; eng_setup: counts and square score from the board, e_me/e_op from e_side
eng_setup:
        clr  e_ns
        clr  e_nh
        clra
        clrb
        std  e_sqs
        ldab #11
.l:     stab e_sq
        ldx  #e_bd
        abx
        ldaa 0,x
        beq  .n
        cmpa #3
        beq  .n
        staa e_n                ; (e_n: a resident byte; the search's scratch is in slot A)
        ldx  #e_ns-1            ; that colour's count
        tab
        abx
        inc  0,x
        ldx  #e_valu
        ldab e_sq
        abx
        ldab 0,x
        clra
        subd #128
        std  e_tw
        ldaa e_n
        cmpa #1
        bne  .h
        ldd  e_sqs
        addd e_tw
        bra  .s
.h:     ldd  e_sqs
        subd e_tw
.s:     std  e_sqs
.n:     ldab e_sq
        incb
        cmpb #69
        bne  .l
        ldaa e_side
        jmp  e_sides
