#!/usr/bin/env python3
"""Milestone 1 probe pack: the launcher C4 (translated for the CM/XP), the bootstrap and the
probe as block C4K. Writes build/probe/probe.opk (a 32K Datapak)."""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import asm   # noqa: E402
import pack  # noqa: E402

BAD_OPL = (0, 9, 10, 13)
ARRAY = 5512


def encode_fixups(fix):
    out = bytearray()
    prev = 0
    for f in sorted(fix):
        d = f - prev
        if 0 <= d < 255:
            out.append(d)
        else:
            out += bytes([255, d >> 8, d & 255])
        prev = f
    return len(fix).to_bytes(2, 'big') + len(out).to_bytes(2, 'big') + bytes(out)


def launcher_lines(name, boot, total, tail):
    poke = []
    for at in range(0, len(boot), 64):
        piece = bytes(boot[at:at + 64])
        lit = '"' + piece.decode('latin-1').replace('"', '""') + '"'
        poke += ['i%%=%d' % at, 'DO', 'POKEB a%%+i%%,ASC(MID$(%s,i%%-%d,1))' % (lit, at - 1),
                 'i%=i%+1', 'UNTIL i%%=%d' % (at + len(piece))]
    return [name + ':', 'LOCAL m%%(%d),v%%(9),i%%,a%%' % ((total + 1) // 2),
            'a%%=ADDR(m%%())+%d' % (total - len(boot))] + poke + [
            'v%%(1)=ADDR(m%%()) :v%%(2)=%d' % total, 'i%=USR(a%,ADDR(v%()))'] + tail


def main():
    out = os.path.join(ROOT, 'build', 'probe')
    os.makedirs(out, exist_ok=True)
    inc = [os.path.join(ROOT, 'src')]
    k = asm.assemble(os.path.join(ROOT, 'src', 'probe', 'probe.asm'), origin=0, incdirs=inc)
    kblock = len(k.out).to_bytes(2, 'big') + bytes(k.out) + encode_fixups(k.fix)
    b = asm.assemble(os.path.join(ROOT, 'src', 'launch', 'boot.asm'), origin=0, incdirs=inc)
    assert not b.fix, 'bootstrap not position independent'
    boot = bytes(b.out)
    assert not [v for v in boot if v in BAD_OPL], 'bootstrap holds bytes OPL strings cannot'
    lines = launcher_lines('C4', boot, ARRAY, [
        'CLS :PRINT "I";i%', 'GET', 'CLS :PRINT "M";v%(7)', 'GET', 'CLS :PRINT "S";v%(8);" ";v%(9)', 'GET'])
    lp = os.path.join(out, 'C4.opl')
    with open(lp, 'w', encoding='latin-1', newline='\n') as f:
        f.write('\n'.join(lines) + '\n')
    img = pack.PackImage('datapak', 32, target='cm')
    img.add_opl(lp)
    img.add_data('C4K', kblock)
    size, used = img.write(os.path.join(out, 'probe.opk'))
    print('probe %d bytes, boot %d bytes, pack %d of %dK' % (len(k.out), len(boot), used, size))


if __name__ == '__main__':
    main()
