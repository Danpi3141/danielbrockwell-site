// Searches on the 6303 against the reference: move, score, depth, positions, exact flag, and
// the seed afterwards. Positions from random games, every stage, every level.
// node t_search.js [positions] [levels e.g. 1,2,3,8]
'use strict';
const { Harness } = require('./harness.js');
const { Engine, LEVELS, rnd } = require('../../ref/engine.js');
const h = new Harness();
const npos = +(process.argv[2] || 20);
const levels = (process.argv[3] || '1,2,3,4,5,6').split(',').map(Number);
const st = { seed: 4242 };
const pos = [];
while (pos.length < npos) {
  const e = new Engine();
  const stop = 4 + (rnd(st) % 44);
  let passes = 0;
  for (let ply = 0; ply < stop; ply++) {
    const l = e.legal();
    if (!l.length) { e.pass(); if (++passes === 2) break; continue; }
    passes = 0;
    e.make(l[(rnd(st) * l.length) >> 8]);
  }
  if (e.legal().length) pos.push([Array.from(e.bd), e.side]);
}
let bad = 0, n = 0, cyc = 0, nodes = 0;
const t0 = Date.now();
for (const [bd, side] of pos) {
  for (const lv of levels) {
    const seed = 1 + n * 31;
    const e = new Engine();
    e.setBoard(bd, side);
    const L = LEVELS[lv];
    const r = e.think({ level: lv, seed });
    h.setPos(bd, side);
    const before = JSON.stringify(h.state());
    const a = h.think({ nodes: L.nodes, depth: L.depth, noise: L.noise, exact: L.exact, seed });
    if (JSON.stringify(h.state()) !== before) { bad++; console.log('the board changed in the search: L' + lv, JSON.stringify(bd), side); }
    const ex = r.margin ? 2 : r.exact ? 1 : 0;
    const same = a.move === r.move && a.score === r.score && a.nodes === r.nodes && a.exact === ex &&
      (ex === 2 || a.depth === r.depth) && a.seed === e.seed;
    n++; cyc += a.cycles; nodes += a.nodes;
    if (!same) {
      bad++;
      if (bad <= 8) console.log(`pos ${pos.indexOf(pos.find(p => p[0] === bd))} L${lv} empties ${bd.filter(v => v === 0).length}: 6303 ${JSON.stringify(a)} ref ${JSON.stringify({ move: r.move, score: r.score, depth: r.depth, nodes: r.nodes, exact: ex, seed: e.seed })}`);
    }
  }
}
console.log(`${n} searches, ${bad} differ; ${nodes} positions in ${(cyc / 921600).toFixed(1)} s emulated: ${(nodes / (cyc / 921600)).toFixed(0)} positions/s (${Date.now() - t0} ms)`);
process.exit(bad ? 1 : 0);
