; Engine variables (cleared at the start). The includer gives their place:
; the board at EV_BD (80 bytes), the rest from EV (EV_LEN bytes).
e_bd    = EV_BD                 ; the board, 10x8 with its border
e_ns    = EV+0                  ; Solid's discs (e_ns-1+side = that side's count)
e_nh    = EV+1                  ; Hollow's
e_side  = EV+2                  ; to move: 1 Solid, 2 Hollow
e_sqs   = EV+3                  ; (2) square score, Solid minus Hollow
e_seed  = EV+5                  ; (3)
; the search's inputs
e_limit = EV+8                  ; (2) positions, 0 none
e_fixd  = EV+10                 ; levels 1-2: the depth
e_noise = EV+11
e_exend = EV+12                 ; the exact ending from this many empty squares
e_poll  = EV+13                 ; (2)
; its results
e_move  = EV+15
e_score = EV+16                 ; (2)
e_depth = EV+18
e_exact = EV+19
e_nodes = EV+20                 ; (3)
; working
e_ply   = EV+23
e_sq    = EV+24
e_fs0   = EV+25                 ; (2)
e_acc   = EV+27                 ; (2)
e_n     = EV+29
e_tw    = EV+30                 ; (2)
e_mode  = EV+32
e_cnt   = EV+33
e_emp   = EV+34
e_sqo   = EV+35                 ; (2) e_sqs before the last move made
e_onp   = EV+37                 ; (2) e_next's place in e_order
e_bstep = EV+39                 ; (2) the thinking bar's block: a tenth of e_limit (OV_BOOK)
EV_LEN  = 41
; (the evaluation's and the key's working bytes are in the search's scratch: esearch.asm)
