; Engine test image for harness.js: the engine, its variables and test drivers.
E_TT    = $6800
E_FS    = $6900
E_FR    = $6A00
        include "engine.asm"
        include "eapi.asm"
        include "epre.asm"
        include "epick.asm"
        include "evars.inc"
EV_BD:  rmb  80
EV:     rmb  48
E_PICK  = e_pick
; t_think: a search, as the game runs it (e_pre from OV_BOOK, then e_think)
t_think:jsr  e_pre
        jmp  e_think
; the kernel's hook: never stop
t_poll: clc
        rts
; t_eval: A = the parent's moves -> D = the evaluation
t_eval: staa e_pmob
        jmp  e_eval
; t_make: B = square, with the flip stack at E_FS
t_make: ldx  #E_FS
        stx  e_fsp
        jmp  e_make
; t_cmob: B = the moves of the side to move
t_cmob: ldaa e_side
        jmp  e_cmob

; t_perft: A = depth. t_cnt = the move sequences from here (a pass counts
; as a move; a game that ends sooner counts nothing)
t_perft:staa t_d
        clr  t_cnt
        clr  t_cnt+1
        clr  t_cnt+2
        ldd  #E_FS
        std  e_fsp
        clra
; t_pf: t_d = the depth left, A = 1 if the last move was a pass
t_pf:   ldab t_d
        bne  .go
        inc  t_cnt+2
        bne  .r
        inc  t_cnt+1
        bne  .r
        inc  t_cnt
.r:     rts
.go:    bsr  t_rx
        staa 2,x
        clr  1,x
        ldaa #11
        staa 0,x
.l:     ldab 0,x
        cmpb #69
        beq  .end
        ldx  #e_bd
        abx
        tst  0,x
        bne  .nx
        bsr  t_rx
        ldd  e_fsp
        std  3,x
        ldd  e_sqs
        std  5,x
        ldab 0,x
        jsr  e_make
        tstb
        beq  .nx
        bsr  t_rx
        inc  1,x
        dec  t_d
        clra
        bsr  t_pf
        inc  t_d
        bsr  t_rx
        ldd  3,x
        std  e_fs0
        ldd  5,x
        std  e_sqs
        ldab 0,x
        jsr  e_undo
.nx:    bsr  t_rx
        inc  0,x
        bra  .l
.end:   tst  1,x
        bne  .r
        tst  2,x
        bne  .r
        jsr  e_pass
        dec  t_d
        ldaa #1
        bsr  t_pf
        inc  t_d
        jmp  e_pass
; X = this depth's record: square, any, passed, flip stack (2), square score (2)
t_rx:   ldab t_d
        aslb
        aslb
        aslb
        ldx  #t_rec
        abx
        rts
t_d:    rmb  1
t_cnt:  rmb  3
t_rec:  rmb  8*12
