; =====================================================================
; OV_FX: the animations during a game: the falling disc and the emptying
; board (stretch goals 5 and 10) and the Psion's newest disc (2). (The
; winning four and the draw sweep are in OV_END.) The board is changed
; only for the picture; the real position follows from the engine
; afterwards. Waits in the falls leave keys in the buffer.
; =====================================================================
        include "../defs.inc"

HV_GET  = 0
HV_SET  = 1

        jmp  fx_fall
        jmp  fx_empty
        jmp  fx_mark

; X_FALL, kv_col = column (one with room): the move goes into the record;
; the side to move's disc falls from the top to its landing cell; then the
; move is made, shown and ticked, and ends with the save, or with the end
; of the game (kernel's game_over, which saves). Until 19 Nov the kernel's
; play_move did all but the record and the fall.
fx_fall:
        ldaa kv_col
        ldab g_n
        jsr  rec_put
        inc  g_n
        ldaa g_mode             ; two players: the next move's timer starts afresh
        deca                    ; (kv_xsc holds its seconds: OV_PLAY2)
        bne  .t
        clr  kv_xsc
.t:
        if   FX_FALL
        tst  g_psion            ; the demo: line 1 shows each move
        beq  .f
        ldaa g_psion
        cmpa #3
        bne  .f
        jsr  lb_clr
        jsr  side_to_move
        ldx  #fx_sol
        cmpa #1
        beq  .n
        ldx  #fx_hol
.n:     jsr  lb_fcl
        jsr  lb_s
        fcl  " col "
        ldaa kv_col
        adda #'1'
        jsr  lb_ch
        clra
        jsr  lb_put
.f:     ldaa kv_col
        staa fx_c
        tab
        ldx  #e_land
        abx
        ldaa fx_c
        ldab #7
        mul
        stab fx_c7
        ldab 0,x
        subb fx_c7
        stab fx_land            ; its row
        jsr  side_to_move
        staa fx_v
        ldab #5
.r:     cmpb fx_land
        bls  .x
        stab fx_r
        bsr  fx_cell            ; the disc in row r
        ldaa #1
        bsr  fx_wait
        clr  fx_v+1             ; and gone again
        ldab fx_r
        bsr  fx_cel0
        ldab fx_r
        decb
        bra  .r
.x:
        endif
        ldaa kv_col             ; made
        jsr  e_make
        ldab #0
        rolb
        stab fx_four            ; 1: it made four
        ldaa kv_col             ; shown: row = the cell just filled - column * 7
        ldab #7
        mul
        stab fx_c7
        ldab kv_col
        ldx  #e_land
        abx
        ldab 0,x
        decb
        subb fx_c7
        ldaa kv_col
        jsr  DRV+DV_CELL
        ldx  #snd_tick
        jsr  snd_play
        tst  fx_four
        beq  .full
        jsr  side_to_move       ; four: the mover (the other side now) wins
        eora #3
        jmp  game_over
.full:  ldaa e_n
        cmpa #42
        bne  .sv
        ldaa #3                 ; a full board: a draw
        jmp  game_over
.sv:    ldd  #OV_GAME*256+G_SAVE
        jmp  ov_call

; B = row of column fx_c: the cell set to fx_v (fx_cel0: emptied) and shown
fx_cel0:
        ldaa #0
        bra  fx_c2
fx_cell:
        ldaa fx_v
fx_c2:  pshb
        addb fx_c7
        ldx  #e_bd
        abx
        staa 0,x
        pulb
        pshx
        ldaa fx_c
        jsr  DRV+DV_CELL
        pulx
        clr  0,x                ; (the board as it was: the cell was empty)
        rts

; A = frames: wait (keys stay in the buffer)
fx_wait:
        adda TMW_FRAM+1
.l:     cmpa TMW_FRAM+1
        bne  .l
        rts

; the discs drop out of the bottom, row by row
fx_empty:
        ldaa #6
        staa fx_r
.step:  ldx  #e_bd              ; every column one row down
.col:   ldab #5
.sh:    ldaa 1,x
        staa 0,x                ; (rows 1-5: never the stop row)
        inx
        decb
        bne  .sh
        clr  0,x                ; the top cell empty
        inx
        inx                     ; past the stop row
        cpx  #e_bd+49
        bne  .col
        jsr  DRV+DV_BOARD
        ldaa #2
        bsr  fx_wait
        dec  fx_r
        bne  .step
        ldd  #OV_GAME*256+G_NEWG  ; then the new game (kv_arg = mode)
        jmp  ov_call

; ---------------------------------------------------------------------
; X_MARK, after the Psion's move: a solved search's value into the
; history (at the ply it moved from); one player, the game going on:
; its disc blinks twice; the demo: a pause of a second, in which a key
; stops it. A = C_MENU (the demo stopped) or 0.
; ---------------------------------------------------------------------
fx_mark:
        ldaa kv_xsc
        beq  .bl
        eora #$80               ; the Psion's score
        tab
        ldaa #2                 ; 0 a draw, above a win, below a loss
        tstb
        beq  .h
        ldaa #1
        tstb
        bpl  .h
        ldaa #3
.h:     ldab g_n
        decb
        jsr  hv_set
.bl:    ldaa g_mode             ; the demo: a pause between moves
        cmpa #2
        beq  .demo
        tst  g_over
        bne  .x
        jsr  pn_clear           ; ("Thinking" gone)
        ldab g_n
        decb
        jsr  rec_get            ; its column
        staa fx_c
        ldab #7
        mul
        stab fx_c7
        ldab fx_c
        ldx  #e_land
        abx
        ldab 0,x
        decb                    ; its cell
        ldx  #e_bd
        abx
        stx  fx_px
        subb fx_c7
        stab fx_r               ; its row
        ldaa 0,x
        staa fx_v
        ldaa #4                 ; off, on, off, on
        staa fx_land
.l:     ldx  fx_px
        ldaa 0,x
        beq  .on
        clr  0,x
        bra  .dr
.on:    ldaa fx_v
        staa 0,x
.dr:    ldaa fx_c
        ldab fx_r
        jsr  DRV+DV_CELL
        ldaa TMW_FRAM+1         ; 4 frames, unless a key is waiting (left for later)
        staa fx_t
.p:     os   KB$TEST
        tstb
        bne  .stop
        ldaa TMW_FRAM+1
        suba fx_t
        cmpa #4
        blo  .p
        dec  fx_land
        bne  .l
.x:     clra                    ; (no command)
        rts
.stop:  ldx  fx_px              ; a key: the disc back
        ldaa fx_v
        staa 0,x
        ldaa fx_c
        ldab fx_r
        jsr  DRV+DV_CELL
        bra  .x
.demo:  tst  kv_kstop           ; a key (one that stopped its search, or one now)
        bne  .m                 ; stops the demo: A = C_MENU
        ldaa #20
        jsr  key_wait
        tstb
        beq  .x
.m:     clr  kv_kstop
        ldaa #C_MENU
        rts

        include "khist.asm"

REC_PUT = 1
        include "krec.asm"

fx_sol: fcl  "Solid"
fx_hol: fcl  "Hollow"
fx_c:   fcb  0
fx_c7:  fcb  0
fx_land: fcb 0
fx_r:   fcb  0
fx_v:   fdb  0
fx_px:  fdb  0
fx_t:   fcb  0
fx_four: fcb 0
