; ---------------------------------------------------------------------
; (Included by each overlay that shows a list: OV_MENU, OV_SET, OV_SETUP.
; It costs pack space three times but no RAM in the kernel.)
; menu: X = a list of strings (each with a leading length), A = how many,
; B = the item to start on. Shown in the panel, kv_plines at a time, the
; chosen one marked '>'. UP/DOWN move (the list scrolls), a letter jumps
; to the next item starting with it, EXE takes it. Out: A = its number,
; or $FF for ON/CLEAR. (LEFT/RIGHT come back as $FE/$FD with B = item,
; for menus with values: mn_lr set.)
; ---------------------------------------------------------------------
; (MENU_V = 1: only menu_v, a menu with values (OV_SET); 0: only menu, a plain list)
        if   MENU_V
menu_v: stx  mn_list            ; (mn_val, mn_lr set by the caller)
        else
menu:   stx  mn_list
        endif
        staa mn_n
        stab mn_i
        clr  mn_top
.draw:  ldaa mn_i               ; the first line shown: so the chosen one fits
        suba mn_top
        bcs  .up
        cmpa kv_plines
        blo  .ok
        ldaa mn_i
        suba kv_plines
        inca
        bra  .st
.up:    ldaa mn_i
.st:    staa mn_top
.ok:    clr  mn_ln
.ln:    jsr  lb_clr
        ldaa mn_top
        adda mn_ln
        cmpa mn_n
        bhs  .put
        psha
        ldab #' '
        cmpa mn_i
        bne  .m
        ldab #'>'
.m:     tba
        jsr  lb_ch
        pula
        bsr  mn_item            ; X = its string
        jsr  lb_fcl
        if   MENU_V
        ldx  mn_val             ; a value after it (settings)
        beq  .put
        ldaa mn_top
        adda mn_ln
        jsr  0,x
        endif
.put:   ldaa mn_ln
        jsr  lb_put
        inc  mn_ln
        ldaa mn_ln
        cmpa kv_plines
        bne  .ln
.key:   clra
        jsr  key_wait
        ldaa mn_i
        cmpb #K_UP
        bne  .dn
        deca
        bpl  .go
        ldaa mn_n
        deca
        bra  .go
.dn:    cmpb #K_DOWN
        bne  .ex
        inca
        cmpa mn_n
        blo  .go
        clra
.go:    staa mn_i
        jmp  .draw
.ex:    cmpb #K_EXE
        beq  .x
        ldaa #$FF
        cmpb #K_ON
        beq  .x
        if   MENU_V
        tst  mn_lr
        beq  .let
        ldaa #$FE
        cmpb #K_LEFT
        beq  .x
        ldaa #$FD
        cmpb #K_RIGHT
        beq  .x
        endif
.let:   stab mn_k               ; a letter: the next item that starts with it
        ldaa mn_i
        staa mn_t
.l:     inca
        cmpa mn_n
        blo  .c
        clra
.c:     cmpa mn_t
        beq  .key               ; none
        psha
        bsr  mn_item
        ldab 1,x
        pula
        cmpb mn_k
        bne  .l
        bra  .go
.x:     ldab mn_i
        rts

; A = item number: X = its string
mn_item:
        ldx  mn_list
.l:     tsta
        beq  .x
        ldab 0,x
        incb
        abx
        deca
        bra  .l
.x:     rts

mn_list: fdb 0
        if   MENU_V
mn_val: fdb  0
mn_lr:  fcb  0
        endif
mn_n:   fcb  0
mn_i:   fcb  0
mn_top: fcb  0
mn_ln:  fcb  0
mn_k:   fcb  0
mn_t:   fcb  0
