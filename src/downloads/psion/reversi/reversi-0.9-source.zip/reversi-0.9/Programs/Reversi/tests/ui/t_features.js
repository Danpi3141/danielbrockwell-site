// The features through the keys, on each model given (default cm lz64).
'use strict';
const { Game, assert } = require('./lib.js');
const R = require('../../ref/rules.js');

function menu(g, item) {           // MODE, then the item by its first letter(s) and UP/DOWN, EXE
  g.waitHuman();
  g.key('MODE', 0.6);
  const items = ['New game', 'Take back', 'Tip', 'Swap sides', 'Level', 'Players', 'Settings', 'Set up', 'Tally', 'Move list', 'Review', 'Export', 'Import', 'Help', 'Quit'];
  const i = items.indexOf(item);
  for (let k = 0; k < i; k++) g.key('DOWN', 0.25);
  assert(g.panel().some(l => l.includes('>' + item.slice(0, 10))), 'menu shows ' + item + '\n' + g.text());
  g.key('EXE', 0.8);
}

function run(model) {
  const g = new Game(model);
  g.start();
  const log = (m) => console.log(`[${model}] ${m}`);
  // 1. a move, the Psion's reply, leave and resume
  g.poke('st_level', 1);
  g.play('d2');
  g.waitHuman();
  const n1 = g.peek('g_n'), b1 = g.board().join('/');
  assert(n1 === 2, 'two moves made: ' + n1);
  menu(g, 'Quit');
  g.waitFor(() => /Find|FIND|PROG|Prog/.test(g.text()), 10);
  g.start();
  g.waitHuman();
  assert(g.peek('g_n') === n1 && g.board().join('/') === b1, 'resumed the same game\n' + g.text());
  log('save and resume ok');
  // 2. take back: back to the start (your move and the reply)
  g.key('DEL', 1.5);
  g.waitHuman();
  assert(g.peek('g_n') === 0, 'take back to move 0: ' + g.peek('g_n'));
  log('take back ok');
  // 3. tip: the cursor goes to the tip's square
  g.key('T', 0.1);
  g.waitFor(() => /\[/.test(g.prompt()), 5, 0.05);
  g.waitHuman();
  const tip = g.peek('e_move');
  const pr = g.prompt();
  assert(pr.includes(R.name(tip)), 'the tip ' + R.name(tip) + ' in the prompt: ' + pr);
  log('tip ok: ' + pr.trim());
  // 4. an illegal square
  g.key('A', 0.2); g.key('U', 0.3);
  assert(/a: illegal|a1: illegal/.test(g.prompt()), 'illegal shown: ' + g.prompt());
  g.m.runSeconds(1.5);
  log('illegal ok');
  // 5. confirm off: the row plays at once
  g.poke('st_confirm', 1);
  g.waitHuman();
  g.key('E', 0.2); g.key('O', 1.0);         // e4? (not legal at the start) -> try c3
  g.waitHuman();
  if (g.peek('g_n') === 0) { g.key('C', 0.2); g.key('W', 1.0); }
  g.waitHuman();
  assert(g.peek('g_n') === 2, 'played without EXE: ' + g.peek('g_n'));
  g.poke('st_confirm', 0);
  log('confirm off ok');
  // 6. swap sides: the Psion takes the side to move (you have Solid now)
  const before = g.peek('g_psion');
  menu(g, 'Swap sides');
  g.waitHuman(120);
  assert(g.peek('g_psion') !== before, 'the Psion changed sides');
  log('swap ok: Psion ' + before + ' -> ' + g.peek('g_psion'));
  // 7. two players: no Psion; a move each by the keys
  menu(g, 'Players');
  g.key('RIGHT', 0.3);                      // One -> Two
  g.key('EXE', 0.8);
  assert(g.peek('st_players') === 1 && g.peek('g_psion') === 0, 'two players: ' + g.peek('st_players') + ' ' + g.peek('g_psion'));
  g.waitHuman();
  assert(/^(S|H): [a-h][1-6] \+[0-9]/.test(g.prompt()), 'side named in the prompt (S: or H:, the square, its flips): ' + g.prompt());
  const n7 = g.peek('g_n');
  g.key('EXE', 1.0); g.waitHuman(); g.key('EXE', 1.0); g.waitHuman();
  assert(g.peek('g_n') === n7 + 2, 'two moves by the keys');
  log('two players ok: ' + g.prompt().trim());
  // 8. demo: plays by itself; a key stops it (the menu)
  menu(g, 'Players');
  g.key('RIGHT', 0.3);                      // Two -> Demo
  g.key('EXE', 0.3);
  const n8 = g.peek('g_n');
  g.m.runSeconds(20);
  assert(g.peek('g_n') > n8 + 1, 'the demo played: ' + n8 + ' -> ' + g.peek('g_n'));
  g.key('SPACE', 1.0);
  g.waitFor(() => g.panel().some(l => l.includes('>New game')), 30);
  assert(g.panel().some(l => l.includes('>New game')), 'a key stopped the demo: the menu\n' + g.text());
  g.key('ON', 0.5);                         // out of the menu: the demo goes on: back to one player
  g.poke('st_players', 0);
  g.waitFor(() => false, 1);
  log('demo ok');
  return g;
}

for (const model of (process.argv[2] || 'cm,lz64').split(',')) {
  const t = Date.now();
  run(model);
  console.log(`[${model}] done (${Date.now() - t} ms)`);
}
