// The spec's ending check: 200 positions with 8 empty squares give the reference's exact score
// (the disc margin), and that score is the true one (a plain minimax to the end, in JS).
'use strict';
const { Harness } = require('./harness.js');
const { Engine, rnd } = require('../../ref/engine.js');
const R = require('../../ref/rules.js');
const n = +(process.argv[2] || 200), E = +(process.argv[3] || 8);
function minimax(b, side, passed) {
  const ms = R.legalMoves(b, side);
  if (!ms.length) {
    if (passed) { const [s, h] = R.count(b); return side === 1 ? s - h : h - s; }
    return -minimax(b, 3 - side, true);
  }
  let best = -99;
  for (const m of ms) {
    const f = R.flipsFor(b, m, side);
    b[m] = side; for (const t of f) b[t] = side;
    const v = -minimax(b, 3 - side, false);
    b[m] = 0; for (const t of f) b[t] = 3 - side;
    if (v > best) best = v;
  }
  return best;
}
const h = new Harness({ build: false });
const st = { seed: 88 };
let bad = 0, done = 0, nodes = 0, cyc = 0;
while (done < n) {
  const e = new Engine();
  let passes = 0;
  while (e.empties() > E) {
    const l = e.legal();
    if (!l.length) { e.pass(); if (++passes === 2) break; continue; }
    passes = 0;
    e.make(l[(rnd(st) * l.length) >> 8]);
  }
  if (e.empties() !== E || !e.legal().length) continue;
  const seed = done + 1;
  const r = e.think({ nodes: 0, exact: E, seed });
  h.setPos(e.bd, e.side);
  const a = h.think({ nodes: 0, exact: E, seed });
  const truth = minimax(Uint8Array.from(e.bd), e.side, false);
  if (a.score !== r.score || a.move !== r.move || a.nodes !== r.nodes || a.exact !== 2 || r.score !== truth) {
    bad++; console.log('pos', done, '6303', JSON.stringify(a), 'ref', r.move, r.score, r.nodes, 'true', truth);
  }
  nodes += a.nodes; cyc += a.cycles; done++;
}
console.log(`${done} positions with ${E} empty squares: ${bad} differ; ${(nodes / done).toFixed(0)} positions each, ${(cyc / 921600 / done).toFixed(2)} s each`);
process.exit(bad ? 1 : 0);
