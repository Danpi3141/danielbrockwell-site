// Starts the game on a model and prints the screens: title, first turn, a move, the Psion's reply.
'use strict';
const { Game } = require('./lib.js');
const model = process.argv[2] || 'cm';
const g = new Game(model);
g.m.runProc('REV', 'B');
for (let i = 0; i < 8; i++) {
  g.m.runSeconds(0.5);
  if (i === 1 || i === 7) console.log(`--- ${(i + 1) * 0.5}s\n` + g.text());
}
g.findBase();
console.log('base', g.base.toString(16), 'plines', g.base >= 0 ? g.peek('kv_plines') : '-');
g.m.runSeconds(2);
console.log('--- turn\n' + g.text());
