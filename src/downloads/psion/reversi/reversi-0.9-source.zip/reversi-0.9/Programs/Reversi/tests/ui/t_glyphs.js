// The board on the screen against the position: two lines, the 8 glyphs' dot rows built from the
// board (2x2 cells, Solid all four, Hollow the diagonal, a gap dot between) in the 4x2 block;
// four lines, each character the stacked pair's code and the 8 glyphs as the spec draws them.
// Checked at your turns through whole games (the cursor's square as the driver shows it).
'use strict';
const { Game, assert } = require('./lib.js');

const PAT = { 1: [[0x18, 0x18], [0x03, 0x03]], 2: [[0x10, 0x08], [0x02, 0x01]], 3: [[0, 0x08], [0, 0x01]] };
const SD = 0x0E, SF = 0x1F, HO = 0x11;
const GL4 = [[SD, SF, SD, 0, SD, SF, SD, 0], [SD, SF, SD, 0, 0, 0, 0, 0], [0, 0, 0, 0, SD, SF, SD, 0], [SD, HO, SD, 0, SD, HO, SD, 0],
  [SD, HO, SD, 0, 0, 0, 0, 0], [0, 0, 0, 0, SD, HO, SD, 0], [SD, SF, SD, 0, SD, HO, SD, 0], [SD, HO, SD, 0, SD, SF, SD, 0]];
const MAP = [32, 2, 5, 1, 0, 6, 4, 7, 3];

function check(g) {
  const bd = g.bytes('e_bd', 80), ovs = g.peek('kv_ovs'), ovv = g.peek('kv_ovv');
  const v = (s) => (s === ovs ? ovv : bd[s]);
  const cells = g.m.cells(), udg = g.m.udgs();
  if (g.m.lines === 2) {
    const block = [cells[0], cells[1], cells[2], cells[3], cells[16], cells[17], cells[18], cells[19]];
    assert(block.join() === '0,1,2,3,4,5,6,7', 'the glyph block: ' + block);
    for (let gi = 0; gi < 8; gi++) {
      const want = [0, 0, 0, 0, 0, 0, 0, 0];
      for (let i = 0; i < 6; i++) {
        const r = 3 * (gi >> 2) + (i >> 1) + 1, c = 2 * (gi & 3) + (i & 1) + 1, x = v(r * 10 + c);
        if (!x) continue;
        const p = PAT[x][i & 1], dr = 3 * (i >> 1);
        want[dr] |= p[0]; want[dr + 1] |= p[1];
      }
      assert(udg[gi].join() === want.join(), `glyph ${gi}: ${udg[gi]} want ${want}`);
    }
  } else {
    for (let L = 0; L < 3; L++) for (let c = 1; c <= 8; c++) {
      const u = v((2 * L + 1) * 10 + c), l = v((2 * L + 2) * 10 + c);
      assert(cells[L * 20 + c - 1] === MAP[3 * u + l], `line ${L + 1} column ${c}: ${cells[L * 20 + c - 1]} want ${MAP[3 * u + l]}`);
    }
    assert(String.fromCharCode(...cells.slice(60, 68)) === 'ABCDEFGH', 'the column letters');
    for (let i = 0; i < 8; i++) assert(udg[i].join() === GL4[i].join(), `glyph ${i}: ${udg[i]}`);
  }
}

for (const model of (process.argv[2] || 'cm,lz64').split(',')) {
  const g = new Game(model);
  g.start();
  g.poke('st_level', 1);
  let n = 0;
  for (let t = 0; t < 120 && !g.over(); t++) {
    g.waitFor(() => g.over() || g.peek('g_over') || g.humanTurn(), 300, 0.2);
    if (g.over() || g.peek('g_over')) break;          // (the game over: no more of your turns)
    const kw = g.base + g.sym.key_wait[0], play = 5;
    for (let k = 0; k < 4; k++) {                     // at OV_PLAY's key waits: the screen settled (both cursor phases)
      let at = false;
      for (let i = 0; i < 50 && !at; i++) { if (g.m.runTo([kw], 921600) === kw && g.peek('kv_res') === play) at = true; else g.m.cpu.execute(1); }
      if (!at) break;
      check(g); n++;
      g.m.cpu.execute(1);
    }
    g.key(['EXE', 'RIGHT', 'DOWN', 'EXE'][t % 4], 0.5);
  }
  console.log(`[${model}] ${n} screens checked against the board`);
}
