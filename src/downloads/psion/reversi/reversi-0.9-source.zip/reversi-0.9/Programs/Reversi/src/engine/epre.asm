; =====================================================================
; e_pre: the start of a search, run just before e_think (in the game from
; OV_BOOK, which is still in slot A: think_run). The results cleared, the
; search table cleared, the side to move's moves counted (e_exm $FF: none),
; the empty squares (e_emp0) and the exact ending decided (e_exm 1, its
; count 4x the level's in e_lim). It writes the search's variables, which
; lie over slot A from E_KIL: in OV_BOOK this code must lie below that
; (tools/build.py checks).
; =====================================================================
e_pre:  clra
        clrb
        std  e_score
        staa e_depth
        staa e_exact
        staa e_exm
        ldaa #NONE
        staa e_move
        ldx  #E_TT
.t:     clr  0,x
        inx
        cpx  #E_TT+256
        bne  .t
        ldaa e_side
        jsr  e_cmob
        tstb
        bne  .go
        dec  e_exm              ; no move
        rts
.go:    jsr  e_empt
        stab e_emp0
        cmpb e_exend
        bhi  .x
        clr  e_lim              ; the exact ending; dropped at 4x the count
        ldd  e_limit
        asld
        rol  e_lim
        asld
        rol  e_lim
        std  e_lim+1
        inc  e_exm
.x:     rts
e_pre_end:
