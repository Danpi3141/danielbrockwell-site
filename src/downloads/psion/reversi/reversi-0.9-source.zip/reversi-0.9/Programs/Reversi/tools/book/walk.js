// The opening book walked exactly as OV_WALK walks it (src/screens/ov_walk.asm), for tests.
// Format 3 (tools/book/encode.js): a bit stream whose moves are indexes among the legal moves, so
// the walk keeps the position (in the book's orientation) as it goes.
// bookReply(bin, rec, side, reps) -> board index of the book's reply, or 0; for the Psion Solid's
// first move it returns the four openings (OV_BOOK picks one at random).
'use strict';
const R = require('../../ref/rules.js');

const D2 = 11, C3 = 18;                 // squares 0-47

const bitsFor = (n) => n <= 1 ? 0 : Math.ceil(Math.log2(n));
function legalSq(b, side) { return R.legalMoves(b, side).map(R.sqOf).sort((a, c) => a - c); }
function playSq(b, sq, side) { const nb = b.slice(); R.play(nb, R.idxOf(sq), side); return nb; }

class Bits {
  constructor(bin, off) { this.bin = bin; this.p = off * 8; }
  get(n) { let v = 0; for (let i = 0; i < n; i++, this.p++) v = v * 2 + ((this.bin[this.p >> 3] >> (7 - (this.p & 7))) & 1); return v; }
}

// a stored move's node: { reply (square), kids, b2 (the position after the reply) }; the jump read
function node(bits, b, o, mover) {
  const b1 = playSq(b, o, mover);
  const M = legalSq(b1, 3 - mover);
  const reply = M[bits.get(bitsFor(M.length))];
  const kids = bits.get(1);
  let jump = -1;
  if (kids && bits.get(1)) jump = bits.get(12);
  return { reply, kids, jump, b2: kids ? playSq(b1, reply, 3 - mover) : null };
}
// past a stored move and everything beneath it
function skipNode(bits, b, o, mover) {
  const n = node(bits, b, o, mover);
  if (!n.kids) return;
  if (n.jump >= 0) bits.p += n.jump;
  else skipGroup(bits, n.b2, mover);
}
// the group's stored moves (square order) and which are there
function groupHead(bits, b, mover) {
  const L = legalSq(b, mover);
  const all = bits.get(1);
  return L.filter(() => true).map(o => ({ o, there: all ? true : !!bits.get(1) }));
}
function skipGroup(bits, b, mover) {
  for (const { o, there } of groupHead(bits, b, mover)) if (there) skipNode(bits, b, o, mover);
}

function bookReply(bin, rec, side, reps = 99) {
  const n = rec.length;
  if (bin.length < 7 || bin[0] !== 3) return 0;
  if (((n ^ side) & 1) === 0) return 0;            // a pass has been
  if (n) {
    let k = n - 1;
    if (side === 1) k--;
    if ((k >> 1) >= reps) return 0;
  }
  let turn, tree, i;
  if (side === 1) {
    if (n === 0) return [D2, C3, 47 - D2, 47 - C3].map(R.idxOf);
    const m0 = rec[0];
    if (m0 === D2) { tree = 0; turn = 0; } else if (m0 === 47 - D2) { tree = 0; turn = 1; }
    else if (m0 === C3) { tree = 1; turn = 0; } else if (m0 === 47 - C3) { tree = 1; turn = 1; }
    else return 0;
    i = 1;
  } else {
    const m0 = rec[0];
    if (m0 === D2 || m0 === C3) turn = 0;
    else if (m0 === 47 - D2 || m0 === 47 - C3) turn = 1;
    else return 0;
    tree = 2; i = 0;
  }
  const map = (s) => turn ? 47 - s : s;
  const off = (bin[1 + 2 * tree] << 8) | bin[2 + 2 * tree];
  if (!off) return 0;
  const bits = new Bits(bin, off);
  const mover = 3 - side;                          // the opponent moves in the groups
  let b = tree === 2 ? R.newBoard() : playSq(R.newBoard(), tree ? C3 : D2, 1);
  for (;;) {
    const opp = map(rec[i]);
    let hit = null;
    for (const { o, there } of groupHead(bits, b, mover)) {
      if (o === opp) { if (!there) return 0; hit = node(bits, b, o, mover); break; }
      if (there) skipNode(bits, b, o, mover);
    }
    if (!hit) return 0;
    if (i + 1 === n) return R.idxOf(map(hit.reply));
    if (map(rec[i + 1]) !== hit.reply || !hit.kids) return 0;
    b = hit.b2;
    i += 2;
  }
}

// every line in the book: [sequence of squares 0-47 ending with the reply, tree]
function lines(bin) {
  const out = [];
  function group(bits, b, mover, prefix) {
    for (const { o, there } of groupHead(bits, b, mover)) {
      if (!there) continue;
      const n = node(bits, b, o, mover);
      const seq = [...prefix, o, n.reply];
      out.push(seq);
      if (n.kids) group(bits, n.b2, mover, seq);
    }
  }
  for (let t = 0; t < 3; t++) {
    const off = (bin[1 + 2 * t] << 8) | bin[2 + 2 * t];
    if (!off) continue;
    const b = t === 2 ? R.newBoard() : playSq(R.newBoard(), t ? C3 : D2, 1);
    group(new Bits(bin, off), b, t === 2 ? 1 : 2, t === 0 ? [D2] : t === 1 ? [C3] : []);
  }
  return out;
}

module.exports = { bookReply, lines, D2, C3 };
