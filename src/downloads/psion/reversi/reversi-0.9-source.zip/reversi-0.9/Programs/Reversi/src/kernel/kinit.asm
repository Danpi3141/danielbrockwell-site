; =====================================================================
; The start-up code: stored after the kernel's code (where the variables
; go), copied into slot A by the kernel's entry and run there once: it
; costs no RAM of its own. Clears the variables, finds the game's blocks,
; picks the screen driver from the model byte (switching an LZ to four
; lines), shows the title.
; =====================================================================
        include "../defs.inc"

kinit:  pula                    ; D = ADDR(v%()), pushed by the entry
        pulb
        ldx  KR_KEEP            ; REV's code must be just above the array (some
        cpx  #$847B             ; variables live in it: kvars.inc), as it is when
        beq  .run               ; REV runs REVG; not if REVG is run by itself
        sts  kv_sp
        clr  kv_four
        ldab #E_RUN
        jmp  quit
.run:
        ldx  #kv_first          ; the variables are not on the pack: clear them
.z:     clr  0,x
        inx
        cpx  #kv_end
        bne  .z
        ldx  #kh_first          ; and those in REVG's code (the bootstrap has run)
.h:     clr  0,x
        inx
        cpx  #kh_end
        bne  .h
        ldx  #kr_first          ; and in REV's
.r:     clr  0,x
        inx
        cpx  #kr_end
        bne  .r
        std  kv_vptr
        ldx  #THINKAT           ; the search's poll: OV_THINK's first byte
        stx  e_poll
        sts  kv_sp              ; (the launcher's return address is on top)
        xgdx
        ldd  0,x
        std  kv_base
        ldd  2,x
        std  kv_size
        ldaa 4,x
        staa kv_dev
        os   PK$QADD            ; B:X: where the bootstrap stopped reading REVK,
        stab kv_dir             ; just past the kernel: block 0, the overlays
        stab kv_dir+3
        stx  kv_dir+1
        stx  kv_dir+4
        os   PK$PKOF
        ldd  kv_dir+4           ; block 1, the book, after them (in_b1: filled in
        addd in_b1              ; by the build)
        std  kv_dir+4
        bcc  in_start
        inc  kv_dir+3
        bra  in_start
in_b1:  fdb  0

in_start:
        ldaa #DRV2              ; the model byte: 13, 14, 29, 30 have four lines
        ldab MODEL
        cmpb #13
        beq  .four
        cmpb #14
        beq  .four
        cmpb #29
        beq  .four
        cmpb #30
        bne  .drv
.four:  ldaa #1
        os   DP$MSET            ; four lines; A = the mode it replaced
        staa kv_omode
        inc  kv_four
        ldab #$80
        os   DP$CSET            ; the clock leaves the glyphs alone
        ldaa #DRV4
.drv:   staa kv_drv
        jsr  ov_load            ; (the board is clear: the variables were)
        jsr  DRV+DV_INIT
        os   KB$FLSH
        ldd  TMB_MIN            ; the seed from the clock's minutes and seconds
        eora FRC                ; (before any key)
        eorb FRC+1
        std  e_seed+1
        oraa #1                 ; (never all zero)
        staa e_seed
        jsr  pn_clear           ; the title
        jsr  lb_clr
        jsr  lb_s
        fcl  "REVERSI 8x6"
        clra
        jsr  lb_put
        ldaa #19                ; the credit: two lines from column 4 of line 2,
        tst  kv_four            ; four lines from column 8 of line 3
        beq  .cr
        ldaa #47
.cr:    clrb
        os   DP$STAT
        ldx  #in_cred
        ldab #13
        os   DP$PRNT
        bsr  in_drop
        ldaa #30                ; about 1.5 seconds, or until a key
        jsr  key_wait
        os   KB$FLSH
        jsr  DRV+DV_INIT        ; (the credit covered board characters)
        jsr  pn_clear
        jmp  kinit_done
in_cred:fcc  "Daniel+Claude"

; stretch goal 9, the title drop: the four starting discs fall down their
; columns into place (d4, e4, then d3, e3 on them). Only the picture: the
; board is set up properly afterwards. A key cuts it short.
in_drop:ldx  #in_tab
.d:     stx  in_p
        ldab 0,x                ; the square it falls to
        stab in_t
.c:     cmpb #20                ; its column, row 1
        blo  .f
        subb #10
        bra  .c
.f:     stab in_s
        ldx  in_p
        ldaa 1,x
        bsr  in_set             ; there for a moment
        ldab in_s
        cmpb in_t
        beq  .n                 ; it has landed
        ldaa #1
        bsr  in_wait
        bne  .x
        clra
        ldab in_s
        bsr  in_set
        ldab in_s
        addb #10
        bra  .f
.n:     ldx  in_p
        inx
        inx
        cpx  #in_tab+8
        bne  .d
.x:     rts

; A = disc (0 empty), B = square: into the board and shown
in_set: ldx  #e_bd
        abx
        staa 0,x
        tba
        jmp  DRV+DV_SQ

; A = frames: wait; Z clear (and the wait cut short) if a key is waiting
in_wait:adda TMW_FRAM+1
        staa in_w
.l:     os   KB$TEST
        tstb
        bne  .k
        ldaa in_w
        cmpa TMW_FRAM+1
        bne  .l
.k:     rts

in_tab: fcb  44,1, 45,2, 34,2, 35,1   ; d4 Solid, e4 Hollow, d3 Hollow, e3 Solid
in_p:   fdb  0
in_t:   fcb  0
in_s:   fcb  0
in_w:   fcb  0
