// The opening book's bytes (data/book.bin) from its trees (data/book.json, written by gen_book.js).
//   node tools/book/encode.js [data/book] [jump]     re-encodes <base>.bin from <base>.json
// Format 3 (20 Nov), a bit stream (the high bit of each byte first): a 7-byte header (3, then the
// byte offsets of three trees: the Psion Solid having opened d2, having opened c3, the Psion
// Hollow; 0 for none), then each tree from a byte boundary. A tree is a group: the opponent's
// moves stored at a position (the opponent to move), each with the Psion's reply:
//   1 bit: every legal opponent move is stored; if not, a bit for each legal move (1: stored),
//          the legal moves in square order (a1, b1 ... h6);
//   then for each stored move, in square order:
//     the reply: its index among the Psion's legal moves there (square order), in as few bits as
//       that many moves need (none if one);
//     1 bit: positions follow beneath; if so,
//       1 bit: a jump: if so, 12 bits, the length of the group beneath in bits, so a walk can
//         pass over it; stored when the group is longer than JUMP bits (else it is passed over by
//         reading it, which needs the positions);
//       the group beneath (at the position after the reply).
// Only legal moves can be stored, and the book has no passes. Read by tools/book/walk.js and
// OV_WALK. (Format 2 was 2 bytes a position, format 1 3 bytes.)
'use strict';
const fs = require('fs');
const path = require('path');
const R = require('../../ref/rules.js');

const JUMP = 32;               // (20 Nov: the worst lookup about 0.9 s on the 6303; 48: 1.2 s, 24: 0.76 s)
const D2 = R.sqOf(R.parse('d2')), C3 = R.sqOf(R.parse('c3'));   // (square numbers 0-47)

function count(g) { return g.reduce((s, n) => s + 1 + count(n.kids), 0); }
const bitsFor = (n) => n <= 1 ? 0 : Math.ceil(Math.log2(n));
// legal moves of `side` on board b, ascending square number (0-47)
function legalSq(b, side) { return R.legalMoves(b, side).map(R.sqOf).sort((a, c) => a - c); }
function playSq(b, sq, side) { const nb = b.slice(); R.play(nb, R.idxOf(sq), side); return nb; }

function encodeGroup(g, b, side, jump) {
  const out = [];
  const put = (v, n) => { for (let i = n - 1; i >= 0; i--) out.push((v >> i) & 1); };
  const L = legalSq(b, side);
  const byOpp = new Map(g.map(n => [R.sqOf(n.opp), n]));
  for (const o of byOpp.keys()) if (!L.includes(o)) throw new Error('a stored move is not legal');
  const all = L.every(o => byOpp.has(o));
  put(all ? 1 : 0, 1);
  if (!all) for (const o of L) put(byOpp.has(o) ? 1 : 0, 1);
  for (const o of L) {
    const n = byOpp.get(o);
    if (!n) continue;
    const b1 = playSq(b, o, side);
    const M = legalSq(b1, 3 - side);
    const r = M.indexOf(R.sqOf(n.reply));
    if (r < 0) throw new Error('a reply is not legal');
    put(r, bitsFor(M.length));
    put(n.kids.length ? 1 : 0, 1);
    if (n.kids.length) {
      const b2 = playSq(b1, R.sqOf(n.reply), 3 - side);
      if (!legalSq(b2, side).length) throw new Error('a pass in the book');
      const sub = encodeGroup(n.kids, b2, side, jump);
      if (sub.length > jump) {
        if (sub.length > 4095) throw new Error('a group of ' + sub.length + ' bits');
        put(1, 1); put(sub.length, 12);
      } else put(0, 1);
      out.push(...sub);
    }
  }
  return out;
}

function encode(trees, jump = JUMP) {
  const body = [];
  const offs = [];
  const starts = [[playSq(R.newBoard(), D2, 1), 2], [playSq(R.newBoard(), C3, 1), 2], [R.newBoard(), 1]];
  trees.forEach((tr, t) => {
    if (!tr.length) { offs.push(0); return; }
    offs.push(7 + body.length);
    const bits = encodeGroup(tr, starts[t][0], starts[t][1], jump);
    while (bits.length % 8) bits.push(0);
    for (let i = 0; i < bits.length; i += 8) body.push(bits.slice(i, i + 8).reduce((v, x) => v * 2 + x, 0));
  });
  if (7 + body.length > 0xFFFF) throw new Error('book too big');
  return Buffer.from([3, offs[0] >> 8, offs[0] & 255, offs[1] >> 8, offs[1] & 255, offs[2] >> 8, offs[2] & 255, ...body]);
}

module.exports = { encode, count, JUMP };

if (require.main === module) {
  const base = path.join(__dirname, '..', '..', process.argv[2] || 'data/book');
  const j = JSON.parse(fs.readFileSync(base + '.json', 'utf8'));
  const bin = encode(j.trees, +(process.argv[3] || JUMP));
  fs.writeFileSync(base + '.bin', bin);
  console.log(`${base}.bin: ${j.trees.map(count).join(' + ')} positions, ${bin.length} bytes`);
}
