; =====================================================================
; OV_MENU: the menu (MODE). UP/DOWN move, a letter jumps to the next item
; starting with it, EXE takes it, ON/CLEAR goes back. Returns a command
; in A, B its argument.
; =====================================================================
        include "../defs.inc"

        jmp  mu_start

mu_start:
        ldx  #mu_items
        ldaa #15
        clrb                    ; New game first (as after a result)
        jsr  menu
        psha
        jsr  pn_clear
        pula
        cmpa #$FF
        beq  .none
        tab
        ldx  #mu_cmds
        abx
        ldaa 0,x
        ldab 15,x               ; (its argument: the settings' first line)
        rts
.none:  clra
        rts

mu_cmds: fcb C_NEW,C_BACK,C_TIP,C_SWAP,C_LEVEL,C_PLAYERS,C_SET,C_SETUP,C_TALLY,C_LIST,C_REVIEW,C_EXPORT,C_IMPORT,C_HELP,C_LEAVE
mu_args: fcb 0,0,0,0,0,1,0,0,0,0,0,0,0,0,0
mu_items:
        fcl  "New game"
        fcl  "Take back"
        fcl  "Tip"
        fcl  "Swap sides"
        fcl  "Level"
        fcl  "Players"
        fcl  "Settings"
        fcl  "Set up"
        fcl  "Tally"
        fcl  "Move list"
        fcl  "Review"
        fcl  "Export"
        fcl  "Import"
        fcl  "Help"
        fcl  "Quit"

MENU_V  = 0
        include "../kernel/kmenu.asm"
