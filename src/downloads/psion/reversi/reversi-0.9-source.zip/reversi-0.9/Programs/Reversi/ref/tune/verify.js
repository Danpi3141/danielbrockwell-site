// A weights file against the defaults: 2 x openings games at each level.
// node ref/tune/verify.js opts.json levels openings
'use strict';
const fs = require('fs');
const { match } = require('../match.js');
(async () => {
  const j = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
  const o = j.opts || j;
  console.log(JSON.stringify(o));
  for (const lv of (process.argv[3] || '3,5,7').split(',').map(Number)) {
    const t = Date.now();
    const r = await match({ a: { level: lv, opts: o }, b: { level: lv }, openings: +(process.argv[4] || 1000), plies: 8, oseed: 0x51515 });
    console.log(`L${lv}: ${r.pct.toFixed(1)}% of ${r.games}, margin ${r.margin.toFixed(2)} (${Date.now() - t} ms)`);
  }
})();
