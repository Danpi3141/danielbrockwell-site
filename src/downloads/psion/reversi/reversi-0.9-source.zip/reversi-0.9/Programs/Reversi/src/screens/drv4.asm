; =====================================================================
; Four-line screen driver (LZ, LZ64). Loaded at DRV.
; The board: 8 characters wide on lines 1-3, each character two squares
; (rows 1/2, 3/4, 5/6); ABCDEFGH under it on line 4. Column 9 is blank;
; the panel is 11 characters from column 10. The 8 glyphs are the 8
; stacked pairs that are not both empty, defined once.
; =====================================================================
        include "../defs.inc"

        jmp  d4_init
        jmp  d4_glyphs
        jmp  d4_sq
        jmp  d4_board
        rts

d4_init:
        ldaa #4
        staa kv_plines
        ldd  #$091D             ; the panel at column 10: positions 9, 29, 49, 69
        std  kv_ppos
        ldd  #$3145
        std  kv_ppos+2
        bsr  d4_glyphs
        clra
        clrb
        os   DP$STAT            ; cursor off
        ldaa #12
        os   DP$EMIT            ; clear
        ldaa #60                ; line 4: the column letters
        clrb
        os   DP$STAT
        ldx  #d4_let
        ldab #8
        os   DP$PRNT
        bra  d4_board
d4_let: fcc  "ABCDEFGH"

; the 8 glyphs straight into the display chip
d4_glyphs:
        ldab #$40
        bsr  lcd_cmd
        ldx  #d4_gl
.l:     ldab 0,x
        bsr  lcd_dat
        inx
        cpx  #d4_gl+64
        bne  .l
        rts

lcd_cmd:ldaa LCD_CTRL
        bmi  lcd_cmd
        stab LCD_CTRL
        rts
lcd_dat:ldaa LCD_CTRL
        bmi  lcd_dat
        stab LCD_DATA
        rts

; A = square index: the character holding it
d4_sq:  clrb                    ; B = the row, A = the column
.l:     suba #10
        bcs  .d
        incb
        bra  .l
.d:     adda #10
        decb                    ; the pair's upper row: odd rows
        andb #$FE
        incb
        staa d4_c
        stab d4_r
        ldaa #10
        mul
        addb d4_c               ; the upper square
        bsr  .one               ; its value
        staa d4_u
        addb #10
        bsr  .one               ; the lower
        psha
        ldaa d4_u               ; 3 * upper + lower
        tab
        asla
        aba
        pulb
        aba
        tab
        ldx  #d4_map
        abx
        ldaa 0,x
        psha
        ldaa d4_r               ; line = (row-1)/2, position = line*20 + column-1
        lsra
        ldab #20
        mul
        addb d4_c
        decb
        tba
        clrb
        os   DP$STAT
        pula
        os   DP$EMIT
        rts
; B = square: A = what it shows (B kept): an empty square where the side to
; move can play flashes slowly (kv_hph) while hints are on
.one:   ldx  #e_bd
        abx
        ldaa 0,x
        bne  .o
        tst  kv_hon
        beq  .o
        tst  kv_hph
        beq  .o
        pshb
        ldaa e_side
        jsr  e_flips
        ldaa e_side
        pshb
        jsr  e_sides
        pula
        pulb
        tsta
        beq  .o
        ldaa e_side
.o:     cmpb kv_ovs
        bne  .r
        ldaa kv_ovv
.r:     rts

; the whole board
d4_board:
        ldaa #11
.s:     psha
        bsr  d4_sq
        pula
        inca
        cmpa #19
        bne  .n
        ldaa #31
.n:     cmpa #39
        bne  .m
        ldaa #51
.m:     cmpa #59
        bne  .s
        rts

; (upper, lower) -> character: 0 empty, 1 Solid, 2 Hollow
d4_map: fcb  32,2,5, 1,0,6, 4,7,3
; glyphs: upper disc dot rows 0-2, lower 4-6
SD      = $0E                   ; .###.
SF      = $1F                   ; #####
HO      = $11                   ; #...#
d4_gl:  fcb  SD,SF,SD,0, SD,SF,SD,0     ; 0: Solid over Solid
        fcb  SD,SF,SD,0, 0,0,0,0        ; 1: Solid over empty
        fcb  0,0,0,0, SD,SF,SD,0        ; 2: empty over Solid
        fcb  SD,HO,SD,0, SD,HO,SD,0     ; 3: Hollow over Hollow
        fcb  SD,HO,SD,0, 0,0,0,0        ; 4: Hollow over empty
        fcb  0,0,0,0, SD,HO,SD,0        ; 5: empty over Hollow
        fcb  SD,SF,SD,0, SD,HO,SD,0     ; 6: Solid over Hollow
        fcb  SD,HO,SD,0, SD,SF,SD,0     ; 7: Hollow over Solid

d4_c:   fcb  0
d4_r:   fcb  0
d4_u:   fcb  0
