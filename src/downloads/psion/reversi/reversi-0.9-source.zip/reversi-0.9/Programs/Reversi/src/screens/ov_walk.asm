; =====================================================================
; OV_WALK: the opening book for the Psion's turn (OV_BOOK's B_TURN hands
; on here with the tree and the turn in BUF). A = the book's square (board
; index), after half a second, or 0: search.
;
; The book (block 1, made by tools/book; format 3, tools/book/encode.js):
; a 7-byte header (3, then the byte offsets of three trees: the Psion
; Solid having opened d2, having opened c3, the Psion Hollow), then the
; trees, each a bit stream (high bit first). A group (the opponent to
; move): a bit "every legal move stored", or else a bit for each legal
; move; then for each stored move in square order the Psion's reply as its
; index among its legal moves (as few bits as they need), a bit "positions
; beneath", and if so a bit "a jump" (then 12 bits: the group beneath's
; length in bits) and the group beneath. Moves are indexes among the legal
; moves, so the walk plays the line on the engine's board as it goes (in
; the book's orientation: a game opened e5 or f4 is the same game turned
; half round, every square 47 minus it); a stored move that is not the
; game's is passed over by its jump, or by reading through what lies
; beneath it (recursively, making and taking back its moves). The game's
; position is kept in the screen driver's area meanwhile (and put back),
; with the flip stack; the driver is read in again. Nothing is kept
; between turns.
; =====================================================================
        include "../defs.inc"

D2      = 11                    ; squares 0-47
C3      = 18

        jmp  wk_turn

SV      = DRV                   ; the game's board kept (80), e_ns..e_sqs (5)
FSP     = DRV+88                ; the flip stack

wk_turn:
        ldaa TMW_FRAM+1         ; (the time: a book move shows after half a
        staa wk_f0              ; second at least)
        ldx  BUF                ; OV_BOOK's: the tree (its header offset), the
        stx  wk_t               ; turn, the opponent's record index, the
        ldx  BUF+2              ; opponent
        stx  wk_i
        ldx  #e_bd              ; the game's position kept
        ldd  #SV
        bsr  .b80
        ldx  #e_ns
        ldd  #SV+80
        bsr  .b5
        bsr  wk_walk
        psha
        ldx  #SV                ; the game's position again
        ldd  #e_bd
        bsr  .b80
        ldx  #SV+80
        ldd  #e_ns
        bsr  .b5
        clr  kv_pkok
        ldaa kv_drv             ; and the driver (its area held all this)
        jsr  ov_load
        pula
        tsta
        beq  .x
.w:     ldab TMW_FRAM+1         ; a book move: half a second since the start,
        subb wk_f0              ; so it is seen
        cmpb #10
        bhs  .x
        slp
        bra  .w
.x:     rts
.b5:    pshb
        ldab #5
        bra  .cp
.b80:   pshb
        ldab #80
.cp:    stab T0+1
        clr  T0
        pulb
        os   UT$CPYB            ; T0 bytes from X to D
        rts

; the book's square (board index) for the opponent's move, or A = 0
wk_walk:
        ldx  #0                 ; the tree's offset from the header (at wk_t)
        ldab wk_t
        abx
        ldab #1
        jsr  pk_at
        os   PK$RWRD
        std  wk_bp
        bne  .on
        jmp  .out2
.on:    asld                    ; (in bits)
        asld
        asld
        std  wk_bp
        ldd  #$FFFF
        std  wk_ci              ; (no byte read yet)
        ldx  #e_bd+11           ; the starting position, Solid to move (the
.cl:    ldaa 0,x                ; border stays)
        cmpa #3
        beq  .bd
        clr  0,x
.bd:    inx
        cpx  #e_bd+69
        bne  .cl
        ldaa #2
        staa e_bd+34            ; Hollow d3 e4, Solid e3 d4
        staa e_bd+45
        ldaa #1
        staa e_bd+35
        staa e_bd+44
        staa e_side
        ldx  #FSP
        stx  e_fsp
        ldab wk_t
        cmpb #5
        beq  .grp               ; (the Psion Hollow: from the start)
        ldaa #D2                ; (the Psion's opening)
        cmpb #1
        beq  .op
        ldaa #C3
.op:    tab
        jsr  wk_mk
.grp:   jsr  gr_start           ; a group: the opponent's move in it
        ldab wk_i
        ldx  #g_rec
        abx
        ldab 0,x
        bsr  turn
        stab wk_o
.nx:    jsr  gr_next
        bcs  .out2
        cmpb wk_o
        beq  .hit
        tsta
        beq  .nx
        jsr  sk_node            ; another stored move: past it
        bra  .nx
.hit:   tsta
        beq  .out2              ; not stored: out of the book
        ldab wk_o
        jsr  wk_mk
        jsr  nd_body            ; its reply
        ldab wk_r
        bsr  turn
        ldaa wk_i
        inca
        cmpa g_n
        bne  .mid
        jmp  e_idxof            ; the opponent's last move: this is the reply
.mid:   pshb                    ; the Psion's move there must be the book's
        ldab wk_i
        ldx  #g_rec+1
        abx
        pulb
        cmpb 0,x
        bne  .out2
        tst  wk_kd
        beq  .out2              ; nothing beneath
        ldab wk_r
        jsr  wk_mk
        inc  wk_i
        inc  wk_i
        bra  .grp
.out2:  clra
        rts

; B = a square: the same square turned half round if the game is
turn:   tst  wk_turn_
        beq  .x
        negb
        addb #47
.x:     rts

; ---------------------------------------------------------------------
; the bit stream (block 1 from bit wk_bp)
; rb: A = bits (0-12) -> D = them
rb:     staa wk_c
        clra
        clrb
        std  wk_v
.l:     tst  wk_c
        beq  .x
        bsr  rbit
        rol  wk_v+1
        rol  wk_v
        dec  wk_c
        bra  .l
.x:     ldd  wk_v
        rts
; C = the bit at wk_bp; wk_bp on by one
rbit:   ldd  wk_bp              ; its byte: read from the pack unless it is held
        lsrd
        lsrd
        lsrd
        subd wk_ci
        beq  .have
        addd wk_ci
        std  wk_ci
        xgdx
        ldd  e_fsp              ; (the OS's calls use the zero page)
        pshb
        psha
        ldab #1
        jsr  pk_at
        os   PK$RBYT
        stab wk_cb
        pula
        pulb
        std  e_fsp
.have:  ldab wk_bp+1
        andb #7
        ldaa wk_cb
.s:     tstb
        beq  .b
        asla
        decb
        bra  .s
.b:     asla                    ; C = the bit
        ldx  wk_bp
        inx
        stx  wk_bp
        rts

; ---------------------------------------------------------------------
; the board: wk_mk B = square (0-47): the side to move plays it; B = its
; index and X = e_fs0 for taking it back (wk_un)
wk_mk:  jsr  e_idxof
        pshb
        jsr  e_make
        pulb
        ldx  e_fs0
        rts
wk_un:  stx  e_fs0
        jmp  e_undo

; A = side, B = k: B = its k-th legal move (square, in square order)
wk_kth: staa wk_sd
        stab wk_k2
        ldab #$FF
        stab wk_s2
.l:     inc  wk_s2
        ldab wk_s2
        jsr  e_idxof
        ldx  #e_bd
        abx
        tst  0,x
        bne  .l
        ldaa wk_sd
        jsr  e_flips
        tstb
        beq  .l
        tst  wk_k2
        beq  .x
        dec  wk_k2
        bra  .l
.x:     ldab wk_s2
        rts

; a group's start (the opponent to move): wk_all, the mask's place wk_mp
; (wk_bp past the mask); before the first move
gr_start:
        ldaa #1
        bsr  rb
        stab wk_all
        ldd  wk_bp
        std  wk_mp
        tst  wk_all
        bne  .x
        ldaa wk_mv              ; the mask: a bit for each legal move
        jsr  e_cmob
        clra
        addd wk_bp
        std  wk_bp
.x:     ldaa #$FF
        staa wk_s
        staa wk_k
        rts

; the group's next legal move: B = its square, A = 1 if it is stored; C
; set if there are no more
gr_next:
.l:     inc  wk_s
        ldab wk_s
        cmpb #48
        beq  .none
        jsr  e_idxof
        ldx  #e_bd
        abx
        tst  0,x
        bne  .l
        ldaa wk_mv
        jsr  e_flips
        tstb
        beq  .l
        inc  wk_k
        ldaa wk_all
        bne  .y
        ldx  wk_bp              ; its bit in the mask
        pshx
        ldab wk_k
        clra
        addd wk_mp
        std  wk_bp
        ldaa #1
        jsr  rb
        pulx
        stx  wk_bp
        tba
.y:     ldab wk_s
        clc
        rts
.none:  sec
        rts

; after the opponent's move: its node: wk_r the reply, wk_kd positions
; beneath, wk_jl the jump ($FFFF none)
nd_body:ldaa wk_mv              ; the reply: its index among the Psion's moves
        eora #3
        jsr  e_cmob
        clra                    ; as few bits as they need
        decb
.bf:    tstb
        beq  .r
        lsrb
        inca
        bra  .bf
.r:     jsr  rb
        ldaa wk_mv
        eora #3
        bsr  wk_kth
        stab wk_r
        ldd  #$FFFF
        std  wk_jl
        ldaa #1
        jsr  rb
        stab wk_kd
        beq  .x
        ldaa #1
        jsr  rb
        tstb
        beq  .x
        ldaa #12
        jsr  rb
        std  wk_jl
.x:     rts

; B = a stored move that is not the game's: past it and all beneath it
sk_node:jsr  wk_mk
        pshx
        pshb
        bsr  nd_body
        tst  wk_kd
        beq  .u
        ldd  wk_jl
        cmpa #$FF
        beq  .rd
        addd wk_bp              ; a jump
        std  wk_bp
        bra  .u
.rd:    ldab wk_r               ; read through the group beneath
        bsr  wk_mk
        pshx
        pshb
        ldx  wk_mp              ; (this group's place kept)
        pshx
        ldaa wk_s
        ldab wk_k
        pshb
        psha
        ldaa wk_all
        psha
        bsr  sk_grp
        pula
        staa wk_all
        pula
        pulb
        staa wk_s
        stab wk_k
        pulx
        stx  wk_mp
        pulb
        pulx
        bsr  wk_un
.u:     pulb
        pulx
        bra  wk_un

; a group to pass over (the opponent to move)
sk_grp: jsr  gr_start
.l:     jsr  gr_next
        bcs  .x
        tsta
        beq  .l
        bsr  sk_node
        bra  .l
.x:     rts

wk_f0:  fcb  0
wk_t:   fcb  0                  ; (BUF's, in order: the tree's header offset,
wk_turn_: fcb 0                 ; the turn, the record index, the opponent)
wk_i:   fcb  0
wk_mv:  fcb  0
wk_o:   fcb  0
wk_r:   fcb  0
wk_kd:  fcb  0
wk_all: fcb  0
wk_s:   fcb  0
wk_k:   fcb  0
wk_sd:  fcb  0
wk_s2:  fcb  0
wk_k2:  fcb  0
wk_c:   fcb  0
wk_cb:  fcb  0
wk_bp:  fdb  0
wk_ci:  fdb  0
wk_v:   fdb  0
wk_mp:  fdb  0
wk_jl:  fdb  0

