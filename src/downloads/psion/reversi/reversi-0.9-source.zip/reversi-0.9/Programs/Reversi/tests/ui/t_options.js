// Play on from Review, Auto level and the demo's level for Hollow (20 Nov).
// Review: EXE at the end goes back; EXE earlier asks "Go on? EXE": another key stays in the
// review, EXE makes that position the game (the record cut there, replayed and saved).
// Auto level: after a counted one-player game the level is one up for a win, one down for a loss.
// Demo H: in a demo Hollow searches at its own level (st_dlev), Solid at Level.
//   node tests/ui/t_options.js [models cm,lz64]
'use strict';
const { Game, assert } = require('./lib.js');

for (const model of (process.argv[2] || 'cm,lz64').split(',')) {
  const log = m => console.log(`[${model}] ${m}`);
  const g = new Game(model);
  g.start(); g.poke('st_level', 1);
  // a few moves, then Review
  for (let i = 0; i < 4; i++) { g.waitFor(() => g.turn(), 60, 0.1); g.key('EXE', 0.8); }
  g.waitFor(() => g.turn(), 60, 0.1);
  const rec = g.rec().slice(), n = rec.length;
  g.menu('Review');
  g.key('EXE', 1.0);                                     // at the end: back, nothing asked
  g.waitFor(() => g.turn(), 10, 0.1);
  assert(g.rec().join() === rec.join(), 'EXE at the end: the game as it was');
  g.menu('Review');                                      // ON earlier: back, nothing asked
  g.key('LEFT', 0.8); g.key('ON', 1.0);
  g.waitFor(() => g.turn(), 10, 0.1);
  assert(g.rec().join() === rec.join() && g.turn(), 'ON in the review: the game as it was: ' + g.prompt());
  g.menu('Review');
  g.key('LEFT', 0.8); g.key('LEFT', 0.8); g.key('LEFT', 0.8);
  g.key('EXE', 0.6);
  assert(/Go on\? EXE/.test(g.prompt()), 'asked: ' + g.prompt());
  g.key('ON', 0.8);                                      // no: still in the review
  assert(g.panel()[0].includes(`Move ${n - 3}/${n}`), 'still in the review: ' + g.panel()[0]);
  g.key('EXE', 0.6); g.key('EXE', 1.5);                  // yes
  g.waitFor(() => g.turn(), 60, 0.1);
  const r2 = g.rec();
  assert(r2.slice(0, n - 3).join() === rec.slice(0, n - 3).join() && r2.length <= n - 1, `played on from move ${n - 3}: ${r2} (was ${rec})`);
  log(`play on from move ${n - 3} of ${n} ok`);
  // auto level: a whole game at level 3 with EXE (most likely lost: down to 2), then a won one:
  // a1 Solid, b1 Hollow, you (Solid) play c1, counted as a handicap game is (g_setup 2)
  g.poke('st_auto', 1); g.poke('st_level', 3);
  const after = (what) => {
    const lv = g.peek('st_level');
    what();
    const won = /win/.test(g.panel().join('|')), lost = /lose/.test(g.panel().join('|'));
    g.m.runSeconds(1);
    const now = g.peek('st_level'), want = won ? Math.min(8, lv + 1) : lost ? Math.max(1, lv - 1) : lv;
    assert(now === want, `auto level after a ${won ? 'win' : lost ? 'loss' : 'draw'} at ${lv}: ${now}, want ${want}`);
    g.key('EXE', 0.8); g.key('ON', 0.8);
    return (won ? 'a win ' : lost ? 'a loss ' : 'a draw ') + lv + '->' + now;
  };
  const a1 = after(() => { g.menu('New game'); g.playOut(600); });
  const a2 = after(() => {
    g.menu('New game');
    g.menu('Set up');
    g.key('SPACE', 0.2); g.key('RIGHT', 0.2); g.key('SPACE', 0.2); g.key('SPACE', 0.2);
    g.keys(['DOWN', 'DOWN', 'RIGHT', 'RIGHT'], 0.15);
    g.keys(['SPACE', 'RIGHT', 'SPACE', 'SPACE', 'DOWN', 'SPACE', 'LEFT', 'SPACE', 'SPACE'], 0.15);
    g.key('EXE', 0.8); g.key('EXE', 2.0);
    g.waitHuman(); g.poke('g_setup', 2); g.key('EXE', 2.0);
    g.waitFor(() => g.over(), 20);
  });
  assert(/a win/.test(a2), "the set-up game was a win: " + a2);
  g.poke('st_auto', 0);
  log(`auto level ok: ${a1}, ${a2}`);
  // the demo: Solid at level 1 (no positions budget, depth 1), Hollow at level 5 (1,200)
  g.poke('st_level', 1); g.poke('st_dlev', 5); g.poke('st_players', 2); g.poke('g_psion', 3);
  g.menu('New game');
  const lim = { 1: new Set(), 2: new Set() };
  const ET = g.sym.e_think[0];                          // each search's settings as it starts
  g.m.dbg.setTrace(pc => { if (g.base >= 0 && pc === g.base + ET) lim[g.m.peek(g.a('e_side'))].add(g.m.peekw(g.a('e_limit')) + '/' + g.m.peek(g.a('e_fixd'))); });
  for (let t = 0; t < 120 && (lim[1].size < 1 || lim[2].size < 1); t++) g.m.runSeconds(0.25);
  g.m.dbg.setTrace(null);
  g.key('EXE', 1.0); g.key('ON', 0.8);
  g.poke('st_players', 0); g.poke('st_dlev', 0);
  assert([...lim[2]].every(v => v === '1200/0') && lim[2].size, 'Hollow at level 5: ' + [...lim[2]]);
  assert([...lim[1]].every(v => v === '0/1'), 'Solid at level 1: ' + [...lim[1]]);
  log(`demo levels ok: Solid ${[...lim[1]]}, Hollow ${[...lim[2]]}`);
}
