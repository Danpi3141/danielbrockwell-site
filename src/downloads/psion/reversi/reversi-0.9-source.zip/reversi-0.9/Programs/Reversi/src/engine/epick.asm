; =====================================================================
; e_pick: the end of a level 1-2 search (e_think jumps to E_PICK). In the
; game it is in OV_THINK, which is still in RAM above the search's working
; space when the search ends; the engine tests include it with the engine.
; =====================================================================
; levels 1-2: a random move among those within e_noise of the best (the
; root's moves and scores are at E_TT, 3 bytes each)
e_pick: ldaa e_dcur
        staa e_depth
        clra
        ldab e_noise
        std  e_v
        ldx  #E_FR
        ldd  F_BEST,x
        subd e_v
        std  e_tsc              ; the lowest score that counts
        ldaa #$FF
        staa e_v                ; (the first scan takes nothing)
        bsr  .scan              ; B = how many
        pshb
        jsr  e_rnd
        pulb
        mul                     ; A = the one to take, from 0
        inca
        staa e_v
        bsr  .scan
        rts
; scans the list: B = how many reach e_tsc; stops at the e_v-th (counting
; down) and makes it the move
.scan:  ldx  #E_TT
        clrb
.s:     cpx  e_tx
        beq  .e
        pshb
        ldd  1,x
        subd e_tsc
        pulb
        blt  .n
        incb
        dec  e_v
        bne  .n
        ldaa 0,x
        staa e_move
        ldd  1,x
        std  e_score
.n:     inx
        inx
        inx
        bra  .s
.e:     rts

