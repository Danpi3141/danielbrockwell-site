; =====================================================================
; Engine calls for the kernel
; =====================================================================

; eng_reset: an empty board
eng_reset:
        ldx  #e_bd
.c:     clr  0,x
        inx
        cpx  #e_lc+69
        bne  .c
        ldx  #e_bd+6            ; the stop row
        ldaa #3
.s:     staa 0,x
        ldab #7
        abx
        cpx  #e_bd+49+6
        bne  .s
        ldx  #e_land
        clra
.l:     staa 0,x
        adda #7
        inx
        cpx  #e_land+7
        bne  .l
        clra
        clrb
        std  e_ev
        std  e_key
        staa e_key+2
        staa e_n
        staa e_won
        rts
