; =====================================================================
; OV_COACH (stretch goal 7, the coach): after your move in a one-player
; game, with Coach on (OV_FX calls it), says what a deeper search
; preferred and by about how many discs: "Coach c4 +3", or "Coach: good"
; when nothing was better. Two searches at a fixed depth (3; to the end in
; the last 7 empty squares), every root move scored exactly as at levels
; 1-2: the best from the position before your move, then the reply to
; your move a ply shallower, which is the score your move had in the first.
; The difference is in discs: proven results are their disc margins;
; estimates are scaled by the stage (ref/tune/coachcal.js: 107, 46 and
; 25 /256 a unit for more than 30, 13-30 and 12 or fewer empty squares).
; A search covers slot A, so each one goes through think_run with
; ov_resume as its return: this overlay is read in again at the next entry
; (kv_cont); what it keeps between is in co_you, co_best, co_sb, co_sg.
; Your move is taken back first (e_undo, its flips still in BUF) and made
; again for the second search, which leaves the game's position. Nothing
; if you had one move only. The verdict for 2 seconds (a key cuts it short).
; =====================================================================
        include "../defs.inc"

C_DEPTH = 3                     ; the search's depth
C_END   = 7                     ; to the end from this many empty squares

        jmp  co_start
        jmp  co_one
        jmp  co_two

co_start:
        ldab kv_lmv             ; your move taken back (its flips are still in
        stab co_you             ; BUF, where OV_GAME made it)
        ldx  #BUF
        stx  e_fs0
        ldab kv_lfl
        abx
        stx  e_fsp
        ldab co_you
        jsr  e_undo
        jsr  eng_setup          ; (the square score too)
        ldaa e_side
        jsr  e_cmob
        cmpb #2
        blo  co_back            ; one move only: nothing to say
        jsr  pn_msg
        fcl  "Coach..."
        jsr  e_empt             ; the depth: C_DEPTH, or to the end
        ldaa #C_DEPTH
        cmpb #C_END
        bhi  .d
        tba
.d:     clr  co_sg
        ldab #1
; A = depth, B = the entry to go on at: a fixed-depth search through
; think_run, this overlay read in again after it
co_srch:staa e_fixd
        clr  e_noise
        clr  e_exend
        clr  e_limit
        clr  e_limit+1
        ldaa #OV_COACH
        std  kv_cont
        ldx  #ov_resume
        pshx
        jmp  think_run

; the first search done: the best move and its score kept; your move made,
; then the reply searched a ply shallower (yours again if the Psion must
; pass; no search if the game is over)
co_one: ldaa e_move
        staa co_best
        ldd  e_score
        std  co_sb
        ldx  #BUF
        stx  e_fsp
        ldab co_you
        jsr  e_make
        jsr  status             ; A = 0 a move, 1 a pass, 2 the end
        tsta
        beq  .s
        deca
        bne  .end
        inc  co_sg              ; the Psion passes: you move again
        jsr  e_pass
.s:     jsr  e_empt             ; a ply shallower than the first
        ldaa #C_DEPTH
        cmpb #C_END-1
        bhi  .d
        tba
.d:     deca
        cmpb #C_END-1
        bhi  .k
        inca                    ; (to the end: all the empty squares)
.k:     ldab #2
        bra  co_srch
.end:   ldab e_ns               ; over: your move's value is your margin
        clra
        subb e_nh
        sbca #0                 ; D = Solid's
        psha
        ldaa e_side             ; (after your move: you are the other side)
        cmpa #HOLLOW
        pula
        beq  co_dlt             ; you are Solid
        coma
        comb
        addd #1
        bra  co_dlt

; the second search done: your move's score, then in discs
co_two: ldd  e_score
        tst  co_sg
        bne  .y
        coma                    ; the Psion's view: yours is minus it
        comb
        addd #1
.y:     bsr  co_conv
; D = your move in discs: co_t = how many the best was better by
co_dlt: std  co_t
        ldd  co_sb
        bsr  co_conv
        subd co_t
        std  co_t
        bra  co_verd

; D = a score: in discs (proven results: their margin; estimates scaled)
co_conv:subd #2000
        bge  .x                 ; a win: its margin
        addd #4000
        ble  .x                 ; a loss: D = s + 2000, its margin (negative)
        subd #2000              ; an estimate
        clr  co_ng
        tsta
        bpl  .p
        inc  co_ng
        coma
        comb
        addd #1
.p:     std  co_a               ; |s| x k / 256, rounded
        jsr  e_empt
        incb                    ; (the position before your move)
        ldaa #107
        cmpb #30
        bhi  .k
        ldaa #46
        cmpb #12
        bhi  .k
        ldaa #25
.k:     staa co_k
        ldab co_a+1
        mul
        addd #128
        staa co_r
        ldaa co_a
        ldab co_k
        mul
        addb co_r
        adca #0
        tst  co_ng
        beq  .x
        coma
        comb
        addd #1
.x:     rts

; the verdict: the game's position again, "Coach c4 +3" or "Coach: good"
co_verd:
        tst  co_sg              ; (the second search was yours: the Psion to
        beq  .p                 ; move again)
        jsr  e_pass
.p:     ldd  co_t
        bmi  .good              ; (no better move)
        beq  .good
        subd #99
        bls  .n
        ldd  #99
        std  co_t
.n:     jsr  lb_clr
        jsr  lb_s
        fcl  "Coach "
        ldab co_best
        jsr  lb_sq
        ldab co_t+1
        cmpb #10
        bhs  .w
        jsr  lb_sp
.w:     ldaa #'+'
        jsr  lb_ch
        clra
        ldab co_t+1
        jsr  lb_num
        ldaa kv_plines
        deca
        jsr  lb_put
        bra  .wt
.good:  jsr  pn_msg
        fcl  "Coach: good"
.wt:    ldaa #40                ; 2 seconds, or a key
        jmp  key_wait

; your move made again (one move only: no verdict)
co_back:ldx  #BUF
        stx  e_fsp
        ldab co_you
        jmp  e_make

co_t:   fdb  0
co_a:   fdb  0
co_k:   fcb  0
co_r:   fcb  0
co_ng:  fcb  0

; eng_setup
        include "../engine/esetup.asm"
