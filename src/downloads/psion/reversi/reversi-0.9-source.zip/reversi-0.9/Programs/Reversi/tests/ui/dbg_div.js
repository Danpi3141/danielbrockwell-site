'use strict';
const { Game } = require('./lib.js');
const R = require('../../ref/rules.js');
const model = process.argv[2] || 'la', level = +(process.argv[3] || 5);
const g = new Game(model);
g.start();
g.poke('st_level', level);
function refBoard(rec) {
  const b = R.newBoard(); let side = 1;
  for (const sq of rec) { if (!R.legalMoves(b, side).length) side = 3 - side; R.play(b, R.idxOf(sq), side); side = 3 - side; }
  const rows = []; for (let r = 1; r <= 6; r++) { let s = ''; for (let c = 1; c <= 8; c++) s += '.XO'[b[r * 10 + c]]; rows.push(s); }
  return rows.join('/');
}
let last = -1;
for (let t = 0; t < 60; t++) {
  g.waitFor(() => /EXE: menu/.test(g.prompt()) || (g.humanTurn() && g.peek('g_n') !== last), 300, 0.2);
  const rec = g.rec(), live = g.board().join('/'), ref = refBoard(rec);
  if (live !== ref) { console.log('diverged at n', rec.length, JSON.stringify(rec), '\nlive', live, '\nref ', ref); break; }
  if (/EXE: menu/.test(g.prompt())) { console.log('done, all matched'); break; }
  last = g.peek('g_n');
  g.key('EXE', 0.3);
}
