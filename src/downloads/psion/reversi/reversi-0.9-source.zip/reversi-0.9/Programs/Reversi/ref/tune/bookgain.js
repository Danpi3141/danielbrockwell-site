// How much stronger the full book (data/book_full.json: every opponent move for four moves, both
// sides) would make the Psion than the 16K pack's book (data/book.json: for the Psion Solid, only
// the opponent's three likeliest fourth moves). They differ only there: the Psion Solid's fourth
// reply, after a fourth opponent move the pruned book lacks; the pruned book then searches at the
// level's budget (levels 5-8 use the book that far; 3-4 only for two replies). For each such
// position and level: the level's own move, and if it is not the full book's, the game played out
// from both (the Psion Solid at that level v Hollow at that level, several seeds). The chance of
// reaching such a position is taken for an opponent choosing its first four moves at random (the
// most it can be: a stronger opponent plays the likeliest moves more often).
//   node ref/tune/bookgain.js [seeds 6] [levels 5,6,7,8] [smaller book.json] [bigger book.json]
'use strict';
const os = require('os');
const path = require('path');
const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');
const R = require('../rules.js');
const { Engine } = require('../engine.js');
const { playFrom } = require('../match.js');

const D2 = R.parse('d2'), C3 = R.parse('c3');

if (!isMainThread) {
  const out = [];
  for (const j of workerData.bjobs) {
    if (j.kind === 'move') {
      const e = new Engine();
      for (const s of j.seq) e.make(s);
      const moves = [];
      for (let k = 0; k < j.seeds; k++) { e.seed = 1 + k * 7919; moves.push(e.think({ level: j.level }).move); }
      out.push({ ...j, moves });
    } else {
      const g = playFrom(j.seq, { level: j.level }, { level: j.level }, j.seed);
      out.push({ ...j, margin: g.ns - g.nh, score: g.ns > g.nh ? 1 : g.ns === g.nh ? 0.5 : 0 });
    }
  }
  parentPort.postMessage(out);
} else {
  const seeds = +(process.argv[2] || 6);
  const levels = (process.argv[3] || '5,6,7,8').split(',').map(Number);
  const ROOT = path.join(__dirname, '..', '..');
  const pruned = require(path.join(ROOT, process.argv[4] || 'data/book.json')).trees;
  const full = require(path.join(ROOT, process.argv[5] || 'data/book_full.json')).trees;
  const run = (jobs) => {
    const nw = Math.min(os.cpus().length, jobs.length);
    const parts = Array.from({ length: nw }, () => []);
    jobs.forEach((j, k) => parts[k % nw].push(j));
    return Promise.all(parts.map(p => new Promise((res, rej) => {
      const w = new Worker(__filename, { workerData: { bjobs: p } });
      w.on('message', res); w.on('error', rej);
    }))).then(rs => rs.flat());
  };
  // the positions only the full book has (the Psion Solid's trees), with the chance a random
  // opponent reaches each (the Psion's opening: d2 or c3, either way round, 1/2 each tree)
  const extra = [];
  let reachTotal = 0;
  function walk(fg, pg, seq, e, p, depth) {
    const legal = e.legal().length;
    for (const n of fg) {
      const pn = pg && pg.find(x => x.opp === n.opp);
      const pr = p / legal;                          // the opponent picks this move at random
      const s2 = [...seq, n.opp];
      if (!pn) {
        if (depth === 4) { extra.push({ seq: s2, book: n.reply, p: pr }); reachTotal += pr; }
        continue;                                    // (a deeper gap would show at depth 4 too)
      }
      if (n.kids.length) {
        const e2 = new Engine();
        for (const s of [...s2, n.reply]) e2.make(s);
        walk(n.kids, pn.kids, [...s2, n.reply], e2, pr, depth + 1);
      }
    }
  }
  [D2, C3].forEach((open, t) => {
    const e = new Engine(); e.make(open);
    walk(full[t], pruned[t], [open], e, 0.5, 1);
  });
  console.log(`${extra.length} positions only the full book has; a random opponent reaches one in ${(100 * reachTotal).toFixed(1)}% of the Psion's games as Solid`);
  (async () => {
    const t0 = Date.now();
    const mv = await run(levels.flatMap(level => extra.map((x, i) => ({ kind: 'move', i, level, seq: x.seq, seeds: 1 }))));
    const games = [];
    for (const m of mv) {
      const x = extra[m.i];
      if (m.moves[0] === x.book) continue;
      for (let k = 0; k < seeds; k++) {
        games.push({ kind: 'game', i: m.i, level: m.level, which: 'book', seq: [...x.seq, x.book], seed: 11 + k * 101 });
        games.push({ kind: 'game', i: m.i, level: m.level, which: 'search', seq: [...x.seq, m.moves[0]], seed: 11 + k * 101 });
      }
    }
    const res = await run(games);
    for (const level of levels) {
      const diff = mv.filter(m => m.level === level && m.moves[0] !== extra[m.i].book);
      let gain = 0, gainP = 0, pDiff = 0, mg = 0;
      for (const m of diff) {
        const rs = res.filter(r => r.level === level && r.i === m.i);
        const sc = (w) => { const a = rs.filter(r => r.which === w); return a.reduce((s, r) => s + r.score, 0) / a.length; };
        const mr = (w) => { const a = rs.filter(r => r.which === w); return a.reduce((s, r) => s + r.margin, 0) / a.length; };
        const d = sc('book') - sc('search');
        gain += d; mg += mr('book') - mr('search');
        gainP += d * extra[m.i].p; pDiff += extra[m.i].p;
      }
      console.log(`level ${level}: the search differs from the full book in ${diff.length} of ${extra.length} positions; ` +
        `where it does, the book's move scores ${diff.length ? (100 * gain / diff.length).toFixed(1) : 0} points per 100 games better ` +
        `(${diff.length ? (mg / diff.length).toFixed(2) : 0} discs); over all the Psion's games as Solid against a random opener: ` +
        `${(100 * gainP).toFixed(2)} points per 100 games`);
    }
    console.log(`${res.length} games, ${((Date.now() - t0) / 1000).toFixed(0)} s on ${os.cpus().length} cores`);
  })();
}
