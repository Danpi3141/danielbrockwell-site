// Fits the evaluation's weights to final margins by least squares (ridge).
// Square values (12 quarter classes, corner class fixed at 0: the corner weight carries it)
// are shared by all stages; mobility, corner, edge run, parity and discs are per stage.
// node ref/tune/fit.js data.jsonl [scale]
'use strict';
const fs = require('fs');
const R = require('../rules.js');
const { Engine, CORNERS } = require('../engine.js');

// quarter class of each square (0-11), row-major in the quarter
const CLS = new Int8Array(80).fill(-1);
for (const s of R.SQUARES) {
  let r = ((s / 10) | 0) - 1, c = s % 10 - 1;
  if (r > 2) r = 5 - r;
  if (c > 3) c = 7 - c;
  CLS[s] = r * 4 + c;
}
function stageOf(e) { return e > 30 ? 0 : e >= 13 ? 1 : 2; }

const NQ = 11;                        // classes 1-11 (class 0 = corner, fixed 0)
const NF = NQ + 3 * 5;                // + per stage: mob corner edge par disc

function features(e) {
  const bd = e.bd, p = e.side, sx = p === 1 ? 1 : -1;
  const f = new Float64Array(NF);
  const cancelled = new Uint8Array(80);
  for (const [c, d1, d2] of CORNERS) if (bd[c]) { cancelled[c + d1] = cancelled[c + d2] = cancelled[c + d1 + d2] = 1; }
  for (const s of R.SQUARES) {
    const v = bd[s];
    if (!v || CLS[s] === 0 || cancelled[s]) continue;
    f[CLS[s] - 1] += (v === 1 ? 1 : -1) * sx;
  }
  const em = e.empties(), st = stageOf(em), o = NQ + st * 5;
  let corner = 0, edge = 0;
  for (const [c, d1, d2] of CORNERS) {
    const x = bd[c];
    if (!x) continue;
    const s1 = x === 1 ? 1 : -1;
    corner += s1;
    for (const d of [d1, d2]) { let t = c + d; while (bd[t] === x) { edge += s1; t += d; } }
  }
  f[o] = e.countMoves(p) - e.countMoves(3 - p);
  f[o + 1] = corner * sx;
  f[o + 2] = edge * sx;
  f[o + 3] = em & 1;
  f[o + 4] = (e.ns - e.nh) * sx;
  return f;
}

function solve(A, b) {
  const n = b.length;
  const M = A.map((row, i) => [...row, b[i]]);
  for (let i = 0; i < n; i++) {
    let p = i;
    for (let k = i + 1; k < n; k++) if (Math.abs(M[k][i]) > Math.abs(M[p][i])) p = k;
    [M[i], M[p]] = [M[p], M[i]];
    for (let k = 0; k < n; k++) {
      if (k === i) continue;
      const t = M[k][i] / M[i][i];
      for (let j = i; j <= n; j++) M[k][j] -= t * M[i][j];
    }
  }
  return M.map((row, i) => row[n] / row[i]);
}

function fit(file, lambda = 1) {
  const lines = fs.readFileSync(file, 'utf8').trim().split('\n');
  const A = Array.from({ length: NF }, () => new Float64Array(NF));
  const b = new Float64Array(NF);
  const e = new Engine();
  let n = 0, sse0 = 0;
  for (const ln of lines) {
    const { b: bs, s, m } = JSON.parse(ln);
    const bd = new Uint8Array(80).fill(3);
    R.SQUARES.forEach((q, i) => { bd[q] = +bs[i]; });
    e.setBoard(bd, s);
    const f = features(e);
    const y = s === 1 ? m : -m;
    for (let i = 0; i < NF; i++) { if (!f[i]) continue; b[i] += f[i] * y; for (let j = 0; j < NF; j++) A[i][j] += f[i] * f[j]; }
    sse0 += y * y; n++;
  }
  for (let i = 0; i < NF; i++) A[i][i] += lambda * n / 1000;
  const w = solve(A.map(r => Array.from(r)), Array.from(b));
  return { w, n };
}

module.exports = { features, fit, NQ, NF, CLS };

if (require.main === module) {
  const { w, n } = fit(process.argv[2]);
  const scale = +(process.argv[3] || 4);
  console.log(`${n} positions`);
  const q = [0, ...w.slice(0, NQ)].map(x => Math.round(x * scale));
  console.log('quarter (x' + scale + '):');
  for (let r = 0; r < 3; r++) console.log('  ' + q.slice(r * 4, r * 4 + 4).map(v => String(v).padStart(4)).join(''));
  const names = ['mob', 'corner', 'edge', 'par', 'disc'];
  for (let k = 0; k < 5; k++) console.log(`${names[k].padEnd(7)} ${[0, 1, 2].map(st => (w[NQ + st * 5 + k] * scale).toFixed(1).padStart(7)).join('')}`);
}
