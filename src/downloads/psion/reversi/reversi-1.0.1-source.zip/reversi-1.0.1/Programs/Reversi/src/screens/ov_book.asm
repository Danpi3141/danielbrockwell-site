; =====================================================================
; OV_BOOK: the Psion's turn: the level's search set up (e_limit, e_fixd,
; e_noise, e_exend) and the thinking bar drawn empty, then the opening
; book (OV_WALK); the tip's search set up (B_TIP); the search's start
; (B_PRE, e_pre, just before think_run's e_think).
; =====================================================================
        include "../defs.inc"

D2      = 11                    ; squares 0-47
C3      = 18

        jmp  bk_turn
        jmp  bk_tip
        ; B_PRE: the search's start (first in the overlay: it writes the
        ; search's variables, which lie over the end of slot A)
        include "../engine/epre.asm"

; the levels: positions (2), depth (levels 1-2), noise, exact ending from,
; book replies (0 none, 2 the first two, 99 all). v1.0 (22 Nov): levels
; 1-3 much easier: 1 nearly random (any move within 100 of the best at
; depth 1), 2 within 40 at depth 2, 3 a 40-position search; 4-8 as before
bk_lv:  fdb  0
        fcb  1,100,0,0
        fdb  0
        fcb  2,40,2,0
        fdb  40
        fcb  0,0,4,0
        fdb  600
        fcb  0,0,8,2
        fdb  1200
        fcb  0,0,9,99
        fdb  3000
        fcb  0,0,10,99
        fdb  8000
        fcb  0,0,11,99
        fdb  24000
        fcb  0,0,12,99
        fdb  300                ; 9: the tip (level 3 before v1.0)
        fcb  0,0,7,0

; T: the tip, a 300-position search (row 9); only on your turn with a move (C set, a
; buzz, if not)
bk_tip: tst  g_over
        bne  .no
        jsr  psion_turn
        bne  .no
        jsr  status
        tsta
        bne  .no
        ldaa #9
        bsr  bk_set
        clc
        rts
.no:    jsr  buzz
        sec
        rts

; A = level: the search's inputs; X = its row
bk_set: deca
        ldab #6
        mul
        addd #bk_lv
        xgdx
        ldd  0,x
        std  e_limit
        ldd  2,x
        std  e_fixd             ; (and e_noise)
        ldaa 4,x
        staa e_exend
        ldaa 5,x
        staa bk_rep
        ldd  e_limit            ; a block of the bar: a tenth of the positions
        ldx  #0
.t:     subd #10
        bcs  .b
        inx
        bra  .t
.b:     stx  e_bstep
        jsr  lb_clr             ; the bar, empty
        ldaa #'['
        jsr  lb_ch
        ldaa #10
        jsr  lb_at
        ldaa #']'
        jsr  lb_ch
        jmp  pn_last

; B_TURN: the level's search set up, the bar drawn; then the book: A = its
; square (board index), or 0: search. The Psion's own opening is chosen
; here; within a tree OV_WALK walks it (BUF: the tree's header offset, the
; turn, the record index of the opponent's first move there, the opponent).
bk_turn:
        ldaa st_level
        ldab g_psion            ; a demo: Hollow at its own level (st_dlev, 0: the same)
        cmpb #3
        bne  .lv
        ldab e_side
        cmpb #HOLLOW
        bne  .lv
        ldab st_dlev
        beq  .lv
        tba
.lv:    bsr  bk_set
        tst  st_book            ; off, not at this level, or a set-up game
        bne  .out
        tst  g_setup
        bne  .out
        ldaa bk_rep
        beq  .out
        ldab g_n                ; a pass has been: out of the book
        eorb e_side             ; (Solid moves at even counts, Hollow at odd)
        andb #1
        beq  .out
        ldab g_n                ; the Psion's replies so far: Solid (g_n-2)/2
        beq  .rp                ; (its opening is not one), Hollow (g_n-1)/2
        decb
        ldaa e_side
        cmpa #SOLID
        bne  .r1
        decb
.r1:    lsrb
        cmpb bk_rep
        bhs  .out
.rp:    ldaa e_side
        eora #3
        staa BUF+3              ; the opponent
        cmpa #HOLLOW
        bne  .hol
        tst  g_n
        bne  .sol
        jsr  e_rnd              ; the Psion opens: d2 or c3, either way round
        tab
        ldaa #D2
        lsrb
        bcc  .o1
        ldaa #C3
.o1:    lsrb
        bcc  .o2
        nega
        adda #47
.o2:    tab
        jsr  e_idxof
        psha                    ; half a second, so it is seen
        ldaa #10
        jsr  pause
        pula
        rts
.sol:   ldab g_rec              ; its opening says the tree and the turn
        ldx  #1*256             ; (header offsets: tree 0 at 1)
        cmpb #D2
        beq  .t
        cmpb #47-D2
        beq  .tt
        ldx  #3*256
        cmpb #C3
        beq  .t
        cmpb #47-C3
        beq  .tt
.out:   clra
        rts
.tt:    inx
.t:     ldaa #1                 ; the first opponent move: index 1
        bra  .go
.hol:   ldab g_rec              ; the opponent opened: d2 or c3, either way round
        ldx  #5*256
        cmpb #D2
        beq  .h
        cmpb #C3
        beq  .h
        inx
        cmpb #47-D2
        beq  .h
        cmpb #47-C3
        bne  .out
.h:     clra
.go:    stx  BUF                ; the tree and the turn
        staa BUF+2              ; the record index of the opponent's move
        ldd  #OV_WALK*256
        jmp  ov_call

bk_rep: fcb  0
