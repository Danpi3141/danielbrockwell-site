#!/usr/bin/env python3
"""Builds Reversi 8x6: the kernel (with the engine), the screen drivers and overlays, the
book, the launchers and the pack image (a 16K Datapak that runs on every model).

    python tools/build.py [--out build/game] [--pack 16|32] [--psion]

The array m%() holds: kernel + engine (code, tables, variables) | screen driver (DRV)
| slot A (one overlay at a time). While the engine searches, the driver and slot A hold its
table (512, at DRV), flip stack (256) and scratch (frames, killers, its variables), with
OV_THINK (its poll and the thinking bar) at the top of slot A; the driver is read in again
afterwards. Everything there is set up afresh at every search, so nothing is lost by sharing.
(From Connect 4's build.)
"""
import argparse
import json
import os
import sys
import zlib

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import asm   # noqa: E402
import pack  # noqa: E402

BLOCK_MAX = 32000
BAD_OPL = (0, 9, 10, 13)
TT_BYTES = 256
FS_BYTES = 244              # the flip stack: 12 plies of 14 flips, and the exact ending's sorted lists (68 moves and 8 ends) too
WS_LOW = TT_BYTES + FS_BYTES   # the scratch (frames...) starts here, from DRV
LAUNCH_OVERHEAD = 345          # REVG beyond its array: the free RAM it needs at the call (Connect 4's measure: 323)
SAVE_ROOM = 150                # A:REVSAV and A:REVTAL; REV adds this while there is no REVSAV
REVG_FRAME_GAP = 22            # REVG's variables between the end of its object code and m%() (as Connect 4's C4G)
REV_FRAME = 12                 # REV's frame between the end of m%() and its QCode (tests/ui/t_hidden.js checks both)
BUF_SIZE = 24                  # the overlays' buffer at the top of slot A: a move's flips, the legal squares
UNITS = [('DRV2', 'drv2.asm'), ('DRV4', 'drv4.asm'), ('OV_GAME', 'ov_game.asm'), ('OV_PANEL', 'ov_panel.asm'),
         ('OV_PLAY', 'ov_play.asm'), ('OV_BOOK', 'ov_book.asm'), ('OV_RESULT', 'ov_result.asm'),
         ('OV_MENU', 'ov_menu.asm'), ('OV_SET', 'ov_set.asm'), ('OV_HELP', 'ov_help.asm'),
         ('OV_SETUP', 'ov_setup.asm'), ('OV_FX', 'ov_fx.asm'), ('OV_REVIEW', 'ov_review.asm'), ('OV_THINK', 'ov_think.asm'),
         ('OV_COACH', 'ov_coach.asm'), ('OV_EXPORT', 'ov_export.asm'), ('OV_IMPORT', 'ov_import.asm'),
         ('OV_WALK', 'ov_walk.asm')]
DRIVERS = ('DRV2', 'DRV4')
BUF_USERS = {'OV_GAME': BUF_SIZE, 'OV_PANEL': BUF_SIZE, 'OV_FX': BUF_SIZE, 'OV_REVIEW': BUF_SIZE, 'OV_COACH': BUF_SIZE, 'OV_WALK': BUF_SIZE}
DEFINES = {}


class BuildError(Exception):
    pass


def build_number(data):
    """The build's number, at the head of the data block and in the bootstrap, which passes over any other build's block
    (another version's on another pack: in Chess that stopped a real Organiser, 24 Nov). No byte an OPL string cannot hold."""
    k = 0
    while True:
        n = zlib.crc32(bytes(data) + bytes([k])) & 0xFFFF
        if not {n >> 8, n & 255} & {0, 9, 10, 13, 34}:
            return n
        k += 1


def encode_fixups(fix, kernel=False):
    """A fix-up list: its length in bytes (one byte), then steps, two a byte (the high nibble
    first): 1-15 on that far and fix the word there, 0 on 15 without a fix-up (also the pad)."""
    nib = []
    prev = 0
    for f in sorted(fix):
        d = f - prev
        if d < 1:
            raise BuildError('a fix-up at %d: steps start at 1' % f)
        while d > 15:
            nib.append(0)
            d -= 15
        nib.append(d)
        prev = f
    if len(nib) % 2:
        nib.append(0)
    out = bytes(nib[i] << 4 | nib[i + 1] for i in range(0, len(nib), 2))
    if len(out) > 255 and not kernel:
        raise BuildError('a fix-up list of %d bytes (its length is one byte)' % len(out))
    return bytes([len(out) & 255]) + out


# ---------------------------------------------------------------------------------------------
# The kernel's relocation by decoding (src/launch/fixer.asm): every 3-byte instruction but $6x
# carries a 16-bit operand, which is an address in the array when it lies in lo..hi-1 (signed);
# the exceptions are listed. reloc_stream makes the list from the listing, reloc_decode is the
# fixer's walk, and the build checks it fixes exactly the assembler's fix-ups.
OPLEN = [1] * 256
for _op in range(0x20, 0x30):
    OPLEN[_op] = 2
OPLEN[0x3F] = 2
for _op in range(0x60, 0x70):
    OPLEN[_op] = 3 if _op in (0x61, 0x62, 0x65, 0x6B) else 2
for _op in range(0x70, 0x80):
    OPLEN[_op] = 3
for _hi in (0x80, 0xC0):
    for _lo in range(16):
        OPLEN[_hi + _lo] = 3 if _lo in (3, 12, 14, 15) else 2     # (15: never used; as the fixer)
        OPLEN[_hi + 0x10 + _lo] = OPLEN[_hi + 0x20 + _lo] = 2
        OPLEN[_hi + 0x30 + _lo] = 3
DATA_OPS = ('fcb', 'fdb', 'fcc', 'fcl', 'rmb', 'org')


def reloc_address(code, at, lo, hi):
    """Is the instruction at `at` taken (by the rule) to carry an address?"""
    op = code[at]
    if OPLEN[op] != 3 or op >> 4 == 6:
        return False
    v = code[at + 1] << 8 | code[at + 2]
    v = v - 65536 if v >= 32768 else v
    return lo <= v < hi


def code_items(u, origin, shift):
    """A unit's bytes from its listing: (offset + shift, 'ins' or 'data', bytes), instructions one
    at a time (a long branch is two)."""
    import re
    items = []
    for pc, data, raw in u.listing:
        if not data:
            continue
        off = pc - origin + shift
        m = re.match(r'^\s*(?:[.\w]+:)?\s*(\w+)', raw)
        op = m.group(1).lower() if m else ''
        if op in DATA_OPS:
            items.append((off, 'data', bytes(data)))
            continue
        i = 0
        while i < len(data):
            n = OPLEN[data[i]]
            if i + n > len(data):
                raise BuildError('cannot decode the instruction at %d: %s' % (off + i, raw.strip()))
            items.append((off + i, 'ins', bytes(data[i:i + n])))
            i += n
    return items


def reloc_stream(items, fix, size, code, lo, hi):
    exc = []                                  # (offset, kind 0 the other way round, 255 a word, 1-254 skip)
    fix = set(fix)
    for off, kind, data in items:
        if kind == 'data':
            j = 0
            while j < len(data):
                if off + j in fix:
                    exc.append([off + j, 255]); j += 2
                    continue
                if exc and 1 <= exc[-1][1] < 254 and exc[-1][0] + exc[-1][1] == off + j:
                    exc[-1][1] += 1
                else:
                    exc.append([off + j, 1])
                j += 1
        else:
            inside = [f for f in fix if off <= f < off + len(data)]
            if inside and inside != [off + 1]:
                raise BuildError('a fix-up inside the instruction at %d not on its operand' % off)
            if reloc_address(code, off, lo, hi) != bool(inside):
                exc.append([off, 0])
    out = bytearray()
    at = 0
    for off, kind in exc:
        gap = off - at
        while gap >= 255:
            out.append(255); gap -= 255
        out += bytes([gap, kind])
        at = off + (2 if kind == 255 else kind if kind else 0)
    if at > size:
        raise BuildError('the relocation list runs past the code')
    return bytes(out)


def reloc_decode(code, stream, lo, hi):
    """The fixer's walk: the offsets of the words it fixes."""
    fixed, pc, i = [], 0, 0

    def nxt(pc, i):
        at = pc
        while True:
            g = stream[i] if i < len(stream) else 0
            i += 1
            at += g
            if g != 255:
                break
        kind = stream[i] if i < len(stream) else None
        return (at if kind is not None else None), kind, i + 1
    exat, kind, i = nxt(pc, i)
    while pc < len(code):
        tog = False
        if pc == exat:
            if kind == 0:
                tog = True
                exat, kind, i = nxt(pc, i)
            else:
                if kind == 255:
                    fixed.append(pc); pc += 2
                else:
                    pc += kind
                exat, kind, i = nxt(pc, i)
                continue
        elif exat is not None and pc > exat:
            raise BuildError('the relocation walk passed an exception at %d' % exat)
        n = OPLEN[code[pc]]
        if reloc_address(code, pc, lo, hi) != tog:
            fixed.append(pc + 1)
        pc += n
    if pc != len(code):
        raise BuildError('the relocation walk ended at %d, not %d' % (pc, len(code)))
    return fixed


def revg_lines(boot, total):
    """REVG: makes the array, pokes the bootstrap into its top from one string, calls it."""
    lit = '"' + bytes(boot).decode('latin-1').replace('"', '""') + '"'
    if len('POKEB a%%+i%%,ASC(MID$(%s,i%%+1,1))' % lit) > 250:
        raise BuildError('the bootstrap no longer fits one string')
    words = (total + 1) // 2
    return ['REVG:', 'LOCAL m%%(%d),v%%(6),i%%,a%%' % words,      # v%(): 12 bytes (boot.asm)
            'a%%=ADDR(m%%())+%d' % (total - len(boot)),
            'i%=0', 'DO', 'POKEB a%%+i%%,ASC(MID$(%s,i%%+1,1))' % lit, 'i%=i%+1', 'UNTIL i%%=%d' % len(boot),
            'v%%(1)=ADDR(m%%()) :v%%(2)=%d' % total,
            'i%=USR(a%,ADDR(v%()))',
            'IF i% :PRINT "REV ERROR ";i% :GET :ENDIF']     # 1 no game files, 2 damaged


def opl_object(path):
    """A launcher's translated object code."""
    class A:
        no_translate = False
        target = 'cm'
        strip_indent = True
        encoding = 'latin-1'
    _, rec, _ = pack.opl2opk.opl_procedure(path, A, quiet=True)
    rec = bytes(rec)
    olen = rec[15] << 8 | rec[16]
    return rec[17:17 + olen]


def revg_hole(path, boot):
    """KH: REVG's QCode before its USR call, in RAM just below the array (offset, length). REVG
    stays loaded all game and its code before USR never runs again, so the kernel keeps
    variables there (src/kernel/kvars.inc); that includes its copy of the bootstrap string,
    which has run by then. Its code from USR on runs when the game ends: it stays."""
    obj = opl_object(path)
    qlen = obj[2] << 8 | obj[3]
    q = obj[len(obj) - qlen:]
    at = q.find(boot)
    if at < 0 or q.find(boot, at + 1) >= 0:
        raise BuildError('REVG: the bootstrap string is not once in its code')
    u = q.rfind(bytes([0x9F, 0x7F]))             # USR, then the assignment to i%
    if u < at + len(boot) or q.find(bytes([0x9F]), at + len(boot)) != u:
        raise BuildError('REVG: its USR call is not where it should be')
    return -(qlen + REVG_FRAME_GAP), u


def array_bytes(total):
    """m%() is whole words: REV's frame starts after its last byte."""
    return (total + 1) // 2 * 2


def rev_lines(needs):
    return ['REV:', 'LOCAL n%',
            'PRINT "REVERSI 8x6"',
            'n%%=%d+%d*EXIST("A:REVSAV")-FREE' % (needs + SAVE_ROOM, SAVE_ROOM),
            'IF n%<=0 :REVG: :RETURN :ENDIF',
            'PRINT "NEEDS ";n%;" BYTES" :GET']


def rev_hole(path):
    """KR: REV's QCode before its call of REVG, in RAM just above the array (offset from its
    end, length), and the end of REV's QCode. After the call only 84 7B (drop REVG's result,
    RETURN) run again, when the game ends: they stay."""
    obj = opl_object(path)
    qlen = obj[2] << 8 | obj[3]
    q = obj[len(obj) - qlen:]
    c = q.find(bytes([0x7D, 4]) + b'REVG' + bytes([0x84, 0x7B]))
    if c < 0 or q.find(b'REVG', c + 3) >= 0:
        raise BuildError('REV: its call of REVG is not where it should be')
    return REV_FRAME, c + 6, REV_FRAME + qlen


def build(out, pack_k=16):
    gen = os.path.join(out, 'gen')
    os.makedirs(gen, exist_ok=True)
    ids = ['; generated by tools/build.py', 'N_UNITS = %d' % len(UNITS)]
    ids += ['%s = %d' % (n, i + 1) for i, (n, _) in enumerate(UNITS)]
    if len(UNITS) >= 32:
        raise BuildError('the command table tells an overlay from a kernel address by its id being below $20')
    with open(os.path.join(gen, 'ids.inc'), 'w') as f:
        f.write('\n'.join(ids) + '\n')
    incdirs = [gen, os.path.join(ROOT, 'src'), os.path.join(ROOT, 'src', 'kernel'),
               os.path.join(ROOT, 'src', 'engine'), os.path.join(ROOT, 'src', 'screens')]

    def assemble(path, origin, imports, what):
        imports = dict(imports)
        for k, v in DEFINES.get(what, {}).items():
            imports[k] = (v, 'abs')
        try:
            return asm.assemble(path, origin=origin, imports=imports, incdirs=incdirs)
        except asm.AsmError as e:
            raise BuildError('%s: %s' % (what, e))

    kpath = os.path.join(ROOT, 'src', 'kernel', 'kernel.asm')

    b = assemble(os.path.join(ROOT, 'src', 'launch', 'boot.asm'), 0, {'BUILD': (0x4242, 'abs')}, 'boot')    # (its build: below)
    if b.fix:
        raise BuildError('the bootstrap must be position independent')
    boot = bytes(b.out)
    bad = [i for i, v in enumerate(boot) if v in BAD_OPL]
    if bad:
        raise BuildError('the bootstrap has bytes an OPL string cannot hold at %s' % bad)
    draft = os.path.join(out, 'REVG_draft.opl')
    with open(draft, 'w', encoding='latin-1', newline='\n') as f:
        f.write('\n'.join(revg_lines(boot, 5000)) + '\n')
    kh, kh_len = revg_hole(draft, boot)
    os.remove(draft)
    with open(draft, 'w', encoding='latin-1', newline='\n') as f:
        f.write('\n'.join(rev_lines(5000)) + '\n')
    kr_off, kr_len, rev_end = rev_hole(draft)
    os.remove(draft)

    scratch = [400]
    think_len = [0]
    init_len = [0]

    def imports(kmax, drv, slot):
        return {'DRV': (kmax, 'rel'), 'SLOTA': (kmax + drv, 'rel'), 'TTBASE': (kmax, 'rel'),
                'SCRATCH': (kmax + WS_LOW, 'rel'), 'THINKAT': (kmax + drv + slot - think_len[0], 'rel'),
                'BUF': (kmax + drv + slot - BUF_SIZE, 'rel'), 'INIT_LEN': (init_len[0], 'abs'),
                'SLOTA_SIZE': (slot, 'abs'), 'DRV_SIZE': (drv, 'abs'), 'KH': (kh, 'rel'),
                'KR': (array_bytes(kmax + drv + slot) + kr_off, 'rel'),
                'KR_KEEP': (array_bytes(kmax + drv + slot) + kr_off + kr_len, 'rel')}

    k = assemble(kpath, 0, imports(0x3000, 512, 1024), 'kernel')
    scratch[0] = k.sym['E_SCRATCH_END'][0] - k.sym['E_FR'][0]
    ksym = dict(k.sym)
    ksym.update(imports(0x3000, 512, 1024))
    drv = slot = 16
    sizes = {}
    for n, fn in UNITS:
        u = assemble(os.path.join(ROOT, 'src', 'screens', fn), 0x3000, ksym, n)
        sizes[n] = len(u.out)
        if n in DRIVERS:
            drv = max(drv, len(u.out))
        elif n == 'OV_THINK':
            think_len[0] = len(u.out)
        else:
            slot = max(slot, len(u.out) + BUF_USERS.get(n, 0))
    ws = WS_LOW + scratch[0]
    slot = max(slot, ws + think_len[0] - drv)     # the search covers the driver and slot A below OV_THINK
    kmax = 0
    for _ in range(8):
        k = assemble(kpath, 0, imports(kmax, drv, slot), 'kernel')
        if len(k.out) == kmax:
            break
        kmax = len(k.out)
    else:
        raise BuildError('kernel size did not settle')
    if bytes(k.out[3:7]) != b'RVK1':
        raise BuildError('kernel does not start with its tag')
    ksym = dict(k.sym)
    ksym.update(imports(kmax, drv, slot))
    kin = assemble(os.path.join(ROOT, 'src', 'kernel', 'kinit.asm'), kmax + drv, ksym, 'kinit')
    init_len[0] = len(kin.out)
    k2 = assemble(kpath, 0, imports(kmax, drv, slot), 'kernel')
    if len(k2.out) != len(k.out) or any(k2.sym[n] != v for n, v in k.sym.items() if n != 'INIT_LEN'):
        raise BuildError('the kernel moved when given the length of the start-up code')
    k = k2
    ksym = dict(k.sym)
    ksym.update(imports(kmax, drv, slot))
    if len(kin.out) > slot - BUF_SIZE:
        raise BuildError('the start-up code (%d) is bigger than slot A' % len(kin.out))
    with open(os.path.join(out, 'kinit.lst'), 'w') as f:
        f.write(kin.listing_text())
    vstart = k.sym['kv_first'][0]
    if vstart + len(kin.out) > kmax + drv:
        raise BuildError('the start-up code would overlap slot A while it is copied')
    image = bytearray(k.out)
    if any(image[vstart:]):
        raise BuildError('kernel variables are not all zero')
    if any(f >= vstart for f in k.fix):
        raise BuildError('a fix-up in the kernel variables')

    blk0 = bytearray()
    offs = {}
    report = []
    for n, fn in UNITS:
        origin = kmax if n in DRIVERS else kmax + drv + slot - think_len[0] if n == 'OV_THINK' else kmax + drv
        u = assemble(os.path.join(ROOT, 'src', 'screens', fn), origin, ksym, n)
        limit = drv if n in DRIVERS else think_len[0] if n == 'OV_THINK' else slot - BUF_USERS.get(n, 0)
        if len(u.out) > limit:
            raise BuildError('%s is %d bytes, over its room (%d)' % (n, len(u.out), limit))
        if n == 'OV_BOOK' and u.sym['e_pre_end'][0] > ksym['E_KIL'][0]:
            raise BuildError("OV_BOOK's e_pre reaches the search's variables (it writes them)")
        if n == 'OV_THINK' and u.sym['e_pick'][0] != ksym['E_PICK'][0]:
            raise BuildError('e_pick is not at E_PICK in OV_THINK')
        offs[n] = len(blk0)
        blk0 += len(u.out).to_bytes(2, 'big') + bytes(u.out) + encode_fixups(u.fix)
        report.append((n, len(u.out), len(u.fix)))
        with open(os.path.join(out, n.lower() + '.lst'), 'w') as f:
            f.write(u.listing_text())
        with open(os.path.join(out, n.lower() + '.sym.json'), 'w') as f:
            json.dump({s: v for s, v in u.sym.items() if s not in ksym}, f, indent=0)
    if len(blk0) > BLOCK_MAX:
        raise BuildError('block 0 is %d bytes' % len(blk0))
    base = k.sym['ovtab'][0]
    for i, (n, _) in enumerate(UNITS):
        image[base + 2 * i:base + 2 * i + 2] = offs[n].to_bytes(2, 'big')
    kin_out = bytearray(kin.out)
    kimg = image[:vstart] + kin_out
    # the kernel's relocation: decoded by the fixer, with a list of the exceptions (checked)
    total = kmax + drv + slot
    rlo, rhi = kh, array_bytes(total) + rev_end  # (the array, and the variables kept below and above it)
    kfix = sorted(list(k.fix) + [vstart + f for f in kin.fix])
    items = [it for it in code_items(k, 0, 0) if it[0] < vstart] + code_items(kin, kmax + drv, vstart)
    covered = sum(len(d) for _, _, d in items)
    if covered != len(kimg):
        raise BuildError('the listing covers %d of the kernel image (%d bytes)' % (covered, len(kimg)))
    enc = bytes(1) + reloc_stream(items, kfix, len(kimg), kimg, rlo, rhi)
    if reloc_decode(kimg, enc[1:], rlo, rhi) != kfix:
        raise BuildError('the relocation by decoding does not fix exactly the fix-ups')
    fx = assemble(os.path.join(ROOT, 'src', 'launch', 'fixer.asm'), 0,
                  {'R_LO': (rlo & 0xFFFF, 'abs'), 'R_SPAN': (rhi - rlo, 'abs')}, 'fixer')
    if fx.fix:
        raise BuildError('the fixer must be position independent')
    book = os.path.join(ROOT, 'data', 'book.bin')
    bk = open(book, 'rb').read() if os.path.exists(book) else b''
    bk = bk or bytes(7)
    # REVM: the kernel's lengths, the kernel (with the start-up code), the fixer and the kernel's
    # fix-ups (all the bootstrap reads), then block 0 (the overlays) and block 1 (the book);
    # the start-up code is told where the blocks are (from REVM's data: in_b0, in_b1)
    allk_len = len(kimg) + len(fx.out) + len(enc) - 1
    o = kin.sym['in_b1'][0] - (kmax + drv)            # block 1 (the book) after block 0
    kin_out[o:o + 2] = len(blk0).to_bytes(2, 'big')
    kimg = image[:vstart] + kin_out
    allk = bytes(kimg) + bytes(fx.out) + enc[1:]
    assert len(allk) == allk_len
    build_id = build_number(allk + bytes(blk0) + bk)
    boot = bytes(assemble(os.path.join(ROOT, 'src', 'launch', 'boot.asm'), 0, {'BUILD': (build_id, 'abs')}, 'boot').out)
    kblock = build_id.to_bytes(2, 'big') + len(kimg).to_bytes(2, 'big') + len(allk).to_bytes(2, 'big') + allk
    if len(kblock) - 4 > total - 160:
        raise BuildError('kernel and its fix-ups do not fit the array while loading')
    with open(os.path.join(out, 'kernel.lst'), 'w') as f:
        f.write(k.listing_text())
    with open(os.path.join(out, 'kernel.sym.json'), 'w') as f:
        json.dump({n: v for n, v in ksym.items()}, f, indent=0)

    hole = k.sym['kh_end'][0] - k.sym['kh_first'][0]
    if k.sym['kh_first'][0] != kh or hole > kh_len:
        raise BuildError("the variables in REVG's code (%d bytes) must fit it (%d)" % (hole, kh_len))
    hole = k.sym['kr_end'][0] - k.sym['kr_first'][0]
    if k.sym['kr_first'][0] != array_bytes(total) + kr_off or hole > kr_len:
        raise BuildError("the variables in REV's code (%d bytes) must fit it (%d)" % (hole, kr_len))
    needs = total + LAUNCH_OVERHEAD
    lines = revg_lines(boot, total)
    lp = os.path.join(out, 'REVG.opl')
    with open(lp, 'w', encoding='latin-1', newline='\n') as f:
        f.write('\n'.join(lines) + '\n')
    sp = os.path.join(out, 'REV.opl')
    with open(sp, 'w', encoding='latin-1', newline='\n') as f:
        f.write('\n'.join(rev_lines(needs)) + '\n')
    if revg_hole(lp, boot) != (kh, kh_len) or rev_hole(sp) != (kr_off, kr_len, rev_end):
        raise BuildError('the launchers changed shape between the draft and the build')

    img = pack.PackImage('datapak', pack_k, target='cm')
    img.add_opl(sp, source=False)       # (the Organiser runs only their object code)
    img.add_opl(lp, source=False)
    img.add_data('REVM', kblock + bytes(blk0) + bk)
    opk = os.path.join(out, 'REV.opk')
    size_k, used = img.write(opk)

    e = {n: v[0] for n, v in k.sym.items()}
    lines = ['Pack (%dK Datapak)              bytes' % size_k,
             '  REVM: kernel+engine    %7d' % len(kblock),
             '  REVM: overlays         %7d' % len(blk0),
             '  REVM: book             %7d' % len(bk),
             '  total                  %7d of %d' % (used, size_k * 1024),
             'RAM (array m%())                bytes',
             '  engine code+tables     %7d' % (e['eng_end'] - e['eng_start']),
             '  kernel code            %7d  (and start-up code %d, run once in slot A)' % (vstart - (e['eng_end'] - e['eng_start']), len(kin.out)),
             '  variables              %7d' % (kmax - vstart),
             '  screen driver          %7d' % drv,
             '  slot A                 %7d  (an overlay, %d of buffer for some; or the search: %d + OV_THINK %d)' % (
                 slot, BUF_SIZE, ws, think_len[0]),
             '  array                  %7d  (REV needs %d free, %d before the first save)' % (total, needs, needs + SAVE_ROOM),
             'Units']
    for n, ln, nf in report:
        lines.append('  %-10s %5d bytes, %3d fix-ups' % (n, ln, nf))
    text = '\n'.join(lines)
    with open(os.path.join(out, 'budget.txt'), 'w') as f:
        f.write(text + '\n')
    meta = {'kmax': kmax, 'drv': drv, 'slot': slot, 'total': total, 'needs': needs, 'opk': opk, 'offs': offs,
            'ws': ws, 'think': think_len[0], 'kh': kh, 'kh_len': kh_len, 'kr': array_bytes(total) + kr_off, 'kr_len': kr_len,
            'rev_end': array_bytes(total) + rev_end}
    with open(os.path.join(out, 'build.json'), 'w') as f:
        json.dump(meta, f, indent=1)
    return text, meta


def psion_folder(opk, folder):
    """The pack's files as .OB3 procedures for RPLOAD (a real Organiser through a Comms Link)."""
    import shutil
    import subprocess
    tools = os.path.join(ROOT, '..', '..', 'Tools')
    tmp = folder + '_tmp'
    if os.path.isdir(tmp):
        shutil.rmtree(tmp)
    subprocess.run([sys.executable, os.path.join(tools, 'opk2files.py'), '-o', tmp, opk], check=True, capture_output=True)
    for f in os.listdir(tmp):
        if f.lower().endswith('.opl'):
            os.remove(os.path.join(tmp, f))
    subprocess.run([sys.executable, os.path.join(tools, 'mkrpdata.py'), tmp, '--title', 'REVERSI 8x6', '--run', 'REV'],
                   check=True, capture_output=True)
    os.makedirs(folder, exist_ok=True)
    for f in os.listdir(folder):                    # procedures the pack no longer has (REVB0, REVB1)
        if f.lower().endswith('.ob3') and f not in os.listdir(tmp):
            os.remove(os.path.join(folder, f))
    for f in os.listdir(tmp):
        shutil.copyfile(os.path.join(tmp, f), os.path.join(folder, f))
    shutil.rmtree(tmp)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=None)
    ap.add_argument('--pack', type=int, default=16)
    ap.add_argument('--psion', action='store_true', help='also write psion/: the files for RPLOAD')
    a = ap.parse_args()
    out = os.path.abspath(a.out) if a.out else os.path.join(ROOT, 'build', 'game')
    os.makedirs(out, exist_ok=True)
    try:
        text, _ = build(out, a.pack)
    except (BuildError, pack.opl2opk.PackError) as e:
        sys.exit('build failed: %s' % e)
    print(text)
    if a.psion:
        psion_folder(os.path.join(out, 'REV.opk'), os.path.join(ROOT, 'psion'))
        print('psion/: the files for RPLOAD')


if __name__ == '__main__':
    main()
