; =====================================================================
; The kernel's fixer: read in from block REVM just after the kernel (where
; the variables go, cleared later) and run once by the bootstrap with
; X = v%()-1. Adds the array's address to every relocatable word in the
; kernel (and the start-up code after it), found by decoding its
; instructions: every 3-byte instruction but the $6x ones (aim/oim/eim/tim
; indexed) carries a 16-bit operand, and one in R_LO..R_LO+R_SPAN-1 (the
; array, and the variables kept below it) is an address in the array.
; The exceptions to that rule follow this code (tools/build.py
; reloc_stream, which checks them against the assembler's fix-ups): for
; each, the bytes on to it (a byte; 255: 255 more and another byte), then
; what it is: 0 the instruction there is the other way round, 255 a word
; of data to fix, 1-254 that many bytes of data to pass over.
; Then jumps to the kernel's first byte with D = ADDR(v%()).
; Position independent: relative branches and zero-page scratch only.
; =====================================================================
        include "../defs.inc"

V_BASE  = 1                     ; (offsets from v%()-1, as in boot.asm)
V_KLEN  = 7                     ; the kernel's length

F_BASE  = T0                    ; the array
F_PC    = T2                    ; the next instruction
F_END   = T4                    ; the kernel's end
F_EXP   = T6                    ; the next exception byte
F_EXAT  = T8                    ; where the next exception is
F_KIND  = T10                   ; what it is
F_TOG   = T11                   ; this instruction the other way round

fix:    pshx                    ; v%()-1 (for the end)
        ldd  V_BASE,x
        std  F_BASE
        std  F_PC
        addd V_KLEN,x
        std  F_END
        addd #FIXLEN
        std  F_EXP              ; the exceptions follow this code
        bsr  .exc
        bra  .nx
.go:    pulx                    ; the kernel's entry is its first byte
        inx
        xgdx                    ; D = v%()
        ldx  F_BASE
        jmp  0,x
; the word at X: the array's address added
.fx:    pshb
        ldd  0,x
        addd F_BASE
        std  0,x
        pulb
        rts
; the next exception: F_EXAT, F_KIND
.exc:   ldx  F_EXP
        ldd  F_PC
.g:     std  F_EXAT
        ldab 0,x                ; the bytes on to it
        inx
        stab F_KIND
        clra
        addd F_EXAT
        inc  F_KIND             ; (255: more)
        beq  .g
        std  F_EXAT
        ldab 0,x                ; what it is
        inx
        stab F_KIND
        stx  F_EXP
        rts

.nx:    ldx  F_PC
        cpx  F_END
        beq  .go
        clr  F_TOG
        cpx  F_EXAT
        bne  .in
        ldab F_KIND             ; an exception
        beq  .tog
        incb
        beq  .wd
        decb
        abx                     ; data: passed over
        bra  .ex
.wd:    bsr  .fx                ; a word of data: fixed
        inx
        inx
.ex:    stx  F_PC
        bsr  .exc
        bra  .nx
.tog:   inc  F_TOG              ; this instruction the other way round
        bsr  .exc
        ldx  F_PC
.in:    bsr  .len               ; B = its length, carry: a 16-bit operand
        bcc  .no
        pshb
        ldd  1,x                ; an address if in range
        subd #R_LO
        subd #R_SPAN
        pulb
.no:    ldaa #0
        adca #0
        eora F_TOG
        beq  .on
        pshx
        inx
        bsr  .fx
        pulx
.on:    abx
        stx  F_PC
        bra  .nx

; X = an instruction: B = its length; carry set if it has a 16-bit
; operand (3 bytes, not $6x)
.len:   ldaa 0,x
        ldab #2
        cmpa #$3F
        beq  .r                 ; os: 2
        cmpa #$60
        bhs  .hi
        anda #$F0
        cmpa #$20
        beq  .r                 ; branches: 2
        decb                    ; the rest below $60: 1
        clc
.r:     rts
.hi:    cmpa #$80
        blo  .six
        bita #$30
        bne  .dx
        anda #15                ; immediate: 3 for subd cpx lds addd ldd ldx
        cmpa #3
        beq  .y
        cmpa #12
        blo  .n2
        cmpa #13                ; (bsr)
        bne  .y
.n2:    clc
        rts
.dx:    anda #$30               ; extended: 3; direct, indexed: 2
        cmpa #$30
        bne  .n2
.y:     incb
        sec
        rts
.six:    cmpa #$70
        bhs  .y                 ; $7x: extended
        anda #15                ; $6x: indexed, 2; aim oim eim tim 3, no operand
        cmpa #1
        beq  .t3
        cmpa #2
        beq  .t3
        cmpa #5
        beq  .t3
        cmpa #11
        bne  .n2
.t3:    incb
        clc
        rts
fix_end:
FIXLEN  = fix_end-fix
