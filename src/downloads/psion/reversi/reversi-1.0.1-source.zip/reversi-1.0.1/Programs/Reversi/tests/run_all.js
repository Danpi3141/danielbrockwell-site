// Every test, in turn: node tests/run_all.js [--quick]
'use strict';
const { execFileSync } = require('child_process');
const path = require('path');
const quick = process.argv.includes('--quick');
const T = [
  ['ref/rules.js', ['8']],
  ['tests/engine/t_perft.js', [quick ? '5' : '6']],
  ['tests/engine/t_state.js', [quick ? '10' : '30']],
  ['tests/engine/t_search.js', quick ? ['20', '1,2,3,5'] : ['60', '1,2,3,4,5,6,7']],
  ['tests/engine/t_ints.js', ['36-la.rom', '32']],
  ['tests/engine/t_endings.js', [quick ? '40' : '200', '8']],
  ['tests/engine/t_markers.js', []],
  ['tests/engine/t_fixed.js', [quick ? '20' : '60']],
  ['tools/book/check_book.js', ['data/book']],
  ['tests/ui/t_features.js', ['cm,lz64']],
  ['tests/ui/t_setup.js', ['cm,lz64']],
  ['tests/ui/t_extras.js', ['cm,lz64']],
  ['tests/ui/t_hints.js', ['cm,lz64']],
  ['tests/ui/t_keys.js', ['cm,lz64']],
  ['tests/ui/t_glyphs.js', ['cm,lz64']],
  ['tests/ui/t_review.js', ['cm,lz64']],
  ['tests/ui/t_think.js', ['cm,lz64']],
  ['tests/ui/t_autooff.js', ['cm,lz64']],
  ['tests/ui/t_misc.js', ['cm,lz64']],
  ['tests/ui/t_more.js', ['cm,lz64']],
  ['tests/ui/t_paths.js', ['cm,lz64']],
  ['tests/ui/t_book.js', ['cm', quick ? '3' : '8']],
  ['tests/ui/t_coach.js', ['cm,lz64', quick ? '1' : '3']],
  ['tests/ui/t_xfer.js', ['cm,lz64']],
  ['tests/ui/t_screens.js', ['cm,lz64']],
  ['tests/ui/t_options.js', ['cm,lz64']],
  ['tests/m1/lowmem.js', []],
  ['tests/m1/needs.js', []],
  ['tests/m1/savesize.js', []],
  ['tests/ui/t_hidden.js', [quick ? 'cm,lz64' : '24-cm.rom,33-cm.rom,31-xp.rom,36-la.rom,46-lz.rom,46a-lz64.rom']],
  ['tests/ui/t_mixed.js', quick ? ['33-cm.rom', '46a-lz64.rom'] : []],
  ['tests/ui/t_game.js', ['cm', '3']],
  ['tests/ui/t_game.js', ['lz64', '5']],
];
const root = path.join(__dirname, '..');
let fail = 0;
for (const [f, a] of T) {
  const t = Date.now();
  try {
    const out = execFileSync('node', [path.join(root, f), ...a], { cwd: path.dirname(path.join(root, f)), encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
    const last = out.trim().split('\n').slice(-1)[0];
    console.log(`ok   ${f} ${a.join(' ')} (${((Date.now() - t) / 1000).toFixed(0)} s): ${last}`);
  } catch (e) {
    fail++;
    console.log(`FAIL ${f} ${a.join(' ')}: ${(e.stdout || '').trim().split('\n').slice(-3).join(' | ')} ${(e.stderr || '').split('\n').filter(l => /FAIL|Error/.test(l)).slice(0, 2).join(' | ')}`);
  }
}
console.log(fail ? `${fail} failed` : 'all passed');
process.exit(fail ? 1 : 0);
