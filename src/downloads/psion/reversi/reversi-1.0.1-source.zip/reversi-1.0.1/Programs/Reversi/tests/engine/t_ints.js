// The engine with the OS's interrupts running (keyboard scan, clock), on a ROM: move counts and
// searches must still match the reference.
'use strict';
const { Harness } = require('./harness.js');
const { Engine, TIP, rnd } = require('../../ref/engine.js');
const rom = process.argv[2] || '36-la.rom', ram = +(process.argv[3] || 32);
const h = new Harness({ rom, ram, ints: true });
const st = { seed: 99 };
let bad = 0, n = 0;
for (let g = 0; g < 6; g++) {
  const e = new Engine();
  h.call('eng_reset');
  let passes = 0;
  while (true) {
    const cm = h.call('t_cmob').b;
    if (cm !== e.countMoves(e.side)) { bad++; console.log('cmob', cm, e.countMoves(e.side)); }
    n++;
    const l = e.legal();
    if (!l.length) { e.pass(); h.call('e_pass'); if (++passes === 2) break; continue; }
    passes = 0;
    if (n % 7 === 0) {
      const L = TIP;
      const r = e.think(Object.assign({}, TIP, { seed: n }));
      h.setPos(e.bd, e.side);
      const a = h.think({ nodes: L.nodes, exact: L.exact, seed: n });
      if (a.move !== r.move || a.nodes !== r.nodes) { bad++; console.log('search', JSON.stringify(a), r.move, r.nodes); }
    }
    const mv = l[(rnd(st) * l.length) >> 8];
    e.make(mv); h.call('t_make', 0, mv);
  }
}
console.log(rom, n, 'positions,', bad, 'differences');
