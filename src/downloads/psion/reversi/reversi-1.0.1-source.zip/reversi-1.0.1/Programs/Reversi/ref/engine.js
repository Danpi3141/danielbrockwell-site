// Reversi 8x6 reference engine: the model the 6303 engine is matched against, position for
// position. Every rule here (move order, counting, stopping, ties, keys) is the one the
// assembler follows, so a search gives the same move, score and position count on both.
//
// Board as in rules.js: bd[80], index row*10+col, 0 empty 1 Solid 2 Hollow 3 border.
'use strict';
const R = require('./rules.js');

// ---------------- tables (src/engine/etab.inc is generated from these) ----------------
// Square values, top-left quarter (rows 1-3, columns a-d); the rest mirror it.
// The spec's starting values; tuned by self-play (ref/tune/spsa.js, round 1: 2,000 iterations at
// level 4, 19 Nov 2026), which scored 57-59% against the spec's at levels 3, 5 and 7 (2,000 games
// each, ref/tune/verify.js); then round 2 (below) is the default.
const SPEC_QUARTER = [
  [30, -8, 6, 4],
  [-8, -14, -2, -1],
  [6, -2, 1, 0],
];
const SPEC_WEIGHTS = {
  mob: [6, 5, 3], corner: [25, 25, 20], edge: [4, 5, 6], par: [0, 2, 8], disc: [0, 0, 2],
};
// Round 2 (1,200 iterations at level 5 from round 1's values): 52.1%, 50.9%, 52.3% against round 1
// at levels 3, 5, 7 (2,000 games each).
const QUARTER = [
  [19, -7, 6, 6],
  [-8, -23, -1, -2],
  [5, -4, 0, -1],
];
// Weights by stage: [more than 30 empty, 13-30, 12 or fewer]
const WEIGHTS = {
  mob: [4, 5, 6], corner: [20, 21, 18], edge: [4, 6, 7], par: [-1, 1, 8], disc: [-2, -1, 0],
};
// Search order: corners, edges, middle, then the squares next to corners.
function defaultOrder(quarter) {
  const v = squareValues(quarter);
  const corners = [11, 18, 61, 68];
  const cx = [12, 21, 22, 17, 28, 27, 62, 51, 52, 67, 58, 57];
  const edges = [], mid = [];
  for (const s of R.SQUARES) {
    if (corners.includes(s) || cx.includes(s)) continue;
    const r = (s / 10) | 0, c = s % 10;
    if (r === 1 || r === 6 || c === 1 || c === 8) edges.push(s); else mid.push(s);
  }
  const byVal = (a, b) => v[b] - v[a] || a - b;
  edges.sort(byVal); mid.sort(byVal);
  const cxs = cx.slice().sort(byVal);
  return [...corners, ...edges, ...mid, ...cxs];
}
function squareValues(quarter) {
  const v = new Int8Array(80);
  for (const s of R.SQUARES) {
    let r = ((s / 10) | 0) - 1, c = s % 10 - 1;     // 0-5, 0-7
    if (r > 2) r = 5 - r;
    if (c > 3) c = 7 - c;
    v[s] = quarter[r][c];
  }
  return v;
}
// corners: square, the two edge steps (neighbours are c+d1, c+d2, c+d1+d2)
const CORNERS = [[11, 1, 10], [18, -1, 10], [61, 1, -10], [68, -1, -10]];

// levels: nodes (0 = fixed depth), depth, noise (points), exact ending from (empties), book.
// The spec's budgets (300, 450, 750, 1500, 4500, 15000) left levels 4-3, 6-5 and 7-6 under the 60%
// the spec asks of each level against the one below; moved apart as it says (ref/tune/levels.js,
// 1,000 games a pair): 76.8, 65.0, 61.9, 61.1, 60.1, 61.5% for levels 3-8 (20 Nov 2026).
// v1.0 (22 Nov 2026): levels 1-3 made much easier (they were depth 1 noise 8, depth 2 noise 4,
// 300 positions): level 1 nearly random (62% against a random mover; it was 93%), each of 1-4
// 85-91% against the one below (ref/tune/easy.js). The tip keeps the old level 3's search (TIP).
const TIP = { nodes: 300, depth: 0, noise: 0, exact: 7, book: 0 };
const LEVELS = [
  null,
  { nodes: 0, depth: 1, noise: 100, exact: 0, book: 0 },
  { nodes: 0, depth: 2, noise: 40, exact: 2, book: 0 },
  { nodes: 40, depth: 0, noise: 0, exact: 4, book: 0 },
  { nodes: 600, depth: 0, noise: 0, exact: 8, book: 2 },
  { nodes: 1200, depth: 0, noise: 0, exact: 9, book: 99 },
  { nodes: 3000, depth: 0, noise: 0, exact: 10, book: 99 },
  { nodes: 8000, depth: 0, noise: 0, exact: 11, book: 99 },
  { nodes: 24000, depth: 0, noise: 0, exact: 12, book: 99 },
];

const INF = 30000;
const WIN = 2000;           // proven results lie beyond 2,000; estimates within 1,000
const EST = 1000;
const MAXD = 12;            // search frames 0-12 (the exact ending is at most 12 empty squares deep)
const TT_N = 64;            // 64 entries: as strong as 128 at levels 5-8 (ref/tune/tt64.js, 19 Nov 2026)
const NONE = 0xff;

// 24-bit Galois LFSR, 8 steps a byte
function rnd(e) {
  let x = e.seed;
  for (let i = 0; i < 8; i++) { const l = x & 1; x >>>= 1; if (l) x ^= 0xE10000; }
  e.seed = x;
  return x & 255;
}

class Engine {
  constructor(opts) {
    this.opts = Object.assign({ tt: TT_N, quarter: QUARTER, weights: WEIGHTS, killer: true }, opts || {});
    this.V = squareValues(this.opts.quarter);
    this.ORDER = this.opts.order || defaultOrder(this.opts.quarter);
    this.W = this.opts.weights;
    this.seed = 0x12345;
    this.reset();
  }

  reset() {
    this.bd = R.newBoard();
    this.ns = 2; this.nh = 2;
    this.side = 1;
    this.sqs = 0;
    for (const s of R.SQUARES) if (this.bd[s]) this.sqs += this.bd[s] === 1 ? this.V[s] : -this.V[s];
    this.fs = [];            // flip stack (squares), with move records
    this.hist = [];          // [square, flipcount] per make (a pass is [NONE,0])
  }

  setBoard(bd, side) {
    this.bd = Uint8Array.from(bd);
    this.side = side;
    this.ns = 0; this.nh = 0; this.sqs = 0;
    for (const s of R.SQUARES) {
      if (this.bd[s] === 1) { this.ns++; this.sqs += this.V[s]; }
      else if (this.bd[s] === 2) { this.nh++; this.sqs -= this.V[s]; }
    }
    this.fs = []; this.hist = [];
  }

  empties() { return 48 - this.ns - this.nh; }

  // ---------- make / undo ----------
  // Plays s for the side to move. Returns the number of flips (0: illegal, nothing changed).
  make(s) {
    const bd = this.bd, p = this.side, o = 3 - p;
    if (bd[s] !== 0) return 0;
    const base = this.fs.length;
    for (const d of R.DIRS) {
      let t = s + d;
      if (bd[t] !== o) continue;
      do t += d; while (bd[t] === o);
      if (bd[t] !== p) continue;
      for (t -= d; t !== s; t -= d) { bd[t] = p; this.fs.push(t); }
    }
    const n = this.fs.length - base;
    if (!n) return 0;
    bd[s] = p;
    let dv = this.V[s];
    for (let i = base; i < this.fs.length; i++) dv += 2 * this.V[this.fs[i]];
    if (p === 1) { this.sqs += dv; this.ns += n + 1; this.nh -= n; }
    else { this.sqs -= dv; this.nh += n + 1; this.ns -= n; }
    this.hist.push([s, n]);
    this.side = o;
    return n;
  }

  undo() {
    const [s, n] = this.hist.pop();
    const p = 3 - this.side;          // the side that moved
    this.side = p;
    if (s === NONE) return;
    const bd = this.bd, o = 3 - p;
    let dv = this.V[s];
    for (let i = 0; i < n; i++) { const t = this.fs.pop(); bd[t] = o; dv += 2 * this.V[t]; }
    bd[s] = 0;
    if (p === 1) { this.sqs -= dv; this.ns -= n + 1; this.nh += n; }
    else { this.sqs += dv; this.nh -= n + 1; this.ns += n; }
  }

  pass() { this.hist.push([NONE, 0]); this.side = 3 - this.side; }

  // flips side p would make at s, counted only
  flipCount(s, p) {
    const bd = this.bd, o = 3 - p;
    if (bd[s] !== 0) return 0;
    let n = 0;
    for (const d of R.DIRS) {
      let t = s + d, k = 0;
      while (bd[t] === o) { t += d; k++; }
      if (k && bd[t] === p) n += k;
    }
    return n;
  }

  canMove(s, p) {
    const bd = this.bd, o = 3 - p;
    for (const d of R.DIRS) {
      let t = s + d;
      if (bd[t] !== o) continue;
      do t += d; while (bd[t] === o);
      if (bd[t] === p) return true;
    }
    return false;
  }

  countMoves(p) {
    let n = 0;
    for (const s of this.ORDER) if (this.bd[s] === 0 && this.canMove(s, p)) n++;
    return n;
  }

  legal(p = this.side) { return this.ORDER.filter(s => this.bd[s] === 0 && this.canMove(s, p)); }

  // ---------- key ----------
  // 12 bytes, 4 squares each (2 bits, a-d / e-h of each row), FNV-style with the prime $193.
  key() {
    let h = this.side === 1 ? 0x9DC5 : 0x9DC6;   // 24-bit start $019DC5 / $019DC6
    h |= 0x010000;
    const bd = this.bd;
    for (let r = 1; r <= 6; r++) {
      for (let half = 0; half < 2; half++) {
        let c = 0;
        for (let k = 0; k < 4; k++) c = (c << 2) | bd[r * 10 + 1 + half * 4 + k];
        h ^= c;
        h = (h * 0x193) & 0xffffff;
      }
    }
    return h;
  }

  // ---------- evaluation (side to move's view) ----------
  evaluate(parentMob) {
    const e = this.empties();
    const st = e > 30 ? 0 : e >= 13 ? 1 : 2;
    const W = this.W, bd = this.bd;
    let sq = this.sqs, stab = 0;
    for (const [c, d1, d2] of CORNERS) {
      const x = bd[c];
      if (!x) continue;
      const sx = x === 1 ? 1 : -1;
      stab += sx * W.corner[st];
      for (const d of [d1, d2]) {
        let t = c + d;
        while (bd[t] === x) { stab += sx * W.edge[st]; t += d; }
      }
      for (const n of [c + d1, c + d2, c + d1 + d2]) {
        if (bd[n] === 1) sq -= this.V[n]; else if (bd[n] === 2) sq += this.V[n];
      }
    }
    let v = sq + stab + W.disc[st] * (this.ns - this.nh);
    if (this.side === 2) v = -v;
    v += W.mob[st] * (this.countMoves(this.side) - parentMob);
    if (this.opts.region) {
      // (experiment, the spec's stretch goal 10: region parity) instead of the one parity term:
      // the empty squares in connected regions (8-way); each odd region is worth the parity
      // weight to the side to move, each even one nothing
      const seen = new Uint8Array(80);
      let odd = 0;
      for (const q of R.SQUARES) {
        if (bd[q] !== 0 || seen[q]) continue;
        let n = 0; const st2 = [q]; seen[q] = 1;
        while (st2.length) { const t = st2.pop(); n++; for (const d of R.DIRS) { const u = t + d; if (bd[u] === 0 && !seen[u]) { seen[u] = 1; st2.push(u); } } }
        if (n & 1) odd++;
      }
      v += W.par[st] * odd;
    } else if (e & 1) v += W.par[st];
    if (v > EST) v = EST; else if (v < -EST) v = -EST;
    return v;
  }

  final() {   // finished game, side to move's view
    let m = this.ns - this.nh;
    if (this.side === 2) m = -m;
    return m > 0 ? WIN + m : m < 0 ? -WIN + m : 0;
  }

  // ---------- search ----------
  // think({level | nodes/depth/noise/exact, seed}) -> { move, score, depth, nodes, exact }
  think(cfg) {
    const lv = cfg.level ? LEVELS[cfg.level] : {};
    const c = Object.assign({ nodes: 0, depth: 0, noise: 0, exact: 0 }, lv, cfg);
    if (cfg.seed !== undefined) this.seed = cfg.seed & 0xffffff;
    this.tt = new Uint32Array(this.opts.tt);       // check(16) | move(6)<<16 | kind(2)<<22, score separate
    this.ttS = new Int8Array(this.opts.tt);
    this.killer = new Uint8Array(MAXD + 1).fill(NONE);
    this.nodes = 0;
    this.abort = false;
    this.maxFlips = 0;
    const legal = this.legal();
    if (!legal.length) return { move: NONE, score: 0, depth: 0, nodes: 0, exact: false };
    const e = this.empties();
    let r;
    if (e <= c.exact) {
      r = this.thinkExact(c.nodes ? c.nodes * 4 : 0);
      if (r) { r.nodes = this.nodes; return r; }
      // dropped at the safety limit: an ordinary search with a fresh count
      this.nodes = 0; this.abort = false;
      this.killer.fill(NONE);
    }
    if (c.depth) r = this.thinkFixed(c.depth, c.noise);
    else r = this.thinkDeep(c.nodes);
    r.nodes = this.nodes;
    return r;
  }

  count(limit) {
    this.nodes++;
    if (limit && this.nodes >= limit) this.abort = true;
  }

  // levels 1-2: every root move scored exactly at a fixed depth, then a random one within noise
  thinkFixed(depth, noise) {
    const scores = [];
    let best = -INF;
    this.limit = 0; this.iter1 = true;
    const rootMob = this.countMoves(this.side);
    for (const s of this.ORDER) {
      if (this.bd[s] !== 0) continue;
      const n = this.make(s);
      if (!n) continue;
      this.count(0);
      const v = -this.node(1, depth - 1, -INF, INF, rootMob, false);
      this.undo();
      scores.push([s, v]);
      if (v > best) best = v;
    }
    const cand = scores.filter(([, v]) => v >= best - noise);
    const k = (rnd(this) * cand.length) >> 8;
    return { move: cand[k][0], score: cand[k][1], depth, exact: false, scores };
  }

  thinkDeep(limit) {
    const e = this.empties();
    let move = NONE, score = 0, depth = 0, exact = false;
    let maxd = Math.min(MAXD, e);
    this.limit = limit;
    for (let d = 1; d <= maxd; d++) {
      this.iter1 = d === 1;
      const r = this.root(d, move);
      if (this.abort) {
        if (r.firstDone) { move = r.move; score = r.score; }
        break;
      }
      move = r.move; score = r.score; depth = d;
      if (d >= e || score >= WIN || score <= -WIN) { exact = d >= e || Math.abs(score) >= WIN; break; }
    }
    return { move, score, depth, exact };
  }

  // root of one iteration: previous best first, then the order; ties broken at random
  root(d, prev) {
    const rootMob = d === 1 ? this.countMoves(this.side) : 0;
    const list = [];
    if (prev !== NONE) list.push(prev);
    for (const s of this.ORDER) if (s !== prev) list.push(s);
    let best = -INF, bmv = NONE, ties = 0, firstDone = false;
    for (const s of list) {
      if (this.bd[s] !== 0) continue;
      const n = this.make(s);
      if (!n) continue;
      if (n > this.maxFlips) this.maxFlips = n;
      this.count(this.iter1 ? 0 : this.limit);
      const alpha = bmv === NONE ? -INF : best - 1;
      const v = -this.node(1, d - 1, -INF, -alpha, rootMob, false);
      this.undo();
      if (this.abort) break;
      firstDone = true;
      if (v > best) { best = v; bmv = s; ties = 1; }
      else if (v === best) { ties++; if (((rnd(this) * ties) >> 8) === 0) bmv = s; }
    }
    return { move: bmv, score: best, firstDone };
  }

  ttIndex(k) { return (k >> 17) & (this.opts.tt - 1); }

  // ordinary search node: ply, depth left, window, the parent's mobility, passed flag
  node(ply, d, alpha, beta, parentMob, passed) {
    if (this.abort) return 0;
    if (d === 0) {
      if (this.empties() === 0) return this.final();
      return this.evaluate(parentMob);
    }
    let ttm = NONE, k = 0, idx = 0;
    if (d >= 3 && !passed && this.opts.tt) {
      k = this.key(); idx = this.ttIndex(k);
      if ((this.tt[idx] & 0xffff) === (k & 0xffff)) ttm = (this.tt[idx] >> 16) & 63;
      if (ttm !== NONE) ttm = R.idxOf(ttm);
    }
    const mob = d === 1 ? this.countMoves(this.side) : 0;
    const kil = this.opts.killer ? this.killer[ply] : NONE;
    let best = -INF, bmv = NONE, any = false;
    // stage 0: table move, 1: killer, then the order
    const cands = [];
    if (ttm !== NONE) cands.push(ttm);
    if (kil !== NONE && kil !== ttm) cands.push(kil);
    for (const s of this.ORDER) if (s !== ttm && s !== kil) cands.push(s);
    for (const s of cands) {
      if (this.bd[s] !== 0) continue;
      const n = this.make(s);
      if (!n) continue;
      if (n > this.maxFlips) this.maxFlips = n;
      any = true;
      this.count(this.iter1 ? 0 : this.limit);
      const v = -this.node(ply + 1, d - 1, -beta, -alpha, mob, false);
      this.undo();
      if (this.abort) return 0;
      if (v > best) { best = v; bmv = s; }
      if (v > alpha) alpha = v;
      if (alpha >= beta) { if (this.opts.killer) this.killer[ply] = s; break; }
    }
    if (!any) {
      if (passed) return this.final_();
      this.pass();
      const v = -this.node(ply, d, -beta, -alpha, parentMob, true);
      this.undo();
      return v;
    }
    if (d >= 3 && !passed && this.opts.tt) {
      this.tt[idx] = (k & 0xffff) | (R.sqOf(bmv) << 16);
    }
    return best;
  }

  // a finished game found by two passes: the side to move is the one that passed second,
  // scored from its view (the board is unchanged)
  final_() { return this.final(); }

  // ---------- exact ending ----------
  thinkExact(limit) {
    this.limit = limit;
    this.iter1 = false;
    const list = this.sortedMoves();
    let best = -INF, bmv = NONE, ties = 0;
    for (const s of list) {
      this.make(s);
      this.count(this.limit);
      const alpha = bmv === NONE ? -64 : best - 1;
      const v = -this.exact(-64, -alpha, false);
      this.undo();
      if (this.abort) return null;
      if (v > best) { best = v; bmv = s; ties = 1; }
      else if (v === best) { ties++; if (((rnd(this) * ties) >> 8) === 0) bmv = s; }
    }
    return { move: bmv, score: best, depth: this.empties(), exact: true, margin: true };
  }

  // legal moves of the side to move, fewest replies first (ties in the order table's order);
  // the trial moves are counted
  sortedMoves() {
    const out = [];
    for (const s of this.ORDER) {
      if (this.bd[s] !== 0) continue;
      if (!this.make(s)) continue;
      this.count(this.limit);
      const r = this.countMoves(this.side);
      this.undo();
      let i = out.length;
      while (i > 0 && out[i - 1][1] > r) i--;
      out.splice(i, 0, [s, r]);
    }
    return out.map(x => x[0]);
  }

  margin() { const m = this.ns - this.nh; return this.side === 1 ? m : -m; }

  exact(alpha, beta, passed) {
    if (this.abort) return 0;
    const e = this.empties();
    if (e === 0) return this.margin();
    if (e === 1) return this.lastOne();
    let ttm = NONE, k = 0, idx = 0;
    if (e >= 3 && !passed && this.opts.tt) {
      k = this.key(); idx = this.ttIndex(k);
      if ((this.tt[idx] & 0xffff) === (k & 0xffff)) {
        const w = this.tt[idx];
        ttm = R.idxOf((w >> 16) & 63);
        const kind = (w >> 22) & 3, sc = this.ttS[idx];
        if (kind === 3) return sc;
        if (kind === 2 && sc >= beta) return sc;
        if (kind === 1 && sc <= alpha) return sc;
      }
    }
    const a0 = alpha;
    let cands;
    if (e >= 5 && !passed) {
      cands = this.sortedMoves();
      if (this.abort) return 0;
      if (ttm !== NONE && cands.includes(ttm)) cands = [ttm, ...cands.filter(s => s !== ttm)];
    } else if (e >= 5) {
      cands = this.sortedMoves();
      if (this.abort) return 0;
    } else {
      cands = [];
      if (ttm !== NONE) cands.push(ttm);
      for (const s of this.ORDER) if (s !== ttm) cands.push(s);
    }
    let best = -INF, bmv = NONE, any = false;
    for (const s of cands) {
      if (this.bd[s] !== 0) continue;
      const n = this.make(s);
      if (!n) continue;
      any = true;
      this.count(this.limit);
      const v = -this.exact(-beta, -alpha, false);
      this.undo();
      if (this.abort) return 0;
      if (v > best) { best = v; bmv = s; }
      if (v > alpha) alpha = v;
      if (alpha >= beta) break;
    }
    if (!any) {
      if (passed) return this.margin();
      this.pass();
      const v = -this.exact(-beta, -alpha, true);
      this.undo();
      return v;
    }
    if (e >= 3 && !passed && this.opts.tt) {
      const kind = best <= a0 ? 1 : best >= beta ? 2 : 3;
      this.tt[idx] = (k & 0xffff) | (R.sqOf(bmv) << 16) | (kind << 22);
      this.ttS[idx] = best;
    }
    return best;
  }

  // one empty square left: count the flips, no move made
  lastOne() {
    let s = 0;
    for (const q of this.ORDER) if (this.bd[q] === 0) { s = q; break; }
    const p = this.side;
    const own = p === 1 ? this.ns : this.nh, opp = p === 1 ? this.nh : this.ns;
    let n = this.flipCount(s, p);
    if (n) { this.count(this.limit); return own + n + 1 - (opp - n); }
    n = this.flipCount(s, 3 - p);
    if (n) { this.count(this.limit); return own - n - (opp + n + 1); }
    return own - opp;
  }
}

module.exports = { Engine, LEVELS, TIP, QUARTER, WEIGHTS, SPEC_QUARTER, SPEC_WEIGHTS, CORNERS, squareValues, defaultOrder, WIN, EST, INF, NONE, MAXD, rnd };
