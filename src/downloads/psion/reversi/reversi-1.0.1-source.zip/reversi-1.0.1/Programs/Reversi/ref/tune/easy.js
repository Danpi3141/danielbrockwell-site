// The easy end of the ladder (v1.0, 22 Nov 2026): level 1 against a random mover, then each of
// levels 2-5 against the one below, the game's own LEVELS table.
//   node ref/tune/easy.js [openings]
'use strict';
const { match } = require('../match.js');
const n = +(process.argv[2] || 500);
const RANDOM = { think: { depth: 1, noise: 30000, exact: 0 } };      // every legal move alike
(async () => {
  const r = await match({ a: { level: 1 }, b: RANDOM, openings: n });
  console.log(`L1 v random: ${r.pct.toFixed(1)}% of ${r.games}, mean margin ${r.margin.toFixed(1)}`);
  for (let k = 2; k <= 5; k++) {
    const q = await match({ a: { level: k }, b: { level: k - 1 }, openings: n, plies: 8, oseed: 0x1EE7 + k });
    console.log(`L${k} v L${k - 1}: ${q.pct.toFixed(1)}% of ${q.games}, mean margin ${q.margin.toFixed(1)}`);
  }
})();
