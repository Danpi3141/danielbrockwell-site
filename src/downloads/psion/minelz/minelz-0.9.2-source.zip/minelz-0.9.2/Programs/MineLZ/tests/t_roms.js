'use strict';
// Every LZ and LZ64 ROM the emulator has (14, with the other languages), on the RELEASE pack
// (spec test plan: "ROMs"): the tiles, the menus, the keys. Start, a Quick game (first move,
// a flag on and off, F in lower case, S, pause and resume, a loss with the field shown, the
// result), Help, Best, Set and Quit back to the Organiser's own menu, whose top bar is left
// a plain line rather than tiles.
//   node tests/t_roms.js [rom...] [--small | --psion | --pack=FILE]
const { Game, ROMS, TILES, checker } = require('./lib');
const T = checker();
const args = process.argv.slice(2).filter((a) => !a.startsWith('--'));
const packArg = process.argv.find((a) => a.startsWith('--pack='));
let pack = packArg ? packArg.slice(7) : process.argv.includes('--small') ? 'MINELZ-small.opk' : 'MINELZ.opk';
if (process.argv.includes('--psion')) {
  // the files psion/ sends to a real Organiser (translated only), put on a pack image
  const fs = require('fs'), path = require('path'), { execFileSync } = require('child_process');
  const ROOT = path.join(__dirname, '..'), dir = path.join(ROOT, 'build', 'psioncheck');
  fs.rmSync(dir, { recursive: true, force: true }); fs.mkdirSync(dir, { recursive: true });
  for (const f of fs.readdirSync(path.join(ROOT, 'psion')).filter((n) => /^M\w*\.OB3$/.test(n))) {
    fs.copyFileSync(path.join(ROOT, 'psion', f), path.join(dir, f.replace(/_\.OB3$/, '%.OB3')));
  }
  pack = 'build/psion.opk';
  execFileSync('python', [path.join(ROOT, '..', '..', 'Tools', 'opl2opk.py'), '-f', path.join(ROOT, pack),
    ...fs.readdirSync(dir).map((f) => path.join(dir, f))], { stdio: 'ignore' });
}
const COV = '\u2460';
const TILE = /[\u2460-\u2466]/;
for (const rom of args.length ? args : Object.keys(ROMS)) {
  const bad = [];
  const want = (c, msg) => { if (!c) bad.push(msg); };
  try {
    const g = new Game(rom, { pack });
    const m = g.m;
    // the Prog menu's top bar before the game (UDG 5 is the clock's blinking colon)
    g.osMenu(); g.key('P', 1);
    const before = g.udgs().map((x) => x.join('.'));
    g.start().wait(/Play +Best +Set[^]*Help +Quit/);
    const u = g.udgs();
    want([0, 1, 2, 3, 4, 5, 6, 7].every((i) => u[i].join() === TILES[i].join()), 'tiles: ' + u.map((x) => x.join('.')).join(' '));
    g.key('P', 0.6).wait(/Quick +Beginner[^]*Intermed +Expert[^]*Custom/);
    g.key('Q', 1.5);
    want(g.rows().every((r) => r === COV.repeat(20)), 'Quick field: ' + g.line());
    g.find();
    const c0 = g.lcdCursor();
    want(c0.on && c0.row === 2 && c0.col === 10, `cursor ${JSON.stringify(c0)}`);
    g.key('EXE', 3);
    want(g.g('O') === 1 && /\u2465/.test(g.text()) && !g.checkWindow(), 'first move: ' + g.line());
    // a flag on a covered square on screen (Quick: the window never moves)
    const b = g.board();
    let fy = 0, fx = 0;
    for (let y = 1; y <= 4 && !fy; y++) for (let x = 1; x <= 20; x++) if (b[y - 1][x - 1] === '#') { fy = y; fx = x; break; }
    g.jump(fy, fx).key('MODE', 0.6).key('F', 0.8);
    want(g.ch(fy, fx) === 2 && g.m.cells()[(fy - 1) * 20 + fx - 1] === 2 && g.g('F') === 1, `flag at ${fy},${fx}: ${g.line()}`);
    // lower case: the keyboard's CAPS state ($7B, kbb_stat) switched to lower case, as SHIFT and UP do
    const st = m.peek(0x7B);
    m.poke(0x7B, st ^ 0x80);
    g.key('F', 0.8);
    m.poke(0x7B, st);
    want(g.ch(fy, fx) === 1 && g.g('F') === 0, `f (lower case) takes it off: ${g.line()}`);
    g.key('S', 0.8);
    want(/Mines 10  Time \d\d:\d\d/.test(g.text()) && /Col +\d+\/20 +Row \d\/4/.test(g.text()), 'S: ' + g.line());
    g.key('LEFT', 1);
    want(!/Mines/.test(g.text()) && !g.checkWindow(), 'S rows gone: ' + g.line());
    g.key('ON', 1).wait(/Paused +Time[^]*Resume +New +Menu/);
    g.key('EXE', 1.5);
    want(!g.checkWindow() && g.lcdCursor().on, 'resumed: ' + g.line());
    const [my, mx] = g.mines()[0];
    g.jump(my, mx).key('MODE', 0.6).key('EXE', 3);
    const shown = (g.board().join('').match(/[*@]/g) || []).length;
    want(g.g('O') === 2 && shown === 10 && !g.checkWindow(), `loss: ${shown} mines shown, ${g.line()}`);
    g.key('EXE', 1).wait(/BOOM! +Time \d\d:\d\d[^]*Mines found 0 of 10[^]*EXE=again  V=view[^]*ON=menu/);
    g.key('ON', 1).wait(/Play +Best/);
    g.key('H', 1);
    want(/Arrows  move[^]*EXE     uncover[^]*F       flag[^]*S       status/.test(g.text()), 'help 1: ' + g.line());
    g.key('EXE', 1);
    want(/EXE on a number with[^]*all its flags placed[^]*uncovers the rest[^]*ON      pause/.test(g.text()), 'help 2: ' + g.line());
    g.key('EXE', 1);
    want(/MineLZ \d+\.\d+\.\d+[^]*Daniel\+Claude/.test(g.text()), 'help 3: ' + g.line());
    g.key('EXE', 1).wait(/Play +Best/);
    g.key('B', 1).wait(/Quick +1\/4[^]*1\. --:--/).key('ON', 1).wait(/Play +Best/);
    g.key('S', 1).wait(/Sound: +ON[^]*EXE=change  ON=back/).key('ON', 1).wait(/Play +Best/);
    g.key('Q', 1.5);
    want(m.isOn() && !/MineLZ/.test(g.text()) && !TILE.test(g.text().split('\n').slice(1).join('')), 'quit: ' + g.line());
    // the Organiser's own bar at the top (its clock and battery are user-defined characters):
    // MineLZ leaves them a plain bar, and the Organiser draws its own again, as before the game
    g.run(1);
    const after = g.udgs().map((x) => x.join('.'));
    want(after.every((x, i) => i === 5 || x === before[i]), `the top bar's characters after quitting: ${after.join(' ')}, before: ${before.join(' ')}`);
    T.ok(!bad.length, `${rom.padEnd(13)} ${pack}${bad.length ? '\n  ' + bad.join('\n  ') : ''}`);
  } catch (e) { T.ok(false, `${rom} ${e.message.split('\n').join(' | ')}${bad.length ? ' | ' + bad.join(' | ') : ''}`); }
}
T.end();
