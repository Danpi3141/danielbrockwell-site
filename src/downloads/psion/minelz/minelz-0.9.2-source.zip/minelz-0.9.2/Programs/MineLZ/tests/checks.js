'use strict';
// Step 1 of the spec: the checks other than speed (bench.js). Runs tests/MLC.opl.
//   node tests/checks.js [rom]
const path = require('path');
const fs = require('fs');
const { execFileSync } = require('child_process');
const { Machine } = require('../tools/emu');
const ROOT = path.join(__dirname, '..');
const TOOLS = path.join(ROOT, '..', '..', 'Tools');
const out = path.join(ROOT, 'build', 'checks.opk');
fs.mkdirSync(path.dirname(out), { recursive: true });
execFileSync('python', [path.join(TOOLS, 'opl2opk.py'), '-f', '--rampak', out, path.join(__dirname, 'MLC.opl')], { stdio: 'ignore' });
const rom = process.argv[2] || '46a-lz64.rom';
const m = new Machine({ rom, ram: /lz64/.test(rom) ? 64 : 32 });
m.boot();
m.insertPack(out, 0);
m.runProc('MLC', 'B');
m.runSeconds(2);
const show = (t) => console.log('--- ' + t + '\n' + m.screenText());
show('NUM$ / tiles / cursor');
const d = []; m.disp.getSnapshotData(d);
console.log('cursor pos', d[1], 'on', d[4], 'underline', d[5], 'flash', d[6]);
console.log('pixels of row 3:\n' + m.pixels().slice(16, 24).join('\n'));
m.press('EXE', 3, 10); m.runSeconds(1); show('main menu under a title');
m.press('DOWN', 3, 5); m.runSeconds(0.5); show('after DOWN');
m.press('EXE', 3, 10); m.runSeconds(1); show('play menu (full screen MENU)');
m.press('ON', 3, 10); m.runSeconds(1); show('pause menu');
m.press('ON', 3, 10); m.runSeconds(1); show('after ON in pause menu');
m.runSeconds(1); show('EDIT prompt');
m.press('ON', 3, 5); m.runSeconds(0.5); show('EDIT after one ON');
m.press('ON', 3, 5); m.runSeconds(0.5); show('EDIT after two ONs');
m.press('EXE', 3, 10); m.runSeconds(1);
// the loop: let it wait 6 minutes and see whether the machine switches itself off
let offAt = -1;
for (let s = 0; s < 400; s += 5) { m.runSeconds(5); if (!m.isOn()) { offAt = s; break; } }
console.log('switched off after', offAt, 's of waiting in the PAUSE -8 loop; tmw_tcnt', m.peekw(0x20CD), 'swof', m.peek(0x7C));
show('loop screen');
if (offAt >= 0) { m.press('ON', 3, 10); m.runSeconds(1.5); show('after switching on'); }
m.press('ON', 3, 10); m.runSeconds(1); show('after ON in the loop (ESCAPE OFF)');
