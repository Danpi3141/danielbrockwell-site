'use strict';
// A tour of every screen and kind of action, for the memory test (and anything else that
// wants the whole program run once): every procedure is called from its deepest caller.
const { Model } = require('./model');

const QUICK = [[1, 20], [2, 20], [3, 20], [4, 20], [1, 18], [3, 18], [4, 16], [1, 13], [2, 11], [4, 9]];

// play a planted Quick board to a win (with a best time and initials saved) or a loss
function quick(g, end) {
  g.play(1);
  g.plant(QUICK);
  const md = new Model(20, 4, QUICK);
  g.jump(2, 3).act('EXE'); md.open(2, 3);
  // a flag, the status rows, clearing round a number (refused, then done), the pause
  g.jump(3, 17).act('F'); md.flag(3, 17);
  g.act('S'); g.act('LEFT');
  g.key('ON', 0.6).wait(/Resume/); g.key('EXE', 0.6); g.idle();
  if (end === 'lost') {
    g.jump(1, 20).act('EXE');
    g.act('RIGHT');
    g.key('EXE', 0.6).wait(/BOOM![^]*ON=menu/);
    g.key('V', 0.6); g.idle(); g.key('EXE', 0.6).wait(/BOOM![^]*ON=menu/);
    g.key('ON', 0.6).wait(/Play +Best/);
  } else {
    md.flag(3, 17); g.jump(3, 17).act('F');
    for (;;) {
      const sq = md.safe().find(([y, x]) => md.s[y][x] === '#');
      md.open(...sq);
      if (md.over) { g.jump(...sq); g.m.press('EXE', 2, 1); break; }
      g.jump(...sq).act('EXE');
    }
    g.wait(/CLEARED![^]*(EXE=enter initials|EXE=again)/, 20);
    if (/initials/.test(g.text())) {
      g.key('EXE', 0.5).wait(/Your initials/);
      if (g.rows()[2].trim()) g.key('ON', 0.2);
      g.type('MEM', 0.2).key('EXE', 0.8);
    }
    g.wait(/EXE=again +ON=menu/, 10).key('ON', 0.6).wait(/Play +Best/);
  }
  g.unplant();
}

function tour(g) {
  g.start();
  quick(g, 'won');
  quick(g, 'lost');
  // a big area on Expert (the deepest point of opening), then Beginner's and Intermediate's panels
  for (const sel of [4, 2, 3]) {
    g.play(sel);
    g.firstMove();
    g.act('S'); g.act('UP');
    g.key('ON', 0.6).wait(/Resume/).key('M', 0.6).wait(/Play +Best/);
  }
  // custom, Best (with a table cleared), Set, Help
  g.custom(7, 5, 3);
  g.key('ON', 0.6).wait(/Resume/).key('M', 0.6).wait(/Play +Best/);
  g.key('B', 0.6).wait(/\/4/).key('DEL', 0.5).wait(/Clear/).key('Y', 0.8).wait(/\/4/).key('ON', 0.6).wait(/Play +Best/);
  g.key('S', 0.6).wait(/Sound/).key('EXE', 0.4).key('EXE', 0.4).key('ON', 0.8).wait(/Play +Best/);
  g.key('H', 0.6).key('EXE', 0.4).key('EXE', 0.4).key('EXE', 0.6).wait(/Play +Best/);
  g.key('Q', 1);
}

module.exports = { tour, quick, QUICK };
