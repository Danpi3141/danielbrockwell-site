'use strict';
// Best times (spec test plan: "Best times"): fill a table, beat each place, ties, a time that
// doesn't place, leaving the initials without saving, a second table, the Best screen (left and
// right, DEL and Y or another key), and after a restart: the tables, the last initials offered
// again and the sound setting, all read back from A:MINEBEST, whose records are checked too.
//   node tests/t_best.js [lz|lz64]
const path = require('path');
const { execFileSync } = require('child_process');
const { Game, ROOT, checker } = require('./lib');
const { Model } = require('./model');
const T = checker();
const model = process.argv[2] || 'lz64';
const TOOLS = path.join(ROOT, '..', '..', 'Tools');
const tpack = path.join(ROOT, 'build', 'tests.opk');
execFileSync('python', [path.join(TOOLS, 'opl2opk.py'), '-f', '--rampak', tpack, path.join(__dirname, 'MLFILE.opl')], { stdio: 'ignore' });

const g = new Game(model);
g.m.insertPack(tpack, 1);
g.start();
const mmss = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

// Quick, on a fixed board: the first move opens most of it, the rest is opened one square at a
// time, and the clock is set just before the last one. Returns the time the game shows.
const QUICK = [[1, 20], [2, 20], [3, 20], [4, 20], [1, 18], [3, 18], [4, 16], [1, 13], [2, 11], [4, 9]];
function win(sel, secs) {
  g.wait(/Play +Best|EXE=again/);
  if (/Play +Best/.test(g.text())) g.play(sel); else g.key('EXE', 0.5).field();
  const [W, H] = [g.g('W'), g.g('H')];
  const mines = sel === 1 ? QUICK : [[1, 9], [2, 9], [3, 9], [9, 1], [9, 2], [9, 3], [5, 9], [9, 9], [7, 7], [1, 1]];
  g.plant(mines);
  const md = new Model(W, H, mines);
  const first = sel === 1 ? [2, 3] : [5, 4];
  g.jump(...first).act('EXE'); md.open(...first);
  // open safe squares one at a time until any further one would finish the board
  const covered = () => md.safe().filter(([y, x]) => md.s[y][x] === '#');
  const finishes = ([y, x]) => { const c = new Model(W, H, mines); c.s = md.s.map((r) => r.slice()); c.left = md.left; c.open(y, x); return c.left === 0; };
  for (;;) {
    const sq = covered().find((q) => !finishes(q));
    if (!sq) break;
    g.jump(...sq).act('EXE'); md.open(...sq);
  }
  const last = covered()[0];
  // the clock held still (rewritten every 22 ms) so the time is exactly secs
  const clock = g.m.read(0x20C8, 3);
  g.m.onChunk = () => g.m.write(0x20C8, clock);
  g.run(0.6); g.idle();               // a pass of the key loop reads the held clock
  g.setg('T', secs);
  g.jump(...last);
  g.m.press('EXE', 2, 1);
  g.wait(/CLEARED! +Time[^]*(EXE=enter initials|EXE=again)/, 15);
  g.m.onChunk = null;
  g.unplant();
  return /Time (\d\d):(\d\d)/.exec(g.text()).slice(1).reduce((a, b) => a * 60 + +b, 0);
}
// type initials over what is offered; null leaves with ON/CLEAR twice (not saved)
function initials(txt) {
  g.key('EXE', 0.4).wait(/Your initials:/);
  const offered = g.rows()[2].trim();
  if (txt === null) { for (let i = 0; i < 3 && !/EXE=again/.test(g.text()); i++) g.key('ON', 0.4); return offered; }
  if (txt !== undefined) { if (offered) g.key('ON', 0.2); g.type(txt, 0.2); }
  g.key('EXE', 0.6).wait(/EXE=again +ON=menu/, 10);
  return offered;
}
function best(table) {
  // the Best screen, from the main menu: returns the rows of the table chosen with RIGHT
  g.wait(/Play +Best/).key('B', 0.6).wait(/\/4/);
  for (let i = 0; i < 6 && !g.rows()[0].startsWith(table); i++) g.key('RIGHT', 0.4);
  return g.rows();
}

let s, r, offered;
s = win(1, 100);
T.ok(/New best time!/.test(g.text()) && /^Quick/.test(g.rows()[1]), `first win, ${mmss(s)}: ${g.line()}`);
offered = initials('DAN');
T.ok(offered === '' && /Best is 01:40  DAN/.test(g.text()), `initials DAN saved, nothing offered the first time: ${g.line()}`);
s = win(1, 200);
T.ok(/2nd best time!/.test(g.text()), `200 s is 2nd: ${g.line()}`);
offered = initials('ABC');
T.ok(offered === 'DAN', `the last initials are offered again (${offered})`);
s = win(1, 50);
T.ok(/New best time!/.test(g.text()), `50 s beats them: ${g.line()}`);
offered = initials();
T.ok(offered === 'ABC' && /Best is 00:50  ABC/.test(g.text()), `EXE keeps the offered ABC: ${g.line()}`);
s = win(1, 300);
T.ok(/Best is 00:50  ABC/.test(g.text()) && /EXE=again/.test(g.text()) && !/best time!/.test(g.text()), `300 s doesn't place: ${g.line()}`);
s = win(1, 150);
T.ok(/3rd best time!/.test(g.text()), `150 s is 3rd: ${g.line()}`);
initials('XYZ');
s = win(1, 100);
T.ok(/3rd best time!/.test(g.text()), `100 s ties with 2nd and goes after it: 3rd (${g.line()})`);
initials('EQ');
s = win(1, 100);
T.ok(!/best time!/.test(g.text()), `another 100 s doesn't beat the 3rd's 100: ${g.line()}`);
s = win(1, 10);
T.ok(/New best time!/.test(g.text()), `10 s would be best...`);
initials(null);
T.ok(/Best is 00:50  ABC/.test(g.text()), `...but leaving the initials with ON/CLEAR saves nothing: ${g.line()}`);
g.key('ON', 0.6);
r = best('Quick');
T.ok(r.join('|') === 'Quick            1/4|1. 00:50  ABC       |2. 01:40  DAN       |3. 01:40  EQ        ', `the Quick table: ${r.join('|')}`);
g.key('ON', 0.5);
s = win(2, 77);
T.ok(/New best time!/.test(g.text()) && /Beginner/.test(g.text()), `Beginner, 01:17: ${g.line()}`);
initials('BEG');
g.key('ON', 0.6);
r = best('Beginner');
T.ok(/1\. 01:17  BEG/.test(r[1]) && /2\. --:--/.test(r[2]), `the Beginner table: ${r.join('|')}`);
g.key('RIGHT', 0.4); T.ok(/^Intermediate +3\/4/.test(g.rows()[0]) && /--:--/.test(g.rows()[1]), `RIGHT: ${g.rows()[0]}`);
g.key('RIGHT', 0.4); g.key('RIGHT', 0.4); T.ok(/^Quick +1\/4/.test(g.rows()[0]), `RIGHT past Expert wraps to Quick`);
g.key('LEFT', 0.4); T.ok(/^Expert +4\/4/.test(g.rows()[0]), `LEFT from Quick wraps to Expert`);
g.key('RIGHT', 0.4);
g.key('DEL', 0.5).wait(/Clear the table for/);
T.ok(/Quick\?/.test(g.text()) && /Y=yes  other=no/.test(g.text()), `DEL asks: ${g.line()}`);
g.key('N', 0.5);
T.ok(/1\. 00:50  ABC/.test(g.text()), `another key keeps it: ${g.line()}`);
g.key('DEL', 0.5).wait(/Clear the table/).key('Y', 0.8);
T.ok(/^Quick/.test(g.rows()[0]) && /1\. --:--/.test(g.text()) && /3\. --:--/.test(g.text()), `Y clears it: ${g.line()}`);
g.key('ON', 0.5);
// sound off, then a restart
g.wait(/Play +Best/).key('S', 0.5).wait(/Sound: +ON/).key('EXE', 0.4);
T.ok(/Sound: +OFF/.test(g.text()), `Set: sound off (${g.line()})`);
g.key('ON', 0.8).wait(/Play +Best/);
g.osMenu();
g.start();
g.key('S', 0.5).wait(/Sound:/);
T.ok(/Sound: +OFF/.test(g.text()), `after a restart the sound is still off: ${g.line()}`);
g.key('EXE', 0.3).key('ON', 0.8).wait(/Play +Best/);
r = best('Quick');
const r2 = (g.key('RIGHT', 0.4), g.rows());
T.ok(/1\. --:--/.test(r[1]) && /1\. 01:17  BEG/.test(r2[1]), `after a restart: Quick cleared, Beginner kept (${r2.join('|')})`);
g.key('ON', 0.5);
s = win(2, 60);
offered = initials('NEW');
T.ok(offered === 'BEG', `after a restart the last initials (BEG) are offered (${offered})`);
g.key('ON', 0.6);
// the file itself: table 0 (sound off, last initials), Quick cleared, Beginner 60 NEW / 77 BEG
g.osMenu(); g.m.runProc('MLFILE', 'C');
const recs = [];
for (let i = 0; i < 10; i++) {
  g.run(0.6);
  if (/^END/.test(g.text())) break;
  recs.push(g.rows().map((x) => x.trim()).join(' / '));
  g.key('EXE', 0.2);
}
const want = ['T0 / 1 NEW| / -1 | / -1 |', 'T1 / -1 | / -1 | / -1 |', 'T2 / 60 NEW| / 77 BEG| / -1 |'];
const tables = recs.map((x) => x.replace(/^R\d+\/\d+ /, '')).sort();
T.ok(recs.length === 3 && JSON.stringify(tables) === JSON.stringify(want), `A:MINEBEST has one record a table: ${recs.join(' || ')}`);
g.key('EXE', 0.5);
T.end();
