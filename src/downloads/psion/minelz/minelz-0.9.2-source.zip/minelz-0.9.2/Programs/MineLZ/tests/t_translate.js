'use strict';
// The Organiser's own translator (Prog > Edit, MODE > Tran) on every procedure of
// build/MINELZ-src.opk (python build.py --source-only: the release source, untranslated),
// against the object code Tools/opltran.py put in MINELZ.opk: byte for byte the same.
//   node tests/t_translate.js [lz|lz64]
const fs = require('fs');
const path = require('path');
const { Game, ROOT, checker } = require('./lib');
const T = checker();
const model = process.argv[2] || 'lz64';

// the procedures in a pack image: name -> object code (hex)
function procs(d) {
  const out = {};
  let a = 10;
  while (a < d.length && d[a] !== 255) {
    const n = d[a], type = d[a + 1];
    if (n === 2 && type === 0x80) { a += 4 + ((d[a + 2] << 8) | d[a + 3]); continue; }
    const name = String.fromCharCode(...d.slice(a + 2, a + 10)).trim();
    a += 2 + n;
    if ((type & 0x7F) === 3 && a < d.length && d[a] === 2 && d[a + 1] === 0x80) {
      const len = (d[a + 2] << 8) | d[a + 3], b = d.slice(a + 4, a + 4 + len);
      a += 4 + len;
      if (type & 0x80) out[name] = Buffer.from(b.slice(2, 2 + ((b[0] << 8) | b[1]))).toString('hex');
    }
  }
  return out;
}
const built = procs([...fs.readFileSync(path.join(ROOT, 'MINELZ.opk')).slice(6)]);
const g = new Game(model, { pack: 'build/MINELZ-src.opk' }), m = g.m;
const pk = m.insertPack(path.join(ROOT, 'build', 'MINELZ-src.opk'), 0);
const data = () => { const o = []; for (let i = 0; i < 32768; i++) o.push(pk.readByte(i)); return o; };
for (const name of Object.keys(built)) {
  g.osMenu();
  g.key('P', 0.6).key('E', 0.6);
  for (let i = 0; i < 4 && !/Edit B:/i.test(g.text()); i++) m.press('MODE', 3, 12);
  if (/Edit B:\S/i.test(g.text())) m.press('ON', 3, 6);
  m.type(name, 3, 3);
  m.press('EXE', 3, 10); g.run(2);
  m.press('MODE', 3, 10); g.run(0.8);
  m.press('T', 3, 10);
  g.wait(/Save B:/, 120);
  m.press('EXE', 3, 10);
  g.wait(/Edit +New|Find +Save|ERR/, 120).run(1);
  const got = procs(data())[name];
  T.ok(got === built[name], `${model} ${name.padEnd(8)} ${got ? got.length / 2 + ' bytes' : 'not translated: ' + g.line()}${got && got !== built[name] ? ' should be ' + built[name].length / 2 : ''}`);
  for (let i = 0; i < 4; i++) m.press('ON', 3, 10);
}
T.end();
