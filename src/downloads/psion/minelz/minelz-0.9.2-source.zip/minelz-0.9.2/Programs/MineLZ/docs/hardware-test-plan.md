# Real hardware: what only it can show

Everything else was tested in the emulator (see the README). Copy `MINELZ.opk` (32K, with the
source) or `MINELZ-small.opk` (16K, translated only) to a Datapak, or load `psion/` with RPBOOT,
then **Prog → Run** `MINELZ`. Try it on an LZ and an LZ64.

| # | Model | Check | Emulator says |
|---|---|---|---|
| 1 | each | The tiles on the real screen: covered, flag, mine, hit mine, wrong flag, the dot, and the bold 1. Each readable at a glance, the 1 never taken for a flag, and the other digits clear beside them | Tiles as the spec drew them; the 1 as 0.9.1 drew it |
| 2 | each | The square under the flashing cursor can be read (the cursor alternates a block and an underline; the underline falls on the tiles' blank bottom row) | Readable half the time |
| 3 | each | Hold an arrow on Expert: the window scrolls smoothly and the cursor stops where you let go | 0.1 s a scroll, no overshoot |
| 4 | each | One numbered square: at once. A first move on Expert: about 2 to 3 seconds. A big area: drawn as it grows | 0.02 s; 2.5 s typical (deal 1.5 s); 108 squares 3 s |
| 5 | each | Sounds: the click, the flag pips, the low buzz on a wrong clear, the three falling notes of a mine, the four rising notes of a win; nothing with Sound OFF | Pitches and lengths as the spec's table |
| 6 | each | Left alone in a game for the machine's switch-off time (5 minutes unless set otherwise): it pauses and switches off; ON shows the pause screen; the minutes off don't count | Off at 296 s; time not counted |
| 7 | each | An alarm during a game: afterwards the game is paused, and Resume brings back the field and tiles | A clock jump pauses it |
| 8 | each | The clock against a stopwatch over a few minutes of play, and across midnight | 10 s counted as 10 |
| 9 | 32K LZ | With A: nearly full: MINELZ says how many bytes more it needs, and never stops with an error | Exact to the byte in the emulator |
| 10 | each | Quit: the Prog menu's top bar shows its own clock and battery again, not tiles | Restored within half a second |
| 11 | each | Best times survive switching off and running MINELZ again; DEL then Y clears one table | File checked record by record |
| 12 | each | Help's third page says MineLZ 0.9.2 | |
