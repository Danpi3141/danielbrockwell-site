'use strict';
// The Custom field (spec test plan: "Custom"): the entry screen and its limits (values out of
// range, not numbers, empty, refused with a beep), the mine limit following the width and
// height, ON/CLEAR clearing an entry and going back a step or out, the last values offered
// again; then the smallest field, the largest, and the most mines allowed on each: all start,
// play and end correctly (won and lost on fixed boards). Custom games keep no best times.
//   node tests/t_custom.js [lz|lz64]
const { Game, checker } = require('./lib');
const { Model, layout, rng } = require('./model');
const T = checker();
const model = process.argv[2] || 'lz64';
const g = new Game(model);
const m = g.m;
g.start();

const row = (n) => g.rows()[n - 1];
g.wait(/Play +Best/).key('P').wait(/Quick +Beginner/).key('C').wait(/Width/);
T.ok(/^Custom field/.test(row(1)) && /^Width  \(5-30\): 20/.test(row(2)), `the entry screen offers 20 x 4 with 14 mines first: ${g.line()}`);
// out of range, then not a number, then empty: each refused with a low beep, the entry stays
const tries = [['4', 'below 5'], ['31', 'above 30'], ['1+2', 'not a number'], ['', 'empty']];
for (const [v, what] of tries) {
  g.key('ON', 0.1);
  m.buzzStart(); g.type(v + '\n', 0.5); const notes = m.buzzStop();
  T.ok(/^Width  \(5-30\):/.test(row(2)) && !/Height/.test(g.text()) && notes.some((n) => n.hz > 340 && n.hz < 400),
    `width ${what} (${JSON.stringify(v)}) is refused with the low beep (${notes.map((n) => n.hz + 'Hz').join(',')})`);
}
g.key('ON', 0.1).type('12\n', 0.5);
T.ok(/^Width  \(5-30\): 12/.test(row(2)) && /^Height \(4-24\): 4/.test(row(3)), `width 12 taken, height offered: ${g.line()}`);
g.key('ON', 0.1).type('25\n', 0.5);
T.ok(!/Mines/.test(g.text()), 'height 25 refused');
g.key('ON', 0.1).type('9\n', 0.5);
T.ok(/^Mines  \(1-36\): 14/.test(row(4)), `12 x 9: the mines may be 1 to 36, 14 offered: ${row(4)}`);
g.key('ON', 0.1).type('37\n', 0.5);
T.ok(/^Mines  \(1-36\):/.test(row(4)) && g.find() === false || !g.waiting(), 'mines 37 refused');
// ON/CLEAR clears the entry; on an empty entry it goes back a step
g.key('ON', 0.2); g.key('ON', 0.4);
T.ok(!/Mines/.test(g.text()) && /^Height \(4-24\): 9/.test(row(3)), `ON/CLEAR twice on the mines goes back to the height: ${g.line()}`);
g.key('ON', 0.2); g.key('ON', 0.4); g.key('ON', 0.2); g.key('ON', 0.4);
T.ok(/Play +Best/.test(g.text()), `and back from the width leaves the entry: ${g.line()}`);
// the last values come back
g.key('P').wait(/Quick/).key('C').wait(/Width/);
T.ok(/^Width  \(5-30\): 12/.test(row(2)), `the width typed last time is offered: ${row(2)}`);
g.type('\n', 0.5);
T.ok(/^Height \(4-24\): 9/.test(row(3)), `and the height: ${row(3)}`);
g.type('\n', 0.5);
T.ok(/^Mines  \(1-36\): 14/.test(row(4)), `and the mines: ${row(4)}`);
g.key('ON', 0.2); g.key('ON', 0.4); g.key('ON', 0.2); g.key('ON', 0.4); g.key('ON', 0.2); g.key('ON', 0.4);
g.wait(/Play +Best/);
// a mine limit lower than the value offered: the offer is the limit
g.key('P').wait(/Quick/).key('C').wait(/Width/);
g.key('ON', 0.1).type('5\n', 0.4); g.key('ON', 0.1).type('4\n', 0.4);
T.ok(/^Mines  \(1-6\): 6/.test(row(4)), `5 x 4: 1 to 6 mines, 6 offered: ${row(4)}`);
g.key('ON', 0.2); g.key('ON', 0.4); g.key('ON', 0.2); g.key('ON', 0.4); g.key('ON', 0.2); g.key('ON', 0.4);
g.wait(/Play +Best/);

// play: the smallest and largest fields with the fewest and most mines, each won and lost
const fields = [[5, 4, 1], [5, 4, 6], [30, 24, 1], [30, 24, 240], [30, 4, 40], [5, 24, 40]];
for (const [W, H, N] of fields) {
  for (const end of ['won', 'lost']) {
    try {
      g.custom(W, H, N);
      const ok0 = g.g('W') === W && g.g('H') === H && g.g('N') === N && g.g('G') === 5;
      const r = rng(W * 1000 + H * 10 + N);
      const fy = 1 + Math.floor(r() * H), fx = 1 + Math.floor(r() * W);
      const mines = layout(W, H, N, r, fy, fx);
      g.plant(mines);
      const md = new Model(W, H, mines);
      md.open(fy, fx);
      if (md.over) { g.jump(fy, fx); m.press('EXE', 2, 1); } else g.jump(fy, fx).act('EXE');
      let n = 1;
      if (end === 'lost' && !md.over) {
        const [y, x] = mines[0];
        g.jump(y, x).act('EXE'); md.open(y, x); n++;
      }
      while (!md.over) {
        const [y, x] = md.safe().find(([a, b]) => md.s[a][b] === '#');
        md.open(y, x); n++;
        if (md.over) { g.jump(y, x); m.press('EXE', 2, 1); break; }
        g.jump(y, x).act('EXE');
      }
      g.settle();
      let res;
      if (md.over === 'won') {
        res = g.wait(/CLEARED![^]*EXE=again/, 20).text();
        T.ok(ok0 && new RegExp(`Custom ${W}x${H} ${N}`).test(res) && !/best time/.test(res), `${W}x${H}, ${N} mines: ${end === 'lost' ? '(no loss possible) ' : ''}won after ${n} moves; no best time (${g.line()})`);
      } else {
        const b = g.board().join('');
        const shown = (b.match(/[*@]/g) || []).length;
        T.ok(ok0 && shown === N && b === md.board().join(''), `${W}x${H}, ${N} mines: lost after ${n} moves, all ${N} mines shown`);
        g.key('EXE', 0.5).wait(/BOOM![^]*ON=menu/);
      }
      g.unplant();
      g.key('ON', 0.6).wait(/Play +Best/);
    } catch (e) { T.ok(false, `${W}x${H} ${N} ${end}: ${e.message}`); g.osMenu(); g.start(); }
  }
}
T.end();
