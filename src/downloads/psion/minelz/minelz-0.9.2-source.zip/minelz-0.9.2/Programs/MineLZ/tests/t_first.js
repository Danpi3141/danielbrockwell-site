'use strict';
// First moves and mine counts, with the game's own random deal (spec test plan: "First move"
// and "Mine count"). For each size: many first moves on corners, edges and anywhere; each must
// open an area (a dot), never a mine, with N% mines laid and none in the 3x3 round it, and the
// field must be the PC model's for that layout. The first 20 games of each size are then lost
// on purpose, and the mines shown counted. First-move times are recorded (deal + open + draw).
//   node tests/t_first.js [lz|lz64] [moves a size, default 200]
const { Game, SIZES, checker } = require('./lib');
const { Model } = require('./model');
const T = checker(); T.quiet = true;
const model = process.argv[2] || 'lz64';
const moves = +process.argv[3] || 200;
const g = new Game(model);
g.start();

const sizes = [['Quick', 1, ...SIZES[1]], ['Beginner', 2, ...SIZES[2]], ['Intermediate', 3, ...SIZES[3]],
  ['Expert', 4, ...SIZES[4]], ['Custom 30x24 240', 5, 30, 24, 240], ['Custom 5x4 6', 5, 5, 4, 6]];
const stats = [];
for (const [name, sel, W, H, N] of sizes) {
  const n = /Custom/.test(name) ? Math.max(20, moves / 4) : moves;
  if (sel === 5) g.custom(W, H, N); else g.play(sel);
  const opened = [], times = [];
  let bad = 0, lostOk = 0;
  for (let k = 0; k < n; k++) {
    // corners, then edges, then anywhere
    const corners = [[1, 1], [1, W], [H, 1], [H, W]];
    let y, x;
    if (k < 4) [y, x] = corners[k];
    else if (k < 24) { const e = k % 4; const t = 1 + ((k * 7) % (e < 2 ? W : H)); [y, x] = [[1, t], [H, t], [t, 1], [t, W]][e]; }
    else { y = 1 + ((k * 37) % H); x = 1 + ((k * 53) % W); }
    y = Math.min(y, H); x = Math.min(x, W);
    try {
      g.jump(y, x);
      // the time from the key being read to the key loop waiting again: deal, open and draw
      times.push(g.act('EXE'));
      const mines = g.mines();
      const md = new Model(W, H, mines);
      md.open(y, x);
      const near = mines.filter(([a, b]) => Math.abs(a - y) <= 1 && Math.abs(b - x) <= 1);
      // the mine map: only 0 and 1 (2 once a win has flagged them: MLMARK), and 0 on its border
      // (the length bytes included)
      let mapOk = true;
      const top = md.over === 'won' ? 2 : 1;
      for (let i = 0; i < (H + 2) * 33; i++) { const v = g.m.peek(g.addr.M + i), b = i % 33, r = (i / 33) | 0; if (v > top || (v && (b === 0 || b > W || r === 0 || r > H))) mapOk = false; }
      const err = [];
      if (mines.length !== N) err.push(`${mines.length} mines`);
      if (!mapOk) err.push('mine map');
      if (near.length) err.push('mine next to the first square');
      if (g.ch(y, x) !== 6) err.push(`first square shows ${g.ch(y, x)}`);
      if (g.board().join() !== md.board().join()) err.push('field differs from the model');
      if (g.g('C') !== md.left) err.push(`C% ${g.g('C')} model ${md.left}`);
      if (g.g('O') !== (md.over === 'won' ? 3 : 1)) err.push(`O% ${g.g('O')}`);
      if (!md.over && g.checkWindow()) err.push('screen ' + g.checkWindow());
      opened.push(W * H - N - md.left);
      if (err.length) { bad++; T.ok(false, `${name} first move ${y},${x}: ${err.join(', ')}\n${g.board().join('\n')}`); }
      if (md.over === 'won') {
        g.wait(/CLEARED![^]*(EXE=enter initials|EXE=again)/, 10);
        if (/initials/.test(g.text())) { g.key('EXE', 0.3).wait(/Your initials/); for (let i = 0; i < 3 && !/EXE=again/.test(g.text()); i++) g.key('ON', 0.4); }
        g.key('EXE', 0.5).field();
      } else if (k < 20) {
        // lose: uncover a mine, then count what the field shows
        const [my, mx] = mines[k % mines.length];
        g.jump(my, mx).act('EXE');
        md.lose(my, mx);
        const b = g.board().join('');
        const shown = (b.match(/[*@]/g) || []).length;
        const ok = shown === N && b === md.board().join('') && g.g('O') === 2 && !g.checkWindow();
        if (ok) lostOk++; else T.ok(false, `${name} loss ${k}: ${shown} mines shown of ${N}\n${g.board().join('\n')}`);
        g.key('EXE', 0.4).wait(/BOOM![^]*ON=menu/);
        if (!new RegExp(`found 0 of ${N}`, 'i').test(g.text())) T.ok(false, `${name} loss screen: ${g.line()}`);
        g.key('EXE', 0.5).field();
      } else {
        g.key('ON', 0.5).wait(/Resume/).key('N', 0.5).field();
      }
    } catch (e) { bad++; T.ok(false, `${name} move ${k} at ${y},${x}: ${e.message}`); g.osMenu(); g.start(); if (sel === 5) g.custom(W, H, N); else g.play(sel); }
  }
  g.key('ON', 0.5).wait(/Resume/).key('M', 0.5).wait(/Play +Best/);
  const q = (a, p) => { const s = a.slice().sort((u, v) => u - v); return s[Math.min(s.length - 1, Math.floor(p * s.length))]; };
  const st = { name, n, opened: [q(opened, 0.5), q(opened, 0.9), Math.max(...opened)], secs: [q(times, 0.5), q(times, 0.9), Math.max(...times)].map((v) => +v.toFixed(2)) };
  stats.push(st);
  T.ok(bad === 0 && lostOk === Math.min(20, n), `${model} ${name.padEnd(17)} ${n} first moves: an area every time, never a mine, field = model; ${lostOk} losses with every mine shown. Opened typical/90%/max ${st.opened.join('/')}, seconds ${st.secs.join('/')}`);
}
console.log(JSON.stringify(stats));
require('fs').writeFileSync(require('path').join(__dirname, '..', 'build', `first-${model}.json`), JSON.stringify(stats, null, 1));
T.end();
