"""Is an integer random number generator good enough for laying mines?

The deal in OPL is slow with RND (floating point: about 56 ms a try). An integer generator
in 16-bit OPL arithmetic needs no floating point. This compares boards dealt with candidate
generators against boards dealt with Python's own random numbers: how often each square is
mined, how many mines touch each other, and the counts of mines round each square.

    python tools/rngcheck.py
"""
import random
import statistics

M = 32749            # a prime below 32768


def is_primitive(a, m=M):
    phi = m - 1
    f, n, d = set(), phi, 2
    while d * d <= n:
        while n % d == 0:
            f.add(d)
            n //= d
        d += 1
    if n > 1:
        f.add(n)
    return all(pow(a, phi // p, m) != 1 for p in f)


def lehmer(a, seed):
    """s = a*s mod M by Schrage's method, as OPL would do it without overflowing 16 bits."""
    q, r = M // a, M % a
    assert r < q
    s = seed % (M - 1) + 1
    while True:
        s = a * (s % q) - r * (s // q)
        assert -32768 <= a * (s % q) <= 32767
        if s < 0:
            s += M
        yield s


def deal(W, H, N, nxt, fy, fx):
    mine = set()
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            mine.add((fy + dy, fx + dx))       # kept clear, as the game does
    keep = set(mine)
    n = W * H
    while len(mine) - len(keep) < N:
        q = nxt() % n
        sq = (q // W + 1, q % W + 1)
        if sq not in mine:
            mine.add(sq)
    return mine - keep


def stats(W, H, N, boards, make):
    freq = {}
    touch, counts = [], [0] * 9
    for b in range(boards):
        fy, fx = 1 + (b * 7) % H, 1 + (b * 13) % W
        m = deal(W, H, N, make(b), fy, fx)
        for s in m:
            freq[s] = freq.get(s, 0) + 1
        t = 0
        for (y, x) in m:
            t += sum((y + dy, x + dx) in m for dy in (-1, 0, 1) for dx in (-1, 0, 1) if dy or dx)
        touch.append(t / 2)
        for y in range(1, H + 1):
            for x in range(1, W + 1):
                if (y, x) not in m:
                    counts[sum((y + dy, x + dx) in m for dy in (-1, 0, 1) for dx in (-1, 0, 1) if dy or dx)] += 1
    f = list(freq.values())
    tot = sum(counts)
    return (statistics.mean(touch), statistics.pstdev(f) / statistics.mean(f), [round(c / tot, 4) for c in counts[:5]])


def main():
    W, H, N, boards = 30, 16, 99, 3000
    ref = stats(W, H, N, boards, lambda b: (lambda r=random.Random(b): (lambda: r.randrange(1 << 30)))())
    print("Python random:   touching pairs %.2f  square spread %.3f  counts 0-4 %s" % ref)
    for a in (171, 172, 177, 178, 179, 180):
        if not is_primitive(a) or M % a >= M // a:
            continue
        res = stats(W, H, N, boards, lambda b, a=a: (lambda g=lehmer(a, b * 2654435761 % M): (lambda: next(g)))())
        print("Lehmer a=%-4d   touching pairs %.2f  square spread %.3f  counts 0-4 %s" % ((a,) + res))


if __name__ == "__main__":
    main()
