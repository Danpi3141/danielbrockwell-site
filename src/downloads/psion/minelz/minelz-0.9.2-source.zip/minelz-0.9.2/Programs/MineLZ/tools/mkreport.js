'use strict';
// Builds docs/report.html from docs/report.template.html and the tests' own output:
// build/screens.json (tests/screens.js), build/speed-*.json (tests/t_speed.js),
// build/first-*.json (tests/t_first.js), build/logs/run_all.txt (tests/run_all.js), the packs.
//   node tools/mkreport.js
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');
const B = (f) => path.join(ROOT, 'build', f);
const read = (f) => JSON.parse(fs.readFileSync(f, 'utf8'));
const n = (v) => Number(v).toLocaleString('en-GB');

// the procedures in a pack image: name -> object code bytes
function procs(file) {
  const d = [...fs.readFileSync(file).slice(6)];
  const out = {};
  let a = 10;
  while (a < d.length && d[a] !== 255) {
    const len = d[a], type = d[a + 1];
    if (len === 2 && type === 0x80) { a += 4 + ((d[a + 2] << 8) | d[a + 3]); continue; }
    const name = String.fromCharCode(...d.slice(a + 2, a + 10)).trim();
    a += 2 + len;
    if ((type & 0x7F) === 3 && d[a] === 2 && d[a + 1] === 0x80) {
      const l = (d[a + 2] << 8) | d[a + 3], b = d.slice(a + 4, a + 4 + l);
      out[name] = { obj: (b[0] << 8) | b[1], src: (b[2 + ((b[0] << 8) | b[1])] << 8) | b[3 + ((b[0] << 8) | b[1])] };
      a += 4 + l;
    }
  }
  return out;
}
const used = (file) => { const d = fs.readFileSync(file); let e = d.length; return { size: 8 * d[7] * 1024, used: (d[3] << 16 | d[4] << 8 | d[5]) }; };

const build = fs.readFileSync(path.join(ROOT, 'build.py'), 'utf8');
const VERSION = /VERSION = "([^"]+)"/.exec(build)[1];
const NEED = +/NEED = (\d+)/.exec(build)[1];
const P = procs(path.join(ROOT, 'MINELZ-small.opk'));
const full = used(path.join(ROOT, 'MINELZ.opk')), small = used(path.join(ROOT, 'MINELZ-small.opk'));
const screens = read(B('screens.json'));
const speed = { lz64: read(B('speed-lz64.json')), lz: read(B('speed-lz.json')) };
const first = { lz64: read(B('first-lz64.json')) };
const log = fs.existsSync(B('logs/run_all.txt')) ? fs.readFileSync(B('logs/run_all.txt'), 'utf8') : '';
const runs = log.split('\n').filter((l) => /^(ok  |FAIL) t_/.test(l)).map((l) => {
  const m = /^(ok  |FAIL) (\S+) ?(.*?)  \((\d+) s\)  (.*)$/.exec(l);
  return m ? { ok: m[1] === 'ok  ', file: m[2], args: m[3], secs: +m[4], last: m[5] } : null;
}).filter(Boolean);
const checks = runs.reduce((s, r) => s + (+(/all (\d+) ok/.exec(r.last) || [0, 0])[1]), 0);

const data = { screens, procs: P, speed, first, runs, VERSION, NEED };
const vals = {
  VERSION, NEED: n(NEED), FULL: n(full.used), FULLK: full.size / 1024, SMALL: n(small.used), SMALLK: small.size / 1024,
  SMALLFREE: n(small.size - small.used), SMALLN: small.used, FULLN: full.used, CHECKS: n(checks), FILES: runs.length,
  ALLOK: runs.length && runs.every((r) => r.ok) ? 'all pass' : `${runs.filter((r) => !r.ok).length} failing`,
  CODE: n(Object.values(P).reduce((s, p) => s + p.obj, 0)), NPROCS: Object.keys(P).length,
  DATE: '26 November 2026',
};
let html = fs.readFileSync(path.join(ROOT, 'docs', 'report.template.html'), 'utf8');
html = html.replace(/\{\{(\w+)\}\}/g, (m, k) => { if (!(k in vals)) throw new Error('no value for ' + k); return String(vals[k]); });
html = html.replace('/*DATA*/null', JSON.stringify(data));
// the page's scripts must parse: one stray quote leaves every table and screen empty
for (const [, js] of html.matchAll(/<script>([\s\S]*?)<\/script>/g)) new Function(js);
fs.writeFileSync(path.join(ROOT, 'docs', 'report.html'), html);
console.log(`docs/report.html: ${html.length} bytes, ${screens.shots.length} screens, ${runs.length} test runs, ${checks} checks`);
