'use strict';
// The PC model of MineLZ's rules, for the tests: a field, its mines, and what uncovering,
// flagging and clearing round a number do to it. Boards use the game's own marks:
// # covered, P flag, * mine, @ the mine that was hit, X wrong flag, . open with no mines near, 1-8.
class Model {
  constructor(W, H, mines) {
    this.W = W; this.H = H;
    this.mine = []; this.s = [];
    for (let y = 0; y <= H + 1; y++) { this.mine.push(new Array(W + 2).fill(0)); this.s.push(new Array(W + 2).fill('#')); }
    for (const [y, x] of mines) this.mine[y][x] = 1;
    this.N = mines.length; this.flags = 0; this.over = '';
    this.left = W * H - this.N;            // covered safe squares
  }
  in(y, x) { return y >= 1 && y <= this.H && x >= 1 && x <= this.W; }
  near(y, x) { const r = []; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) if ((dy || dx) && this.in(y + dy, x + dx)) r.push([y + dy, x + dx]); return r; }
  count(y, x) { return this.near(y, x).filter(([a, b]) => this.mine[a][b]).length; }
  // uncover a covered square; returns 'mine', or the number of squares opened
  open(y, x) {
    if (this.s[y][x] !== '#') return 0;
    if (this.mine[y][x]) { this.lose(y, x); return 'mine'; }
    let n = 0;
    const stack = [[y, x]];
    const seen = new Set([y * 100 + x]);
    while (stack.length) {
      const [a, b] = stack.pop();
      const c = this.count(a, b);
      this.s[a][b] = c ? String(c) : '.'; n++; this.left--;
      if (!c) for (const [p, q] of this.near(a, b)) if (this.s[p][q] === '#' && !seen.has(p * 100 + q)) { seen.add(p * 100 + q); stack.push([p, q]); }
    }
    if (this.left === 0) this.win();
    return n;
  }
  // EXE on a number: 'refused' unless its flags equal it, else 'mine' or the number opened
  chord(y, x) {
    const v = this.s[y][x];
    if (!/[1-8]/.test(v)) return 0;
    const near = this.near(y, x);
    if (near.filter(([a, b]) => this.s[a][b] === 'P').length !== +v) return 'refused';
    for (const [a, b] of near) if (this.s[a][b] === '#' && this.mine[a][b]) { this.lose(a, b); return 'mine'; }
    let n = 0;
    for (const [a, b] of near) { const r = this.open(a, b); if (typeof r === 'number') n += r; if (this.over) break; }
    return n;
  }
  flag(y, x) {
    if (this.s[y][x] === '#') { this.s[y][x] = 'P'; this.flags++; } else if (this.s[y][x] === 'P') { this.s[y][x] = '#'; this.flags--; }
  }
  lose(y, x) {
    this.over = 'lost';
    for (let a = 1; a <= this.H; a++) for (let b = 1; b <= this.W; b++) {
      if (this.mine[a][b] && this.s[a][b] !== 'P') this.s[a][b] = '*';
      if (!this.mine[a][b] && this.s[a][b] === 'P') this.s[a][b] = 'X';
    }
    this.s[y][x] = '@';
  }
  win() {
    this.over = 'won';
    for (let a = 1; a <= this.H; a++) for (let b = 1; b <= this.W; b++) if (this.mine[a][b]) this.s[a][b] = 'P';
    this.flags = this.N;
  }
  rightFlags() { let n = 0; for (let a = 1; a <= this.H; a++) for (let b = 1; b <= this.W; b++) if (this.mine[a][b] && this.s[a][b] === 'P') n++; return n; }
  board() { const r = []; for (let y = 1; y <= this.H; y++) r.push(this.s[y].slice(1, this.W + 1).join('')); return r; }
  // safe squares, for tests that play a whole board
  safe() { const r = []; for (let y = 1; y <= this.H; y++) for (let x = 1; x <= this.W; x++) if (!this.mine[y][x]) r.push([y, x]); return r; }
}

// a random layout of n mines on W x H, none in the 3x3 round (fy, fx) if given; rng returns [0,1)
function layout(W, H, n, rng, fy, fx) {
  const out = [], used = new Set();
  while (out.length < n) {
    const y = 1 + Math.floor(rng() * H), x = 1 + Math.floor(rng() * W);
    if (used.has(y * 100 + x) || (fy && Math.abs(y - fy) <= 1 && Math.abs(x - fx) <= 1)) continue;
    used.add(y * 100 + x); out.push([y, x]);
  }
  return out;
}

// a small seeded random number generator, so test boards are the same every run
function rng(seed) {
  let s = seed >>> 0 || 1;
  return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
}

module.exports = { Model, layout, rng };
