'use strict';
// Step 1 of the spec: measure. Builds a pack from tests/MLB*.opl and runs MLB on a ROM.
//   node tests/bench.js [rom] [MLB|MLB2]
const path = require('path');
const fs = require('fs');
const { execFileSync } = require('child_process');
const { Machine } = require('../tools/emu');
const ROOT = path.join(__dirname, '..');
const TOOLS = path.join(ROOT, '..', '..', 'Tools');
const out = path.join(ROOT, 'build', 'bench.opk');
fs.mkdirSync(path.dirname(out), { recursive: true });
execFileSync('python', [path.join(TOOLS, 'opl2opk.py'), '-f', '--rampak', out,
  path.join(__dirname, 'MLB.opl'), path.join(__dirname, 'MLB2.opl'), path.join(__dirname, 'MLBP.opl')], { stdio: 'ignore' });
const rom = process.argv[2] || '46a-lz64.rom';
const m = new Machine({ rom, ram: /lz64/.test(rom) ? 64 : 32 });
m.boot();
m.insertPack(out, 0);
m.runProc(process.argv[3] || 'MLB', 'B');
const t0 = m.cycles();
for (let i = 0; i < 600 && !/^F\d+ |DONE/m.test(m.screenText()); i++) m.runSeconds(0.25);
console.log(m.screenText());
console.log('total', ((m.cycles() - t0) / 921600).toFixed(1), 's');
// where the arrays are
const txt = m.screenText();
const hx = txt.match(/F\s*\d+ ([0-9A-F]+) ([0-9A-F]+)/);
if (hx) {
  const a = parseInt(hx[1], 16), b = parseInt(hx[2], 16);
  console.log('ADDR(M%()) bytes before:', m.read(a - 4, 4).map((v) => v.toString(16)), 'first', m.read(a, 6));
  console.log('ADDR(R$()) bytes before:', m.read(b - 4, 4).map((v) => v.toString(16)), 'first', m.read(b, 8));
  console.log('R$(5) at element 5:', String.fromCharCode(...m.read(b + 4 * 33, 34)));
}
