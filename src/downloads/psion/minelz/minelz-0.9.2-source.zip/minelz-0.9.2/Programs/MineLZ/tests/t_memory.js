'use strict';
// Memory (spec test plan: "Memory"). 1: the tour of every screen with the free memory sampled
// every 22 ms: how much the game takes beyond what is free as MINELZ starts, and where.
// 2: with exactly that much free (the allocator's top moved up to take the rest), the whole
// tour runs; with one byte less, MINELZ says how much more it needs and stops cleanly.
// Run on a 32K LZ and an LZ64. The figure is build.py's NEED.
//   node tests/t_memory.js [--measure]
const { Game, checker } = require('./lib');
const { tour } = require('./tour');
const T = checker();
const measureOnly = process.argv.includes('--measure');
const BUILD = require('fs').readFileSync(require('path').join(__dirname, '..', 'build.py'), 'utf8');
const NEED = +/NEED = (\d+)/.exec(BUILD)[1], FILE_NEW = +/FILE_NEW = (\d+)/.exec(BUILD)[1], FILE_GROWS = +/FILE_GROWS = (\d+)/.exec(BUILD)[1];

const free = (m) => m.peekw(0xA5) - m.peekw(0x2040) - 256;
function profile(model, pack) {
  const g = new Game(model);
  const m = g.m;
  // FREE as MINELZ starts: what the OS menu has, less MINELZ's own frame, read just as it runs
  let start = null, low = 1e9, where = '';
  m.onChunk = () => {
    const f = free(m);
    if (start === null && /^MineLZ/.test(g.text())) start = null;
    if (f < low) { low = f; where = g.line(); }
  };
  g.osMenu();
  const osFree = free(m);
  tour(g);
  m.onChunk = null;
  return { osFree, low, used: osFree - low, where };
}

// FREE inside MINELZ: the dev build's MINELZ is the same as the release one up to its check, so
// with the allocator's top at os - k, MINELZ reads FREE = os - k - frame. Find frame once.
function run(model, frame, want, withFile) {
  const g = new Game(model);
  const m = g.m;
  // the best-times file first, if wanted: on a 32K LZ it takes some of FREE
  if (withFile) { g.start(); require('./tour').quick(g, 'won'); g.key('Q', 1); }
  g.osMenu();
  // MINELZ's frame, here: with 2000 free at the menu its message says how much it is short
  const top = m.peekw(0x2040), os = free(m), add = withFile ? 0 : FILE_NEW;
  m.pokew(0x2040, top + os - 2000);
  m.runProc('MINELZ', 'B'); g.run(2);
  const msg = /MineLZ needs (\d+)/.exec(g.text());
  if (!msg) return { err: 'no message with 2000 free: ' + g.line(), txt: '' };
  frame = 2000 - (NEED + add - +msg[1]);
  g.key('EXE', 1);
  // the allocator's top moved up so that MINELZ sees FREE = want
  m.pokew(0x2040, top + os - frame - want);
  let err = '';
  try { tour(g); } catch (e) { err = e.message.split('\n').slice(0, 5).join(' | '); }
  const txt = g.text();
  return { err, txt, g };
}

for (const model of ['lz', 'lz64']) {
  const p = profile(model);
  console.log(`${model}: free at the OS menu ${p.osFree}, lowest during the tour ${p.low} (${p.used} used), at: ${p.where}`);
  if (measureOnly) continue;
  // the tour with just enough: the OS menu's free less what the tour used, plus MINELZ's check
  const g = new Game(model);
  const m = g.m;
  g.osMenu();
  const os = free(m), top = m.peekw(0x2040);
  // leave NEED free inside MINELZ: MINELZ's frame (its code and a local) is the difference between
  // the OS menu's FREE and the FREE it sees; find it by the message with too little memory
  m.pokew(0x2040, top + os - 2000);
  g.m.runProc('MINELZ', 'B'); g.run(2);
  const msg = /MineLZ needs ?(\d+)/.exec(g.text());
  const frame = msg ? +msg[1] + 2000 - NEED - FILE_NEW : NaN;   // needs = NEED+FILE_NEW(no file) - (2000 - frame)
  console.log(`${model}: MINELZ's own frame ${frame}; the game needs ${p.used - frame} beyond the FREE MINELZ sees`);
  g.key('EXE', 1);
  T.ok(msg && /more bytes free/.test(g.text().replace(/\n/g, ' ')) || msg, `${model}: with 2000 bytes free MINELZ says it needs ${msg && msg[1]} more and stops`);
  // what the game takes beyond the FREE MINELZ sees must be inside NEED (not living off the
  // 256 bytes OPL keeps in reserve)
  T.ok(p.used - frame + FILE_GROWS <= NEED, `${model}: the game takes ${p.used - frame} beyond what MINELZ sees, and the best-times file can grow by ${FILE_GROWS}; NEED is ${NEED}`);
  m.pokew(0x2040, top);
  // with no best-times file MINELZ wants FILE_NEW more for it; with the file there, NEED
  for (const file of [false, true]) {
    const want = NEED + (file ? 0 : FILE_NEW);
    for (const [k, label] of [[0, 'exactly enough'], [1, 'one byte short']]) {
      const r = run(model, frame, want - k, file);
      const what = `${model}, ${file ? 'best-times file there' : 'no best-times file'}: ${label} (FREE ${want - k} in MINELZ)`;
      if (k === 0) T.ok(!r.err && !/ERROR|OUT OF MEMORY/.test(r.txt), `${what}: the whole tour runs${r.err ? ' - ' + r.err : ''}`);
      else T.ok(/MineLZ needs 1\b/.test(r.err + r.txt), `${what}: MINELZ says it needs 1 more byte`);
    }
  }
}
T.end();
