# MineLZ

Minesweeper for the Psion Organiser II LZ and LZ64, in OPL. The field fills all four rows of the
screen, and bigger fields scroll under the 20 by 4 window, which follows the cursor and always
shows its eight neighbours. The first move always opens an area.

Built from *MineLZ: design spec* (25 Nov 2026, `docs/spec.docx`): version 1, pure OPL. The
spec's second stage, no-guess mode with a machine-code solver, is not in this version. Changes
from the spec are listed at the end; `docs/report.html` is the full report, with the screens.

Version 0.9.2, tested in the emulator on every LZ and LZ64 ROM. Not yet tried on a real
Organiser (`docs/hardware-test-plan.md`).

## Playing it

**Jape:** Select OPK file... → `MINELZ.opk` → type a name → Create → Slot B.
**Organiser:** Prog → Run, press MODE until the prompt shows `B:`, type `MINELZ`, EXE.

| Pack | What it holds |
|---|---|
| `MINELZ.opk` | 32K Datapak: the 20 procedures translated, with their source (so they can be edited and translated on the Organiser) |
| `MINELZ-small.opk` | 16K Datapak: the same, translated only. Plays the same |
| `psion/` | For a real Organiser with Psi2Win: the `.OB3` procedures translated only (11K, so they also fit A: on a 32K LZ with room to play), their source in `opl/`, and the RPBOOT/RPLOAD loader with its file list. In Psi2Win set the folder to `psion/`, then **Prog → Run** `RPBOOT` on the Organiser |

MineLZ needs 5,950 bytes free (5,992 until its best-times file exists), about 27% of what an LZ
has free. With less, it says how many more bytes it needs and stops.

### The games

| Game | Field | Mines | Beside the field |
|---|---|---|---|
| Quick | 20 × 4 | 10 | nothing: the whole field is in view; S shows the status |
| Beginner | 9 × 9 | 10 | a wide panel: mines left, time, rows in view, the game |
| Intermediate | 16 × 16 | 40 | a narrow panel: mines left, minutes, seconds, the cursor's row |
| Expert | 30 × 16 | 99 | scrolls both ways; S shows the status |
| Custom | 5 to 30 × 4 to 24 | 1 to a third of the squares | the panel that fits its width |

### Keys

| Key | In play |
|---|---|
| Arrows | Move the cursor. Holding one repeats it; arrow repeats still waiting after a move are dropped, so the cursor stops where you let go |
| EXE | Uncover a covered square. On a number with all its flags placed: uncover its other neighbours (with too few or too many flags, a low buzz). On a flag: nothing |
| F | Place a flag on a covered square, or take it off (F or f) |
| S | Mines left, time, and the cursor's column and row, over the two rows furthest from the cursor, until the next key |
| ON/CLEAR | Pause: the field is hidden and the clock stops. Resume, New (a new board of the same size) or Menu |

Before the first move only the arrows, EXE and ON/CLEAR do anything. After a mine is hit every
mine is shown (the hit one crossed out, wrong flags marked); the arrows still scroll the field,
and EXE (or ON/CLEAR) shows the result. EXE plays again, V looks at the field again, ON/CLEAR
goes to the menu.

The clock starts once the first area is on screen and counts only play: not the pause, not
time with the machine off. Left alone for the machine's switch-off time (five minutes unless
set otherwise), the game pauses and the machine switches off; switching on shows the pause screen.

The best three times of Quick, Beginner, Intermediate and Expert are kept with initials in
`A:MINEBEST`, with the sound setting. **Best** shows them a table at a time (LEFT and RIGHT
change the game, DEL then Y clears one); **Set** turns the sound on or off. Custom games keep
no best times.

## Files

| Path | What it is |
|---|---|
| `src/*.opl` | The 20 procedures; `MINELZ` is the one to run. Each begins with what it does |
| `build.py` | Builds the packs (below) |
| `tests/` | The tests (see *How it was tested*), `tests/run_all.js` runs them all |
| `tests/model.js` | The game's rules written separately in JavaScript, to check the program against |
| `tests/lib.js`, `tools/emu.js` | Drive the emulator: Jape's own sources run under Node with the real ROMs |
| `tests/MLB.opl`, `MLB2.opl`, `MLC.opl` | The spec's build step 1: speed benches and checks (`bench.js`, `checks.js`) |
| `tools/rngcheck.py` | Compares the integer generator's boards with true random ones |
| `tools/mkreport.js`, `docs/report.template.html` | Build `docs/report.html` from the tests' output |
| `docs/` | The spec, the report, the hardware test plan |

```bash
python build.py
```
```bash
python build.py --dev
```
```bash
python build.py --psion
```
```bash
node tests/run_all.js
```

`python build.py` writes `MINELZ.opk` and `MINELZ-small.opk`; `--dev` writes
`build/MINELZ-dev.opk` with the test hooks (lines with `REM DEBUG`); `--source-only` writes
`build/MINELZ-src.opk`, the release source untranslated, for checking the Organiser's own
translator; `--psion` also writes `psion/`.

**Names.** In `src/` the globals have readable names (`Width%`, `CurX%`, `ToOpen%`, ...). OPL
keeps a global's name in every procedure that uses it, so the build gives each one or two
letters on the packs (`build.py`'s `SHORT` table: `W%`, `X%`, `C%`, ...); the long names would
cost about 270 bytes at the game's deepest point. Locals keep their names, which cost nothing
once translated. On the pack, `MLMAIN`'s source starts with the table, for editing there. The
build refuses a local or parameter named like a global, long or short: OPL names ignore case,
so a local `c%` would be the global `C%`.

## How it is built

The field lives in two string arrays with the same layout. `Board$(26,32)` holds the field's
rows as screen characters, one row an element: square (y, x) is byte `y×33+x` from
`ADDR(Board$())`, the length byte in front of each row being the left border. The screen rows
are the game's state:
a square is covered (1), flagged (2), a mine (3), the hit mine (4), a wrong flag (5), open with
no mines near (6, a dot) or a digit (the 1 is tile 0, a bold 1: the Organiser's own 1 is
hard to tell from the flag), and a row of the screen is one `PRINT MID$` of its string.
`MineMap$(26,32)` holds the mines, one byte a square (1 a mine), laid out the same way, so one
number names a square in both and the eight neighbours are fixed steps of 1, 32, 33 and 34
either way. Its length bytes stay 0, as they are the left border, where there are no mines; a
row's length is put in only while `LOC` looks for its mines (a loss, a win). A border of open,
mine-free squares removes the edge cases.

| Procedure | Bytes | Job |
|---|---|---|
| `MINELZ` | 136 | Checks there is room, then runs `MLMAIN` with ON/CLEAR as an ordinary key (`ESCAPE OFF`) |
| `MLMAIN` | 549 | Declares the data, sets the tiles, reads the setting, the main menu, games until it is wanted |
| `MLTILE` | 240 | The tiles: the six, 0 a bold 1, and 7: a covered square waiting to be opened |
| `MLSIZE%` | 295 | The Play menu: the fixed sizes, or Custom |
| `MLCUST%` | 620 | Custom: width, height and mines, with their limits |
| `MLNEW` | 357 | A new game: the field covered, no mines, the cursor, the window and the panel |
| `MLGAME%` | 2,026 | One game: the key loop and the clock, moves and scrolls, a numbered square, flags, S, pause |
| `MLCLOCK%` | 58 | Reads the time of day for the game clock |
| `MLDRAW` | 592 | The four rows and the panels beside a narrow field |
| `MLDEAL` | 454 | Lays the mines after the first move, none round it |
| `MLOPEN%` | 1,232 | Opens an area, finding the squares waiting with `LOC`; clears round a number |
| `MLSTAT` | 269 | The S rows |
| `MLPAUS%` | 154 | The pause screen, and switching off |
| `MLMARK` | 343 | Every mine shown: after a loss (the hit one, wrong flags crossed) or a win (flagged) |
| `MLLOSS%` | 314 | The result of a loss |
| `MLWIN%` | 672 | A win: the finished field, the result, a best time's initials |
| `MLBEST%` | 1,778 | `A:MINEBEST`: the setting and the best times; the Best screen |
| `MLSET` | 172 | The Set screen |
| `MLHELP` | 366 | Help, three pages |
| `MLSND` | 174 | The longer sounds, behind the setting |

OPL keeps a procedure's code in memory while it runs and reads it again from the pack at every
call (about 14 ms, more for a big one), so the busiest work is done in `MLGAME%` itself: moving,
scrolling (four row prints), a numbered square (one count, one poke, one print), a flag.

- **An area:** a square waiting to be opened is marked in its row (7, drawn as covered), so it
  is marked once, and the next is found with `LOC`, a row at a time, from the first row that can
  have one; a square with no mines near marks its covered neighbours, and any in the row above
  take the search back a row. Every 16 squares the screen is drawn again, so a large area is seen
  growing. (Up to 0.9.1 the squares went on a stack of 1,440 bytes.)
- **The mines** are laid after the first EXE, round it. `RND` is floating point (about 56 ms a
  try: 7.7 s for Expert, now 1.5 s), so it only seeds Lehmer's `s = 171·s mod 32749`, worked out by
  Schrage's method in 16-bit OPL; `tools/rngcheck.py` compares its boards with true random ones.
  The first square and its neighbours are marked as mined while the mines go down.
- **The clock** is looked at on every pass of the key loop (`PAUSE -8`, 0.4 s) and read in full
  (floating point, slow) when its second has changed. A jump of more than 5 s means the machine
  was off, or an alarm rang: the game pauses. The machine switches itself off even in that loop,
  so the game pauses itself when 3 s of the machine's own count are left; keys read with `KEY`
  don't put that count back as the machine's own key waits do, so the game does it.
- **Memory:** the arrays are a fixed 1,722 bytes. The deepest point is opening an area
  (`MLGAME%` and `MLOPEN%` in memory together): 5,933 bytes used on a 32K LZ (8,568 in 0.9.1,
  10,464 in the first build). What runs once a game (`MLNEW`), the Play menu (`MLSIZE%`) and a
  win's result (`MLWIN%`) are never in memory with `MLGAME%`, and what is loaded over it at a
  loss is small (`MLMARK`, `MLLOSS%`). On a 32K LZ the best-times file shares the memory: 42
  bytes when made, 165 with every table full, and `MINELZ` keeps room for it to grow.

## Measured

The spec's estimates assumed 400 OPL statements a second; simple integer statements run at
about 2,000. In the emulator (LZ64; the LZ the same within a frame):

| Action | Spec's estimate | Measured |
|---|---|---|
| Move, no scroll | under 0.05 s | 0.015 s |
| Move with a scroll | about 0.1 s | 0.1 s |
| Uncover one square | under 0.1 s | 0.02 s |
| Clear round a number | up to 0.3 s | 0.3 s |
| Lay 99 mines | about 1 s | 1.4 s |
| First move on Expert, deal included | 1.3 to 3.4 s | 2.4 s typical, 3.3 s for 9 in 10 (200 deals) |
| An area of 108 squares | | 2.95 s |
| An area of 380 squares (99 mines packed in a corner) | 9 s for 143 | 10.0 s |
| A loss on Expert, every mine shown | about 1 s | 1.2 s |

`docs/report.html` has these from the test run and the first-move statistics of 200 real
deals on each size against the spec's simulation.

## How it was tested

All in the emulator, `node tests/run_all.js` (about ten minutes; `--quick` for a short run):

| Test | What it covers |
|---|---|
| `t_rules.js` | Fixed boards on seven sizes against `tests/model.js`: every number, area, flag, clearing round a number (opens, loses, refuses), wins with no, some and all flags, losses with the right flags counted; the whole field, the counts, the state and the screen compared after every action |
| `t_first.js` | 200 first moves a size on corners, edges and anywhere, with the real deal: an area every time, never a mine, the mines laid right, the field as the model; 20 losses a size with every mine shown; timings |
| `t_window.js` | The cursor walked round every edge and through the middle of ten sizes: the window's margins, the neighbours on screen, the machine's cursor on the square, nothing outside the field, the panels; arrows held down, and no overshoot when let go |
| `t_clock.js` | Play counted, the pause not, a clock jump pauses without counting, midnight, S's time, switching off after the machine's own time and back to the pause screen, its setting (30 s, disabled), 99:59, the pass count wrapping |
| `t_best.js` | A table filled, each place beaten, ties, a time that doesn't place, initials offered again and left unsaved, two tables, the Best screen, DEL with Y and another key, a restart, the sound setting kept, the file's records |
| `t_custom.js` | The entry: out of range, not a number, empty (each refused with the buzz), ON/CLEAR back a step and out, the last values offered; 5×4 and 30×24 with the fewest and most mines, and 30×4, 5×24: won and lost |
| `t_sound.js` | Every sound's notes on the buzzer against the spec's table; one click for an area; nothing with sound off |
| `t_tick.js` | The time counting each second on the panel and on S's status rows; the 1 drawn as tile 0 in the field and on the screen |
| `t_memory.js` | The deepest point of a tour of every screen, with room for the best-times file to grow; `MINELZ`'s check a byte either side, with and without the file, on an LZ and an LZ64 |
| `t_roms.js` | The release pack on all 14 LZ and LZ64 ROMs (the other languages too): tiles, menus, keys, a game, Help, Best, Set, Quit and the Organiser's top bar after it. Also the 16K pack, and `psion/`'s files put on a pack |
| `t_translate.js` | The Organiser's own translator on every procedure: the same object code as `Tools/opltran.py`, byte for byte |
| `t_speed.js` | The table above |
| `t_stress.js` | Random keys through every screen for half an hour of emulated time: no error, no hang, the field and its counts always right |

Not checked: a real Organiser. Jape's `BEEP` takes no time, so the sounds' lengths are those of
the buzzer's edges; the tiles on a real screen; timings against a stopwatch.

## Changes from the spec

| Spec | Built | Why |
|---|---|---|
| `MINELZ` declares the data | `MINELZ` checks the memory, then `MLMAIN` declares the data | An array is allocated as its procedure starts, so a clear "needs more memory" must come from the one before |
| `MLMOVE`, `MLFLAG`, `MLCLR` | Moves and flags in `MLGAME%`, clearing round a number in `MLOPEN%`; `MLPAUS%` and `MLTILE` added | A call costs 14 ms or more; clearing shares the area code |
| `MLPLAY`, `MLEND` | `MLSIZE%`, `MLNEW`, `MLMARK`, `MLLOSS%`, `MLWIN%`, `MLCLOCK%` | Less code in memory while a game runs |
| The field's arrays: rows, mines, a mine list, a stack | Rows and mines as two string arrays; `LOC` finds waiting squares and mines | 1,933 bytes less (0.9.2) |
| `RND` lays the mines | `RND` seeds an integer generator | 7.7 s on Expert with floating point, 1.5 s now |
| Codes 0 and 7 spare, 7 the fallback cursor frame | 0 a bold 1; 7 marks a square waiting to be opened, drawn as covered | The Organiser's 1 looked like the flag; the machine's cursor reads well enough |
| Help is two pages | A third: the version and Daniel+Claude | Asked for |
| Five minutes with no key | The machine's own switch-off time; never, if switching off is disabled | The machine switches off on its own setting in any case |
| A win's result at once | The finished field (every mine flagged) with the win's tune, then the result | Half a second to see it |
| "New best time!" | "New", "2nd" or "3rd best time!" | Says the place |
| Best, one table at a time | The title row says 1/4 to 4/4 | Shows there are more |
| After a loss EXE moves on | ON/CLEAR too | A pause would only hide a finished field |
| S shows the status | Its time counts each second while it shows | Asked for (0.9.1) |
| Waiting arrow presses dropped after a scroll | After every move | The key repeat is faster than a move once the clock is read; the cursor overshot by up to 7 squares |
| Machine code later | None in this version | Every time is within the spec's estimates in OPL |
| Comments | The packs keep each procedure's first comment line | All the source with its comments would not fit a 32K pack; `src/` has them all |
| One-letter globals | Readable names in `src/`, one or two letters on the packs | The long names would cost about 270 bytes at the peak (0.9.2) |

Leaving MineLZ sets the eight user-defined characters to a plain bar, so the Organiser draws its
own top bar (its clock and battery are user-defined characters too) at once, not tiles.

## About this repository

One of the Psion Organiser II projects (`Psion-*`). The build and test scripts expect the PsionII workspace layout:

```
PsionII/
  Emulator/          Jape, Jaap Scherphuis's emulator, with its ROM images (not in any repo:
                     https://www.jaapsch.net/psion/jape/jape.htm)
  Tools/             opltran, opl2opk, RPBOOT/RPLOAD, ...
  Programs/MineLZ    this repository
```

`build/` is not committed: `build.py` and the tests recreate it.
