'use strict';
// Captures every screen of MineLZ for the report (docs/report.html): the 80 character codes,
// the eight user-defined characters and the cursor, on an LZ64. Writes build/screens.json with
// the LCD font's patterns for every character used.
//   node tests/screens.js
const fs = require('fs');
const path = require('path');
const { Game, ROOT } = require('./lib');
const { Model } = require('./model');
const { QUICK } = require('./tour');
const g = new Game('lz64', { pack: 'build/screens-dev.opk' });
const m = g.m;
const shots = [];
function shot(name, caption) {
  const c = g.m.cells();
  const cur = g.lcdCursor();
  shots.push({ name, caption, lines: [0, 1, 2, 3].map((r) => c.slice(r * 20, r * 20 + 20)), udg: g.udgs(), cursor: cur.on ? [cur.row, cur.col] : null });
  console.log(`${name.padEnd(12)} ${g.line()}`);
}
// a fixed Expert board, for the same pictures every time
const EXPERT = [];
{
  let s = 7;
  const rnd = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  while (EXPERT.length < 99) {
    const y = 1 + Math.floor(rnd() * 16), x = 1 + Math.floor(rnd() * 30);
    if (Math.abs(y - 8) <= 1 && Math.abs(x - 18) <= 1) continue;
    if (!EXPERT.some((q) => q[0] === y && q[1] === x)) EXPERT.push([y, x]);
  }
}
g.start();
g.wait(/Play +Best +Set[^]*Help +Quit/);
shot('main', 'The main menu');
g.key('P', 0.8).wait(/Custom/);
shot('play', 'Play: the game');
g.key('Q', 1.2); g.field();
shot('quick0', 'Quick: the whole 20 by 4 field, covered; the cursor in the middle');
g.plant(QUICK);
const mq = new Model(20, 4, QUICK);
g.jump(2, 3).act('EXE'); mq.open(2, 3);
g.goto(3, 17); g.act('F'); mq.flag(3, 17);
g.goto(2, 16);
shot('quick1', 'Quick after the first move: an area opened, a flag placed');
g.act('S');
shot('status', 'S: mines left, time and the cursor, over the two rows furthest from it');
g.act('LEFT');
g.key('ON', 0.8).wait(/Resume/);
shot('pause', 'ON/CLEAR: paused, the field hidden and the clock stopped');
g.key('EXE', 0.8); g.idle();
g.goto(1, 20); g.act('EXE');
shot('lost', 'A mine hit: every mine shown, the hit one crossed, a wrong flag marked');
g.key('EXE', 0.8).wait(/BOOM![^]*ON=menu/);
shot('boom', 'The result of a loss');
g.key('ON', 0.8).wait(/Play +Best/);
g.unplant();
// a win with a best time
g.play(1); g.plant(QUICK);
const mw = new Model(20, 4, QUICK);
g.jump(2, 3).act('EXE'); mw.open(2, 3);
for (;;) {
  const sq = mw.safe().find(([y, x]) => mw.s[y][x] === '#');
  mw.open(...sq);
  if (mw.over) {
    const clock = m.read(0x20C8, 3); m.onChunk = () => m.write(0x20C8, clock); g.run(0.6); g.idle();
    g.setg('T', 227); g.jump(...sq); m.press('EXE', 2, 1);
    g.wait(/CLEARED![^]*EXE=enter initials/, 10); m.onChunk = null; break;
  }
  g.jump(...sq).act('EXE');
}
shot('cleared', 'A win that beats a saved time');
g.key('EXE', 0.6).wait(/Your initials/);
g.type('DAN', 0.3);
shot('initials', 'Initials, offered again next time');
g.key('EXE', 1).wait(/EXE=again/);
shot('cleared2', 'Saved: the time to beat');
g.key('ON', 0.8).wait(/Play +Best/);
g.unplant();
// Beginner and Intermediate: the panels
g.play(2); g.firstMove(); g.act('DOWN'); g.act('DOWN'); g.run(3);
shot('beginner', 'Beginner: four of its nine rows, with the wide panel');
g.key('ON', 0.8).wait(/Resume/).key('M', 0.8).wait(/Play +Best/);
g.play(3); g.firstMove(); g.act('DOWN'); g.run(4);
shot('intermed', 'Intermediate: the narrow panel (mines left, minutes, seconds, the cursor\'s row)');
g.key('ON', 0.8).wait(/Resume/).key('M', 0.8).wait(/Play +Best/);
// Expert on a fixed board
g.play(4); g.plant(EXPERT);
const me = new Model(30, 16, EXPERT);
g.jump(8, 18).act('EXE'); me.open(8, 18);
for (const [y, x] of EXPERT) if (Math.abs(y - 8) <= 4 && Math.abs(x - 18) <= 8 && me.near(y, x).some(([a, b]) => /[1-8.]/.test(me.s[a][b]))) { g.goto(y, x); g.act('F'); me.flag(y, x); }
g.goto(7, 20);
shot('expert', 'Expert: 20 of its 30 columns and 4 of its 16 rows; the window follows the cursor');
g.act('S');
shot('expertS', 'S on Expert: column and row of the cursor');
g.act('LEFT');
g.key('ON', 0.8).wait(/Resume/).key('M', 0.8).wait(/Play +Best/);
g.unplant();
// Custom
g.key('P', 0.8).wait(/Custom/).key('C', 0.8).wait(/Width/);
g.key('ON', 0.1).type('24\n', 0.4); g.key('ON', 0.1).type('12\n', 0.4); g.key('ON', 0.1).type('50', 0.4);
shot('custom', 'Custom: width, height and mines; the mine limit follows the field');
g.key('EXE', 1); g.field();
g.key('ON', 0.8).wait(/Resume/).key('M', 0.8).wait(/Play +Best/);
g.key('B', 0.8).wait(/\/4/);
shot('best', 'Best: one table at a time; LEFT and RIGHT change the game, DEL clears it');
g.key('ON', 0.8).wait(/Play +Best/);
g.key('S', 0.8).wait(/Sound/);
shot('set', 'Set: the one setting of the first version');
g.key('ON', 0.8).wait(/Play +Best/);
g.key('H', 0.8);
shot('help1', 'Help, page 1');
g.key('EXE', 0.8);
shot('help2', 'Help, page 2');
g.key('EXE', 0.8);
shot('help3', 'Help, page 3');
g.key('EXE', 0.8).wait(/Play +Best/);
// the LCD's patterns for every character used (32..127 from the ROM's font)
const font = m.font();
const used = new Set();
shots.forEach((s) => s.lines.flat().forEach((c) => { if (c >= 32) used.add(c); }));
const glyphs = {};
[...used].sort((a, b) => a - b).forEach((c) => { glyphs[c] = font.slice((c - 32) * 8, (c - 32) * 8 + 8).map((v) => v & 31); });
fs.writeFileSync(path.join(ROOT, 'build', 'screens.json'), JSON.stringify({ shots, glyphs }));
console.log(`${shots.length} screens, ${Object.keys(glyphs).length} characters`);
