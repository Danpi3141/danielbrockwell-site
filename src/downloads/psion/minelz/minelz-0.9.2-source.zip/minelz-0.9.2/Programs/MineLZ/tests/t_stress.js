'use strict';
// Random keys (spec test plan, beyond its list): for the given number of emulated seconds,
// keys at random from everything the game uses (and some it doesn't), through every menu and
// screen. After every key: no OPL error, and the program still running (Quit starts it again).
// Whenever the game waits for a key in play: the screen is the field through the window, the
// covered safe squares and the flags agree with the field, and nothing is left half opened.
//   node tests/t_stress.js [seconds, default 1800] [lz|lz64] [seed]
const { Game, checker } = require('./lib');
const { rng } = require('./model');
const T = checker();
const secs = +process.argv[2] || 1800;
const model = process.argv[3] || 'lz64';
const r = rng(+process.argv[4] || 12345);
const g = new Game(model);
const m = g.m;
g.start();
const KEYS = [
  ['UP', 9], ['DOWN', 9], ['LEFT', 9], ['RIGHT', 9], ['EXE', 14], ['F', 6], ['S', 3], ['ON', 4],
  ['P', 3], ['B', 1], ['H', 1], ['Q', 1], ['V', 1], ['N', 1], ['M', 1], ['R', 1], ['Y', 1], ['C', 1],
  ['I', 1], ['E', 1], ['DEL', 1], ['MODE', 1], ['X', 1], ['SPACE', 1],
];
const total = KEYS.reduce((s, k) => s + k[1], 0);
const pick = () => { let v = r() * total; for (const [k, w] of KEYS) { v -= w; if (v < 0) return k; } return 'EXE'; };
let keys = 0, checks = 0, games = 0, restarts = 0, err = '', t0 = m.cycles();
const seen = new Set();
function invariants() {
  if (!g.waiting()) return '';
  const O = g.g('O');
  if (O !== 1 && O !== 0) return '';
  checks++;
  const b = g.board().join('');
  if (/q/.test(b)) return 'a square left marked to open';
  const W = g.g('W'), H = g.g('H');
  let safeCovered = 0, flags = 0;
  for (let y = 1; y <= H; y++) for (let x = 1; x <= W; x++) {
    const c = g.ch(y, x);
    if (c === 2) flags++;
    if ((c === 1 || c === 2) && !g.mine(y, x)) safeCovered++;
  }
  if (O === 1 && g.g('C') !== safeCovered) return `C% ${g.g('C')}, covered safe squares ${safeCovered}`;
  if (g.g('F') !== flags) return `F% ${g.g('F')}, flags ${flags}`;
  if (O === 1 && g.mines().length !== g.g('N')) return `${g.mines().length} mines, N% ${g.g('N')}`;
  const w = g.checkWindow(); if (w && !/Mines|Col/.test(g.text())) return 'screen: ' + w;
  return '';
}
while ((m.cycles() - t0) / 921600 < secs && !err) {
  const k = pick();
  m.press(k, 2, 2 + Math.floor(r() * 4));
  m.runSeconds(r() < 0.1 ? 1.5 : 0.15);
  keys++;
  const txt = g.text();
  seen.add(txt.split('\n')[0].slice(0, 8));
  // an OPL error: ERROR and its message, then the offer to edit the procedure (Y/N)
  if (/ERROR|Edit B:\S+ Y\/N|MISSING|OUT OF/.test(txt)) { err = 'an error: ' + g.line(); break; }
  if (!m.isOn()) { m.press('ON', 3, 10); m.runSeconds(1); }
  // Quit: back in the Organiser's own menus (the Prog menu, or the top level): start again
  if (/Edit +New +Run|Find +Save|Edit B:|Run B:|New B:/.test(txt) && !/MineLZ/.test(txt)) { restarts++; g.osMenu(); g.start(); continue; }
  if (/CLEARED|BOOM/.test(txt)) games++;
  const e = invariants();
  if (e) err = e + ' | ' + g.line();
  if (/Width|Height|Mines  \(/.test(txt) && r() < 0.3) { g.key('ON', 0.1); g.type(String(5 + Math.floor(r() * 20)) + '\n', 0.2); }
}
T.ok(!err, `${model} ${keys} random keys over ${((m.cycles() - t0) / 921600).toFixed(0)} s: ${checks} checks while playing, ${games} game ends seen, ${restarts} restarts after Quit${err ? '\n  ' + err : ''}`);
T.end();
