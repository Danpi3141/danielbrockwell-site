'use strict';
// Speed (spec test plan: "Speed"): the actions in the spec's speed table, timed in the emulator
// from the key being read to the game waiting for the next one (the dev build's frame-counter
// hooks, 1/20 s). Writes build/speed.json for the README and the report.
//   node tests/t_speed.js [lz|lz64]
const fs = require('fs');
const path = require('path');
const { Game, ROOT, checker } = require('./lib');
const { Model } = require('./model');
const T = checker();
const model = process.argv[2] || 'lz64';
const g = new Game(model);
g.start();
const out = {};
const med = (a) => { const s = a.slice().sort((x, y) => x - y); return s[Math.floor(s.length / 2)]; };
// (single actions are often under a frame: the mean of several says more than the median)
const mean = (a) => +(a.reduce((s, v) => s + v, 0) / a.length).toFixed(3);
const rec = (k, v, note) => { out[k] = v; console.log(`${k.padEnd(34)} ${Array.isArray(v) ? v.join(' / ') : v} s${note ? '  ' + note : ''}`); };
const back = () => g.key('ON', 0.6).wait(/Resume/).key('M', 0.6).wait(/Play +Best/);

// Quick: moves (no scroll), one square, a flag, S, clearing round a number
g.play(1);
g.firstMove();
// (a move is under a frame: timed as ten in a row)
const ten = (keys) => +(keys.reduce((s, k) => s + g.act(k), 0) / keys.length).toFixed(3);
rec('move, no scroll (Quick)', ten(['RIGHT', 'LEFT', 'RIGHT', 'LEFT', 'RIGHT', 'LEFT', 'RIGHT', 'LEFT', 'RIGHT', 'LEFT']));
const fl = [];
// flags and one square: on covered squares near the cursor
let b = g.board();
const cov = [];
for (let y = 1; y <= 4; y++) for (let x = 1; x <= 20; x++) if (b[y - 1][x - 1] === '#') cov.push([y, x]);
for (const sq of cov.slice(0, 3)) { g.goto(...sq); fl.push(g.act('F')); g.act('F'); }
rec('flag (Quick)', mean(fl));
rec('S, the status rows', g.act('S')); g.act('LEFT');
back();

// Expert: scrolls both ways, and the narrow panel's moves on Intermediate
g.play(4); g.firstMove();
// to the window's right edge: from there each RIGHT scrolls; the same downwards
// only the moves that scrolled are counted
const scrolls = (k, n, which) => { let s = 0, c = 0; for (let i = 0; i < n; i++) { const w = g.g(which), t = g.act(k); if (g.g(which) !== w) { s += t; c++; } } return { t: +(s / c).toFixed(3), c }; };
while (g.g('X') - g.g('U') < 17) g.act('RIGHT');
const sx = scrolls('RIGHT', 10, 'U');
while (g.g('Y') - g.g('V') < 2) g.act('DOWN');
const sy = scrolls('DOWN', 8, 'V');
rec('move with a scroll (Expert)', [sx.t, sy.t], `sideways / up and down (${sx.c} and ${sy.c} scrolls)`);
back();
g.play(3); g.firstMove();
rec('move, panel row (Intermediate)', ten(['DOWN', 'UP', 'DOWN', 'UP', 'DOWN', 'UP', 'DOWN', 'UP', 'DOWN', 'UP']));
back();

// Expert on a fixed board: one square, clearing round a number, a large area, the loss
function expert(mines, first) {
  g.play(4); g.plant(mines);
  const md = new Model(30, 16, mines);
  const t = g.jump(...first).act('EXE'); md.open(...first);
  return { md, t };
}
// the deal alone: a real deal, then the same layout planted, the same first move
g.play(4);
g.jump(8, 15);
const tReal = g.act('EXE');
const layout = g.mines(), openedReal = 480 - 99 - g.g('C');
back();
const { t: tPlanted } = expert(layout, [8, 15]);
back();
rec('first move on Expert, with the deal', tReal, `${openedReal} squares opened`);
rec('laying 99 mines (the difference)', +(tReal - tPlanted).toFixed(2));
// mines in the top left only: the first move opens nearly all the rest
// (a 10 by 10 block with a safe hole in it, which the area can't reach, so the game goes on)
const corner = []; for (let y = 1; y <= 10; y++) for (let x = 1; x <= 10; x++) if (y !== 5 || x !== 5) corner.push([y, x]);
let r = expert(corner, [16, 30]);
rec('largest area: Expert, 99 mines in a corner', r.t, `${480 - 99 - r.md.left} squares opened`);
back();
// Intermediate's largest in the spec: about 150 squares
// 40 mines over the top and left, leaving the bottom right for one large area
const imines = []; for (let y = 1; y <= 16 && imines.length < 40; y++) for (let x = 1; x <= 16 && imines.length < 40; x++) if ((y * 7 + x * 3) % 4 === 0 && (y < 9 || x < 7)) imines.push([y, x]);
g.play(3); g.plant(imines);
const md3 = new Model(16, 16, imines);
const big = md3.safe().filter(([y, x]) => md3.count(y, x) === 0).sort((p, q) => (q[0] + q[1]) - (p[0] + p[1]))[0];
const tI = g.jump(...big).act('EXE'); md3.open(...big);
rec('an area on Intermediate (fixed board)', tI, `${256 - 40 - md3.left} squares opened`);
back();
// one square and clearing round a number, on a board with small areas
const scat = []; for (let i = 0; i < 99; i++) scat.push([1 + ((i * 7) % 16), 1 + ((i * 13 + (i >> 4)) % 30)]);
const uniq = [...new Map(scat.map((s) => [s.join(), s])).values()];
while (uniq.length < 99) { const s = [1 + uniq.length % 16, 1 + (uniq.length * 11) % 30]; if (!uniq.some((u) => u.join() === s.join())) uniq.push(s); }
g.play(4); g.plant(uniq.slice(0, 99));
const md4 = new Model(30, 16, uniq.slice(0, 99));
const firstSafe = md4.safe().find(([y, x]) => md4.count(y, x) === 0) || md4.safe()[0];
g.jump(...firstSafe).act('EXE'); md4.open(...firstSafe);
const one = [];
for (const sq of md4.safe().filter(([y, x]) => md4.s[y][x] === '#' && md4.count(y, x) > 0).slice(0, 5)) {
  g.goto(...sq); one.push(g.act('EXE')); md4.open(...sq);
}
rec('uncover one square (a number)', mean(one));
// clearing round a number: flag its mines, then EXE on it
const nums = [];
for (let y = 1; y <= 16; y++) for (let x = 1; x <= 30; x++) if (/[1-8]/.test(md4.s[y][x]) && md4.near(y, x).some(([a, c]) => md4.s[a][c] === '#' && !md4.mine[a][c])) nums.push([y, x]);
const cl = [];
for (const [y, x] of nums.slice(0, 3)) {
  if (md4.over || md4.s[y][x] === '#') continue;
  for (const [a, c] of md4.near(y, x)) if (md4.mine[a][c] && md4.s[a][c] === '#') { g.goto(a, c); g.act('F'); md4.flag(a, c); }
  g.goto(y, x); cl.push(g.act('EXE')); md4.chord(y, x);
}
rec('clear round a number', med(cl));
const tr = []; for (let i = 0; i < 3; i++) { g.goto(...nums[0]); } // (cursor parked)
// the loss: every mine shown
const live = uniq.slice(0, 99).find(([y, x]) => md4.s[y][x] === '#');
g.goto(...live);
rec('a loss on Expert: the mines shown', g.act('EXE'));
g.key('EXE', 0.6).wait(/BOOM![^]*ON=menu/).key('ON', 0.6).wait(/Play +Best/);
g.unplant();

fs.writeFileSync(path.join(ROOT, 'build', `speed-${model}.json`), JSON.stringify(out, null, 1));
T.ok(out['move, no scroll (Quick)'] < 0.1 && out['move with a scroll (Expert)'][0] < 0.3, 'moves are quick');
T.end();
