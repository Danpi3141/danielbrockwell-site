'use strict';
// The rules against the PC model (tests/model.js), on fixed boards: every number, every area,
// flags right and wrong, clearing round numbers (opens, loses, refuses), wins with no flags,
// some flags and all flags, losses with the field shown and the right flags counted.
// After every action the whole field, the counts, the game state and the screen are compared.
//   node tests/t_rules.js [lz|lz64] [--quick]
const { Game, SIZES, checker } = require('./lib');
const { Model, layout, rng } = require('./model');
const T = checker();
const model = process.argv[2] && !process.argv[2].startsWith('-') ? process.argv[2] : 'lz64';
const quick = process.argv.includes('--quick');

const g = new Game(model);
g.start();

// put the cursor on y,x with the arrow keys, checking the screen after each scroll
function at(y, x) { g.goto(y, x); }
// EXE, then wait until the game waits for a key again; after a win it is on the result screen
function act(k) { if (g.g('C') <= 0) return g.key(k); g.m.press(k, 2, 1); for (let i = 0; i < 400 && !g.waiting() && !/CLEARED|BOOM/.test(g.text()); i++) g.m.runTicks(1); g.settle(); }
function compare(md, what) {
  const b = g.board().join('\n'), want = md.board().join('\n');
  const st = { lost: 2, won: 3 }[md.over] || 1;
  const bad = [];
  if (b !== want) bad.push('field differs\n' + b + '\n--- model\n' + want);
  if (!md.over && g.g('C') !== md.left) bad.push(`C% ${g.g('C')} model ${md.left}`);
  if (g.g('F') !== md.flags && md.over !== 'lost') bad.push(`F% ${g.g('F')} model ${md.flags}`);
  if (g.g('O') !== st) bad.push(`O% ${g.g('O')} want ${st}`);
  if (!md.over || md.over === 'lost') { const w = g.checkWindow(); if (w) bad.push('screen: ' + w); }
  return bad.length ? `${what}: ${bad.join('; ')}` : '';
}

// play one game of the given size on a fixed board; plan = 'win', 'lose', 'chord'
function game(name, sel, W, H, N, seed, plan) {
  if (sel === 5) g.custom(W, H, N); else g.play(sel);
  const r = rng(seed);
  const fy = 1 + Math.floor(r() * H), fx = 1 + Math.floor(r() * W);
  const mines = layout(W, H, N, r, fy, fx);
  g.plant(mines);
  const md = new Model(W, H, mines);
  let err = '', actions = 0, chords = { ok: 0, refused: 0, mine: 0 }, flags = 0;
  at(fy, fx); g.act('EXE');
  md.open(fy, fx); actions++;
  err = compare(md, `first move ${fy},${fx}`);
  // flag some mines and a few wrong squares, open safe squares, clear round numbers
  let guard = 0;
  while (!err && !md.over && guard++ < 2000) {
    const covered = [], numbers = [];
    for (let y = 1; y <= H; y++) for (let x = 1; x <= W; x++) {
      if (md.s[y][x] === '#') covered.push([y, x]);
      if (/[1-8]/.test(md.s[y][x])) numbers.push([y, x]);
    }
    const pick = (a) => a[Math.floor(r() * a.length)];
    const u = r();
    let what;
    if (u < 0.15 && covered.length) {
      // a flag: on a mine mostly, sometimes on a safe square (a wrong flag)
      const mineSq = covered.filter(([y, x]) => md.mine[y][x]);
      const [y, x] = (plan === 'win' || r() < 0.8) && mineSq.length ? pick(mineSq) : pick(covered);
      if (plan === 'win' && !md.mine[y][x]) continue;
      at(y, x); g.act('F'); md.flag(y, x); flags++;
      what = `flag ${y},${x}`;
    } else if (u < 0.25 && numbers.length && plan !== 'win') {
      const [y, x] = pick(numbers);
      at(y, x); act('EXE');
      const res = md.chord(y, x);
      if (res === 'refused') chords.refused++; else if (res === 'mine') chords.mine++; else chords.ok++;
      what = `clear round ${y},${x} (${res})`;
      if (res === 'mine' && plan !== 'chord' && plan !== 'lose') { /* a wrong flag found: the game is lost */ }
    } else {
      // open a safe square, or (plan lose) a mine once a few moves are made
      const safe = covered.filter(([y, x]) => !md.mine[y][x]);
      const mineSq = covered.filter(([y, x]) => md.mine[y][x]);
      let sq = pick(safe.length ? safe : covered);
      if (plan === 'lose' && actions > 6 && mineSq.length) sq = pick(mineSq);
      at(sq[0], sq[1]); act('EXE');
      md.open(sq[0], sq[1]);
      what = `open ${sq}`;
    }
    actions++;
    err = compare(md, what);
  }
  if (!err && !md.over) err = 'game never ended';
  // the end: the result screen
  let end = '';
  if (!err && md.over === 'lost') {
    // the field stays with the mines shown; EXE moves on
    end = g.key('EXE', 0.5).wait(/BOOM![^]*ON=menu/).text();
    const found = md.rightFlags();
    if (!new RegExp(`(Mines f|F)ound ${found} of ${N}`).test(end)) err = 'loss screen: ' + end;
    if (!err) { g.key('V', 0.5); if (g.checkWindow() || !/^[^]*$/.test(g.text())) err = 'view again: ' + g.checkWindow(); }
    if (!err) { g.key('EXE', 0.5).wait(/BOOM!/); g.key('ON', 0.5).wait(/Play +Best/); }
  } else if (!err && md.over === 'won') {
    end = g.wait(/CLEARED![^]*(EXE=enter initials|EXE=again)/, 10).text();
    if (!err && /EXE=enter initials/.test(end)) {
      // leave the initials without saving: ON/CLEAR clears them, and on an empty entry leaves it
      g.key('EXE', 0.3).wait(/Your initials/);
      for (let i = 0; i < 3 && !/EXE=again/.test(g.text()); i++) g.key('ON', 0.4);
    }
    g.wait(/EXE=again +ON=menu/, 10);
    g.key('ON', 0.5).wait(/Play +Best/);
  }
  g.unplant();
  T.ok(!err, `${model} ${name.padEnd(13)} ${plan.padEnd(5)} ${md.over || '-'} after ${actions} actions, ${flags} flags, clears ok ${chords.ok} refused ${chords.refused} mine ${chords.mine}${err ? '\n' + err + '\n' + g.text() : ''}`);
  return md;
}

const plans = quick ? [['win', 1], ['lose', 2]] : [['win', 1], ['lose', 2], ['chord', 3], ['win', 4], ['lose', 5], ['chord', 6]];
const boards = [
  ['Quick', 1, ...SIZES[1]], ['Beginner', 2, ...SIZES[2]], ['Intermediate', 3, ...SIZES[3]], ['Expert', 4, ...SIZES[4]],
  ['Custom 5x4', 5, 5, 4, 2], ['Custom 30x24', 5, 30, 24, 60], ['Custom 12x7', 5, 12, 7, 28],
];
for (const [name, sel, W, H, N] of (quick ? boards.slice(0, 3) : boards).filter((b) => !process.env.ONLY || b[0] === process.env.ONLY)) {
  for (const [plan, seed] of plans) {
    try { game(name, sel, W, H, N, seed * 7919 + W * 31 + H, plan); } catch (e) { T.ok(false, `${name} ${plan}: ${e.message} | on ${g.m.isOn()} tout ${g.m.peekw(0x7D)} O ${g.find() && g.g('O')} T ${g.find() && g.g('T')} clock ${g.m.read(0x20C5, 6)} secs ${(g.m.cycles() / 921600).toFixed(0)}`); try { g.unplant(); g.osMenu(); g.start(); } catch (e2) { /* */ } }
  }
}
T.end();
