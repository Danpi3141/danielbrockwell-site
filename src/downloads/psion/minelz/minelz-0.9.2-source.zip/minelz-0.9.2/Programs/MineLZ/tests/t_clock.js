'use strict';
// The clock (spec test plan: "Clock"): it starts once the first area is on screen, counts only
// playing time, stops for the pause, does not count time with the machine off, and carries on
// past midnight. Also: the game pauses itself and switches off after the machine's own
// switch-off time with no key, and comes back to the pause screen; a jump in the clock
// (the machine off, or an alarm) pauses the game; the panel's time ticks; 99:59 is the most.
//   node tests/t_clock.js [lz|lz64]
const { Game, checker } = require('./lib');
const T = checker();
const model = process.argv[2] || 'lz64';
const RTC = 0x20C5;                  // year, month (0-11), day (0-30), hour, minute, second
const g = new Game(model);
const m = g.m;
g.start();

const t = () => g.g('T');
const near = (a, b, d = 1) => Math.abs(a - b) <= d;
const mmss = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

// Beginner: the wide panel shows the time
g.play(2);
g.run(3);
T.ok(t() === 0 && /Time  0:00/.test(g.text()), `the clock waits for the first move (T% ${t()}, ${g.line()})`);
g.act('EXE');
const t0 = t();
g.idle(); g.run(10.2);
T.ok(t0 === 0 && near(t() - t0, 10), `10 s of play counts 10 s (T% ${t0} -> ${t()})`);
g.idle(); T.ok(new RegExp(`Time ${String(Math.floor(t() / 60)).padStart(2)}:${String(t() % 60).padStart(2, '0')}`).test(g.text()), `the panel shows the time as it runs: ${g.rows()[1].slice(10)}`);

// the pause stops it
let before = t();
g.key('ON', 0.5).wait(/Paused +Time/);
T.ok(new RegExp(`Paused   Time ${mmss(before)}`).test(g.text()) && /Resume New +Menu/.test(g.text()), `pause screen: ${g.line()}`);
const hidden = !/[①-⑦]/.test(g.text());
g.run(30);
g.key('EXE', 0.5); g.idle();
T.ok(hidden && near(t(), before, 1), `30 s paused counts nothing (T% ${before} -> ${t()}), and the field was hidden`);
T.ok(!g.checkWindow(), 'resume draws the field again');

// a jump in the clock: the machine was off (or an alarm rang): the game pauses
before = t();
let c = m.read(RTC, 6);
m.write(RTC + 3, [(c[3] + 1) % 24, c[4], c[5]]);
g.run(1.5);
T.ok(/Paused/.test(g.text()) && near(t(), before, 1), `the clock jumping an hour pauses the game without counting it (T% ${before} -> ${t()})`);
g.key('EXE', 0.5); g.idle();

// past midnight
// (the clock is set during a pause: set while playing, it would be a jump)
g.key('ON', 0.5).wait(/Paused/);
m.write(RTC + 3, [23, 59, 50]);
g.key('EXE', 0.5); g.idle();
before = t(); g.run(20);
const after = m.read(RTC + 3, 3);
T.ok(after[0] === 0 && near(t() - before, 20), `play through midnight counts (23:59:50 -> ${after.join(':')}, T% ${before} -> ${t()})`);

// the status rows show the same time
g.act('S');
T.ok(new RegExp(`Time ${mmss(t())}`).test(g.text()) || new RegExp(`Time ${mmss(t() - 1)}`).test(g.text()), `S shows the time: ${g.line()}`);
g.act('LEFT');

// playing on for more than the machine's switch-off time: a key every few seconds keeps it on
// (keys read with KEY don't reset the machine's own count; the game does it)
let stayed = true;
for (let s = 0; s < 400; s += 4) { g.act(s % 8 ? 'LEFT' : 'RIGHT'); g.run(3.5); if (!m.isOn() || /Paused/.test(g.text())) { stayed = false; break; } }
T.ok(stayed && m.isOn() && g.waiting(), `400 s of play with a key every 4 s: still on and playing (${g.line()})`);

// idle: the machine's own switch-off time (5 minutes) with no key: the game pauses and switches off
before = t();
let offAt = -1;
for (let s = 0; s < 340; s += 2) { g.run(2); if (!m.isOn()) { offAt = s; break; } }
T.ok(offAt > 280 && offAt < 310, `no key for ${offAt} s: switched off`);
const tOff = t();
g.run(60);
m.press('ON', 3, 10); g.run(1.5);
T.ok(m.isOn() && /Paused +Time/.test(g.text()) && /Resume/.test(g.text()), `switching on shows the pause screen: ${g.line()}`);
T.ok(near(tOff - before, 297, 8) && t() === tOff, `the 5 minutes waiting counted as play (${tOff - before} s), the minute off did not (T% ${tOff} -> ${t()})`);
g.key('EXE', 0.5); g.idle();
T.ok(!g.checkWindow() && g.lcdCursor().on, 'resumed: field and cursor back');

// the switch-off time is the machine's own setting: 30 s
m.pokew(0x20CD, 30);
g.act('LEFT');
offAt = -1;
for (let s = 0; s < 60; s += 1) { g.run(1); if (!m.isOn()) { offAt = s; break; } }
T.ok(offAt >= 27 && offAt <= 31, `with the machine set to switch off after 30 s: off after ${offAt} s`);
m.press('ON', 3, 10); g.run(1.5); g.key('EXE', 0.5); g.idle();
// and with switching off disabled it never does
m.poke(0x7C, 0); m.pokew(0x20CD, 300);
g.act('LEFT');
g.run(400);
T.ok(m.isOn() && g.waiting(), 'with switching off disabled the game waits on');
m.poke(0x7C, 1);

// the key loop's pass count (part of the seed) wraps instead of overflowing
g.setg('E', 16380);
g.run(4);
T.ok(g.waiting() && g.g('E') > 0 && g.g('E') < 16384, `the pass count wraps (16380 -> ${g.g('E')}), no INTEGER OVERFLOW`);

// 99:59 is the most
g.setg('T', 5990);
g.run(15);
T.ok(t() === 5999 && /Time99:59/.test(g.text().replace(/ /g, '')), `the clock stops at 99:59 (${t()}, ${g.rows()[1].slice(10)})`);

// a win stops the clock: lose instead and check it stops
const tl = t();
const mine = g.mines()[0];
g.jump(mine[0], mine[1]).act('EXE');
g.run(5);
T.ok(t() === tl && g.g('O') === 2, `after a loss the clock stops (${tl} -> ${t()})`);
g.key('EXE', 0.5).wait(/BOOM! +Time 99:59/);
T.ok(true, `loss screen: ${g.line()}`);
T.end();
