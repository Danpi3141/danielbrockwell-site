'use strict';
// The time counts once a second on the panel and on S's status rows, and the digit 1 is tile 0.
//   node tests/t_tick.js [lz|lz64]
const { Game, checker } = require('./lib');
const T = checker();
const model = process.argv[2] || 'lz64';
const g = new Game(model);
g.start();
// (read while the game waits for a key, never between the time going up and its redraw)
const secs = (re) => { g.idle(); const m = g.line().match(re); return m ? +m[1] * 60 + +m[2] : NaN; };
// Quick: no panel, so S is the only place the time shows
g.play(1); g.firstMove();
g.act('S');
const s0 = secs(/Time (\d\d):(\d\d)/);
const seen = new Set([s0]);
for (let i = 0; i < 8; i++) { g.run(0.5); seen.add(secs(/Time (\d\d):(\d\d)/)); }
const s1 = secs(/Time (\d\d):(\d\d)/);
T.ok(s1 - s0 >= 3 && s1 - s0 <= 5 && seen.size >= 4, `S's status rows count: ${s0} s then ${s1} s four seconds on (${[...seen].join(',')})`);
T.ok(s1 === g.g('T'), `they show the game's time (${g.g('T')})`);
// the status rows go at the next key, which does nothing else
const cur = g.cursor().join();
g.act('RIGHT');
T.ok(!/Time \d\d:/.test(g.line()) && g.cursor().join() === cur, 'the next key takes them away and moves nothing');
T.ok(g.checkWindow() === '', 'the field is back: ' + g.checkWindow());
// Beginner: the panel's time counts on its own
g.key('ON', 0.6).wait(/Resume/).key('M', 0.6).wait(/Play +Best/);
g.play(2); g.firstMove();
const p0 = secs(/Time +(\d+):(\d\d)/);
g.run(3.2);
const p1 = secs(/Time +(\d+):(\d\d)/);
T.ok(p1 - p0 >= 2 && p1 - p0 <= 4, `the panel counts: ${p0} s then ${p1} s`);
// S on Beginner with the cursor low (status rows 1-2 cover the panel's time) and high (rows 3-4)
for (const [y, rows] of [[9, '1-2'], [1, '3-4']]) {
  g.goto(y, 5); g.act('S');
  const a = secs(/Time (\d\d):(\d\d)/); g.run(2.6); const b = secs(/Time (\d\d):(\d\d)/);
  T.ok(b - a >= 2 && b - a <= 3, `S on Beginner, status on rows ${rows}: ${a} s then ${b} s`);
  if (rows === '3-4') T.ok(/Time +\d+:\d\d.*Time \d\d:\d\d/.test(g.line()) && secs(/Time +(\d+):(\d\d)\|/) === b, 'the panel time above it agrees: ' + g.line());
  g.act('LEFT');
  T.ok(g.checkWindow() === '', 'the field is back: ' + g.checkWindow());
}
// the digit 1: tile 0 in the field and on the screen, never byte 49
const b = g.board();
const ones = [];
for (let y = 1; y <= 9; y++) for (let x = 1; x <= 9; x++) if (b[y - 1][x - 1] === '1') ones.push([y, x]);
let bytes49 = 0; for (let y = 1; y <= 9; y++) for (let x = 1; x <= 9; x++) if (g.ch(y, x) === 49) bytes49++;
T.ok(ones.length > 0 && bytes49 === 0, `${ones.length} ones on the field, all tile 0`);
const cells = g.m.cells();
T.ok(cells.includes(0) && !cells.slice(0, 20 * 4).some((c, i) => c === 49 && (i % 20) < 9), 'tile 0 on the screen, no 1 from the font in the field');
T.ok(g.udgs()[0].join() === '6,14,6,6,6,6,6,0', 'UDG 0 is the bold 1: ' + g.udgs()[0].join());
T.end();
