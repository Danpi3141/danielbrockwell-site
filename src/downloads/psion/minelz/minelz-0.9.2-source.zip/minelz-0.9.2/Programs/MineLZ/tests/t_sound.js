'use strict';
// The sounds (spec: "Sound"): each event's notes measured on the buzzer, against the spec's
// table (BEEP length in ms and pitch value, Hz = 921600/(78+2p)); an area makes one click, not
// one a square; with Sound OFF there is nothing at all. (Jape's BEEP takes no time, so lengths
// are what the buzzer's edges say, not what the program waited.)
//   node tests/t_sound.js [lz|lz64]
const { Game, checker } = require('./lib');
const { Model } = require('./model');
const { QUICK } = require('./tour');
const T = checker();
const g = new Game(process.argv[2] || 'lz64');
const m = g.m;
const hz = (p) => Math.round(921600 / (78 + 2 * p));
const want = {
  uncover: [[5, 150]], flagOn: [[15, 100]], flagOff: [[15, 250]], refused: [[40, 1200]],
  hit: [[120, 600], [150, 1000], [300, 1800]], win: [[80, 500], [80, 380], [80, 300], [200, 220]],
};
// what the buzzer played, less the Organiser's own key clicks (a single pulse: 0 ms)
// (an interrupt in the middle of a note can split it in two: pieces of the same pitch that follow
// each other are one note)
function heard(fn) {
  m.buzzStart(); fn();
  const out = [];
  for (const n of m.buzzStop().filter((x) => x.ms >= 2)) {
    const p = out[out.length - 1];
    if (p && Math.abs(p.hz - n.hz) <= p.hz * 0.02 && n.at <= p.at + p.ms + 3) p.ms = n.at + n.ms - p.at; else out.push({ ...n });
  }
  return out;
}
// pitch within 2%; length within 10% and two cycles of the note (the buzzer's edges are what is
// measured, and Jape times BEEP by the ROM's own loop)
function same(notes, spec) {
  if (notes.length !== spec.length) return false;
  return notes.every((n, i) => Math.abs(n.hz - hz(spec[i][1])) <= hz(spec[i][1]) * 0.02
    && Math.abs(n.ms - spec[i][0]) <= spec[i][0] * 0.1 + 2000 / n.hz);
}
const show = (notes) => notes.map((n) => `${n.ms}ms ${n.hz}Hz`).join(', ') || 'nothing';

function round(soundOn) {
  g.play(1);
  g.plant(QUICK);
  const md = new Model(20, 4, QUICK);
  const res = {};
  res.first = heard(() => { g.jump(2, 3).act('EXE'); md.open(2, 3); });
  res.flagOn = heard(() => g.jump(3, 17).act('F'));
  res.flagOff = heard(() => g.act('F'));
  // a number whose flags don't match it: refused
  let num = null;
  for (let y = 1; y <= 4 && !num; y++) for (let x = 1; x <= 20; x++) if (/[1-8]/.test(md.s[y][x])) { num = [y, x]; break; }
  res.refused = heard(() => g.jump(...num).act('EXE'));
  // one square with a number
  const one = md.safe().find(([y, x]) => md.s[y][x] === '#' && md.count(y, x) > 0);
  res.uncover = heard(() => { g.jump(...one).act('EXE'); md.open(...one); });
  res.hit = heard(() => { g.jump(1, 20).act('EXE'); });
  g.key('EXE', 0.6).wait(/BOOM![^]*ON=menu/).key('EXE', 0.6).field();
  g.plant(QUICK);
  const md2 = new Model(20, 4, QUICK);
  g.jump(2, 3).act('EXE'); md2.open(2, 3);
  for (;;) {
    const sq = md2.safe().find(([y, x]) => md2.s[y][x] === '#');
    md2.open(...sq);
    if (md2.over) { res.win = heard(() => { g.jump(...sq); m.press('EXE', 2, 1); g.wait(/CLEARED!/, 10); }); break; }
    g.jump(...sq).act('EXE');
  }
  g.unplant();
  g.wait(/EXE=enter initials|EXE=again/);
  if (/initials/.test(g.text())) { g.key('EXE', 0.5).wait(/Your initials/); for (let i = 0; i < 3 && !/EXE=again/.test(g.text()); i++) g.key('ON', 0.4); }
  g.key('ON', 0.6).wait(/Play +Best/);
  return res;
}

g.start();
const on = round(true);
T.ok(same(on.first, want.uncover), `the first move's area: one click (${show(on.first)})`);
for (const k of ['uncover', 'flagOn', 'flagOff', 'refused', 'hit', 'win']) {
  T.ok(same(on[k], want[k]), `${k.padEnd(8)} ${show(on[k])}  (spec: ${want[k].map(([ms, p]) => `${ms}ms ${hz(p)}Hz`).join(', ')})`);
}
// Set: sound off (the change itself sounds the flag pip, then nothing)
g.key('S', 0.6).wait(/Sound: +ON/);
const sw = heard(() => g.key('EXE', 0.6));
T.ok(/Sound: +OFF/.test(g.text()), `Set turns the sound off (${show(sw)})`);
g.key('ON', 0.8).wait(/Play +Best/);
const off = round(false);
T.ok(Object.values(off).every((n) => n.length === 0), `with sound off nothing is heard: ${Object.entries(off).map(([k, v]) => k + ' ' + v.length).join(', ')}`);
g.key('S', 0.6).wait(/Sound: +OFF/);
const sw2 = heard(() => g.key('EXE', 0.6));
T.ok(/Sound: +ON/.test(g.text()) && same(sw2, want.flagOn), `and on again, with a pip (${show(sw2)})`);
T.end();
