'use strict';
// Test helpers: MineLZ on an emulated LZ or LZ64 (tools/emu.js runs the Jape emulator's sources).
// The game's arrays are found in memory from their headers, and its globals from A%'s value.
// The dev build (python build.py --dev) has test hooks in HK%(1) to HK%(5) (Hook% in src/): a
// planted board, the frame counter as a key is read and when the game waits again, a flag set
// while it waits, and a count of the keys dealt with.
const path = require('path');
const { Machine } = require('../tools/emu');

const ROOT = path.join(__dirname, '..');
const ROMS = {                       // every four-line ROM the emulator has, and its RAM in K
  '42-lz.rom': 32, '44-lz.rom': 32, '45-lz.rom': 32, '45-lzi.rom': 32, '45-lzs.rom': 32, '46-lz.rom': 32, '46-lzi.rom': 32,
  '43-lz64.rom': 64, '44-lz64.rom': 64, '45-lz64.rom': 64, '46a-lz64.rom': 64, '46b-lz64.rom': 64, '46-lz64i.rom': 64, '46-lz64s.rom': 64,
};
const MODELS = { lz: '46-lz.rom', lz64: '46a-lz64.rom' };
const SIZES = { 1: [20, 4, 10], 2: [9, 9, 10], 3: [16, 16, 40], 4: [30, 16, 99] };
const NAMES = { 1: 'Quick', 2: 'Beginner', 3: 'Intermediate', 4: 'Expert', 5: 'Custom' };
// screen characters
const COVER = 1, FLAG = 2, MINE = 3, HIT = 4, WRONG = 5, DOT = 6, QUEUED = 7;
// globals in MLMAIN's order, by their names on the pack: GLOBAL A%,B%,W%,...  (each 2 bytes,
// going down in memory). src/ calls them MapAdr%, BrdAdr%, Width%... (build.py's SHORT)
const GLOBALS = ['A', 'B', 'W', 'H', 'N', 'G', 'X', 'Y', 'U', 'V', 'D', 'P', 'C', 'F', 'T', 'O', 'K', 'Z', 'E'];
// HK%(1) planted board, (2) frame as a key is read, (3) frame when waiting again,
// (4) set while waiting, (5) count of keys dealt with (1 to 16384, wrapping): offsets in HK%()
const HOOK = { plant: 0, read: 2, done: 4, wait: 6, count: 8 };
const ROWS = 26 * 33;                // R$(26,32) and M$(26,32): 26 elements of 33 bytes

class Game {
  constructor(model, opts = {}) {
    const rom = MODELS[model] || model || MODELS.lz64;
    this.rom = rom;
    this.m = new Machine({ rom, ram: ROMS[rom] || 64 });
    this.m.boot();
    this.pack = path.join(ROOT, opts.pack || 'build/MINELZ-dev.opk');
    this.m.insertPack(this.pack, 0);
    this.addr = null;
  }
  text() { return this.m.screenText(); }
  line() { return this.text().replace(/\n/g, '|'); }
  rows() { return this.m.screen(); }
  run(s) { this.m.runSeconds(s); return this; }
  key(k, s = 0.3) { this.m.press(k, 2, 2); this.m.runSeconds(s); return this; }
  keys(list, s = 0.3) { for (const k of list) this.key(k, s); return this; }
  type(t, s = 0.3) { this.m.type(t, 2, 2); this.m.runSeconds(s); return this; }
  wait(re, sec = 20) {
    for (let t = 0; t < sec; t += 0.05) { if (re.test(this.text())) return this; this.m.runSeconds(0.05); }
    throw new Error('waited for ' + re + ' but the screen is\n' + this.text());
  }
  // out to the Organiser's own menu: ON/CLEAR backs out of everything but MineLZ's main menu,
  // which Quit leaves
  osMenu() {
    for (let i = 0; i < 10 && !/Find|FIND|Prog|PROG/.test(this.text()); i++) {
      this.m.press(/Play +Best/.test(this.text()) ? 'Q' : 'ON', 3, 10); this.m.runSeconds(0.5);
    }
    return this;
  }
  // after a move that may have ended the game: from a win or loss, on to a new game of the same size
  again() {
    if (this.g('O') === 2) this.key('EXE', 0.5).wait(/BOOM![^]*ON=menu/);
    this.wait(/(CLEARED|BOOM)![^]*(EXE=enter initials|EXE=again)/, 10);
    if (/initials/.test(this.text())) {
      this.key('EXE', 0.3).wait(/Your initials/);
      for (let i = 0; i < 3 && !/EXE=again/.test(this.text()); i++) this.key('ON', 0.4);
    }
    this.key('EXE', 0.5);
    return this.field();
  }
  // a first move in the middle that leaves the game going (not won at once)
  firstMove() {
    for (let i = 0; i < 20; i++) {
      // (not act: a first move that wins at once leaves the key loop for the result)
      this.idle();
      const c0 = this.m.peekw(this.addr.H + HOOK.count);
      this.m.press('EXE', 2, 3);
      for (let t = 0; t < 600 && this.m.peekw(this.addr.H + HOOK.count) === c0 && !/CLEARED/.test(this.text()); t++) this.m.runTicks(1);
      if (this.g('O') === 1 && this.idle(5)) return this;
      this.again();
    }
    throw new Error('every first move won');
  }
  start(proc = 'MINELZ') { this.osMenu(); this.m.runProc(proc, 'B'); return this.wait(/^MineLZ/); }
  // from the main menu, a game from the Play menu (1 Quick .. 4 Expert) by its first letter
  play(n) {
    this.wait(/Play +Best/).key('P').wait(/Quick +Beginner/);
    this.key('QBIEC'[n - 1]);
    if (n < 5) this.field();
    return this;
  }
  custom(w, h, mines) {
    this.wait(/Play +Best/).key('P').wait(/Quick +Beginner/).key('C').wait(/Width/);
    for (const v of [w, h, mines]) { this.key('ON', 0.1); this.type(String(v) + '\n', 0.4); }
    return this.field();
  }
  // wait until a game's field is in memory and the game waits for a key
  field() {
    for (let t = 0; t < 10; t += 0.1) {
      if (this.find() && this.g('W') > 0 && this.waiting()) return this;
      this.m.runSeconds(0.1);
    }
    throw new Error('no field\n' + this.text());
  }
  // the arrays and globals in memory. R$(26,32) (the field) and below it M$(26,32) (the mines):
  // each a header 20 00 1A, then 26 elements of 33 bytes. In the dev build HK%(5) lies below M$.
  isStr(a) { return this.m.peek(a - 3) === 0x20 && this.m.peekw(a - 2) === 26; }
  find() {
    const m = this.m;
    if (this.addr && this.isStr(this.addr.R) && this.isStr(this.addr.M)) return true;
    for (let a = 0x2000; a < 0x8000;) {
      const r = m.find([0x20, 0x00, 0x1A], a, 0x8000);
      if (r < 0) return false;
      const R = r + 3, M = R - 3 - ROWS;
      if (this.isStr(M)) {
        const H = M - 3 - 10, dev = m.peekw(H - 2) === 5;
        const low = dev ? H - 2 : M - 3;
        // A% holds ADDR(M$()), B% ADDR(R$()): A% is the first global below the arrays
        let ga = -1;
        for (let x = low - 2; x > low - 200; x--) if (m.peekw(x) === M && m.peekw(x - 2) === R) { ga = x; break; }
        if (ga < 0) { a = r + 1; continue; }
        this.addr = { R, M, H: dev ? H : -1, g: ga };
        return true;
      }
      a = r + 1;
    }
    return false;
  }
  g(name) {
    const i = GLOBALS.indexOf(name);
    const v = this.m.peekw(this.addr.g - 2 * i);
    return v > 32767 ? v - 65536 : v;
  }
  setg(name, v) { this.m.pokew(this.addr.g - 2 * GLOBALS.indexOf(name), v & 0xffff); }
  // square y,x (1-based) as its screen character and its mine byte
  ch(y, x) { return this.m.peek(this.addr.R + y * 33 + x); }
  mine(y, x) { return this.m.peek(this.addr.M + y * 33 + x); }
  // the whole field as text: # covered, P flag, * mine, @ hit, X wrong flag, . open, 1-8 (1 is tile 0), q queued
  board() {
    const W = this.g('W'), H = this.g('H'), out = [];
    for (let y = 1; y <= H; y++) {
      let s = '';
      for (let x = 1; x <= W; x++) {
        const c = this.ch(y, x);
        s += c >= 49 && c <= 56 ? String.fromCharCode(c) : ({ 0: '1', 1: '#', 2: 'P', 3: '*', 4: '@', 5: 'X', 6: '.', 7: 'q' }[c] || '?');
      }
      out.push(s);
    }
    return out;
  }
  mines() {
    const W = this.g('W'), H = this.g('H'), out = [];
    for (let y = 1; y <= H; y++) for (let x = 1; x <= W; x++) if (this.mine(y, x)) out.push([y, x]);
    return out;
  }
  // a test board: the mines put in M$() before the first move, HK%(1) set so MLDEAL keeps them
  plant(list) {
    const m = this.m, N = this.g('N');
    if (list.length !== N) throw new Error(`board has ${list.length} mines, the game ${N}`);
    for (let i = 0; i < ROWS; i++) m.poke(this.addr.M + i, 0);
    list.forEach(([y, x]) => m.poke(this.addr.M + y * 33 + x, 1));
    m.pokew(this.addr.H + HOOK.plant, 1);
    return this;
  }
  unplant() { this.m.pokew(this.addr.H + HOOK.plant, 0); return this; }
  // frames (1/20 s) the last action took, from the key being read to the key loop waiting again
  actionFrames() { return (this.m.peekw(this.addr.H + HOOK.done) - this.m.peekw(this.addr.H + HOOK.read)) & 0xffff; }
  // the game waits for a key in its key loop (the dev build sets HK%(4) just before PAUSE)
  waiting() { return this.find() && this.addr.H > 0 && this.m.peekw(this.addr.H + HOOK.wait) === 1; }
  // run until the game waits for a key (false if it never does in max seconds)
  idle(max = 30) {
    for (let i = 0; i < max * 20; i++) { if (this.waiting()) return true; this.m.runTicks(1); }
    return this.waiting();
  }
  // press a key and wait until the game has dealt with it and waits again; returns seconds taken
  act(k) {
    const m = this.m, M = this.addr.H;
    if (!this.idle()) throw new Error('not waiting for a key\n' + this.text());
    // dealt with when the count of keys moves on (the frame numbers can be 0 when the frame
    // counter wraps, so they can't say it)
    const c0 = m.peekw(M + HOOK.count);
    m.press(k, 2, 3);           // (released for 3 ticks: the keyboard scan must see it let go)
    // (a move that wins goes on to the result: dealt with when CLEARED shows)
    const won = () => /CLEARED/.test(this.text());
    for (let i = 0; i < 6000 && m.peekw(M + HOOK.count) === c0 && !(i % 10 === 0 && won()); i++) m.runTicks(1);
    if (won()) return ((m.peekw(0x20CB) - m.peekw(M + HOOK.read)) & 0xffff) / 20;
    if (m.peekw(M + HOOK.count) === c0 || !this.idle()) {
      throw new Error(`key ${k} never dealt with (waiting ${m.peekw(M + HOOK.wait)} cursor ${this.cursor()} E ${this.g('E')})\n` + this.text());
    }
    return this.actionFrames() / 20;
  }
  cursor() { return [this.g('Y'), this.g('X')]; }
  // move the cursor to y,x with the arrows
  goto(y, x) {
    for (let i = 0; i < 80 && this.g('Y') !== y; i++) this.act(this.g('Y') < y ? 'DOWN' : 'UP');
    for (let i = 0; i < 80 && this.g('X') !== x; i++) this.act(this.g('X') < x ? 'RIGHT' : 'LEFT');
    if (this.g('Y') !== y || this.g('X') !== x) throw new Error(`cursor at ${this.cursor()}, wanted ${y},${x}`);
    return this;
  }
  // put the cursor on y,x at once: X% Y% and a window round them by the game's own rule, all
  // poked between two instructions. The screen is not redrawn, so use it on a fresh (all covered)
  // field, or before something that redraws the whole field (a loss)
  jump(y, x) {
    const W = this.g('W'), H = this.g('H');
    let U = this.g('U'), V = this.g('V');
    if (x < U + 2) U = x - 2; if (x > U + 17) U = x - 17; if (U > W - 19) U = W - 19; if (U < 1) U = 1;
    if (y < V + 1) V = y - 1; if (y > V + 2) V = y - 2; if (V > H - 3) V = H - 3; if (V < 1) V = 1;
    this.setg('Y', y); this.setg('X', x); this.setg('U', U); this.setg('V', V);
    return this;
  }
  uncover(y, x) { this.goto(y, x); this.act('EXE'); return this; }
  flag(y, x) { this.goto(y, x); this.act('F'); return this; }
  // In a game: until it waits for a key. Elsewhere (results, menus): until three looks
  // 0.5 s apart see the same screen.
  settle(max = 30) {
    let last = '', same = 0;
    for (let t = 0; t < max; t += 0.5) {
      if (this.waiting()) return this;
      const now = this.text();
      if (now === last) { if (++same >= 3) return this; } else same = 0;
      last = now; this.m.runSeconds(0.5);
    }
    throw new Error('never settled\n' + this.text());
  }
  // what the screen should show: four rows of the field through the window, as characters
  window() {
    const U = this.g('U'), V = this.g('V'), D = this.g('D'), out = [];
    for (let r = 0; r < 4; r++) {
      const row = []; for (let c = 0; c < D; c++) row.push(this.ch(V + r, U + c));
      out.push(row);
    }
    return out;
  }
  // '' or what differs between the screen's field columns and the field through the window
  checkWindow() {
    const want = this.window(), cells = this.m.cells();
    for (let r = 0; r < 4; r++) for (let c = 0; c < want[r].length; c++) {
      const got = cells[r * 20 + c], w = want[r][c];
      if (got !== w) return `row ${r + 1} col ${c + 1}: ${got} on screen, ${w} in the field`;
    }
    return '';
  }
  // the machine's cursor: its place on the screen and whether it is on
  lcdCursor() {
    const d = []; this.m.disp.getSnapshotData(d);
    const pos = d[1], on = d[4];
    const idx = this.m.screen2mem.indexOf(pos);
    return { on: !!on, row: idx < 0 ? 0 : Math.floor(idx / 20) + 1, col: idx < 0 ? 0 : (idx % 20) + 1 };
  }
  udgs() { return this.m.udgs().map((u) => u.map((v) => v & 31)); }
}

const TILES = [[6, 14, 6, 6, 6, 6, 6, 0], [21, 10, 21, 10, 21, 10, 21, 0], [4, 12, 28, 12, 4, 4, 14, 0], [4, 21, 14, 31, 14, 21, 4, 0],
  [21, 14, 27, 17, 27, 14, 21, 0], [17, 10, 4, 10, 17, 0, 14, 0], [0, 0, 0, 4, 0, 0, 0, 0], [21, 10, 21, 10, 21, 10, 21, 0]];

const checker = () => {
  const r = { fails: 0, n: 0, quiet: false,
    ok(c, msg) { r.n++; if (!c) { r.fails++; console.log('FAIL', msg); } else if (!r.quiet) console.log('ok  ', msg); return c; },
    end() { console.log(r.fails ? `${r.fails} of ${r.n} FAILED` : `all ${r.n} ok`); process.exit(r.fails ? 1 : 0); } };
  return r;
};

module.exports = { Game, Machine, ROMS, MODELS, SIZES, NAMES, ROOT, TILES, HOOK, COVER, FLAG, MINE, HIT, WRONG, DOT, QUEUED, checker };
