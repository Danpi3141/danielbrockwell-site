"""Build MineLZ pack images from src/.

    python build.py                # MINELZ.opk        release 32K Datapak, translated and with source
                                   # MINELZ-small.opk  the same translated only, on a 16K Datapak
    python build.py --dev          # build/MINELZ-dev.opk  Rampak with the test hooks kept
    python build.py --source-only  # build/MINELZ-src.opk  untranslated release source on a
                                   # Rampak, for checking the Organiser's own translator
    python build.py --psion        # MINELZ.opk, then psion/ with files for a real Organiser:
                                   # the .OB3 procedures translated only (source in psion/opl/),
                                   # the RPBOOT/RPLOAD loader
                                   # and its RPDATA.ODB file list (Tools/mkrpdata.py)

Lines containing "REM DEBUG" are test hooks ("REM DEBUG+" on a line of its own: the next line is) (a mine layout put in memory by the tests in
place of the random deal, timings, a flag while the game waits for a key); the release build
drops them. Comment lines other than each procedure's first are left out of the packs. @VERSION@, @NEED@ and
@FILENEW@ in the source are replaced by the version and the free memory MINELZ checks for.
"""
import argparse
import glob
import os
import re
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.join(HERE, "..", "..", "Tools")

VERSION = "0.9.2"
# Free memory MINELZ asks for (bytes, from FREE). tests/t_memory.js measures the deepest point
# of a tour of every screen (opening an area: MLGAME% and MLOPEN% together, 5,780 beyond what
# MINELZ sees on a 32K LZ, 5,735 on an LZ64, in 0.9.2) and checks the figure a byte either side.
# On a 32K LZ the best-times file A:MINEBEST shares that memory (on an LZ64 it goes in the other
# banks): measured, it takes 42 bytes when first made and 165 with every table full, so it can
# grow by 123 while the game runs. NEED is the peak, that growth and a little to spare; without
# the file MINELZ asks for FILE_NEW more. (0.9.1 asked for 8,500 and 300: the list of mines and
# the stack for opening areas are gone, and the file's growth wasn't allowed for.)
FILE_NEW = 42
FILE_GROWS = 123
NEED = 5950


# The globals have readable names in src/, and one or two letters on the packs. OPL keeps a
# global's name in every procedure that uses it, so the long names would cost about 270 bytes
# at the game's deepest point (measured); a local's name costs nothing once translated, so the
# locals keep theirs. MLMAIN's source on the pack starts with this table, for editing there.
SHORT = {
    "Board$": "R$", "MineMap$": "M$", "Hook%": "HK%",
    "MapAdr%": "A%", "BrdAdr%": "B%", "Width%": "W%", "Height%": "H%", "Mines%": "N%",
    "Level%": "G%", "CurX%": "X%", "CurY%": "Y%", "ViewX%": "U%", "ViewY%": "V%",
    "ViewW%": "D%", "Panel%": "P%", "ToOpen%": "C%", "Flags%": "F%", "Secs%": "T%",
    "State%": "O%", "HitSq%": "K%", "Sound%": "Z%", "Passes%": "E%", "ClockWas": "Q",
    "Inits$": "I$", "BestLn$": "J$", "CustW%": "CW%", "CustH%": "CH%", "CustN%": "CN%",
}
# a name outside a string: not after a letter, digit, "." (a file's field) or "$" (hex), and
# not a procedure's name (followed by ":")
_NAME = re.compile(r'"[^"]*"|(?<![A-Za-z0-9_.$])([A-Za-z][A-Za-z0-9]*[%$]?)(?![A-Za-z0-9%$:])')


def shorten(text):
    """The globals' long names in text replaced by their short ones (not in strings or REMs;
    field lists of OPEN and CREATE, which are not variables, left alone)."""
    up = {k.upper(): v for k, v in SHORT.items()}
    sub = lambda m: m.group(0) if m.group(1) is None else up.get(m.group(1).upper(), m.group(1))
    out = []
    for ln in text.split("\n"):
        s = ln.lstrip().upper()
        if s.startswith("REM") or re.search(r"\b(OPEN|CREATE)\b", s):
            out.append(ln)
            continue
        out.append(_NAME.sub(sub, ln))
    return "\n".join(out)


def name_key():
    """REM lines for MLMAIN on the pack: each short name and the long one it stands for."""
    lines, cur = [], []
    for long, short in SHORT.items():
        cur.append(f"{short}={long}")
        if len(" ".join(cur)) > 50:
            lines.append("REM " + " ".join(cur))
            cur = []
    return lines + (["REM " + " ".join(cur)] if cur else [])


def sources(dev, short=True):
    out = {}
    for path in sorted(glob.glob(os.path.join(HERE, "src", "*.opl"))):
        with open(path, encoding="latin-1") as f:
            lines = f.read().splitlines()
        if not dev:
            # "REM DEBUG+" takes the next line with it
            drop = {i + 1 for i, ln in enumerate(lines) if "REM DEBUG+" in ln}
            lines = [ln for i, ln in enumerate(lines) if "REM DEBUG" not in ln and i not in drop]
        # The source kept on the pack (for editing on the Organiser) has each procedure's first
        # comment line, which says what it does, and no others: comments make no object code,
        # and with them all the source would not fit a 32K pack. src/ keeps every comment.
        lines = [ln for i, ln in enumerate(lines) if i == 1 or not ln.lstrip().upper().startswith("REM")]
        text = "\n".join(lines) + "\n"
        text = text.replace("@VERSION@", VERSION).replace("@NEED@", str(NEED)).replace("@FILENEW@", str(FILE_NEW))
        assert "@" not in text, path + ": unknown @NAME@"
        out[os.path.basename(path)] = text
    if short:
        # a local named like a global's long name would be renamed with it: refuse that first
        check_names(out)
        for name, text in out.items():
            text = shorten(text)
            if name == "MLMAIN.opl":
                first, comment, rest = text.split("\n", 2)
                text = "\n".join([first, comment] + name_key() + [rest])
            out[name] = text
    return out


def check_names(srcs):
    """OPL names ignore case, so a local or parameter called c% IS the global C% inside its
    procedure. Refuse any local or parameter whose name (and type) is also a global's."""
    names = lambda decl: {re.sub(r"\(.*", "", v.strip()).upper() for v in re.split(r",(?![^(]*\))", decl) if v.strip()}
    glob_ = set()
    for text in srcs.values():
        for m in re.finditer(r"^\s*GLOBAL\s+(.*)$", text, re.M):
            glob_ |= names(m.group(1))
    bad = []
    for fn, text in srcs.items():
        first = text.split("\n", 1)[0]
        params = re.search(r"\((.*)\)", first)
        mine = names(params.group(1)) if params else set()
        for m in re.finditer(r"^\s*LOCAL\s+(.*)$", text, re.M):
            mine |= names(m.group(1))
        bad += [f"{fn}: {n}" for n in sorted(mine & glob_)]
    if bad:
        raise SystemExit("locals or parameters with a global's name:\n  " + "\n  ".join(bad))


def build(out, dev=False, source_only=False, small=False):
    tmp = tempfile.mkdtemp(prefix="minelz_")
    try:
        srcs = sources(dev)
        check_names(srcs)
        for name, text in srcs.items():
            with open(os.path.join(tmp, name), "w", encoding="latin-1", newline="\n") as f:
                f.write(text)
        if small:
            # translated only: .ob3 files with no source text
            files = sorted(glob.glob(os.path.join(tmp, "*.opl")))
            rc = subprocess.call([sys.executable, os.path.join(TOOLS, "opltran.py"), "--no-source", "-o", tmp] + files,
                                 stdout=subprocess.DEVNULL)
            if rc:
                return rc
            for f in files:
                os.remove(f)
        cmd = [sys.executable, os.path.join(TOOLS, "opl2opk.py"), "-f", "--strip-indent"]
        cmd += ["--rampak"] if dev or source_only else ["--size", "16" if small else "32"]
        cmd += ["--no-translate"] if source_only else []
        cmd += [out, tmp]
        return subprocess.call(cmd)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def pc_name(name):
    """Comms Link maps % in Organiser names to _ in PC names."""
    return name.upper().replace("%", "_")


def write_crlf(path, lines):
    # Comms Link RECEIVE rejects tabs and other control characters in a procedure
    with open(path, "w", encoding="latin-1", newline="\r\n") as f:
        for ln in lines:
            if any(ord(c) < 32 for c in ln):
                raise SystemExit(f"{path}: control character in line {ln!r}")
            f.write(ln + "\n")


def object_only(path):
    """An OB3 file with the source text dropped (translated code only, source length 0)."""
    raw = open(path, "rb").read()
    assert raw[:3] == b"ORG" and raw[5] == 0x83, path
    block = raw[6:]
    olen = (block[0] << 8) | block[1]
    block = block[:2 + olen] + bytes(2)
    return b"ORG" + bytes([len(block) >> 8, len(block) & 0xFF, 0x83]) + block


def sync_folder(src, dest):
    """Make dest match src, touching only files that changed (Psi2Win may hold files open)."""
    want, locked = set(), []
    for root, _, files in os.walk(src):
        rel = os.path.relpath(root, src)
        os.makedirs(os.path.join(dest, rel), exist_ok=True)
        for fn in files:
            s, d = os.path.join(root, fn), os.path.join(dest, rel, fn)
            want.add(os.path.normcase(os.path.normpath(d)))
            data = open(s, "rb").read()
            if os.path.isfile(d) and open(d, "rb").read() == data:
                continue
            try:
                with open(d, "wb") as f:
                    f.write(data)
            except PermissionError:
                locked.append(d)
    for root, _, files in os.walk(dest):
        for fn in files:
            d = os.path.join(root, fn)
            if os.path.normcase(os.path.normpath(d)) not in want:
                try:
                    os.remove(d)
                except PermissionError:
                    locked.append(d)
    return locked


def psion_folder(pack):
    """psion/: everything Psi2Win needs to put the game on a real Organiser."""
    dest = os.path.join(HERE, "psion")
    tmp = tempfile.mkdtemp(prefix="minelz_psion_")
    try:
        unpacked, stage = os.path.join(tmp, "unpacked"), os.path.join(tmp, "psion")
        os.makedirs(os.path.join(stage, "opl"))
        rc = subprocess.call([sys.executable, os.path.join(TOOLS, "opk2files.py"), pack, "-o", unpacked],
                             stdout=subprocess.DEVNULL)
        if rc:
            return rc
        for path in sorted(glob.glob(os.path.join(unpacked, "*.ob3"))):
            name = os.path.splitext(os.path.basename(path))[0]
            # translated only (11K, not 26K): on a 32K LZ the files may go to A:, which shares
            # the game's memory; the source goes in opl/ beside them
            with open(os.path.join(stage, pc_name(name) + ".OB3"), "wb") as f:
                f.write(object_only(path))
            source = os.path.splitext(path)[0] + ".opl"
            if os.path.exists(source):
                with open(source, encoding="latin-1") as f:
                    write_crlf(os.path.join(stage, "opl", pc_name(name) + ".OPL"), f.read().splitlines())
        rc = subprocess.call([sys.executable, os.path.join(TOOLS, "mkrpdata.py"), stage,
                              "--title", "MINELZ", "--run", "MINELZ"], stdout=subprocess.DEVNULL)
        if rc:
            return rc
        locked = sync_folder(stage, dest)
        if locked:
            print("could not write (in use?):", *locked, sep="\n  ")
            return 1
        print("psion/ written")
        return 0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dev", action="store_true", help="keep the test hooks, build a Rampak in build/")
    ap.add_argument("--source-only", action="store_true", help="release source, untranslated, on a Rampak in build/")
    ap.add_argument("--psion", action="store_true", help="also write psion/ for Comms Link transfer")
    a = ap.parse_args()
    if a.psion and (a.dev or a.source_only):
        ap.error("--psion goes with the release build only")
    os.makedirs(os.path.join(HERE, "build"), exist_ok=True)
    if a.dev:
        out = os.path.join(HERE, "build", "MINELZ-dev.opk")
    elif a.source_only:
        out = os.path.join(HERE, "build", "MINELZ-src.opk")
    else:
        out = os.path.join(HERE, "MINELZ.opk")
        rc = build(os.path.join(HERE, "MINELZ-small.opk"), small=True)
        if rc:
            return rc
    rc = build(out, a.dev, a.source_only)
    if rc == 0 and a.psion:
        rc = psion_folder(out)
    return rc


if __name__ == "__main__":
    sys.exit(main())
