'use strict';
// Every test, in turn, after building the packs. About ten minutes (two with --quick).
//   node tests/run_all.js [--quick]
const { execFileSync, spawnSync } = require('child_process');
const path = require('path');
const ROOT = path.join(__dirname, '..');
const quick = process.argv.includes('--quick');
for (const a of [['--psion'], ['--dev'], ['--source-only']]) execFileSync('python', [path.join(ROOT, 'build.py'), ...a], { stdio: 'ignore' });
const tests = [
  ['t_rules.js', 'lz64', ...(quick ? ['--quick'] : [])],
  ['t_rules.js', 'lz', '--quick'],
  ['t_first.js', 'lz64', quick ? '20' : '200'],
  ['t_first.js', 'lz', quick ? '8' : '40'],
  ['t_window.js', 'lz64'],
  ['t_clock.js', 'lz64'],
  ['t_clock.js', 'lz'],
  ['t_best.js', 'lz64'],
  ['t_best.js', 'lz'],
  ['t_custom.js', 'lz64'],
  ['t_sound.js', 'lz64'],
  ['t_tick.js', 'lz64'],
  ['t_tick.js', 'lz'],
  ['t_memory.js'],
  ['t_roms.js'],
  ['t_roms.js', '46-lz.rom', '46a-lz64.rom', '--small'],
  ['t_roms.js', '46-lz.rom', '46a-lz64.rom', '--psion'],
  ['t_translate.js', 'lz64'],
  ['t_speed.js', 'lz64'],
  ['t_speed.js', 'lz'],
  ['t_stress.js', quick ? '300' : '1800'],
];
const results = [];
for (const [file, ...args] of tests) {
  const t0 = Date.now();
  const r = spawnSync('node', [path.join(__dirname, file), ...args], { encoding: 'utf8', maxBuffer: 1 << 26 });
  const out = (r.stdout || '') + (r.stderr || '');
  const last = out.trim().split('\n').slice(-1)[0];
  const ok = r.status === 0;
  results.push([`${file} ${args.join(' ')}`, ok, last, ((Date.now() - t0) / 1000).toFixed(0)]);
  console.log(`${ok ? 'ok  ' : 'FAIL'} ${file} ${args.join(' ')}  (${results[results.length - 1][3]} s)  ${last}`);
  if (!ok) console.log(out.split('\n').filter((l) => /FAIL|Error/.test(l)).slice(0, 12).join('\n'));
}
const bad = results.filter((r) => !r[1]).length;
console.log(bad ? `${bad} of ${results.length} test files FAILED` : `all ${results.length} test files ok`);
process.exit(bad ? 1 : 0);
