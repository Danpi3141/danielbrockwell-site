'use strict';
// The window onto the field (spec test plan: "Window"). On each size, after the first move:
// walk the cursor round the edge of the field and through its middle with the arrow keys.
// After every step: the window keeps one row clear above and below the cursor and two columns
// each side (except at the field's edge), so its eight neighbours are on screen; the screen shows
// exactly the field through the window and nothing outside it; the machine's cursor is on the
// square; the panel beside a narrow field is right. Then an arrow held down: the cursor stops
// when it is let go, and never leaves the field.
//   node tests/t_window.js [lz|lz64]
const { Game, SIZES, checker } = require('./lib');
const T = checker();
const model = process.argv[2] || 'lz64';
const g = new Game(model);
g.start();

function mmss(t) { return `${String(Math.floor(t / 60)).padStart(2, '0')}:${String(t % 60).padStart(2, '0')}`; }
// '' or what is wrong with the screen now
function check() {
  const W = g.g('W'), H = g.g('H'), X = g.g('X'), Y = g.g('Y'), U = g.g('U'), V = g.g('V'), D = g.g('D'), P = g.g('P');
  const N = g.g('N'), F = g.g('F'), T_ = g.g('T');
  if (X < 1 || X > W || Y < 1 || Y > H) return `cursor ${Y},${X} off the field`;
  if (D !== Math.min(W, 20)) return `D% ${D}`;
  // the eight neighbours on screen
  for (const [dy, dx] of [[-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 1], [1, -1], [1, 0], [1, 1]]) {
    const y = Y + dy, x = X + dx;
    if (y < 1 || y > H || x < 1 || x > W) continue;
    if (y < V || y > V + 3 || x < U || x > U + D - 1) return `neighbour ${y},${x} off the screen (window ${V},${U})`;
  }
  // the window's margins: the cursor on screen row 2 or 3 unless at the top or bottom
  const sr = Y - V + 1, sc = X - U + 1;
  if ((sr === 1 && V !== 1) || (sr === 4 && V !== H - 3)) return `cursor on screen row ${sr} with the window at row ${V}`;
  if (W > 20 && ((sc < 3 && U !== 1) || (sc > 18 && U !== W - 19))) return `cursor on screen column ${sc} with the window at column ${U}`;
  if (V < 1 || V > Math.max(1, H - 3) || U < 1 || U > Math.max(1, W - 19)) return `window ${V},${U} outside the field`;
  const w = g.checkWindow(); if (w) return w;
  const c = g.lcdCursor();
  if (!c.on || c.row !== sr || c.col !== sc) return `machine's cursor at ${c.row},${c.col} (${c.on ? 'on' : 'off'}), square at ${sr},${sc}`;
  // nothing outside the field but the panel
  const rows = g.rows();
  for (let r = 0; r < 4; r++) {
    const rest = rows[r].slice(D);
    let want;
    if (P === 2) {
      const mid = ' '.repeat(10 - D);
      const lft = N - F;
      let rv = `${V}-${V + 3}/${H}`; rv = rv.length > 5 ? 'R' + rv : 'Rows ' + rv;
      want = mid + [`Mines${String(lft).padStart(5)}`, `Time ${String(Math.floor(T_ / 60)).padStart(2)}:${String(T_ % 60).padStart(2, '0')}`,
        rv.padEnd(10), (g.g('G') === 5 ? 'Custom' : 'Beginner').padEnd(10)][r];
    } else if (P === 1) {
      const lft = Math.max(-99, N - F);
      want = ' '.repeat(16 - D) + [('③' + lft).padStart(4), `${String(Math.floor(T_ / 60)).padStart(3)}m`, `${String(T_ % 60).padStart(3)}s`, ` R${String(Y).padStart(2)}`][r];
    } else want = ' '.repeat(20 - D);
    if ((r === 1 && P) || (r === 2 && P === 1)) {
      // the time may tick between reading T% and the screen: allow one second either way
      if (rest.replace(/\d/g, '0') !== want.replace(/\d/g, '0')) return `panel row ${r + 1}: "${rest}" want "${want}"`;
    } else if (rest !== want) return `panel row ${r + 1}: "${rest}" want "${want}"`;
  }
  return '';
}

const sizes = [['Quick', 1, ...SIZES[1]], ['Beginner', 2, ...SIZES[2]], ['Intermediate', 3, ...SIZES[3]], ['Expert', 4, ...SIZES[4]],
  ['Custom 5x4', 5, 5, 4, 3], ['Custom 9x24', 5, 9, 24, 20], ['Custom 10x5', 5, 10, 5, 8], ['Custom 17x6', 5, 17, 6, 10],
  ['Custom 21x24', 5, 21, 24, 50], ['Custom 30x24', 5, 30, 24, 100]];
for (const [name, sel, W, H, N] of sizes) {
  try {
    if (sel === 5) g.custom(W, H, N); else g.play(sel);
    // a first move in the middle, so the field has numbers and open squares to show
    g.firstMove();
    let steps = 0, bad = '';
    const step = (k) => { g.act(k); steps++; if (!bad) { const e = check(); if (e) bad = `${k} to ${g.cursor()}: ${e}`; } };
    // round the edge: to the top-left corner, then clockwise
    while (g.g('Y') > 1) step('UP');
    while (g.g('X') > 1) step('LEFT');
    for (const [k, n] of [['RIGHT', W - 1], ['DOWN', H - 1], ['LEFT', W - 1], ['UP', H - 1]]) for (let i = 0; i < n; i++) step(k);
    // pushing against each edge does nothing
    step('UP'); step('LEFT');
    // through the middle: down the field in a zigzag, every other row
    for (let y = 1; y <= H && !bad; y += 2) {
      for (let i = 0; i < W - 1; i++) step(y % 4 === 1 ? 'RIGHT' : 'LEFT');
      if (y + 2 <= H) { step('DOWN'); step('DOWN'); }
    }
    // an arrow held down: key repeat after 0.7 s; the cursor stops when it is let go
    let held = '';
    for (const k of ['RIGHT', 'DOWN', 'LEFT', 'UP']) {
      g.m.keyDown(k); g.m.runSeconds(2.5); g.m.keyUp(k); g.run(0.5); g.settle();   // (a repeat already on its way when the key comes up may still move it one square)
      const at = g.cursor().join();
      g.run(1);
      if (g.cursor().join() !== at) held = `${k}: the cursor went on moving after the key was let go`;
      g.settle(); const e = check(); if (e && !held) held = `${k} held: ${e}`;
    }
    T.ok(!bad && !held, `${model} ${name.padEnd(13)} ${steps} steps round the edge and through the middle, arrows held${bad ? '\n  ' + bad : ''}${held ? '\n  ' + held : ''}${bad || held ? '\n' + g.text() : ''}`);
    g.key('ON', 0.5).wait(/Resume/).key('M', 0.5).wait(/Play +Best/);
  } catch (e) { T.ok(false, `${name}: ${e.message}`); g.osMenu(); g.start(); }
}

// No overshoot: an arrow held on Quick (no scrolls, so nothing is dropped) moves the cursor as
// fast as the key repeats, and once it is let go, at most the one repeat already on its way
g.play(1); g.firstMove();
const res = [];
for (const hold of [1.0, 1.3, 1.6]) {
  while (g.g('X') < 20) g.act('RIGHT');
  const x0 = g.g('X');
  g.m.keyDown('LEFT'); g.m.runSeconds(hold); g.m.keyUp('LEFT');
  const xUp = g.g('X');
  g.run(1.5);
  res.push([x0 - xUp, xUp - g.g('X')]);
}
T.ok(res.every(([a, b]) => b <= 1) && res[2][0] > res[0][0], `held 1.0, 1.3, 1.6 s on Quick: moved ${res.map((r) => r[0]).join(', ')} while held, then ${res.map((r) => r[1]).join(', ')} after`);
g.key('ON', 0.6).wait(/Resume/).key('M', 0.6).wait(/Play +Best/);
T.end();
