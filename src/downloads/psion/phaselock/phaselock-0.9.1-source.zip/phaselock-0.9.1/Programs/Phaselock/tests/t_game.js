// End to end: the real pack (PHASE.opk) on the emulated Organiser, played from the
// title to the boss by the test bot through real key presses. Checks the loader, the
// OPL shell's screens, pause and quit, the high-score file and that it survives a
// restart.
//   node tests/t_game.js [rom] [opk]
'use strict';
const assert = require('assert');
const path = require('path');
const { execFileSync } = require('child_process');
const { Machine, TICK } = require('../tools/emu.js');
const { loadBuild, ROOT } = require('./harness.js');
const { makeBot } = require('./bot.js');

const rom = process.argv[2] || '46a-lz64.rom';
const opk = process.argv[3] || path.join(ROOT, 'PHASE.opk');
const core = loadBuild();
if (!process.argv[3]) execFileSync(process.env.PYTHON || 'python', ['build.py'], { cwd: ROOT });
const bot = makeBot(core);
const m = new Machine({ rom, ram: rom.includes('64') ? 64 : 32, deferOCI: !process.env.JAPE_IRQ });
let n = 0;
const ok = (name) => console.log('ok %d - %s', ++n, name);
const secs = () => (m.cycles() / 921600).toFixed(1);

function waitFor(text, seconds, what) {
  for (let i = 0; i < seconds * 20; i++) { if (m.screenText().includes(text)) return; m.runTicks(1); }
  throw new Error('waited ' + seconds + ' s for ' + (what || text) + '\n' + m.screenText());
}

// locate the loaded core and its state block in RAM
function findCore() {
  const sig = core.image.slice(0, 4);                    // xgdx / ldd 0,x / subd #
  for (let a = 0x2000; a < 0x7F00; a++) {
    if (m.peek(a) !== sig[0] || m.peek(a + 1) !== sig[1] || m.peek(a + 2) !== sig[2] || m.peek(a + 3) !== sig[3]) continue;
    if (m.peek(a + 6) !== core.image[6] || m.peek(a + 8) !== core.image[8]) continue;
    return { base: a, state: m.peekw(a + 4) };
  }
  throw new Error('core not found in RAM');
}

// a hopeless player: flies into the nearest enemy without lining up a shot
function crash(st) {
  const o = (nme) => core.sym[nme].value;
  let best = null;
  for (let i = 0; i < 8; i++) {
    const c = st[o('S_EN') + 4 * i + 2], lane = st[o('S_EN') + 4 * i + 1];
    if (c !== 0xff && lane >= 1 && (best === null || c < best.c)) best = { c, lane };
  }
  if (!best) return 0;
  const y = st[o('S_Y')], want = 8 * best.lane - 3;
  return want < y ? 1 : want > y ? 2 : 0;
}

// Play one call of the core with the bot on the real keyboard. opts.at(frame) may press keys.
function playWave(opts) {
  opts = opts || {};
  const { base, state } = findCore();
  const S = (nme) => core.sym[nme].value;
  const d = m.dbg, logic = base + S('fr_logic'), exit = base + S('exit');
  d.setBp(logic); d.setBp(exit);
  const held = { UP: false, DOWN: false };
  const set = (k, on) => { if (held[k] !== on) { if (on) m.keyDown(k); else m.keyUp(k); held[k] = on; } };
  let frames = 0, result = null, exeUntil = -1, over = 0;
  for (;;) {
    const hit = m.run(921600 * 20);
    if (hit < 0) throw new Error('game stalled\n' + m.screenText());
    if (hit === exit) { result = d.a(); over = m.peekw(state + S('S_OVER')); break; }
    frames++;
    if (opts.lives && frames === 1) m.poke(state + S('S_LIVES'), opts.lives);
    if (opts.at && opts.at(frames) === 'stop') continue;
    const st = m.read(state, core.state_size);
    const k = opts.crash ? crash(st) : bot(st);
    set('UP', !!(k & 1)); set('DOWN', !!(k & 2) && !(k & 1));
    if (k & 4 && exeUntil < 0) { set('UP', false); set('DOWN', false); m.keyDown('EXE'); exeUntil = frames + 2; }
    if (exeUntil >= 0 && frames >= exeUntil) { m.keyUp('EXE'); exeUntil = -1; }
  }
  d.setBp(logic, false); d.setBp(exit, false);
  m.allUp();
  return { result, frames, over, score: m.peekw(state + S('S_SCORE')), lives: m.peek(state + S('S_LIVES')) };
}

function tap(key, ticks) {            // press, and release after `ticks` whatever is running
  const until = m.cycles() + ticks * TICK; m.keyDown(key);
  m.onChunk = () => { if (m.cycles() >= until) { m.keyUp(key); m.onChunk = null; } };
}

// ------------------------------------------------------------------ start
m.boot();
m.insertPack(opk, 0);
m.runProc('PHASE', 'B');
const t0 = m.cycles();
waitFor('LOADING', 5);
waitFor('Play', 30, 'the title menu');
const loadTime = (m.cycles() - t0) / 921600;
assert.ok(loadTime < 8, 'load took ' + loadTime.toFixed(1) + ' s');
assert.ok(m.screenText().includes('PHASELOCK') && m.screenText().includes('Scores') && m.screenText().includes('Quit'));
ok('loader and title: core loaded and relocated in ' + loadTime.toFixed(1) + ' s');
console.log(m.screen().map((l) => '    |' + l + '|').join('\n'));

// ------------------------------------------------------------------ scores screen (empty)
m.press('S', 3, 10);
waitFor('1 -----', 3, 'the empty score table');
ok('Scores shows the empty table');
m.runTicks(20); m.press('EXE', 3, 10);
waitFor('Play', 5);

// ------------------------------------------------------------------ quit from the wave card, quit mid-wave
m.press('EXE', 3, 10);
waitFor('WAVE 1: DRONES', 5);
assert.ok(m.screenText().includes('SCORE 0') && m.screenText().includes('EXE=GO'));
console.log(m.screen().map((l) => '    |' + l + '|').join('\n'));
waitFor('EXE=GO', 5); m.runTicks(20); m.press('ON', 3, 10);
waitFor('Play', 5, 'the title after ON/CLEAR on the card');
ok('ON/CLEAR on the wave card returns to the title');

m.press('EXE', 3, 10); waitFor('EXE=GO', 8); m.runTicks(20); m.press('EXE', 3, 0);
let r = playWave({ at: (f) => { if (f === 60) tap('ON', 4); } });
assert.strictEqual(r.result, 2);
waitFor('Play', 5, 'the title after ON/CLEAR in a wave');
ok('ON/CLEAR during a wave returns to the title (after ' + r.frames + ' frames)');

// ------------------------------------------------------------------ pause and resume
m.press('EXE', 3, 10); waitFor('EXE=GO', 8); m.runTicks(20); m.press('EXE', 3, 0);
r = playWave({ at: (f) => { if (f === 100) tap('MODE', 4); } });
assert.strictEqual(r.result, 3);
waitFor('PAUSED - WAVE 1', 5); waitFor('EXE=GO', 5);
console.log(m.screen().map((l) => '    |' + l + '|').join('\n'));
const pausedScore = r.score;
m.runSeconds(3);
assert.ok(m.screenText().includes('PAUSED'), 'still paused');
m.press('EXE', 3, 0);
r = playWave({ lives: 0 });
assert.ok(r.score >= pausedScore, 'score kept across the pause');
ok('MODE pauses with a status card, EXE resumes the same wave');

// ------------------------------------------------------------------ a full run
// continue wave 1 to its end, then every wave; lives are topped up so the run reaches the boss
let wave = 1, total = 0, overrun = 0, cardTime = 0;
const log = [];
for (;;) {
  log.push(`wave ${wave}: result ${r.result} after ${r.frames} frames (${(r.frames / 20).toFixed(0)} s), score ${r.score}0, lives ${r.lives}, overrun ${r.over}`);
  total += r.frames; overrun += r.over;
  if (r.result !== 0) break;
  wave++;
  if (wave > 9) break;
  const tc = m.cycles();
  waitFor('WAVE ' + wave, 8, 'the card for wave ' + wave); waitFor('EXE=GO', 5);
  cardTime = Math.max(cardTime, (m.cycles() - tc) / 921600);
  if (wave === 5) console.log(m.screen().map((l) => '    |' + l + '|').join('\n'));
  m.runTicks(25);
  m.press('EXE', 3, 0);
  r = playWave({ lives: 60 });      // plenty: the point here is to reach every screen
}
console.log(log.map((l) => '    ' + l).join('\n'));
assert.strictEqual(wave, 10, 'the run should clear all nine waves');
assert.strictEqual(overrun, 0, 'OVERRUN across the run');
ok('all nine waves cleared through the OPL shell with real key presses, OVERRUN 0 (slowest wave card: ' + cardTime.toFixed(1) + ' s from the end of a wave)');

// ------------------------------------------------------------------ victory, high-score entry
waitFor('PHASELOCK BROKEN', 8);
waitFor('NAME:', 8, 'high-score entry');
console.log(m.screen().map((l) => '    |' + l + '|').join('\n'));
m.type('BOT\n', 3, 4);
waitFor('1 BOT', 5, 'the score table'); waitFor('4 -----', 5);
m.runTicks(10);
console.log(m.screen().map((l) => '    |' + l + '|').join('\n'));
const finalScore = /1 BOT\s+(\d+)/.exec(m.screenText())[1];
assert.strictEqual(finalScore, r.score + '0');
ok('victory screen, name entry and score table (' + finalScore + ' points)');
m.runTicks(20); m.press('EXE', 3, 10);
waitFor('Play', 5);
assert.ok(m.screenText().includes('HI ' + finalScore + ' BOT'), m.screenText());
ok('title shows the high score');

// ------------------------------------------------------------------ game over path (no top-up, hopeless player)
m.press('EXE', 3, 10); waitFor('EXE=GO', 8); m.runTicks(20); m.press('EXE', 3, 0);
r = playWave({ crash: true });
assert.strictEqual(r.result, 1);
waitFor('GAME OVER', 8);
if (r.score > 0) {                      // any score makes the four-place table while it has gaps
  waitFor('NAME:', 8);
  m.type('ACE\n', 3, 4);
  waitFor('2 ACE', 5, 'second place in the table'); waitFor('4 -----', 5); m.runTicks(10);
  console.log(m.screen().map((l) => '    |' + l + '|').join('\n'));
  assert.ok(m.screenText().includes('1 BOT'));
} else {
  waitFor('PRESS EXE', 8);
}
m.runTicks(20); m.press('EXE', 3, 10);
waitFor('Play', 5);
ok('game over screen when the lives run out (after ' + r.frames + ' frames, ' + r.score + '0 points)');

// ------------------------------------------------------------------ quit, the Organiser is intact, the score persists
m.press('Q', 3, 20);
m.runSeconds(1);
assert.ok(m.screenText().includes('Edit') || m.screenText().includes('Find'), 'back in the Organiser menus:\n' + m.screenText());
assert.deepStrictEqual([m.peek(0x77), m.peek(0x78), m.peek(0x20C0)], [14, 0, 1], 'keyboard variables');
ok('Quit returns to the Organiser with the keyboard variables at their defaults');
for (let i = 0; i < 3 && !m.screenText().includes('Find'); i++) m.press('ON', 3, 10);
m.runProc('PHASE', 'B');
waitFor('Play', 30);
assert.ok(m.screenText().includes('HI ' + finalScore + ' BOT'), m.screenText());
ok('the high score is still there after restarting the game');
console.log('PASS: %d end-to-end checks (%s), %d frames played, %s s of Organiser time', n, rom, total, secs());
