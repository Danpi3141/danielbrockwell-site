"""Assemble src/core.asm and work out its fix-up lists.

The core is assembled at origin 0. As the spec describes, it is then assembled again at
other origins and the outputs are compared: every byte that differs is the high byte of
an absolute address, and its offset goes in a fix-up list. There are two lists, one for
addresses inside the core (code origin moved) and one for addresses inside the state
block (state origin moved). The assembler also records the same lists directly, and the
two methods must agree.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from asm6303 import assemble  # noqa: E402


def diff(a, b):
    assert len(a) == len(b)
    out = [i for i in range(len(a)) if a[i] != b[i]]
    for i in out:
        assert (b[i] - a[i]) & 255 == 1, 'not a high byte at %d' % i
    return out


def build_core(path=None):
    path = path or os.path.join(ROOT, 'src', 'core.asm')
    src = open(path, encoding='utf-8').read()
    a0 = assemble(src, 0, 0, path)
    a_code = assemble(src, 0x100, 0, path)
    a_state = assemble(src, 0, 0x100, path)
    fix_code = diff(a0.out, a_code.out)
    fix_state = diff(a0.out, a_state.out)
    assert fix_code == sorted(a0.fix['code']), 'code fix-ups disagree'
    assert fix_state == sorted(a0.fix['state']), 'state fix-ups disagree'
    assert not set(fix_code) & set(fix_state)
    sym = a0.symbols()
    return {
        'image': list(a0.out),
        'fix_code': fix_code,
        'fix_state': fix_state,
        'sym': sym,
        'state_size': sym['S_END']['value'],
        'listing': a0.listing_text(),
    }


def relocate(core, code_base, state_base):
    img = bytearray(core['image'])
    for lst, base in ((core['fix_code'], code_base), (core['fix_state'], state_base)):
        for off in lst:
            v = ((img[off] << 8 | img[off + 1]) + base) & 0xFFFF
            img[off], img[off + 1] = v >> 8, v & 255
    return img


def delta_list(offsets):
    """Fix-up offsets as one byte each: the gap from the previous one. 255 means
    'skip 254 bytes, no fix-up here'; 0 ends the list."""
    out, prev = [], 0
    for off in offsets:
        d = off - prev
        while d >= 255:
            out.append(255)
            d -= 254
        assert d > 0
        out.append(d)
        prev = off
    return out + [0]


if __name__ == '__main__':
    core = build_core()
    os.makedirs(os.path.join(ROOT, 'build'), exist_ok=True)
    with open(os.path.join(ROOT, 'build', 'core.lst'), 'w', encoding='utf-8') as f:
        f.write(core.pop('listing') + '\n')
    with open(os.path.join(ROOT, 'build', 'core.json'), 'w') as f:
        json.dump(core, f)
    print('core: %d bytes, %d code fix-ups, %d state fix-ups, state block %d bytes' % (
        len(core['image']), len(core['fix_code']), len(core['fix_state']), core['state_size']))
