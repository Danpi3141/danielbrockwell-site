// Runs the Phaselock core in the headless emulator through a small OPL test runner
// (TESTRUN) and records every frame for tools/check.py to compare against the model.
'use strict';
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const { Machine, TICK } = require('../tools/emu.js');

const ROOT = path.resolve(__dirname, '..');
const PY = process.env.PYTHON || 'python';

function py(code) {
  return execFileSync(PY, ['-c', code], { cwd: ROOT, maxBuffer: 64 * 1024 * 1024 }).toString();
}

// build/core.json plus sprite library and wave scripts
function loadBuild() {
  execFileSync(PY, ['tools/corebuild.py'], { cwd: ROOT });
  const core = JSON.parse(fs.readFileSync(path.join(ROOT, 'build', 'core.json')));
  const data = JSON.parse(py(
    "import sys,json;sys.path.insert(0,'tools');import sprites,waves;" +
    "print(json.dumps({'lib':sprites.library(),'waves':[w.bytes() for w in waves.WAVES]}))"));
  core.lib = data.lib; core.waves = data.waves;
  return core;
}

function relocate(core, codeBase, stateBase) {
  const img = core.image.slice();
  for (const [list, base] of [[core.fix_code, codeBase], [core.fix_state, stateBase]]) {
    for (const off of list) {
      const v = ((img[off] << 8 | img[off + 1]) + base) & 0xffff;
      img[off] = v >> 8; img[off + 1] = v & 255;
    }
  }
  return img;
}

const SIG = { M: [0xA5, 0x5A, 0xC3, 0x3C], S: [0x5A, 0xA5, 0x3C, 0xC3], P: [0x11, 0xEE, 0x22, 0xDD], W: [0x33, 0xCC, 0x44, 0xBB], L: [0x55, 0xAA, 0x66, 0x99] };

class Rig {
  constructor(core, opts) {
    opts = opts || {};
    this.core = core;
    this.m = new Machine({ rom: opts.rom, ram: opts.ram, deferOCI: opts.deferOCI });
    const m = this.m;
    m.boot();
    const pack = path.join(__dirname, 'TESTRUN.opk');
    execFileSync(PY, [path.join(ROOT, '..', '..', 'Tools', 'opl2opk.py'), '-f', pack, path.join(__dirname, 'TESTRUN.opl')]);
    m.insertPack(pack, 0);
    m.runProc('TESTRUN', 'B');
    for (let i = 0; i < 40 && !m.screenText().includes('READY'); i++) m.runSeconds(0.25);
    if (!m.screenText().includes('READY')) throw new Error('TESTRUN did not start\n' + m.screenText());
    this.addr = {};
    for (const k of Object.keys(SIG)) {
      this.addr[k] = m.find(SIG[k]);
      if (this.addr[k] < 0) throw new Error('array ' + k + ' not found');
    }
    this.base = this.addr.M; this.state = this.addr.S;
    m.write(this.base, relocate(core, this.base, this.state));
    m.write(this.addr.L, core.lib);
    this.sym = {};
    for (const [n, v] of Object.entries(core.sym)) {
      this.sym[n] = v.seg === 'code' ? this.base + v.value : v.seg === 'state' ? this.state + v.value : v.value;
    }
    this.trace = null;
  }

  setParams(p) {
    const m = this.m, P = this.addr.P;
    if (p.wave) m.write(this.addr.W, p.wave);
    m.pokew(P + 0, p.state !== undefined ? p.state : this.state);
    m.pokew(P + 2, this.addr.W);
    m.pokew(P + 4, this.addr.L);
    m.pokew(P + 6, p.score || 0);
    m.pokew(P + 8, p.stock !== undefined ? p.stock : 0x0301);
    m.pokew(P + 10, p.tune !== undefined ? p.tune : 0x0206);
    m.pokew(P + 12, p.mode || 0);
    m.pokew(P + 14, 0);
    this.params = p;
  }

  stateBytes() { return this.m.read(this.state, this.core.state_size); }
  st(name, i) { return this.m.peek(this.sym[name] + (i || 0)); }
  hex(a) { return Buffer.from(a).toString('hex'); }

  // Call the core once. opts.keys(frame, rig) returns the S_KEYS value to force for that
  // frame, or undefined to leave what the core read from the keyboard.
  // opts.onFrame(frame, rig) is called at fr_logic (real key presses can be made there).
  // Returns { result, frames, score, stock, overrun, stats }.
  call(opts) {
    opts = opts || {};
    const m = this.m, s = this.sym, d = m.dbg;
    const bps = ['fr_logic', 'fr_udg', 'fr_comp', 'fr_pres', 'fr_sound', 'fr_end', 'exit', 'sound.play'];
    bps.forEach((n) => d.setBp(s[n]));
    const rec = this.trace ? { type: 'call', params: this.paramWords(), addr: this.addr, frames: [] } : null;
    if (rec) {
      rec.wave = m.read(this.addr.W, 256); rec.lib = m.read(this.addr.L, 256);
      rec.framLowHint = null;
    }
    // start: press a key so TESTRUN's GET returns and it calls USR
    // (opts.cont: the core is already running after a call that stopped at maxFrames)
    let hit;
    if (!opts.cont) {
      m.keyDown('SPACE');
      hit = m.runTo(s.entry, 921600 * 5);
      m.keyUp('SPACE');
      if (hit !== s.entry) throw new Error('core was not entered\n' + m.screenText());
    }
    const stats = { frames: 0, maxActive: 0, sumActive: 0, stage: { logic: [0, 0], udg: [0, 0], comp: [0, 0], pres: [0, 0], sound: [0, 0] }, hist: [] };
    let frame = 0, cur = null, last = 0, result = null, tone = null;
    const maxFrames = opts.maxFrames || 100000;
    const t = {};
    for (;;) {
      hit = m.run(921600 * 8);
      if (hit < 0) {
        // returned to OPL without reaching the exit routine (refused the state block)?
        if (frame === 0 && /R=\d/.test(m.screenText())) { result = null; break; }
        throw new Error('core stalled at frame ' + frame + '\n' + m.screenText());
      }
      if (hit === s.fr_logic) {
        if (opts.onFrame) opts.onFrame(frame, this);
        if (opts.keys) {
          const k = opts.keys(frame, this);
          if (k !== undefined) { m.poke(s.S_KEYS, k); m.pokew(s.S_IDLE, 0); }
        }
        t.logic = m.cycles();
        cur = rec ? { pre: this.hex(this.stateBytes()) } : null;
        tone = null;
      } else if (hit === s.fr_udg) { t.udg = m.cycles();
      } else if (hit === s.fr_comp) { t.comp = m.cycles();
      } else if (hit === s.fr_pres) { t.pres = m.cycles();
      } else if (hit === s.fr_sound) {
        t.sound = m.cycles();
        if (cur) { cur.post = this.hex(this.stateBytes()); cur.cells = this.hex(m.cells()); cur.udg = this.hex([].concat(...m.udgs())); }
      } else if (hit === s['sound.play']) {
        tone = [d.d(), d.x()];
      } else if (hit === s.fr_end) {
        t.end = m.cycles();
        const st = stats.stage;
        const add = (k, v) => { st[k][0] += v; if (v > st[k][1]) st[k][1] = v; };
        add('logic', t.udg - t.logic); add('udg', t.comp - t.udg); add('comp', t.pres - t.comp);
        add('pres', t.sound - t.pres); add('sound', t.end - t.sound);
        const active = t.end - t.logic;
        stats.sumActive += active; if (active > stats.maxActive) stats.maxActive = active;
        stats.frames++;
        if (cur) { cur.end = this.hex(this.stateBytes()); cur.tone = tone; cur.cyc = active; rec.frames.push(cur); }
        frame++;
        if (opts.afterFrame) opts.afterFrame(frame, this);
        if (frame >= maxFrames) { result = -1; break; }
      } else if (hit === s.exit) {
        result = d.a();
        if (cur && !cur.end && cur.post) { cur.end = null; cur.tone = null; cur.cyc = 0; rec.frames.push(cur); }
        break;
      }
    }
    bps.forEach((n) => d.setBp(s[n], false));
    const out = { result, frames: frame, stats };
    if (result === null || result >= 0) {
      // let the exit path finish and OPL print the result
      for (let i = 0; i < 80 && !m.screenText().includes('R='); i++) m.runTicks(1);
      const P = this.addr.P;
      out.score = m.peekw(P + 6); out.stock = m.peekw(P + 8); out.overrun = m.peekw(P + 14);
      out.screen = m.screen();
      const mm = /R=(-?\d+)/.exec(m.screenText());
      out.oplResult = mm ? parseInt(mm[1], 10) : null;
    }
    if (rec) { rec.result = result; rec.out = { score: out.score, stock: out.stock, overrun: out.overrun }; this.trace.push(rec); }
    return out;
  }

  // the core is still running (a call stopped at maxFrames): quit it with ON/CLEAR
  stop() {
    this.tap('ON', 3);
    const o = this.call({ cont: true, maxFrames: 50 });
    if (o.result !== 2) throw new Error('ON/CLEAR did not stop the core: ' + o.result);
    return o;
  }

  // press a key now and let go after `ticks` ticks of emulated time, whatever the
  // core is doing by then (KB$BREK waits for ON/CLEAR to be released)
  tap(key, ticks) {
    const m = this.m, until = m.cycles() + ticks * TICK;
    m.keyDown(key);
    const prev = m.onChunk;
    m.onChunk = () => { if (m.cycles() >= until) { m.keyUp(key); m.onChunk = prev; } if (prev) prev(); };
  }

  paramWords() { const r = []; for (let i = 0; i < 8; i++) r.push(this.m.peekw(this.addr.P + 2 * i)); return r; }

  startTrace() { this.trace = []; }
  saveTrace(file) {
    const head = { type: 'head', sym: this.core.sym, state_size: this.core.state_size, stateAddr: this.state, base: this.base };
    fs.writeFileSync(file, [head].concat(this.trace).map((r) => JSON.stringify(r)).join('\n') + '\n');
    this.trace = [];
  }
}

// run tools/check.py on a trace; throws if the model and the core disagree
function check(file, extra) {
  try {
    return execFileSync(PY, ['tools/check.py', file].concat(extra || []), { cwd: ROOT, maxBuffer: 64 * 1024 * 1024, stdio: ['ignore', 'pipe', 'pipe'] }).toString().trim();
  } catch (e) {
    throw new Error('model check failed: ' + (e.stderr ? e.stderr.toString() : e.message));
  }
}

// deterministic random numbers for the fuzz tests
function rng(seed) {
  let s = seed >>> 0;
  return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
}

module.exports = { Rig, loadBuild, relocate, check, rng, ROOT, TICK };
