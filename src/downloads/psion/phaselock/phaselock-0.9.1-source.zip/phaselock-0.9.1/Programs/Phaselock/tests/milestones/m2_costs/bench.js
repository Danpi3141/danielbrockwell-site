const {Machine}=require('../../../tools/emu.js');
const {execFileSync}=require('child_process');
const py=`import sys,json;sys.path.insert(0,'tools');from asm6303 import assemble;a=assemble(open('tests/milestones/m2_costs/bench.asm').read());print(json.dumps({'image':list(a.out),'sym':a.symbols()}))`;
const asm=JSON.parse(execFileSync('python',['-c',py]).toString());
const m=new Machine(); m.boot(); m.insertPack(__dirname+'/MCRUN.opk',0); m.runProc('MCRUN','B'); m.runSeconds(2);
console.log(m.screen()[0]);
const base=m.find([0xA5,0x5A,0xC3,0x3C]), par=m.find([0x5A,0xA5,0x3C,0xC3]);
console.log('base',base.toString(16),'par',par.toString(16));
m.write(base,asm.image);
const frame=[]; for(let i=0;i<80;i++) frame.push(i%7==0?2:(i%11==0?45:32));
m.write(par,frame.concat([0x74,0xD8,0xF0,0xD8,0x74],[0,0,0,0,0,16,28,31]));
const labels=Object.keys(asm.sym).filter(k=>k.startsWith('t_')).sort((a,b)=>asm.sym[a].value-asm.sym[b].value);
m.keyDown('EXE'); 
let r=m.runTo(base+asm.sym[labels[0]].value, 921600*5); m.keyUp('EXE');
let prev=m.cycles();
for(let i=1;i<labels.length;i++){
  r=m.runTo(base+asm.sym[labels[i]].value, 921600*5);
  if(r<0) throw new Error('missed '+labels[i]);
  const c=m.cycles(); console.log(labels[i-1].padEnd(10), c-prev, 'cycles'); prev=c;
}
m.runSeconds(1); console.log(JSON.stringify(m.screen()));
