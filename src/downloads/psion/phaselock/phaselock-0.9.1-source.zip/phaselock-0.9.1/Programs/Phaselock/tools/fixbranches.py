#!/usr/bin/env python3
"""Rewrite branches the assembler reports as out of range: bsr->jsr, bra->jmp, bcc->lbcc."""
import re, subprocess, sys, os
src = sys.argv[1]
asm = os.path.join(os.path.dirname(__file__), 'asm6303.py')
for _ in range(200):
    r = subprocess.run([sys.executable, asm, src], capture_output=True, text=True)
    if r.returncode == 0:
        print(r.stdout.strip().split('\n')[-1]); break
    m = re.search(r':(\d+): branch out of range', r.stderr)
    if not m:
        sys.exit(r.stderr)
    n = int(m.group(1)) - 1
    lines = open(src).read().split('\n')
    def sub(mm):
        op = mm.group(2)
        new = {'bsr': 'jsr', 'bra': 'jmp'}.get(op, 'l' + op)
        return mm.group(1) + new + ' ' * max(1, len(mm.group(3)) - (len(new) - len(op)))
    lines[n] = re.sub(r'^(.*?\s)(b\w+)(\s+)', sub, lines[n], count=1)
    print('fixed line', n + 1, lines[n].strip())
    open(src, 'w', newline='\n').write('\n'.join(lines))
