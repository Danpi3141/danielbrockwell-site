// Lives the test bot loses in each wave when it has plenty, and how long each wave lasts.
//   node tests/profile.js [runs]
const { Rig, loadBuild, rng } = require('./harness.js');
const { makeBot } = require('./bot.js');
const core = loadBuild(); const rig = new Rig(core);
const runs = parseInt(process.argv[2] || '4', 10);
for (let w = 0; w < 9; w++) {
  const lost = [], secs = [];
  for (let run = 0; run < runs; run++) {
    const bot = makeBot(core, { horizon: 10 + run }); const r = rng(run * 13 + w);
    rig.setParams({ wave: core.waves[w], stock: (60 << 8) | 1 });
    const out = rig.call({ maxFrames: 6000, keys: (f, rg) => (r() < 0.97 ? bot(rg.stateBytes()) : 0) });
    if (out.result === -1) { rig.stop(); lost.push('stuck'); secs.push(300); continue; }
    lost.push(60 - (out.stock >> 8)); secs.push(Math.round(out.frames / 20));
  }
  console.log(`wave ${w + 1}: lives lost ${lost.join(' ')}   seconds ${secs.join(' ')}`);
}
