// Translate every OPL procedure with the Organiser's own translator (in the emulator)
// and compare the object code with what the PC build (Tools/opltran.py) produced.
//   node tests/t_romtran.js [rom]
'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');
const { Machine } = require('../tools/emu.js');
const { ROOT } = require('./harness.js');

const rom = process.argv[2] || '46a-lz64.rom';
const PY = process.env.PYTHON || 'python';
const TOOLS = path.join(ROOT, '..', '..', 'Tools');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'pl_romtran_'));
execFileSync(PY, ['build.py'], { cwd: ROOT });
const srcDir = path.join(ROOT, 'build', 'opl');
const names = fs.readdirSync(srcDir).filter((f) => f.endsWith('.opl')).map((f) => f.slice(0, -4)).sort();

// source-only Rampak
const srcPack = path.join(tmp, 'src.opk');
execFileSync(PY, [path.join(TOOLS, 'opl2opk.py'), '-f', '--rampak', '--no-translate', '--size', '64', srcPack, srcDir]);
// reference: PC-translated object files
const refDir = path.join(tmp, 'ref'); fs.mkdirSync(refDir);
execFileSync(PY, [path.join(TOOLS, 'opltran.py'), '-o', refDir].concat(names.map((n) => path.join(srcDir, n + '.opl'))));

const m = new Machine({ rom, ram: rom.includes('64') ? 64 : 32 });
m.boot();
const pk = m.insertPack(srcPack, 0);
const wait = (text, secs) => { for (let i = 0; i < secs * 20; i++) { if (m.screenText().includes(text)) return true; m.runTicks(1); } return false; };

for (const name of names) {
  m.press('P', 3, 8);
  if (!wait('Edit', 5)) throw new Error('no Prog menu\n' + m.screenText());
  m.press('E', 3, 8);
  for (let i = 0; i < 4 && !m.screenText().includes('Edit B:'); i++) m.press('MODE', 3, 10);
  assert.ok(m.screenText().includes('Edit B:'), m.screenText());
  const pre = /Edit B:(\S+)/.exec(m.screenText());
  if (pre) m.press('ON', 3, 6);               // clear a prefilled name (ON on an empty prompt would leave it)
  assert.ok(/Edit B:\s/.test(m.screenText() + ' '), m.screenText());
  m.type(name, 3, 3);
  m.press('EXE', 3, 20);
  if (!wait(name.toUpperCase() + ':', 20)) throw new Error('editor did not open ' + name + '\n' + m.screenText());
  m.press('MODE', 3, 10);
  if (!wait('Tran', 5)) throw new Error('no editor menu\n' + m.screenText());
  const t0 = m.cycles();
  m.press('T', 3, 5);
  let saved = false;
  for (let i = 0; i < 120 * 20; i++) {
    const s = m.screenText();
    if (s.includes('Save ')) { saved = true; break; }
    if (/ERROR|error|MISSING|BAD|MISMATCH|TOO /.test(s) && !s.includes('TRANSLATING')) throw new Error('translator rejected ' + name + ':\n' + s);
    m.runTicks(1);
  }
  if (!saved) throw new Error('translation of ' + name + ' did not finish\n' + m.screenText());
  const secs = (m.cycles() - t0) / 921600;
  for (let i = 0; i < 4 && !m.screenText().includes('Save B:'); i++) m.press('MODE', 3, 10);
  m.press('EXE', 3, 10);
  if (!wait('Edit', 60) && !wait('Find', 5)) throw new Error('save of ' + name + ' did not finish\n' + m.screenText());
  // back to the top-level menu
  for (let i = 0; i < 4 && !m.screenText().includes('Find'); i++) m.press('ON', 3, 10);
  console.log('translated %s on the Organiser in %s s', name.padEnd(8), secs.toFixed(1));
}

// pull the pack image out of the emulator and unpack it
const raw = [];
for (let a = 0; a < 65536; a++) raw.push(pk.readByte(a));
let len = raw.length; while (len > 10 && raw[len - 1] === 0xff) len--;
len += 2;
const opk = Buffer.concat([Buffer.from([0x4f, 0x50, 0x4b, (len >> 16) & 255, (len >> 8) & 255, len & 255]), Buffer.from(raw.slice(0, len))]);
const outPack = path.join(tmp, 'rom.opk'); fs.writeFileSync(outPack, opk);
const romDir = path.join(tmp, 'rom'); fs.mkdirSync(romDir);
execFileSync(PY, [path.join(TOOLS, 'opk2files.py'), outPack, '-o', romDir], { stdio: 'pipe' });
let same = 0;
for (const name of names) {
  const a = fs.readFileSync(path.join(refDir, name + '.ob3'));
  const cand = fs.readdirSync(romDir).find((f) => f.toLowerCase() === (name + '.ob3').toLowerCase());
  assert.ok(cand, 'no translated ' + name + ' on the pack');
  const b = fs.readFileSync(path.join(romDir, cand));
  if (!a.equals(b)) throw new Error('object code differs for ' + name + ' (PC ' + a.length + ' bytes, Organiser ' + b.length + ')');
  same++;
}
fs.rmSync(tmp, { recursive: true, force: true });
console.log('PASS: the Organiser\'s translator (%s) and the PC build agree byte for byte on all %d procedures', rom, same);
