// Real keyboard, pause/resume and exit-path tests (through the OS keyboard buffer,
// nothing injected below it).
//   node tests/t_keys.js [rom]
'use strict';
const os = require('os'), path = require('path'), fs = require('fs');
const assert = require('assert');
const { Rig, loadBuild, check, rng } = require('./harness.js');

const rom = process.argv[2] || '46a-lz64.rom';
const core = loadBuild();
const rig = new Rig(core, { rom, ram: rom.includes('64') ? 64 : 32 });
const m = rig.m;
const file = path.join(os.tmpdir(), 'pl_keys_' + process.pid + '.jsonl');
const kbVars = () => [m.peek(0x77), m.peek(0x78), m.peek(0x20C0)];
const defaults = kbVars();
console.log('keyboard variables before any call (KBB_DLAY, KBB_REPT, KBB_CLIK):', defaults.join(', '));
const emptyWave = [0, 0, 2, 0, 1, 0, 255, 0, 255, 0, 255, 0, 255, 0, 255, 0, 255, 0, 255, 0, 255, 0, 0];   // a drone in lane 0 every 12.75 s, out of the ship's way
let n = 0;
const ok = (name) => console.log('ok %d - %s', ++n, name);

function runPlan(plan, frames, params) {
  // plan: [[key, downFrame, upFrame], ...]; returns per-frame S_Y and the call result
  rig.startTrace();
  rig.setParams(Object.assign({ wave: emptyWave, stock: 0x0903 }, params || {}));
  const ys = [], bombs = [];
  const out = rig.call({
    maxFrames: frames,
    onFrame: (f) => { for (const [k, a, b] of plan) { if (f === a) m.keyDown(k); if (f === b) m.keyUp(k); } },
    afterFrame: (f, rg) => { ys.push(rg.st('S_Y')); bombs.push(rg.st('S_BOMBS')); },
  });
  m.allUp();
  if (out.result === -1) rig.stop();
  rig.saveTrace(file); check(file);
  return { ys, bombs, out };
}

// ---- steering: held key moves 2 px a tick, stops within 2 ticks of release
{
  const { ys } = runPlan([['DOWN', 10, 14], ['UP', 30, 50], ['DOWN', 60, 61], ['UP', 70, 71]], 90);
  // ys[f] = y after frame f. Ship starts at 12.
  const firstMove = ys.findIndex((y) => y !== 12);
  assert.ok(firstMove >= 10 && firstMove <= 12, 'DOWN took effect at frame ' + firstMove);
  const downSteps = ys.slice(9, 20).filter((y, i, a) => i > 0 && y !== a[i - 1]).length;
  assert.strictEqual(ys[19] - 12, 2 * downSteps);
  assert.ok(downSteps >= 3 && downSteps <= 5, 'held 4 ticks moved ' + downSteps + ' steps');
  const lastDown = ys.slice(0, 30).reduce((acc, y, i, a) => (i > 0 && y !== a[i - 1] ? i : acc), 0);
  assert.ok(lastDown <= 14 + 2, 'ship stopped ' + (lastDown - 14) + ' ticks after release');
  // UP held 20 ticks from y=20: reaches 0 and clamps
  assert.strictEqual(ys[55], 0, 'UP held long enough reaches the top');
  for (let f = 33; f < 40; f++) assert.strictEqual(ys[f - 1] - ys[f], 2, 'UP moves 2 px every tick while held (frame ' + f + ')');
  const lastUp = ys.slice(0, 60).reduce((acc, y, i, a) => (i > 0 && y !== a[i - 1] ? i : acc), 0);
  assert.ok(lastUp <= 52, 'stopped after release');
  // single-tick taps move exactly one step
  assert.strictEqual(ys[68] - ys[58], 2, 'a one-tick DOWN tap moves 2 px');
  assert.strictEqual(ys[78] - ys[68], -2, 'a one-tick UP tap moves 2 px');
  ok('steering: held arrows move 2 px per tick, stop within 2 ticks, taps move one step');
}

// ---- bottom clamp
{
  const { ys } = runPlan([['DOWN', 5, 40]], 50);
  assert.strictEqual(ys[45], 27);
  ok('ship clamps at y = 27');
}

// ---- bomb: EXE held uses exactly one bomb, a second press another
{
  const { bombs } = runPlan([['EXE', 10, 25], ['EXE', 40, 42]], 60);
  assert.strictEqual(bombs[8], 3);
  assert.strictEqual(bombs[30], 2, 'holding EXE for 15 ticks used one bomb');
  assert.strictEqual(bombs[55], 1, 'a second press used another');
  ok('bomb fires once per EXE press');
}

// ---- MODE pauses with the state intact, MODE=1 resumes exactly there
{
  rig.startTrace();
  rig.setParams({ wave: core.waves[0], stock: 0x0901 });
  const o1 = rig.call({ maxFrames: 400, onFrame: (f) => { if (f === 120) rig.tap('MODE', 3); if (f === 20) m.keyDown('DOWN'); if (f === 25) m.keyUp('DOWN'); } });
  m.allUp();
  assert.strictEqual(o1.result, 3, 'MODE gives result 3');
  assert.strictEqual(o1.oplResult, 3, 'OPL received 3');
  assert.deepStrictEqual(kbVars(), defaults, 'keyboard variables restored on pause');
  assert.ok(m.screenText().replace(/R=3/, '').trim() === '', 'screen cleared on exit:\n' + m.screenText());
  const saved = rig.stateBytes();
  m.runSeconds(2);                                     // OPL shows its card for a while
  rig.setParams({ mode: 1, stock: 0x0101, score: 999 });   // these must be ignored on resume
  let first = null;
  const o2 = rig.call({ maxFrames: 100, onFrame: (f, rg) => { if (f === 0) first = rg.stateBytes(); } });
  const S = core.sym, mask = new Set();
  for (const nm of ['S_KSAV', 'S_LAST', 'S_KEYS', 'S_IDLE', 'S_OVER', 'S_TMP', 'S_MIN', 'S_MINF', 'S_PV', 'S_DIRTY', 'S_EXF', 'S_RES', 'S_FLAGS']) {
    const names = Object.keys(S).filter((k) => S[k].seg === 'state').sort((a, b) => S[a].value - S[b].value);
    const end = names[names.indexOf(nm) + 1];
    for (let i = S[nm].value; i < S[end].value; i++) mask.add(i);
  }
  for (let i = 0; i < saved.length; i++) if (!mask.has(i)) assert.strictEqual(first[i], saved[i], 'state byte ' + i + ' changed across pause');
  assert.strictEqual(o2.result, -1);
  rig.stop();
  rig.saveTrace(file); check(file);
  ok('MODE pauses (result 3), state survives, MODE=1 resumes where it stopped');
}

// ---- ON/CLEAR at 20 random moments: result 2 and the keyboard variables back to defaults
{
  const r = rng(77);
  for (let i = 0; i < 20; i++) {
    const w = Math.floor(r() * 9), at = 1 + Math.floor(r() * (w === 8 ? 60 : 300));
    rig.setParams({ wave: core.waves[w], stock: 0x6301 });
    const held = r() < 0.5 ? (r() < 0.5 ? 'UP' : 'DOWN') : null;
    const o = rig.call({ maxFrames: 400, onFrame: (f) => { if (held && f === Math.max(0, at - 5)) m.keyDown(held); if (f === at) rig.tap('ON', 2 + Math.floor(r() * 6)); } });
    m.allUp();
    assert.strictEqual(o.result, 2, 'quit ' + i + ' gave ' + o.result);
    assert.strictEqual(o.oplResult, 2);
    assert.deepStrictEqual(kbVars(), defaults, 'keyboard variables after quit ' + i);
    assert.strictEqual(m.peek(0x73) /* KBB_NKYS? */ >= 0, true);
    assert.ok(m.screenText().replace(/R=2/, '').trim() === '', 'screen cleared');
    m.runSeconds(1.5);
    assert.ok(m.screenText().includes('R=2'), 'OPL is waiting in GET, no stray key restarted the core');
  }
  ok('ON/CLEAR at 20 random moments: result 2, keyboard variables restored, key buffer empty');
}

// ---- left alone for 30 s: pauses by itself
{
  rig.setParams({ wave: emptyWave, stock: 0x6301 });
  const o = rig.call({ maxFrames: 700 });
  assert.strictEqual(o.result, 3);
  assert.strictEqual(o.frames, 599);
  assert.deepStrictEqual(kbVars(), defaults);
  ok('no key for 600 ticks pauses the game (result 3)');
  // any key resets the idle count
  rig.setParams({ mode: 1 });
  const o2 = rig.call({ maxFrames: 1000, onFrame: (f) => { if (f === 300) m.keyDown('UP'); if (f === 301) m.keyUp('UP'); } });
  m.allUp();
  assert.strictEqual(o2.result, 3);
  assert.ok(o2.frames >= 899 && o2.frames <= 902, 'paused at frame ' + o2.frames);
  ok('a key press restarts the 30 s idle count');
}

// ---- the three other ways out restore the keyboard too
{
  rig.setParams({ wave: [0, 0, 2, 0, 1, 0, 0], stock: 0x0301 });   // empty script: cleared at once
  const o = rig.call({ maxFrames: 50 });
  assert.strictEqual(o.result, 0); assert.strictEqual(o.oplResult, 0);
  assert.strictEqual(o.score, 30, 'three lives left: 30 tens bonus');
  assert.deepStrictEqual(kbVars(), defaults);
  ok('wave cleared: result 0, 10 tens per life, keyboard restored');
  rig.setParams({ wave: core.waves[7], stock: 0x0100 });
  const o2 = rig.call({ maxFrames: 3000 });
  assert.strictEqual(o2.result, 1); assert.strictEqual(o2.oplResult, 1);
  assert.strictEqual(o2.stock >> 8, 0);
  assert.deepStrictEqual(kbVars(), defaults);
  ok('no lives left: result 1, keyboard restored');
}

// ---- something holds the machine for half a second or more (an alarm ringing): pause
{
  rig.setParams({ wave: core.waves[0], stock: 0x0301 });
  const o = rig.call({ maxFrames: 200, afterFrame: (f) => { if (f === 40) m.pokew(0x20CB, (m.peekw(0x20CB) + 30) & 0xffff); } });
  assert.strictEqual(o.result, 3, 'a 30-tick stall pauses');
  assert.strictEqual(o.frames, 40);
  assert.deepStrictEqual(kbVars(), defaults);
  rig.setParams({ mode: 1 });
  const o2 = rig.call({ maxFrames: 60, afterFrame: (f) => { if (f === 20) m.pokew(0x20CB, (m.peekw(0x20CB) + 5) & 0xffff); } });
  assert.strictEqual(o2.result, -1, 'a 5-tick stall only counts as overrun');
  assert.strictEqual(rig.st('S_OVER', 1), 4);       // the counter jumped 5: one frame for the first tick, four missed
  rig.stop();
  ok('a stall of 10 ticks or more pauses the game; a shorter one is counted in OVERRUN');
}

// ---- a state block the core was not relocated for is refused before anything is touched
{
  const before = rig.stateBytes();
  rig.setParams({ wave: core.waves[0], state: rig.state + 2 });
  const o = rig.call({ maxFrames: 5 });
  assert.strictEqual(o.result, null);            // never reached the exit routine
  for (let i = 0; i < 40 && !m.screenText().includes('R='); i++) m.runTicks(1);
  assert.ok(m.screenText().includes('R=4'), m.screenText());
  assert.deepStrictEqual(rig.stateBytes(), before);
  assert.deepStrictEqual(kbVars(), defaults);
  ok('wrong state block address: result 4, nothing written');
}

fs.unlinkSync(file);
console.log('PASS: %d keyboard and exit-path tests (%s)', n, rom);
