; =====================================================================
; Phaselock loader helpers. Position independent (relative branches only),
; so OPL can put them in any integer array.
;
;   USR(ADDR(B%()), ADDR(C%()))          hex decoder
;       C%(1) = address of an OPL string of hex digits (length byte first)
;       C%(2) = where to put the bytes; advanced past them on return
;   USR(ADDR(B%())+reloc, ADDR(C%()))    relocator
;       C%(1) = address of a fix-up list: one byte per fix-up, the gap from the
;               previous one; 255 = skip 254 bytes; 0 = end
;       C%(2) = address the gaps count from
;       C%(3) = value to add to each 16-bit word
; =====================================================================
T0      = $41
T2      = $43
T4      = $45

hexdec: xgdx                    ; X = control block
        tpa
        psha
        sei                     ; a key click from the keyboard interrupt would use
        pshx                    ; the scratch words
        ldd  2,x
        std  T2                 ; destination
        ldx  0,x
        ldab 0,x                ; string length
        lsrb                    ; bytes to make
        beq  .done
        inx
.lp:    bsr  nib
        asla
        asla
        asla
        asla
        staa T0
        bsr  nib
        adda T0
        stx  T4
        ldx  T2
        staa 0,x
        inx
        stx  T2
        ldx  T4
        decb
        bne  .lp
.done:  pulx
        ldd  T2
        std  2,x
        pula
        tap
        rts

; next hex digit at X as a value in A
nib:    ldaa 0,x
        inx
        suba #48
        cmpa #9
        bls  .r
        suba #7
.r:     rts

reloc:  xgdx
        tpa
        psha
        sei
        ldd  2,x
        std  T2                 ; position
        ldd  4,x
        std  T4                 ; value to add
        ldx  0,x                ; list
.lp:    ldab 0,x
        beq  .done
        inx
        stx  T0
        cmpb #255
        bne  .fix
        decb
        clra
        addd T2
        std  T2
        bra  .nx
.fix:   clra
        addd T2
        std  T2
        ldx  T2
        ldd  0,x
        addd T4
        std  0,x
.nx:    ldx  T0
        bra  .lp
.done:  pula
        tap
        rts
