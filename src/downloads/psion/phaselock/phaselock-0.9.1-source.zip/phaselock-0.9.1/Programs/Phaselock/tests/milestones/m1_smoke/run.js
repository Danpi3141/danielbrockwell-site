const {Machine}=require('../../../tools/emu.js');
for (const rom of ['46a-lz64.rom','46-lz.rom']) {
  const m=new Machine({rom, ram: rom.includes('64')?64:32});
  m.boot(); m.insertPack(__dirname+'/M1.opk',0);
  m.runProc('M1','B'); m.runSeconds(2);
  console.log(rom, JSON.stringify(m.screen()), 'udg2 rows', m.udg(2).join(','));
  m.press('EXE',3,10); m.runSeconds(1);
  console.log(rom, JSON.stringify(m.screen()), 'udg2 rows', m.udg(2).join(','));
  console.log(m.pixels().slice(0,8).map(r=>r.slice(0,30)).join('\n'));
  m.press('EXE',3,10); m.runSeconds(1); console.log(JSON.stringify(m.screen()));
}
