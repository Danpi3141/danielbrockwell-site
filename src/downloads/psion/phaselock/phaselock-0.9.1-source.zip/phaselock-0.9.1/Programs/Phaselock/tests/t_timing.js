// Timing: cycles per frame and per stage, the worst case, and OVERRUN over ten minutes
// of wave 8. Run with interrupts modelled as on real hardware (a masked timer interrupt
// stays pending) and as Jape does it (a masked timer interrupt is dropped).
//   node tests/t_timing.js [minutes]
'use strict';
const assert = require('assert');
const { Rig, loadBuild, rng } = require('./harness.js');
const { makeBot } = require('./bot.js');

const minutes = parseFloat(process.argv[2] || '10');
const core = loadBuild();
const TICKC = 0xB3DD + 35;        // cycles between keyboard interrupts
const bot = makeBot(core);

function summary(st) {
  const f = st.frames, s = st.stage;
  const row = (k) => `${k} avg ${Math.round(s[k][0] / f)} max ${s[k][1]}`;
  return `${f} frames; whole frame avg ${Math.round(st.sumActive / f)} max ${st.maxActive} of ${TICKC} cycles; ` + ['logic', 'udg', 'comp', 'pres', 'sound'].map(row).join('; ');
}

for (const deferOCI of [true, false]) {
  const label = deferOCI ? 'hardware-style interrupts' : 'Jape-style interrupts';
  const rig = new Rig(core, { deferOCI });
  const m = rig.m;

  // ---- worst case: eight enemies in two classes at 40 px/s, ship moving every tick,
  // explosions, bombs and the 10 ms sounds
  {
    const wave = [0, 1, 8, 8, 4, 0];
    for (let i = 0; i < 100; i++) wave.push(i === 0 ? 5 : 3, (i & 3) | ((i & 1) << 2) | (i % 3 === 0 ? 0x20 : 0) | (i % 5 === 0 ? 0x10 : 0) | 8);
    wave.push(0);
    rig.setParams({ wave, stock: 0xFF7F, tune: 0x0203 });
    const t0 = m.cycles(), f0 = m.peekw(0x20CB);
    const out = rig.call({ maxFrames: 900, keys: (f) => ((f >> 2) & 1 ? 1 : 2) | (f % 40 === 0 ? 4 : 0) });
    const ticks = (m.peekw(0x20CB) - f0) & 0xffff;
    if (out.result === -1) rig.stop();
    console.log(`${label}, stress wave: ${summary(out.stats)}; ticks ${ticks}`);
    assert.ok(out.stats.maxActive < TICKC, 'a frame ran past its tick: ' + out.stats.maxActive);
    assert.strictEqual(rig.st('S_OVER') * 256 + rig.st('S_OVER', 1), 0, 'OVERRUN in the stress wave');
  }

  // ---- ten minutes of wave 8, played by the bot
  {
    const want = Math.round(minutes * 60 * 20);
    let frames = 0, overrun = 0, calls = 0, lateTicks = 0;
    const tot = { frames: 0, sumActive: 0, maxActive: 0, stage: { logic: [0, 0], udg: [0, 0], comp: [0, 0], pres: [0, 0], sound: [0, 0] } };
    const r = rng(5);
    while (frames < want) {
      rig.setParams({ wave: core.waves[7], stock: 0x6301 });
      const c0 = m.cycles(), f0 = m.peekw(0x20CB);
      const out = rig.call({ maxFrames: want - frames, keys: (f, rg) => (r() < 0.9 ? bot(rg.stateBytes()) : Math.floor(r() * 4)) });
      const ticks = (m.peekw(0x20CB) - f0) & 0xffff;
      if (out.result === -1) rig.stop();
      else overrun += out.overrun;
      frames += out.frames; calls++;
      // every tick that passed while the wave ran was a frame (a couple are spent entering and leaving)
      lateTicks += Math.max(0, ticks - out.frames - 3);
      tot.frames += out.stats.frames; tot.sumActive += out.stats.sumActive; tot.maxActive = Math.max(tot.maxActive, out.stats.maxActive);
      for (const k of Object.keys(tot.stage)) { tot.stage[k][0] += out.stats.stage[k][0]; tot.stage[k][1] = Math.max(tot.stage[k][1], out.stats.stage[k][1]); }
    }
    console.log(`${label}, wave 8 for ${(frames / 1200).toFixed(1)} min in ${calls} calls: OVERRUN ${overrun}, ticks without a frame ${lateTicks}; ${summary(tot)}`);
    assert.strictEqual(overrun, 0, 'OVERRUN must be 0');
    assert.strictEqual(lateTicks, 0, 'no tick may pass without a frame');
  }
}
console.log('PASS: every frame fits its tick, OVERRUN 0');
