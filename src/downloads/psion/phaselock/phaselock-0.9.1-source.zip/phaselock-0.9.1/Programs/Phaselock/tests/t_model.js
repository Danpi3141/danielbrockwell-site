// Differential test: the real core in the emulator against the Python model, every
// frame of every wave, with random keys and with the test bot.
//   node tests/t_model.js [rounds] [rom]
'use strict';
const os = require('os'), path = require('path'), fs = require('fs');
const { Rig, loadBuild, check, rng } = require('./harness.js');
const { makeBot } = require('./bot.js');

const rounds = parseInt(process.argv[2] || '2', 10);
const rom = process.argv[3] || '46a-lz64.rom';
const core = loadBuild();
const rig = new Rig(core, { rom, ram: rom.includes('64') ? 64 : 32 });
// TDEL=<cycles> shortens the keyboard interrupt period, so that the OS's interrupt handler
// lands all over the core's logic instead of only while it sleeps
if (process.env.TDEL) rig.m.pokew(0x71, parseInt(process.env.TDEL, 10));
const bot = makeBot(core);
const file = path.join(os.tmpdir(), 'pl_model_' + process.pid + '.jsonl');
let frames = 0, calls = 0;
const results = {};

for (let round = 0; round < rounds; round++) {
  for (let w = 0; w < core.waves.length; w++) {
    for (const policy of ['random', 'bot', 'mixed']) {
      const r = rng(1000 * round + 10 * w + policy.length);
      let k = 0, hold = 0;
      const lives = policy === 'random' ? 1 + Math.floor(r() * 5) : 3 + Math.floor(r() * 6);
      const bombs = Math.floor(r() * 4);
      const tune = ((1 + Math.floor(r() * 3)) << 8) | (3 + Math.floor(r() * 6));
      rig.startTrace();
      rig.setParams({ wave: core.waves[w], stock: (lives << 8) | bombs, tune, score: Math.floor(r() * 3) ? Math.floor(r() * 500) : 32700 });
      const out = rig.call({
        maxFrames: 4000,
        keys: (f, rg) => {
          if (policy === 'bot' || (policy === 'mixed' && (f >> 6) & 1)) return bot(rg.stateBytes());
          if (hold-- <= 0) { k = [0, 1, 2, 0, 3][Math.floor(r() * 5)]; hold = Math.floor(r() * 14); }
          return k | (r() < 0.004 ? 4 : 0);
        },
      });
      if (out.result === -1) {
        // still running after 4000 frames: stop it with ON/CLEAR
        rig.stop();
      }
      rig.saveTrace(file);
      const msg = check(file);
      const n = parseInt(/on (\d+) frames/.exec(msg)[1], 10);
      frames += n; calls++;
      results[out.result] = (results[out.result] || 0) + 1;
      console.log(`round ${round} wave ${w + 1} ${policy.padEnd(6)} result ${out.result} frames ${out.frames} score ${out.score} lives ${out.stock >> 8} max frame ${out.stats.maxActive} cycles`);
    }
  }
}
fs.unlinkSync(file);
console.log('PASS: model and core agree on %d frames in %d calls (%s). Results: %s', frames, calls, rom, JSON.stringify(results));
