const {Machine}=require('../../../tools/emu.js');
const {execFileSync}=require('child_process');
const py=`import sys,json;sys.path.insert(0,'tools');from asm6303 import assemble;a=assemble(open('tests/milestones/m2_costs/keys.asm').read());print(json.dumps({'image':list(a.out),'sym':a.symbols()}))`;
const asm=JSON.parse(execFileSync('python',['-c',py]).toString());
function run(plan){
  const m=new Machine(); m.boot(); m.insertPack(__dirname+'/MCRUN.opk',0); m.runProc('MCRUN','B'); m.runSeconds(2);
  const base=m.find([0xA5,0x5A,0xC3,0x3C]), par=m.find([0x5A,0xA5,0x3C,0xC3]);
  m.write(base,asm.image);
  m.keyDown('EXE'); if(m.runTo(base,921600*5)<0) throw new Error('no entry'); m.keyUp('EXE');
  const tick=base+asm.sym['t_tick'].value; let n=0; const held=[];
  while(n<64){ const r=m.runTo(tick,921600*10); if(r<0) throw new Error('no tick'); 
    let h=''; for(const [k,a,b] of plan){ if(n==a) m.keyDown(k); if(n==b) m.keyUp(k); if(n>=a&&n<b) h+=k[0]; }
    held.push(h||'.'); n++; }
  m.runSeconds(1);
  const log=m.read(par,64);
  console.log('held ',held.map(h=>h.padEnd(2)).join(''));
  console.log('seen ',log.map(v=>(v?String(v):'.').padEnd(2)).join(''));
  console.log('vars',m.peek(0x77),m.peek(0x78),m.peek(0x20C0), JSON.stringify(m.screen()[1]));
}
run([['DOWN',5,25],['UP',30,33],['DOWN',40,41],['EXE',50,52]]);
run([['DOWN',5,25],['EXE',12,14],['UP',20,35]]);
