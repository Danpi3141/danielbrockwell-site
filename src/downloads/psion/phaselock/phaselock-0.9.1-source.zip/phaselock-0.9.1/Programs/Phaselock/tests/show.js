// prints the LCD as pixels at a few moments of a wave:  node tests/show.js <wave 1-9> <frame> [frame...]
const { Rig, loadBuild } = require('./harness.js');
const { makeBot } = require('./bot.js');
const core = loadBuild(); const rig = new Rig(core); const bot = makeBot(core);
const w = parseInt(process.argv[2] || '1', 10) - 1; const at = process.argv.slice(3).map(Number);
rig.setParams({ wave: core.waves[w], stock: 0x0901 });
const out = rig.call({ maxFrames: Math.max(...at) + 1, keys: (f, rg) => bot(rg.stateBytes()), afterFrame: (f) => { if (at.includes(f)) { console.log('--- wave ' + (w + 1) + ' frame ' + f); console.log(rig.m.pixels().map((r) => r.replace(/\./g, ' ').replace(/(.{5})/g, '$1|')).join('\n')); } } });
if (out.result === -1) rig.stop();
