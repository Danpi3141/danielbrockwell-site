// A simple player for the tests: it reads the core's state block and decides which
// keys to hold this frame (bit0 up, bit1 down, bit2 bomb). It dodges what is about to
// reach column 1 and otherwise lines up with the nearest enemy it can shoot.
'use strict';

function makeBot(core, opts) {
  opts = opts || {};
  const o = {};
  for (const [n, v] of Object.entries(core.sym)) if (v.seg === 'state') o[n] = v.value;
  const HORIZON = opts.horizon || 14;

  return function bot(S) {
    const g = (n, i) => S[o[n] + (i || 0)];
    const y = g('S_Y'), spd = Math.max(1, g('S_TUNE'));
    const boss = g('S_FLAGS') & 2;
    const danger = new Array(28).fill(0);
    const mark = (lo, hi, v) => { for (let q = Math.max(0, lo); q <= Math.min(27, hi); q++) danger[q] += v; };
    let target = null;
    if (!boss) {
      for (let i = 0; i < 8; i++) {
        const c = g('S_EN', 4 * i + 2); if (c === 0xff) continue;
        const fl = g('S_EN', 4 * i), n = g('S_EN', 4 * i + 1), cls = fl & 1;
        const p = g('S_PHA', cls), sp = g('S_SPD', cls);
        const dist = 5 * c - p - 10;                     // pixels until it can touch the ship
        const t = sp ? dist * 4 / sp : 1e9;
        if (t < HORIZON) mark(8 * n - 3, 8 * n + 5, t < 5 ? 100 : 10);
        if (opts.hunt !== false && !(fl & 0x80) && c >= 2 && (target === null || c < target.c)) target = { c, n };
      }
    } else if (g('S_BOSS', 1) !== 0xff) {
      const bl = g('S_BOSS'), sl = (y + 2) >> 3;
      target = { c: g('S_BOSS', 1), n: sl >= bl && sl <= bl + 1 ? sl : (sl < bl ? bl : bl + 1) };
    }
    for (let i = 0; i < 3; i++) {
      const c = g('S_ES', 2 * i + 1); if (c === 0xff) continue;
      const n = g('S_ES', 2 * i), t = (c - 1) * (g('S_FLAGS') & 0x12 ? 1 : 2);
      const tall = true;                            // shots count over five rows
      if (t < HORIZON) mark(tall ? 8 * n - 3 : 8 * n - 1, tall ? 8 * n + 5 : 8 * n + 3, t < 5 ? 100 : 10);
    }
    // pick where to be: safe, reachable, and in the target's lane if possible
    let best = null, bestCost = 1e9;
    for (let q = 0; q <= 27; q++) {
      if (danger[q]) continue;
      let cost = Math.abs(q - y);
      if (target) {
        const lane = (q + 2) >> 3;
        cost += lane === target.n ? 0 : 40 + 8 * Math.abs(lane - target.n);
      } else {
        cost += opts.hunt === false ? 0 : Math.abs(q - 13) / 4;
      }
      if (cost < bestCost) { bestCost = cost; best = q; }
    }
    let keys = 0;
    if (best !== null) {
      if (best < y) keys = 1; else if (best > y && best - y >= Math.min(spd, 27 - y)) keys = 2;
    }
    if (opts.bombs !== false && danger[y] >= 100 && (best === null || Math.abs(best - y) > 2 * spd) && g('S_BOMBS') > 0 && g('S_INV') === 0) keys |= 4;
    return keys;
  };
}

module.exports = { makeBot };
