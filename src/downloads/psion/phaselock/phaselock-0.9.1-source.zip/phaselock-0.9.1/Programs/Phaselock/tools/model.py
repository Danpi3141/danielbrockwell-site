"""Reference model of the Phaselock core.

It works on a copy of the core's state block and reproduces one frame of the core:
logic, the UDG stage's bookkeeping, the composed frame and the sound queue. The tests
run the real core in the emulator and compare every byte of state after every frame
(tools/check.py). The strip builders give the expected UDG patterns for every phase
and ship position.
"""
from sprites import SHIP_ROWS, EXPLOSIONS, cols_to_rows

NEN, NPS, NES, NEX, NST = 8, 3, 3, 3, 6
FF = 0xFF


# ---------------------------------------------------------------- strip builders
def class_strip(sprite5, phase):
    """10-column strip: 5-phase blank columns, the sprite, phase blank columns."""
    s = [0] * (5 - phase) + list(sprite5) + [0] * phase
    return s[:5], s[5:]


def ship_strip(y):
    """Upper and lower UDG (8 rows each) for the ship at pixel row y."""
    s = [0] * 16
    for i, r in enumerate(SHIP_ROWS):
        s[(y & 7) + i] = r
    return s[:8], s[8:]


def star_cols(phase):
    c = [0] * 5
    c[4 - phase] = 0x20
    return c


# ---------------------------------------------------------------- collision tests
def shot_hits_enemy(s, c, phase):
    return s == c or (s == c - 1 and phase > 0)


def ship_hits_enemy(y, c, n, phase):
    return (c == 1 or (c == 2 and phase > 0)) and y <= 8 * n + 5 and y + 4 >= 8 * n + 1


def ship_hits_shot(y, cell, n):
    # a shot counts over the five rows of its '+' glyph
    return cell == 1 and y <= 8 * n + 5 and y + 4 >= 8 * n + 1


def value(flags):
    if flags & 0x80:
        return 0
    if flags & 0x40:
        return 5
    if flags & 0x20:
        return 3
    if flags & 0x10:
        return 2
    return 1


class Model:
    def __init__(self, sym, mem):
        """sym: state symbol -> offset. mem(addr) reads a byte of Organiser memory
        (wave script and sprite library)."""
        self.S = sym
        self.mem = mem

    # -------- state access
    def g(self, n, i=0):
        return self.st[self.S[n] + i]

    def s(self, n, v, i=0):
        self.st[self.S[n] + i] = v & 255

    def w(self, n):
        return self.g(n) << 8 | self.g(n, 1)

    def sw(self, n, v):
        self.s(n, v >> 8)
        self.s(n, v, 1)

    def en(self, i, f):
        return self.st[self.S['S_EN'] + 4 * i + f]

    def sen(self, i, f, v):
        self.st[self.S['S_EN'] + 4 * i + f] = v & 255

    def rnd(self):
        a = self.g('S_SEED')
        c = a & 1
        a >>= 1
        if c:
            a ^= 0xB8
        self.s('S_SEED', a)
        return a

    def sndreq(self, a, b):
        if a >= self.g('S_SND'):
            self.s('S_SND', a)
            self.s('S_SNDT', b)

    def addscore(self, d):
        v = (self.w('S_SCORE') + d) & 0xFFFF
        if v & 0x8000:
            v = 0x7FFF
        self.sw('S_SCORE', v)

    def clsph(self, i):
        return self.g('S_PHA', self.en(i, 0) & 1)

    def shiplane(self):
        return ((self.g('S_Y') + 2) & 255) >> 3

    # -------- set-up (MODE = 0), given the parameter words and the seed source
    def init(self, size, score, stock, tune, wave, lib, fram_low):
        self.st = bytearray(size)
        S = self.S
        for i in range(NEN):
            self.sen(i, 2, FF)
        for n, k, step in (('S_PS', NPS, 2), ('S_ES', NES, 2), ('S_EX', NEX, 3)):
            for i in range(k):
                self.s(n, FF, i * step + 1)
        self.sw('S_SCORE', score)
        self.s('S_LIVES', stock >> 8)
        self.s('S_BOMBS', stock)
        self.sw('S_TUNE', tune)
        self.s('S_FIRE', tune)
        m = self.mem
        self.s('S_SPD', m(wave + 2), 0)
        self.s('S_SPD', m(wave + 3), 1)
        self.s('S_SPD', m(wave + 4), 2)
        self.s('S_FLAGS', m(wave + 5) & 0x32)
        self.s('S_BOSS', m(wave + 1), 2)
        self.sw('S_SPRA', (m(wave) * 10 + lib) & 0xFFFF)
        self.sw('S_SPRB', (m(wave + 1) * 10 + lib) & 0xFFFF)
        self.sw('S_SCRP', wave + 6)
        self.s('S_WAIT', m(wave + 6))
        if m(wave + 6) == 0:
            self.s('S_FLAGS', self.g('S_FLAGS') | 1)
        self.s('S_Y', 12)
        self.s('S_CHAIN', 1)
        self.s('S_SEED', fram_low | 1)
        for i in range(NST):
            self.s('S_STAR', self.rnd() & 3, 2 * i)
            a = self.rnd() & 31
            if a >= 20:
                a -= 20
            self.s('S_STAR', a, 2 * i + 1)
        if self.g('S_FLAGS') & 2:
            self.s('S_BOSS', 1, 0)
            self.s('S_BOSS', 20, 1)
        return self.st

    # -------- one frame: fr_logic up to fr_sound
    def step(self, st):
        self.st = st
        self.s('S_TICK', self.g('S_TICK') + 1)
        self.phases()
        self.spawn()
        self.moves()
        self.behave()
        self.bomb()
        self.colshots()
        self.colship()
        if self.g('S_INV'):
            self.s('S_INV', self.g('S_INV') - 1)
        self.wavend()
        self.udgs()
        self.compose()
        base = self.S['S_FB']
        pv = self.S['S_PV']
        st[pv:pv + 80] = st[base:base + 80]
        return st

    def phases(self):
        if self.g('S_TICK') & 7 == 0:
            self.s('S_DIRTY', self.g('S_DIRTY') | 6)
        for cls, bit in ((0, 2), (1, 4), (2, 8)):
            acc = (self.g('S_ACC', cls) + self.g('S_SPD', cls)) & 255
            while acc >= 4:
                acc -= 4
                self.s('S_DIRTY', self.g('S_DIRTY') | bit)
                p = (self.g('S_PHA', cls) + 1) & 255
                if p == 5:
                    self.wrap(cls)
                    p = 0
                self.s('S_PHA', p, cls)
            self.s('S_ACC', acc, cls)

    def wrap(self, cls):
        if cls == 2:
            for i in range(NST):
                c = (self.g('S_STAR', 2 * i + 1) - 1) & 255
                if c & 0x80:
                    c = 19
                    self.s('S_STAR', c, 2 * i + 1)
                    self.s('S_STAR', self.rnd() & 3, 2 * i)
                else:
                    self.s('S_STAR', c, 2 * i + 1)
            return
        for i in range(NEN):
            if self.en(i, 2) == FF or (self.en(i, 0) & 1) != cls:
                continue
            c = (self.en(i, 2) - 1) & 255
            self.sen(i, 2, c)
            if c & 0x80 and not self.en(i, 0) & 0x80:
                self.reenter(i)

    def reenter(self, i):
        """An enemy that got past the ship comes back in on the right as a weaving shooter."""
        self.sen(i, 0, self.en(i, 0) | 0x30)
        self.s('S_CHAIN', 1)
        for _ in range(4):
            lane = self.en(i, 1)
            busy = any(self.en(j, 2) != FF and self.en(j, 2) >= 19 and self.en(j, 1) == lane for j in range(NEN))
            if not busy:
                self.sen(i, 2, 20)
                return
            self.sen(i, 1, (lane + 1) & 3)

    def spawn(self):
        if self.g('S_FLAGS') & 1:
            return
        w = self.g('S_WAIT')
        if w:
            w -= 1
            self.s('S_WAIT', w)
            if w:
                return
        ptr = self.w('S_SCRP')
        info = self.mem(ptr + 1)
        cls = 1 if info & 4 else 0
        home = 21 if self.g('S_PHA', cls) else 20
        lane = info & 3
        free = None
        for i in range(NEN):
            c = self.en(i, 2)
            if c == FF:
                if free is None:
                    free = i
            elif self.en(i, 1) == lane and c >= home - 1:
                return
        if free is None:
            return
        flags = ((info & 0xF0) + ((info >> 2) & 1)) & 255
        self.sen(free, 0, flags)
        self.sen(free, 1, lane)
        self.sen(free, 2, home)
        aux = (self.rnd() & 0xF8) | 1
        if flags & 0x40:
            aux |= 3
        self.sen(free, 3, aux)
        if info & 8:
            self.sndreq(2, 1)
        ptr += 2
        self.sw('S_SCRP', ptr)
        w = self.mem(ptr)
        self.s('S_WAIT', w)
        if w == 0:
            self.s('S_FLAGS', self.g('S_FLAGS') | 1)

    def moves(self):
        keys = self.g('S_KEYS')
        y = self.g('S_Y')
        if keys & 1:
            y -= self.g('S_TUNE')
            if y < 0:
                y = 0
        if keys & 2:
            y = (y + self.g('S_TUNE')) & 255
            if y > 27:
                y = 27
        if y != self.g('S_Y'):
            self.s('S_Y', y)
            self.s('S_DIRTY', self.g('S_DIRTY') | 1)
        for i in range(NPS):
            c = self.g('S_PS', 2 * i + 1)
            if c != FF:
                c += 1
                if c == 20:
                    c = FF
                self.s('S_PS', c, 2 * i + 1)
        f = self.g('S_FIRE')
        fire = True
        if f:
            f -= 1
            self.s('S_FIRE', f)
            fire = f == 0
        if fire:
            for i in range(NPS):
                if self.g('S_PS', 2 * i + 1) == FF:
                    self.s('S_PS', self.shiplane(), 2 * i)
                    self.s('S_PS', 2, 2 * i + 1)
                    self.s('S_FIRE', self.g('S_TUNE', 1))
                    self.sndreq(1, 1)
                    break
        if self.g('S_FLAGS') & 0x12 or self.g('S_TICK') & 1:
            for i in range(NES):
                c = self.g('S_ES', 2 * i + 1)
                if c != FF:
                    self.s('S_ES', c - 1, 2 * i + 1)
        for i in range(NEX):
            if self.g('S_EX', 3 * i + 1) != FF:
                left = (self.g('S_EX', 3 * i + 2) - 1) & 255
                self.s('S_EX', left, 3 * i + 2)
                if left == 0:
                    self.s('S_EX', FF, 3 * i + 1)

    def eshot(self, lane, cell):
        for i in range(NES):
            if self.g('S_ES', 2 * i + 1) == FF:
                self.s('S_ES', lane, 2 * i)
                self.s('S_ES', cell, 2 * i + 1)
                return

    def behave(self):
        if self.g('S_FLAGS') & 2:
            return self.boss()
        tick = self.g('S_TICK')
        for i in range(NEN):
            if self.en(i, 2) == FF:
                continue
            t1 = ((self.en(i, 3) >> 3) + tick) & 255
            flags = self.en(i, 0)
            if flags & 0x10 and t1 & 15 == 0:
                target = self.shiplane()
                lane = self.en(i, 1)
                if target != lane:
                    new = (lane + 1 if target > lane else lane - 1) & 255
                    mine = self.en(i, 2)
                    blocked = False
                    for j in range(NEN):
                        if j == i or self.en(j, 2) == FF or self.en(j, 1) != new:
                            continue
                        if (self.en(j, 2) - mine + 1) & 255 <= 2:
                            blocked = True
                            break
                    if not blocked:
                        self.sen(i, 1, new)
            if flags & 0x20 and t1 & (15 if self.g('S_FLAGS') & 0x20 else 31) == 0:
                c = self.en(i, 2)
                if 3 <= c <= 20:
                    self.eshot(self.en(i, 1), c - 2)

    def boss(self):
        col = self.g('S_BOSS', 1)
        if col == FF:
            return
        tick = self.g('S_TICK')
        if col > 16:
            if tick & 3 == 0:
                self.s('S_BOSS', col - 1, 1)
            return
        s = self.shiplane()
        if tick & 7 == 0:
            bl = self.g('S_BOSS')
            if self.g('S_FLAGS') & 8:
                self.s('S_FLAGS', self.g('S_FLAGS') & 0xF7)
                want = 2 if s <= 1 else 0
                if want > bl:
                    self.s('S_BOSS', bl + 1)
                elif want < bl:
                    self.s('S_BOSS', bl - 1)
            elif s < bl:
                self.s('S_BOSS', bl - 1)
            elif (s - bl) & 255 > 1:
                self.s('S_BOSS', bl + 1)
        if tick & 7 == 4 and (self.g('S_BOSS', 2) <= 8 or not tick & 8):
            bl = self.g('S_BOSS')
            a = s
            if a < bl:
                a = bl
            elif a > bl + 1:
                a = bl + 1
            self.eshot(a, (self.g('S_BOSS', 1) - 1) & 255)

    def explode(self, lane, cell, left=6):
        if cell > 19:
            cell = 19
        for i in range(NEX):
            if self.g('S_EX', 3 * i + 1) == FF:
                self.s('S_EX', lane, 3 * i)
                self.s('S_EX', cell, 3 * i + 1)
                self.s('S_EX', left, 3 * i + 2)
                return

    def boom(self, i):
        self.explode(self.en(i, 1), self.en(i, 2))
        self.sen(i, 2, FF)

    def kill(self, i):
        self.addscore(value(self.en(i, 0)) * self.g('S_CHAIN'))
        if self.g('S_CHAIN') < 4:
            self.s('S_CHAIN', self.g('S_CHAIN') + 1)
        self.boom(i)

    def bossdie(self):
        self.s('S_BOSS', 0, 2)
        self.addscore(100)
        a, b = self.g('S_BOSS'), self.g('S_BOSS', 1)
        self.s('S_EX', a, 0)
        self.s('S_EX', b, 1)
        self.s('S_EX', a + 1, 3)
        self.s('S_EX', b, 4)
        b2 = b + 1
        if b2 > 19:
            b2 = 19
        self.s('S_EX', a, 6)
        self.s('S_EX', b2, 7)
        for k in (2, 5, 8):
            self.s('S_EX', 6, k)
        self.s('S_BOSS', FF, 1)
        self.sndreq(4, 5)

    def bomb(self):
        if not self.g('S_KEYS') & 4 or self.g('S_BOMBS') == 0:
            return
        self.s('S_BOMBS', self.g('S_BOMBS') - 1)
        for i in range(NEN):
            if self.en(i, 2) != FF:
                self.addscore(value(self.en(i, 0)))
                self.boom(i)
        for i in range(NES):
            self.s('S_ES', FF, 2 * i + 1)
        if self.g('S_FLAGS') & 2 and self.g('S_BOSS', 1) != FF:
            hp = self.g('S_BOSS', 2)
            if hp > 3:
                self.s('S_BOSS', hp - 3, 2)
            else:
                self.bossdie()
        self.sndreq(4, 5)

    def colshots(self):
        for k in range(NPS):
            s = self.g('S_PS', 2 * k + 1)
            if s == FF:
                continue
            lane = self.g('S_PS', 2 * k)
            if self.g('S_FLAGS') & 2:
                col = self.g('S_BOSS', 1)
                if col == FF or col != s or (lane - self.g('S_BOSS')) & 255 > 1:
                    continue
                self.s('S_PS', FF, 2 * k + 1)
                if col > 16:
                    continue
                self.s('S_FLAGS', self.g('S_FLAGS') | 8)
                hp = (self.g('S_BOSS', 2) - 1) & 255
                self.s('S_BOSS', hp, 2)
                if hp == 0:
                    self.bossdie()
                else:
                    self.explode(lane, (col - 1) & 255, 2)
                    self.sndreq(3, 2)
                continue
            for i in range(NEN):
                c = self.en(i, 2)
                if c == FF or self.en(i, 1) != lane:
                    continue
                if c == s or (((c - 1) & 255) == s and self.clsph(i) != 0):
                    self.s('S_PS', FF, 2 * k + 1)
                    if self.en(i, 0) & 0x80:
                        break
                    aux = (self.en(i, 3) - 1) & 255
                    self.sen(i, 3, aux)
                    if aux & 7 == 0:
                        self.kill(i)
                    self.sndreq(3, 2)
                    break

    def shiphit(self):
        lives = (self.g('S_LIVES') - 1) & 255
        self.s('S_LIVES', lives)
        if lives == 0:
            self.s('S_RES', 1)
        self.s('S_INV', 21)
        self.s('S_CHAIN', 1)
        self.sndreq(5, 3)

    def colship(self):
        if self.g('S_INV'):
            return
        y = self.g('S_Y')
        for i in range(NEN):
            c = self.en(i, 2)
            if c == 1 or (c == 2 and self.clsph(i) != 0):
                a = (self.en(i, 1) * 8 + 5) & 255
                if a < y or y + 4 < a - 4:
                    continue
                if not self.en(i, 0) & 0x80:
                    self.boom(i)
                return self.shiphit()
        for i in range(NES):
            if self.g('S_ES', 2 * i + 1) == 1:
                a = (self.g('S_ES', 2 * i) * 8 + 5) & 255
                if a < y or y + 4 < a - 4:
                    continue
                self.s('S_ES', FF, 2 * i + 1)
                return self.shiphit()

    def wavend(self):
        if self.g('S_RES') != FF:
            return
        for n, k, step in (('S_EX', NEX, 3), ('S_ES', NES, 2)):
            for i in range(k):
                if self.g(n, i * step + 1) != FF:
                    return
        fl = self.g('S_FLAGS')
        if fl & 2:
            if self.g('S_BOSS', 1) != FF:
                return
        else:
            if not fl & 1:
                return
            for i in range(NEN):
                if self.en(i, 2) != FF:
                    return
        self.addscore(self.g('S_LIVES') * 10)
        self.s('S_RES', 0)

    def udgs(self):
        self.s('S_DIRTY', 0)
        m = 0
        if self.g('S_EX', 1) != FF:
            m = self.g('S_EX', 2)
        for k in (1, 2):
            if self.g('S_EX', 3 * k + 1) != FF and not m >= self.g('S_EX', 3 * k + 2):
                m = self.g('S_EX', 3 * k + 2)
        if m:
            f = ((6 - m) & 255) >> 1
            if f != self.g('S_EXF'):
                self.s('S_EXF', f)

    def compose(self):
        fb = [32] * 80

        def put(lane, cell, ch):
            fb[(lane * 20 + cell) & 255] = ch
        for i in range(NST):
            put(self.g('S_STAR', 2 * i), self.g('S_STAR', 2 * i + 1), 6)
        if self.g('S_FLAGS') & 2:
            col = self.g('S_BOSS', 1)
            if col != FF:
                ch, lane = 2, self.g('S_BOSS')
                for _ in range(2):
                    if col <= 19:
                        put(lane, col, ch)
                    if col + 1 <= 19:
                        put(lane, col + 1, ch + 1)
                    lane += 1
                    ch += 2
        else:
            for i in range(NEN):
                c = self.en(i, 2)
                if c == FF:
                    continue
                ch = (self.en(i, 0) & 1) * 2 + 2
                if self.clsph(i) != 0 and c != 0 and c - 1 <= 19:
                    put(self.en(i, 1), c - 1, ch)
                if c <= 19:
                    put(self.en(i, 1), c, ch + 1)
        for n, k, step, ch in (('S_PS', NPS, 2, 45), ('S_ES', NES, 2, 43), ('S_EX', NEX, 3, 7)):
            for i in range(k):
                if self.g(n, i * step + 1) != FF:
                    put(self.g(n, i * step), self.g(n, i * step + 1), ch)
        if not self.g('S_INV') & 1:
            y = self.g('S_Y')
            put(y >> 3, 1, 0)
            if y & 7 >= 4:
                put((y >> 3) + 1, 1, 1)
        base = self.S['S_FB']
        self.st[base:base + 80] = bytes(fb)

    # -------- sound stage
    def sound(self, st):
        self.st = st
        t = self.g('S_SNDT')
        if not t:
            return None
        snd = self.g('S_SND')
        if snd == 3 and t == 1:
            tone = (500, 10)
        else:
            tone = {1: (100, 4), 2: (60, 8), 3: (300, 10), 4: (800, 10), 5: (1200, 10)}[snd]
        self.s('S_SNDT', t - 1)
        if t - 1 == 0:
            self.s('S_SND', 0)
        return tone

    # -------- what the eight UDGs must hold after the UDG stage (8 rows each, None = not defined)
    def expected_udgs(self, st):
        self.st = st
        out = [None] * 8
        out[0], out[1] = ship_strip(self.g('S_Y'))
        f = 5 if self.g('S_TICK') & 8 else 0
        if self.g('S_FLAGS') & 2:
            a = self.w('S_SPRA')
            for k in range(4):
                out[2 + k] = cols_to_rows([self.mem(a + 5 * k + i) for i in range(5)])
        else:
            for cls, name, slot in ((0, 'S_SPRA', 2), (1, 'S_SPRB', 4)):
                a = self.w(name) + f
                left, right = class_strip([self.mem(a + i) for i in range(5)], self.g('S_PHA', cls))
                out[slot], out[slot + 1] = cols_to_rows(left), cols_to_rows(right)
        out[6] = cols_to_rows(star_cols(self.g('S_PHA', 2)))
        if self.g('S_EXF') != FF:
            out[7] = EXPLOSIONS[self.g('S_EXF')]
        return out


if __name__ == '__main__':
    # the two worked examples from the spec
    from sprites import enemy_frames, ENEMIES
    drone = enemy_frames(ENEMIES[0][1])[0]
    assert class_strip(drone, 2) == ([0, 0, 0, 0x74, 0xD8], [0xF0, 0xD8, 0x74, 0, 0])
    assert ship_strip(13) == ([0, 0, 0, 0, 0, 16, 28, 31], [28, 16, 0, 0, 0, 0, 0, 0])
    assert star_cols(0) == [0, 0, 0, 0, 0x20]
    print('worked examples from the spec: OK')
