; Milestone 1 smoke test: define UDG 2 from a 5-column pattern whose address is in D
        xgdx
        ldaa #1
        ldab #2
        os DP$UDG
        ldx #$1234
        rts
