// How hard is the game? Plays full runs on three lives with different kinds of player
// and reports how far each gets.   node tests/difficulty.js [runs]
//   camper   never touches a key
//   dodger   stays in one lane, steps aside only when something is about to hit it
//   bot      the test bot: dodges and lines up with the nearest enemy
'use strict';
const { Rig, loadBuild, rng } = require('./harness.js');
const { makeBot } = require('./bot.js');
const core = loadBuild(); const rig = new Rig(core);
const runs = parseInt(process.argv[2] || '5', 10);
const players = (process.argv[3] || 'camper,dodger,bot').split(',');

for (const who of players) {
  const reached = [];
  let beat = 0, frames = 0, score = 0;
  for (let run = 0; run < runs; run++) {
    const bot = makeBot(core, { horizon: 10 + (run % 6), hunt: who === 'bot' });
    const r = rng(run * 7 + 1);
    let lives = 3, sc = 0, w = 0, stuck = false;
    for (; w < 9 && lives > 0; w++) {
      rig.setParams({ wave: core.waves[w], stock: (lives << 8) | 1, score: sc });
      const out = rig.call({ maxFrames: 6000, keys: (f, rg) => (who === 'camper' ? 0 : (r() < 0.97 ? bot(rg.stateBytes()) : 0)) });
      frames += out.frames;
      if (out.result === -1) { rig.stop(); stuck = true; break; }
      lives = out.stock >> 8; sc = out.score;
      if (out.result !== 0) break;
    }
    if (lives > 0 && w === 9) beat++;
    reached.push(stuck ? (w + 1) + '*' : lives > 0 ? 'won' : String(w + 1));
    score += sc;
  }
  console.log(`${who.padEnd(7)} lost on wave: ${reached.join(' ')}   (beat the boss ${beat}/${runs}, average ${Math.round(score / runs)}0 points, ${(frames / runs / 1200).toFixed(1)} min)   * = wave still running after 5 minutes`);
}
