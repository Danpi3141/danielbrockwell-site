import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..', 'tools'))
from asm6303 import assemble
code = assemble(open(os.path.join(os.path.dirname(__file__), 'smoke.asm')).read()).out
L = ['M1:', 'LOCAL m%(8),u%(4),r%,i%,a%']
L.append('a%=ADDR(m%())')
for i, b in enumerate(code):
    L.append('POKEB a%%+%d,%d' % (i, b))
for i, b in enumerate([0x74, 0xD8, 0xF0, 0xD8, 0x74]):
    L.append('POKEB ADDR(u%%())+%d,%d' % (i, b))
L += ['CLS', 'PRINT CHR$(2);" ";CHR$(2);" ";CHR$(2)',
      'r%=USR(a%,ADDR(u%()))',
      'AT 1,2 :PRINT "R=";r%;" M=";a%',
      'PRINT "U=";ADDR(u%());" S=";PEEKW($2065)',
      'GET',
      'POKEB ADDR(u%()),255',
      'r%=USR(a%,ADDR(u%()))',
      'AT 1,4 :PRINT "AGAIN ";r%;',
      'GET']
open(os.path.join(os.path.dirname(__file__), 'M1.opl'), 'w', newline='\n').write('\n'.join(L) + '\n')
