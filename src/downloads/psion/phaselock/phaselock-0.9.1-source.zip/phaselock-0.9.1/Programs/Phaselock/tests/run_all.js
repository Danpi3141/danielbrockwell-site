// Runs every Phaselock test.   node tests/run_all.js [--quick]
'use strict';
const { spawnSync } = require('child_process');
const path = require('path');
const quick = process.argv.includes('--quick');
const jobs = [
  ['reference model: worked examples from the spec', 'python', ['tools/model.py']],
  ['model vs core, LZ64 ROM 4.6a', 'node', ['tests/t_model.js', quick ? '1' : '4']],
  ['model vs core, LZ ROM 4.6', 'node', ['tests/t_model.js', quick ? '1' : '2', '46-lz.rom']],
  ['model vs core with interrupts landing inside the logic', 'node', ['tests/t_model.js', '1'], { TDEL: '9000' }],
  ['keyboard and exit paths, LZ64', 'node', ['tests/t_keys.js']],
  ['keyboard and exit paths, LZ', 'node', ['tests/t_keys.js', '46-lz.rom']],
  ['alarms', 'node', ['tests/t_alarm.js']],
  ['bounded writes', 'node', ['tests/t_safety.js']],
  ['UDG read-back', 'node', ['tests/t_udg.js']],
  ['timing and OVERRUN', 'node', ['tests/t_timing.js', quick ? '1' : '10']],
  ['Organiser translator vs PC build', 'node', ['tests/t_romtran.js']],
  ['end to end, LZ64', 'node', ['tests/t_game.js']],
  ['end to end, LZ', 'node', ['tests/t_game.js', '46-lz.rom']],
  ['end to end, LZ64, Jape-style interrupts', 'node', ['tests/t_game.js'], { JAPE_IRQ: '1' }],
];
let failed = 0;
for (const [name, cmd, args, env] of jobs) {
  const t = Date.now();
  const r = spawnSync(cmd, args, { cwd: path.resolve(__dirname, '..'), encoding: 'utf8', env: Object.assign({}, process.env, env || {}), maxBuffer: 1 << 28 });
  const out = (r.stdout || '').trim().split('\n');
  const last = out[out.length - 1];
  if (r.status === 0) console.log('PASS  %s  (%ss)\n      %s', name, ((Date.now() - t) / 1000).toFixed(0), last);
  else { failed++; console.log('FAIL  %s\n%s\n%s', name, out.slice(-15).join('\n'), (r.stderr || '').split('\n').slice(0, 12).join('\n')); }
}
console.log(failed ? failed + ' test group(s) FAILED' : 'ALL ' + jobs.length + ' TEST GROUPS PASSED');
process.exit(failed ? 1 : 0);
