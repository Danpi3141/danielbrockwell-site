"""Sprite art for Phaselock. Enemy sprites are 5 columns x 8 rows, two animation frames.
The library the core receives holds each as 5 column bytes (top pixel = bit 7), frame 0
then frame 1, 10 bytes per sprite; the boss follows as four 5-column quarters."""

ENEMIES = [
    ('DRONE', """
.###.   .###.
#####   #####
#.#.#   #.#.#
#####   #####
.#.#.   #...#
#...#   .#.#.
.....   .....
.....   .....
"""),
    ('DART', """
.....   .....
..###   ..##.
.##..   .##.#
#####   ####.
.##..   .##.#
..###   ..##.
.....   .....
.....   .....
"""),
    ('SAUCER', """
.....   .....
.###.   .###.
#####   #####
#.#.#   .#.#.
#####   #####
.###.   .###.
.....   .....
.....   .....
"""),
    ('CRAB', """
#...#   .#.#.
.###.   .###.
##.##   ##.##
#####   #####
#.#.#   #.#.#
.#.#.   #...#
.....   .....
.....   .....
"""),
    ('HEAVY', """
#####   #####
#...#   #...#
#.#.#   #.#.#
#.#.#   #.#.#
#...#   #...#
#####   #####
.#.#.   #...#
.....   .....
"""),
    ('MINE', """
..#..   ..#..
#.#.#   #.#.#
.###.   .###.
#####   ##.##
.###.   .###.
#.#.#   #.#.#
..#..   ..#..
.....   .....
"""),
]

BOSS = """
....#####.
..########
.####.####
####...###
##########
.#########
..#######.
...####...
...####...
..#######.
.#########
##########
####...###
.####.####
..########
....#####.
"""

SHIP_ROWS = [16, 28, 31, 28, 16]
EXPLOSIONS = [[0, 0, 4, 14, 4, 0, 0, 0], [0, 21, 14, 27, 14, 21, 0, 0], [17, 0, 10, 0, 10, 0, 17, 0]]


def cols(rows):
    """8 strings of 5 chars -> 5 column bytes."""
    out = []
    for c in range(5):
        v = 0
        for r in range(8):
            if rows[r][c] == '#':
                v |= 0x80 >> r
        out.append(v)
    return out


def cols_to_rows(c5):
    rows = [0] * 8
    for c in range(5):
        for r in range(8):
            if c5[c] & (0x80 >> r):
                rows[r] |= 0x10 >> c
    return rows


def enemy_frames(art):
    lines = [ln.split() for ln in art.strip().split('\n')]
    assert len(lines) == 8 and all(len(l) == 2 and len(l[0]) == 5 and len(l[1]) == 5 for l in lines), art
    return cols([l[0] for l in lines]), cols([l[1] for l in lines])


def boss_quarters():
    lines = BOSS.strip().split('\n')
    assert len(lines) == 16 and all(len(l) == 10 for l in lines)
    top, bot = lines[:8], lines[8:]
    return [cols([l[:5] for l in top]), cols([l[5:] for l in top]),
            cols([l[:5] for l in bot]), cols([l[5:] for l in bot])]


BOSS_INDEX = len(ENEMIES)


def library():
    out = []
    for _, art in ENEMIES:
        a, b = enemy_frames(art)
        out += a + b
    for q in boss_quarters():
        out += q
    return out


SPRITE = {name: i for i, (name, _) in enumerate(ENEMIES)}

if __name__ == '__main__':
    assert enemy_frames(ENEMIES[0][1])[0] == [0x74, 0xD8, 0xF0, 0xD8, 0x74]
    assert enemy_frames(ENEMIES[1][1])[0] == [0x10, 0x38, 0x7C, 0x54, 0x54]
    lib = library()
    print(len(lib), 'bytes:', bytes(lib).hex().upper())
