const os = require('os'), path = require('path');
const { Rig, loadBuild, check, rng } = require('./harness.js');
const { makeBot } = require('./bot.js');
const core = loadBuild(); const rig = new Rig(core); const bot = makeBot(core);
const file = path.join(os.tmpdir(), 'pl_boss.jsonl');
for (const policy of ['bot', 'random', 'still']) for (let seed = 1; seed <= 3; seed++) {
  const r = rng(seed); let k = 0, hold = 0;
  rig.startTrace(); rig.setParams({ wave: core.waves[8], stock: 0x0301 });
  const out = rig.call({ maxFrames: 6000, keys: (f, rg) => policy === 'bot' ? bot(rg.stateBytes()) : policy === 'still' ? 0 : ((hold-- <= 0 ? (k = [0, 1, 2, 0][Math.floor(r() * 4)], hold = Math.floor(r() * 14)) : 0), k) });
  if (out.result === -1) rig.stop();
  rig.saveTrace(file); check(file);
  console.log(policy, seed, 'result', out.result, 'frames', out.frames, 'score', out.score, 'lives', out.stock >> 8);
}
