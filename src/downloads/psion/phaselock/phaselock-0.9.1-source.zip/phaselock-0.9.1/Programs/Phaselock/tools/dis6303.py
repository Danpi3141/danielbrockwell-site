#!/usr/bin/env python3
"""Tiny HD6303 disassembler (for reading ROM routines and checking the assembler)."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from asm6303 import INH, BRANCH, MEM, BITIMM, REG

TAB = {}
for n, o in INH.items(): TAB[o] = (n, 'inh')
for n, o in BRANCH.items(): TAB.setdefault(o, (n, 'rel'))
for n, o in MEM.items():
    TAB[o] = (n, 'idx'); TAB[o + 0x10] = (n, 'ext')
for n, o in BITIMM.items():
    TAB[0x60 + o] = (n, 'bidx'); TAB[0x70 + o] = (n, 'bdir')
for n, (o, imm) in REG.items():
    if imm == 1: TAB[o] = (n, 'imm8')
    elif imm == 2: TAB[o] = (n, 'imm16')
    if n != 'jsr' or True:
        TAB.setdefault(o + 0x10, (n, 'dir'))
    TAB[o + 0x20] = (n, 'idx'); TAB[o + 0x30] = (n, 'ext')
TAB[0x8D] = ('bsr', 'rel'); TAB[0x9D] = ('jsr', 'dir')

def dis(data, addr, count, org):
    out = []
    i = addr - org
    for _ in range(count):
        if i >= len(data): break
        op = data[i]; a = org + i
        if op not in TAB:
            out.append('%04X  %02X        ???' % (a, op)); i += 1; continue
        n, mode = TAB[op]
        if mode == 'inh': ln, txt = 1, n
        elif mode == 'rel':
            off = data[i + 1]; off -= 256 if off > 127 else 0
            ln, txt = 2, '%s $%04X' % (n, a + 2 + off)
        elif mode == 'imm8': ln, txt = 2, '%s #$%02X' % (n, data[i + 1])
        elif mode == 'imm16': ln, txt = 3, '%s #$%04X' % (n, data[i + 1] * 256 + data[i + 2])
        elif mode == 'dir': ln, txt = 2, '%s $%02X' % (n, data[i + 1])
        elif mode == 'idx': ln, txt = 2, '%s $%02X,x' % (n, data[i + 1])
        elif mode == 'ext': ln, txt = 3, '%s $%04X' % (n, data[i + 1] * 256 + data[i + 2])
        elif mode == 'bidx': ln, txt = 3, '%s #$%02X,$%02X,x' % (n, data[i + 1], data[i + 2])
        elif mode == 'bdir': ln, txt = 3, '%s #$%02X,$%02X' % (n, data[i + 1], data[i + 2])
        if n == 'swi': ln, txt = 2, 'os %d' % data[i + 1]
        out.append('%04X  %-8s  %s' % (a, data[i:i + ln].hex().upper(), txt))
        i += ln
    return out

if __name__ == '__main__':
    rom = open(sys.argv[1], 'rb').read()
    addr = int(sys.argv[2], 16); n = int(sys.argv[3]) if len(sys.argv) > 3 else 30
    bank = int(sys.argv[4]) if len(sys.argv) > 4 else 0
    if addr < 0xC000 and bank:
        data = rom[0x8000 + (bank - 1) * 0x4000:][:0x4000]; org = 0x8000
    else:
        data = rom[:0x8000]; org = 0x8000
    print('\n'.join(dis(data, addr, n, org)))
