// An alarm rings in the middle of a wave (25 Nov 2026, version 0.9.1). The OS rings it inside its keyboard interrupt for
// as long as 59 seconds: the frame counter stands still, so the stall check does not see it, and the screen that comes
// back is the OS's own, without the ship. The game must pause (the status card), and go on from there with EXE. And a
// minute that begins without one must not pause it.
//   node tests/t_alarm.js [rom ...]
'use strict';
const path = require('path');
const { Machine } = require('../tools/emu.js');
const ROOT = path.resolve(__dirname, '..');
const PACK = process.env.OLD || path.join(ROOT, 'PHASE.opk');
let fails = 0;
const ok = (c, s) => { if (!c) fails++; console.log((c ? 'ok   ' : 'FAIL ') + s); };
const ringing = (m) => /ALARM/.test(m.screenText());

for (const rom of process.argv.slice(2).length ? process.argv.slice(2) : ['46a-lz64.rom', '42-lz.rom']) {
  let s = 99; const rnd = (n) => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s % n; };
  const m = new Machine({ rom, ram: /64/.test(rom) ? 64 : 32 });
  m.boot();
  m.press('A', 3, 12); m.runSeconds(1); for (let i = 0; i < 3; i++) { m.press('EXE', 3, 12); m.runSeconds(0.5); }
  for (let i = 0; i < 6; i++) m.press('ON', 3, 10);
  m.runSeconds(1);
  const calm = () => { m.write(0x22F9, [0, 0, 0, 0, 0, 0]); };
  calm();
  m.insertPack(PACK, 0);
  m.runProc('PHASE', 'B');
  for (let i = 0; i < 40 && !/Play/.test(m.screenText()); i++) m.runSeconds(0.5);
  const text = () => m.screenText();
  // into a wave, whatever the screen says
  const wave = () => {
    for (let i = 0; i < 60; i++) {
      const t = text();
      if (/Play +Scores/.test(t)) { m.press('P', 3, 6); m.runSeconds(1.5); }
      else if (/EXE=GO/.test(t)) { m.press('EXE', 3, 4); m.runSeconds(0.4); if (!/EXE=GO/.test(text())) return true; }
      else if (/NAME|GAME OVER|SCORE|PILOT/i.test(t)) { m.press('EXE', 3, 6); m.runSeconds(1); }
      else return true;
    }
    return false;
  };
  const card = () => /PAUSED - WAVE/.test(text());
  const inWave = () => !/PAUSED|EXE=GO|GAME OVER|Play|NAME|SCORE|PILOT/.test(text());
  let done = 0, paused = 0, resumed = 0, none = 0, falsePause = 0; const kinds = {};
  for (let i = 0; i < 30; i++) {
    calm(); m.write(0x20C5, [126, 10, 27, 23, 59, 5]);       // (only the seconds are changed in a wave)
    m.runTicks(30);                                        // (the minute poked: that pauses)
    if (!wave()) { ok(false, rom + ': cannot get into a wave: ' + text()); break; }
    if (i % 2 === 0) {                                     // an alarm
      m.runTicks(5 + rnd(30));
      if (!inWave()) continue;
      m.write(0x22F9, [89, 0, 0, 0, 0, 5]); m.poke(0x20CA, 59);
      for (let k = 0; k < 60 && !ringing(m); k++) m.runTicks(1);
      if (!ringing(m)) continue;
      const how = ['left to ring', 'dismissed', 'dismissed at once'][(i / 2) % 3];
      if (how === 'left to ring') for (let k = 0; k < 80 && ringing(m); k++) m.runSeconds(1);
      else { if (how === 'dismissed') m.runSeconds(2 + rnd(3)); for (let k = 0; k < 40 && ringing(m); k++) { m.press('ON', 2, 2); } }
      m.runSeconds(1.5);
      done++; kinds[how] = (kinds[how] || 0) + 1;
      if (card()) { paused++; m.runSeconds(1); m.press('EXE', 3, 4); m.runSeconds(0.5); if (!/PAUSED/.test(text())) resumed++; } else console.log(`     ${how}: ${text().replace(/\n/g, '|')}`);
    } else {                                                // a new minute, no alarm
      m.poke(0x20CA, 58); m.runTicks(rnd(20));
      let seen = 0;
      for (let k = 0; k < 20 && inWave(); k++) { m.runTicks(4); if (m.peek(0x20C9) === 0 && m.peek(0x20CA) >= 2) { seen = 1; break; } if (card()) break; }
      if (card()) falsePause++; else if (seen) none++;
    }
  }
  ok(done >= 8 && paused === done && resumed === done, `${rom}: ${done} alarms in a wave (${Object.entries(kinds).map(([k, v]) => v + ' ' + k).join(', ')}): paused ${paused}, gone on with EXE ${resumed}`);
  ok(none >= 8 && !falsePause, `${rom}: ${none} new minutes with no alarm: ${falsePause} pauses`);
}
console.log(fails ? fails + ' FAILED' : 'PASS: t_alarm');
process.exit(fails ? 1 : 0);
