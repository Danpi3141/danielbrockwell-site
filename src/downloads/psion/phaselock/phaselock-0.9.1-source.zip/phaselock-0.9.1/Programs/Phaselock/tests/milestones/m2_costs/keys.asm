; logs the last key seen in each of 64 frames into the parameter area (address in D)
TMW_FRAM = $20CB
start:  std  $41
        ldaa $77
        psha
        clr  $77
        ldaa $78
        psha
        clr  $78
        ldaa $20C0
        psha
        clr  $20C0
        ldab #64
frame:  pshb
        ldaa TMW_FRAM+1
.wait:  slp
        cmpa TMW_FRAM+1
        beq  .wait
t_tick: clra
.drain: os   KB$TEST
        tstb
        beq  .done
        os   KB$GETK
        tba
        bra  .drain
.done:  ldx  $41
        staa 0,x
        inx
        stx  $41
        pulb
        decb
        bne  frame
        pula
        staa $20C0
        pula
        staa $78
        pula
        staa $77
        os   KB$FLSH
        ldx  #1
        rts
