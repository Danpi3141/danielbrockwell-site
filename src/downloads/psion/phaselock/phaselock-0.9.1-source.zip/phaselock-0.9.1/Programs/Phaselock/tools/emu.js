// Headless Psion Organiser II: runs the Jape emulator sources (PsionII/Emulator)
// under Node, with breakpoints, cycle counting, key presses and screen reading.
// Nothing in Emulator/ is modified; hd6303.js is patched in memory for debug hooks.
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const EMU = path.resolve(__dirname, '..', '..', '..', 'Emulator');

// key name -> [row, col] on the 6x6 keyboard grid
const KEYS = { ON: [0, 0], MODE: [0, 1], UP: [0, 2], DOWN: [0, 3], LEFT: [0, 4], RIGHT: [0, 5],
  SHIFT: [5, 0], DEL: [5, 1], SPACE: [5, 4], EXE: [5, 5], ' ': [5, 4] };
'ABCDEF'.split('').forEach((c, i) => { KEYS[c] = [1, i]; });
'GHIJKL'.split('').forEach((c, i) => { KEYS[c] = [2, i]; });
'MNOPQR'.split('').forEach((c, i) => { KEYS[c] = [3, i]; });
'STUVWX'.split('').forEach((c, i) => { KEYS[c] = [4, i]; });
KEYS.Y = [5, 2]; KEYS.Z = [5, 3];
// shifted symbols: [key, needs shift]
const SHIFTED = { '<': 'A', '>': 'B', '(': 'C', ')': 'D', '%': 'E', '/': 'F', '=': 'G', '"': 'H',
  '7': 'I', '8': 'J', '9': 'K', '*': 'L', ',': 'M', '$': 'N', '4': 'O', '5': 'P', '6': 'Q', '-': 'R',
  ';': 'S', ':': 'T', '1': 'U', '2': 'V', '3': 'W', '+': 'X', '0': 'Y', '.': 'Z' };

const TICK = 46080;           // CPU cycles per 50 ms keyboard interrupt (approx)

function Machine(opts) {
  opts = opts || {};
  const rom = opts.rom || '46a-lz64.rom';
  const ram = opts.ram || 64;
  const quiet = opts.quiet !== false;
  const logs = [];
  const sandbox = {
    console: { log: (...a) => { logs.push(a.join(' ')); if (!quiet) console.log('[emu]', ...a); } },
    alert: (m) => { throw new Error('emulator alert: ' + m); },
    Date, Math, Uint8Array, ArrayBuffer, Array, setTimeout,
  };
  sandbox.window = sandbox;
  vm.createContext(sandbox);
  // synchronous file loader replacing binaryfile.js
  vm.runInContext(`
    var FileStatus = { loading: 0, ready: 1, error: 2 };
    function BinaryFile(inputFile, isLocal, callback) {
      var _data = (typeof inputFile === 'string') ? __readFile(inputFile) : inputFile;
      var _name = (typeof inputFile === 'string') ? inputFile : 'memory';
      this.status = function () { return FileStatus.ready; };
      this.isReady = function () { return true; };
      this.getData = function () { return _data; };
      this.getName = function () { return _name; };
      if (callback) callback();
    }`, sandbox);
  sandbox.__readFile = (name) => new Uint8Array(fs.readFileSync(path.isAbsolute(name) ? name : path.join(EMU, name)));

  function load(name, patch) {
    let src = fs.readFileSync(path.join(EMU, name), 'utf8');
    if (patch) src = patch(src);
    vm.runInContext(src, sandbox, { filename: name });
  }
  load('memory.js');
  load('display.js');
  load('keyboard.js');
  load('pack.js');
  load('bus.js');
  load('hd6303.js', (src) => {
    const rep = (a, b) => { if (!src.includes(a)) throw new Error('patch target missing: ' + a); src = src.replace(a, b); };
    rep('var _sleep=true;', `var _sleep=true;
      var _bps = {}; var _bpHit = -1; var _skip = -1; var _cyc = 0; var _trace = null;
      this.dbg = {
        pc: function(){ return _PC; }, a: function(){ return _A; }, b: function(){ return _B; },
        x: function(){ return _X; }, sp: function(){ return _SP; }, d: function(){ return (_A<<8)+_B; },
        p: function(){ return P(); }, sleeping: function(){ return _sleep; },
        setBp: function(a, on){ if(on===false) delete _bps[a]; else _bps[a]=true; },
        clearBps: function(){ _bps = {}; },
        hit: function(){ return _bpHit; },
        cycles: function(){ return _cyc; },
        setTrace: function(f){ _trace = f; },
        setX: function(v){ _X = v & 0xffff; }, setA: function(v){ _A = v & 0xff; }, setB: function(v){ _B = v & 0xff; }
      };`);
    rep('this.execute = function(ticksToExecute) {', 'this.execute = function(ticksToExecute) { _bpHit = -1;');
    rep('var inst = _sleep || _bus.isSwitchedOff() ? 1 : nxtpcb();',
      `if(!_sleep && !_bus.isSwitchedOff()){
          if(_bps[_PC]){ if(_skip!==_PC){ _bpHit=_PC; _skip=_PC; return ticksToExecute; } }
          if(_skip===_PC) _skip=-1;
          if(_trace) _trace(_PC);
       }
       var inst = _sleep || _bus.isSwitchedOff() ? 1 : nxtpcb();`);
    rep('_bus.incFrame(ticks);', '_bus.incFrame(ticks); _cyc += ticks;');
    // Jape drops a timer interrupt that comes due while interrupts are masked. The real
    // 6303 keeps it pending and takes it when the mask clears; deferOCI models that.
    if (opts.deferOCI !== false) {
      rep('if( _bus.isOCIdue() && !Iset() ){', 'if( (!Iset() || _bus.isSwitchedOff()) && _bus.isOCIdue() && !Iset() ){');
    }
    return src;
  });

  const ctx = { getContext: null };
  const fakeCtx = { createImageData: (w, h) => ({ data: new Uint8Array(w * h * 4) }), fillRect() {}, putImageData() {}, drawImage() {} };
  const g = (expr) => vm.runInContext(expr, sandbox);
  sandbox.__ctx = fakeCtx;
  sandbox.__rom = sandbox.__readFile('roms/' + rom);
  g(`var __display = new Display(__ctx, 4);
     var __memory = new Memory(${ram}, new BinaryFile(__rom));
     var __keyboard = new Keyboard(KeyboardLayout.Normal);
     var __bus = new Bus(__memory, __display, __keyboard);
     var __cpu = new HD6303(__bus);
     __bus.onSwitchOnOff = function(state){ __cpu.onSwitchOnOff(); };
     __memory.isReady();`);
  const cpu = sandbox.__cpu, bus = sandbox.__bus, mem = sandbox.__memory, kb = sandbox.__keyboard, disp = sandbox.__display;
  const dbg = cpu.dbg;
  const self = this;
  this.cpu = cpu; this.bus = bus; this.mem = mem; this.kb = kb; this.disp = disp; this.dbg = dbg; this.logs = logs;
  this.screen2mem = g('screen2mem4');

  // ---- memory ----
  this.peek = (a) => mem.read(a & 0xffff) & 0xff;
  this.peekw = (a) => (self.peek(a) << 8) | self.peek(a + 1);
  this.poke = (a, v) => mem.write(a & 0xffff, v & 0xff);
  this.pokew = (a, v) => { self.poke(a, v >> 8); self.poke(a + 1, v); };
  this.read = (a, n) => { const r = []; for (let i = 0; i < n; i++) r.push(self.peek(a + i)); return r; };
  this.write = (a, bytes) => { for (let i = 0; i < bytes.length; i++) self.poke(a + i, bytes[i]); };
  this.find = (bytes, from, to) => {
    from = from || 0x2000; to = to || 0x8000;
    outer: for (let a = from; a <= to - bytes.length; a++) {
      for (let i = 0; i < bytes.length; i++) if (self.peek(a + i) !== bytes[i]) continue outer;
      return a;
    }
    return -1;
  };

  // ---- running ----
  // run for n cycles or until a breakpoint; returns the breakpoint address or -1
  this.run = (cycles) => {
    let left = cycles;
    while (left > 0) {
      const chunk = Math.min(left, 20000);
      const before = dbg.cycles();
      cpu.execute(chunk);
      const used = dbg.cycles() - before;
      left -= Math.max(used, 1);
      if (dbg.hit() >= 0) return dbg.hit();
      if (used === 0) break;                      // stack error or switched off and stuck
      if (self.onChunk) self.onChunk();
    }
    return -1;
  };
  this.runTicks = (n) => self.run(n * TICK);
  this.runSeconds = (s) => self.run(Math.round(s * 921600));
  // run until one of the breakpoints is hit (max cycles), returns address or -1
  this.runTo = (addrs, maxCycles) => {
    if (!Array.isArray(addrs)) addrs = [addrs];
    addrs.forEach((a) => dbg.setBp(a));
    const r = self.run(maxCycles || 921600 * 60);
    addrs.forEach((a) => dbg.setBp(a, false));
    return r;
  };
  this.cycles = () => dbg.cycles();

  // ---- keyboard ----
  this.keyDown = (k) => { const rc = KEYS[k]; if (!rc) throw new Error('no key ' + k); kb.doGrid(rc[0], rc[1], true); };
  this.keyUp = (k) => { const rc = KEYS[k]; kb.doGrid(rc[0], rc[1], false); };
  this.allUp = () => { Object.keys(KEYS).forEach((k) => self.keyUp(k)); };
  // press and release, in ticks
  this.press = (k, hold, gap) => {
    self.keyDown(k); self.runTicks(hold || 3); self.keyUp(k); self.runTicks(gap === undefined ? 3 : gap);
  };
  // type text: letters, digits and symbols (shift handled), '\n' = EXE
  this.type = (text, hold, gap) => {
    for (const ch of text) {
      if (ch === '\n') { self.press('EXE', hold, gap); continue; }
      const up = ch.toUpperCase();
      if (KEYS[up]) { self.press(up, hold, gap); continue; }
      if (SHIFTED[ch]) {
        self.keyDown('SHIFT'); self.runTicks(1); self.press(SHIFTED[ch], hold, 1); self.keyUp('SHIFT'); self.runTicks(gap === undefined ? 3 : gap);
        continue;
      }
      throw new Error('cannot type ' + JSON.stringify(ch));
    }
  };

  // ---- display ----
  function dispState() {
    const arr = []; disp.getSnapshotData(arr);
    return { hdr: arr.slice(0, 11), data: arr.slice(11, 11 + 128), udg: arr.slice(11 + 128, 11 + 128 + 64) };
  }
  // raw 80 character codes, row major
  this.cells = () => { const d = dispState().data; return self.screen2mem.map((m) => d[m]); };
  this.screen = () => {
    const c = self.cells(); const rows = [];
    for (let r = 0; r < 4; r++) {
      rows.push(c.slice(r * 20, r * 20 + 20).map((v) => (v >= 32 && v < 127 ? String.fromCharCode(v) : (v < 8 ? "⓪①②③④⑤⑥⑦"[v] : "?"))).join(''));
    }
    return rows;
  };
  this.screenText = () => self.screen().join('\n');
  // UDG n as 8 row bytes
  this.udg = (n) => dispState().udg.slice(n * 8, n * 8 + 8);
  this.udgs = () => { const u = dispState().udg; const r = []; for (let i = 0; i < 8; i++) r.push(u.slice(i * 8, i * 8 + 8)); return r; };
  this.isOn = () => !bus.isSwitchedOff();
  // 32 pixel rows x 100 columns as strings, from the LCD contents (ROM font for 32..127 only)
  this.pixels = () => {
    const font = g('char4'); const c = self.cells(); const u = dispState().udg; const out = [];
    for (let y = 0; y < 32; y++) {
      let s = '';
      for (let x = 0; x < 100; x++) {
        const ch = c[(y >> 3) * 20 + Math.floor(x / 5)];
        const row = ch < 8 ? u[ch * 8 + (y & 7)] : (ch >= 32 ? font[(ch - 32) * 8 + (y & 7)] : 0);
        s += (row >> (4 - (x % 5))) & 1 ? '#' : '.';
      }
      out.push(s);
    }
    return out;
  };

  // ---- packs ----
  // slot 0 = B:, 1 = C:
  this.insertPack = (file, slot) => {
    sandbox.__pf = new Uint8Array(fs.readFileSync(file));
    g(`var __pk = new Pack({ name: 'pk', file: new BinaryFile(__pf) }); __pk.isReady(); __bus.setPack(__pk, ${slot || 0});`);
    return sandbox.__pk;
  };
  this.emptyPack = (type, sizeK, slot) => {
    g(`var __pk = new Pack({ name: 'pk', type: ${type}, size: ${sizeK} }); __pk.isReady(); __bus.setPack(__pk, ${slot || 0});`);
    return sandbox.__pk;
  };

  // ---- boot ----
  // cold boot to the top-level menu (English)
  this.boot = () => {
    self.keyDown('ON'); self.runTicks(4); self.keyUp('ON');
    for (let i = 0; i < 40 && !self.screenText().includes('English'); i++) self.runSeconds(0.25);
    self.press('EXE', 3, 10);
    for (let i = 0; i < 40 && !self.screenText().includes('Find'); i++) self.runSeconds(0.25);
    if (!self.screenText().includes('Find')) throw new Error('boot failed\n' + self.screenText());
    return self.screen();
  };
  // from the top-level menu: Prog > Run <dev>:<name>
  this.runProc = (name, dev) => {
    self.press('P', 3, 10); self.press('R', 3, 10);
    const want = (dev || 'B') + ':';
    for (let i = 0; i < 4 && !self.screenText().includes('Run ' + want); i++) self.press('MODE', 3, 12);
    if (!self.screenText().includes('Run ' + want)) throw new Error('cannot select ' + want + '\n' + self.screenText());
    self.type(name, 3, 3);
    self.press('EXE', 3, 0);
  };
}

module.exports = { Machine, KEYS, TICK };

if (require.main === module) {
  const m = new Machine({ rom: process.argv[2] });
  console.log(m.boot().join('\n'));
  console.log('cycles', m.cycles());
}
