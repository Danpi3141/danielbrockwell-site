"""Wave scripts for Phaselock.

A wave is a 6-byte header followed by 2-byte spawn records and a 0 terminator:
  header: sprite of class A, sprite of class B (the boss's hit points in its wave),
          speed A, speed B, star speed, kind
          kind: $02 boss, $10 enemy shots hop every tick, $20 shooters fire twice as often
  record: ticks to wait since the last spawn (1..255), then lane (bits 0-1), class (bit 2),
          announce with a blip (bit 3), flags (bits 4-7)
Speeds are quarter pixels per tick: 2 = 10 px/s, 3 = 15, 4 = 20, 5 = 25, 6 = 30, 7 = 35, 8 = 40.

Tuning: each wave has a `pace` that scales every wait (smaller = denser), its two class
speeds, and the `fast` and `rapid` switches. `reprise` repeats the back half of a script
until it is long enough.
"""
from sprites import SPRITE, BOSS_INDEX

WEAVER, SHOOTER, ARMOURED, MINE = 0x10, 0x20, 0x40, 0x80
A, B = 0, 1


def rec(wait, lane, cls=A, flags=0, blip=False):
    assert 1 <= wait <= 255 and 0 <= lane <= 3
    return [wait, lane | (cls << 2) | (8 if blip else 0) | flags]


class Wave:
    def __init__(self, name, spr_a, spr_b, spd_a, spd_b, star=1, boss=False, fast=False, rapid=False, pace=1.0, hp=0):
        self.name = name
        kind = (0x02 if boss else 0) | (0x10 if fast else 0) | (0x20 if rapid else 0)
        self.header = [BOSS_INDEX if boss else SPRITE[spr_a], hp if boss else (SPRITE[spr_b] if spr_b else 0),
                       spd_a, spd_b, star, kind]
        self.pace = pace
        self.recs = []

    def add(self, wait, lane, cls=A, flags=0, blip=False):
        self.recs += rec(max(1, int(round(wait * self.pace))), lane, cls, flags, blip)
        return self

    def reprise(self, ticks=1250):
        """Repeat the back half of the script until the last spawn is at `ticks` or later."""
        half = self.recs[len(self.recs) // 4 * 2:]
        i = 0
        while self.ticks() < ticks and len(self.recs) + 2 <= 240:
            self.recs += half[i:i + 2]
            i = (i + 2) % len(half)
        return self

    def line(self, wait, lanes, gap, cls=A, flags=0, blip=False):
        """One enemy in each of `lanes`, `gap` ticks apart, after `wait` ticks."""
        for i, ln in enumerate(lanes):
            self.add(wait if i == 0 else gap, ln, cls, flags, blip)
        return self

    def dart(self, wait, lane, flags=0):
        """A class B enemy announced by the warning blip."""
        return self.add(wait, lane, B, flags, True)

    def bytes(self):
        out = self.header + self.recs + [0]
        assert len(out) <= 255, "%s: %d bytes" % (self.name, len(out))
        return out

    def ticks(self):
        return sum(self.recs[0::2])

    def count(self):
        return len(self.recs) // 2


def build():
    W = []

    # 1: drones in loose lines
    w = Wave("DRONES", "DRONE", None, 4, 0, pace=0.7)
    w.line(30, [1, 2], 20).line(70, [0, 3], 20).line(70, [1, 0, 2], 28)
    w.line(80, [3, 2, 1, 0], 26).line(80, [0, 1], 16).line(50, [3, 2], 16)
    w.line(80, [1, 2, 1, 2], 30).line(70, [0, 3, 0, 3], 28)
    w.line(80, [0, 1, 2, 3], 18).line(60, [3, 2, 1, 0], 18)
    w.line(90, [1, 2], 12).line(40, [0, 3], 12, flags=SHOOTER).line(60, [2, 1, 2, 1], 22)
    W.append(w.reprise())

    # 2: weavers
    w = Wave("WEAVERS", "SAUCER", None, 4, 0, pace=0.7)
    w.line(30, [0], 1, flags=WEAVER).line(60, [3], 1, flags=WEAVER)
    w.line(70, [1, 2], 24).line(60, [0, 3], 30, flags=WEAVER)
    w.line(80, [2, 1, 3], 26, flags=WEAVER).line(70, [0, 1, 2, 3], 24)
    w.line(70, [3, 0], 20, flags=WEAVER).line(40, [1, 2], 20)
    w.line(80, [0, 2, 3, 1], 28, flags=WEAVER).line(70, [1, 2], 14, flags=SHOOTER)
    w.line(50, [0, 3, 0, 3], 26, flags=WEAVER).line(70, [2, 1, 2], 20)
    w.line(60, [3, 0, 2, 1], 22, flags=WEAVER)
    W.append(w.reprise())

    # 3: darts, each announced by a blip
    w = Wave("DARTS", "SAUCER", "DART", 5, 8, pace=0.75)
    w.line(30, [1, 2], 22).dart(50, 0).line(40, [2, 1], 22, flags=WEAVER)
    w.dart(40, 3).dart(30, 0).line(40, [1, 2, 1], 24)
    w.dart(30, 3).line(40, [2, 1], 20, flags=WEAVER).dart(30, 0)
    w.dart(24, 3).line(40, [1, 2, 1, 2], 22).dart(30, 0)
    w.line(36, [2, 1], 20, flags=WEAVER).dart(28, 3).dart(20, 0)
    w.line(40, [1, 2], 16, flags=SHOOTER).dart(24, 3).line(36, [2, 1, 2], 20, flags=WEAVER)
    w.dart(26, 0).dart(18, 3).line(40, [1, 2, 1, 2], 18)
    w.dart(24, 0).dart(16, 3).dart(16, 0)
    w.line(44, [2, 1, 2, 1], 20, flags=WEAVER).dart(26, 3).dart(14, 0)
    w.line(40, [1, 2], 14).line(30, [2, 1], 14, flags=WEAVER).dart(24, 0).dart(12, 3).dart(12, 0).dart(12, 3)
    W.append(w.reprise())

    # 4: mines (cannot be shot) and darts
    w = Wave("MINES", "MINE", "DART", 4, 8, pace=0.8)
    w.line(30, [1], 1, flags=MINE).line(50, [2], 1, flags=MINE).dart(40, 0)
    w.line(40, [0, 3], 24, flags=MINE).dart(36, 1).dart(20, 2)
    w.line(40, [1, 2], 30, flags=MINE).dart(30, 3).line(36, [0, 2], 26, flags=MINE)
    w.dart(30, 1).dart(18, 3).line(40, [3, 1], 26, flags=MINE)
    w.dart(28, 0).dart(18, 2).line(40, [0, 2, 3], 28, flags=MINE)
    w.dart(30, 1).dart(16, 0).line(40, [1, 3], 24, flags=MINE)
    w.dart(26, 2).dart(16, 0).line(40, [2, 0, 3, 1], 26, flags=MINE)
    w.dart(28, 1).dart(14, 2).dart(14, 3).dart(14, 0)
    w.line(44, [1, 3, 0, 2], 24, flags=MINE).dart(26, 2).dart(14, 1)
    w.line(40, [0, 1], 20, flags=MINE).line(36, [3, 2], 20, flags=MINE).dart(24, 0).dart(12, 3).dart(12, 1).dart(12, 2)
    W.append(w.reprise())

    # 5: shooters and drones
    w = Wave("SHOOTERS", "CRAB", "DRONE", 5, 3, rapid=True, pace=0.75)
    w.line(30, [1, 2], 24, B).line(40, [0], 1, flags=SHOOTER).line(50, [3], 1, flags=SHOOTER)
    w.line(40, [2, 1], 20, B).line(40, [1, 2], 24, flags=SHOOTER).line(40, [0, 3], 18, B)
    w.line(44, [3, 0, 2], 22, flags=SHOOTER).line(40, [1, 2], 16, B)
    w.line(40, [1, 3], 20, flags=SHOOTER).line(30, [0, 2], 20, flags=SHOOTER)
    w.line(40, [3, 2, 1, 0], 18, B).line(44, [0, 1, 2, 3], 20, flags=SHOOTER)
    w.line(40, [2, 1], 14, B).line(36, [3, 0, 3, 0], 20, flags=SHOOTER)
    w.line(40, [1, 2, 1, 2], 16, B).line(40, [2, 0, 3, 1], 18, flags=SHOOTER)
    w.line(40, [0, 3, 1, 2], 14, B).line(40, [1, 2, 0, 3], 16, flags=SHOOTER)
    w.line(36, [2, 1], 12, B).line(32, [3, 0, 2, 1, 3, 0], 14, flags=SHOOTER)
    W.append(w.reprise())

    # 6: armoured heavies and shooters
    w = Wave("HEAVIES", "HEAVY", "CRAB", 5, 3, rapid=True, pace=0.75)
    w.line(30, [1], 1, flags=ARMOURED).line(50, [2], 1, flags=ARMOURED)
    w.line(40, [0, 3], 24, B, SHOOTER).line(44, [1, 2], 26, flags=ARMOURED)
    w.line(40, [3, 0], 20, B, SHOOTER).line(44, [0, 2, 3], 24, flags=ARMOURED)
    w.line(40, [1, 2], 20, B, SHOOTER).line(44, [3, 1], 22, flags=ARMOURED)
    w.line(30, [0, 2], 22, flags=ARMOURED).line(40, [3, 0, 1], 20, B, SHOOTER)
    w.line(44, [1, 2, 0, 3], 22, flags=ARMOURED).line(40, [2, 1], 18, B, SHOOTER)
    w.line(44, [0, 3, 1, 2], 20, flags=ARMOURED).line(36, [3, 0], 16, B, SHOOTER)
    w.line(40, [2, 1, 3, 0], 20, flags=ARMOURED)
    w.line(40, [0, 3], 14, B, SHOOTER).line(40, [1, 2, 1, 2], 18, flags=ARMOURED)
    w.line(36, [3, 0, 2], 16, B, SHOOTER).line(40, [0, 3, 1, 2, 0, 3], 18, flags=ARMOURED)
    W.append(w.reprise())

    # 7: mixed and denser: weaving shooters and darts
    w = Wave("SWARM", "SAUCER", "DART", 6, 8, fast=True, rapid=True, pace=0.75)
    w.line(30, [1, 2], 18, flags=WEAVER).dart(30, 0).line(30, [3, 0], 18, flags=SHOOTER)
    w.dart(24, 2).line(30, [1, 2, 1], 16, flags=WEAVER).dart(22, 3)
    w.dart(14, 0).line(30, [0, 3], 16, flags=WEAVER | SHOOTER).line(28, [2, 1], 16)
    w.dart(22, 3).line(28, [1, 2, 0], 16, flags=SHOOTER).dart(20, 1)
    w.dart(14, 2).line(28, [3, 0, 3], 16, flags=WEAVER).line(26, [1, 2], 14, flags=SHOOTER)
    w.dart(20, 0).dart(12, 3).line(28, [2, 1, 2, 1], 14, flags=WEAVER)
    w.line(26, [0, 3], 14, flags=WEAVER | SHOOTER).dart(20, 1).dart(12, 2)
    w.line(28, [3, 2, 1, 0], 14, flags=WEAVER).dart(20, 0).dart(12, 3)
    w.line(26, [1, 2, 1, 2], 14, flags=SHOOTER).dart(18, 0).dart(12, 3)
    w.line(30, [0, 3, 1, 2], 14, flags=WEAVER | SHOOTER).dart(20, 2).dart(12, 1)
    w.line(28, [1, 2, 3, 0, 1, 2], 12, flags=WEAVER).dart(18, 3).dart(10, 0).dart(10, 3)
    w.line(28, [2, 1, 0, 3], 12, flags=SHOOTER).line(24, [1, 2, 1, 2], 12, flags=WEAVER | SHOOTER)
    w.dart(18, 0).dart(10, 3).dart(10, 1).dart(10, 2)
    W.append(w.reprise())

    # 8: everything: shooters, weavers, armour and fast mines
    w = Wave("STORM", "CRAB", "MINE", 6, 8, fast=True, rapid=True, pace=0.85)
    w.line(30, [1, 2], 16, flags=SHOOTER).dart(30, 0, MINE).line(28, [3, 0], 16, flags=WEAVER)
    w.line(26, [2], 1, flags=ARMOURED).dart(24, 3, MINE).line(26, [1, 2, 1], 14, flags=SHOOTER)
    w.dart(22, 0, MINE).line(24, [0, 3], 14, flags=WEAVER | SHOOTER)
    w.line(24, [1], 1, flags=ARMOURED).dart(20, 2, MINE).line(24, [3, 2, 0], 14, flags=WEAVER)
    w.dart(20, 1, MINE).line(24, [2, 1], 12, flags=ARMOURED).line(22, [0, 3], 12, flags=SHOOTER)
    w.dart(20, 3, MINE).dart(14, 0, MINE)
    w.line(24, [1, 2, 3, 0], 12, flags=WEAVER | SHOOTER).line(22, [2, 1], 12, flags=ARMOURED)
    w.dart(18, 2, MINE).line(22, [3, 0, 1], 12, flags=SHOOTER)
    w.dart(18, 1, MINE).dart(12, 3, MINE)
    w.line(22, [0, 2, 1, 3], 12, flags=WEAVER).line(22, [1, 2], 12, flags=ARMOURED | SHOOTER)
    w.dart(18, 0, MINE).line(20, [3, 0, 2, 1], 12, flags=SHOOTER)
    w.line(26, [1, 2], 12, flags=ARMOURED).dart(18, 3, MINE).line(22, [0, 3, 1, 2], 12, flags=WEAVER | SHOOTER)
    w.dart(18, 2, MINE).dart(12, 0, MINE).line(24, [2, 1, 3, 0], 12, flags=SHOOTER)
    w.line(22, [1, 2], 12, flags=ARMOURED | SHOOTER).dart(18, 1, MINE).line(22, [3, 0, 2, 1, 3, 0], 10, flags=WEAVER)
    w.line(22, [0, 3], 12, flags=ARMOURED).dart(16, 2, MINE).dart(10, 1, MINE).line(22, [1, 2, 0, 3], 10, flags=WEAVER | SHOOTER)
    W.append(w.reprise())

    # boss: both classes stopped, sprite slots 2..5 borrowed
    W.append(Wave("BOSS", None, None, 0, 0, boss=True, hp=24))
    return W


WAVES = build()

if __name__ == "__main__":
    for i, w in enumerate(WAVES, 1):
        print("%d %-9s %3d bytes %3d spawns, last spawn at %5.1f s" % (i, w.name, len(w.bytes()), w.count(), w.ticks() / 20))
