; D = address of parameter area: 80 byte frame, then 5 byte column pattern, then 8 byte row pattern
POB_PORT = $180
start:  std  $41
t_stat: clra
        clrb
        os   DP$STAT
t_prnt: ldx  $41
        ldab #80
        os   DP$PRNT
t_udg5: ldx  $41
        ldab #80
        abx
        ldaa #1
        ldab #2
        os   DP$UDG
t_udg8: ldx  $41
        ldab #85
        abx
        clra
        ldab #0
        os   DP$UDG
t_emit: ldaa #'A'
        os   DP$EMIT
t_se:   ldaa #40
        clrb
        os   DP$STAT
        ldaa #3
        os   DP$EMIT
t_test: os   KB$TEST
t_brek: os   KB$BREK
t_tone4: ldd #100
        ldx  #4
        os   BZ$TONE
t_tone10: ldd #300
        ldx  #10
        os   BZ$TONE
t_end:  ldx  #7
        rts
