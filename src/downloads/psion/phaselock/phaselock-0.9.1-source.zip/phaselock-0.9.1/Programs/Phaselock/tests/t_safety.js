// Bounded writes: while a core instruction is executing, every memory write must go to
// the state block, the scratch words, the three keyboard variables, the LCD registers,
// the output words of the parameter block or the stack. And the core must never touch
// the bank-switching addresses. (Writes made by OS services it calls are the OS's own.)
//   node tests/t_safety.js
'use strict';
const assert = require('assert');
const { Rig, loadBuild, rng } = require('./harness.js');
const { makeBot } = require('./bot.js');

const core = loadBuild();
const rig = new Rig(core);
const m = rig.m, bot = makeBot(core);
const base = rig.base, end = rig.base + core.image.length;
const S0 = rig.state, S1 = rig.state + core.state_size, P = rig.addr.P;
const bad = new Map();
let writes = 0, reads = 0;
const note = (kind, addr, pc) => { const k = kind + ' $' + addr.toString(16); if (!bad.has(k)) bad.set(k, 'pc $' + (pc - base).toString(16)); };

const bus = m.bus, w0 = bus.write, r0 = bus.read;
bus.write = function (addr, b) {
  const pc = m.dbg.pc();
  if (pc >= base && pc <= end) {
    writes++;
    const sp = m.dbg.sp();
    const ok = (addr >= S0 && addr < S1) || (addr >= 0x41 && addr <= 0x4C) || addr === 0x77 || addr === 0x78 || addr === 0x20C0 ||
      addr === 0x180 || addr === 0x181 || (addr >= P + 6 && addr <= P + 9) || addr === P + 14 || addr === P + 15 ||
      (addr >= sp - 8 && addr <= sp + 8);
    if (!ok) note('write', addr, pc);
  }
  return w0.call(bus, addr, b);
};
bus.read = function (addr) {
  const pc = m.dbg.pc();
  if (pc >= base && pc <= end) {
    reads++;
    if (addr >= 0x100 && addr < 0x400 && addr !== 0x180) note('read', addr, pc);   // only the LCD busy flag
  }
  return r0.call(bus, addr);
};

const r = rng(9);
let frames = 0;
for (let w = 0; w < core.waves.length; w++) {
  rig.setParams({ wave: core.waves[w], stock: 0x0502 });
  const out = rig.call({ maxFrames: 2500, keys: (f, rg) => (r() < 0.7 ? bot(rg.stateBytes()) : Math.floor(r() * 8)) });
  if (out.result === -1) rig.stop();
  frames += out.frames;
}
// pause, resume and a refused call as well
rig.setParams({ wave: core.waves[0] });
rig.call({ maxFrames: 300, onFrame: (f) => { if (f === 50) rig.tap('MODE', 2); } });
rig.setParams({ mode: 1 });
if (rig.call({ maxFrames: 100 }).result === -1) rig.stop();
rig.setParams({ wave: core.waves[0], state: rig.state + 2 });
rig.call({ maxFrames: 5 });

console.log('%d frames, %d writes and %d reads made by core instructions checked', frames, writes, reads);
if (bad.size) { for (const [k, v] of bad) console.log('  OUT OF BOUNDS: %s (%s)', k, v); }
assert.strictEqual(bad.size, 0);
console.log('PASS: the core writes only to its state block, scratch words, the three keyboard variables, the LCD and its outputs');
