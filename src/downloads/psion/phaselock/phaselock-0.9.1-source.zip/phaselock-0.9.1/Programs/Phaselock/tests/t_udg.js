// UDG read-back: after the core has run, read all eight UDGs back through the OS
// (DP$UDG with bit 7 of A set) and compare them with the model's strips for the state
// the core stopped in, and with the patterns in the LCD itself.
//   node tests/t_udg.js
'use strict';
const assert = require('assert');
const { execFileSync } = require('child_process');
const { Rig, loadBuild, rng, ROOT } = require('./harness.js');
const { makeBot } = require('./bot.js');

const core = loadBuild();
const rig = new Rig(core);
const m = rig.m, bot = makeBot(core), r = rng(3);
const PY = process.env.PYTHON || 'python';

// reader: for slot 0..7: A=$80, B=slot, X=buffer -> 8 row bytes each
const BUF = rig.addr.W;                       // the wave buffer is free once the core has returned
const reader = [0xCE, BUF >> 8, BUF & 255,    // ldx #BUF
  0x5F,                                       // clrb
  0x37, 0x86, 0x80, 0x3F, 133, 0x33,          // .lp: pshb / ldaa #$80 / os DP$UDG / pulb
  0x5C, 0xC1, 0x08, 0x26, 0xF5,               // incb / cmpb #8 / bne .lp
  0xCE, 0x00, 0x08, 0x39];                    // ldx #8 / rts
const image = m.read(rig.base, reader.length);

let checked = 0;
for (let round = 0; round < 24; round++) {
  const w = round % 9;
  rig.setParams({ wave: core.waves[w], stock: 0x6302 });
  const stopAt = 20 + Math.floor(r() * 500);
  const out = rig.call({ maxFrames: 2000, keys: (f, rg) => bot(rg.stateBytes()), onFrame: (f) => { if (f === stopAt) rig.tap('ON', 3); } });
  if (out.result !== 2) continue;                        // wave ended first
  const state = rig.stateBytes();
  const wave = m.read(rig.addr.W, 256), lib = m.read(rig.addr.L, 256);
  const lcd = [].concat(...m.udgs());
  // swap the reader in for one call
  m.write(rig.base, reader);
  m.keyDown('SPACE'); for (let i = 0; i < 40 && !m.screenText().includes('R=8'); i++) m.runTicks(1); m.keyUp('SPACE');
  assert.ok(m.screenText().includes('R=8'), m.screenText());
  const back = m.read(BUF, 64);
  m.write(rig.base, image);
  const job = JSON.stringify({ sym: core.sym, state, wave, lib, waveAddr: rig.addr.W, libAddr: rig.addr.L, back, lcd, size: core.state_size });
  const res = execFileSync(PY, ['-c', `
import sys, json
sys.path.insert(0, 'tools')
from model import Model
j = json.load(sys.stdin)
S = {n: v['value'] for n, v in j['sym'].items() if v['seg'] == 'state'}
def mem(a):
    if j['waveAddr'] <= a < j['waveAddr'] + 256: return j['wave'][a - j['waveAddr']]
    return j['lib'][a - j['libAddr']]
exp = Model(S, mem).expected_udgs(bytearray(j['state']))
n = 0
for slot in range(8):
    if exp[slot] is None: continue
    got = j['back'][slot*8:slot*8+8]; lcd = j['lcd'][slot*8:slot*8+8]
    assert [g & 31 for g in got] == list(exp[slot]), 'slot %d read back %s, model %s' % (slot, got, exp[slot])
    assert lcd == list(exp[slot]), 'slot %d LCD %s, model %s' % (slot, lcd, exp[slot])
    n += 1
print(n)
`], { cwd: ROOT, input: job }).toString().trim();
  checked += parseInt(res, 10);
}
assert.ok(checked > 100);
console.log('PASS: %d UDG patterns read back through DP$UDG match the model and the LCD', checked);
