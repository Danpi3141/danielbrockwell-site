#!/usr/bin/env python3
"""Compare a trace recorded from the real core (tests/harness.js) with the model.

For every frame the model is given the core's state and keys as they were at the start
of the logic stage and must reproduce, byte for byte:
  - the whole state block after the frame (logic, UDG bookkeeping, composed frame)
  - the 80 characters on the LCD and the eight UDG patterns in the LCD
  - the tone played and the state after the sound stage
and the state must carry over unchanged to the next frame. On a MODE=0 call the state at
the first frame is also checked against the model's own wave set-up.
"""
import json
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from model import Model  # noqa: E402


def main(path, verbose=False):
    lines = [json.loads(l) for l in open(path)]
    head = lines[0]
    S = {n: v['value'] for n, v in head['sym'].items() if v['seg'] == 'state'}
    size = head['state_size']
    order = sorted((v, n) for n, v in S.items() if n != 'S_END')
    spans = {n: (v, (order[i + 1][0] if i + 1 < len(order) else size)) for i, (v, n) in enumerate(order)}

    def field(off):
        for n, (a, b) in spans.items():
            if a <= off < b:
                return '%s+%d' % (n, off - a)
        return str(off)

    def masked(st, names):
        st = bytearray(st)
        for n in names:
            a, b = spans[n]
            st[a:b] = bytes(b - a)
        return st

    def diff(a, b, what, frame):
        bad = [i for i in range(len(a)) if a[i] != b[i]]
        if bad:
            msg = ', '.join('%s core=%d model=%d' % (field(i), a[i], b[i]) for i in bad[:12])
            raise SystemExit('MISMATCH %s, call %d frame %d: %s' % (what, ncall, frame, msg))

    total = 0
    ncall = 0
    tones = {}
    for rec in lines[1:]:
        ncall += 1
        wave_addr, lib_addr = rec['addr']['W'], rec['addr']['L']
        wave, lib = rec['wave'], rec['lib']

        def mem(a):
            if wave_addr <= a < wave_addr + len(wave):
                return wave[a - wave_addr]
            if lib_addr <= a < lib_addr + len(lib):
                return lib[a - lib_addr]
            raise SystemExit('model read outside wave/library: %04X' % a)
        mdl = Model(S, mem)
        frames = rec['frames']
        prm = rec['params']
        # ---- wave set-up
        if frames and prm[6] == 0:
            pre = bytearray.fromhex(frames[0]['pre'])
            entry_set = ['S_KSAV', 'S_LAST', 'S_KEYS', 'S_PARM', 'S_TMP', 'S_IDLE', 'S_OVER', 'S_TICK']
            ok = False
            for low in range(256):
                st = mdl.init(size, prm[3], prm[4], prm[5], prm[1], prm[2], low)
                mdl.st = st
                mdl.s('S_DIRTY', 0x0F)
                mdl.s('S_EXF', 0xFF)
                mdl.s('S_RES', 0xFF)
                st[S['S_PV']:S['S_PV'] + 80] = b' ' * 80
                if masked(st, entry_set) == masked(pre, entry_set):
                    ok = True
                    break
            if not ok:
                st = mdl.init(size, prm[3], prm[4], prm[5], prm[1], prm[2], pre[S['S_SEED']])
                mdl.st = st
                mdl.s('S_DIRTY', 0x0F); mdl.s('S_EXF', 0xFF); mdl.s('S_RES', 0xFF)
                st[S['S_PV']:S['S_PV'] + 80] = b' ' * 80
                diff(masked(pre, entry_set + ['S_SEED', 'S_STAR']), masked(st, entry_set + ['S_SEED', 'S_STAR']), 'wave set-up', 0)
                raise SystemExit('MISMATCH wave set-up (seed/stars), call %d' % ncall)
            assert pre[S['S_PARM']] << 8 | pre[S['S_PARM'] + 1] == rec['addr']['P']
        prev_end = None
        for n, fr in enumerate(frames):
            pre = bytearray.fromhex(fr['pre'])
            post = bytearray.fromhex(fr['post'])
            if prev_end is not None:
                carry = ['S_LAST', 'S_OVER', 'S_IDLE', 'S_KEYS', 'S_TMP']
                a, b = masked(prev_end, carry), masked(pre, carry)
                a[S['S_FLAGS']] &= 0xFB
                b[S['S_FLAGS']] &= 0xFB
                diff(b, a, 'state carried between frames', n)
            want = mdl.step(bytearray(pre))
            diff(masked(post, ['S_TMP']), masked(want, ['S_TMP']), 'state after frame', n)
            cells = bytes.fromhex(fr['cells'])
            fb = post[S['S_FB']:S['S_FB'] + 80]
            diff(cells, fb, 'LCD characters', n)
            udg = bytes.fromhex(fr['udg'])
            exp = mdl.expected_udgs(bytearray(post))
            for slot in range(8):
                if exp[slot] is None:
                    continue
                got = list(udg[slot * 8:slot * 8 + 8])
                if got != list(exp[slot]):
                    raise SystemExit('MISMATCH UDG %d, call %d frame %d: LCD %s expected %s' % (slot, ncall, n, got, list(exp[slot])))
            if fr['end'] is not None:
                end = bytearray.fromhex(fr['end'])
                want2 = bytearray(post)
                tone = mdl.sound(want2)
                diff(masked(end, ['S_TMP']), masked(want2, ['S_TMP']), 'state after sound', n)
                got_tone = tuple(fr['tone']) if fr['tone'] else None
                if got_tone != tone:
                    raise SystemExit('MISMATCH tone, call %d frame %d: core %s model %s' % (ncall, n, got_tone, tone))
                if tone:
                    tones[tone] = tones.get(tone, 0) + 1
                prev_end = end
            total += 1
        # ---- outputs written back
        if frames and rec['result'] is not None and rec['result'] >= 0 and rec['out']['score'] is not None:
            last = bytearray.fromhex(frames[-1]['end'] or frames[-1]['post'])
            sc = last[S['S_SCORE']] << 8 | last[S['S_SCORE'] + 1]
            stock = last[S['S_LIVES']] << 8 | last[S['S_BOMBS']]
            if rec['out']['score'] != sc or rec['out']['stock'] != stock:
                raise SystemExit('MISMATCH outputs, call %d: %s vs score %d stock %d' % (ncall, rec['out'], sc, stock))
    print('model agrees with the core on %d frames in %d calls; tones %s' % (total, ncall, dict(sorted(tones.items()))))


if __name__ == '__main__':
    main(sys.argv[1], '-v' in sys.argv)
