; =====================================================================
; Phaselock - machine-code core for the Psion Organiser II LZ / LZ64
;
; One call runs a whole wave:   R% = USR(E%, ADDR(P%()))
;   D = address of the parameter block (8 words), result returned in X:
;   0 wave cleared, 1 no lives left, 2 ON/CLEAR, 3 paused, 4 wrong state block
;
; Assembled at origin 0. The loader adds the address of M%() to every word
; in the code fix-up list and the address of S%() to every word in the state
; fix-up list (see tools/build.py).
; =====================================================================

; ---- zero-page scratch (UTW_S0..S5). Never kept across an OS call.
T0      = $41
T1      = $42
T2      = $43
T3      = $44
T4      = $45
T5      = $46
T6      = $47
T7      = $48
T10     = $4B
T11     = $4C

; ---- system variables and hardware
KBB_DLAY = $77
KBB_REPT = $78
KBB_CLIK = $20C0
TMW_FRAM = $20CB
LCD_CTRL = $0180
LCD_DATA = $0181

; ---- parameter block offsets
P_STATE = 0
P_WAVE  = 2
P_SPR   = 4
P_SCORE = 6
P_STOCK = 8
P_TUNE  = 10
P_MODE  = 12
P_OVER  = 14

IDLE_MAX = 600                  ; ticks without a key before pausing (30 s)

; =====================================================================
; State block (lives in the OPL array S%())
; =====================================================================
        seg  state
        org  0
S_PHA:   rmb 3                  ; phase of class A, class B, stars (0..4)
S_ACC:   rmb 3                  ; quarter-pixel accumulators
S_SPD:   rmb 3                  ; speeds in quarter pixels per tick
S_Y:     rmb 1                  ; ship y, 0..27
S_FIRE:  rmb 1                  ; ticks to the next shot
S_INV:   rmb 1                  ; invulnerable ticks left
S_CHAIN: rmb 1                  ; chain multiplier 1..4
S_SEED:  rmb 1                  ; random seed
S_SCRP:  rmb 2                  ; address of the next spawn record
S_WAIT:  rmb 1                  ; ticks until that spawn
S_KSAV:  rmb 3                  ; saved KBB_DLAY, KBB_REPT, KBB_CLIK
S_LAST:  rmb 1                  ; low byte of TMW_FRAM at the last frame
S_TICK:  rmb 1                  ; frame counter
S_KEYS:  rmb 1                  ; bit0 up, bit1 down, bit2 bomb, bit3 pause
S_FLAGS: rmb 1                  ; bit0 script ended, bit1 boss wave, bit2 EXE was held, bit3 boss was hit,
                                ; bit4 enemy shots hop every tick, bit5 shooters fire twice as often
S_EN:    rmb 32                 ; enemies 8 x (flags, lane, home cell, aux)
S_PS:    rmb 6                  ; player shots 3 x (lane, cell)
S_ES:    rmb 6                  ; enemy shots 3 x (lane, cell)
S_EX:    rmb 9                  ; explosions 3 x (lane, cell, frames left)
S_STAR:  rmb 12                 ; stars 6 x (lane, cell)
S_DIRTY: rmb 1                  ; UDGs to rebuild: bit0 ship, bit1 A, bit2 B, bit3 star
S_SND:   rmb 1                  ; sound playing (0 none)
S_SNDT:  rmb 1                  ; ticks of it left
S_LIVES: rmb 1
S_BOMBS: rmb 1
S_SCORE: rmb 2                  ; in tens
S_FB:    rmb 80                 ; frame buffer, row major
S_PV:    rmb 80                 ; what the LCD shows now
S_IDLE:  rmb 2                  ; ticks since the last key
S_OVER:  rmb 2                  ; frames that missed their tick
S_RES:   rmb 1                  ; result code, $FF while the wave runs
S_SPRA:  rmb 2                  ; address of class A's sprite (two 5-byte frames)
S_SPRB:  rmb 2
S_TUNE:  rmb 2                  ; ship speed, fire interval
S_EXF:   rmb 1                  ; explosion frame now in UDG 7
S_BOSS:  rmb 3                  ; top lane, left column ($FF dead), hits left
S_PARM:  rmb 2                  ; address of the parameter block
S_TMP:   rmb 16                 ; UDG build strip
S_END:

; =====================================================================
        seg  code
        org  0
entry:  xgdx                    ; X = parameter block
        ldd  P_STATE,x
        subd #S_PHA
        beq  .ok
        ldx  #4                 ; relocated for a different state block
        rts
.ok:    ldaa P_MODE+1,x
        bne  .keep
        pshx
        jsr  clrstate
        pulx
        stx  S_PARM
        jsr  initwave
        ldx  S_PARM
.keep:  stx  S_PARM
        ldaa KBB_DLAY
        staa S_KSAV
        ldaa KBB_REPT
        staa S_KSAV+1
        ldaa KBB_CLIK
        staa S_KSAV+2
        clr  KBB_DLAY           ; a held key reports every tick
        clr  KBB_REPT
        clr  KBB_CLIK
        ldaa #1
        os   DP$MSET            ; 4-line mode, UDG clock off
        ldab #$80
        os   DP$CSET
        clra
        clrb
        os   DP$STAT            ; cursor off
        ldaa #12
        os   DP$EMIT            ; clear the screen
        os   KB$FLSH
        ldx  #S_PV
        ldaa #32
        ldab #80
.fill:  staa 0,x
        inx
        decb
        bne  .fill
        ldaa #$0F
        staa S_DIRTY            ; rebuild every UDG
        ldaa #$FF
        staa S_EXF
        staa S_RES
        clr  S_IDLE
        clr  S_IDLE+1
        clr  S_OVER             ; OVERRUN counts this call only
        clr  S_OVER+1
        ldaa S_FLAGS
        anda #$FB
        staa S_FLAGS
        bita #2
        beq  .nb
        jsr  bossudg
.nb:    ldaa TMW_FRAM+1
        staa S_LAST

; ---------------------------------------------------------------------
; Frame loop
; ---------------------------------------------------------------------
frame:  ldaa TMW_FRAM+1         ; 1. wait for the next 50 ms tick
        cmpa S_LAST
        bne  .got
        slp                     ; sleep until an interrupt...
.poll:  ldaa TMW_FRAM+1         ; ...then watch the counter. Going back to sleep
        cmpa S_LAST             ; here could lose a tick: the once-a-second NMI can
        beq  .poll              ; wake us just before the tick arrives.
.got:   tab
        subb S_LAST
        staa S_LAST
        decb
        beq  fr_input
        cmpb #10
        blo  .few
        ldaa #3                 ; something held the machine for half a second or more
        jmp  exit               ; (an alarm ringing, say): pause, so the shell redraws
.few:   clra
        addd S_OVER             ; missed ticks
        std  S_OVER

fr_input:
        os   KB$BREK            ; 2. input
        bcc  .nobrk
        ldaa #2
        jmp  exit
.nobrk: clra
.drain: os   KB$TEST
        tstb
        beq  .done
        os   KB$GETK
        oraa #$80               ; some key
        cmpb #3
        bne  .k1
        oraa #1
.k1:    cmpb #4
        bne  .k2
        oraa #2
.k2:    cmpb #13
        bne  .k3
        oraa #4
.k3:    cmpb #2
        bne  .drain
        oraa #8
        bra  .drain
.done:  tsta
        bne  .act
        ldx  S_IDLE
        inx
        stx  S_IDLE
        cpx  #IDLE_MAX
        blo  .edge
        ldaa #3                 ; left alone: pause
        jmp  exit
.act:   clr  S_IDLE
        clr  S_IDLE+1
.edge:  ldab S_FLAGS            ; the bomb fires on the EXE key going down
        bita #4
        beq  .noexe
        bitb #4
        beq  .first
        anda #$FB
        bra  .setf
.first: orab #4
        bra  .setf
.noexe: andb #$FB
.setf:  stab S_FLAGS
        anda #$0F
        staa S_KEYS
        bita #8
        beq  fr_logic
        ldaa #3                 ; MODE: pause
        jmp  exit

fr_logic:
        inc  S_TICK
        jsr  phases             ; 3. advance phases
        jsr  spawn              ; 4. spawn
        jsr  moves              ; 5. move
        jsr  behave
        jsr  bomb
        jsr  colshots           ; 6. collide
        jsr  colship
        ldaa S_INV
        beq  .inv
        dec  S_INV
.inv:   jsr  wavend
fr_udg: jsr  udgs               ; 7. redefine UDGs
fr_comp:
        jsr  compose            ; 8. compose
fr_pres:
        jsr  present            ; 9. present
fr_sound:
        ldaa S_RES              ; 11. exit check
        cmpa #$FF
        bne  exit
        jsr  sound              ; 10. sound, last
fr_end: jmp  frame

; ---------------------------------------------------------------------
; The one way out. A = result code.
; ---------------------------------------------------------------------
exit:   psha
        ldaa S_KSAV
        staa KBB_DLAY
        ldaa S_KSAV+1
        staa KBB_REPT
        ldaa S_KSAV+2
        staa KBB_CLIK
        os   KB$FLSH
        ldaa #12
        os   DP$EMIT
        ldx  S_PARM
        ldd  S_SCORE
        std  P_SCORE,x
        ldaa S_LIVES
        ldab S_BOMBS
        std  P_STOCK,x
        ldd  S_OVER
        std  P_OVER,x
        pulb
        clra
        xgdx
        rts

; ---------------------------------------------------------------------
; Wave set-up
; ---------------------------------------------------------------------
clrstate:
        ldx  #S_PHA
.c:     clr  0,x
        inx
        cpx  #S_END
        bne  .c
        ldaa #$FF
        ldx  #S_EN
        ldab #8
.e:     staa 2,x
        inx
        inx
        inx
        inx
        decb
        bne  .e
        staa S_PS+1
        staa S_PS+3
        staa S_PS+5
        staa S_ES+1
        staa S_ES+3
        staa S_ES+5
        staa S_EX+1
        staa S_EX+4
        staa S_EX+7
        rts

initwave:
        ldx  S_PARM
        ldd  P_SCORE,x
        std  S_SCORE
        ldd  P_STOCK,x
        staa S_LIVES
        stab S_BOMBS
        ldd  P_TUNE,x
        std  S_TUNE
        stab S_FIRE
        ldd  P_SPR,x
        std  T0                 ; sprite library
        ldx  P_WAVE,x           ; wave header
        ldd  2,x
        std  S_SPD              ; speeds of A and B
        ldaa 4,x
        staa S_SPD+2            ; and of the stars
        ldaa 5,x                ; kind: $02 boss, $10 fast enemy shots, $20 rapid shooters
        anda #$32
        staa S_FLAGS
        ldaa 1,x                ; in the boss wave this byte is its hit points
        staa S_BOSS+2
        ldab 0,x
        ldaa #10
        mul
        addd T0
        std  S_SPRA
        ldab 1,x
        ldaa #10
        mul
        addd T0
        std  S_SPRB
        ldab #6
        abx
        stx  S_SCRP
        ldaa 0,x
        staa S_WAIT
        bne  .w
        ldaa S_FLAGS
        oraa #1
        staa S_FLAGS            ; empty script
.w:     ldaa #12
        staa S_Y
        ldaa #1
        staa S_CHAIN
        ldaa TMW_FRAM+1
        oraa #1
        staa S_SEED
        ldx  #S_STAR
        ldab #6
.s:     jsr  rnd
        anda #3
        staa 0,x
        jsr  rnd
        anda #31
        cmpa #20
        blo  .k
        suba #20
.k:     staa 1,x
        inx
        inx
        decb
        bne  .s
        ldaa S_FLAGS
        bita #2
        beq  .x
        ldaa #1
        staa S_BOSS
        ldaa #20
        staa S_BOSS+1
.x:     rts

; 8-bit shift-register generator. Returns A, keeps B and X.
rnd:    ldaa S_SEED
        lsra
        bcc  .n
        eora #$B8
.n:     staa S_SEED
        rts

; ---------------------------------------------------------------------
; 3. Phases
; ---------------------------------------------------------------------
phases: ldaa S_TICK
        anda #7
        bne  .na
        ldaa S_DIRTY            ; animation frame swap every 8 ticks
        oraa #6
        staa S_DIRTY
.na:    ldx  #S_PHA
        ldaa #2
        staa T1
        clr  T2
        bsr  adv
        ldx  #S_PHA+1
        ldaa #4
        staa T1
        inc  T2
        bsr  adv
        ldx  #S_PHA+2
        ldaa #8
        staa T1
        inc  T2
; X = phase byte of the class, T1 = its dirty bit, T2 = class number
adv:    ldaa 3,x
        adda 6,x
.lp:    cmpa #4
        blo  .done
        suba #4
        psha
        ldaa S_DIRTY
        oraa T1
        staa S_DIRTY
        ldaa 0,x
        inca
        cmpa #5
        bne  .st
        pshx
        bsr  wrap
        pulx
        clra
.st:    staa 0,x
        pula
        bra  .lp
.done:  staa 3,x
        rts

; every member of class T2 moves one cell left
wrap:   ldaa T2
        cmpa #2
        beq  .stars
        ldx  #S_EN
        ldab #8
.lp:    ldaa 2,x
        cmpa #$FF
        beq  .nx
        ldaa 0,x
        anda #1
        cmpa T2
        bne  .nx
        dec  2,x                ; 0 becomes $FF: gone off the left edge
        bpl  .nx
        ldaa 0,x
        bmi  .nx                ; a mine just leaves
        bsr  reenter            ; anything else comes round again
.nx:    inx
        inx
        inx
        inx
        decb
        bne  .lp
        rts
.stars: ldx  #S_STAR
        ldab #6
.sl:    dec  1,x
        bpl  .sn
        ldaa #19                ; re-enter on the right in a random lane
        staa 1,x
        jsr  rnd
        anda #3
        staa 0,x
.sn:    inx
        inx
        decb
        bne  .sl
        rts

; Enemy X got past the ship. It comes back in on the right, now weaving
; toward the ship and shooting, in its own lane or the next one with room.
; Keeps X and B.
reenter:
        pshb
        ldaa 0,x
        oraa #$30
        staa 0,x
        ldaa #1
        staa S_CHAIN
        stx  T4
        ldab #4
        stab T3                 ; lanes left to try
.try:   ldx  T4
        ldaa 1,x
        staa T6
        ldx  #S_EN
.sc:    ldab 2,x
        cmpb #$FF
        beq  .n
        cmpb #19
        blo  .n
        ldab 1,x
        cmpb T6
        beq  .busy              ; someone is entering in that lane
.n:     inx
        inx
        inx
        inx
        cpx  #S_EN+32
        bne  .sc
        ldx  T4
        ldaa #20
        staa 2,x
        pulb
        rts
.busy:  ldx  T4
        ldaa 1,x
        inca
        anda #3
        staa 1,x
        dec  T3
        bne  .try
        pulb                    ; no room anywhere: it is gone after all
        rts

; ---------------------------------------------------------------------
; 4. Spawn
; ---------------------------------------------------------------------
spawn:  ldaa S_FLAGS
        bita #1
        lbne .x
        ldaa S_WAIT
        beq  .try
        deca
        staa S_WAIT
        lbne .x
.try:   ldx  S_SCRP
        ldab 1,x
        stab T0                 ; lane, class and flags
        ldaa #20                ; home cell 20, or 21 if the class is mid-step
        bitb #4
        bne  .cb
        tst  S_PHA
        beq  .h
        inca
        bra  .h
.cb:    tst  S_PHA+1
        beq  .h
        inca
.h:     staa T1
        deca
        staa T2
        andb #3
        stab T3
        clr  T4
        clr  T5                 ; free slot found
        ldx  #S_EN
.sc:    ldaa 2,x
        cmpa #$FF
        bne  .al
        ldd  T4
        bne  .n
        stx  T4
        bra  .n
.al:    ldab 1,x
        cmpb T3
        bne  .n
        cmpa T2
        bhs  .x                 ; no one-cell gap yet: hold the spawn
.n:     inx
        inx
        inx
        inx
        cpx  #S_EN+32
        bne  .sc
        ldx  T4
        beq  .x                 ; pool full
        ldaa T0
        tab
        anda #$F0
        lsrb
        lsrb
        andb #1
        aba
        staa 0,x
        ldaa T3
        staa 1,x
        ldaa T1
        staa 2,x
        jsr  rnd
        anda #$F8               ; timer offset in the top five bits
        oraa #1                 ; one hit
        ldab 0,x
        bitb #$40
        beq  .h1
        oraa #3                 ; armoured: three
.h1:    staa 3,x
        ldaa T0
        bita #8
        beq  .na
        ldaa #2
        ldab #1
        jsr  sndreq             ; dart warning
.na:    ldx  S_SCRP
        inx
        inx
        stx  S_SCRP
        ldaa 0,x
        staa S_WAIT
        bne  .x
        ldaa S_FLAGS
        oraa #1
        staa S_FLAGS
.x:     rts

; ---------------------------------------------------------------------
; 5. Move: ship, shots, explosions
; ---------------------------------------------------------------------
moves:  ldaa S_KEYS
        ldab S_Y
        bita #1
        beq  .nu
        subb S_TUNE
        bcc  .nu
        clrb
.nu:    bita #2
        beq  .nd
        addb S_TUNE
        cmpb #27
        bls  .nd
        ldab #27
.nd:    cmpb S_Y
        beq  .ns
        stab S_Y
        ldaa S_DIRTY
        oraa #1
        staa S_DIRTY
.ns:    ldx  #S_PS              ; player shots hop right
        ldab #3
.ps:    ldaa 1,x
        cmpa #$FF
        beq  .pn
        inca
        cmpa #20
        bne  .pk
        ldaa #$FF
.pk:    staa 1,x
.pn:    inx
        inx
        decb
        bne  .ps
        ldaa S_FIRE             ; auto-fire
        beq  .fr
        deca
        staa S_FIRE
        bne  .nf
.fr:    ldx  #S_PS
.fl:    ldaa 1,x
        cmpa #$FF
        beq  .fp
        inx
        inx
        cpx  #S_PS+6
        bne  .fl
        bra  .nf
.fp:    ldaa S_Y
        adda #2
        lsra
        lsra
        lsra
        staa 0,x
        ldaa #2
        staa 1,x
        ldaa S_TUNE+1
        staa S_FIRE
        ldaa #1
        ldab #1
        jsr  sndreq
.nf:    ldaa S_FLAGS            ; enemy shots hop left on odd ticks, or on every
        bita #$12               ; tick for the boss and in the fast-shot waves
        bne  .eg
        ldaa S_TICK
        lsra
        bcc  .ne
.eg:
        ldx  #S_ES
        ldab #3
.es:    ldaa 1,x
        cmpa #$FF
        beq  .en
        dec  1,x
.en:    inx
        inx
        decb
        bne  .es
.ne:    ldx  #S_EX              ; explosions burn down
        ldab #3
.ex:    ldaa 1,x
        cmpa #$FF
        beq  .xn
        dec  2,x
        bne  .xn
        ldaa #$FF
        staa 1,x
.xn:    inx
        inx
        inx
        decb
        bne  .ex
        rts

; ---------------------------------------------------------------------
; Enemy behaviour: weavers and shooters, or the boss
; ---------------------------------------------------------------------
behave: ldaa S_FLAGS
        bita #2
        lbne boss
        ldx  #S_EN
        ldaa #8
        staa T0
.lp:    ldaa 2,x
        cmpa #$FF
        lbeq .nx
        ldaa 3,x
        lsra
        lsra
        lsra
        adda S_TICK
        staa T1                 ; this enemy's own clock
        ldab 0,x
        bitb #$10
        beq  .nw
        anda #15
        bne  .nw
        ldaa S_Y                ; weaver: one lane toward the ship
        adda #2
        lsra
        lsra
        lsra
        cmpa 1,x
        beq  .nw
        bhi  .down
        ldaa 1,x
        deca
        bra  .try
.down:  ldaa 1,x
        inca
.try:   staa T2
        stx  T4
        ldab 2,x
        stab T3
        ldx  #S_EN
.oc:    cpx  T4
        beq  .on
        ldab 2,x
        cmpb #$FF
        beq  .on
        ldaa 1,x
        cmpa T2
        bne  .on
        subb T3
        incb
        cmpb #2
        bls  .bl                ; someone is within a cell of the target
.on:    inx
        inx
        inx
        inx
        cpx  #S_EN+32
        bne  .oc
        ldx  T4
        ldaa T2
        staa 1,x
        bra  .nw
.bl:    ldx  T4
.nw:    ldab 0,x
        bitb #$20
        beq  .nx
        ldab #31                ; shooter: every 32 ticks, or 16 in a rapid wave
        ldaa S_FLAGS
        bita #$20
        beq  .per
        ldab #15
.per:   andb T1
        bne  .nx
        ldab 2,x                ; it fires from two cells ahead
        cmpb #3
        blo  .nx
        cmpb #20
        bhi  .nx
        stx  T4
        ldaa 1,x
        subb #2
        bsr  eshot
        ldx  T4
.nx:    inx
        inx
        inx
        inx
        dec  T0
        lbne .lp
        rts

; new enemy shot in lane A, cell B (dropped if all three are flying)
eshot:  staa T10
        stab T11
        ldx  #S_ES
.l:     ldaa 1,x
        cmpa #$FF
        beq  .put
        inx
        inx
        cpx  #S_ES+6
        bne  .l
        rts
.put:   ldaa T10
        staa 0,x
        ldaa T11
        staa 1,x
        rts

boss:   ldab S_BOSS+1
        cmpb #$FF
        lbeq .x
        ldaa S_TICK
        cmpb #16
        bls  .fight
        anda #3                 ; arriving: one cell every 4 ticks
        lbne .x
        dec  S_BOSS+1
        rts
.fight: staa T1
        ldaa S_Y
        adda #2
        lsra
        lsra
        lsra
        staa T2                 ; ship lane
        ldaa T1
        anda #7
        bne  .nf
        ldaa S_FLAGS            ; every 8 ticks it hops one lane
        bita #8
        beq  .hunt
        anda #$F7
        staa S_FLAGS
        ldab #2                 ; just hit: uncover the ship's lane
        ldaa T2
        cmpa #1
        bls  .want
        clrb
.want:  cmpb S_BOSS
        beq  .nf
        bhi  .up
        dec  S_BOSS
        bra  .nf
.up:    inc  S_BOSS
        bra  .nf
.hunt:  ldaa T2                 ; otherwise: cover the ship's lane
        cmpa S_BOSS
        bhs  .ge
        dec  S_BOSS
        bra  .nf
.ge:    suba S_BOSS
        cmpa #1
        bls  .nf
        inc  S_BOSS
.nf:    ldaa T1
        anda #7
        cmpa #4
        bne  .x
        ldaa S_BOSS+2
        cmpa #8
        bls  .fire              ; down to its last 8 hits: it fires every 8 ticks,
        ldaa T1
        bita #8
        bne  .x                 ; before that every 16
.fire:  ldaa T2                 ; along the ship's lane
        cmpa S_BOSS
        bhs  .c1
        ldaa S_BOSS
        bra  .c2
.c1:    ldab S_BOSS
        incb
        cba
        bls  .c2
        tba
.c2:    ldab S_BOSS+1
        decb
        jmp  eshot
.x:     rts

; ---------------------------------------------------------------------
; Bomb
; ---------------------------------------------------------------------
bomb:   ldaa S_KEYS
        bita #4
        beq  .x
        ldaa S_BOMBS
        beq  .x
        dec  S_BOMBS
        ldx  #S_EN
        ldab #8
.lp:    ldaa 2,x
        cmpa #$FF
        beq  .nx
        pshb
        ldaa 0,x
        jsr  value
        clra
        jsr  addscore
        jsr  boom
        pulb
.nx:    inx
        inx
        inx
        inx
        decb
        bne  .lp
        ldaa #$FF
        staa S_ES+1
        staa S_ES+3
        staa S_ES+5
        ldaa S_FLAGS
        bita #2
        beq  .s
        ldaa S_BOSS+1
        cmpa #$FF
        beq  .s
        ldaa S_BOSS+2           ; three hits on the boss
        suba #3
        bhi  .hp
        bsr  bossdie
        bra  .s
.hp:    staa S_BOSS+2
.s:     ldaa #4
        ldab #5
        jmp  sndreq
.x:     rts

bossdie:
        clr  S_BOSS+2
        ldd  #100
        jsr  addscore
        ldaa S_BOSS
        ldab S_BOSS+1
        ldx  #S_EX
        staa 0,x
        stab 1,x
        inca
        staa 3,x
        stab 4,x
        deca
        incb
        cmpb #19
        bls  .ok
        ldab #19
.ok:    staa 6,x
        stab 7,x
        ldaa #6
        staa 2,x
        staa 5,x
        staa 8,x
        ldaa #$FF
        staa S_BOSS+1
        ldaa #4
        ldab #5
        jmp  sndreq

; ---------------------------------------------------------------------
; 6. Collisions
; ---------------------------------------------------------------------
colshots:
        ldx  #S_PS
        ldaa #3
        staa T0
.lp:    ldab 1,x
        cmpb #$FF
        beq  .nx
        stx  T2
        stab T4                 ; shot cell
        ldaa 0,x
        staa T5                 ; shot lane
        bsr  hitscan
        ldx  T2
.nx:    inx
        inx
        dec  T0
        bne  .lp
        rts

hitscan:
        ldaa S_FLAGS
        bita #2
        beq  .en
        ldab S_BOSS+1           ; the boss takes hits on its front cells
        cmpb #$FF
        beq  .x
        cmpb T4
        bne  .x
        ldaa T5
        suba S_BOSS
        cmpa #1
        bhi  .x
        ldx  T2
        ldaa #$FF
        staa 1,x
        cmpb #16
        bhi  .x                 ; no damage while it is still arriving
        ldaa S_FLAGS
        oraa #8
        staa S_FLAGS
        dec  S_BOSS+2
        bne  .flash
        jmp  bossdie
.flash: ldaa #2                 ; a short burst in front of it
        staa T11
        ldaa T5
        decb
        jsr  explode
        bra  .dmg
.en:    ldx  #S_EN
        ldab #8
.lp:    ldaa 2,x
        cmpa #$FF
        beq  .nx
        ldaa 1,x
        cmpa T5
        bne  .nx
        ldaa 2,x
        cmpa T4
        beq  .hit
        deca
        cmpa T4
        bne  .nx
        jsr  clsph              ; the cell to its left counts once it has moved
        bne  .hit
.nx:    inx
        inx
        inx
        inx
        decb
        bne  .lp
.x:     rts
.hit:   stx  T6
        ldx  T2
        ldaa #$FF
        staa 1,x                ; the shot is spent
        ldx  T6
        ldaa 0,x
        bmi  .x                 ; a mine just absorbs it
        dec  3,x
        ldaa 3,x
        anda #7
        bne  .dmg
        bsr  kill
.dmg:   ldaa #3
        ldab #2
        jmp  sndreq

; phase of the class of enemy X in A, Z set if 0. Keeps B and X.
clsph:  ldaa 0,x
        lsra
        ldaa S_PHA
        bcc  .r
        ldaa S_PHA+1
.r:     tsta
        rts

; enemy X destroyed by a shot: score, chain, explosion
kill:   ldaa 0,x
        bsr  value
        ldaa S_CHAIN
        mul
        bsr  addscore
        ldaa S_CHAIN
        cmpa #4
        bhs  boom
        inc  S_CHAIN
; explosion where enemy X is, then free its slot. Keeps X.
boom:   ldaa #6
        staa T11
        ldaa 1,x
        ldab 2,x
        pshx
        bsr  explode
        pulx
        ldaa #$FF
        staa 2,x
        rts

; score value of an enemy with flags A, in B. Keeps X.
value:  clrb
        tsta
        bmi  .r
        ldab #5
        bita #$40
        bne  .r
        ldab #3
        bita #$20
        bne  .r
        ldab #2
        bita #$10
        bne  .r
        ldab #1
.r:     rts

; add D tens to the score, stopping at 32767. Keeps X.
addscore:
        addd S_SCORE
        bpl  .ok
        ldd  #$7FFF
.ok:    std  S_SCORE
        rts

; explosion in lane A, cell B, lasting T11 ticks
explode:
        cmpb #19
        bls  .ok
        ldab #19
.ok:    staa T10
        ldx  #S_EX
.lp:    ldaa 1,x
        cmpa #$FF
        beq  .put
        inx
        inx
        inx
        cpx  #S_EX+9
        bne  .lp
        rts
.put:   ldaa T10
        staa 0,x
        stab 1,x
        ldaa T11
        staa 2,x
        rts

colship:
        ldaa S_INV
        lbne .x
        ldx  #S_EN
        ldab #8
.lp:    ldaa 2,x
        cmpa #1
        beq  .col
        cmpa #2
        bne  .nx
        jsr  clsph
        beq  .nx
.col:   ldaa 1,x                ; rows 8n+1..8n+5 of the enemy against the ship's five
        asla
        asla
        asla
        adda #5
        cmpa S_Y
        blo  .nx
        suba #4
        staa T0
        ldaa S_Y
        adda #4
        cmpa T0
        blo  .nx
        ldaa 0,x
        bmi  shiphit            ; a mine stays
        jsr  boom
        bra  shiphit
.nx:    inx
        inx
        inx
        inx
        decb
        bne  .lp
        ldx  #S_ES
        ldab #3
.sl:    ldaa 1,x
        cmpa #1
        bne  .sn
        ldaa 0,x                ; a shot counts over the five rows of its + glyph,
        asla                    ; 8n+1..8n+5. (Counting only the middle row left
        asla                    ; three bands of rows where no shot could ever hit.)
        asla
        adda #5
        cmpa S_Y
        blo  .sn
        suba #4
        staa T0
        ldaa S_Y
        adda #4
        cmpa T0
        blo  .sn
        ldaa #$FF
        staa 1,x
        bra  shiphit
.sn:    inx
        inx
        decb
        bne  .sl
.x:     rts

shiphit:
        dec  S_LIVES
        bne  .alive
        ldaa #1
        staa S_RES
.alive: ldaa #21
        staa S_INV
        ldaa #1
        staa S_CHAIN
        ldaa #5
        ldab #3
; ask for sound A lasting B ticks; a higher number wins
sndreq: cmpa S_SND
        blo  .x
        staa S_SND
        stab S_SNDT
.x:     rts

; wave cleared? (script done and nothing left; or the boss is gone)
wavend: ldaa S_RES
        cmpa #$FF
        bne  .x
        ldaa S_EX+1
        anda S_EX+4
        anda S_EX+7
        anda S_ES+1
        anda S_ES+3
        anda S_ES+5
        cmpa #$FF
        bne  .x
        ldaa S_FLAGS
        bita #2
        beq  .norm
        ldaa S_BOSS+1
        cmpa #$FF
        bne  .x
        bra  .clear
.norm:  bita #1
        beq  .x
        ldx  #S_EN
        ldaa 2,x
        anda 6,x
        anda 10,x
        anda 14,x
        anda 18,x
        anda 22,x
        anda 26,x
        anda 30,x
        cmpa #$FF
        bne  .x
.clear: ldab S_LIVES            ; 10 tens for each life left
        ldaa #10
        mul
        jsr  addscore
        clr  S_RES
.x:     rts

; ---------------------------------------------------------------------
; 10. Sound: at most one tone a tick, never longer than 10 ms
; ---------------------------------------------------------------------
sound:  ldab S_SNDT
        beq  .x
        ldaa S_SND
        cmpa #3
        bne  .tab
        cmpb #1
        bne  .tab
        ldd  #500               ; second half of the hit sound
        ldx  #10
        bra  .play
.tab:   tab
        aba
        aba
        tab
        ldx  #sndtab-3
        abx
        ldd  0,x
        pshb
        psha
        ldab 2,x
        clra
        xgdx
        pula
        pulb
.play:  os   BZ$TONE
        dec  S_SNDT
        bne  .x
        clr  S_SND
.x:     rts

; pitch (the D of BZ$TONE) and length in ms
sndtab: fdb  100                ; 1 shot
        fcb  4
        fdb  60                 ; 2 dart warning
        fcb  8
        fdb  300                ; 3 enemy hit, first tick
        fcb  10
        fdb  800                ; 4 bomb
        fcb  10
        fdb  1200               ; 5 ship hit
        fcb  10

; ---------------------------------------------------------------------
; 7. UDGs
; ---------------------------------------------------------------------
udgs:   ldaa S_FLAGS
        bita #2
        beq  .a
        ldaa S_DIRTY            ; the boss owns slots 2..5
        anda #$F9
        staa S_DIRTY
.a:     ldaa S_DIRTY
        bita #1
        beq  .ca
        bsr  udgship
.ca:    ldaa S_DIRTY
        bita #2
        beq  .cb
        ldx  S_SPRA
        ldaa S_PHA
        ldab #2
        bsr  udgclass
.cb:    ldaa S_DIRTY
        bita #4
        beq  .cs
        ldx  S_SPRB
        ldaa S_PHA+1
        ldab #4
        bsr  udgclass
.cs:    ldaa S_DIRTY
        bita #8
        beq  .ce
        bsr  udgstar
.ce:    clr  S_DIRTY
        jmp  udgexpl

; the ship's five rows in a 16-row strip: slots 0 (upper) and 1 (lower)
udgship:
        bsr  clrtmp
        ldab S_Y
        andb #7
        ldx  #S_TMP
        abx
        ldaa #16
        staa 0,x
        staa 4,x
        ldaa #28
        staa 1,x
        staa 3,x
        ldaa #31
        staa 2,x
        ldx  #S_TMP
        clra
        clrb
        os   DP$UDG
        ldx  #S_TMP+8
        clra
        ldab #1
        os   DP$UDG
        rts

clrtmp: ldx  #S_TMP
        ldab #16
.c:     clr  0,x
        inx
        decb
        bne  .c
        rts

; X = sprite (two 5-column frames), A = phase, B = slot of the left part.
; The 10-column strip is 5-phase blank columns, the sprite, phase blank columns.
udgclass:
        pshb
        staa T1
        ldaa S_TICK
        bita #8
        beq  .f0
        ldab #5
        abx
.f0:    stx  T2
        bsr  clrtmp
        ldab #5
        subb T1
        ldx  #S_TMP
        abx
        stx  T4
        ldab #5
.cp:    ldx  T2
        ldaa 0,x
        inx
        stx  T2
        ldx  T4
        staa 0,x
        inx
        stx  T4
        decb
        bne  .cp
        pulb
        pshb
        ldx  #S_TMP
        ldaa #1
        os   DP$UDG
        pulb
        incb
        ldx  #S_TMP+5
        ldaa #1
        os   DP$UDG
        rts

; one pixel that steps left through the cell: slot 6
udgstar:
        bsr  clrtmp
        ldab #4
        subb S_PHA+2
        ldx  #S_TMP
        abx
        ldaa #$20
        staa 0,x
        ldx  #S_TMP
        ldaa #1
        ldab #6
        os   DP$UDG
        rts

; slot 7 follows the newest explosion
udgexpl:
        clra
        ldx  #S_EX
        ldab 1,x
        cmpb #$FF
        beq  .n1
        ldaa 2,x
.n1:    ldab 4,x
        cmpb #$FF
        beq  .n2
        cmpa 5,x
        bhs  .n2
        ldaa 5,x
.n2:    ldab 7,x
        cmpb #$FF
        beq  .n3
        cmpa 8,x
        bhs  .n3
        ldaa 8,x
.n3:    tsta
        beq  .x
        nega
        adda #6
        lsra                    ; frame 0, 1 or 2
        cmpa S_EXF
        beq  .x
        staa S_EXF
        asla
        asla
        asla
        tab
        ldx  #expltab
        abx
        clra
        ldab #7
        os   DP$UDG
.x:     rts

; the boss sprite: four 5-column patterns into slots 2..5
bossudg:
        ldx  S_SPRA
        ldab #2
.lp:    pshb
        pshx
        ldaa #1
        os   DP$UDG
        pulx
        ldab #5
        abx
        pulb
        incb
        cmpb #6
        bne  .lp
        rts

expltab:
        fcb  0,0,4,14,4,0,0,0
        fcb  0,21,14,27,14,21,0,0
        fcb  17,0,10,0,10,0,17,0

; ---------------------------------------------------------------------
; 8. Compose the 80-byte frame: stars, enemies, shots, explosions, ship
; ---------------------------------------------------------------------
compose:
        ldx  #S_FB
        ldaa #32
        ldab #80
.f:     staa 0,x
        inx
        decb
        bne  .f
        ldx  #S_STAR
        ldd  #$0602             ; 6 records of 2 bytes
        std  T0
        ldaa #6
        jsr  drawrecs
        ldaa S_FLAGS
        bita #2
        bne  .boss
        ldx  #S_EN
        ldaa #8
        staa T0
.en:    ldab 2,x
        cmpb #$FF
        beq  .enx
        stx  T2
        ldaa 0,x
        anda #1
        asla
        adda #2
        staa T4                 ; character of the left part
        jsr  clsph
        beq  .right             ; phase 0: the left part is blank
        ldab 2,x
        beq  .right
        decb
        cmpb #19
        bhi  .right
        ldaa 1,x
        jsr  cellptr
        ldaa T4
        staa 0,x
        ldx  T2
.right: ldab 2,x
        cmpb #19
        bhi  .enx
        ldaa 1,x
        jsr  cellptr
        ldaa T4
        inca
        staa 0,x
        ldx  T2
.enx:   inx
        inx
        inx
        inx
        dec  T0
        bne  .en
        bra  .shots
.boss:  ldab S_BOSS+1
        cmpb #$FF
        beq  .shots
        ldaa #2
        staa T4
        ldaa S_BOSS
        staa T5
.brow:  ldab S_BOSS+1
        cmpb #19
        bhi  .b2
        ldaa T5
        bsr  cellptr
        ldaa T4
        staa 0,x
.b2:    ldab S_BOSS+1
        incb
        cmpb #19
        bhi  .b3
        ldaa T5
        bsr  cellptr
        ldaa T4
        inca
        staa 0,x
.b3:    inc  T5
        ldaa T4
        adda #2
        staa T4
        cmpa #6
        bne  .brow
.shots: ldx  #S_PS
        ldd  #$0302
        std  T0
        ldaa #'-'
        bsr  drawrecs
        ldx  #S_ES
        ldd  #$0302
        std  T0
        ldaa #'+'
        bsr  drawrecs
        ldx  #S_EX
        ldd  #$0303
        std  T0
        ldaa #7
        bsr  drawrecs
        ldaa S_INV              ; the ship flickers while it cannot be hit
        lsra
        bcs  .x
        ldaa S_Y
        lsra
        lsra
        lsra
        psha
        ldab #1
        bsr  cellptr
        clr  0,x
        pula
        ldab S_Y
        andb #7
        cmpb #4
        blo  .x
        inca
        ldab #1
        bsr  cellptr
        ldaa #1
        staa 0,x
.x:     rts

; X = frame buffer address of lane A, cell B
cellptr:
        pshb
        ldab #20
        mul
        tsx
        addb 0,x
        ins
        ldx  #S_FB
        abx
        rts

; draw character A for T0 records of T1 bytes (lane, cell, ...) at X
drawrecs:
        staa T4
.lp:    stx  T2
        ldab 1,x
        cmpb #$FF
        beq  .n
        ldaa 0,x
        bsr  cellptr
        ldaa T4
        staa 0,x
.n:     ldx  T2
        ldab T1
        abx
        dec  T0
        bne  .lp
        rts

; ---------------------------------------------------------------------
; 9. Present: write only the cells that changed, straight to the LCD.
; Same protocol as the ROM: interrupts off, wait for the busy flag.
; ---------------------------------------------------------------------
present:
        ldx  #S_FB
        clrb
.lp:    ldaa 0,x
        cmpa 80,x
        beq  .same
        staa 80,x
        stx  T2
        ldx  #lcdtab
        abx
        ldaa 0,x                ; "set address" command for this cell
        ldx  T2
        staa T0
        tpa
        staa T1
        sei
        ldaa T0
.w1:    tst  LCD_CTRL
        bmi  .w1
        staa LCD_CTRL
        ldaa 0,x
.w2:    tst  LCD_CTRL
        bmi  .w2
        staa LCD_DATA
        ldaa T1
        tap
.same:  inx
        incb
        cmpb #80
        bne  .lp
        rts

; LCD address commands for the 80 cells, row major
lcdtab: fcb  $80,$81,$82,$83,$88,$89,$8A,$8B,$8C,$8D,$8E,$8F,$98,$99,$9A,$9B,$9C,$9D,$9E,$9F
        fcb  $C0,$C1,$C2,$C3,$C8,$C9,$CA,$CB,$CC,$CD,$CE,$CF,$D8,$D9,$DA,$DB,$DC,$DD,$DE,$DF
        fcb  $84,$85,$86,$87,$90,$91,$92,$93,$94,$95,$96,$97,$A0,$A1,$A2,$A3,$A4,$A5,$A6,$A7
        fcb  $C4,$C5,$C6,$C7,$D0,$D1,$D2,$D3,$D4,$D5,$D6,$D7,$E0,$E1,$E2,$E3,$E4,$E5,$E6,$E7
core_end:
