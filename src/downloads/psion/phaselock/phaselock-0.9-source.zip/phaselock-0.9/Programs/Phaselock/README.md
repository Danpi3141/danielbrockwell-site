# Phaselock

A side-scrolling shooter for the Psion Organiser II LZ and LZ64 that moves the stars, the enemies and the ship one pixel at a time at 20 frames a second. One machine-code routine runs a whole wave; OPL does the title, the wave data, the status cards and the high scores.

Built from *LZ64 Machine-Code Shooter — Technical Spec* (15 Nov 2026). Milestones 1 to 6 are done and tested in the emulator. Milestone 7, the pass on a real LZ64, is still to do: the emulator cannot show LCD smear, real sound or battery behaviour.

## Play it

**In Jape.** Select model **LZ64 (64k)**, then **Select OPK file...** → `PHASE.opk` → type a name → **Create** → **Slot B**. On the Organiser: **Prog → Run**, MODE until it shows `B:`, type `PHASE`, EXE. Loading takes about 2.5 seconds.

**On a real LZ64 with RPBOOT.** In Psi2Win set **Folder** to `psion` and click **Start!**, then run `RPBOOT` on the Organiser and pick a pack (A: needs about 14K free for the files, plus about 8K while the game runs). When it finishes, run `PHASE`.

| Key | In a wave |
| --- | --- |
| UP / DOWN | Move, 2 pixels a tick while held |
| EXE | Bomb: clears every enemy and enemy shot. One per wave. Let go of the arrow first, the keyboard reports one key at a time |
| MODE | Pause and show the status card |
| ON/CLEAR | Quit to the title |

The ship fires by itself. Three lives, eight waves and a boss, about ten minutes. If no key is pressed for 30 seconds the game pauses itself.

Two rules make it hard:

- **Nothing gets away.** An enemy you let past comes back in on the right, now weaving toward your lane and shooting. A wave ends only when everything in it is destroyed. Mines are the exception: they cannot be shot and just leave.
- **Shots fill the lane.** An enemy shot hits anywhere over the five rows of its `+`, so the only way to dodge is to leave that lane.

## Build and test

```bash
python build.py --psion
```

```bash
node tests/run_all.js
```

`build.py` assembles the core, generates the loader and wave procedures into `build/opl`, and writes `PHASE.opk` and, with `--psion`, the `psion` folder. `run_all.js` takes about four minutes; `--quick` takes one.

| Folder | What is in it |
| --- | --- |
| `src/core.asm` | The machine-code core |
| `src/boot.asm` | Hex decoder and relocator used by the loader |
| `src/opl` | The OPL shell: `PHASE` (start here), title, game loop, cards, scores |
| `tools/asm6303.py` | Two-pass 6303 assembler with fix-up lists |
| `tools/corebuild.py` | Assembles at three origins and compares the outputs to find the fix-ups |
| `tools/model.py` | Reference model of the core: strip builders, collision tests, one frame of logic |
| `tools/waves.py`, `tools/sprites.py` | Wave scripts and sprite art: edit these to tune the game |
| `tests/difficulty.js`, `tests/profile.js` | How far three kinds of player get on three lives, and the lives the bot loses in each wave |
| `tools/emu.js` | The Jape emulator sources run under Node, with breakpoints, cycle counts, key presses and LCD read-out |
| `tests` | The test suite; `tests/milestones` holds the milestone 1 and 2 measurements |

## How it was tested

Everything runs on the Jape emulator code under Node (`tools/emu.js`), about 100 times faster than real time, on the LZ64 4.6a and LZ 4.6 ROM images. The end-to-end test also passes on the other English LZ and LZ64 ROMs in `Emulator/roms` (4.2 to 4.6b).

| Test | What it shows |
| --- | --- |
| `t_model.js` | The real core and the Python model agree on every byte of state, the 80 LCD characters, the eight UDG patterns and the tone played, after every frame, for all nine waves with random keys and with a test bot. About 127,000 frames in a full run. One run shortens the tick so that interrupts land inside the logic |
| `t_keys.js` | Through the real keyboard buffer: held-key steering, the bomb, pause and resume with the state intact, ON/CLEAR at 20 random moments with the three keyboard variables back at their defaults, the 30-second idle pause, every exit path, a refused state block |
| `t_safety.js` | Millions of memory writes made by core instructions all went to the state block, the scratch words, the three keyboard variables, the LCD, the output words or the stack. No access to the bank-switch addresses |
| `t_udg.js` | UDGs read back through `DP$UDG` match the model and the LCD |
| `t_timing.js` | Every frame fits its tick and OVERRUN is 0 after ten minutes of wave 8 |
| `t_romtran.js` | The Organiser's own translator accepts all 17 procedures and produces the same object code as the PC build, byte for byte |
| `t_game.js` | The real pack from title to boss, played by the bot with real key presses: loader, cards, pause, quit, victory, name entry, and the high score still there after a restart |

## Measured, replacing the spec's targets

OS service costs in CPU cycles (`tests/milestones/m2_costs`); a tick is 46,080:

| Service | Cycles |
| --- | --- |
| `DP$PRNT` of 80 characters | 46,540 |
| `DP$STAT` + `DP$EMIT` for one cell | 1,069 |
| `DP$UDG`, 5 columns / 8 rows | 1,575 / 1,066 |
| `BZ$TONE`, 4 ms / 10 ms | 4,106 / 10,262 |
| `KB$TEST` with no key / `KB$BREK` | 573 / 191 |

A full-screen print costs more than a whole tick, so renderer R1 is out; R2 would cost a whole tick whenever a class steps a cell. The core uses R3, writing changed cells straight to the LCD.

Frame cost over ten minutes of wave 8, and in a stress wave (eight enemies in two classes at 40 px/s, ship moving every tick, bombs):

| Stage | Wave 8 average | Worst seen |
| --- | --- | --- |
| Game logic | 2,040 | 4,470 |
| UDG redefinition | 8,270 | 12,490 |
| Compose | 2,380 | 3,460 |
| Present (R3) | 2,020 | 3,470 |
| Sound | 2,500 | 13,420 |
| **Whole frame** | **17,200 (37%)** | **34,000 (74%)** |

## Where it differs from the spec, and why

1. **Renderer R3 from the start**, for the reason above.
2. **`KBB_DLAY` is set to 0, not 1.** With 1 a held key reports, skips a tick, then repeats. With 0 it reports every tick and stops the tick after release.
3. **The core is 3,083 bytes, not under 1,500.** `M%()` is 1,701 words (core plus fix-up lists) and the state block is 289 bytes in `S%(145)`.
4. **Two fix-up lists.** State variables are reached by absolute address, so the loader also patches the core for where `S%()` is. The core checks the STATE parameter against that and returns 4 if they differ.
5. **The frame wait sleeps once, then watches the counter.** Sleeping in a loop lost a frame whenever the once-a-second clock interrupt woke the core just before the tick. The timing test caught this.
6. **Every key in the buffer is acted on**, not only the last, so a bomb press is not lost behind an arrow. The bomb fires on EXE going down.
7. **Enemies spawn at home cell 21 when their class is mid-step**, so they always slide in a pixel at a time. The one-cell gap rule is applied across both classes.
8. **The boss.** It takes 24 hits, not 12; its shots hop every tick; it cannot be hurt while arriving; it hops away after a hit; it fires every 16 ticks, every 8 for its last 8 hits. Its hit points are a byte in its wave header.
9. **A stall of ten ticks or more pauses the game**, so an alarm ringing mid-wave ends in a clean status card. The 30-second idle pause (the spec's fallback) is in for the same reason.
10. **A ship-hit tone was added** (D = 1200 for three ticks).
11. **High scores are in `A:PHASEHS`**, four places, not on the pack: a Datapak would lose space on every update.
12. **Sprites animate**: two frames each, swapped every 8 ticks (10 bytes a sprite). This answers the third open question with yes.
13. **Own assembler.** `tools/asm6303.py` runs on Windows; org2asm needs Tcl and Linux. The fix-ups come from assembling at three origins and comparing, as the spec describes.
14. **The loader uses the machine-code hex decoder from the start.**
15. **Scoring details the spec leaves open.** A mine leaving does not reset the chain. Bombed enemies score their base value. Ramming an enemy destroys it for no score. The boss is worth 100 tens. If the last life goes in the same frame as the boss, the game is over.
16. **The top-level procedure is `PHASE`** (names are limited to eight characters).

## Made harder after the first play-through

The first build followed the spec's rules and was far too easy: a player who sat in one lane and only side-stepped beat the boss in four runs out of five, and a ship that never moved survived to wave 4. Auto-fire makes the ship's own lane safe, and nothing made you leave it. These changes go beyond the spec:

17. **Enemies that get past come back** as weaving shooters, and a wave ends only when all are destroyed. The spec let them leave with no penalty beyond the chain.
18. **Enemy shots count over five rows in every wave.** With the spec's one-row test the rows y = 4–6, 12–14 and 20–22 could never be hit by a shot.
19. **Faster, denser waves.** Class A runs at 20, 20, 25, 20, 25, 25, 30 and 30 px/s in waves 1 to 8 (the spec has 10, 10, 15, 15, 20, 20, 25, 30), class B drones and crabs at 15, and every wait is scaled by 0.7 to 0.85. Shooters appear from the end of wave 1.
20. **Two per-wave switches in the wave header.** From wave 5 shooters fire every 16 ticks instead of 32; in waves 7 and 8 enemy shots hop every tick.

Measured with `tests/difficulty.js` on three lives, six runs each:

| Player | First build | Now |
| --- | --- | --- |
| Never touches a key | Lost on wave 4 | Lost on wave 1, after about 20 seconds |
| Sits in one lane, side-steps threats | Beat the boss 4 runs in 5 | Lost on waves 3 to 5 |
| Test bot: dodges and hunts the nearest enemy | Lost on wave 8, sometimes beat the boss | Lost on wave 5 every time |

With lives to spare the bot loses about 0, 0, 0, 2, 2, 4, 3, 6 lives in waves 1 to 8 and 1 on the boss (`tests/profile.js`). The bot has perfect reactions and no plan, so treat these as a rough guide: no person has played this build yet.

To tune: each wave in `tools/waves.py` has its two speeds, a `pace` that scales every wait, and the `fast` and `rapid` switches; the boss has `hp`. Rebuild with `python build.py --psion`.

## Left for the hardware pass

- **LCD response.** One-pixel steps at 20 frames a second may smear on the real panel.
- **LCD busy flag.** The emulator's LCD is never busy. The core waits on the flag the same way the ROM does, but this path has not run for real.
- **Sound and battery.** Tone lengths and the cost of running awake about a third of each tick.
- **Jape and interrupts.** Jape drops a timer interrupt that comes due while interrupts are masked; real hardware keeps it pending. The tests run both ways. In Jape this can cost the odd tick when the clock interrupt coincides with the frame tick.
- **Overtaking.** A fast class B enemy passing a class A enemy in the same lane blanks part of it for a few ticks, as the spec expects.
- **Difficulty.** Only measured with test players so far; see the section above.

If a frame ever misses its tick, the status card shows `LATE` and the count.

## About this repository

One of the Psion Organiser II projects on Forgejo (`Daniel/Psion-*`). The build and test scripts expect the PsionII workspace layout:

```
PsionII/
  Emulator/          Jape, Jaap Scherphuis's emulator, with its ROM images (not in any repo:
                     https://www.jaapsch.net/psion/jape/jape.htm)
  Tools/             Daniel/Psion-Tools (opltran, opl2opk, RPBOOT/RPLOAD, ...)
  Programs/NAME/     this repository
```

`build/` is not committed: the build scripts recreate it.
