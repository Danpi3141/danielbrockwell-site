Phaselock 0.9 for the Psion Organiser II (LZ and LZ64)
MIT licence: see LICENSE.

These are the program's files, ready for an Organiser: translated procedures (.OB3)
and the loader that copies them onto a pack over a Comms Link.

Loading them
  1. Unzip this folder on the PC.
  2. In Psi2Win, set Folder to this folder and click Start!.
  3. If RPBOOT is not on the Organiser yet: COMMS > RECEIVE > PROCEDURE, type RPBOOT,
     EXE. Then PROG > EDIT RPBOOT, MODE > TRAN.
  4. PROG > RUN RPBOOT. Choose the pack to copy the program to (B: or C: is best) and
     wait until it says NOW RUN B:PHASE (or whichever pack you chose).
  5. PROG > RUN PHASE on that pack.
  RPBOOT uses RPLOAD on an LZ or LZ64 and RPLOADCM on a CM, XP or LA. Delete A:RPLOAD
  afterwards to free its memory.

Files
  PHASE.OB3
  PLCARD_.OB3
  PLGAME.OB3
  PLHSRD.OB3
  PLHSWR.OB3
  PLHX.OB3
  PLLD1.OB3
  PLLD2.OB3
  PLLD3.OB3
  PLLD4.OB3
  PLLOAD.OB3
  PLOVER.OB3
  PLPNAM.OB3
  PLPSC.OB3
  PLSCORE.OB3
  PLTITLE_.OB3
  PLWAVE.OB3
  RPBOOT.OPL
  RPDATA.ODB
  RPLOAD.OB3
  RPLOADCM.OB3

More: https://danielbrockwell.uk/psion/getting-started/
