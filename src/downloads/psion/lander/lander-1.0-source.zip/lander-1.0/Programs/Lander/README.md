# Lunar Lander for the Psion LZ64

A single-screen Lunar Lander in OPL for the Psion Organiser II LZ64 (it also runs on the 32K LZ).
The lander moves down one pixel at a time across a 75 × 32 pixel sky, using two UDGs that are redefined as it falls.
Land gently on the pad with a four-step throttle and side thrusters before the fuel runs out.

Built from *Lunar Lander for the Psion LZ64 — Game Spec* (14 Nov 2026). Changes from the spec are listed at the end.

## Playing it

**Jape:** Select OPK file... → `LANDER.opk` → type a name → Create → Slot B.
**Organiser:** Prog → Run, press MODE until the prompt shows `B:`, type `LANDER`, EXE.

### Putting it on your LZ64 with RPBOOT

`psion/` holds the 9 procedures already translated (`.OB3`), the loader `RPLOAD.OB3`, its file list `RPDATA.ODB`, and `RPBOOT.OPL`.

1. In Psi2Win, set **Folder** to `Programs/Lander/psion` and click **Start!**.
2. On the Organiser: **PROG → RUN** `RPBOOT`. Pick the pack to copy the game to.
3. When it says `NOW RUN B:LANDER` (or whichever pack), **PROG → RUN** `LANDER` on that pack.

The game takes about 11.7K. `psion-small/` has the same procedures without their source text (about 5K) if memory is tight; they play identically but can't be edited on the Organiser.
`python build.py --psion` rebuilds both folders.

### The screen

```
     12345678901234567890
  1    .            F 187      fuel
  2        A    .   Vv 22      vertical speed: v falling, ^ rising
  3      /#\        H>  6      horizontal speed: < left, > right
  4  ___/###\_==__  T2OK       throttle 0-3, OK = safe to land now
```

### Keys

| Key | Action |
| --- | --- |
| UP / DOWN | Throttle up / down one step (0–3). It stays where you leave it |
| LEFT / RIGHT | One side burst: sideways speed changes by 16, costs 2 fuel |
| ON/CLEAR | Pause. Q quits the game (the score still counts), any other key carries on |

On the title screen: EXE (or SPACE) plays, S switches the engine and thruster sound on and off, H shows the keys, ON/CLEAR quits.

### Rules

- Gravity adds 2 to the downward speed every tick (5 ticks a second). Throttle 1 burns 1 fuel and gives 1 thrust, 2 gives 2 (holds your speed), 3 burns 4 and gives 4 (brakes or climbs).
- Land on the pad with a downward speed of 24 or less and a sideways speed of 8 or less (`OK` shows on the HUD). Anything else is a crash.
- Each landing scores the fuel left plus 25 × level. You have 3 ships; a crash replays the level with new terrain.
- Each level has less fuel (500, then 25 less a level, never below 275), a narrower pad (3 wide on levels 1–2, 2 on 3–4, then 1) and more starting drift (up to 32).
- The best score is kept in the data file `A:LANDER`.

## Files

| Path | What it is |
| --- | --- |
| `LANDER.opk` | Release pack image (16K Datapak): translated procedures plus source |
| `src/*.opl` | The 9 procedures; `LANDER` is the one to run |
| `build.py` | Builds `LANDER.opk`; `--psion` also writes `psion/` and `psion-small/`; `--dev` builds `LANDER-dev.opk` with the test procedures and debug hooks; `--source-only` builds an untranslated pack for checking the Organiser's own translator |
| `tools/sim.py` | PC model of the game rules (terrain generator, physics, touchdown), scripted pilots, and the generator for `tests/LTEST.opl` |
| `tools/jape_helpers.js` | Browser-side helpers for driving Jape: keys, reading the LCD and UDGs as data, an autopilot |
| `tests/LTEST.opl` | Replays 9 scripted flights through the real `LPLAY%` and prints the final state, plus one timed real-time flight |
| `tests/LBENCH.opl` | The spec's bench test: `BEEP` timing, the frame counter rate, the cost of the long `UDG` lines |

```bash
python build.py --psion
```
```bash
python tools/sim.py
```
```bash
python tools/sim.py --scenarios
```

Lines containing `REM DEBUG` are test hooks (scripted keys, a fixed start, tick timings shown on the level banner). The release build removes them.

## How it was tested

All in Jape on the LZ64 ROM (4.6a):

- **Physics against the model.** `tests/LTEST` flies 9 scripted flights through the real `LPLAY%`: free fall, too fast onto the pad, an efficient landing, the same landing spoiled by one late side burst, a cautious landing on a raised pad, a landing on a 1-wide pad between peaks, flying into a peak, running out of fuel while climbing against the ceiling, and bouncing off both side walls. Result, tick count, fuel, position, both speeds and the final cell matched `tools/sim.py` exactly in every one.
- **Speed.** A real-time flight took exactly 4.00 frames per tick, i.e. the spec's 5 ticks a second. A tick's work averages about 0.5 frames (25 ms) and never exceeded 2 frames (100 ms).
- **The Organiser's own translator** accepted all 9 procedures from source, including the 181- and 189-character `UDG` lines, and produced object code byte-for-byte identical to `LANDER.opk`.
- **Bench test:** `$20CC` is the low byte of the 50 ms frame counter (100 counts in 5 clock seconds); the two long `UDG` lines cost 22 ms together. Redefining a UDG changes the characters already on screen, and `PRINT CHR$(0);` shows slot 0.
- **Full games** flown by an autopilot that reads the LCD and the UDG RAM and presses keys like a player: title screen, help, sound toggle, level banners, landings on low and raised pads with the flag planted, crashes with the explosion and the ground restored, ships counting down, game over, a new best score saved to `A:LANDER` and shown on the title screen.

Not checked: sound. Jape doesn't make `BEEP` take any time, so the spec's question of whether the first `BEEP` value is milliseconds can only be answered on the real machine (`BEEP 1000,300` should last a second). The in-flight beeps are 5 ms (engine, side burst) and 20 ms (low fuel, every 8th tick), so they can't slow the game much either way.

## Changes from the spec

| Spec | Built | Why |
| --- | --- | --- |
| `LQ%:` procedure looks up the terrain under the lander | Inlined into `LPLAY%` (4 lines) | Each call costs about 100 ms (the procedure is reloaded from the pack), so every line change took up to 250 ms and the lander stuttered; inlined, the slowest tick is 100 ms |
| `LANDER:` plays one game and stops | Title screen (play, sound, help, quit), a level/ships/score/fuel banner before each flight, and back to the title after game over | Listed in the spec as "not in the listing yet" |
| No pause key; `ESCAPE ON` while developing | `ESCAPE OFF`; ON/CLEAR pauses and Q quits, ending the game | Also on the spec's to-do list; errors restore `ESCAPE ON` and are passed on so the Organiser names the culprit |
| Side-burst and low-fuel beeps not in the listing | Added (`BEEP 5,800` per burst, `BEEP 20,300` every 8th tick under 60 fuel) | From the spec's sound table |
| Engine rumble always on | Engine and thruster beeps follow the title screen's S toggle | The spec suggested a sound option |
| `LHISC:` ends with `GET` | Waits half a second and empties the key buffer first | Keys pressed during the crash would otherwise skip the score screen |
| `%Q` style character codes | Plain numbers (`81`, `113`, ...) | `Tools/opltran.py` rejects `k%=%Q` as a percentage operator |

## About this repository

One of the Psion Organiser II projects on Forgejo (`Daniel/Psion-*`). The build and test scripts expect the PsionII workspace layout:

```
PsionII/
  Emulator/          Jape, Jaap Scherphuis's emulator, with its ROM images (not in any repo:
                     https://www.jaapsch.net/psion/jape/jape.htm)
  Tools/             Daniel/Psion-Tools (opltran, opl2opk, RPBOOT/RPLOAD, ...)
  Programs/NAME/     this repository
```

`build/` is not committed: the build scripts recreate it.
