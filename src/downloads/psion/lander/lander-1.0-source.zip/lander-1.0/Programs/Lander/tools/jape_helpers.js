// Helpers for driving Jape from the browser console / test harness.
// Load in the page with: eval(await (await fetch('/Programs/Lander/tools/jape_helpers.js')).text())
window.H = {
  gen: 0,
  sleep: ms => new Promise(r => setTimeout(r, ms)),
  // LCD as 4 strings of 20; UDG codes 0-7 shown as subscript digits
  lcd() {
    const s = psion.createSnapshot(); const a = [];
    for (let i = 0; i < 400; i++) a.push(s.readByte());
    const sub = '₀₁₂₃₄₅₆₇'; const out = [];
    for (let l = 0; l < 4; l++) {
      let t = '';
      for (let c = 0; c < 20; c++) { const b = a[45 + screen2mem4[l * 20 + c]]; t += b < 8 ? sub[b] : String.fromCharCode(b); }
      out.push(t);
    }
    return out;
  },
  async press(key, hold = 150, gap = 100) {
    const g = H.gen;
    const ev = { code: 'K_' + key, key, shiftKey: false, preventDefault() {} };
    psion.handleKeyDown(ev); await H.sleep(hold); psion.handleKeyUp(ev); await H.sleep(gap);
    if (g !== H.gen) throw 'stale';
  },
  async type(s) { for (const ch of s) await H.press(ch); },
  async waitFor(re, ms = 20000, g) {
    const t = Date.now();
    while (Date.now() - t < ms) {
      if (g !== undefined && g !== H.gen) throw 'stale';
      const l = H.lcd().join('\n'); if (re.test(l)) return l; await H.sleep(100);
    }
    throw 'timeout: ' + H.lcd().join('|');
  },
  async lz64() {
    typelist.selectedIndex = [...typelist.options].findIndex(o => /LZ64/.test(o.text));
    typeChanged(); selectModel(); await H.sleep(1500);
    // the first ON press after a reset is sometimes missed: retry until the language menu shows
    for (let i = 0; i < 5 && !/LANGUAGE|English/.test(H.lcd().join('')); i++) await H.press('Escape', 250, 2500);
    await H.waitFor(/LANGUAGE|English/, 8000);
    await H.press('Enter', 250, 1500);
  },
  async loadPack(url, name, slot) {
    const pkdef = { name, filename: url + '?t=' + Date.now() };
    Packs.push(pkdef); createPackList(); packlist.selectedIndex = packlist.length - 1; updateSelectPackButton();
    for (let i = 0; i < 50 && !(pkdef.pack && pkdef.pack.isReady()); i++) await H.sleep(100);
    packChanged(slot); await H.sleep(300);
    return [selectedpackb.innerHTML, selectedpackc.innerHTML];
  },
  // Background: n times, wait for a screen matching re, store it, press EXE, and wait
  // for that screen to go (so the EXE can't be buffered into a later GET). Results in H.out.
  collect(n, re, ms = 180000) {
    const g = ++H.gen;
    const out = H.out = { rows: [], done: false, err: null };
    (async () => {
      try {
        for (let i = 0; i < n; i++) {
          await H.waitFor(re, ms, g); await H.sleep(300);
          if (g !== H.gen) throw 'stale';
          const scr = H.lcd(); out.rows.push(scr);
          await H.press('Enter', 200, 300);
          const t = Date.now();
          while (H.lcd().join('|') === scr.join('|') && Date.now() - t < 10000) await H.sleep(100);
        }
      } catch (e) { out.err = String(e); }
      out.done = true;
    })();
    return 'started';
  },
  // From anywhere in the menus: Prog > Run <name> on the device shown in the prompt (B: by default)
  async run(name, dev = 'B') {
    for (let i = 0; i < 6 && !/Find   Save/.test(H.lcd().join('')); i++) await H.press('Escape', 200, 900);
    await H.press('P', 150, 900); await H.press('R', 150, 1200);
    await H.prompt(dev, name);
    await H.press('Enter', 250, 300);
    return H.lcd()[1];
  },
  // At a "Xxx D:NAME" prompt on line 2: pick the device with MODE, clear the
  // remembered name with one ON/CLEAR (only if there is one: ON on an empty
  // prompt leaves it), then type the new name.
  async prompt(dev, name) {
    const re = new RegExp('^\\w+ ' + dev + ':');
    for (let i = 0; i < 4 && !re.test(H.lcd()[1]); i++) await H.press('F1', 200, 1500);
    if (!re.test(H.lcd()[1])) throw 'no device ' + dev + ': ' + H.lcd()[1];
    if (/:\S/.test(H.lcd()[1])) await H.press('Escape', 200, 400);
    await H.type(name);
    const l = H.lcd()[1].trim();
    if (!l.endsWith(':' + name)) throw 'prompt shows ' + l;
  },
  // Raw display: chars[line][col] (1-based) and the 8 UDG patterns
  raw() {
    const s = psion.createSnapshot(); const a = [];
    for (let i = 0; i < 240; i++) a.push(s.readByte());
    const ch = [null];
    for (let l = 0; l < 4; l++) { const row = [null]; for (let c = 0; c < 20; c++) row.push(a[45 + screen2mem4[l * 20 + c]]); ch.push(row); }
    const udg = []; for (let n = 0; n < 8; n++) udg.push(a.slice(173 + 8 * n, 181 + 8 * n));
    return { ch, udg };
  },
  // Lunar Lander state as the player can see it (plus the exact pixel row from the UDGs)
  lander(terrain) {
    const { ch, udg } = H.raw();
    const hud = l => String.fromCharCode(...ch[l].slice(16, 21));
    const st = { fuel: parseInt(hud(1).slice(1)), t: parseInt(hud(4)[1]) };
    const v = hud(2), h = hud(3);
    st.vy = (v[1] === '^' ? -1 : 1) * parseInt(v.slice(2)); st.vx = (h[1] === '<' ? -1 : 1) * parseInt(h.slice(2));
    st.ok = hud(4).slice(2, 4) === 'OK';
    for (let l = 1; l <= 4; l++) for (let c = 1; c <= 15; c++) if (ch[l][c] === 0) { st.c = c; st.r = l; }
    if (st.c) {
      const rows = udg[0].concat(udg[1]), pat = [14, 27, 31, 10, 17];
      for (let j = 0; j < 8; j++) if (pat.every((p, i) => (rows[j + i] & p) === p)) { st.py = (st.r - 1) * 8 + j; break; }
    }
    if (terrain) {
      // surface row per column from lines 3/4 (only valid while the lander is up high)
      st.H = [null]; st.pad = [];
      for (let c = 1; c <= 15; c++) {
        const a3 = ch[3][c], a4 = ch[4][c];
        let hh = { 2: 30, 3: 24, 4: 24, 5: 30, 6: 22 }[a4];
        if (a4 === 6) hh = { 2: 22, 5: 22, 3: 16, 4: 16 }[a3];
        st.H.push(hh); if (a3 === 5 || a4 === 5) st.pad.push(c);
      }
    }
    return st;
  },
  // Background autopilot for one flight: reads the screen, presses at most one key per tick.
  fly(opts = {}) {
    const g = ++H.gen;
    const log = H.flog = { steps: [], done: false, err: null, terrain: null };
    (async () => {
      try {
        // wait for the flight screen (HUD 'F' at column 16), then read the terrain
        let T = null;
        for (let i = 0; i < 400 && !T; i++) {
          if (g !== H.gen) throw 'stale';
          const s = H.lcd()[0][15] === 'F' ? H.lander(true) : null;
          if (s && s.c && s.H.every((x, k) => k === 0 || x)) T = s; else await H.sleep(50);
        }
        if (!T) throw 'no lander/terrain: ' + H.lcd().join('|');
        log.terrain = { H: T.H, pad: T.pad };
        const padL = Math.min(...T.pad), padR = Math.max(...T.pad);
        const padMid = (padL + padR) / 2;
        let lastH = 0;
        for (let step = 0; step < 2000; step++) {
          if (g !== H.gen) throw 'stale';
          const s = H.lander(false);
          const scr = H.lcd().join('|');
          if (!log.screens) log.screens = [];
          if (log.screens[log.screens.length - 1] !== scr) { log.screens.push(scr); if (log.screens.length > 12) log.screens.shift(); }
          if (opts.noKeys) { if (!/F/.test(scr[16])) break; await H.sleep(80); continue; }
          if (!s.c || s.py === undefined || isNaN(s.vy)) { if (!/F/.test(String.fromCharCode(...H.raw().ch[1].slice(16, 17)))) break; await H.sleep(60); continue; }
          const over = s.c >= padL && s.c <= padR;
          // horizontal: column error -> wanted speed
          const dc = padMid - s.c;
          let wantVx = Math.abs(dc) < 0.6 ? 0 : Math.sign(dc) * (Math.abs(dc) >= 4 ? 48 : Math.abs(dc) >= 2 ? 32 : 16);
          let hkey = null;
          if (Date.now() - lastH > 900 && Math.abs(s.vx - wantVx) > 8) hkey = s.vx < wantVx ? 'ArrowRight' : 'ArrowLeft';
          // vertical: target height
          const lo = Math.min(s.c, padL), hi = Math.max(s.c, padR);
          let floor = 99; for (let c = Math.max(1, lo - 1); c <= Math.min(15, hi + 1); c++) floor = Math.min(floor, T.H[c]);
          let wantVy;
          if (over && Math.abs(s.vx) <= 8) { const gap = T.H[s.c] - 5 - s.py; wantVy = gap > 6 ? 40 : 14; }
          else { const gap = floor - 5 - 4 - s.py; wantVy = gap > 3 ? 24 : gap > 0 ? 6 : -8; }
          const err = s.vy - wantVy;
          const wantT = err > 3 ? 3 : err < -10 ? 0 : err < -3 ? 1 : 2;
          let tkey = wantT > s.t ? 'ArrowUp' : wantT < s.t ? 'ArrowDown' : null;
          let key = (tkey && (err > 6 || !hkey)) ? tkey : (hkey || tkey);
          if (key) {
            if (key === hkey) lastH = Date.now();
            log.steps.push([s.c, s.py, s.vx, s.vy, s.t, s.fuel, key[5]]);
            await H.press(key, 120, 130);
          } else await H.sleep(100);
        }
      } catch (e) { log.err = String(e); }
      log.done = true;
    })();
    return 'flying';
  },
  model() { return document.body.innerText.match(/Model: .*/)[0]; },
  // Jape runs on requestAnimationFrame, which the browser pane sometimes stops
  // delivering; drive it from a MessageChannel loop at ~60 frames a second instead.
  unfreeze() {
    if (window.__rafPatched) return 'already';
    let q = [], idle = true, last = 0;
    const mc = new MessageChannel();
    mc.port1.onmessage = () => {
      const now = performance.now();
      if (now - last >= 16 && q.length) { last = now; const run = q; q = []; run.forEach(f => f(now)); }
      if (q.length) mc.port2.postMessage(0); else idle = true;
    };
    window.requestAnimationFrame = f => { q.push(f); if (idle) { idle = false; mc.port2.postMessage(0); } return 1; };
    window.cancelAnimationFrame = () => { q = []; };
    window.__rafPatched = true;
    psion.stopRunning(); psion.startRunning();
    return 'patched';
  },
};
'helpers loaded';
