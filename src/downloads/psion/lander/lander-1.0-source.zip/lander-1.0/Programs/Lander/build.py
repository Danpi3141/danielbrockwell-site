"""Build Lunar Lander pack images from src/.

    python build.py          # LANDER.opk      release Datapak (debug lines removed)
    python build.py --dev    # LANDER-dev.opk  Rampak with debug keys and tick profiling
    python build.py --source-only  # LANDER-src.opk  untranslated release source on a
                                   # Rampak, for checking the Organiser's own translator
    python build.py --psion  # LANDER.opk, then psion/ with files for a real Organiser:
                             # translated .OB3 procedures, the RPBOOT/RPLOAD loader with its
                             # RPDATA.ODB file list (Tools/mkrpdata.py) and
                             # (fallback) the .OPL sources, all named for Comms Link

Lines containing "REM DEBUG" (and the line after a bare "REM DEBUG") are development aids
(scripted keys, start overrides and tick timings used by tests/LTEST, and the
tick timings on the level banner); the release build drops them. The dev build
also includes the test procedures in tests/.
"""
import argparse
import glob
import os
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.join(HERE, "..", "..", "Tools")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dev", action="store_true", help="keep debug lines, add tests/, build a Rampak")
    ap.add_argument("--source-only", action="store_true", help="release source, untranslated, on a Rampak")
    ap.add_argument("--psion", action="store_true", help="also write psion/ for Comms Link transfer")
    a = ap.parse_args()
    if a.psion and (a.dev or a.source_only):
        ap.error("--psion goes with the release build only")
    name = "LANDER-dev.opk" if a.dev else "LANDER-src.opk" if a.source_only else "LANDER.opk"
    out = os.path.join(HERE, name)
    tmp = tempfile.mkdtemp(prefix="lander_")
    try:
        srcs = sorted(glob.glob(os.path.join(HERE, "src", "*.opl")))
        if a.dev:
            srcs += sorted(glob.glob(os.path.join(HERE, "tests", "*.opl")))
        for path in srcs:
            with open(path, encoding="latin-1") as f:
                lines = f.read().splitlines()
            if not a.dev:
                keep, skip = [], False
                for ln in lines:
                    if skip or "REM DEBUG" in ln:
                        # a line that is just "REM DEBUG" also drops the line after it
                        skip = ln.strip() == "REM DEBUG"
                        continue
                    keep.append(ln)
                lines = keep
            with open(os.path.join(tmp, os.path.basename(path)), "w", encoding="latin-1", newline="\n") as f:
                f.write("\n".join(lines) + "\n")
        cmd = [sys.executable, os.path.join(TOOLS, "opl2opk.py"), "-f", "--strip-indent"]
        cmd += ["--rampak"] if a.dev or a.source_only else []
        cmd += ["--no-translate"] if a.source_only else []
        cmd += [out, tmp]
        rc = subprocess.call(cmd)
        if rc == 0 and a.psion:
            rc = psion_folder(out)
        return rc
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def pc_name(name):
    """Comms Link maps % in Organiser names to _ in PC names."""
    return name.upper().replace("%", "_")


def write_crlf(path, lines):
    # Comms Link RECEIVE rejects tabs and other control characters in a procedure
    with open(path, "w", encoding="latin-1", newline="\r\n") as f:
        for ln in lines:
            if any(ord(c) < 32 for c in ln):
                raise SystemExit(f"{path}: control character in line {ln!r}")
            f.write(ln + "\n")


def object_only(path):
    """An OB3 file with the source text dropped (translated code only, source length 0)."""
    raw = open(path, "rb").read()
    assert raw[:3] == b"ORG" and raw[5] == 0x83, path
    block = raw[6:]
    olen = (block[0] << 8) | block[1]
    block = block[:2 + olen] + bytes(2)
    return b"ORG" + bytes([len(block) >> 8, len(block) & 0xFF, 0x83]) + block


def sync_folder(src, dest):
    """Make dest match src, touching only files that changed.

    Psi2Win may be serving dest and keep files open, so nothing is deleted
    wholesale: unchanged files are left alone, and a locked file is reported
    instead of leaving the folder half-written.
    """
    want = set()
    locked = []
    for root, _, files in os.walk(src):
        rel = os.path.relpath(root, src)
        os.makedirs(os.path.join(dest, rel), exist_ok=True)
        for fn in files:
            s, d = os.path.join(root, fn), os.path.join(dest, rel, fn)
            want.add(os.path.normcase(os.path.normpath(d)))
            data = open(s, "rb").read()
            if os.path.isfile(d) and open(d, "rb").read() == data:
                continue
            try:
                with open(d, "wb") as f:
                    f.write(data)
            except PermissionError:
                locked.append(d)
    for root, _, files in os.walk(dest):
        for fn in files:
            d = os.path.join(root, fn)
            if os.path.normcase(os.path.normpath(d)) not in want:
                try:
                    os.remove(d)
                except PermissionError:
                    locked.append(d)
    return locked


def psion_folder(pack):
    """psion/ and psion-small/: everything Psi2Win needs to put the game on a real Organiser."""
    dest = os.path.join(HERE, "psion")
    small = os.path.join(HERE, "psion-small")
    tmp = tempfile.mkdtemp(prefix="lander_psion_")
    try:
        unpacked, s_dest, s_small = (os.path.join(tmp, d) for d in ("unpacked", "psion", "psion-small"))
        os.makedirs(os.path.join(s_dest, "opl"))
        os.makedirs(s_small)
        rc = subprocess.call([sys.executable, os.path.join(TOOLS, "opk2files.py"), pack, "-o", unpacked],
                             stdout=subprocess.DEVNULL)
        if rc:
            return rc
        names = []
        for path in sorted(glob.glob(os.path.join(unpacked, "*.ob3"))):
            name = os.path.splitext(os.path.basename(path))[0]
            names.append(name.upper())
            shutil.copyfile(path, os.path.join(s_dest, pc_name(name) + ".OB3"))
            with open(os.path.join(s_small, pc_name(name) + ".OB3"), "wb") as f:
                f.write(object_only(path))
            with open(os.path.splitext(path)[0] + ".opl", encoding="latin-1") as f:
                write_crlf(os.path.join(s_dest, "opl", pc_name(name) + ".OPL"), f.read().splitlines())
        # the generic loader (RPBOOT.OPL, RPLOAD.OB3) and its file list RPDATA.ODB, from Tools/mkrpdata.py
        for d in (s_dest, s_small):
            rc = subprocess.call([sys.executable, os.path.join(TOOLS, "mkrpdata.py"), d,
                                  "--title", "LUNAR LANDER", "--run", "LANDER"], stdout=subprocess.DEVNULL)
            if rc:
                return rc

        def game_bytes(d):
            return sum(os.path.getsize(os.path.join(d, pc_name(n) + ".OB3")) for n in names)
        sizes = game_bytes(s_small), game_bytes(s_dest)
        locked = sync_folder(s_dest, dest) + sync_folder(s_small, small)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    if locked:
        print("These files are in use (is Psi2Win running?), so they were not updated:", file=sys.stderr)
        for p in locked:
            print("  " + os.path.relpath(p, HERE), file=sys.stderr)
        print("Stop Psi2Win and run build.py --psion again.", file=sys.stderr)
        return 1
    print(f"psion/: {len(names)} .OB3 procedures, opl/ sources, loader (RPBOOT.OPL, RPLOAD.OB3, RPDATA.ODB)")
    print(f"psion-small/: the same without source text ({sizes[0]} bytes vs {sizes[1]})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
