"""Lunar Lander LZ - PC model of the OPL game rules.

Mirrors LGEN (terrain rules) and LPLAY% (physics, touchdown) tick for tick,
so the numbers in the spec can be checked and emulator runs compared.

    python sim.py              # spec checks + scripted pilots over 500 levels each
    python sim.py --scenarios  # print the expected results of tests/LTEST scenarios
"""
import argparse
import random

TH = [0, 1, 2, 4]            # thrust per throttle
GRAV = 2
SAFE_VY, SAFE_VX = 24, 8
BURST, BURST_FUEL = 16, 2
XMAX = 9599

# column kinds -> (line 3 char, line 4 char, surface row)
LOW, UP, DOWN, PADLO, PLAT, PADHI, PEAKA, PEAKB = range(8)
KIND = {LOW: (" ", 2, 30), UP: (" ", 3, 24), DOWN: (" ", 4, 24), PADLO: (" ", 5, 30),
        PLAT: (2, 6, 22), PADHI: (5, 6, 22), PEAKA: (3, 6, 16), PEAKB: (4, 6, 16)}


def fuel_for(lv):
    return max(275, 525 - 25 * lv)


def pad_width(lv):
    return 3 if lv <= 2 else 2 if lv <= 4 else 1


class Level:
    def __init__(self, kinds, padc, padw):
        self.kinds, self.padc, self.padw = kinds, padc, padw
        self.H = [None] + [KIND[k][2] for k in kinds]   # 1-based like H%()


def gen(lv, rnd):
    """LGEN: same decisions in the same order (RND draws differ from the Psion's)."""
    w = pad_width(lv)
    padc = 1 + int(rnd.random() * (16 - w))
    st = int(rnd.random() * 2) if lv > 2 else 0
    kinds = []
    c = 1
    while c <= 15:
        z = rnd.random()
        if padc <= c < padc + w:
            kinds.append(PADLO if st == 0 else PADHI)
            c += 1
        elif st == 0:
            if z < 0.3 and c < 15:
                kinds.append(UP)
                st = 1
            else:
                kinds.append(LOW)
            c += 1
        elif z < 0.3 and c < 15:
            kinds.append(DOWN)
            st = 0
            c += 1
        elif lv > 3 and z < 0.55 and c < 15 and (c + 1 < padc or c + 1 >= padc + w):
            kinds += [PEAKA, PEAKB]
            c += 2
        else:
            kinds.append(PLAT)
            c += 1
    return Level(kinds, padc, w)


def start(lv, level, rnd, col=None, drift=None):
    """LPLAY% start: column at least 5 from the pad centre, drift towards the pad."""
    padc, padw = level.padc, level.padw
    while True:
        c = col if col is not None else 1 + int(rnd.random() * 15)
        if abs(2 * c - 2 * padc - padw + 1) >= 10 or col is not None:
            break
    k = min(lv - 1, 4)
    vx = drift if drift is not None else 8 * int(rnd.random() * (k + 1))
    if 2 * c > 2 * padc + padw - 1:
        vx = -abs(vx)
    return dict(x=(c - 1) * 640 + 320, y=0, vx=vx, vy=0, t=0, f=fuel_for(lv), n=0)


def tick(s, level, key):
    """One pass of the LPLAY% loop. key: 0 none, 3 up, 4 down, 5 left, 6 right.
    Returns 0 flying, 1 landed, 2 crashed."""
    if key == 3 and s["t"] < 3:
        s["t"] += 1
    elif key == 4 and s["t"] > 0:
        s["t"] -= 1
    elif key == 5 and s["f"] >= BURST_FUEL:
        s["vx"] -= BURST
        s["f"] -= BURST_FUEL
    elif key == 6 and s["f"] >= BURST_FUEL:
        s["vx"] += BURST
        s["f"] -= BURST_FUEL
    if s["f"] == 0:
        s["t"] = 0
    s["f"] = max(0, s["f"] - TH[s["t"]])
    s["vy"] += GRAV - TH[s["t"]]
    s["y"] += s["vy"]
    s["x"] += s["vx"]
    if s["y"] < 0:
        s["y"], s["vy"] = 0, 0
    if s["x"] < 0:
        s["x"], s["vx"] = 0, 0
    if s["x"] > XMAX:
        s["x"], s["vx"] = XMAX, 0
    s["n"] += 1
    c = s["x"] // 640 + 1
    py = s["y"] // 128
    d = py + 5 - level.H[c]
    s["c"], s["py"], s["d"] = c, py, d
    if d < 0:
        return 0
    s["py"] = level.H[c] - 5
    if (level.padc <= c < level.padc + level.padw and d <= 1
            and 0 <= s["vy"] <= SAFE_VY and abs(s["vx"]) <= SAFE_VX):
        return 1
    return 2


def fly(s, level, keys):
    """Run a key list (one per tick; then no keys) until touchdown."""
    i = 0
    while True:
        r = tick(s, level, keys[i] if i < len(keys) else 0)
        i += 1
        if r:
            return r


# ---- a scripted pilot (one key per tick, like a person) --------------------
def pilot(s, level, efficient):
    """Returns the key for this tick from the visible state.

    Cautious: climbs/hovers near the top while crossing, then descends over the pad.
    Efficient: descends to just above the highest ground in the way while crossing."""
    x, y, vx, vy = s["x"], s["y"], s["vx"], s["vy"]
    col = x // 640 + 1
    padx = ((level.padc - 1) * 2 + level.padw) * 320     # pad centre in x units
    dx = padx - x
    settled = level.padc <= col < level.padc + level.padw and abs(dx) <= 320 * level.padw - 200
    # horizontal: cruise towards the pad, slowing as it gets close, ~0 over it
    if settled:
        want_vx = 0
    else:
        # fast enough to waste no ticks (fuel is ~2 per tick), slow enough to stop:
        # braking one 16-burst per tick from v covers about v*v/32 units
        mag = min(96 if efficient else 48, max(16, int((32 * abs(dx) * 0.6) ** 0.5)))
        want_vx = mag if dx > 0 else -mag
    hkey = 6 if vx < want_vx - 8 else 5 if vx > want_vx + 8 else 0
    # vertical: target speed from the distance to a target height
    if settled and abs(vx) <= 8:
        floor_py = level.H[col] - 5
        vmax = 90
    else:
        lo, hi = sorted((col, min(max(col, level.padc), level.padc + level.padw - 1)))
        top = min(level.H[c] for c in range(max(1, lo - 1), min(15, hi + 1) + 1))
        floor_py = top - 5 - 4 if efficient else 2
        vmax = 40 if efficient else 20
    gap = floor_py * 128 - y                              # units to go
    if gap <= 0:
        want_vy = max(-16, gap // 16)
    else:
        want_vy = min(vmax, int((18 * 18 + 2.8 * gap) ** 0.5) if settled else int((4 * 4 + 2.8 * gap) ** 0.5))
    err = vy - want_vy
    want_t = 3 if err > 2 else 0 if err < -8 else 1 if err < -2 else 2
    tkey = 3 if want_t > s["t"] else 4 if want_t < s["t"] else 0
    if s["f"] < 2:
        hkey = 0
    if tkey and (err > 6 or not hkey):
        return tkey
    return hkey or tkey


def run_pilots(n=500, seed=1):
    print("level fuel pad drift  cautious efficient  (win %, fuel used)")
    for lv in range(1, 13):
        line = [f"{lv:5} {fuel_for(lv):4} {pad_width(lv):3} {8 * min(lv - 1, 4):5}"]
        for eff in (False, True):
            rnd = random.Random(seed + lv)
            wins = used = 0
            for _ in range(n):
                level = gen(lv, rnd)
                s = start(lv, level, rnd)
                f0 = s["f"]
                while True:
                    r = tick(s, level, pilot(s, level, eff))
                    if r:
                        break
                    if s["n"] > 2000:
                        r = 2
                        break
                if r == 1:
                    wins += 1
                    used += f0 - s["f"]
            line.append(f"{100 * wins / n:8.0f}% {used / max(wins, 1):4.0f}")
        print("  ".join(line))


# ---- fixed scenarios, replayed on the Organiser by tests/LTEST.opl ---------
def fixed(kinds, padc, padw):
    """kinds: 15 digits, one column kind each (0 low .. 7 peak falling half)."""
    return Level([int(ch) for ch in kinds], padc, padw)


def test_start(lv, col, drift):
    """The LTEST override in LPLAY%: x from the column, vx exactly as given."""
    return dict(x=(col - 1) * 640 + 320, y=0, vx=drift, vy=0, t=0, f=fuel_for(lv), n=0)


def record(lv, level, col, drift, efficient):
    """Fly the pilot and return its key list."""
    s, keys = test_start(lv, col, drift), []
    while True:
        k = pilot(s, level, efficient)
        keys.append(k)
        if tick(s, level, k):
            return keys


def encode(keys):
    """Run-length pairs: key digit, then count as a letter A=1 .. Z=26."""
    out, i = "", 0
    while i < len(keys):
        j = i
        while j < len(keys) and keys[j] == keys[i] and j - i < 26:
            j += 1
        out += str(keys[i]) + chr(64 + j - i)
        i = j
    return out


T_FLAT = "000000333000000"          # low ground, 3-wide pad at 7
T_HILL = "001444444442000"          # plateau 4-11 with a 2-wide high pad at 8
T_PEAK = "014467445444420"          # peaks at 4-5 and 9-10 (6,7), 1-wide high pad at 7


def scenarios():
    """(name, level, kinds, padc, padw, start col, drift, keys)"""
    sc = [("FREEFALL", 1, T_FLAT, 7, 3, 1, 0, [0]),
          ("PADFAST", 1, T_FLAT, 7, 3, 8, 0, [0])]
    L = fixed(T_FLAT, 7, 3)
    sc.append(("LANDEFF", 1, T_FLAT, 7, 3, 1, 0, record(1, L, 1, 0, True)))
    keys = record(1, L, 1, 0, True)
    keys[-3] = 6                       # one burst just before touchdown: too fast sideways
    sc.append(("SIDEFAST", 1, T_FLAT, 7, 3, 1, 0, keys))
    L = fixed(T_HILL, 8, 2)
    sc.append(("LANDCAU", 3, T_HILL, 8, 2, 14, -16, record(3, L, 14, -16, False)))
    L = fixed(T_PEAK, 7, 1)
    sc.append(("LANDPEAK", 6, T_PEAK, 7, 1, 1, 32, record(6, L, 1, 32, True)))
    sc.append(("HITPEAK", 6, T_PEAK, 7, 1, 1, 48, [0]))
    sc.append(("NOFUEL", 10, T_FLAT, 7, 3, 2, 0, [3, 3, 3] + [0] * 80 + [5, 6] * 5))
    sc.append(("WALLS", 2, T_FLAT, 7, 3, 2, -16, [5, 5, 0, 3, 3] + [0] * 30 + [6] * 12 + [0] * 60))
    return sc


def scenario_results():
    rows = []
    for i, (name, lv, kinds, padc, padw, col, drift, keys) in enumerate(scenarios(), 1):
        L = fixed(kinds, padc, padw)
        s = test_start(lv, col, drift)
        r = fly(s, L, keys)
        rows.append((i, name, r, s))
    return rows


OPL_KINDS = "LTEST"


def write_ltest(path):
    """tests/LTEST.opl: replays every scenario through the real LPLAY%."""
    sc = scenarios()
    out = ["LTEST:",
           "REM scripted flights through LPLAY%; compare with tools/sim.py --scenarios",
           "GLOBAL S%(24),P%(48),H%(15),TH%(4),FL%(8)",
           "GLOBAL L$(4,15),FUEL%,PADC%,PADW%,LC%,LR%,snd%",
           "GLOBAL tc%,tv%,tk$(255),tf%,DX%,DY%,DVX%,DVY%,DN%,mx%,sw%,mt%,fr%",
           "LOCAL i%,j%,c%,a%,r%,lv%,e$(250),k$(15),k3$(8),k4$(8),t",
           "KSTAT 1 :CURSOR OFF",
           "LINIT:",
           'k3$="    "+CHR$(2)+CHR$(5)+CHR$(3)+CHR$(4)',
           "k4$=CHR$(2)+CHR$(3)+CHR$(4)+CHR$(5)+CHR$(6)+CHR$(6)+CHR$(6)+CHR$(6)",
           "i%=1",
           "DO",
           "tf%=1",
           f"IF i%={len(sc) + 1}",
           "REM real time: the efficient landing (scenario 3) again, timed",
           "tf%=0 :i%=3 :t=HOUR*3600.0+MINUTE*60+SECOND",
           "ENDIF"]
    for i, (name, lv, kinds, padc, padw, col, drift, keys) in enumerate(sc, 1):
        e = encode(keys)
        assert len(keys) <= 255 and len(e) <= 250, (name, len(keys), len(e))
        kw = "IF" if i == 1 else "ELSEIF"
        out.append(f"{kw} i%={i}")
        out.append(f'lv%={lv} :k$="{kinds}" :PADC%={padc} :PADW%={padw} :tc%={col} :tv%={drift}')
        out.append(f'e$="{e}"')
    out += ["ENDIF",
            "tk$=\"\" :j%=1",
            "WHILE j%<LEN(e$)",
            "tk$=tk$+REPT$(MID$(e$,j%,1),ASC(MID$(e$,j%+1,1))-64)",
            "j%=j%+2",
            "ENDWH",
            "L$(1)=REPT$(\" \",15) :L$(2)=L$(1) :L$(3)=\"\" :L$(4)=\"\"",
            "c%=1",
            "DO",
            "a%=ASC(MID$(k$,c%,1))-48",
            "L$(3)=L$(3)+MID$(k3$,a%+1,1) :L$(4)=L$(4)+MID$(k4$,a%+1,1)",
            'H%(c%)=VAL(MID$("3024243022221616",2*a%+1,2))',
            "c%=c%+1",
            "UNTIL c%>15",
            "CLS",
            "c%=1",
            "DO",
            "AT 1,c% :PRINT L$(c%);",
            "c%=c%+1",
            "UNTIL c%>4",
            "r%=LPLAY%:(lv%)",
            "IF r%=1 :LWIN: :ELSE :LBOOM: :ENDIF",
            "CLS",
            "IF tf%",
            'PRINT "S";i%;" R";r%;" N";DN%;" F";FUEL%',
            'PRINT "X";DX%;" Y";DY%',
            'PRINT "VX";DVX%;" VY";DVY%',
            'PRINT "C";LC%;" L";LR%;" M";mx%;"@";mt%;" A";sw%;',
            "ELSE",
            "t=HOUR*3600.0+MINUTE*60+SECOND-t",
            'PRINT "REAL TIME R";r%;" N";DN%',
            'PRINT "SECONDS ";t',
            'PRINT "WORK MAX";mx%;"@";mt%;" SUM";sw%',
            'PRINT "FRAMES ";fr%;" ";FIX$(fr%/DN%,2,5);"/TICK";',
            "i%=99",
            "ENDIF",
            "GET",
            "i%=i%+1",
            f"UNTIL i%>{len(sc) + 1}"]
    with open(path, "w", encoding="latin-1", newline="\n") as f:
        f.write("\n".join(out) + "\n")


def spec_checks():
    level = flat()
    s = start(1, level, None, 1, 0)
    r = fly(s, level, [])
    print(f"free fall from the top onto low ground: {s['n']} ticks, speed {s['vy']} (spec: 57, 114), result {r}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenarios", action="store_true", help="expected LTEST results")
    ap.add_argument("--write-ltest", metavar="PATH", help="write tests/LTEST.opl")
    ap.add_argument("-n", type=int, default=500)
    a = ap.parse_args()
    if a.write_ltest:
        write_ltest(a.write_ltest)
    elif a.scenarios:
        for i, name, r, s in scenario_results():
            print(f"S{i} {name:8} R{r} N{s['n']} F{s['f']} X{s['x']} Y{s['y']} "
                  f"VX{s['vx']} VY{s['vy']} C{s['c']} L{s['py'] // 8 + 1}")
    else:
        spec_checks()
        run_pilots(a.n)
