#!/usr/bin/env python3
"""Builds Connect 4: the kernel (with the engine), the screen drivers and overlays, the
book, the launcher and the pack image (a 32K Datapak that runs on every model).

    python tools/build.py [--out build/game]

The array m%() holds: kernel + engine (code, tables, variables) | screen driver (DRV)
| region R. While the engine searches, R holds its scratch and then the 512-byte search table
(TTBASE); the rest of the time it holds one overlay (slot A), with the overlays' buffer (BUF,
BUF_SIZE bytes) at its top. The table is cleared at the start of every search, so nothing is
lost by sharing.
"""
import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import asm   # noqa: E402
import pack  # noqa: E402

BLOCK_MAX = 32000
BAD_OPL = (0, 9, 10, 13)
TT_BYTES = 512
LAUNCH_OVERHEAD = 330          # C4G beyond its array: the free RAM it needs at the call (tests/m1/needs.js: 323 on CM 2.4 and 3.3, 19 Nov)
SAVE_ROOM = 134                # A:C4SAV (92, 93 with Keep) and A:C4TAL, the tally (41), measured on a CM 19 Nov 2026; C4 adds this while there is no C4SAV
C4G_FRAME_GAP = 22             # C4G's variables between the end of its object code and m%() (i%, a%, v%(), m%()'s count): tests/m1/holeprobe.js, the same on all 29 ROMs, 19 Nov
BUF_SIZE = 120                 # the overlays' buffer at the top of slot A: set-up's search 103 (import and export use the driver's area since 19 Nov)
# ids: overlays run in slot A, drivers at DRV
UNITS = [('DRV2', 'drv2.asm'), ('DRV4', 'drv4.asm'), ('OV_PLAY', 'ov_play.asm'), ('OV_PLAY2', 'ov_play.asm'),
         ('OV_GAME', 'ov_game.asm'), ('OV_BOOK', 'ov_book.asm'), ('OV_COACH', 'ov_book.asm'), ('OV_MENU', 'ov_menu.asm'), ('OV_SET', 'ov_set.asm'), ('OV_LIST', 'ov_list.asm'),
         ('OV_RESULT', 'ov_result.asm'), ('OV_SETUP', 'ov_setup.asm'), ('OV_IMPORT', 'ov_import.asm'),
         ('OV_EXPORT', 'ov_export.asm'), ('OV_HELP', 'ov_help.asm'), ('OV_FX', 'ov_fx.asm'), ('OV_REVIEW', 'ov_review.asm'),
         ('OV_END', 'ov_end.asm'), ('OV_PANEL', 'ov_panel.asm'), ('OV_THINK', 'ov_think.asm'),
         ('OV_CMD', 'ov_cmd.asm')]
DRIVERS = ('DRV2', 'DRV4')
BUF_USERS = {'OV_SETUP': 103, 'OV_LIST': 11, 'OV_REVIEW': 11,
             'OV_RESULT': 12, 'OV_HELP': 12, 'OV_END': 12}
# the top bytes of slot A each uses: BUF = the top 120; the review's tactics RV_TAC the top 11 (OV_LIST
# writes them); the result's last line RS_LINE the top 12 (OV_RESULT writes it, OV_END reads it, OV_HELP
# loads between). OV_EXPORT and OV_IMPORT read and build their files and lists in the driver's area
# (until 19 Nov the top 256 and the top 120 of slot A).
EXPORT_BUF = 16 + 256          # OV_EXPORT: a name, then a record of up to 255 bytes, at DRV
GAME_GAP = 249                 # FREE in C4 = the gap below the array during a game + array - 249 (CM 3.3, 19 Nov: gap 507, C4 NEEDS 72)
KEEP_GAP = LAUNCH_OVERHEAD + GAME_GAP + 64   # a file is made only with this gap left: C4 can start again (64: a 42-move export)
DEFINES = {'OV_PLAY': {'TWO': 0}, 'OV_PLAY2': {'TWO': 1},   # one source, two units
           'OV_BOOK': {'COACH': 0}, 'OV_COACH': {'COACH': 1}}


class BuildError(Exception):
    pass


def encode_fixups(fix, kernel=False):
    """A fix-up list: its length in bytes (one byte), then steps, two a byte (the high nibble
    first): 1-15 on that far and fix the word there, 0 on 15 without a fix-up (also the pad).
    Until 19 Nov 2026 a byte a step (255 then a word for a long one), with a count first:
    1,193 bytes in all for 2,186."""
    nib = []
    prev = 0
    for f in sorted(fix):
        d = f - prev
        if d < 1:
            raise BuildError('a fix-up at %d: steps start at 1' % f)
        while d > 15:
            nib.append(0)
            d -= 15
        nib.append(d)
        prev = f
    if len(nib) % 2:
        nib.append(0)
    out = bytes(nib[i] << 4 | nib[i + 1] for i in range(0, len(nib), 2))
    if len(out) > 255 and not kernel:          # (the kernel's: the fixer runs to the block's end)
        raise BuildError('a fix-up list of %d bytes (its length is one byte)' % len(out))
    return bytes([len(out) & 255]) + out              # (the kernel's is dropped: enc[1:])


# the book (data/book.bin: 5-bit codes, 0 none, 1-7 a win in column 1-7, 8-14 a draw, 15-21 a
# loss) packed in 4 bits for C4B1 (19 Nov 2026: 11,205 bytes for 14,007). 1-7 stay; the book's
# 20 other entries use only these 8 codes, which 8-15 stand for (OV_BOOK's bk_read: 8-12 + 1,
# 13-15 (+ 1) * 2 - 12): draws in columns 2-6, losses in columns 2, 4, 6
BOOK_HI = [9, 10, 11, 12, 13, 16, 18, 20]


def book4(b5):
    n = (len(b5) - 1) * 8 // 5              # (one pad byte after the 5-bit entries)
    def rd(i):
        bit = i * 5
        return (((b5[bit >> 3] << 8) | b5[(bit >> 3) + 1]) >> (11 - (bit & 7))) & 31
    for c in range(8, 16):                  # the decoding OV_BOOK does
        d = c + 1 if c < 13 else (c + 1) * 2 - 12
        if d != BOOK_HI[c - 8]:
            raise BuildError('BOOK_HI and bk_read differ')
    codes = []
    for i in range(n):
        c = rd(i)
        if c >= 8:
            if c not in BOOK_HI:
                raise BuildError('book entry %d: code %d has no 4-bit code (BOOK_HI)' % (i, c))
            c = BOOK_HI.index(c) + 8
        codes.append(c)
    if len(codes) % 2:
        codes.append(0)
    return bytes(codes[i] << 4 | codes[i + 1] for i in range(0, len(codes), 2))


def c4g_lines(boot, total):
    """C4G: makes the array, pokes the bootstrap into its top from one string, calls it."""
    poke = []
    step = len(boot)
    # one string and one loop if the line fits OPL's 255 characters (each extra loop costs C4G,
    # which stays in RAM all game, about 35 bytes), else pieces
    while True:
        lits = []
        for at in range(0, len(boot), step):
            piece = bytes(boot[at:at + step])
            lits.append((at, piece, '"' + piece.decode('latin-1').replace('"', '""') + '"'))
        if all(len('POKEB a%%+i%%,ASC(MID$(%s,i%%-%d,1))' % (l, at - 1)) <= 250 for at, _, l in lits):
            break
        step = (step + 1) // 2
    if len(lits) != 1:
        raise BuildError("the bootstrap no longer fits one string: the kernel's variables in it (KH) need one")
    for at, piece, lit in lits:
        poke += ['i%%=%d' % at, 'DO', 'POKEB a%%+i%%,ASC(MID$(%s,i%%-%d,1))' % (lit, at - 1),
                 'i%=i%+1', 'UNTIL i%%=%d' % (at + len(piece))]
    words = (total + 1) // 2
    return ['C4G:', 'LOCAL m%%(%d),v%%(6),i%%,a%%' % words,      # v%(): 12 bytes (boot.asm)
            'a%%=ADDR(m%%())+%d' % (total - len(boot))] + poke + [
            'v%%(1)=ADDR(m%%()) :v%%(2)=%d' % total,
            'i%=USR(a%,ADDR(v%()))',
            'IF i% :PRINT "C4 ERROR ";i% :GET :ENDIF']     # 1 no game files, 2 damaged (README)


def c4g_hole(path, boot):
    """Where C4G's copy of the bootstrap string is in RAM, relative to the array: C4G stays
    loaded all game, and once the bootstrap has run nothing reads those bytes again, so the
    kernel keeps variables there (KH, src/kernel/kvars.inc)."""
    class A:
        no_translate = False
        target = 'cm'
        strip_indent = True
        encoding = 'latin-1'
    _, rec, _ = pack.opl2opk.opl_procedure(path, A, quiet=True)
    rec = bytes(rec)
    # the record: name (11 bytes), 02 80, length (2), then the object code's length (2) and the
    # object code (variables' sizes, then the Q-code), then the source
    olen = rec[15] << 8 | rec[16]
    obj = rec[17:17 + olen]
    at = obj.find(boot)
    if at < 0 or obj.find(boot, at + 1) >= 0:
        raise BuildError('C4G: the bootstrap string is not once in its object code')
    return -(olen - at + C4G_FRAME_GAP)


def build(out):
    gen = os.path.join(out, 'gen')
    os.makedirs(gen, exist_ok=True)
    ids = ['; generated by tools/build.py', 'N_UNITS = %d' % len(UNITS)]
    ids += ['%s = %d' % (n, i + 1) for i, (n, _) in enumerate(UNITS)]
    if len(UNITS) >= 32:
        raise BuildError('the command table tells an overlay from a kernel address by its id being below $20')
    with open(os.path.join(gen, 'ids.inc'), 'w') as f:
        f.write('\n'.join(ids) + '\n')
    incdirs = [gen, os.path.join(ROOT, 'src'), os.path.join(ROOT, 'src', 'kernel'),
               os.path.join(ROOT, 'src', 'engine'), os.path.join(ROOT, 'src', 'screens')]

    def assemble(path, origin, imports, what):
        imports = dict(imports)
        for k, v in DEFINES.get(what, {}).items():
            imports[k] = (v, 'abs')
        try:
            return asm.assemble(path, origin=origin, imports=imports, incdirs=incdirs)
        except asm.AsmError as e:
            raise BuildError('%s: %s' % (what, e))

    kpath = os.path.join(ROOT, 'src', 'kernel', 'kernel.asm')

    # the bootstrap first: the kernel keeps some variables in C4G's copy of it (KH)
    b = assemble(os.path.join(ROOT, 'src', 'launch', 'boot.asm'), 0, {}, 'boot')
    if b.fix:
        raise BuildError('the bootstrap must be position independent')
    boot = bytes(b.out)
    bad = [i for i, v in enumerate(boot) if v in BAD_OPL]
    if bad:
        raise BuildError('the bootstrap has bytes an OPL string cannot hold at %s' % bad)
    draft = os.path.join(out, 'C4G_draft.opl')
    with open(draft, 'w', encoding='latin-1', newline='\n') as f:
        f.write('\n'.join(c4g_lines(boot, 5000)) + '\n')
    kh = c4g_hole(draft, boot)
    os.remove(draft)

    scratch = [400]
    think_len = [0]
    init_len = [0]

    def imports(kmax, drv, slot):
        # during a search the table starts at DRV and the scratch follows it (into slot A)
        return {'DRV': (kmax, 'rel'), 'SLOTA': (kmax + drv, 'rel'), 'TTBASE': (kmax, 'rel'),
                'SCRATCH': (kmax + TT_BYTES, 'rel'), 'THINKAT': (kmax + drv + slot - think_len[0], 'rel'),
                'BUF': (kmax + drv + slot - BUF_SIZE, 'rel'), 'INIT_LEN': (init_len[0], 'abs'),
                'SLOTA_SIZE': (slot, 'abs'), 'DRV_SIZE': (drv, 'abs'), 'KH': (kh, 'rel'),
                'KEEP_GAP': (KEEP_GAP, 'abs')}

    # sizes: the drivers and overlays, assembled against a first kernel
    k = assemble(kpath, 0, imports(0x3000, 512, 1024), 'kernel')
    scratch[0] = k.sym['E_SCRATCH_END'][0] - k.sym['E_FR'][0]
    ksym = dict(k.sym)
    ksym.update(imports(0x3000, 512, 1024))
    drv = slot = 16
    for n, fn in UNITS:
        u = assemble(os.path.join(ROOT, 'src', 'screens', fn), 0x3000, ksym, n)
        if n in DRIVERS:
            drv = max(drv, len(u.out))
        elif n == 'OV_THINK':
            think_len[0] = len(u.out)
            if u.sym['ot_tstart'][0] - 0x3000 != len(u.out) - 2:
                raise BuildError('OV_THINK: ot_tstart must be its last two bytes (think_run sets it at the top of slot A)')
        else:
            slot = max(slot, len(u.out) + BUF_USERS.get(n, 0))
    slot = max(slot, scratch[0] + TT_BYTES - drv)       # the search covers the driver too
    if drv < EXPORT_BUF:
        raise BuildError('the driver area (%d) is smaller than the export buffer (%d)' % (drv, EXPORT_BUF))
    if think_len[0] > drv + slot - (scratch[0] + TT_BYTES):
        raise BuildError('OV_THINK (%d) does not fit above the search (%d free)' % (think_len[0], drv + slot - scratch[0] - TT_BYTES))
    kmax = 0
    for _ in range(8):
        k = assemble(kpath, 0, imports(kmax, drv, slot), 'kernel')
        if len(k.out) == kmax:
            break
        kmax = len(k.out)
    else:
        raise BuildError('kernel size did not settle')
    if bytes(k.out[3:7]) != b'C4K1':
        raise BuildError('kernel does not start with its tag')
    ksym = dict(k.sym)
    ksym.update(imports(kmax, drv, slot))
    # the start-up code: assembled to run at SLOTA, stored after the kernel's code
    kin = assemble(os.path.join(ROOT, 'src', 'kernel', 'kinit.asm'), kmax + drv, ksym, 'kinit')
    init_len[0] = len(kin.out)
    k2 = assemble(kpath, 0, imports(kmax, drv, slot), 'kernel')
    if len(k2.out) != len(k.out) or any(k2.sym[n] != v for n, v in k.sym.items() if n != 'INIT_LEN'):
        raise BuildError('the kernel moved when given the length of the start-up code')
    k = k2
    ksym = dict(k.sym)
    ksym.update(imports(kmax, drv, slot))
    # again, now that it knows its own length (its first lines copy it into R: 20 Nov 2026)
    kin = assemble(os.path.join(ROOT, 'src', 'kernel', 'kinit.asm'), kmax + drv, ksym, 'kinit')
    if len(kin.out) != init_len[0]:
        raise BuildError('the start-up code changed length when given its length')
    if len(kin.out) > slot:
        raise BuildError('the start-up code (%d) is bigger than region R' % len(kin.out))
    with open(os.path.join(out, 'kinit.lst'), 'w') as f:
        f.write(kin.listing_text())
    vstart = k.sym['kv_first'][0]
    if vstart + len(kin.out) > kmax + drv:
        raise BuildError('the start-up code would overlap region R while it is copied')
    image = bytearray(k.out)
    if any(image[vstart:]):
        raise BuildError('kernel variables are not all zero')
    if any(f >= vstart for f in k.fix):
        raise BuildError('a fix-up in the kernel variables')

    # block 0 starts with two tables the kernel reads from the pack (20 Nov 2026; in RAM before):
    # the command table (src/kernel/kcmd.asm) and the units' offsets
    cmd = assemble(os.path.join(ROOT, 'src', 'kernel', 'kcmd.asm'), 0, ksym, 'kcmd')
    ncmd = 2 * (ksym['C_FLAG'][0] + 1)
    if len(cmd.out) != ncmd:
        raise BuildError('the command table is %d bytes, not %d' % (len(cmd.out), ncmd))
    for i in range(0, ncmd, 2):
        w = cmd.out[i] * 256 + cmd.out[i + 1]
        if (i in cmd.fix) != (w >= 0x8000) or (w < 0x8000 and not 0x100 <= w < 0x2000) or (w >= 0x8000 and w - 0x8000 >= vstart):
            raise BuildError('command %d: entry %04X' % (i // 2, w))
    hdr = ncmd + 2 * len(UNITS)
    if ksym['B0_OVT'][0] != ncmd:
        raise BuildError('B0_OVT does not match the command table')

    # the units into block 0
    blk0 = bytearray()
    offs = {}
    report = []
    for n, fn in UNITS:
        origin = kmax if n in DRIVERS else kmax + drv + slot - think_len[0] if n == 'OV_THINK' else kmax + drv
        u = assemble(os.path.join(ROOT, 'src', 'screens', fn), origin, ksym, n)
        limit = drv if n in DRIVERS else slot - BUF_USERS.get(n, 0)
        if len(u.out) > limit:
            raise BuildError('%s is %d bytes, over its room (%d)' % (n, len(u.out), limit))
        offs[n] = hdr + len(blk0)
        blk0 += len(u.out).to_bytes(2, 'big') + bytes(u.out) + encode_fixups(u.fix)
        report.append((n, len(u.out), len(u.fix)))
        with open(os.path.join(out, n.lower() + '.lst'), 'w') as f:
            f.write(u.listing_text())
        with open(os.path.join(out, n.lower() + '.sym.json'), 'w') as f:
            json.dump({s: v for s, v in u.sym.items() if s not in ksym}, f, indent=0)
    blk0 = bytes(cmd.out) + b''.join(offs[n].to_bytes(2, 'big') for n, _ in UNITS) + blk0
    if len(blk0) > BLOCK_MAX:
        raise BuildError('block 0 is %d bytes' % len(blk0))
    kimg = image[:vstart] + bytes(kin.out)
    # the fixer (position independent) runs from just after the kernel, then the encoded list
    fx = assemble(os.path.join(ROOT, 'src', 'launch', 'fixer.asm'), 0, {}, 'fixer')
    if fx.fix:
        raise BuildError('the fixer must be position independent')
    enc = encode_fixups(list(k.fix) + [vstart + f for f in kin.fix], kernel=True)
    allk = bytes(kimg) + bytes(fx.out) + enc[1:]            # read in one go by the bootstrap
    kblock = len(kimg).to_bytes(2, 'big') + len(allk).to_bytes(2, 'big') + allk
    total = kmax + drv + slot
    if len(kblock) - 2 > total - 160:
        raise BuildError('kernel and its fix-ups do not fit the array while loading')
    with open(os.path.join(out, 'kernel.lst'), 'w') as f:
        f.write(k.listing_text())
    with open(os.path.join(out, 'kernel.sym.json'), 'w') as f:
        json.dump({n: v for n, v in ksym.items()}, f, indent=0)

    # the launcher (translated for the CM/XP: runs on every model)
    hole = k.sym['kh_end'][0] - k.sym['kh_first'][0]
    if k.sym['kh_first'][0] != kh or hole > len(boot):
        raise BuildError("the variables in C4G's string (%d bytes) must fit it (%d)" % (hole, len(boot)))
    needs = total + LAUNCH_OVERHEAD
    lines = c4g_lines(boot, total)
    lp = os.path.join(out, 'C4G.opl')
    with open(lp, 'w', encoding='latin-1', newline='\n') as f:
        f.write('\n'.join(lines) + '\n')
    # C4 checks the free RAM first (C4G's array is made as C4G starts)
    sp = os.path.join(out, 'C4.opl')
    with open(sp, 'w', encoding='latin-1', newline='\n') as f:
        # n% = the bytes missing (EXIST is -1 once the save files are there). C4 stays in RAM while
        # the game runs; this form costs 10 bytes less than one with a separate IF for the files
        f.write('\n'.join(['C4:', 'LOCAL n%',
                           'n%%=%d+%d*EXIST("A:C4SAV")-FREE' % (needs + SAVE_ROOM, SAVE_ROOM),
                           'IF n%<=0 :C4G: :RETURN :ENDIF',
                           'PRINT "C4 NEEDS ";n% :PRINT "BYTES MORE RAM" :GET']) + '\n')

    if c4g_hole(lp, boot) != kh:
        raise BuildError('C4G: its string moved (%d, the kernel has %d)' % (c4g_hole(lp, boot), kh))

    img = pack.PackImage('datapak', 32, target='cm')
    img.add_opl(sp)
    img.add_opl(lp)
    img.add_data('C4K', kblock)
    img.add_data('C4B0', bytes(blk0))
    book = os.path.join(ROOT, 'data', 'book.bin')
    bk = book4(open(book, 'rb').read()) if os.path.exists(book) else b''
    img.add_data('C4B1', bk if bk else b'\0')
    opk = os.path.join(out, 'C4.opk')
    size_k, used = img.write(opk)

    e = {n: v[0] for n, v in k.sym.items()}
    lines = ['Pack (%dK Datapak)              bytes' % size_k,
             '  kernel+engine block    %7d' % len(kblock),
             '  screens (C4B0)         %7d' % len(blk0),
             '  book (C4B1)            %7d' % len(bk),
             '  total                  %7d of %d' % (used, size_k * 1024),
             'RAM (array m%())                bytes',
             '  engine code+tables     %7d' % (e['eng_end'] - e['eng_start']),
             '  kernel code            %7d  (and start-up code %d, run once in R)' % (vstart - (e['eng_end'] - e['eng_start']), len(kin.out)),
             '  variables              %7d' % (kmax - vstart),
             '  screen driver          %7d' % drv,
             '  region R               %7d  (an overlay, with the buffer %d for some; or scratch %d + table %d)' % (
                 slot, BUF_SIZE, scratch[0], TT_BYTES),
             '  array                  %7d  (C4 needs %d free)' % (total, needs),
             'Units']
    for n, ln, nf in report:
        lines.append('  %-10s %5d bytes, %3d fix-ups' % (n, ln, nf))
    text = '\n'.join(lines)
    with open(os.path.join(out, 'budget.txt'), 'w') as f:
        f.write(text + '\n')
    meta = {'kmax': kmax, 'drv': drv, 'slot': slot, 'total': total, 'needs': needs, 'opk': opk, 'offs': offs}
    with open(os.path.join(out, 'build.json'), 'w') as f:
        json.dump(meta, f, indent=1)
    return text, meta


def psion_folder(opk, folder):
    """The pack's files as .OB3 procedures for RPLOAD (a real Organiser through a Comms Link)."""
    import shutil
    import subprocess
    tools = os.path.join(ROOT, '..', '..', 'Tools')
    # made in a scratch folder, then copied over: other files in psion/ (games brought back from the
    # Organiser, such as C4G2.odb) are left alone. (Until 19 Nov the folder was deleted first.)
    tmp = folder + '_tmp'
    if os.path.isdir(tmp):
        shutil.rmtree(tmp)
    subprocess.run([sys.executable, os.path.join(tools, 'opk2files.py'), '-o', tmp, opk], check=True, capture_output=True)
    for f in os.listdir(tmp):
        if f.lower().endswith('.opl'):
            os.remove(os.path.join(tmp, f))          # (the .ob3 files hold the source too)
    subprocess.run([sys.executable, os.path.join(tools, 'mkrpdata.py'), tmp, '--title', 'CONNECT 4', '--run', 'C4'],
                   check=True, capture_output=True)
    os.makedirs(folder, exist_ok=True)
    for f in os.listdir(tmp):
        shutil.copyfile(os.path.join(tmp, f), os.path.join(folder, f))
    shutil.rmtree(tmp)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=None)
    ap.add_argument('--psion', action='store_true', help='also write psion/: the files for RPLOAD')
    a = ap.parse_args()
    out = os.path.abspath(a.out) if a.out else os.path.join(ROOT, 'build', 'game')
    os.makedirs(out, exist_ok=True)
    try:
        text, _ = build(out)
    except (BuildError, pack.opl2opk.PackError) as e:
        sys.exit('build failed: %s' % e)
    print(text)
    if a.psion:
        psion_folder(os.path.join(out, 'C4.opk'), os.path.join(ROOT, 'psion'))
        print('psion/: the files for RPLOAD')


if __name__ == '__main__':
    main()
