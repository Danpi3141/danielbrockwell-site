; =====================================================================
; OV_CMD: the rarer commands, from the command table (src/kernel/kcmd.asm).
; Kernel code until 20 Nov 2026: moved here for RAM (an overlay load, about
; 30 ms, when one is used).
; =====================================================================
        include "../defs.inc"

        jmp  cm_swap            ; M_SWAP
        jmp  cm_resign          ; M_RESIGN
cm_flag:                        ; M_FLAG: the side to move ran out of time
        jsr  side_to_move
        eora #3
        oraa #8
        jmp  game_over
cm_resign:                      ; the side to move resigns
        jsr  side_to_move
        eora #3
        oraa #4
        jmp  game_over
cm_swap:
        ldaa g_psion            ; one player: the Psion takes the other side
        beq  .x
        eora #3
        staa g_psion
.x:     rts

        include "kover.asm"
