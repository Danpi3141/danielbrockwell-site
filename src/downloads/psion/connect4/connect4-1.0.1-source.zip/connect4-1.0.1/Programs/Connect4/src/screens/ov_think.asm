; =====================================================================
; OV_THINK: the search's poll (e_poll), every 64 positions: a key stops the
; search; the depth and the seconds, and the thinking bar, are shown when
; they change. Read in by think_run to the top of slot A (THINKAT), which
; the search leaves free (its table starts at DRV, its scratch follows);
; until 19 Nov it was in the kernel, in RAM all the time.
; =====================================================================
        include "../defs.inc"

; every 64 positions: a key stops the search; the depth and the seconds
; are shown when they change
think_poll:
        os   KB$TEST
        tstb
        beq  .nk
        os   KB$GETK
        inc  kv_kstop
        sec
        rts
.nk:    ldd  TMW_FRAM
        subd ot_tstart
        xgdx                    ; A = whole seconds (to 255)
        ldd  #20
        os   UT$UDIV            ; X = quotient, D = remainder
        xgdx                    ; (no search lasts 255 s)
        tba
        ldab e_dcur
        cmpa ot_tsec
        bne  .show
        cmpb ot_tdep
        beq  .x
.show:  staa ot_tsec
        stab ot_tdep
        jsr  lb_clr
        jsr  lb_s
        fcl  "depth "
        ldab ot_tdep
        clra
        jsr  lb_num
        jsr  lb_sp
        jsr  lb_sp
        ldab ot_tsec
        clra
        jsr  lb_num
        ldaa #'s'
        jsr  lb_ch
        ldaa #2                 ; line 3 on four lines; on two lines line 2,
        ldab kv_plines          ; or line 1 when the bar has line 2
        cmpb #2
        bne  .p
        ldaa #1
        ldx  e_limit
        beq  .p
        clra
.p:     jsr  lb_put
.x:     ldx  e_limit            ; the thinking bar: tenths of the positions used
        beq  .r
        ldd  #10
        os   UT$UDIV            ; X = limit / 10
        xgdx
        ldx  e_nodes
        os   UT$UDIV            ; X = positions / (limit / 10): at most 10, as
        xgdx                    ; a search stops at its limit
        cmpb ot_tbar
        beq  .r
        stab ot_tbar
        jsr  lb_clr
        ldaa #'['
        jsr  lb_ch
        ldab ot_tbar
.f:     tstb
        beq  .e
        pshb
        ldaa #'='
        jsr  lb_ch
        pulb
        decb
        bra  .f
.e:     ldaa #']'
        ldab #11
        stab kv_lp
        jsr  lb_ch
        ldaa kv_plines          ; the last line
        deca
        jsr  lb_put
.r:     clc
        rts

; its own variables: read in with it before every search, so they start as
; set here (no depth or seconds shown, no bar); think_run sets ot_tstart,
; which must be the last two bytes (the top of slot A: the build checks)
ot_tsec: fcb 0
ot_tdep: fcb 0
ot_tbar: fcb $FF
ot_tstart: fdb 0
