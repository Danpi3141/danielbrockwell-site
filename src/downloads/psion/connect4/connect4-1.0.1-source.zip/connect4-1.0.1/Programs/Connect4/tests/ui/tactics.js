// The review's tactics (OV_LIST L_TACT, shown by OV_REVIEW), worked out again on a plain board,
// apart from the engine: for move r (1-based) of a record (columns 0-6), when it made no four:
//   1 "Missed a win"  the mover had a four to make
//   2 "Allows four"   the other side has one to make now
//   3 "Allows fork"   the other side has a move after which the mover has no four to make and
//                     it has two (or one with another of its own just above it)
// 2 and 3 only when another move would have let neither happen. Else 0.
'use strict';
const TEXT = [null, 'Missed a win', 'Allows four', 'Allows fork'];

function board(rec) {             // b[c][row] = 0 empty, 1 Solid, 2 Hollow
  const b = Array.from({ length: 7 }, () => [0, 0, 0, 0, 0, 0]);
  rec.forEach((c, i) => { b[c][b[c].indexOf(0)] = (i % 2) + 1; });
  return b;
}
const top = (b, c) => b[c].indexOf(0);                     // -1: full
function fourAt(b, s, c, r) {    // would side s have four with a disc at (c, r)?
  for (const [dc, dr] of [[1, 0], [0, 1], [1, 1], [1, -1]]) {
    let n = 1;
    for (const k of [1, -1]) {
      let x = c + dc * k, y = r + dr * k;
      while (x >= 0 && x < 7 && y >= 0 && y < 6 && b[x][y] === s) { n++; x += dc * k; y += dr * k; }
    }
    if (n >= 4) return true;
  }
  return false;
}
function count(b, s) {           // the cells where s makes four now (one with another above: two)
  let n = 0;
  for (let c = 0; c < 7; c++) {
    const r = top(b, c);
    if (r < 0 || !fourAt(b, s, c, r)) continue;
    n++;
    if (r < 5 && fourAt(b, s, c, r + 1)) n++;
  }
  return n;
}
function bad(b, m) {             // m just moved (no four): 2, 3 or 0
  const o = 3 - m;
  if (count(b, o)) return 2;
  for (let c = 0; c < 7; c++) {
    const r = top(b, c);
    if (r < 0) continue;
    b[c][r] = o;
    const fork = !count(b, m) && count(b, o) >= 2;
    b[c][r] = 0;
    if (fork) return 3;
  }
  return 0;
}
function tactic(rec, r) {
  if (r === 0) return 0;
  const b = board(rec.slice(0, r - 1)), m = ((r - 1) % 2) + 1, col = rec[r - 1], row = top(b, col);
  if (fourAt(b, m, col, row)) return 0;
  if (count(b, m)) return 1;
  b[col][row] = m;
  const t = bad(b, m);
  b[col][row] = 0;
  if (!t) return 0;
  for (let c = 0; c < 7; c++) {
    const y = top(b, c);
    if (y < 0) continue;
    b[c][y] = m;
    const u = bad(b, m);
    b[c][y] = 0;
    if (!u) return t;
  }
  return 0;
}
module.exports = { tactic, TEXT, board, fourAt, count };
