// The move list for games of 1, 20, 21 and 42 moves (discs), scrolled with UP and DOWN on both
// displays: every move shown once, in order, as "n.ab" (Solid's column, then Hollow's).
'use strict';
const { Game, assert } = require('./lib');
const S = require('../../tools/solver/solver');

function noFourGame(n, seed) {      // n moves with no four (retry until one is found)
  let rnd = seed;
  const rand = k => { rnd = (rnd * 1103515245 + 12345) & 0x7fffffff; return rnd % k; };
  for (;;) {
    const p = S.fromMoves([]), seq = [];
    while (seq.length < n) {
      const ok = [0, 1, 2, 3, 4, 5, 6].filter(c => S.canPlay(p, c) && !S.isWinningMove(p, c));
      if (!ok.length) break;
      const c = ok[rand(ok.length)]; seq.push(c); S.play(p, c);
    }
    if (seq.length === n) return seq;
  }
}

for (const model of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'lz64']) {
  for (const n of [1, 20, 21, 42]) {
    const g = new Game(model).start();
    g.waitHuman(60);
    g.key('ON', 0.4); g.key('EXE', 0.4); g.key('DOWN', 0.3); g.key('EXE', 0.5); g.names();
    const seq = noFourGame(n, n * 7 + 1);
    for (const c of seq) { if (g.peek('g_over')) break; g.drop(c); }
    if (n === 42) { g.waitText(/A draw/, 10); g.key('UP', 0.8); }   // (the list from the result screen)
    else { g.waitHuman(30); g.key('UP', 0.8); }
    // collect every screen: from the end (shown first) up to the top, then down again
    const seen = new Map();
    const grab = () => {
      for (const l of g.panel()) for (const m of l.matchAll(/(\d+)\.(\d)(\d?)/g)) seen.set(+m[1], m[2] + m[3]);
    };
    grab();
    for (let i = 0; i < 12; i++) { g.key('UP', 0.4); grab(); }
    for (let i = 0; i < 12; i++) { g.key('DOWN', 0.4); grab(); }
    const want = new Map();
    for (let i = 0; i < seq.length; i += 2) want.set(i / 2 + 1, String(seq[i] + 1) + (i + 1 < seq.length ? String(seq[i + 1] + 1) : ''));
    for (const [k, v] of want) assert(seen.get(k) === v, `${model} ${n} moves: move ${k} shows ${seen.get(k)}, want ${v}`);
    assert(seen.size === want.size, `${model} ${n}: ${seen.size} moves shown, want ${want.size}`);
    console.log(model, n, 'discs: all', want.size, 'moves listed');
  }
}
