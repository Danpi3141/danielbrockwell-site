// Finishes one book subtree on many cores: its root node first, then each child's whole
// subtree on its own worker. Writes data/book_nodes_<name>.jsonl (make_book.js reads it too).
//   node tools/book/gen_one.js S 3,3        (the subtree S44: the opponent's moves 4, 4)
'use strict';
const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');
const fs = require('fs'), path = require('path');
const S = require('../solver/solver');
const G = require('./gen_book');
if (!isMainThread) {
  S.ttInit();
  const recs = [];
  G.subtree(workerData.t, workerData.opp, workerData.seq, r => recs.push(r));
  parentPort.postMessage(recs);
} else {
  const t = process.argv[2], opp = process.argv[3].split(',').map(Number);
  const name = t + opp.map(c => c + 1).join('');
  const out = path.join(__dirname, '..', '..', 'data', 'book_nodes_' + name + '.jsonl');
  // the root's position: the parent entry's book move between the opponent's moves
  const recs = new Map();
  for (const f of fs.readdirSync(path.join(__dirname, '..', '..', 'data')).filter(f => /^book_nodes.*\.jsonl$/.test(f))) {
    for (const line of fs.readFileSync(path.join(__dirname, '..', '..', 'data', f), 'utf8').split('\n')) {
      if (!line.trim()) continue; const r = JSON.parse(line); recs.set(r.t + r.opp.join(','), r);
    }
  }
  const parent = recs.get(t + opp.slice(0, -1).join(','));
  const seq = parent.seq.concat([parent.move, opp[opp.length - 1]]);
  S.ttInit();
  const t0 = Date.now();
  console.log(new Date().toISOString().slice(11, 19), 'root', name, seq.map(c => c + 1).join(''));
  const root = G.entry(t, opp, seq);
  fs.appendFileSync(out, JSON.stringify(root) + '\n');
  console.log(new Date().toISOString().slice(11, 19), 'root done in', ((Date.now() - t0) / 60000).toFixed(1), 'min: move', root.move + 1, 'code', root.code);
  const kids = G.children(root);
  let left = kids.length;
  for (const k of kids) {
    const w = new Worker(__filename, { workerData: { t, opp: k.opp, seq: k.seq } });
    w.on('message', (rs) => {
      for (const r of rs) fs.appendFileSync(out, JSON.stringify(r) + '\n');
      console.log(new Date().toISOString().slice(11, 19), 'child', k.opp.map(c => c + 1).join(''), rs.length, 'entries');
      if (--left === 0) { console.log('done', name, ((Date.now() - t0) / 60000).toFixed(1), 'min'); process.exit(0); }
    });
  }
}
