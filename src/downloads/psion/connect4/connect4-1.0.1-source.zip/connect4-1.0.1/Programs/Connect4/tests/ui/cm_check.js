'use strict';
const { Machine } = require('../../tools/emu');
const m = new Machine({ rom: '33-cm.rom', ram: 8 });
m.boot();
m.insertPack(__dirname + '/../../build/game/C4.opk', 0);
m.runProc('C4', 'B');
m.runSeconds(7);
const u = m.udgs();
const show = () => { const u = m.udgs(); for (let r = 0; r < 8; r++) console.log([0,1,2,3].map(g => u[g][r].toString(2).padStart(5, '0').replace(/0/g, '.').replace(/1/g, '#')).join(' ') + '   ' + [4,5,6,7].map(g => u[g][r].toString(2).padStart(5, '0').replace(/0/g, '.').replace(/1/g, '#')).join(' ')); };
console.log(m.screen().join('\n')); show();
for (const k of ['LEFT', 'EXE']) { m.press(k, 3, 10); }
m.runSeconds(12);
console.log(m.screen().join('\n')); show();
// the save file on A: and free memory: leave and look at the directory
m.press('ON', 3, 10); m.runSeconds(1);
console.log(m.screen().join('\n'));
