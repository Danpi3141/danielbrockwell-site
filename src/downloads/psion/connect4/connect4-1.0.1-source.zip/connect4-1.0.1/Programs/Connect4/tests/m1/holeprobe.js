// The kernel keeps its working variables (KH, src/kernel/kvars.inc) in C4G's copy of the
// bootstrap string: C4G's object code stays in RAM all game. Checks on every ROM that they are
// there: the string's Q-code header (push string, length) just below them, kv_base holding the
// array's address, and the Q-code after the string intact (C4G returns through it).
//   node tests/m1/holeprobe.js [rom ...]
'use strict';
const fs = require('fs'), path = require('path');
const { Game, ROMS, ROOT } = require('../ui/lib');

const opl = fs.readFileSync(path.join(ROOT, 'build', 'game', 'C4G.opl'), 'latin1');
const boot = Buffer.from(opl.match(/MID\$\("((?:[^"]|"")*)"/)[1].replace(/""/g, '"'), 'latin1');
const roms = process.argv.slice(2).length ? process.argv.slice(2) : Object.keys(ROMS);
let bad = 0;
for (const rom of roms) {
  const g = new Game(rom).start();
  g.waitHuman(60);
  g.sync(); const kh = g.a('kh_first'), probs = [];
  if (g.m.peek(kh - 2) !== 0x24 || g.m.peek(kh - 1) !== boot.length) probs.push(`no string header below KH (${g.m.peek(kh - 2).toString(16)} ${g.m.peek(kh - 1)})`);
  if (g.peekw('kv_base') !== g.base) probs.push(`kv_base ${g.peekw('kv_base').toString(16)}, array ${g.base.toString(16)}`);
  // after the string: ",i%-(-1),1))" in Q-code begins with the push of i% (00 ed f0 on this C4G)
  if (g.m.peek(kh + boot.length) !== 0x00) probs.push('the Q-code after the string changed');
  console.log(`${rom.padEnd(14)} array ${g.base.toString(16)}, KH ${kh.toString(16)} (${kh - g.base}) ${probs.length ? 'FAIL ' + probs.join('; ') : 'ok'}`);
  if (probs.length) bad++;
}
console.log(bad ? `${bad} ROMs FAILED` : `all ${roms.length} ROMs ok`);
process.exitCode = bad ? 1 : 0;
