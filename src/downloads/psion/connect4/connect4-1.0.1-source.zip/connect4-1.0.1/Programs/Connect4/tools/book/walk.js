// The book walk on the PC (spec "Following the book"): for a game record (columns 0-6) with
// the Psion to move, the entry's code from data/book.bin, or 0.
'use strict';
const fs = require('fs'), path = require('path');
const B = require('./make_book');
const bytes = fs.readFileSync(path.join(__dirname, '..', '..', 'data', 'book.bin'));
function walk(rec, psionFirst) {
  const n = rec.length;
  if (psionFirst ? n % 2 !== 0 : n % 2 !== 1) throw new Error('not the Psion to move');
  if (psionFirst && n === 0) return B.read(bytes, 0);
  if (psionFirst && rec[0] !== 3) return 0;
  const oppFirst = psionFirst ? rec[1] : rec[0];
  const mir = oppFirst >= 4;
  const m = (c) => (mir ? 6 - c : c);
  const opp = [], own = [];
  for (let i = 0; i < n; i++) ((i % 2 === 0) === psionFirst ? own : opp).push(m(rec[i]));
  const t = psionFirst ? 'F' : 'S';
  // each of the Psion's moves so far must be the book's (in the mirrored frame)
  for (let j = psionFirst ? 1 : 0; j < own.length; j++) {
    const o = opp.slice(0, psionFirst ? j : j + 1);
    if (o.length > 5) return 0;
    const code = B.read(bytes, B.index(t, o));
    if (!code || ((code - 1) % 7) !== own[j]) return 0;
  }
  if (opp.length > 5) return 0;
  return B.read(bytes, B.index(t, opp));
}
function codeCol(code, rec, psionFirst) {
  const oppFirst = psionFirst ? rec[1] : rec[0];
  const c = (code - 1) % 7;
  return rec.length >= (psionFirst ? 2 : 1) && oppFirst >= 4 ? 6 - c : c;
}
module.exports = { walk, codeCol };
