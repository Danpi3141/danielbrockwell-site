; =====================================================================
; Four-line screen driver (LZ, LZ64). Loaded at DRV.
; The board: 7 characters wide on lines 1-3, each character two cells
; (rows 6/5, 4/3, 2/1); 1234567 under it on line 4. The panel: 12
; characters from column 9 on all four lines. The glyphs are defined once.
; =====================================================================
        include "../defs.inc"

        jmp  d4_init
        jmp  d4_glyphs
        jmp  d4_cell
        jmp  d4_board
        jmp  d4_mark

d4_init:
        ldaa #4
        staa kv_plines
        ldd  #$081C             ; panel at columns 9: positions 8, 28, 48, 68
        std  kv_ppos
        ldd  #$3044
        std  kv_ppos+2
        bsr  d4_glyphs
        clra
        clrb
        os   DP$STAT            ; cursor off
        ldaa #12
        os   DP$EMIT            ; clear
        ldaa #60                ; line 4: the column numbers
        clrb
        os   DP$STAT
        ldx  #d4_nums
        ldab #7
        os   DP$PRNT
        rts
d4_nums: fcc "1234567"

; the 8 glyphs straight into the display chip
d4_glyphs:
        ldab #$40
        bsr  lcd_cmd
        ldx  #d4_gl
.l:     ldab 0,x
        bsr  lcd_dat
        inx
        cpx  #d4_gl+64
        bne  .l
        rts

lcd_cmd: ldaa LCD_CTRL
        bmi  lcd_cmd
        stab LCD_CTRL
        rts
lcd_dat: ldaa LCD_CTRL
        bmi  lcd_dat
        stab LCD_DATA
        rts

; A = column, B = row: the character holding that cell, from e_bd
d4_cell:
        andb #$FE               ; the pair's lower row
        staa d4_c
        stab d4_r
        ldab #7
        mul
        addb d4_r
        ldx  #e_bd
        abx
        ldab 0,x                ; lower cell
        ldaa 1,x                ; upper cell
        ldx  #d4_map            ; (upper*3 + lower)
        abx
        tab
        aslb
        aba                     ; A = upper*3
        tab
        abx
        ldaa 0,x                ; the character
        psha
        ldaa #4                 ; line = 2 - row/2; position = line*20 + column
        suba d4_r
        lsra                    ; (rows 0/2/4 -> lines 2/1/0)
        ldab #20
        mul
        addb d4_c
        tba
        clrb
        os   DP$STAT
        pula
        os   DP$EMIT
        rts

; the whole board
d4_board:
        clr  d4_bc
.c:     clr  d4_br
.r:     ldaa d4_bc
        ldab d4_br
        bsr  d4_cell
        ldaa d4_br
        adda #2
        staa d4_br
        cmpa #6
        bne  .r
        inc  d4_bc
        ldaa d4_bc
        cmpa #7
        bne  .c
        rts

; A = side: its disc in the panel (glyph 0 Solid, 1 Hollow: the lower cell)
d4_mark:
        deca
        rts

; (upper, lower) -> character: 0 empty, 1 Solid, 2 Hollow
d4_map: fcb  ' ',0,1, 6,2,5, 7,4,3
; glyphs: upper cell dot rows 0-2, lower cell 4-6
SD      = $0E                   ; .###.
SF      = $1F                   ; #####
HO      = $11                   ; #...#
d4_gl:  fcb  0,0,0,0, SD,SF,SD,0        ; 0: empty over Solid
        fcb  0,0,0,0, SD,HO,SD,0        ; 1: empty over Hollow
        fcb  SD,SF,SD,0, SD,SF,SD,0     ; 2: Solid over Solid
        fcb  SD,HO,SD,0, SD,HO,SD,0     ; 3: Hollow over Hollow
        fcb  SD,HO,SD,0, SD,SF,SD,0     ; 4: Hollow over Solid
        fcb  SD,SF,SD,0, SD,HO,SD,0     ; 5: Solid over Hollow
        fcb  SD,SF,SD,0, 0,0,0,0        ; 6: Solid over empty
        fcb  SD,HO,SD,0, 0,0,0,0        ; 7: Hollow over empty

d4_c:   fcb  0
d4_r:   fcb  0
d4_bc:  fcb  0
d4_br:  fcb  0
