'use strict';
const { Game } = require('./lib');
const g = new Game(process.argv[2] || 'lz64').start();
g.waitHuman(60);
g.poke('st_pace', 1);
g.drop(3); g.waitHuman();
console.log(g.text());
g.m.press('UP', 3, 0);
for (let i = 0; i < 8; i++) { g.m.runSeconds(0.15); console.log('--', i, g.panel().join('|')); }
