; =====================================================================
; OV_IMPORT: choose a game file: A:C4LAST ("Last game", the last game
; finished: OV_EXPORT's X_END) and A:C4Gn, each with its number of moves
; ("C4G3   30"); OV_EXPORT's X_READ reads it and plays it through.
; Returns nothing (A = 0) if no file is chosen.
; Each record is read in the screen driver's area (a record can be 254
; bytes), and the list is built there, as are the names; the driver is read
; in again after (by X_READ, or here). (Until 19 Nov the top 120 bytes of
; slot A were its buffer.)
; =====================================================================
        include "../defs.inc"

FN      = DRV                   ; a file name, with its length
RD      = DRV+16                ; a record, with its length; then the list (up to 19 x 12 bytes)
MAXN    = 19                    ; the last game and 18 others

        jmp  im_start

im_start:
        clr  im_n               ; the files there: their numbers and moves
        clr  ex_k               ; (0: A:C4LAST)
.f:     jsr  ex_name
        clr  kv_pkok
        ldx  #FN
        os   FL$OPEN
        bcs  .nx
        tab
        os   FL$RECT
        clra
        clrb
        os   FL$SETP
        ldd  #1
        os   FL$RSET
        bcs  .nx
        ldx  #RD
        os   FL$READ
        bcs  .nx
        ldab im_n
        cmpb #MAXN
        bhs  .nx
        ldx  #im_num
        abx
        ldaa ex_k
        staa 0,x
        ldab RD                 ; its moves: the record's length (A:C4LAST: its count)
        tsta
        bne  .c
        ldab RD+1
.c:     stab MAXN,x
        inc  im_n
.nx:    inc  ex_k
        ldaa ex_k
        cmpa #100
        bne  .f
        clr  kv_pkok
        ldaa im_n
        bne  .list
        jsr  lb_clr
        jsr  lb_s
        fcl  "No games"
        clra
        jsr  lb_put
        clra
        jsr  key_wait
        bra  .none
.list:  ldx  #RD                ; the list: "Last game", "C4Gk   30" (11 at most)
        stx  im_p
        clr  im_i
.m:     ldab im_i
        ldx  #im_num
        abx
        ldaa 0,x
        staa ex_k
        ldab MAXN,x
        stab im_mv
        jsr  lb_clr
        tst  ex_k
        bne  .g
        jsr  lb_s
        fcl  "Last game"
        bra  .t
.g:     jsr  ex_name
        ldab FN                ; the name without "A:"
        subb #2
        stab FN+2
        ldx  #FN+2
        jsr  lb_fcl
.pd:    jsr  lb_sp              ; the moves from column 8
        ldab kv_lp
        cmpb #7
        blo  .pd
        ldab im_mv
        clra
        jsr  lb_num
.t:     ldx  im_p               ; the item, with its length
        ldab kv_lp
        stab 0,x
        inx
        clra
        std  T0
        xgdx
        ldx  #kv_lb
        os   UT$CPYB
        ldab kv_lp
        incb
        ldx  im_p
        abx
        stx  im_p
        inc  im_i
        ldaa im_i
        cmpa im_n
        bne  .m
        ldx  #RD
        ldaa im_n
        clrb
        jsr  menu
        cmpa #$FF
        beq  .none
        tab                     ; its number to OV_EXPORT, which reads it
        ldx  #im_num
        abx
        ldab 0,x
        clra
        xgdx
        ldd  #OV_EXPORT*256+X_READ
        jmp  ov_call
.none:  clr  kv_pkok            ; the driver again (its area held the list)
        ldaa kv_drv
        jsr  ov_load
        clra
        rts

; FN = "A:C4Gk" with a leading length (k = ex_k), or "A:C4LAST" (k = 0)
ex_name:
        ldd  #'A'*256+':'
        std  FN+1
        ldd  #'C'*256+'4'
        std  FN+3
        ldab ex_k
        bne  .g
        ldd  #'L'*256+'A'
        std  FN+5
        ldd  #'S'*256+'T'
        std  FN+7
        ldab #8
        bra  .n
.g:     ldaa #'G'
        staa FN+5
        ldx  #FN+6
        clra
        os   UT$UTOB
        addb #5
.n:     stab FN
        rts

ex_k:   fcb  0
im_n:   fcb  0
im_i:   fcb  0
im_mv:  fcb  0
im_p:   fdb  0
im_num: rmb  MAXN               ; then their moves
im_mvs: rmb  MAXN

MENU_V  = 0
        include "../kernel/kmenu.asm"
