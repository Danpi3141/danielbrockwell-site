// A contact sheet of the tour's screenshots (tests/ui/tour.js), numbered, for reviewing:
//   node tests/ui/sheet.js cm [cols]  ->  build/shots/cm_sheet.png
'use strict';
const fs = require('fs'), path = require('path'), zlib = require('zlib');
const { ROOT } = require('./lib');
const { pngEncode } = (() => {
  const s = require('./shots');
  return { pngEncode: s.png };
})();

function readPng(file) {             // only our own PNGs: 8-bit RGB, filter 0
  const b = fs.readFileSync(file);
  let p = 8, w = 0, h = 0; const idat = [];
  while (p < b.length) {
    const len = b.readUInt32BE(p), type = b.toString('latin1', p + 4, p + 8), data = b.subarray(p + 8, p + 8 + len);
    if (type === 'IHDR') { w = data.readUInt32BE(0); h = data.readUInt32BE(4); }
    if (type === 'IDAT') idat.push(data);
    p += 12 + len;
  }
  const raw = zlib.inflateSync(Buffer.concat(idat)), rgb = Buffer.alloc(w * h * 3);
  for (let y = 0; y < h; y++) raw.copy(rgb, y * w * 3, y * (w * 3 + 1) + 1, (y + 1) * (w * 3 + 1));
  return { w, h, rgb };
}

// 3x5 digits for the numbers
const DIG = ['111101101101111', '010110010010111', '111001111100111', '111001111001111', '101101111001001',
  '111100111001111', '111100111101111', '111001001001001', '111101111101111', '111101111001111'];

const model = process.argv[2] || 'cm', cols = +(process.argv[3] || 2);
const dir = path.join(ROOT, 'build', 'shots', model);
const files = fs.readdirSync(dir).filter(f => /^\d\d_.*\.png$/.test(f)).sort();
const imgs = files.map(f => readPng(path.join(dir, f)));
const iw = imgs[0].w, ih = imgs[0].h, lab = 28, gap = 8;
const rows = Math.ceil(imgs.length / cols);
const W = cols * (lab + iw + gap) + gap, H = rows * (ih + gap) + gap;
const out = Buffer.alloc(W * H * 3, 255);
imgs.forEach((im, i) => {
  const cx = gap + (i % cols) * (lab + iw + gap), cy = gap + Math.floor(i / cols) * (ih + gap);
  for (let y = 0; y < im.h; y++) im.rgb.copy(out, ((cy + y) * W + cx + lab) * 3, y * im.w * 3, (y + 1) * im.w * 3);
  const num = String(i + 1).padStart(2, '0');
  [...num].forEach((d, k) => {
    const pat = DIG[+d];
    for (let r = 0; r < 5; r++) for (let c = 0; c < 3; c++) if (pat[r * 3 + c] === '1')
      for (let dy = 0; dy < 3; dy++) for (let dx = 0; dx < 3; dx++) {
        const x = cx + k * 12 + c * 3 + dx, y = cy + 4 + r * 3 + dy;
        out[(y * W + x) * 3] = out[(y * W + x) * 3 + 1] = out[(y * W + x) * 3 + 2] = 0;
      }
  });
});
const f = path.join(ROOT, 'build', 'shots', model + '_sheet.png');
fs.writeFileSync(f, pngEncode(W, H, out));
console.log(f, W + 'x' + H, files.length, 'shots');
