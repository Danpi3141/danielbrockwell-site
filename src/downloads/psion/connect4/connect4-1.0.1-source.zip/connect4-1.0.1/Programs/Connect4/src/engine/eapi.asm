; =====================================================================
; Engine calls for the kernel
; =====================================================================

; eng_reset: an empty board. (20 Nov 2026: the clearing by the ROM's
; UT$FILL and one loop for the stop row and the landing cells, 33 bytes
; for 53; reading the empty position from the pack was 15 bytes, but its
; seek back cost about 55 ms a call, on every step of the review.)
eng_reset:
        ldx  #e_bd              ; e_bd to e_won: 0
        ldd  #e_won+1-e_bd      ; (A = 0, B = the count)
        os   UT$FILL
        ldx  #e_land
        clra
.l:     staa 0,x                ; a column's landing cell: 7 * column
        pshx
        ldx  #e_bd+6
        tab
        abx
        ldab #3
        stab 0,x                ; its stop row
        pulx
        inx
        adda #7
        cmpa #49
        bne  .l
        rts
