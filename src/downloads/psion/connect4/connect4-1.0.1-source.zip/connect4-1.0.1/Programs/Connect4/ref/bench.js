// Search-efficiency benchmark for engine options (ref/engine.js opts), on positions from
// engine-v-engine games (level 5) started from Tromp's 8-ply positions:
//  - middle game: positions with 10..26 discs searched to a fixed depth (8): total positions, and
//    how often the move or score differ from the plain engine's;
//  - endings: positions with 16, 18, 20 and 22 empty cells: solved exactly within the level-8
//    budget (30,000 positions)? and the positions a full solve takes (capped at 400,000).
//   node ref/bench.js '<opts json>' [games]     e.g. node ref/bench.js '{"pvs":1}' 40
'use strict';
const E = require('./engine'), S = require('../tools/solver/solver'), T = require('../tools/solver/tromp');
S.ttInit();
const opts = JSON.parse(process.argv[2] || '{}');
const G = +(process.argv[3] || 40);
const db = T.load();
let rnd = 4242; const rand = n => { rnd = (rnd * 1103515245 + 12345) & 0x7fffffff; return rnd % n; };
const mids = [], ends = [];
for (let g = 0; g < G; g++) {
  const start = db[rand(db.length)];
  const cols = require('./strength_moves')(S.clone(start.p));
  const e = new E.Engine();
  for (const c of cols) e.make(c);
  const rec = cols.slice();
  for (;;) {
    if (e.n >= 10 && e.n <= 26 && e.n % 4 === g % 4) mids.push(rec.slice());
    const empt = 42 - e.n;
    if ([16, 18, 20, 22].includes(empt)) ends.push(rec.slice());
    if (empt <= 15) break;
    const r = e.think({ nodes: 1500, seed: g + e.n });
    if (r.move < 0 || e.make(r.move)) break;
    rec.push(r.move);
  }
}
const load = (seq, o) => { const e = new E.Engine(o); for (const c of seq) e.make(c); return e; };
let mNodes = 0, mBase = 0, mDiff = 0;
for (const seq of mids) {
  const b = load(seq, {}).think({ depth: 8 });
  const r = load(seq, opts).think({ depth: 8 });
  mNodes += r.nodes; mBase += b.nodes;
  if (r.move !== b.move || r.score !== b.score) mDiff++;
}
const out = [`opts ${JSON.stringify(opts)}: middle game, ${mids.length} positions to depth 8: ${mNodes} positions (plain ${mBase}, ${(100 * mNodes / mBase).toFixed(1)}%), move or score differs ${mDiff}`];
for (const k of [16, 18, 20, 22]) {
  const set = ends.filter(s => 42 - s.length === k);
  let inBudget = 0, full = 0, solved = 0, wrong = 0;
  for (const seq of set) {
    const r = load(seq, opts).think({ nodes: 30000 });
    if (r.exact) {
      inBudget++;
      const truth = Math.sign(S.solve(S.fromMoves(seq), true));
      if (Math.sign(r.score) !== truth) wrong++;
    }
    const f = load(seq, opts).think({ nodes: 400000 });
    if (f.exact) { solved++; full += f.nodes; }
  }
  out.push(`  ${k} empty: ${set.length} positions, exact within 30,000: ${inBudget} (${wrong} wrong), full solves ${solved} in ${solved ? (full / solved).toFixed(0) : '-'} positions on average`);
}
console.log(out.join('\n'));
