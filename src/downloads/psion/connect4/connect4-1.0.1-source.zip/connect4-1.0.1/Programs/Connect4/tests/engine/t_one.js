// one search, asm v ref, with the iterations traced: node tests/engine/t_one.js <moves 1-7> <level> <seed>
'use strict';
const { Harness } = require('./harness');
const E = require('../../ref/engine');
const h = new Harness({ build: false });
const [seq, lvn, seed] = [process.argv[2], +process.argv[3], +process.argv[4]];
const lv = E.LEVELS[lvn];
const e = new E.Engine(); h.call('eng_reset');
for (const ch of seq) { e.make(+ch - 1); h.call('e_make', +ch - 1); }
for (let lim = lv.nodes - 3; lim <= lv.nodes; lim++) {
  const o = { nodes: lim, depth: lv.depth, noise: lv.noise, seed };
  const w = e.think(o), g = h.think(o);
  console.log(lim, 'ref', w.move, w.score, w.depth, w.nodes, ' asm', g.move, g.score, g.depth, g.nodes);
}
