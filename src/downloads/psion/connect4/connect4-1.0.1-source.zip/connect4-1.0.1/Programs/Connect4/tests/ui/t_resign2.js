// Resigning with two players: the winner's name (the one not to move) and "by surrender".
// (One player, "Psion wins / You resigned": t_features.js, t_tally.js.)
'use strict';
const { Game, assert } = require('./lib');
for (const model of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'lz64']) {
  const g = new Game(model).start();
  g.waitHuman();
  g.keys(['ON', 'EXE'], 0.5);                 // menu, New game
  g.keys(['DOWN', 'EXE'], 0.5);               // Two players
  g.names('ANN', '');                         // player 1 is ANN (Solid), player 2 no name
  g.drop(3); g.drop(3); g.drop(2);            // Hollow to move
  g.keys(['ON', 'R', 'R', 'EXE'], 2);         // Resign
  g.waitText(/surrender/, 5);
  g.m.runSeconds(0.5);
  assert(/ANN wins/.test(g.text()), 'two players, Hollow resigns: ' + g.text());
  console.log(model, 'ok:', g.panel().map(s => s.trim()).filter(Boolean).join(' | '));
}
