'use strict';
const { Game } = require('./lib');
const g = new Game('lz64').start();
g.waitHuman(60);
g.poke('st_clock', 1);
g.key('ON', 0.5); g.key('N', 0.3); g.key('EXE', 0.8); g.key('DOWN', 0.3); g.key('EXE', 1.5);
for (let i = 0; i < 6; i++) { g.m.runSeconds(1); console.log(i, g.bytes('g_clk', 4).join(','), 'mode', g.peek('g_mode'), g.panel().join('|'), 'res', g.peek('kv_res')); }
