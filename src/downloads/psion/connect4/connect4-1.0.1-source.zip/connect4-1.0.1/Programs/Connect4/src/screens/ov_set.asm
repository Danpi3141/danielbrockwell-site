; =====================================================================
; OV_SET: the settings. UP/DOWN choose, LEFT/RIGHT change, EXE or
; ON/CLEAR go back. kv_arg = the line to start on.
; =====================================================================
        include "../defs.inc"

N_SET   = 16

        jmp  se_start

se_start:
        ldab kv_arg
.again: stab se_i
        ldaa #1
        staa mn_lr
        ldx  #se_val
        stx  mn_val
        ldx  #se_items
        ldaa #N_SET
        jsr  menu_v
        cmpa #$FF
        beq  .x                 ; ON: done
        cmpa #$FD
        blo  .x                 ; EXE: done
        stab se_i
        ldx  #st_level          ; the setting's byte
        abx
        stx  se_p
        aslb                    ; its range: min, max
        ldx  #se_rng
        abx
        ldab 0,x
        stab se_min
        ldab 1,x
        stab se_max
        ldx  se_p
        ldab 0,x
        cmpa #$FE
        beq  .dn
        incb                    ; RIGHT: up, round to the lowest
        cmpb se_max
        bls  .st
        ldab se_min
        bra  .st
.dn:    decb                    ; LEFT: down, round to the highest
        cmpb se_min
        bge  .st
        ldab se_max
.st:    stab 0,x
        ldab se_i
        bra  .again
.x:     rts

; A = item: its value, from column 9 of the line
se_val: psha
        ldaa #8
        staa kv_lp
        pula
        tab
        ldx  #st_level
        abx
        ldaa 0,x                ; the value
        aslb
        ldx  #se_txt
        abx
        ldx  0,x                ; its words, or 0: a number
        bne  .w
        cmpa #9
        bne  .num
        ldx  #se_auto
        jmp  lb_fcl
.num:   tab
        clra
        jmp  lb_num
.w:     tsta                    ; the value's word
        beq  .p
        ldab 0,x
        incb
        abx
        deca
        bra  .w
.p:     jmp  lb_fcl

se_items:
        fcl  "Level"
        fcl  "Play"
        fcl  "Coach"
        fcl  "Hints"
        fcl  "Undo"
        fcl  "Keep"
        fcl  "Pace"
        fcl  "Sound"
        fcl  "Digits"
        fcl  "Starts"
        fcl  "Swap"
        fcl  "Timer"
        fcl  "Match"
        fcl  "Clock"
        fcl  "Demo S"
        fcl  "Demo H"
se_rng: fcb  1,9, 0,2, 0,1, 0,1, 0,1, 0,2, 0,1, 0,2, 0,1, 0,2, 0,1, 0,3, 0,3, 0,4, 1,8, 1,8
se_txt: fdb  0, se_play, se_off, se_yes, se_yes, se_kp, se_pace, se_snd, se_off, se_who, se_off, se_tmr, se_mat, se_clk, 0, 0
se_auto: fcl "Auto"
se_play: fcl "1st"
        fcl  "2nd"
        fcl  "Alt"
se_kp:  fcl  "Ask"              ; Keep: a finished game exported (asked, all, off: the next word)
        fcl  "All"
se_off: fcl  "Off"
        fcl  "On"
se_yes: fcl  "Yes"
        fcl  "No"
se_pace: fcl "Nat"
        fcl  "Fast"
se_snd: fcl  "All"
        fcl  "Tick"
        fcl  "Off"
se_who: fcl  "Alt"
        fcl  "Lost"             ; (who starts: the one who lost, or won; 4 letters fit)
        fcl  "Won"
se_tmr: fcl  "Off"
        fcl  "10s"
        fcl  "20s"
        fcl  "30s"
se_mat: fcl  "1"
        fcl  "3"
        fcl  "5"
        fcl  "10"
se_clk: fcl  "None"
        fcl  "1m"
        fcl  "3m"
        fcl  "5m"
        fcl  "10m"
se_i:   fcb  0
se_p:   fdb  0
se_min: fcb  0
se_max: fcb  0

MENU_V  = 1
        include "../kernel/kmenu.asm"
