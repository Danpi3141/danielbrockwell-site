; =====================================================================
; OV_SETUP: set up a position, starting from the one on the board.
; LEFT/RIGHT choose a column, S or H adds a disc, DEL takes the top one
; off, EXE plays on from there, ON/CLEAR leaves it as it was.
; The position is refused if one side is more than a disc ahead (Solid
; moves first), if a four is made, or if no game could reach it: a move
; order alternating the sides is searched for, and becomes the record.
; Leaving goes on to OV_GAME: G_RSAVE (a new record) or G_REPLAY (as it was).
; =====================================================================
        include "../defs.inc"

ST      = BUF+17                ; the search: next try per depth (42), the order (42), in
ORD     = BUF+65                ; the top 103 bytes of slot A (BUF is the top 120)
PTR     = BUF+113               ; discs used per column (7)

        jmp  su_start

su_start:
        ldaa #3
        staa su_c
.show:  jsr  lb_clr
        jsr  lb_s
        fcl  "Set up col "
        ldaa su_c
        adda #'1'
        jsr  lb_ch
        clra
        jsr  lb_put
        jsr  lb_clr
        jsr  lb_s
        fcl  "S H DEL EXE"
        ldaa #1
        jsr  lb_put
        clra
        jsr  key_wait
        ldaa su_c
        cmpb #K_LEFT
        bne  .r
        deca
        bmi  .show
        bra  .c
.r:     cmpb #K_RIGHT
        bne  .s
        inca
        cmpa #7
        beq  .show
.c:     staa su_c
        bra  .show
.s:     cmpb #'S'
        bne  .h
        ldab #1
        bra  .add
.h:     cmpb #'H'
        bne  .d
        ldab #2
.add:   stab su_v
        bsr  su_cell            ; X -> the landing cell's byte
        ldaa 0,x
        cmpa #3
        beq  .show              ; full
        ldaa su_v
        staa 0,x
        ldx  su_lp
        inc  0,x
        decb                    ; (B = the cell filled - 1 after the inc below)
        incb
        bra  .draw
.d:     cmpb #K_DEL
        bne  .e
        bsr  su_cell
        cmpb su_c7              ; empty column?
        beq  .show
        dex
        clr  0,x
        ldx  su_lp
        dec  0,x
        ldab 0,x                ; the cell emptied
.draw:  subb su_c7              ; B = its row
        ldaa su_c
        jsr  DRV+DV_CELL
        jmp  .show
.e:     cmpb #K_ON
        bne  .x
        ldd  #OV_GAME*256+G_REPLAY  ; (the board was changed meanwhile)
        jmp  ov_call
.x:     cmpb #K_EXE
        bne  .show
        jmp  su_done

; X -> the landing cell of column su_c in e_bd, su_lp -> its e_land byte,
; B = the landing cell, su_c7 = column * 7
su_cell:
        ldaa su_c
        ldab #7
        mul
        stab su_c7
        ldx  #e_land
        ldab su_c
        abx
        stx  su_lp
        ldab 0,x
        ldx  #e_bd
        abx
        rts

; EXE: count, then search for a move order
su_done:
        clr  su_ns
        clr  su_nh
        ldx  #e_bd
.ct:    ldaa 0,x
        cmpa #1
        bne  .c2
        inc  su_ns
.c2:    cmpa #2
        bne  .c3
        inc  su_nh
.c3:    inx
        cpx  #e_bd+49
        bne  .ct
        ldaa su_ns
        suba su_nh
        cmpa #1
        bhi  .bad               ; (also catches Hollow ahead: negative)
        ldaa su_ns
        adda su_nh
        staa su_tot
        ldx  #ST                ; the search
        ldab #48+48+7
.z:     clr  0,x
        inx
        decb
        bne  .z
        clr  su_k
        ldd  #0
        std  su_steps
.at:    ldab su_k
        cmpb su_tot
        beq  .found
        ldx  #ST
        abx
        ldaa 0,x                ; the next column to try at this depth
.try:   cmpa #7
        bhs  .back
        staa su_try
        tab                     ; its next disc: cell col*7 + used
        ldx  #PTR
        abx
        ldab #7
        mul
        addb 0,x
        stab su_t
        ldx  #e_bd
        abx
        ldab 0,x
        beq  .no                ; (none left: empty above)
        cmpb #3
        beq  .no
        ldaa su_k               ; the side to play at depth k: Solid on even
        anda #1
        inca
        cba
        beq  .yes
.no:    ldaa su_try
        inca
        bra  .try
.yes:   ldab su_try             ; take it
        ldx  #PTR
        abx
        inc  0,x
        ldab su_k
        ldx  #ORD
        abx
        ldaa su_try
        staa 0,x
        ldx  #ST
        abx
        inca
        staa 0,x                ; (next time here: the column after)
        inc  su_k
        ldab su_k
        ldx  #ST
        abx
        clr  0,x
        ldd  su_steps
        addd #1
        std  su_steps
        cmpa #20                ; give up after 5,120 steps
        bhs  .bad
        bra  .at
.back:  ldab su_k
        beq  .bad               ; nothing works
        dec  su_k
        ldab su_k
        ldx  #ORD
        abx
        ldab 0,x                ; undo that column's disc
        ldx  #PTR
        abx
        dec  0,x
        ldab su_k
        ldx  #ST
        abx
        ldaa 0,x
        jmp  .try
.found: jsr  eng_reset          ; replay the order: a four anywhere is refused
        clr  su_k
.mk:    ldab su_k
        cmpb su_tot
        beq  .chk
        ldx  #ORD
        abx
        ldaa 0,x
        jsr  e_make
        inc  su_k
        bra  .mk
.chk:   tst  e_won
        bne  .bad
        ldab su_tot             ; it becomes the game, two moves a byte
        stab g_n
        beq  .r
        incb
        lsrb
        stab su_k
        ldx  #ORD
        stx  kv_t0
        ldx  #g_rec
.cp:    pshx
        ldx  kv_t0
        ldd  0,x                ; (past the end: a nibble never read)
        inx
        inx
        stx  kv_t0
        pulx
        aslb
        aslb
        aslb
        aslb
        aba
        staa 0,x
        inx
        dec  su_k
        bne  .cp
.r:     ldd  #OV_GAME*256+G_RSAVE
        jmp  ov_call
.bad:   jsr  lb_clr
        jsr  lb_s
        fcl  "Not possible"
        clra
        jsr  lb_put
        clra
        jsr  key_wait
        jmp  su_start

su_c:   fcb  0
su_c7:  fcb  0
su_v:   fcb  0
su_lp:  fdb  0
su_ns:  fcb  0
su_nh:  fcb  0
su_tot: fcb  0
su_k:   fcb  0
su_try: fcb  0
su_t:   fcb  0
su_steps: fdb 0
