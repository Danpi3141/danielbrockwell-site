// A CM with its RAM filling up: exported 30-disc games on A: until an export is refused. Since 19
// Nov that happens while C4 can still start (OV_EXPORT keeps KEEP_GAP free below the array); until
// then the last export left C4 72 bytes short, and C4 said so. (The spec's "it says how many bytes
// are missing" still holds when other files fill the RAM.)
'use strict';
const { Game, assert } = require('./lib');
const S = require('../../tools/solver/solver');
let rnd = 5; const rand = n => { rnd = (rnd * 1103515245 + 12345) & 0x7fffffff; return rnd % n; };
const p = S.fromMoves([]), seq = [];
while (seq.length < 30) {
  const ok = [0, 1, 2, 3, 4, 5, 6].filter(c => S.canPlay(p, c) && !S.isWinningMove(p, c));
  const c = ok[rand(ok.length)]; seq.push(c); S.play(p, c);
}
const g = new Game('cm').start();
g.waitHuman(60);
g.key('ON', 0.4); g.key('EXE', 0.4); g.key('DOWN', 0.3); g.key('EXE', 0.5); g.names();   // two players
for (const c of seq) g.drop(c);
let n = 0;
for (; n < 40; n++) {
  g.waitHuman(30);
  g.key('ON', 0.4); g.key('E', 0.3); g.key('EXE', 0.3);
  g.waitFor(() => /Saved C4G|Cannot/.test(g.text()), 10);   // (saving slows as A: fills)
  const t = g.text();
  if (!/Saved C4G/.test(t)) { console.log('export', n + 1, 'refused:', t.replace(/\n/g, '|')); g.key('EXE', 0.5); break; }
  g.key('EXE', 0.5);
}
console.log('exported', n, 'games of', seq.length, 'discs');
g.waitHuman(30);
g.key('ON', 0.4); g.key('L', 0.3); g.key('L', 0.3); g.key('EXE', 2);    // leave
g.start(); g.m.runSeconds(3);
const t = g.text();
console.log('C4 then shows:', t.replace(/\n/g, '|'));
assert(n < 40, 'A: never filled');
assert(!/NEEDS/.test(t) && g.findBase() >= 0, 'after the refused export C4 still starts');
