'use strict';
const { Harness } = require('./harness');
const E = require('../../ref/engine');
const h = new Harness({ build: false });
const [seq, lim] = [process.argv[2], +process.argv[3]];
const e = new E.Engine(); h.call('eng_reset');
for (const ch of seq) { e.make(+ch - 1); h.call('e_make', +ch - 1); }
const rl = [];
const st = e.ttStore.bind(e);
e.ttStore = (d, f, s, mv) => { rl.push(`${e.key.toString(16)} d${d} f${f} s${s} m${mv} n${e.n}`); return st(d, f, s, mv); };
e.think({ nodes: lim });
const al = []; const m = h.m, sd = h.a('s_done');
m.dbg.setTrace((pc) => { if (pc === sd) {
  const k = h.bytes('e_key', 3); const fp = h.peekw('e_fp'); const f = m.read(fp, 10);
  const sb = v => v > 127 ? v - 256 : v;
  al.push(`${(k[0] | k[1] << 8 | k[2] << 16).toString(16)} d${f[0]} best${sb(f[4])} a0 ${sb(f[3])} b${sb(f[2])} m${f[5]} n${h.peek('e_n')}`);
} });
h.think({ nodes: lim });
let i = 0; while (i < rl.length && rl[i].split(" ")[0] === (al[i] || "").split(" ")[0] && rl[i].split(" ")[1] === (al[i] || "").split(" ")[1]) i++;
console.log("stores", rl.length, al.length, "first difference", i); for (let j = Math.max(0, i - 4); j < i + 4; j++) console.log((rl[j] || "").padEnd(36), al[j] || "");
