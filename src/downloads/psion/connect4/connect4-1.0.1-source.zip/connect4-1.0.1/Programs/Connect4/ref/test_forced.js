// The forced block (19 Nov): with no win of its own and exactly one of the opponent's wins to
// stop, think() now plays the block at once. Checks, on positions from random games, that the
// full search (opts.searchForced, as before) chose the same move at every level, and how many
// positions it spent there.
//   node ref/test_forced.js [games, default 400]
'use strict';
const { Engine, LEVELS } = require('./engine');
const games = +process.argv[2] || 400;
let rnd = 7; const rand = n => { rnd = (rnd * 1103515245 + 12345) & 0x7fffffff; return (rnd >> 8) % n; };
const now = new Engine(), old = new Engine({ searchForced: true });
let found = 0, same = 0;
const spent = LEVELS.map(() => 0), maxSpent = LEVELS.map(() => 0);
for (let gi = 0; gi < games; gi++) {
  const moves = [];
  for (const e of [now, old]) e.reset();
  while (moves.length < 42) {
    const s = now.side();
    if (now.playable(s) === 0) {
      const opp = now.playable(3 - s);
      if (opp && !(opp & (opp - 1))) {
        found++;
        let ok = true;
        LEVELS.forEach((lv, i) => {
          if (i === 0) return;                 // (LEVELS[0] is unused: levels are 1-8)
          const o = { nodes: lv.nodes, depth: lv.depth, noise: lv.noise, seed: (gi * 31 + moves.length) & 255 };
          const a = now.think(o), b = old.think(o);
          if (a.move !== b.move) { ok = false; console.log(`level ${i}: ${moves.map(c => c + 1).join('')} block ${a.move + 1}, search ${b.move + 1}`); }
          if (a.nodes !== 0) ok = false;
          spent[i] += b.nodes; maxSpent[i] = Math.max(maxSpent[i], b.nodes);
        });
        if (ok) same++;
      }
    }
    if (now.playable(s)) break;                // a win to make: the game ends
    const legal = [0, 1, 2, 3, 4, 5, 6].filter(c => now.canPlay(c));
    if (!legal.length) break;
    const c = legal[rand(legal.length)];
    now.make(c); old.make(c); moves.push(c);
  }
}
console.log(`${found} positions with one win to stop: the same move at every level in ${same}`);
LEVELS.forEach((lv, i) => { if (i) console.log(`  level ${i}: the search spent ${Math.round(spent[i] / found)} positions on average, at most ${maxSpent[i]}`); });
if (same !== found) { console.log('FAIL'); process.exit(1); }
console.log('forced ok');
