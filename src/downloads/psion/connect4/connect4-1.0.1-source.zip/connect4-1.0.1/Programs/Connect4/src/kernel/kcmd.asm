; ---------------------------------------------------------------------
; The command table (C_GO .. C_FLAG), the first thing in block C4B0:
; do_cmd reads its entry from the pack (until 20 Nov 2026 it was in the
; kernel, 34 bytes of RAM). A kernel routine's offset + $8000, or an
; overlay's id and entry (the commands that are only an overlay). Assembled
; by tools/build.py against the kernel's symbols; its fix-ups are dropped.
; (A new game goes through OV_END's E_NEW: with Keep Ask, a result not kept
; is asked about; then the board empties, OV_FX X_EMPTY, and OV_GAME G_NEWG)
; ---------------------------------------------------------------------
        fdb  gm_x+$8000, OV_LIST*256+L_DROP, OV_GAME*256+G_BACK, hint+$8000
        fdb  OV_COACH*256+B_COACH, OV_LIST*256, OV_MENU*256, OV_END*256+E_NEW
        fdb  OV_CMD*256+M_SWAP, cm_set+$8000, OV_EXPORT*256+X_EXPORT, OV_IMPORT*256
        fdb  OV_SETUP*256, OV_CMD*256+M_RESIGN, cm_leave+$8000, OV_HELP*256
        fdb  OV_CMD*256+M_FLAG
