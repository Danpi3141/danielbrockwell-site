// The thinking display (OV_THINK): depth and seconds, and the bar, appear during the Psion's
// search on both displays, and a key stops the search.
'use strict';
const { Game, assert } = require('./lib');

for (const model of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'lz64']) {
  const g = new Game(model).start();
  g.waitHuman(60);
  g.poke('st_pace', 1);
  g.poke('st_level', 6);
  g.poke('st_you', 0);                       // you first
  g.key('ON', 0.5); g.key('N', 0.3); g.key('EXE', 0.8); g.key('EXE', 1.5);   // new game, one player
  // play out of the book: the Psion then searches
  let seen = null, bar = null;
  for (const c of [3, 3, 3, 2, 4, 1, 5]) {
    if (g.peek('g_over')) break;
    g.drop(c);
    for (let t = 0; t < 400 && !(seen && bar); t++) {
      g.m.runSeconds(0.25);
      const s = g.text();
      const d = s.match(/depth +(\d+) +(\d+)s/);
      if (d && +d[2] >= 1) seen = d[0];
      if (/\[=+ *\]?/.test(s)) bar = s.match(/\[=+/)[0];
      if (g.peek('g_psion') && !/depth|\[/.test(s) && t > 8 && seen) break;
    }
    g.waitHuman(120);
    if (seen && bar) break;
  }
  assert(seen, model + ': no depth and seconds shown');
  assert(bar, model + ': no thinking bar');
  console.log(`${model}: shown "${seen}" and "${bar}"`);
}
console.log('ok');
