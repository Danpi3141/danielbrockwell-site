; =====================================================================
; Two-line screen driver (CM, XP, LA). Loaded at DRV.
; The whole board is the 8 glyphs, a block 4 characters wide and 2 high
; at the left of the screen: each glyph holds 2 columns and 3 rows of
; cells; a cell is 2x2 dots with a one-dot gap. The top line holds rows
; 6, 5, 4, the bottom line rows 3, 2, 1. Solid is a solid square, Hollow
; a diagonal pair of dots. The spare eighth column carries the separator.
; The panel: 12 characters from column 5 on both lines.
; =====================================================================
        include "../defs.inc"

SEPBIT  = $02                   ; the separator: dot column 4 of glyphs 3 and 7 (0: none)

        jmp  d2_init
        jmp  d2_glyphs
        jmp  d2_cell
        jmp  d2_board           ; (DV_MARK: four-line screens only)

d2_init:
        ldaa #2
        staa kv_plines
        ldd  #$0414             ; panel at column 5: positions 4, 20
        std  kv_ppos
        clra
        clrb
        os   DP$STAT            ; cursor off
        ldaa #12
        os   DP$EMIT
        bsr  d2_board           ; the glyphs from the (empty) board
        ldx  #d2_top            ; the block: glyphs 0-3 over 4-7
        ldab #4
        os   DP$PRNT
        ldaa #16
        clrb
        os   DP$STAT
        ldx  #d2_top+4
        ldab #4
        os   DP$PRNT
        rts
d2_top: fcb  0,1,2,3,4,5,6,7

; the glyphs again (after switching on): all eight from the board
d2_glyphs:
; the whole board: every glyph rebuilt and sent
d2_board:
        clra
.g:     psha
        bsr  d2_glyph
        pula
        inca
        cmpa #8
        bne  .g
        rts

lcd_cmd: ldaa LCD_CTRL
        bmi  lcd_cmd
        stab LCD_CTRL
        rts
lcd_dat: ldaa LCD_CTRL
        bmi  lcd_dat
        stab LCD_DATA
        rts

; A = column, B = row: the glyph holding that cell, rebuilt and sent
d2_cell:
        lsra                    ; glyph = column / 2, +4 for rows 0-2
        cmpb #3
        bhs  d2_glyph
        adda #4
; A = glyph (0-7): its 8 dot rows built from its 6 cells (no copy is
; kept: 64 bytes of RAM saved) and sent to the display chip
d2_glyph:
        staa d2_g
        clrb                    ; the separator in glyphs 3 and 7
        anda #3
        cmpa #3
        bne  .z
        ldab #SEPBIT
.z:     ldx  #d2_buf
        ldaa #8
.zl:    stab 0,x
        inx
        deca
        bne  .zl
        clr  d2_i               ; cells 0-5: column (i & 1), row (i >> 1) of the glyph
.c:     ldaa d2_g
        anda #3
        asla
        ldab d2_i
        andb #1
        aba                     ; the board column
        cmpa #7
        bhs  .nx                ; (the spare eighth column)
        staa d2_c
        ldab d2_i
        lsrb                    ; 0-2: the glyph's bottom, middle, top cell row
        stab d2_r
        ldaa d2_g
        cmpa #4
        bhs  .lo
        addb #3                 ; top line: board rows 3-5
.lo:    stab d2_t               ; the board row

        ldaa d2_c
        ldab #7
        mul
        addb d2_t
        ldx  #e_bd
        abx
        ldab 0,x                ; 0 empty, 1 Solid, 2 Hollow
        beq  .nx
        aslb
        ldaa d2_c
        anda #1
        aba                     ; 2 * value + odd column
        asla
        tab
        ldx  #d2_pat
        abx
        ldd  0,x
        std  d2_p               ; its top and bottom dot rows
        ldaa #2                 ; dot row = (2 - cell row) * 3
        suba d2_r
        tab
        aslb
        aba
        tab
        ldx  #d2_buf
        abx
        ldaa 0,x
        oraa d2_p
        staa 0,x
        ldaa 1,x
        oraa d2_p+1
        staa 1,x
.nx:    inc  d2_i
        ldaa d2_i
        cmpa #6
        bne  .c
        ldab d2_g               ; into the chip: CG RAM $40 + glyph * 8
        aslb
        aslb
        aslb
        orab #$40
        bsr  lcd_cmd
        ldx  #d2_buf
.s:     ldab 0,x
        bsr  lcd_dat
        inx
        cpx  #d2_buf+8
        bne  .s
        rts

; dot rows (top, bottom) for empty, Solid, Hollow: even column, odd column
d2_pat: fcb  0,0, 0,0, $18,$18, $03,$03, $10,$08, $02,$01

; A = side: the letter for it in the panel (no glyph to spare)
d2_c:   fcb  0
d2_r:   fcb  0
d2_g:   fcb  0
d2_i:   fcb  0
d2_t:   fcb  0
d2_p:   fdb  0
d2_buf: rmb  8
