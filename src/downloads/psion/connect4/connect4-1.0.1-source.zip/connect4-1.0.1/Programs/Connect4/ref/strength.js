// Strength by level (spec "Checks: Strength"): the engine (ref/engine.js, the same as the
// 6303 engine) against a perfect opponent, from random 8-ply positions of Tromp's database,
// the engine taking each side in turn. For every engine move: does it keep the position's true
// result? The opponent plays a best move; when it is losing, the trickiest one (leaving the
// engine the fewest moves that keep the win).
//   node ref/strength.js [games per level] [workers] [levels e.g. 1-8]
'use strict';
const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');
const E = require('./engine');
const S = require('../tools/solver/solver');

function play(level, start, engineFirst, seed) {
  const lv = E.LEVELS[level];
  const p = S.clone(start.p);
  const e = new E.Engine(workerData && workerData.opts ? workerData.opts : {});
  // replay the start position into the engine: rebuild from the board (x moved first)
  const cols = startMoves(start.p);
  for (const c of cols) e.make(c);
  let kept = 0, moves = 0, res = 0;
  for (;;) {
    const engineToMove = (p.n % 2 === 0) === engineFirst;
    const an = S.analyse(p, true);
    const best = Math.max(...an.filter(v => v !== null));
    let col;
    if (engineToMove) {
      const r = e.think({ nodes: lv.nodes, depth: lv.depth, noise: lv.noise, seed: seed + p.n });
      col = r.move;
      moves++;
      if (an[col] === best) kept++;
    } else {
      const cands = [0, 1, 2, 3, 4, 5, 6].filter(c => an[c] === best);
      col = cands[0];
      if (best < 0 && cands.length > 1) {
        // the trickiest losing move: fewest engine replies that keep its win
        let bestCount = 99;
        for (const c of cands) {
          if (S.isWinningMove(p, c)) continue;
          const q = S.clone(p); S.play(q, c);
          const a2 = S.analyse(q, true);
          const cnt = a2.filter(v => v === 1).length;
          if (cnt < bestCount) { bestCount = cnt; col = c; }
        }
      } else col = cands[(seed + p.n) % cands.length];
    }
    const win = S.isWinningMove(p, col);
    S.play(p, col); e.make(col);
    if (win) { res = engineToMove ? 1 : -1; break; }
    if (p.n === 42) { res = 0; break; }
  }
  return { kept, moves, res };
}

// a move order reaching a Tromp position (8 discs, x first): columns bottom-up, alternating
function startMoves(p) {
  const col = [];
  for (let c = 0; c < 7; c++) {
    const stack = [];
    for (let r = 0; r < 6; r++) {
      const b = c * 7 + r;
      const inM = b < 28 ? (p.ml >> b) & 1 : (p.mh >> (b - 28)) & 1;
      if (!inM) break;
      const inC = b < 28 ? (p.cl >> b) & 1 : (p.ch >> (b - 28)) & 1;
      stack.push(inC ? 'x' : 'o');
    }
    col.push(stack);
  }
  const ptr = [0, 0, 0, 0, 0, 0, 0], out = [];
  const dfs = (k) => {
    if (k === 8) return true;
    const want = k % 2 === 0 ? 'x' : 'o';
    for (let c = 0; c < 7; c++) {
      if (ptr[c] < col[c].length && col[c][ptr[c]] === want) {
        ptr[c]++; out.push(c);
        if (dfs(k + 1)) return true;
        ptr[c]--; out.pop();
      }
    }
    return false;
  };
  if (!dfs(0)) throw new Error('no move order');
  return out;
}

if (!isMainThread) {
  S.ttInit();
  const T = require('../tools/solver/tromp').load();
  parentPort.on('message', (j) => {
    const r = play(j.level, T[j.pos], j.engineFirst, j.seed);
    parentPort.postMessage(Object.assign({ level: j.level }, r));
  });
} else {
  const per = +(process.argv[2] || 20), NW = +(process.argv[3] || 6);
  const [lo, hi] = (process.argv[4] || '1-8').split('-').map(Number);
  const jobs = [];
  let rnd = 31337; const rand = n => { rnd = (rnd * 1103515245 + 12345) & 0x7fffffff; return rnd % n; };
  for (let lv = lo; lv <= hi; lv++) for (let i = 0; i < per; i++) {
    jobs.push({ level: lv, pos: rand(67557), engineFirst: i % 2 === 0, seed: rand(65536) });
  }
  const stats = {};
  let active = 0;
  const t0 = Date.now();
  const next = (w) => { const j = jobs.shift(); if (!j) { w.terminate(); return; } active++; w.postMessage(j); };
  for (let i = 0; i < NW; i++) {
    const w = new Worker(__filename, { workerData: { opts: JSON.parse(process.env.EOPTS || '{}') } });
    w.on('message', (r) => {
      active--;
      const s = stats[r.level] || (stats[r.level] = { kept: 0, moves: 0, w: 0, d: 0, l: 0, g: 0 });
      s.kept += r.kept; s.moves += r.moves; s.g++;
      if (r.res > 0) s.w++; else if (r.res < 0) s.l++; else s.d++;
      if (!jobs.length && !active) {
        console.log(`level  games  moves kept   W  D  L   (${((Date.now() - t0) / 60000).toFixed(1)} min)`);
        for (const lv of Object.keys(stats)) {
          const x = stats[lv];
          console.log(`${String(lv).padStart(5)}  ${String(x.g).padStart(5)}   ${(100 * x.kept / x.moves).toFixed(1).padStart(5)}%   ${x.w} ${x.d} ${x.l}`);
        }
      }
      next(w);
    });
    next(w);
  }
}
