; Engine variables (in the kernel's variable area, cleared at the start)
e_bd:   rmb  49                 ; the board
e_thr:  rmb  49                 ; threat counts (must follow e_bd)
e_lc:   rmb  69                 ; line counts
e_land: rmb  7                  ; landing cells
e_ev:   rmb  2
e_key:  rmb  3
e_n:    rmb  1
e_won:  rmb  1
; the search's inputs (resident: set before it by OV_BOOK or set_search; e_poll at start-up)
e_limit: rmb 2                  ; positions, 0 none
e_fixd: rmb  1                  ; depth, 0 none
e_noise: rmb 1
e_nseed: rmb 1
e_poll: rmb  2                  ; called every 64 positions (C set stops), 0 none
; search inputs and results
; (its working bytes: src/kernel/kvars.inc, tests/engine/etest.asm)
