; =====================================================================
; The start-up code: stored after the kernel's code (where the variables
; go), copied into region R and run there once: it costs no RAM of its
; own. The kernel's entry jumps to where it is stored; its first lines
; (only absolute addresses, so they run there) copy it all up into R.
; (Until 20 Nov 2026 that copy, the seed and the start of the game were
; kernel code: 34 bytes of RAM.) Clears the variables, finds the game's
; blocks, saves the keyboard state, picks the screen driver from the
; model byte (switching an LZ to four lines), shows the title.
; =====================================================================
        include "../defs.inc"

kinit_cp:                       ; (at kv_first) D = ADDR(v%())
        pshb
        psha
        ldd  #INIT_LEN
        std  T0
        ldx  #kv_first
        ldd  #SLOTA
        os   UT$CPYB
        jmp  kinit              ; (in R)
kinit:  pula                    ; D = ADDR(v%())
        pulb
        ldx  #kv_first          ; the variables are not on the pack: clear them
.z:     clr  0,x
        inx
        cpx  #kv_end
        bne  .z
        ldx  #kh_first          ; and those in C4G's string (the bootstrap has run)
.h:     clr  0,x
        inx
        cpx  #kh_end
        bne  .h
        std  kv_vptr
        ldx  #THINKAT           ; the search's poll: OV_THINK's first byte (think_run reads it in)
        stx  e_poll
        sts  kv_sp              ; (the launcher's return address is on top)
        xgdx
        ldd  0,x
        std  kv_base
        ldd  2,x
        std  kv_size
        ldaa 4,x
        staa kv_dev
        jsr  pk_scan            ; find the blocks C4B0, C4B1
        bcc  in_start
        ldab #E_FILES
        jmp  quit

; find each block C4Bn with the OS's FL$BOPN: kv_dir gets the pack address
; of its data (past the object length and the CM RETURN stub), or $FF.
; Carry set if C4B0 is missing.
pk_scan:
        clr  kv_pkok
        ldx  #kv_dir
        ldab #2*3
        ldaa #$FF
.f:     staa 0,x
        inx
        decb
        bne  .f
        ldx  #BUF           ; "D:C4Bn" with a leading count
        ldaa #6
        staa 0,x
        ldaa kv_dev
        adda #'A'
        staa 1,x
        ldd  #$3A43             ; ":C"
        std  2,x
        ldd  #$3442             ; "4B"
        std  4,x
        clr  kv_t0
.b:     ldaa kv_t0
        adda #'0'
        staa BUF+6
        ldx  #BUF
        ldab #$83
        os   FL$BOPN
        bcs  .n
        os   PK$QADD            ; B:X = where its data starts
        pshx
        pshb
        clra
        ldab #16
        os   PK$SKIP
        os   PK$RWRD            ; the build it belongs to
        subd #BUILD
        beq  .mine
        pulb
        pulx
        bra  .n                 ; another build's: as if it were not there
.mine:
        ldaa kv_t0
        ldab #3
        mul
        addd #kv_dir
        xgdx
        pula
        staa 0,x
        pula
        pulb
        addd #18                ; past the object length (2), the stub (14) and the build (2)
        std  1,x
        bcc  .n
        inc  0,x
.n:     inc  kv_t0
        ldaa kv_t0
        cmpa #2
        bne  .b
        os   PK$PKOF
        ldaa kv_dir
        cmpa #$FF
        beq  .bad
        clc
        rts
.bad:   sec
        rts


in_start:
        ldaa #DRV2              ; the model byte: 13, 14, 29, 30 have four lines
        ldab MODEL
        cmpb #13
        beq  .four
        cmpb #14
        beq  .four
        cmpb #29
        beq  .four
        cmpb #30
        bne  .drv
.four:  ldaa #1
        os   DP$MSET            ; four lines; A = the mode it replaced
        staa kv_omode
        inc  kv_four
        ldab #$80
        os   DP$CSET            ; the clock leaves the glyphs alone
        ldaa #DRV4
.drv:   staa kv_drv
        jsr  ov_load
        jsr  DRV+DV_INIT
        os   KB$FLSH
        ldd  TMB_MIN            ; the seed from the clock's minutes and seconds
        eora FRC                ; (before any key)
        eorb FRC+1
        std  kv_seed
        ; the title
        jsr  pn_clear
        jsr  lb_clr
        jsr  lb_s
        fcl  "Connect 4"
        clra
        jsr  lb_put
        jsr  lb_clr
        jsr  lb_s
        fcl  "Ver. 1.0.1"           ; (12 characters at most)
        ldaa #1
        jsr  lb_put
        jsr  in_drop            ; four discs drop into the bottom row
        tst  kv_four
        beq  .two
        ldaa #47                ; the credit: line 3 from column 8 (13 letters)
        bra  .cr
.two:   ldaa #19                ; two lines: from column 4 of line 2, after a moment
        psha
        ldaa #20
        jsr  key_wait
        pula
        tstb
        bne  .done
.cr:    clrb
        os   DP$STAT
        ldx  #in_cred
        ldab #13
        os   DP$PRNT
        ldaa #40                ; about 2 seconds, or until a key
        jsr  key_wait
.done:  os   KB$FLSH
        jsr  DRV+DV_INIT        ; (the credit covered a board character or column 8)
        jsr  pn_clear
        ldx  #gm_main           ; then the saved game, or a new one (replayed),
        pshx                    ; and the game loop (OV_GAME returns there)
        ldd  #OV_GAME*256+G_LOAD
        jmp  ov_call
in_cred: fcc "Daniel+Claude"

; stretch goal 8: four discs drop into the bottom row, Solid and Hollow in
; turn (columns 3-6), then blink once. Only the picture: the board is set
; up properly afterwards. A key cuts it short.
in_drop:
        ldaa #2
        staa in_c
.d:     ldab #5                 ; from the top row down
.r:     stab in_r
        ldaa in_c               ; this disc: Solid in even columns
        anda #1
        inca
        bsr  in_set
        ldaa #1
        bsr  in_wait
        bne  .x
        ldab in_r
        beq  .n                 ; it has landed
        clra
        bsr  in_set
        ldab in_r
        decb
        bra  .r
.n:     inc  in_c
        ldaa in_c
        cmpa #6
        bne  .d
        clr  in_v               ; blink once
.b:     ldaa #2
        staa in_c
.bc:    clrb
        stab in_r
        ldaa in_v
        beq  .o
        ldaa in_c
        anda #1
        inca
.o:     bsr  in_set
        inc  in_c
        ldaa in_c
        cmpa #6
        bne  .bc
        ldaa #4
        bsr  in_wait
        bne  .x
        com  in_v
        bne  .b
.x:     rts

; A = disc (0 empty): put in row in_r of column in_c and shown
in_set: psha
        ldaa in_c
        ldab #7
        mul
        addb in_r
        ldx  #e_bd
        abx
        pula
        staa 0,x
        ldaa in_c
        ldab in_r
        jmp  DRV+DV_CELL

; A = frames: wait; Z clear (and the wait cut short) if a key is waiting
in_wait:
        adda TMW_FRAM+1
        staa in_t
.l:     os   KB$TEST
        tstb
        bne  .k
        ldaa in_t
        cmpa TMW_FRAM+1
        bne  .l
.k:     rts

in_c:   fcb  0
in_r:   fcb  0
in_v:   fcb  0
in_t:   fcb  0
