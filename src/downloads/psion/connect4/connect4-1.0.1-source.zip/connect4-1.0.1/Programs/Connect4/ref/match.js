// Self-play match between two engine settings from varied openings, both colours.
//   node ref/match.js <nodes> <games> <optsA json> <optsB json>
'use strict';
const E = require('./engine');
const [nodes, games] = [+process.argv[2] || 2500, +process.argv[3] || 100];
const oA = JSON.parse(process.argv[4] || '{}'), oB = JSON.parse(process.argv[5] || '{}');
let rnd = 4242; const rand = n => { rnd = (rnd * 1103515245 + 12345) & 0x7fffffff; return rnd % n; };
let a = 0, b = 0, d = 0;
for (let g = 0; g < games; g++) {
  const open = [rand(7), rand(7), rand(7), rand(7)];      // the same opening twice, colours swapped
  for (const aFirst of [true, false]) {
    const eA = new E.Engine(oA), eB = new E.Engine(oB);
    let res = 0;
    for (const c of open) { eA.make(c); eB.make(c); }
    while (!res) {
      const aMove = (eA.n % 2 === 0) === aFirst;
      const r = (aMove ? eA : eB).think({ nodes });
      const f1 = eA.make(r.move); eB.make(r.move);
      if (f1) res = aMove ? 1 : 2; else if (eA.n === 42) res = 3;
    }
    if (res === 1) a++; else if (res === 2) b++; else d++;
  }
}
const n = a + b + d;
console.log(`A ${a}  B ${b}  draws ${d}  (A scores ${(100 * (a + d / 2) / n).toFixed(1)}%)`);
