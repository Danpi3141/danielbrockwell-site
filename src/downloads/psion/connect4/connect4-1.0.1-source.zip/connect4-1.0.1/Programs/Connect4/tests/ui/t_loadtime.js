// Overlay load times (ov_load, from its call to its return) by unit, while games are played
// (one player, level 3, Pace Fast): the mean and the most for each unit seen.
//   node tests/ui/t_loadtime.js [model] (default cm)
'use strict';
const fs = require('fs'), path = require('path');
const { Game } = require('./lib');
const model = process.argv[2] || 'cm';
const lst = fs.readFileSync(path.join(__dirname, '..', '..', 'build', 'game', 'kernel.lst'), 'utf8').split(/\r?\n/);
const at = lst.findIndex(l => /^\s*[0-9A-F]{4}\s.*ov_call:/.test(l) || /^[0-9A-F]{4}\s+\S+\s+ov_call:/.test(l));
const callIdx = lst.findIndex((l, i) => i > at && /jsr\s+ov_load/.test(l));
const back = parseInt(lst[callIdx + 1].slice(0, 4), 16);
const ids = {}; fs.readFileSync(path.join(__dirname, '..', '..', 'build', 'game', 'gen', 'ids.inc'), 'utf8').split(/\r?\n/).forEach(l => { const m = /^(\w+) = (\d+)/.exec(l); if (m) ids[m[2]] = m[1]; });
const g = new Game(model).start(); g.waitHuman(60);
g.poke('st_level', 3); g.poke('st_pace', 1);
g.keys(['ON', 'N', 'EXE', 'EXE'], 1.0);
const call = g.a('ov_load'), ret = g.base + back, t = {};
let rnd = 9; const rand = n => { rnd = (rnd * 1103515245 + 12345) & 0x7fffffff; return (rnd >> 8) % n; };
for (let mv = 0; mv < 60; mv++) {
  if (g.peek('g_over')) { g.m.runSeconds(1); g.key('EXE', 2); continue; }
  g.m.press('UVWOPQI'[rand(7)], 3, 3); g.m.runSeconds(0.1);
  g.m.press('EXE', 3, 3);
  for (let k = 0; k < 40; k++) {
    if (g.m.runTo([call], 921600 * 2) !== call) break;
    const id = g.m.dbg.a(), c0 = g.m.cycles(), res = g.peek('kv_res');
    if (g.m.runTo([ret], 921600) !== ret) break;
    if (id !== res) { const ms = (g.m.cycles() - c0) / 921.6; (t[ids[id] || id] = t[ids[id] || id] || []).push(ms); }
    if (g.humanTurn()) break;
  }
}
for (const [n, a] of Object.entries(t).sort()) console.log(n.padEnd(10), 'loads', String(a.length).padStart(3), 'mean', (a.reduce((x, y) => x + y) / a.length).toFixed(1), 'ms, most', Math.max(...a).toFixed(1));
