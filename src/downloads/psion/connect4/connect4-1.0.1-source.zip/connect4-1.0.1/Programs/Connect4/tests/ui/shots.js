// LCD screenshots from the emulator, as PNG: either display (16x2 or 20x4), user-defined
// characters included, with the gaps between character cells. For reviewing the UI.
'use strict';
const zlib = require('zlib');

const CRC = (() => { const t = []; for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t.push(c >>> 0); } return t; })();
function crc32(buf) { let c = 0xFFFFFFFF; for (const b of buf) c = CRC[(c ^ b) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
function chunk(type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type, 'latin1'), data]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td));
  return Buffer.concat([len, td, crc]);
}
function png(w, h, rgb) {            // rgb: Buffer of w*h*3
  const raw = Buffer.alloc((w * 3 + 1) * h);
  for (let y = 0; y < h; y++) { raw[y * (w * 3 + 1)] = 0; rgb.copy(raw, y * (w * 3 + 1) + 1, y * w * 3, (y + 1) * w * 3); }
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}

// the screen as pixel rows: [rows][cols] of 0/1 per character cell
function lcd(m) {
  const W = m.lines === 4 ? 20 : 16, H = m.lines === 4 ? 4 : 2;
  return { W, H, cells: m.cells(), udg: m.udgs(), font: m.font() };
}

// scale: screen pixel -> s x s, with a 1-pixel gap between character cells
function screenshot(m, s = 4) {
  const { W, H, cells, udg, font } = lcd(m);
  const cw = 5 * s + s, ch = 8 * s + s, pad = 3 * s;
  const w = W * cw - s + 2 * pad, h = H * ch - s + 2 * pad;
  const rgb = Buffer.alloc(w * h * 3);
  const bg = [0xA9, 0xB8, 0x8C], off = [0x9C, 0xAB, 0x80], on = [0x22, 0x2A, 0x1C];
  for (let i = 0; i < w * h; i++) rgb.set(bg, i * 3);
  for (let r = 0; r < H; r++) for (let c = 0; c < W; c++) {
    const v = cells[r * W + c];
    for (let y = 0; y < 8; y++) {
      const row = v < 8 ? udg[v][y] : (v >= 32 && v < 128 ? font[(v - 32) * 8 + y] : 0);
      for (let x = 0; x < 5; x++) {
        const col = (row >> (4 - x)) & 1 ? on : off;
        for (let dy = 0; dy < s - (s > 2 ? 1 : 0); dy++) for (let dx = 0; dx < s - (s > 2 ? 1 : 0); dx++) {
          const px = pad + c * cw + x * s + dx, py = pad + r * ch + y * s + dy;
          rgb.set(col, (py * w + px) * 3);
        }
      }
    }
  }
  return png(w, h, rgb);
}

module.exports = { screenshot, png };
