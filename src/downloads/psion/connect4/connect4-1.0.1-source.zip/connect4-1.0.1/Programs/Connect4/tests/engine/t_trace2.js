'use strict';
const { Harness } = require('./harness');
const E = require('../../ref/engine');
const h = new Harness({ build: false });
const [seq, noise, seed, lim, at] = [process.argv[2], +process.argv[3], +process.argv[4], +process.argv[5], +process.argv[6]];
const e = new E.Engine(); h.call('eng_reset');
for (const ch of seq) { e.make(+ch - 1); h.call('e_make', +ch - 1); }
let k = 0;
const mk = e.make.bind(e);
e.make = (c) => { if (k++ === at) console.log('ref killer', e.killer.slice(0, 6).join(','), 'tt', JSON.stringify(e.ttProbe()), 'key', e.key.toString(16)); return mk(c); };
e.think({ nodes: lim, noise, seed });
let j = 0; const m = h.m, mpc = h.a('e_make');
m.dbg.setTrace((pc) => { if (pc === mpc && j++ === at) {
  const key = h.bytes('e_key', 3); const kk = key[0] | key[1] << 8 | key[2] << 16;
  const ti = h.a('E_TT') + (key[0] & 127) * 4;
  console.log('asm killer', h.bytes('E_KIL', 6).join(','), 'tt', m.read(ti, 4).join(','), 'key', kk.toString(16), 'ply', h.peek('e_ply'));
} });
h.think({ nodes: lim, noise, seed });
