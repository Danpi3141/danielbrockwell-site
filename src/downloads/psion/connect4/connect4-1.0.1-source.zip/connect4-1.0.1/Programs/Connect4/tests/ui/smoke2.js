'use strict';
const { Machine } = require('../../tools/emu');
const rom = process.argv[2] || '46a-lz64.rom', ram = +(process.argv[3] || 64);
const m = new Machine({ rom, ram });
m.boot();
m.insertPack(__dirname + '/../../build/game/C4.opk', 0);
m.runProc('C4', 'B');
let last = '';
for (let t = 0; t < 400; t++) {
  m.runSeconds(0.05);
  const s = m.screen().join('|');
  if (s !== last) { console.log((t * 0.05).toFixed(2).padStart(6), s); last = s; }
}
