'use strict';
const S = require('./solver'), T = require('./tromp');
S.ttInit();
const db = T.load();
let t0 = Date.now(), bad = 0, N = +process.argv[2] || 200;
for (let i = 0; i < N; i++) {
  const e = db[(i * 337) % db.length];
  const r = S.solve(e.p, true);
  if (r !== e.res) { bad++; console.log('MISMATCH', i, r, e.res); }
}
console.log(`tromp sample ${N}: ${bad} bad, ${Date.now() - t0} ms, nodes ${S.getNodes()}`);
// known: empty board +1; after 4 the second player loses
t0 = Date.now(); S.resetNodes();
const p = S.fromMoves([3]);
console.log('after d1 (2nd to move) score', S.solve(p, false), Date.now() - t0, 'ms', S.getNodes(), 'nodes');
