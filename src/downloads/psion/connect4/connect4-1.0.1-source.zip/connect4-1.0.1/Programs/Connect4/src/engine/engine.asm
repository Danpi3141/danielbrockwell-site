; =====================================================================
; Connect 4 engine (matched to ref/engine.js position for position).
; Needs from the includer: E_FR (scratch for frames and killers,
; E_SCRATCH_END-E_FR bytes) and E_TT (the 512-byte table).
; Never touches the screen; calls the kernel only through e_poll.
; =====================================================================
; The engine's busiest working variables are on the zero page, in the OS's
; utility scratch UTW_S0-S5 ($41-$4C): direct addressing is a byte shorter
; and a cycle faster (19 Nov 2026: 80 bytes of engine code). The OS uses
; these bytes in its services, so they hold only what lives inside one move,
; evaluation or node; e_ply and e_fp, which last a whole search, are kept on
; the stack while e_poll (which calls the OS) runs.
e_ply   = $41                   ; the search's ply
e_fp    = $42                   ; (2) the current frame
e_acc   = $44                   ; make/unmake: the open-line change
e_tmp   = $45                   ; (2)
e_kb    = $47                   ; (3) the cell's key bytes
e_sf    = $4A                   ; the side moving: 0 Solid, 1 Hollow
e_cell  = $4B
e_unit  = $4C                   ; the mover's 1 in a count byte
e_li    = e_kb                  ; (2) make/unmake's line loop: the line (the key bytes are done by then)
e_lend  = e_tmp                 ; (2) and the end of the cell's lines (e_tmp is free until e_evadd)

eng_start:
        include "emove.asm"
        include "eeval.asm"
        include "esearch.asm"
        include "eapi.asm"
        include "etab.inc"
eng_end:
