; ---------------------------------------------------------------------
; game_over: A = the result (g_res): the game is over. The tune, then the
; save (OV_GAME; tail call). Included by OV_FX (a four, a full board) and
; OV_CMD (resigned, out of time); kernel code until 20 Nov 2026.
; ---------------------------------------------------------------------
game_over:
        staa g_res
        ldaa #1
        staa g_over
        ldx  #snd_win
        jsr  snd_play           ; (played from here: the overlay stays while it plays)
        jmp  save
snd_win:    fcb  $80                    ; four in a row (src/kernel/ksound.asm)
            fdb  842
            fcb  90
            fdb  660
            fcb  90
            fdb  549
            fcb  90
            fdb  401
            fcb  180
            fdb  0
