const { Machine } = require('../../tools/emu');
for (const [rom, ram] of [['33-cm.rom', 8], ['24-cm.rom', 8], ['31-xp.rom', 16], ['36-la.rom', 32], ['46-lz.rom', 32], ['46a-lz64.rom', 64]]) {
  const m = new Machine({ rom, ram });
  m.boot();
  m.insertPack(__dirname + '/../../build/probe/probe.opk', 0);
  m.runProc('C4', 'B');
  m.runSeconds(3);
  const s1 = m.screen(), u = m.udgs().slice(0, 2).map(r => r.map(x => x.toString(16)).join(''));
  m.press('EXE', 3, 20); m.runSeconds(1);
  console.log(rom.padEnd(13), JSON.stringify(s1), u.join('/'), '->', JSON.stringify(m.screen()));
}
