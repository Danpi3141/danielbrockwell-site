; =====================================================================
; Search (ref/engine.js think / node / nextMove)
; Iterative deepening, alpha-beta (fail-soft negamax) on explicit frames
; in the scratch (E_FR, 10 bytes a ply), a 128-entry table at E_TT.
; Scores are signed bytes: a win is 100 less the plies from the root.
; =====================================================================

WIN     = 100
MAXPLY  = 20
F_D     = 0                     ; depth left
F_A     = 1                     ; alpha
F_B     = 2                     ; beta
F_A0    = 3                     ; alpha on entry
F_BEST  = 4
F_BMV   = 5                     ; best move
F_ST    = 6                     ; move stage: 0 table, 1 killer, 2-8 centre out
F_TT    = 7                     ; the table's move (7 none)
F_FC    = 8                     ; 7 no forced reply, 0-6 the forced one, 8 it was tried
F_COL   = 9                     ; the move being searched
FSIZE   = 10
E_KIL   = E_FR+FSIZE*(MAXPLY+1)  ; killers, one a ply
; the search's own variables (inputs, results and working) follow: they are
; only used while it runs, so they live in the scratch too
ES      = E_KIL+MAXPLY+2
e_move  = ES+0
e_score = ES+1
e_depth = ES+2
e_exact = ES+3
e_nodes = ES+4
e_dcur  = ES+6
e_cnt   = ES+7
e_par   = ES+8
e_c7    = ES+10
e_lp    = ES+11
e_seen  = ES+13
e_t     = ES+14
e_xp    = ES+15
e_v16   = ES+17
e_abort = ES+19
e_d1    = ES+20
e_maxd  = ES+21
e_empt  = ES+22
e_rmove = ES+23
e_pms   = ES+24
e_pmh   = ES+25
e_mine  = ES+26
e_opp   = ES+27
e_v     = ES+28
e_tx    = ES+29
e_flag  = ES+31
e_tsc   = ES+32
e_tdf   = ES+33
e_tmv   = ES+34
E_SCRATCH_END = ES+35

; e_think: searches for the side to move.
; In:  e_limit (positions, 0 none), e_fixd (depth, 0 none), e_noise, e_nseed,
;      e_poll (a routine called every 64 positions; C set stops; 0 none)
; Out: e_move (7 none), e_score, e_depth, e_exact, e_nodes
e_think:
        clra
        clrb
        std  e_nodes
        clr  e_abort
        clr  e_depth
        clr  e_exact
        clr  e_score
        ldx  #E_KIL
        ldaa #7
.k:     staa 0,x
        inx
        cpx  #E_KIL+MAXPLY+2
        bne  .k
        ldx  #E_TT
.t:     clr  0,x
        inx
        cpx  #E_TT+512
        bne  .t
        jsr  e_masks
        ldaa e_mine
        beq  .nw
        jsr  e_low              ; a win at once
        staa e_move
        ldaa #WIN-1
        staa e_score
        inc  e_exact
        rts
.nw:    ldaa e_opp
        beq  .go                ; nothing to block
        tab
        decb
        stab e_tmp
        anda e_tmp
        beq  .one
        ldaa #-(WIN-2)          ; two threats to block: lost
        staa e_score
        inc  e_exact
.one:   ldaa e_opp              ; one: it is blocked, no search (any other move loses at
        jsr  e_low              ; once, so every search chose it; score 0, not exact.
        staa e_move             ; Until 19 Nov a full search ran, up to 100 s)
        rts
.go:    ldaa #42
        suba e_n
        staa e_empt
        ldab e_fixd
        beq  .nf
        cba
        bls  .nf
        tba                     ; the level's depth when smaller
.nf:    cmpa #MAXPLY
        bls  .mx
        ldaa #MAXPLY
.mx:    staa e_maxd
        ldaa #7
        staa e_move
        ldaa #1
        staa e_dcur
.it:    clr  e_d1
        ldaa e_dcur
        cmpa #1
        bne  .d
        inc  e_d1
.d:     ldab #7
        stab e_rmove
        ldx  #E_FR
        staa F_D,x
        ldaa #-WIN-1
        staa F_A,x
        ldaa #WIN+1
        staa F_B,x
        jsr  e_search
        ldab e_rmove
        cmpb #7
        beq  .nm
        stab e_move
        tst  e_abort
        bne  .fin
        staa e_score
.nm:    tst  e_abort
        bne  .fin
        ldab e_dcur
        stab e_depth
        cmpb e_empt
        bhs  .ex
        cmpa #50
        bgt  .ex
        cmpa #-50
        blt  .ex
        ldaa e_dcur
        inca
        staa e_dcur
        cmpa e_maxd
        bls  .it
.fin:   rts
.ex:    inc  e_exact
        rts

; e_masks: e_pms / e_pmh = columns where Solid / Hollow can play a
; threat cell now (bit n = column n); e_mine / e_opp = the side to move's
; and the other's. Columns 6 down to 0, each bit rotated in.
e_masks:
        clr  e_pms
        clr  e_pmh
        ldx  #e_land+6
.c:     ldab 0,x
        pshx
        ldx  #e_thr
        abx
        ldaa 0,x
        pulx
        tab
        andb #$0F
        addb #$FF               ; C: Solid can make four here
        rol  e_pms
        anda #$F0
        adda #$FF               ; C: Hollow can
        rol  e_pmh
        dex
        cpx  #e_land-1
        bne  .c
        ldaa e_pms
        ldab e_pmh
        tst  e_n
        psha
        ldaa e_n
        bita #1
        pula
        beq  .s
        psha                    ; Hollow to move: swap
        tba
        pulb
.s:     staa e_mine
        stab e_opp
        rts

; A = a column mask (not 0) -> A = its lowest column
e_low:  clrb
.l:     lsra
        bcs  .r
        incb
        bra  .l
.r:     tba
        rts

; the table entry for this position: X = E_TT + (k0 & 127) * 4
e_ttx:  ldab e_key
        andb #127
        clra
        asld
        asld
        addd #E_TT
        xgdx
        rts

; ---------------------------------------------------------------------
; e_search: frame E_FR holds depth, alpha, beta. A = the score.
; ---------------------------------------------------------------------
e_search:
        ldx  #E_FR
        stx  e_fp
        clr  e_ply
s_enter:
        ldd  e_nodes
        addd #1
        std  e_nodes
        tst  e_d1
        bne  .np0
        ldd  e_limit
        beq  .np0
        ldd  e_nodes
        subd e_limit
        blo  .np0
        ldaa #1
        staa e_abort
.np0:   ldaa e_nodes+1
        anda #63
        bne  .np
        ldx  e_poll
        beq  .np
        ldaa e_ply              ; (on the zero page: the OS may use it)
        psha
        ldd  e_fp
        pshb
        psha
        jsr  0,x
        pula                    ; (pulls and stores leave C as the poll set it)
        pulb
        std  e_fp
        pula
        staa e_ply
        bcc  .np
        ldaa #1
        staa e_abort
.np:    tst  e_abort
        beq  .go
        tst  e_d1
        bne  .go
        clra
        jmp  s_ret
.go:    jsr  e_masks
                                ; (the side to move cannot win at once here: its parent
.nw:    ldaa e_opp              ; blocked any playable threat, and never fed one)
        tab
        decb
        stab e_tmp
        anda e_tmp
        beq  .n2
        ldaa e_ply              ; two threats: lost
        suba #WIN-2
        jmp  s_ret
.n2:    ldaa e_n
        cmpa #42
        bne  .nf
        clra
        jmp  s_ret
.nf:    ldx  e_fp
        tst  F_D,x
        bne  .in
        jsr  e_eval
        jmp  s_ret
.in:    ldaa F_A,x
        staa F_A0,x
        clr  F_ST,x
        ldaa #7
        staa F_TT,x
        ; the table
        jsr  e_ttx
        ldaa 3,x
        beq  .miss
        ldaa 0,x
        cmpa e_key+1
        bne  .miss
        ldab e_key+2
        aslb
        aslb
        aslb
        ldaa 1,x
        anda #$F8
        cba
        bne  .miss
        ldaa 1,x
        anda #7
        stx  e_tx
        ldx  e_fp
        staa F_TT,x
        tst  e_ply
        beq  .miss
        ldx  e_tx
        ldaa 3,x
        lsra
        lsra                    ; its depth
        ldx  e_fp
        cmpa F_D,x
        blo  .miss
        ldx  e_tx
        ldaa 2,x                ; its score, made relative to this ply
        cmpa #50
        ble  .t1
        suba e_ply
        bra  .t2
.t1:    cmpa #-50
        bge  .t2
        adda e_ply
.t2:    ldab 3,x
        andb #3
        ldx  e_fp
        cmpb #3
        beq  .cut
        cmpb #2
        bne  .up
        cmpa F_B,x
        bge  .cut
        bra  .miss
.up:    cmpa F_A,x
        bgt  .miss
.cut:   jmp  s_ret
.miss:  ldx  e_fp
        ldaa #7
        staa F_FC,x
        ldaa e_opp
        beq  .nfc
        jsr  e_low
        ldx  e_fp
        staa F_FC,x
        ldaa #9
        staa F_ST,x
.nfc:   ldaa #-WIN-1
        staa F_BEST,x
        ldaa #7
        staa F_BMV,x
s_loop: ldx  e_fp
        ldaa F_FC,x
        cmpa #7
        beq  .norm
        bhi  s_done             ; 8: the forced reply was tried
        ldab #8
        stab F_FC,x
        bra  .col
.norm:  jsr  e_next
        cmpa #7
        bhs  s_done
.col:   ldx  e_fp
        staa F_COL,x
        tab                     ; feeds the opponent's threat above?
        ldx  #e_land
        abx
        ldab 0,x
        ldx  #e_thr+1
        abx
        ldaa 0,x
        ldab e_n
        bitb #1
        bne  .fh
        anda #$F0               ; Solid to move: Hollow's threats
        bra  .ft
.fh:    anda #$0F
.ft:    beq  .play
        ldaa e_ply
        suba #WIN-2
        bra  s_val
.play:  ldx  e_fp
        ldaa F_COL,x
        jsr  e_make
        ldx  e_fp
        ldaa F_D,x
        deca
        staa FSIZE+F_D,x
        ldaa F_B,x
        nega
        staa FSIZE+F_A,x
        ldaa F_A,x
        nega
        staa FSIZE+F_B,x
        ldab #FSIZE
        abx
        stx  e_fp
        inc  e_ply
        jmp  s_enter

; a child's score A comes back up
s_ret:  tst  e_ply
        bne  .up
        rts
.up:    staa e_v
        dec  e_ply
        ldd  e_fp
        subd #FSIZE
        std  e_fp
        xgdx
        ldaa F_COL,x
        jsr  e_unmake
        ldaa e_v
        nega
        tst  e_abort
        beq  s_val
        tst  e_d1
        bne  s_val
        clra
        bra  s_ret
; A = the score of this frame's move F_COL
s_val:  ldx  e_fp
        cmpa F_BEST,x
        ble  .nb
        staa F_BEST,x
        ldab F_COL,x
        stab F_BMV,x
        tst  e_ply
        bne  .nb
        stab e_rmove
.nb:    cmpa F_A,x
        ble  .na
        staa F_A,x
.na:    ldaa F_A,x
        cmpa F_B,x
        bge  .cut
        jmp  s_loop
.cut:   ldaa F_FC,x
        cmpa #7
        bne  s_done
        ldab e_ply              ; the killer for this ply
        ldaa F_COL,x
        ldx  #E_KIL
        abx
        staa 0,x
; all moves done (or a cut-off): store and return the best
s_done: ldx  e_fp
        ldaa F_BEST,x
        ldab #1                 ; flag: 1 upper, 2 lower, 3 exact
        cmpa F_A0,x
        ble  .fl
        ldab #2
        cmpa F_B,x
        bge  .fl
        ldab #3
.fl:    stab e_flag
        cmpa #50                ; a win or loss: relative to this ply
        ble  .s1
        adda e_ply
        bra  .s2
.s1:    cmpa #-50
        bge  .s2
        suba e_ply
.s2:    staa e_tsc
        ldaa F_D,x
        asla
        asla
        oraa e_flag
        staa e_tdf
        ldab F_BMV,x
        stab e_tmv
        jsr  e_ttx
        ldaa 3,x                ; a deeper result stays
        beq  .w
        lsra
        lsra
        stx  e_tx
        ldx  e_fp
        ldab F_D,x
        ldx  e_tx               ; (ldx sets Z: compare after it)
        cba
        bhi  .ret
.w:     ldaa e_key+1
        staa 0,x
        ldaa e_key+2
        asla
        asla
        asla
        oraa e_tmv
        staa 1,x
        ldaa e_tsc
        staa 2,x
        ldaa e_tdf
        staa 3,x
.ret:   ldx  e_fp
        ldaa F_BEST,x
        jmp  s_ret

; e_next: X = the frame. A = the next move to try (7: none left)
e_next: ldaa F_ST,x
        inc  F_ST,x
        cmpa #8
        bhi  .none
        tsta
        bne  .k
        ldaa F_TT,x
        bra  .chk
.k:     cmpa #1
        bne  .o
        ldab e_ply
        pshx
        ldx  #E_KIL
        abx
        ldaa 0,x
        pulx
        cmpa F_TT,x
        beq  e_next
        bra  .chk
.o:     suba #2
        tab
        pshx
        ldx  #e_order
        abx
        ldaa 0,x
        ldab e_ply
        ldx  #E_KIL
        abx
        cmpa 0,x
        pulx
        beq  e_next
        cmpa F_TT,x
        beq  e_next
.chk:   cmpa #7
        bhs  e_next
        tab                     ; a column with room?
        pshx
        ldx  #e_land
        abx
        ldab 0,x
        ldx  #e_bd
        abx
        ldab 0,x
        pulx
        cmpb #3
        beq  e_next
        rts
.none:  ldaa #7
        rts
