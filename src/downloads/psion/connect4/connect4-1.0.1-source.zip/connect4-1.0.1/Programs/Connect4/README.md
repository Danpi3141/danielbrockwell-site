# Connect 4 for the Psion Organiser II

Connect 4 for the CM, XP, LA, LZ and LZ64, built from *Connect 4 for the Psion Organiser II: design spec* (18 Nov 2026).
One 32K Datapak serves every model: the launcher reads the model byte and loads the screen code for a two-line or a four-line display. Everything else is shared, so the game plays the same on every model.

## Status (19 Nov 2026)

- **The core game is complete and tested in the emulator on the CM (ROMs 2.4, 2.6, 3.3), XP (2.4, 2.6, 3.1), LA, LZ and LZ64; it starts and survives random keys on all 29 Organiser ROMs the emulator has, French, German and multilingual ones included (*Stress test*, below).**
  - **Both screens:** two-line (the whole board in the 8 custom glyphs, cells of 2 by 2 dots) and four-line (one character a column, round discs of 5 by 3 dots with the corners off: Solid filled, Hollow a ring).
  - **Modes:** one player (levels 1-8 and Auto), two players, demo.
  - **One player:** the solved opening book, the coach (which also names a bad drop before it is made), take back, hint, swap sides, resign.
  - **Two players:** move timer, game clocks, swap rule, match score, who starts, and the coach's check of each drop.
  - **Everywhere else:** move list, review, export and import of games (the last game always kept; Keep: Ask, All, Off), set-up, settings, help, the result screen with a tally for each level and its keys named, and save and resume after every move.
- **The engine** is 6303 machine code, matched position for position against a JavaScript reference engine (`ref/engine.js`).
- **The opening book** was made by our own perfect solver (`tools/solver`), checked against John Tromp's database.
- **Stretch goals:** all 11 are built (below).
- **Review (added 19 Nov 2026):** step through the game on the board; the moves that threw away a win or a draw are marked where the book or a solved search knew the values, and moves that missed a four or let one in are marked everywhere (below).
- **Not done:** the checks that need real hardware (see *Still to check* and `docs/hardware-test-plan.md`).

## Stretch goals

| | Goal | Where |
|---|---|---|
| 1 | Ghost disc: the chosen column's landing cell blinks about 3 times a second (it rests after about 15 s so the Organiser can switch off) | OV_PLAY |
| 2 | Last-move marker: the Psion's newest disc blinks twice | OV_PLAY |
| 3 | Winning four: the four blink until a key | OV_END |
| 4 | Thinking bar: `[====      ]`, tenths of the level's positions | kernel |
| 5 | Falling disc: a cell every 50 ms | OV_FX |
| 6 | Threat cells (coach on): cells where a side would make four blink slowly in its disc | OV_PLAY |
| 7 | Player names: after choosing Two players, each player types up to 6 letters (DEL rubs out, EXE takes it, ON/CLEAR: no name); the panel and the result use them | OV_MENU, OV_PLAY2, OV_RESULT |
| 8 | Title drop: four discs drop into the bottom row and blink once | start-up code |
| 9 | Hint flash: the hint's landing cell blinks faster for a moment | OV_PLAY |
| 10 | Emptying the board: at a new game the discs drop out of the bottom, row by row | OV_FX |
| 11 | Draw sweep: a full board's columns blink in turn | OV_END |

`FX_FALL` and `FX_EMPTY` in `src/defs.inc` leave out the two OV_FX animations.

## Review

**Review game** in the menu, or **MODE** on the result screen. The board shows the position after each move:

| | |
|---|---|
| LEFT, RIGHT | a move back, a move on |
| UP | the start |
| DOWN | the next marked move (a verdict worse than "Still ...", or one of the three below), or the end if there is none (19 Nov 2026; until then always the end) |
| EXE, ON/CLEAR, MODE | back to the game (or the result), the position as it was |

The panel shows the move ("Hollow col 3") and what it did: "Win -> draw", "Win -> loss", "Draw -> loss", or "Still a win" / "Still a draw" / "Still a loss"; the move that made four shows "Makes four" (until 19 Nov 2026 "Still a win", or in a two-player game just the move number). Otherwise it shows "Move 14/30" (on four lines both, and "Review").

Where there is no verdict, or the verdict is "Still a loss", the panel shows what the move let happen at once, if anything:

| | |
|---|---|
| Missed a win | the mover had a four to make, and didn't |
| Allows four | the other side has a four to make now |
| Allows fork | the other side has a move after which the mover can't stop a four (two fours to make, or one with another just above it) |

"Allows four" and "Allows fork" are shown only when another move would have let neither happen. A move made when every move lost at once keeps "Still a loss". These checks need no history, so they work in two-player games and in the middle game too. They are worked out for the whole game on the way into the review, which takes under half a second. The move list's overlay does this and leaves the results in the top 11 bytes of the slot, where the review reads them, so it costs no RAM.

(Added 19 Nov 2026 after a game exported as C4G2. You were Solid; the history marked move 3, Solid col 1, as "Win -> loss", the move that really lost. But your deliberate blunder at move 9, Solid col 2, which let Hollow make an open three, only showed "Still a loss". It now shows "Allows fork".)

The verdicts come from a history the game keeps as it goes (11 bytes in the save file): the value of the position at each of the Psion's turns, when the opening book or a solved search knew it. So they are exact, and there are verdicts for the opening (from the book) and the ending (from the solved searches), but not for the middle game, not for two-player games, and not for the Psion's searched moves before the ending. The side names are Solid and Hollow (not You/Psion or the players' names, which can change between games).

## Keeping games (19 Nov 2026)

Until 19 Nov a finished game was lost as soon as EXE started the next one, unless it had been exported from the menu first. Now:

| On the result | |
|---|---|
| EXE | a new game (with Keep "Ask", first "Export game?": EXE yes, ON no) |
| E | export the game (A:C4Gn), then the result again |
| MODE | review the game |
| UP | the move list |
| DEL | take back |
| ON/CLEAR | the menu |

- **The keys are named.** For about 15 s the panel's last line shows them in turn, 2 s each: "EXE new game", "E export" (not once the game is exported), "MODE review", "UP move list". Then the line is put back ("in 30 moves" on two lines, "EXE new game" on four), and the Organiser can switch itself off as before.
- **Keep** (in Settings, after Undo): **Ask** (the default) asks "Export game?" when EXE or *New game* would start a new game over a finished game of one or two players that hasn't been exported; **All** exports every finished game as its result is shown ("Saved C4G4" for 1.5 s); **Off** never asks. The demo is never asked about or exported.
- **The last game is always kept.** Each finished game (not the demo) is written to A:C4LAST, over the one before; its record is padded to 43 bytes, so the file never grows (56 bytes on A:). *Import game* lists it first as "Last game"; import it, then export it, if you started a new game too soon.
- **Import game** shows each game's moves: "C4G3   30".
- **Room.** A file is made only while C4 could still start again afterwards (the free gap below the game's array stays over 643 bytes; build.py's KEEP_GAP). Until 19 Nov the export that filled A: left C4 72 bytes short at the next start. On a blank CM 33 exported 30-disc games now fit (36 before), and C4 still starts after the next is refused.

How it fits: the Keep setting is the only new byte of RAM (it is saved, so the save file's version went to 7 and an older save starts a new game). The rest is in the overlays. The tally moved from OV_END into OV_HELP, which had room. That made room in OV_END for the key names and the question. OV_EXPORT and OV_IMPORT now build and read their files and lists in the screen driver's area, which is read in again afterwards, as the search already does. So they no longer need the top 256 and 120 bytes of the slot, and OV_EXPORT could take the last game and Keep All.

## The coach's check, the review's DOWN, the pause at levels 1-2 (19 Nov 2026)

- **The coach checks your drop.** With the coach on (Settings, Coach: On), in one-player and two-player games, a drop that the review would mark afterwards is named first, on the coach's line: "Missed a win" (you had a four to make), "Allows four" (the other side has one to make after it) or "Allows fork" (the other side then has a move you can't answer), with "EXE drops it" on line 2, and a buzz. EXE or DOWN drops it anyway; any other key goes back to choosing. As in the review, "Allows four" and "Allows fork" are named only when another column would have let neither happen, so a lost position isn't nagged about. A drop made by the move timer running out is never asked about. With the coach off nothing changes.
- **DOWN in the review goes to the next marked move**, stopping at each "Win -> draw", "Win -> loss", "Draw -> loss", "Missed a win", "Allows four" and "Allows fork" in turn, and at the end after the last. UP still goes to the start, so UP then DOWN, DOWN ... visits a game's mistakes. Each step is replayed and drawn on the way, so the board runs forward to the mark: 11 unmarked moves take 0.2 s on the CM, 0.7 s on the LZ64.
- **At Pace Natural, levels 1 and 2 pause too.** They search only 2 moves ahead, which takes no time, so the Psion answered at once even at Pace Natural, while (since 19 Nov) a forced block at the same levels waited 1.5 s. Now every move at those levels gets the book move's pause at Pace Natural (the demo's too); Pace Fast is unchanged.

How it fits, with no RAM: the check is a new entry, L_DROP, in OV_LIST, which already has the review's tactics code it reuses (the command table's C_DROP now goes there, and on to the kernel's `cm_drop`). The engine makes the drop and takes it back, as the review's tactics do. Only when there is something to say does it load OV_PANEL (entry P_WARN) to say it and wait for the key. Each drop now loads OV_LIST first (about 85 ms in the emulator, since the half-byte fix-ups below), coach on or off. The review's "no moves yet" buzz moved from OV_REVIEW into OV_LIST to make room for DOWN. OV_BOOK took 5 bytes for the levels 1-2 pause. The array is still 4,531 bytes; the pack grew by 301 bytes to 32,352 (416 free).

## Pack savings (19 Nov 2026)

The coach's check left 416 bytes free on the 32K Datapak. Two changes freed 3,941 bytes, with no change in play and a byte less RAM (`docs/report.html` has the pack's layout):

- **The book in 4 bits** (2,802 bytes). Its 22,409 entries were 5 bits each: a column and whether the Psion wins, draws or loses there. Only 20 entries are draws or losses (all in the Psion-second table: after you open in column 3 or 4, and some lines on from there), and they use just 8 column-and-result pairs. So `tools/build.py` stores 1-7 for a winning column, as before, and 8-15 for those 8 pairs; OV_BOOK's `bk_read` turns them back into the old codes, and the build fails if a new book ever needs another pair (`BOOK_HI`). Reading a nibble is simpler than reading 5 bits, so OV_BOOK and OV_COACH each shrank by 43 bytes. `data/book.bin` and the PC tools keep the 5-bit form.
- **Half-byte fix-ups** (1,139 bytes). Every overlay and the kernel carry a list of the words to which the array's address is added as they load: 2,184 of them, stored as a byte for each gap (and a count and a length at the front). The gaps are small (94% under 16; 38% exactly 3: one 3-byte instruction after another), so each is now a nibble: 1-15 on that far and fix the word there, 0 on 15 without one. The overlays' lists start with a one-byte length (64 bytes at most now), the kernel's has none (the fixer runs to the block's end). The resident loader came out a byte smaller (it steps a pointer with `abx` instead of adding offsets, and the count it never used is gone): the array is 4,530 bytes. Overlays load 6-12 ms faster, as fewer bytes are read from the pack (`tests/ui/t_loadtime.js`).

Pack: 28,411 bytes, 4,357 free (was 32,352). Further ideas, not done: 3 bits a book entry with the 20 draws and losses in a short list (about 2,700 more, but some 25 bytes of code in the two full book overlays); leaving out the empty groups of seven at the book's last depth (about 4K more); a compressed book read through its own overlay (the 4-bit book zips to 3.7K).

## RAM from the pack (20 Nov 2026)

With 4.3K free on the pack, two tables the kernel kept in RAM now stay there, and the empty-board routine is shorter: 78 bytes less RAM (array 4,452; C4 needs 4,782), play unchanged.

- **The overlay table** (40 bytes): where each unit starts in C4B0. It is now at the start of C4B0, after the command table; `ov_load` reads the unit's 2-byte entry, then the unit.
- **The command table** (34 bytes): what each command runs (`src/kernel/kcmd.asm`, the first thing in C4B0). `do_cmd` reads the command's 2-byte entry. A kernel routine is stored as its offset + $8000 and gets the array's address added as it is read; an overlay entry is its id × 256 + entry, as before. The build checks every entry.
- **The empty board** (`eng_reset`, 33 bytes for 53): it clears with the ROM's `UT$FILL` and sets the stop row and landing cells in one loop. Reading an empty position from the pack instead (15 bytes) was tried and dropped: in the emulator a seek back to the start of C4B0 takes about 55 ms (a short seek forward about 1 ms), and every step of the review would have paid it.

The seek back is also why the two tables cost little time: a command now pays it once, reading its entry, and the overlay that follows is then a seek forward. Overlay loads are within 2 ms of before, and some are faster (`tests/ui/t_loadtime.js`: OV_LIST 86 → 34 ms; OV_FX at most 37 ms, was 87), so a drop takes about as long as before. The quick tests pass (`tests/run_all.js --quick`), with `t_drop.js` on its default seed after a fix to the test (it pressed ON for the menu while the Psion was still thinking: any key stops the search, and is then flushed).

**Then the rarer kernel code into overlays** (122 bytes more; array 4,330, C4 needs 4,660, or 4,794 on the first launch):

- **The rarer commands** (OV_CMD, a new 69-byte overlay, `src/screens/ov_cmd.asm`): swap sides, resign, out of time. The command table points at it, so they cost an overlay load (about 30 ms) when used.
- **The end of a game** (`game_over` and its tune, `src/screens/kover.asm`): included in OV_FX, where a four or a full board ends the game, and in OV_CMD.
- **The menu**: the command table calls OV_MENU straight, and OV_MENU carries out the chosen command through `do_cmd` itself (the kernel's `cm_menu` gone).
- **The level in force** (`level`, 11 bytes): written out where it is used, in OV_BOOK, OV_HELP and OV_PANEL.
- **Start-up**: the kernel's entry jumps straight to the start-up code where it is stored; its first lines copy it into R (they use only absolute addresses, so they run there), and it seeds the random numbers and starts the game itself (`kinit.asm`, now 510 bytes, run once). The build assembles it twice, the second time knowing its own length.
- `psion_to_move` calls `side_to_move`.

Settings and Leave stay in the kernel: each calls an overlay and then carries on, which overlay code cannot do (the overlay it calls replaces it). Hint and the Psion's move stay too: the search covers slot A while they run.

**Not done: the lines through a cell worked out instead of looked up.** The engine's 326-byte table (`e_cloff`, `e_clist`) lists the lines through each cell; `e_make` and `e_unmake` read it on every move of the search. Two versions were built in a scratch copy of the engine and checked against `ref/engine.js` (`tests/engine/t_match.js`: identical moves, evaluations and searches) and timed with `tests/engine/t_prof.js` (3,369 cycles a position now):

| Version | RAM saved | Search |
|---|---|---|
| Worked out from the column and row with compares (a 13-byte list built at each move) | 124 bytes | 4,065 cycles a position: 21% slower |
| A 2-byte range table a cell (84 bytes) and the same list | 96 bytes | 3,768: 12% slower |

Strength stays the same at each level, since levels count positions, but the Psion thinks longer: level 8 (30,000 positions) about 118 s a move instead of 106 with the second. A faster form would walk the four ranges inside `e_make`/`e_unmake` with no list (estimated 6-8% slower, 150 bytes or so); not built.

## Build

```bash
python tools/build.py
```

This writes `build/game/C4.opk` (a 32K Datapak image) and `build/game/budget.txt` (the RAM and pack budget).
The book (`data/book.bin`) is made by:

```bash
node tools/book/gen_book.js
```
```bash
node tools/book/make_book.js
```

The first took about 2 hours on 15 cores (the last subtree, the opponent and the Psion both opening in the centre, is the slow one) and can be stopped and restarted; `tools/book/gen_one.js` finishes a single subtree on many cores.

## Run

In Jape: **Select OPK file** → `build/game/C4.opk` → **Create** → **Slot B**, then **Prog → Run → B:C4**.
On a real Organiser, burn the image to a 32K Datapak. Or, with a Comms Link: `python tools/build.py --psion` writes `psion/` (the pack's files as .OB3 procedures, with RPLOAD's list) for loading onto a Datapak with RPBOOT on any model: it runs RPLOAD on an LZ or LZ64 and the smaller RPLOADCM on a CM, XP or LA (`Tools/README.md`). Or load the pack in an LZ64 and move it to any model.

## Keys

| On your move | |
|---|---|
| LEFT, RIGHT | choose the next column with room |
| EXE or DOWN | drop the disc in the chosen column (with the coach on, a drop that misses a four or lets one in is named first: EXE or DOWN again drops it) |
| 1 to 7 | choose that column (no SHIFT: the key carrying the digit counts, U V W O P Q I) |
| DEL | take back your move (and the reply, against the Psion) |
| SPACE | hint: a 600-position search, about 2 s |
| MODE | ask the coach |
| UP | the move list |
| ON/CLEAR | the menu (Review game is in it) |
| any key while it thinks | the Psion moves now |

In menus: UP/DOWN move, a letter jumps to the next item starting with it, EXE takes the item, ON/CLEAR goes back. In the settings LEFT/RIGHT change a value.

## Measured

| | |
|---|---|
| Search speed | about 300 positions a second with the OS running, the same on the CM and the LZ64 (the spec guessed 500); 286 a second on the bare processor (291 after the zero-page variables on 19 Nov; 284 after two engine tables were replaced by code, to save 111 bytes; 286 after an unreachable check was removed) |
| Exact endings | positions from engine games: all 60 with 8-14 empty cells solved exactly (right score, right move) in 617 positions on average (2 s); level 8 solves 17 of 20 at 16 empty, 18 of 20 at 18, about a third at 20-22 (`ref/test_endings2.js`) |
| Strength | the share of the engine's moves that keep the true result, against a perfect opponent from random 8-ply positions: level 1 96.2%, 2 96.0% (240 games each), 3 97.6%, 4 97.2%, 5 96.7%, 6 97.3%, 7 97.7%, 8 98.5% (80 games each; `ref/strength.js`). With the 84-byte key table the cell keys replaced (19 Nov): 96.5, 96.0, 97.4, 97.4, 96.5, 97.3, 97.8, 98.6: the same within noise |
| Book | 13,260 entries; 754 of its 8-disc positions agree with Tromp's database (none differ); 2,905 entries agree with their replies' entries (none differ); on 10,000 random openings the walk finds the generator's entry at all 49,072 positions (18,676 mirrored); in the game the Psion's 117 book moves checked all match the PC's walk. On the pack 4 bits an entry (11,205 bytes; 5 bits, 14,007, until 19 Nov evening) |
| Search experiments (19 Nov) | tried in `ref/engine.js` (options, all off in the game) with `ref/bench.js` and `ref/match.js`: PVS 5% fewer positions to a fixed depth; history ordering 12%; second killer 4%; two-entry table 3% more (better endings); PVS + history + two-entry table 16%; aspiration windows 5-16% more; win/draw/loss proving of endings no change. In 2,000-game matches against the plain engine at the level-7 budget (and 600 at level 8) every candidate scored 49.4-50.4%: no measurable strength. Exact endings within the level-8 budget, of 993 positions with 16-22 empty: plain 662, PVS +16, both PVS and the two-entry table +25. PVS would cost about 50 bytes of RAM, the table about 40: not taken |
| Evaluation | threat-parity weights 24/6 and 10/3 tried against the spec's 16/4 at levels 5-8 (60 games each): no difference beyond noise, so the spec's are kept |
| Same play on every model | the CM and the LZ64 searched the same 138,363 positions in the same 34 searches |
| RAM | an array of 4,323 bytes on every model (5,664 on the morning of 19 Nov 2026; 4,528 before the Keep setting, 4,529 before the forced block, 4,531 before the half-byte fix-ups, 4,530 before the tables went onto the pack on 20 Nov, 4,452 before the rarer commands moved into overlays); C4 needs 4,660 bytes free (4,794 on the first launch, before the first save, which makes A:C4SAV, 93 bytes, and A:C4TAL, the tally, 41). A blank CM has 6,417 free when C4 checks, so about 1,650 bytes are left over both before the first save (C4 keeps room for the save files) and after it (they then take 134; A:C4LAST, the last game, takes 56 more after the first game) |
| CM with games on A: | 33 exported 30-disc games fit beside the game on a blank CM; the next is refused ("Cannot save") while C4 can still start again. (Until 19 Nov 36 fitted, but the last left C4 72 bytes short: it said so and wouldn't start until a game was deleted.) (`tests/ui/t_lowmem.js`) |
| Pack | 27.8K of 32K: 28,483 bytes, 4,285 free (29.6K before review mode; 32,051 before the coach's check on 19 Nov, 32,352 before the 4-bit book and half-byte fix-ups) |
| Forced block (19 Nov) | with no win of its own and exactly one of your wins to stop, the Psion now blocks without searching: at Pace Fast at once (0.15 s), at Pace Natural after the same pause as a book move (about 1.5 s; any key cuts it short). OV_BOOK sees these turns before the search, from the threat counts at the landing cells, so the pause costs no RAM (`tests/ui/t_forced.js`). In 1,520 such positions from random games the full search had chosen the same move at every level, after 10 positions on average at levels 1-2, 512 at 3, 758 at 4, 1,240 at 5, 2,423 at 6, 7,049 at 7 and 22,962 at 8 (about 75 s; at most 30,000, 100 s) (`ref/test_forced.js`). The engine grew 2 bytes. A blocked move has no solved score, so after it the coach shows no "Win in 9" and the review has no history value for it; the Psion's next move searches as before |
| Overlay loads | in the emulator, during one-player games at level 3 (`node tests/ui/t_loadtime.js`): OV_FX 44 ms (each move), OV_GAME 37, OV_PANEL 60 (your turn), OV_LIST 86 (each drop of yours), OV_PLAY 28, OV_BOOK 34, the screen driver 52 (after each search). With the byte-a-gap fix-ups before 19 Nov evening: 55, 46, 70, 96, 34, 44 and 64 |

## Where it differs from the spec

- **Levels re-timed.** The engine searches about 300 positions a second, not 500. So the counts give the spec's times: 600, 900, 1,500, 3,000, 9,000 and 30,000 positions at levels 3-8 (about 2, 3, 5, 10, 30 and 100 s). The hint is 600 positions.
- **Memory layout.** The overlay slot (671 bytes, set by the largest overlay with the buffer it uses), the screen driver and the engine's search table and scratch share RAM: overlays only run while the engine is idle, the table is cleared at every search, and the driver is read in again after a search (and after export and import, which use its area as their buffer) (`docs/design.md`).
- **Save files.** A:C4SAV is one record, read and written in place; the tally is a second file, A:C4TAL, so it takes no RAM in the game.
- **Kernel size.** Start-up code is appended to the kernel image and run once from that region. The menu routine is included in each of the three overlays that show lists, not kept in the kernel.
- **Search table key.** 24 bits from 84 bytes of cell keys: the index is 7 bits, the check 13 bits, as the spec asks.
- **Frames.** The engine keeps 20 search frames (level 8 reached depth 17 at most in 900 searches with more than 20 empty cells).
- **"Do not feed" moves.** A move that lets the opponent win directly above it is not searched: it is scored as the loss it is. The spec says it is searched last; the result is the same.
- **Two-line board text.** The credit "Daniel+Claude" is 13 letters: the title prints it one column left of the panel.
- **Panel text on four lines.** Lines 1 and 2 start with the side's disc, so long names lose a space: "Hollow:col4", "Solid: col4".
- **Hints in two-player games.** The spec has them off by default there; here the hint key does nothing in a two-player game (the Hints setting is for the one-player game).
- **Match score.** It shows player 1 and player 2 ("P1 2 - P2 1"), because who starts changes which side each player has.

## Stress test (19 Nov 2026)

`tests/ui/t_stress.js` presses random keys (weighted to the game's keys, with bursts, long holds, SHIFT, and idle spells long enough for the Organiser to switch itself off) on every Organiser ROM: CM 2.4, 2.6, 3.3, 3.3 French, 3.6 French; XP 2.4, 2.6, 3.1; LA 3.0 (HP), 3.3, 3.4 German, 3.6, 3.6 French, 3.6 German, 3.7 multilingual; LZ 4.2, 4.4, 4.5, 4.5 Italian/Spanish, 4.5 Swedish/Danish, 4.6, 4.6 Italian/Spanish; LZ64 4.3, 4.4, 4.5, 4.6a, 4.6b, 4.6 Italian/Spanish, 4.6 Swedish/Danish. Every time the game waits for a key it checks that the kernel and engine code are unchanged, that the board is the move record replayed, that the stack is where it was, and that a result has a reason; a game left and started again must resume the same record. (The POS 200, 250, 350 and P432/P464 terminals need their own application packs and are not covered.)

Bugs it and the directed tests around it found, all fixed:
- the winning four blinked until a key, so the Organiser never switched itself off on the result screen (now about 15 s, then it rests);
- a two-player game never let it switch off, even with no clock or move timer running;
- importing a file whose record was longer than 104 bytes (one made with OPL) wrote past the end of the game's RAM;
- (found while freeing RAM) the tally counted into a stray byte, and resuming a finished game counted it again and forgot a resignation.

## UI pass (19 Nov 2026)

Every screen was captured on a CM and an LZ64 (`node tests/ui/tour.js`, then `node tests/ui/sheet.js cm` for a numbered contact sheet in `build/shots/`) and reviewed. Changed:
- **Two-line screens, two players:** the game clocks were never shown (they went to line 4); they now take line 1, in place of the last move.
- **Move timer:** its countdown never fitted after "Hollow: col4" and was cut off on both displays; while it runs, line 2 now reads "Hollow:4 17" (side, chosen column, seconds left). It also started again whenever the play screen came back (after the menu, the move list, the coach), so a player could win back time; now it goes on where it was (held, like the game clock, while those are shown) and starts afresh only for the next move.
- **Four-line screens:** the menu clears the panel as it closes, so no menu lines are left under set-up, an export's message, the name prompt or a demo.
- **Coach:** "You can win", "It's a draw", "You lose" are now "Coach: win", "Coach: draw", "Coach: lost" (on two lines the verdict replaces the last move while the Psion thinks, and read like the result); out of the book, "Can't tell" instead of "Not known".
- **Resigning:** "You resigned" (one player) or "by surrender" (two players) instead of "by resigning".
- **Swap rule:** "EXE=Y  ON=N" (any key but EXE is no).
- **Settings:** "Undo" for "Takebk"; who starts: "Lost", "Won" for "Losr", "Winr".
- **Smaller things:** two-line screens show the level before the first move; after a hint, line 2 says "Hint: col 5" until a key; the demo shows the move number on four lines; "C4 ERROR 1" has its space.
None of it changed the array: the overlays grew inside the slot (OV_GAME made room for the swap text).

The final runs (two seeds, 60 emulated minutes on each ROM: 58 runs) passed: 282,844 random keys, 88,958 key waits checked, 2,531 games finished, 197 times left and resumed.

Also tried and found sound: keys hammered during start-up, the pack in slot C, junk save and tally files, the pack taken out mid-game (the OS stops the program at the next overlay load, with no message; the saved game resumes).

## Still to check (need a real Organiser)

From the spec's list:
- the eighth dot row of a glyph on the two-line screen;
- the gap between the screen's lines;
- the display chip's busy time on the CM;
- whether a Datapak written on the LZ64 reads on the CM.

The emulator showed:
- an LZ starts the CM-translated launcher and switches itself to four lines, and back on leaving;
- FL$BOPN works on the CM (ROMs 2.4, 2.6 and 3.3);
- glyphs can be written straight to the display chip on every model;
- PEEKB(-24) gives 0, 1, 2, 14, 13 on the CM, XP, LA, LZ, LZ64.

**Two versions on two packs (24 Nov 2026, version 1.0.1).** The launcher looks for its data on C:, then B:, then A:. Until now it took the first it found, so another version on another pack could be loaded (in Chess that stopped a real Organiser with TRAP 0007 7E80). The data now starts with the build's number, a checksum the launcher has too, and any other build's is passed over; and the data block has a new name, C4M (C4K before: one left on a pack from an older version is not used and can be deleted). The start-up code checks the blocks C4B0 and C4B1 the same way. The peak (while C4G pokes the bootstrap, from a longer string) is 8 bytes higher, so C4 needs 4,668; seven of the engine's bytes went into the launcher's copy of the bootstrap, seven longer. `tests/ui/t_mixed.js` starts every combination on six ROMs, with the last released version and with another build.

## Tests

| | |
|---|---|
| `node ref/test_engine.js` | reference engine: tables v a recount, win detection v the solver, exact endings v the solver |
| `node ref/test_forced.js` | the forced block: the full search chose the same move at every level |
| `node tests/ui/t_forced.js cm lz64` | the forced block in the game: the right column, at once (Fast), after the pause (Natural), or when a key cuts the pause short; levels 1-2 pause at Natural, not at Fast |
| `node tests/ui/t_loadtime.js [cm]` | how long each overlay takes to load, while games are played |
| `node tests/ui/t_drop.js cm lz64` | the coach's check of a drop, against `tests/ui/tactics.js`: one player (marked and unmarked drops; EXE, DOWN, ON after a mark), the coach off, two players, the move timer's drop unasked. `DROP_SEED=n` picks another sequence of choices (default 5). Seeds 8 and 9 fail in the coach-off part: the first drop after the test switches the coach off (a poke, in the middle of your turn) lands in another column. The build before 20 Nov fails seed 9 the same way, so it is not the pack tables; not explained yet |
| `node tests/engine/t_match.js` | 6303 engine v the reference: every state byte, every evaluation, searches (move, score, depth, positions) |
| `node tests/ui/t_twoplayer.js cm lz64 xp la lz cm24` | a two-player game, leave and resume, on every model |
| `node tests/ui/t_features.js cm lz64` | take back, hint, coach, move list, settings, export, import, set-up, help, resign |
| `node tests/ui/t_modes.js cm lz64` | demo, game clock, move timer, swap rule, match |
| `node tests/ui/t_book.js cm` | the Psion's book moves and the values it puts in the history v the PC's book walk; your 7 first moves with the Psion second (win, win, draw, loss, draw, win, win: the 4-bit codes 8-15) |
| `node tests/ui/t_search.js cm` | the Psion's searched moves v the reference engine |
| `node tests/ui/t_selfplay.js lz64` | whole games against the reference engine, coach on |
| `node tests/ui/t_glyphs.js cm lz64` | the board on the screen v the position after every move (glyph dots, characters) |
| `node tests/ui/t_list.js cm lz64` | the move list for games of 1, 20, 21 and 42 discs, scrolled |
| `node tests/ui/t_stress.js all 60` | random keys on all 29 ROMs, 60 emulated minutes each (optional seed `s7`; with the environment variable STRESS_COACH=1 the coach is kept on, so the drop check meets random keys too) |
| `C4_COVER=build/cover node tests/ui/...` then `node tests/coverage.js build/cover` | which instructions the tests ran, unit by unit, and the runs that never ran (all the UI tests and 2 hours of stress: 95%) |
| `node tests/ui/t_autooff.js cm lz64` | it switches itself off on every screen where nothing keeps time; the glyphs after switching on |
| `node tests/ui/t_tally.js lz64` | the tally counted once, kept on resume; a resignation kept on resume |
| `node tests/ui/t_review.js cm lz64` | the history v the solver and the book; the review's every step (board, move, verdict, and that the verdict is true, or the tactic), UP, DOWN to each marked move then the end, leaving; from the menu mid-game |
| `node tests/ui/t_tactics.js cm lz64` | the review's tactics: the C4G2 game (moves 3, 9, 11), then random two-player games, every step against `tests/ui/tactics.js` (a plain-board model, apart from the engine); DOWN from the start stopping at each tactic, then the end |
| `node tests/ui/t_keep.js cm lz64` | the result's keys named in turn and the line put back; Keep Ask (ON, EXE, E on the result), All, the setting; Import: "Last game" first, the moves, the last game imported, ON |
| `node tests/ui/t_lowmem.js` | a CM filling up with exported games: the next refused while C4 can still start |
| `node tests/ui/t_soak.js cm 20` | the demo playing itself for 20 emulated minutes: every game legal, every result right |
| `node tests/ui/t_speed.js cm 6` | positions a second in the game |
| `node tests/run_all.js [--quick]` | all of the above |
| `node ref/strength.js` | strength by level against a perfect opponent |

## About this repository

One of the Psion Organiser II projects on Forgejo (`Daniel/Psion-*`). The build and test scripts expect the PsionII workspace layout:

```
PsionII/
  Emulator/          Jape, Jaap Scherphuis's emulator, with its ROM images (not in any repo:
                     https://www.jaapsch.net/psion/jape/jape.htm)
  Tools/             Daniel/Psion-Tools (opltran, opl2opk, RPBOOT/RPLOAD, ...)
  Programs/NAME/     this repository
```

`build/` is not committed: the build scripts recreate it.

Also kept out of the repository (large, downloaded or third-party):

- `ext/tromp/` - John Tromp's 8-ply Connect-4 database (UCI Machine Learning Repository, https://archive.ics.uci.edu/dataset/26/connect+4), used to check the book.
- `backup/` - snapshots taken before each round of changes; the git history does that job now.
