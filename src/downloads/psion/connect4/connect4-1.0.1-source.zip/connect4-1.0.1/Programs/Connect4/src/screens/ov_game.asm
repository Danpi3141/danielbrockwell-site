; =====================================================================
; OV_GAME: the save file, a new game, take back, replaying the record,
; and the swap rule's question (two players, asked when the first disc
; is saved). The save file A:C4SAV is one record: length, 'C', version,
; the bytes sv_first..sv_end, a checksum, read and written in place.
; =====================================================================
        include "../defs.inc"

SV_VER  = 7                     ; (4: the history g_hv; 5: the tally in A:C4TAL; 6: g_rec packed; 7: st_keep)
SV_LEN  = sv_end-sv_first
HV_GET  = 0
HV_SET  = 1

        jmp  g_load
        jmp  g_save
        jmp  g_newg
        jmp  g_back
        jmp  g_rsave
        jmp  g_replay

fn_sav: fcl  "A:C4SAV"

; open the save file: C clear if it is there; its record 1 current
sv_open:
        clr  kv_pkok            ; (the file services select A:)
        ldx  #fn_sav
        os   FL$OPEN
        bcs  .x
        tab
        os   FL$RECT
        clra
        clrb
        os   FL$SETP
        ldd  #1
        os   FL$RSET
.x:     rts

; B = checksum of the saved bytes
sv_sum: ldx  #sv_first
        clrb
.l:     addb 0,x
        inx
        cpx  #sv_end
        bne  .l
        rts

; the record is read straight into place, then checked
g_load: bsr  sv_open
        bcs  .new
        ldx  #sv_rec
        os   FL$READ
        bcs  .new
        ldaa sv_rec
        cmpa #SV_LEN+3
        bne  .new
        ldd  sv_tag
        subd #'C'*256+SV_VER
        bne  .new
        bsr  sv_sum
        cmpb sv_chk
        bne  .new
        ldaa g_n
        cmpa #42
        bhi  .new
        clr  kv_pkok
        ldx  g_over             ; g_over and g_res as saved: replaying would count a
        pshx                    ; result again, and forget a resignation or a flag
        jsr  g_replay           ; (until 19 Nov it did)
        pulx
        stx  g_over
        rts
.new:   clr  kv_pkok
        ldx  #sv_first          ; the defaults and a new game
.z:     clr  0,x
        inx
        cpx  #sv_end
        bne  .z
        ldaa #9
        staa st_level           ; Auto
        ldaa #2
        staa st_you             ; alternate
        ldaa #5
        staa st_dlv1
        staa st_dlv2
        ldaa #4
        staa g_alv
        clr  kv_arg             ; one player
        bra  g_newg

g_save: jsr  g_swapq            ; (two players, after the first disc)
        ldaa #SV_LEN+3          ; the record, in place
        staa sv_rec
        ldd  #'C'*256+SV_VER
        std  sv_tag
        bsr  sv_sum
        stab sv_chk
        jsr  sv_open
        bcc  .old
        ldx  #fn_sav            ; no file yet
        os   FL$CRET
        bcs  .x
        tab
        os   FL$RECT
        bra  .w
.old:   os   FL$ERAS
.w:     ldx  #sv_rec
        os   FL$WRIT
.x:     clr  kv_pkok
        clra                    ; (no command, for OV_RESULT)
        rts

; ---------------------------------------------------------------------
; G_NEWG: a new game. kv_arg = mode (0 one player, 1 two players, 2 demo)
; ---------------------------------------------------------------------
g_newg: ldab kv_arg
        stab g_mode
        ldd  FRC                ; a new game stirs the seed (the demo has no keys)
        eora kv_seed+1
        eorb kv_seed
        std  kv_seed
        tst  g_p1               ; two players: player 1 starts as Solid
        bne  .p1
        inc  g_p1
.p1:    ldaa #3
        staa g_chosen           ; the centre column
        clr  g_n
        clr  g_over
        clra
        clrb
        std  g_clk
        std  g_clk+2
        ldab g_mode
        beq  .one
        clra                    ; two players: nobody's Psion
        decb
        beq  .p
        ldaa #3                 ; demo: both
        bra  .p
.one:   ldaa st_you             ; 0 you first, 1 second, 2 alternate
        cmpa #2
        bne  .y
        ldaa g_alt
        eora #1
        staa g_alt
.y:     inca                    ; you first: the Psion is Hollow (2)
        eora #3
.p:     staa g_psion
        bsr  g_new
        bra  g_rsave

; a finished match starts again; the clocks (two players)
g_new:  clr  g_swq
        ldab st_match
        beq  .ck
        ldx  #.tgt-1
        abx
        ldab 0,x
        cmpb g_score
        beq  .rs
        cmpb g_score+1
        bne  .ck
.rs:    clr  g_score
        clr  g_score+1
.ck:    ldab st_clock
        beq  .x
        ldx  #.min-1
        abx
        ldab 0,x                ; minutes
        ldaa #60
        mul
        std  g_clk
        std  g_clk+2
.x:     rts
.min:   fcb  1,3,5,10
.tgt:   fcb  3,5,10


; ---------------------------------------------------------------------
; G_BACK: take back one move in a two-player game, your move and the
; reply against the Psion (only while allowed)
; ---------------------------------------------------------------------
g_back: tst  st_back
        bne  .no
        ldaa g_n
        beq  .no
        ldab g_psion
        cmpb #3
        beq  .no                ; (demo)
        deca
        staa g_n
        tstb
        beq  .r                 ; two players: one move
        anda #1                 ; one player: if the Psion is now to move,
        inca                    ; your move goes too
        cmpa g_psion
        bne  .r
        ldaa g_n
        beq  .r
        dec  g_n
.r:     ldab g_n                ; the history after the position now goes
.cut:   incb
        cmpb #42
        bhi  .rp
        pshb
        clra
        jsr  hv_set
        pulb
        bra  .cut
.rp:    bsr  g_replay
        clr  g_over
        jmp  g_save
.no:    ldx  #snd_buzz
        jmp  snd_play

; ---------------------------------------------------------------------
; G_RSAVE: a new record (a new game, an import, a set-up): the history
; cleared, the position replayed, saved
; ---------------------------------------------------------------------
g_rsave:
        ldx  #g_hv
.z:     clr  0,x
        inx
        cpx  #g_hv+11
        bne  .z
        bsr  g_replay
        jmp  g_save

; ---------------------------------------------------------------------
; g_replay: the position rebuilt from g_rec (g_n moves), board redrawn
; ---------------------------------------------------------------------
g_replay:
        jsr  eng_reset
        clr  g_over
        clr  kv_xsc
        clr  kv_t2
.l:     ldab kv_t2
        cmpb g_n
        beq  .d
        jsr  rec_get
        jsr  e_make
        bcc  .n
        jsr  side_to_move       ; a four in the record: the game is over
        eora #3
        staa g_res
        ldaa #1
        staa g_over
.n:     inc  kv_t2
        bra  .l
.d:     ldaa e_n
        cmpa #42
        bne  .b
        tst  g_over
        bne  .b
        ldaa #3
        staa g_res
        inc  g_over
.b:     jmp  DRV+DV_BOARD

; ---------------------------------------------------------------------
; the swap rule (two players): after Solid's first disc, Hollow's player
; may take Solid. Asked once, when that disc is saved.
; ---------------------------------------------------------------------
g_swapq:
        ldaa g_mode
        deca
        bne  .x
        tst  st_swap
        beq  .x
        ldaa g_n
        deca
        bne  .x
        tst  g_swq
        bne  .x
        tst  g_over
        bne  .x
        inc  g_swq
        jsr  lb_clr
        jsr  lb_s
        fcl  "Swap sides?"
        clra
        jsr  lb_put
        jsr  lb_clr
        jsr  lb_s
        fcl  "EXE=Y  ON=N"          ; (any key but EXE is no)
        ldaa #1
        jsr  lb_put
        clra
        jsr  key_wait
        cmpb #K_EXE
        bne  .x
        ldaa g_p1               ; the players change sides
        eora #3
        staa g_p1
.x:     rts

        include "khist.asm"

REC_PUT = 0
        include "krec.asm"
