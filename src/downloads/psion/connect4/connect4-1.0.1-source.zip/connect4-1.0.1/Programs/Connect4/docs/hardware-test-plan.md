# Hardware test plan

Checks that only a real Organiser can answer: the spec's "Still to check" list, and the emulator's blind spots.

## Getting the pack onto the machines

1. Burn `build/game/C4.opk` to a 32K Datapak with a pack writer. Or, on an LZ64 with a Comms Link, send the pack's files to a Datapak with RPLOAD (`python Tools/mkrpdata.py`).
   A Datapak cannot be erased without ultraviolet light, so use a finished build.
2. Put the Datapak in slot B of the LZ64 and run **Prog → Run → B:C4**. Then move it to the CM and do the same.
   This answers whether a Datapak written on the LZ64 reads on the CM.

## On the CM (two-line screen)

| Check | How | Pass |
|---|---|---|
| Free RAM | Run C4 on a CM with nothing on A: | The title appears. If "C4 NEEDS n BYTES MORE RAM" appears, note n and what is on A: |
| The eighth dot row | Drop a disc in any column | The bottom row's discs are 2 by 2 dots, not 2 by 1. The board's lowest cells use the glyph's dot rows 7 and 8 |
| Solid and Hollow | Play a few discs each | Solid (a 2 by 2 square) and Hollow (a diagonal pair) are easy to tell apart, and from an empty cell |
| The separator | Look at the right edge of the board block | One dotted line, right of column 7 |
| The gap between lines | Look at rows 3 and 4 (the two screen lines) | The cells look evenly spaced across the line gap; note how it looks |
| Display timing | Play a quick game and use the menus | No glyph is garbled. That would mean the display chip was still busy |
| Ghost disc and blinks | Wait on your move | The landing cell blinks about 3 times a second; the Psion's last disc blinks twice after it moves |
| Speed | Level 6, mid-game: time the "Thinking" | About 10 s (the emulator gives 300 positions a second) |
| Switch off | Leave it on your move for the Organiser's switch-off time | It switches off; ON brings the board back, glyphs and all |
| Leave and resume | Menu → Leave, then run C4 again | The same position |

## On the LZ64 (four-line screen)

| Check | How | Pass |
|---|---|---|
| Four lines | Run C4 | The board on lines 1-3, `1234567` under it, the panel at the right |
| Leaving | Menu → Leave | The Organiser's own screen comes back normally, including its top line's clock symbols |
| Discs | Play a few | Solid filled, Hollow a ring; each character shows the right pair of cells |
| The same pack | Use the Datapak written for the CM | It runs unchanged |

## Worth noting either way

- How the thinking bar and the blinking look on the real display (it is slow to change).
- Whether the falling disc (50 ms a cell) reads as a fall on the real display.
