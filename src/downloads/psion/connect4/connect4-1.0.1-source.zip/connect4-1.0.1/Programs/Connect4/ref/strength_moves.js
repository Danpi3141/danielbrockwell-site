// a move order reaching a Tromp position (8 discs, x first): columns bottom-up, alternating
'use strict';
module.exports = function startMoves(p) {
  const col = [];
  for (let c = 0; c < 7; c++) {
    const stack = [];
    for (let r = 0; r < 6; r++) {
      const b = c * 7 + r;
      const inM = b < 28 ? (p.ml >> b) & 1 : (p.mh >> (b - 28)) & 1;
      if (!inM) break;
      const inC = b < 28 ? (p.cl >> b) & 1 : (p.ch >> (b - 28)) & 1;
      stack.push(inC ? 'x' : 'o');
    }
    col.push(stack);
  }
  const ptr = [0, 0, 0, 0, 0, 0, 0], out = [];
  const dfs = (k) => {
    if (k === 8) return true;
    const want = k % 2 === 0 ? 'x' : 'o';
    for (let c = 0; c < 7; c++) {
      if (ptr[c] < col[c].length && col[c][ptr[c]] === want) {
        ptr[c]++; out.push(c);
        if (dfs(k + 1)) return true;
        ptr[c]--; out.pop();
      }
    }
    return false;
  };
  if (!dfs(0)) throw new Error('no move order');
  return out;
};
