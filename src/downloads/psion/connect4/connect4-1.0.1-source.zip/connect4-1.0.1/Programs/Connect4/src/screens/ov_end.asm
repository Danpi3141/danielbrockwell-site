; =====================================================================
; OV_END, after OV_RESULT has shown the result (and OV_HELP's H_TALLY the
; tally): the keys, with the winning four blinking or the draw sweeping,
; and the keys named in turn on the panel's last line. Returns a command.
; (Until 19 Nov the tally was here too.)
; E_NEW: the command C_NEW, kv_arg = the mode. With Keep "Ask", a result
; of one or two players not kept yet (g_res bit 7) is asked about first,
; "Export game?": EXE yes (OV_EXPORT's X_NEW exports it, then the new
; game), ON no. Then the new game.
; =====================================================================
        include "../defs.inc"

RS_LINE = SLOTA+SLOTA_SIZE-12   ; the result's last line (OV_RESULT): put back after the hints

        if   FX_EMPTY
OV_NEWG = OV_FX*256+X_EMPTY     ; a new game: the board empties (OV_FX), then OV_GAME's G_NEWG
        else
OV_NEWG = OV_GAME*256+G_NEWG
        endif

        jmp  en_keys
        jmp  en_new

en_new: tst  g_over
        beq  .go
        tst  st_keep            ; 0: ask
        bne  .go
        tst  g_n
        beq  .go
        ldaa g_mode
        cmpa #2
        beq  .go                ; (not the demo)
        tst  g_res              ; bit 7: kept already
        bmi  .go
        jsr  pn_clear
        jsr  lb_s               ; (pn_clear leaves the line empty)
        fcl  "Export game?"
        clra
        jsr  lb_put
        jsr  lb_clr
        jsr  lb_s
        fcl  "EXE=Y  ON=N"
        ldaa #1
        jsr  lb_put
.k:     clra
        jsr  key_wait
        cmpb #K_ON
        beq  .go
        cmpb #K_EXE
        bne  .k
        ldd  #OV_EXPORT*256+X_NEW
        jmp  ov_call
.go:    ldd  #OV_NEWG
        jmp  ov_call

; the keys: EXE a new game, ON/CLEAR the menu, UP the move list, DEL
; take back, MODE the review, E export. Meanwhile the winning four blinks
; (or a full board sweeps once), and for about 15 s the last line names
; the keys in turn, 2 s each; then it is put back, and the key wait that
; follows lets the Organiser switch itself off. The demo: its four blinks
; about 3 s, no keys named, then a new game. A = a command.
en_keys:
.key:   jsr  rs_fx              ; the four's cells (rs_cn: 0 none); a draw sweeps across once
        tstb
        bne  .k
        ldaa #38                ; about 15 s
        ldab g_mode
        cmpb #2
        bne  .bc
        ldaa #8                 ; the demo: about 3 s
.bc:    staa rs_bc
        clr  en_h
        ldaa #5
        staa en_t
.l:     ldab g_mode             ; every 5 rounds (2 s) the next key named (not the demo)
        cmpb #2
        beq  .b
        dec  en_t
        bne  .b
        ldaa #5
        staa en_t
        bsr  en_hint
.b:     tst  rs_cn              ; a round: the four blinks once, or 8 frames
        beq  .nb
        jsr  rs_blink
        bra  .kb
.nb:    ldaa #8
        jsr  key_wait
.kb:    tstb
        bne  .k
        dec  rs_bc
        bne  .l
        ldx  #RS_LINE           ; the line as it was
        bsr  en_put
        clra
        ldab g_mode
        cmpb #2
        bne  .w
        ldaa #60                ; the demo goes on by itself
.w:     jsr  key_wait
        tstb
        beq  .new
.k:     cmpb #K_EXE
        beq  .new
        ldaa #C_MENU
        cmpb #K_ON
        beq  .x
        ldaa #C_LIST
        cmpb #K_UP
        beq  .x
        ldaa #C_BACK
        cmpb #K_DEL
        beq  .x
        ldaa #C_EXPORT          ; (OV_EXPORT, then the result again)
        cmpb #'E'
        beq  .x
        cmpb #K_MODE
        bne  .key
        ldd  #OV_LIST*256+L_TACT    ; (the review returns no command: the result again)
        jmp  ov_call
.x:     rts
.new:   ldaa #C_NEW
        ldab g_mode
        rts

; the next key named on the last line (en_h 1-4), or the line as it was (0)
en_hint:
.n:     inc  en_h
        ldaa en_h
        cmpa #5
        blo  .s
        clr  en_h
        ldx  #RS_LINE
        bra  en_put
.s:     cmpa #1                 ; "EXE new game": four lines have it as their line
        bne  .e
        ldab kv_plines
        cmpb #4
        beq  .n
.e:     cmpa #2                 ; "E export": not when kept, or with no moves
        bne  .t
        tst  g_res
        bmi  .n
        tst  g_n
        beq  .n
.t:     deca
        ldab #12
        mul
        addd #en_txt
        xgdx
; X = 12 characters: the panel's last line
en_put: ldaa kv_plines
        deca
        jmp  pn_put

en_txt: fcc  "EXE new game"
        fcc  "E export    "
        fcc  "MODE review "
        fcc  "UP move list"
en_h:   fcb  0
en_t:   fcb  0

; ---------------------------------------------------------------------
; Stretch goals: the winning four's cells into rs_cells (rs_cn of them,
; 0 if there is no four); a full board's columns blink in turn, once
; (B = a key that cut it short, else 0).
; rs_set blanks rs_cells (A = 0) or puts them back.
; ---------------------------------------------------------------------
rs_fx:  clr  rs_cn
        ldx  #e_lc              ; the line holding four
        clrb
.f:     ldaa 0,x
        cmpa #4
        beq  .got
        cmpa #$40
        beq  .got
        inx
        incb
        cmpb #69
        bne  .f
        ldaa g_res              ; no four: a draw sweeps
        anda #3
        cmpa #3
        bne  .none
        clra                    ; column by column: its 6 cells
.sw:    psha
        ldab #7
        mul
        ldx  #rs_cells
        ldaa #6
        staa rs_cn
.c6:    stab 0,x
        incb
        inx
        deca
        bne  .c6
        pula
        psha
        bsr  rs_blink
        pula
        tstb
        bne  .x
        inca
        cmpa #7
        bne  .sw
.none:  clrb
.x:     clr  rs_cn
        rts
.got:   jsr  e_line             ; its cells: the first, and the step
        ldaa e_stp
        staa rs_d
        ldx  #rs_cells
        ldaa #4
        staa rs_cn
.c4:    stab 0,x
        addb rs_d
        inx
        deca
        bne  .c4
        clrb
        rts

; the cells off for 4 frames, then back for 4: B = a key that cut it short
rs_blink:
        clra
        bsr  rs_set
        ldaa #4
        jsr  key_wait
        pshb
        ldaa #1
        bsr  rs_set
        pulb
        tstb
        bne  .x
        ldaa #4
        jmp  key_wait
.x:     rts

; A = 0: rs_cells blanked (their discs kept in rs_save); 1: put back. Shown.
rs_set: staa rs_d
        clr  rs_i
.l:     ldab rs_i
        ldx  #rs_cells
        abx
        ldab 0,x
        stab rs_tc              ; the cell
        ldx  #e_bd
        abx
        ldab rs_i
        tst  rs_d
        bne  .on
        ldaa 0,x
        pshx
        ldx  #rs_save
        abx
        staa 0,x
        pulx
        clr  0,x
        bra  .dr
.on:    pshx
        ldx  #rs_save
        abx
        ldaa 0,x
        pulx
        staa 0,x
.dr:    ldaa rs_tc              ; column = cell / 7, row = cell mod 7
        clrb
.dv:    cmpa #7
        blo  .sh
        suba #7
        incb
        bra  .dv
.sh:    psha
        tba
        pulb
        jsr  DRV+DV_CELL
        inc  rs_i
        ldab rs_i
        cmpb rs_cn
        bne  .l
        rts

rs_cells: rmb 6
rs_save: rmb 6
rs_cn:  fcb  0
rs_bc:  fcb  0
rs_d:   fcb  0
rs_i:   fcb  0
rs_tc:  fcb  0
