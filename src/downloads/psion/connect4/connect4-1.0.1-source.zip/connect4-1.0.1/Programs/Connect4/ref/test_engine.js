// Reference engine checks: incremental tables v a recount, win detection v the solver's,
// and exact endings v the perfect solver (score and number of moves).
//   node ref/test_engine.js [games] [endings]
'use strict';
const E = require('./engine');
const S = require('../tools/solver/solver');

let rnd = 12345;
function rand(n) { rnd = (rnd * 1103515245 + 12345) & 0x7fffffff; return rnd % n; }

function recount(e) {
  const lc = new Array(E.NLINES).fill(0), thr = new Array(49).fill(0);
  let ev = 0;
  for (let L = 0; L < E.NLINES; L++) {
    let sN = 0, hN = 0, emp = -1;
    for (let i = 0; i < 4; i++) {
      const c = E.LSTART[L] + i * E.lineStep(L);
      if (e.bd[c] === 1) sN++; else if (e.bd[c] === 2) hN++; else emp = c;
    }
    lc[L] = sN | (hN << 4);
    if (!hN && sN < 4) ev += E.W[sN];
    if (!sN && hN < 4) ev -= E.W[hN];
    if (!hN && sN === 4) ev += 9;
    if (!sN && hN === 4) ev -= 9;
    if (sN === 3 && !hN) thr[emp] += 1;
    if (hN === 3 && !sN) thr[emp] += 16;
  }
  return { lc, thr, ev };
}

function checkTables(e, where) {
  const r = recount(e);
  for (let L = 0; L < E.NLINES; L++) if (r.lc[L] !== e.lc[L]) throw new Error(where + ' lc ' + L);
  for (let c = 0; c < 49; c++) if (e.bd[c] === 0 && r.thr[c] !== e.thr[c]) throw new Error(where + ' thr ' + c + ' ' + r.thr[c] + ' ' + e.thr[c]);
  if (r.ev !== e.ev) throw new Error(where + ' ev ' + r.ev + ' ' + e.ev);
}

function tablesTest(games) {
  let moves = 0, wins = 0;
  for (let g = 0; g < games; g++) {
    const e = new E.Engine();
    const p = S.fromMoves([]);
    const snaps = [];
    for (;;) {
      const legal = [0, 1, 2, 3, 4, 5, 6].filter(c => e.canPlay(c));
      if (!legal.length) break;
      const col = legal[rand(legal.length)];
      const solverWin = S.isWinningMove(p, col);
      snaps.push(JSON.stringify([e.lc, e.thr, e.ev, e.key]));
      const four = e.make(col); S.play(p, col); moves++;
      if (!!four !== solverWin) throw new Error('win detection differs, game ' + g);
      checkTables(e, 'game ' + g + ' move ' + e.n);
      if (four) { wins++; break; }
    }
    // unmake everything and compare
    while (e.n) {
      e.unmake();
      const s = snaps.pop();
      if (s !== JSON.stringify([e.lc, e.thr, e.ev, e.key])) throw new Error('unmake differs, game ' + g + ' at ' + e.n);
    }
  }
  console.log(`tables: ${games} random games, ${moves} moves, ${wins} wins: all consistent`);
}

function endingsTest(count, empties) {
  S.ttInit();
  let ok = 0, bad = 0, nodes = 0, made = 0;
  while (made < count) {
    // a random game to `empties` empty cells with nobody having won and no immediate win
    const e = new E.Engine({ searchForced: true }); const p = S.fromMoves([]);   // (a forced block is not searched in the game: its score is not known)
    let dead = false;
    while (42 - e.n > empties) {
      const legal = [0, 1, 2, 3, 4, 5, 6].filter(c => e.canPlay(c) && !S.isWinningMove(p, c));
      if (!legal.length) { dead = true; break; }
      const col = legal[rand(legal.length)];
      e.make(col); S.play(p, col);
    }
    if (dead) continue;
    made++;
    const truth = S.solve(p, false);
    const want = truth > 0 ? 100 - S.pliesToEnd(truth, p.n) : truth < 0 ? -(100 - S.pliesToEnd(truth, p.n)) : 0;
    const r = e.think({});
    nodes += r.nodes;
    // the move chosen must keep the best score
    const an = S.analyse(p, false);
    const moveOk = an[r.move] === truth;
    if (r.score === want && r.exact && moveOk) ok++;
    else { bad++; if (bad < 10) console.log('ending mismatch', e.hist.map(c => c + 1).join(''), 'engine', r, 'want', want, 'an', an); }
  }
  console.log(`endings with ${empties} empty: ${ok} right, ${bad} wrong, ${Math.round(nodes / count)} nodes on average`);
}

const games = +process.argv[2] || 2000;
const ends = +process.argv[3] || 200;
tablesTest(games);
for (const em of [8, 10, 12, 14]) endingsTest(ends, em);
