// Demo, and the two-player options: game clock, move timer, swap rule, match.
'use strict';
const { Game, assert } = require('./lib');

function menu(g, letter, times = 1) {
  g.key('ON', 0.5);
  for (let i = 0; i < times; i++) g.key(letter, 0.3);
  g.key('EXE', 0.8);
}
function newGame(g, mode) {                  // 0 one player, 1 two, 2 demo
  g.key('ON', 0.3);
  g.waitText(/New game/, 10);
  g.key('N', 0.3); g.key('EXE', 0.3);
  g.waitText(/One player/, 10);
  const want = ['One player', 'Two players', 'Demo'][mode];
  for (let i = 0; i < 3 && !g.text().includes('>' + want); i++) g.key('DOWN', 0.3);
  if (!g.text().includes('>' + want)) throw new Error('new game menu: ' + g.text());
  g.key('EXE', 0.5);
  if (mode === 1) g.names();
  else g.m.runSeconds(1);
}

for (const model of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'lz64']) {
  const g = new Game(model).start();
  g.waitHuman(60);
  // ---- demo: the Psion plays both sides at levels 1 and 2 (fast); a key stops it
  g.poke('st_dlv1', 1); g.poke('st_dlv2', 2);
  newGame(g, 2);
  assert(g.peek('g_mode') === 2 && g.peek('g_psion') === 3, 'demo mode');
  g.waitFor(() => g.peek('g_n') >= 6, 60);
  assert(g.peek('g_n') >= 6, 'the demo plays: ' + g.peek('g_n'));
  g.key('SPACE', 2.0);
  g.waitFor(() => /New game/.test(g.text()), 20);
  assert(/New game/.test(g.text()), 'a key stops the demo: the menu ' + g.text());
  // ---- two players, game clock 1 minute: Solid's runs out
  g.key('EXE', 0.6); g.key('DOWN', 0.3); g.key('EXE', 0.5); g.names();    // (the menu: New game) -> Two players
  g.waitHuman(30);
  g.poke('st_clock', 1);
  newGame(g, 1);
  assert(g.peek('g_clk') === 0 && g.peek('g_clk', 1) >= 58 && g.peekw('g_clk', 2) === 60, 'clocks set: ' + g.bytes('g_clk', 4));
  g.m.runSeconds(30);
  const left = g.peekw('g_clk');
  assert(left >= 27 && left <= 31, 'Solid\'s clock runs: ' + left);
  assert(g.peekw('g_clk', 2) === 60, 'Hollow\'s clock stands');
  g.m.runSeconds(32);
  g.waitText(/on time/, 20);                 // (the last line names the keys for 15 s, then is put back)
  assert(/Hollow wins/.test(g.text()), 'Solid lost on time: ' + g.text());
  // ---- move timer 10 s: the disc drops by itself
  g.poke('st_clock', 0); g.poke('st_timer', 1);
  g.key('EXE', 1.5);                          // (the result: EXE, a new two-player game)
  g.waitHuman(10);
  g.m.runSeconds(2.5);
  const tl = g.panel()[1];
  assert(/:4 [78]\b/.test(tl), 'the countdown shown on line 2: ' + tl);
  g.key('ON', 1.0); g.key('ON', 1.0);         // the menu and back: the timer goes on, not afresh
  const tl2 = g.panel()[1];
  assert(/:4 [678]\b/.test(tl2), 'the countdown kept after the menu: ' + tl2);
  g.m.runSeconds(8.5);
  assert(g.peek('g_n') === 1 && g.recAt(0) === 3, 'the timer dropped in column 4: ' + g.recStr());
  // ---- swap rule: after the first disc the second player takes Solid
  g.poke('st_timer', 0); g.poke('st_swap', 1);
  newGame(g, 1);
  const p1 = g.peek('g_p1');
  g.drop(3);
  g.waitText(/Swap sides/, 5);
  g.key('EXE', 1.0);
  assert(g.peek('g_p1') === (p1 ^ 3), 'swapped: P1 ' + p1 + ' -> ' + g.peek('g_p1'));
  // ---- match, first to 3: a win for the player who has Solid
  g.poke('st_swap', 0); g.poke('st_match', 1);
  newGame(g, 1);
  g.poke('g_score', 0); g.poke('g_score', 0, 1);
  const solidP = g.peek('g_p1') === 1 ? 0 : 1;
  for (const c of [0, 1, 0, 1, 0, 1, 0]) g.drop(c);
  g.waitText(/Solid wins/, 5);
  g.m.runSeconds(0.5);
  const sc = g.bytes('g_score', 2);
  assert(sc[solidP] === 1 && sc[1 - solidP] === 0, 'match score ' + sc);
  assert(/P1 \d - P2 \d/.test(g.text()) || g.m.lines === 2, 'match line: ' + g.text());
  console.log(model, 'modes ok');
}
