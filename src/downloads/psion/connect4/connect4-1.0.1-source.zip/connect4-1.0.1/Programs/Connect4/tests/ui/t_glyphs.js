// The board on the screen against the position, after every move of random two-player games:
// two lines - the 8 glyphs' dot rows against a drawing made here from the board (2x2 cells,
// Solid a square, Hollow a diagonal, the separator); four lines - each board character against
// the glyph its two cells need, and the glyphs' dot patterns against the spec's discs.
'use strict';
const { Game, assert } = require('./lib');
const S = require('../../tools/solver/solver');
let rnd = 11; const rand = n => { rnd = (rnd * 1103515245 + 12345) & 0x7fffffff; return rnd % n; };

function expect2(bd) {           // 8 glyphs x 8 rows of 5 bits
  const g = [];
  for (let k = 0; k < 8; k++) g.push([0, 0, 0, 0, 0, 0, 0, 0]);
  for (let k = 0; k < 8; k++) if ((k & 3) === 3) for (let r = 0; r < 8; r++) g[k][r] |= 0x02;   // separator
  for (let c = 0; c < 7; c++) for (let row = 0; row < 6; row++) {
    const v = bd[c * 7 + row]; if (!v) continue;
    const k = (c >> 1) + (row < 3 ? 4 : 0), dot = (2 - (row % 3)) * 3;
    const odd = c & 1;
    const [t, b] = v === 1 ? (odd ? [3, 3] : [0x18, 0x18]) : (odd ? [2, 1] : [0x10, 0x08]);
    g[k][dot] |= t; g[k][dot + 1] |= b;
  }
  return g;
}
const SD = 0x0E, SF = 0x1F, HO = 0x11;
const GL4 = [[0, 0, 0, 0, SD, SF, SD, 0], [0, 0, 0, 0, SD, HO, SD, 0], [SD, SF, SD, 0, SD, SF, SD, 0], [SD, HO, SD, 0, SD, HO, SD, 0],
  [SD, HO, SD, 0, SD, SF, SD, 0], [SD, SF, SD, 0, SD, HO, SD, 0], [SD, SF, SD, 0, 0, 0, 0, 0], [SD, HO, SD, 0, 0, 0, 0, 0]];
const MAP4 = [' ', 0, 1, 6, 2, 5, 7, 4, 3];     // (upper*3 + lower) -> character

for (const model of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'lz64']) {
  const g = new Game(model).start();
  g.waitHuman(60);
  g.key('ON', 0.4); g.key('EXE', 0.4); g.key('DOWN', 0.3); g.key('EXE', 0.5); g.names();   // two players
  let checks = 0;
  for (let game = 0; game < 3; game++) {
    if (game) { g.key('EXE', 2); }
    const p = S.fromMoves([]);
    for (let k = 0; k < 42; k++) {
      g.waitHuman(30);
      const ok = [0, 1, 2, 3, 4, 5, 6].filter(c => S.canPlay(p, c));
      const c = ok[rand(ok.length)];
      const win = S.isWinningMove(p, c);
      g.drop(c); S.play(p, c);
      g.m.runSeconds(0.4);
      if (g.peek('g_over') && win) break;
      // the ghost disc blinks in the chosen column: compare with it off
      g.waitFor(() => { g.poke('kv_flash', 0); return true; }, 1);
      // the board from the record (e_bd itself holds the ghost disc for a moment while it is drawn)
      const bd = new Array(49).fill(0), ht = [0, 0, 0, 0, 0, 0, 0];
      g.rec().forEach((c, i) => { bd[c * 7 + ht[c]++] = (i % 2) + 1; });
      if (g.m.lines === 2) {
        // (looked at twice, a little apart, and the same both times: not half way through a glyph)
        const want = expect2(bd);
        let have = g.m.udgs();
        for (let t = 0; t < 10; t++) { g.m.runSeconds(0.012); const h = g.m.udgs(); if (JSON.stringify(h) === JSON.stringify(have)) break; have = h; }
        // the ghost may be on: allow exactly the chosen column's landing cell to differ
        const ch = g.peek('g_chosen'), land = g.bytes('e_land', 7)[ch] - ch * 7;
        let diff = 0;
        for (let i = 0; i < 8; i++) for (let r = 0; r < 8; r++) if ((want[i][r] & 0x1F) !== (have[i][r] & 0x1F)) diff++;
        if (diff) {
          const bd2 = bd.slice(); bd2[ch * 7 + land] = 3 - (g.peek('g_n') % 2 ? 1 : 2);   // the side to move's ghost
          bd2[ch * 7 + land] = (g.peek('g_n') % 2) + 1;
          const want2 = expect2(bd2);
          let diff2 = 0;
          for (let i = 0; i < 8; i++) for (let r = 0; r < 8; r++) if ((want2[i][r] & 0x1F) !== (have[i][r] & 0x1F)) diff2++;
          if (diff2) { for (let i = 0; i < 8; i++) console.log(i, want2[i].map(x=>x.toString(2).padStart(5,'0')).join(' '), '|', have[i].map(x=>x.toString(2).padStart(5,'0')).join(' ')); }
          assert(diff2 === 0, `${model} glyphs differ after ${g.recStr()}`);
        }
      } else {
        const u = g.m.udgs();
        for (let i = 0; i < 8; i++) assert(JSON.stringify(u[i]) === JSON.stringify(GL4[i]), 'glyph ' + i);
        const scr = g.m.cells();
        const ch = g.peek('g_chosen'), land = g.bytes('e_land', 7)[ch] - ch * 7;
        for (let c = 0; c < 7; c++) for (let line = 0; line < 3; line++) {
          const lo = (2 - line) * 2;
          const cellv = (r) => bd[c * 7 + r];
          let want = MAP4[cellv(lo + 1) * 3 + cellv(lo)];
          const have = scr[line * 20 + c];
          const wantCode = want === ' ' ? 32 : want;
          if (have !== wantCode) {
            // the ghost: the side to move's disc in the landing cell
            const bd2 = bd.slice(); bd2[ch * 7 + land] = (g.peek('g_n') % 2) + 1;
            const w2 = MAP4[bd2[c * 7 + lo + 1] * 3 + bd2[c * 7 + lo]];
            assert(c === ch && have === (w2 === ' ' ? 32 : w2), `${model} column ${c + 1} line ${line + 1}: ${have} want ${wantCode} after ${g.recStr()}`);
          }
        }
      }
      checks++;
      if (g.peek('g_over')) break;
    }
  }
  console.log(model, 'board checked after', checks, 'moves');
}
