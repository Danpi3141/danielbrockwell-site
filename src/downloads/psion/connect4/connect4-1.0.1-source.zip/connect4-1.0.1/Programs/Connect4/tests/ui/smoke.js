// Start C4 on a model and show the screen after each step.
'use strict';
const { Machine } = require('../../tools/emu');
const rom = process.argv[2] || '46a-lz64.rom', ram = +(process.argv[3] || 64);
const m = new Machine({ rom, ram });
m.boot();
m.insertPack(__dirname + '/../../build/game/C4.opk', 0);
m.runProc('C4', 'B');
const show = (t) => console.log('--', t, '\n' + m.screen().join('\n'));
m.runSeconds(1); show('1 s');
m.runSeconds(3); show('4 s');
for (const k of (process.argv[4] || '').split(',').filter(Boolean)) { m.press(k, 3, 10); m.runSeconds(1); show(k); }
