; =====================================================================
; Making and taking back a move (ref/engine.js make / unmake)
;
; e_bd    49 cells, col*7+row; 0 empty, 1 Solid, 2 Hollow, 3 the stop row
; e_thr   follows e_bd (so a cell's threat byte is 49,x from its board byte):
;         lines that would give Solid (low nibble) / Hollow (high) four there
; e_lc    69 lines: Solid's discs in the low nibble, Hollow's in the high
; e_land  7 columns: the cell a disc dropped there lands in (the stop cell
;         when full; its threat byte is always 0)
; e_ev    open-line score, Solid minus Hollow, 16 bits. A move only ever
;         moves it one way (Solid's up, Hollow's down), by at most 13*9, so
;         the change is summed in a byte (e_acc) and applied once.
; e_key   24 bits; e_n discs on the board; e_won the side that made four
; One loop serves both sides: for Hollow each line's count byte is read
; with its nibbles swapped, so the mover's count is always the low one;
; e_unit / e_ounit are the mover's / the other side's 1 in a count byte.
; =====================================================================

; set up for the side B (0 Solid, 1 Hollow): e_sf, e_unit, e_ounit, the
; branch over the nibble swap in both loops (BRA for Solid, BRN for
; Hollow: the code is in RAM), and the key
e_side: stab e_sf
        ldaa #$01
        ldab #$10
        tst  e_sf
        beq  .s
        ldaa #$10
        ldab #$01
.s:     staa e_unit
        stab e_ounit
        ldaa #$20               ; BRA
        adda e_sf               ; BRN ($21) for Hollow
        staa e_make.sw
        staa e_unmake.sw
        ldab e_cell             ; the key: the cell's bytes, rotated for Hollow
        subb e_col
        aslb                    ; t = 2 * (col*6 + row)
        addb #$CD               ; (ref/engine.js cellBytes: until 19 Nov an 84-byte table)
        ldaa #$79
        mul                     ; B = y = lo((t + $CD) * $79)
        stab e_ki
        tba
        mul                     ; D = y * y
        eorb e_ki
        std  e_kb               ; b0 = hi(y*y), b1 = lo(y*y) ^ y
        ldab e_ki
        ldaa #$95
        mul
        staa e_kb+2             ; b2 = hi(y * $95)
        tst  e_sf
        bne  .h
        ldaa e_kb
        eora e_key
        staa e_key
        ldaa e_kb+1
        eora e_key+1
        staa e_key+1
        ldaa e_kb+2
        eora e_key+2
        staa e_key+2
        rts
.h:     ldaa e_kb+1
        eora e_key
        staa e_key
        ldaa e_kb+2
        eora e_key+1
        staa e_key+1
        ldaa e_kb
        eora e_key+2
        staa e_key+2
        rts

; e_make: A = column (must have room). The side to move plays it.
; Returns C set if it made four.
e_make: staa e_col
        tab
        ldx  #e_land
        abx
        ldab 0,x                ; the landing cell
        inc  0,x
        stab e_cell
        ldx  #e_bd
        abx
        stx  e_cx
        clr  e_four
        clr  e_acc
        ldab e_n
        inc  e_n
        andb #1
        incb
        stab 0,x                ; the disc
        decb
        jsr  e_side
        jsr  e_cl               ; X -> the cell's lines, e_lend just after them
.ls:    cpx  e_lend
        beq  .end
        ldab 0,x
        stx  e_li
        ldx  #e_lc
        abx
        ldaa 0,x
        tab
        addb e_unit             ; the mover's count + 1
        stab 0,x
.sw:    bra  .ns                ; (BRN for Hollow: the nibbles swapped, so A
        tab                     ;  has the mover's count low, the other's high)
        lsrb
        lsrb
        lsrb
        lsrb
        asla
        asla
        asla
        asla
        aba
.ns:    bita #$F0
        bne  .dead
        tab                     ; open for the mover: A = own (0..3)
        ldx  #e_dw
        abx
        ldab 0,x                ; + W[own+1] - W[own]
        addb e_acc
        stab e_acc
        cmpa #2
        blo  .nx
        bne  .four
        ldx  e_li
        ldab 0,x
        jsr  e_empty            ; X -> the line's empty cell
        ldaa 49,x               ; a new threat there for the mover
        adda e_unit
        staa 49,x
        bra  .nx
.four:  inc  e_four
        bra  .nx
.dead:  bita #$0F               ; the mover already in it: dead before
        bne  .nx
        lsra                    ; the line dies: the other side's score goes
        lsra
        lsra
        lsra
        tab
        ldx  #e_w
        abx
        ldab 0,x
        addb e_acc
        stab e_acc
        cmpa #3
        bne  .nx
        ldx  e_cx               ; it had three: its threat (here) goes
        ldaa 49,x
        suba e_ounit
        staa 49,x
.nx:    ldx  e_li
        inx
        bra  .ls
.end:   jsr  e_evadd            ; Solid's move raises e_ev, Hollow's lowers it
        ldaa e_four
        beq  .no
        ldab e_sf
        incb
        stab e_won
        sec
        rts
.no:    clc
        rts

; e_ev += e_acc (Solid) or -= (Hollow); for unmake the other way (e_sf flipped)
e_evadd:
        ldab e_acc
        clra
        tst  e_sf
        bne  .h
        addd e_ev
        std  e_ev
        rts
.h:     std  e_tmp
        ldd  e_ev
        subd e_tmp
        std  e_ev
        rts

; X -> the list of lines through e_cell, e_lend = just after it (until 19 Nov
; the lists ended with 255: 42 bytes)
e_cl:   ldab e_cell
        ldx  #e_cloff
        abx
        ldaa 1,x                ; it runs to the next cell's list
        suba 0,x
        ldab 0,x
        ldx  #e_clist
        psha
        ldaa e_cell
        cmpa #E_CLT
        blo  .lo
        ldx  #e_clist+256
.lo:    abx
        pulb
        pshx
        abx
        stx  e_lend
        pulx
        rts

; B = a line: B = its first cell, e_stp = its step (until 19 Nov a 69-byte
; table). Lines 0-20 go up (step 1), 21-44 across (7), 45-56 up-right (8),
; 57-68 down-right (6, from rows 3-5); within a group i: up and the
; diagonals start at i + 4 * (i / 3) (+ 3 for down-right), across at
; column i mod 4, row i / 4. (Also called by OV_END.)
e_line: ldaa #1
        cmpb #21
        blo  .g
        subb #21
        ldaa #7
        cmpb #24
        blo  .h
        subb #24
        ldaa #8
        cmpb #12
        blo  .g
        subb #12
        ldaa #6
        staa e_stp
        ldaa #3
        bra  .g2
.h:     staa e_stp              ; across: column i mod 4, row i / 4
        tba
        anda #3
        lsrb
        lsrb
        pshb
        ldab #7
        mul
        pula
        aba
        tab
        rts
.g:     staa e_stp
        clra
.g2:    psha
        pshb
        ldaa #86                ; i / 3 = (i * 86) / 256 for i up to 20
        mul
        asla
        asla
        pulb
        aba
        pulb
        aba
        tab
        rts

; X -> the board byte of the empty cell of line B (which has exactly one)
e_empty:
        bsr  e_line
        ldx  #e_bd
        abx
.f:     tst  0,x
        beq  .r
        ldab e_stp
        abx
        bra  .f
.r:     rts

; e_unmake: A = column. Takes back the last disc in it.
e_unmake:
        staa e_col
        tab
        ldx  #e_land
        abx
        dec  0,x
        ldab 0,x
        stab e_cell
        ldx  #e_bd
        abx
        stx  e_cx
        clr  e_won
        clr  e_acc
        dec  e_n
        ldab 0,x                ; the disc: 1 Solid, 2 Hollow
        decb
        jsr  e_side
        jsr  e_cl
.ls:    cpx  e_lend
        beq  .end
        ldab 0,x
        stx  e_li
        ldx  #e_lc
        abx
        ldaa 0,x
        suba e_unit             ; the mover's count - 1
        staa 0,x
.sw:    bra  .ns                ; (BRN for Hollow)
        tab
        lsrb
        lsrb
        lsrb
        lsrb
        asla
        asla
        asla
        asla
        aba
.ns:    bita #$F0
        bne  .dead
        tab
        ldx  #e_dw
        abx
        ldab 0,x
        addb e_acc
        stab e_acc
        cmpa #2
        bne  .nx
        ldx  e_li
        ldab 0,x
        jsr  e_empty            ; (the cell still holds the disc)
        ldaa 49,x
        suba e_unit
        staa 49,x
        bra  .nx
.dead:  bita #$0F
        bne  .nx
        lsra
        lsra
        lsra
        lsra
        tab
        ldx  #e_w
        abx
        ldab 0,x
        addb e_acc
        stab e_acc
        cmpa #3
        bne  .nx
        ldx  e_cx
        ldaa 49,x
        adda e_ounit
        staa 49,x
.nx:    ldx  e_li
        inx
        bra  .ls
.end:   ldaa e_sf               ; undo: the other way
        eora #1
        staa e_sf
        jsr  e_evadd
        ldx  e_cx
        clr  0,x
        rts
