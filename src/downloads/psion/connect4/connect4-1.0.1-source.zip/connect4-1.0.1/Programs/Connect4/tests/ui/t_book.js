// The Psion's book moves in the game against the PC's book walk, as first and second player,
// against random replies (level 8: the book is used to its end), and the value it puts in the
// history; then each of your 7 first moves with the Psion second (the book's draws and losses
// are 4-bit codes 8-15 since 19 Nov 2026: tools/build.py BOOK_HI).
'use strict';
const { Game, assert } = require('./lib');
const W = require('../../tools/book/walk');
const model = process.argv[2] || 'lz64', games = +(process.argv[3] || 6);
let rnd = 99; const rand = n => { rnd = (rnd * 1103515245 + 12345) & 0x7fffffff; return rnd % n; };
let checked = 0, values = 0;
const hvAt = (g, p) => (g.bytes('g_hv', 11)[p >> 2] >> ((p & 3) * 2)) & 3;
const valOf = c => (c < 8 ? 1 : c < 15 ? 2 : 3);
for (let gi = 0; gi < games; gi++) {
  const g = new Game(model).start();
  g.waitHuman(60);
  g.poke('st_level', 8);
  g.poke('st_you', gi % 2);                 // you first / second
  g.keys(['ON', 'EXE', 'EXE'], 1.5);        // New game, One player
  const psionFirst = g.peek('g_psion') === 1;
  for (let ply = 0; ply < 16 && !g.peek('g_over'); ply++) {
    const n = g.peek('g_n');
    const rec = g.rec();
    const psionToMove = (n % 2 === 0) === psionFirst;
    if (psionToMove) {
      const code = W.walk(rec, psionFirst);
      if (!code) break;                     // out of the book: the search (another test)
      g.waitFor(() => g.peek('g_n') === n + 1, 60);
      const got = g.recAt(n);
      if (g.peek('g_over')) { assert(got === W.codeCol(code, rec, psionFirst), 'book: winning move'); checked++; break; }
      const want = W.codeCol(code, rec, psionFirst);
      assert(got === want, `book: after ${rec.map(c => c + 1).join('')} the Psion played ${got + 1}, book ${want + 1}`);
      assert(hvAt(g, n) === valOf(code), `book: the history at ply ${n} is ${hvAt(g, n)}, the book's value ${valOf(code)}`);
      checked++; values++;
    } else {
      g.waitFor(() => g.peek('g_over') || g.humanTurn(), 60, 0.1);
      if (g.peek('g_over')) break;
      let c; do { c = rand(7); } while (g.bytes('e_bd', 1, c * 7 + 5)[0] !== 0);
      g.waitFor(() => g.peek('g_over') || g.humanTurn(), 60, 0.1);
      if (g.peek('g_over')) break;
      g.key('UVWOPQI'[c], 0.1);
      g.m.press('EXE', 3, 0);
      g.waitFor(() => g.peek('g_n') === n + 1, 5, 0.02);
      if (g.peek('g_over')) break;
    }
  }
  console.log(model, 'game', gi, psionFirst ? 'Psion first' : 'Psion second', g.recStr());
}
// your first move in each column, the Psion second: its reply and value (column 4 a loss for it,
// 3 and 5 draws, the rest wins)
const want = [];
for (let c = 0; c < 7; c++) {
  const g = new Game(model).start();
  g.waitHuman(60);
  g.poke('st_level', 8); g.poke('st_you', 0);
  g.keys(['ON', 'EXE', 'EXE'], 1.5);
  g.waitHuman(30);
  g.key('UVWOPQI'[c], 0.1); g.key('EXE', 0.3);
  g.waitFor(() => g.peek('g_n') === 2, 60);
  const code = W.walk([c], false);
  assert(g.recAt(1) === W.codeCol(code, [c], false) && hvAt(g, 1) === valOf(code), `first move col ${c + 1}: reply ${g.recAt(1) + 1}, value ${hvAt(g, 1)}; the book ${W.codeCol(code, [c], false) + 1}, ${valOf(code)}`);
  want.push(hvAt(g, 1));
}
assert(want.join('') === '1123211', 'values for the Psion after each first move: ' + want.join(''));
console.log('book moves checked:', checked, '(values too), and the 7 first moves: values', want.join(''));
