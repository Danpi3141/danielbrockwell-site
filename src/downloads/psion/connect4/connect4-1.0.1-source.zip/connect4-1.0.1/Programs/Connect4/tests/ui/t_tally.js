// The tally (kept in A:C4TAL, not in RAM) and resuming a finished game:
//  - two lost games at level 2: the four-line result shows L1, then L2;
//  - leave on the result screen and come back: the result again, not counted again;
//  - a resigned game left and resumed is still over ("You resigned").
//   node tests/ui/t_tally.js [model] (default lz64: the tally line is on four-line screens)
'use strict';
const { Game, assert } = require('./lib');
const model = process.argv[2] || 'lz64';
const g = new Game(model).start();
g.waitHuman(60);
g.poke('st_level', 2); g.poke('st_you', 0); g.poke('st_pace', 1);
g.keys(['ON', 'EXE', 'EXE'], 1.5);                        // New game, One player
const tallyLine = () => g.panel()[2].trim();
for (let game = 1; game <= 2; game++) {
  const ps = g.peek('g_psion');
  for (let k = 0; k < 40 && !g.peek('g_over'); k++) {      // always the leftmost column with room
    g.waitFor(() => g.peek('g_over') || (g.humanTurn() && (g.peek('g_n') % 2) + 1 !== ps), 120, 0.1);
    if (g.peek('g_over')) break;
    const n = g.peek('g_n'); let c = 0; while (g.bytes('e_bd', 1, c * 7 + 5)[0]) c++;
    g.key('UVWOPQI'[c], 0.1); g.key('EXE', 0.3); g.waitFor(() => g.peek('g_n') > n, 5, 0.02);
  }
  assert(g.waitFor(() => g.peek('g_over') === 2, 20), 'game counted');
  g.m.runSeconds(1);
  assert(/Psion wins/.test(g.panel()[0]), 'the Psion won: ' + g.panel().join('|'));
  assert(tallyLine() === `W0 D0 L${game}`, `tally after game ${game}: "${tallyLine()}"`);
  if (game === 1) { g.key('EXE', 2); g.waitHuman(60); }
}
g.keys(['ON', 'L', 'L', 'EXE'], 2);                       // leave on the result screen
g.start();
assert(g.waitFor(() => /Psion wins/.test(g.panel()[0]), 10), 'resumed on the result: ' + g.panel().join('|'));
g.m.runSeconds(1);
assert(tallyLine() === 'W0 D0 L2' && g.peek('g_over') === 2, `not counted again: "${tallyLine()}"`);
// a resignation survives leaving and coming back
g.key('EXE', 2);
g.waitHuman(60);
g.keys(['ON', 'R', 'R', 'EXE'], 1);                       // (R: Review game, then Resign)
g.waitText(/You resigned/, 5);
g.waitFor(() => tallyLine() === 'W0 D0 L3', 5);           // (OV_END draws it just after)
assert(tallyLine() === 'W0 D0 L3', `resigned: "${tallyLine()}"`);
g.keys(['ON', 'L', 'L', 'EXE'], 2);
g.start();
assert(g.waitFor(() => /You resigned/.test(g.text()), 10), 'resumed resignation: ' + g.text());
g.m.runSeconds(1);
assert(tallyLine() === 'W0 D0 L3' && g.peek('g_over') === 2, `resignation not counted again: "${tallyLine()}"`);
console.log(`${model} tally ok: L1, L2, kept on resume; resignation L3 kept on resume`);
