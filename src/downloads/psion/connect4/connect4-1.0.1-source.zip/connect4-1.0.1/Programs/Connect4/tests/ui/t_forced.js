// The forced block (19 Nov): one player at level 8, you first, your moves making a threat where
// they can (else random). Whenever the Psion has exactly one of your wins to stop (and none of its
// own), it must play the block without a search: at Pace Fast at once; at Pace Natural after the
// book's pause (about 1.5 s), which a key cuts short.
//   node tests/ui/t_forced.js [models...] (default cm lz64)
'use strict';
const { Game, assert } = require('./lib');
const { Engine } = require('../../ref/engine');
const models = process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'lz64'];
let total = 0;

for (const model of models) {
  let rnd = 3; const rand = n => { rnd = (rnd * 1103515245 + 12345) & 0x7fffffff; return (rnd >> 8) % n; };
  const g = new Game(model).start(); g.waitHuman(60);
  g.poke('st_level', 8); g.poke('st_you', 0); g.poke('st_coach', 0);
  g.keys(['ON', 'N', 'EXE', 'EXE'], 1.0);
  const seen = { fast: [], natural: [], key: [] };
  const want = () => seen.fast.length < 2 ? 'fast' : seen.natural.length < 2 ? 'natural' : seen.key.length < 2 ? 'key' : null;
  for (let gi = 0; gi < 30 && want(); gi++) {
    while (!g.peek('g_over') && want()) {
      const mode = want();
      g.poke('st_pace', mode === 'fast' ? 1 : 0);
      g.waitFor(() => g.peek('g_over') || g.humanTurn(), 200, 0.05);
      if (g.peek('g_over')) break;
      const e = new Engine(); for (const c of g.rec()) e.make(c);
      const me = e.side(), legal = [0, 1, 2, 3, 4, 5, 6].filter(c => e.canPlay(c));
      const thr = legal.filter(c => { e.make(c); const t = e.playable(me); e.unmake(); return t && !(t & (t - 1)) && !e.playable(3 - me); });
      const c = thr.length ? thr[rand(thr.length)] : legal[rand(legal.length)];
      const n = g.peek('g_n');
      g.key('UVWOPQI'[c], 0.05); g.key('EXE', 0.05);
      g.waitFor(() => g.peek('g_n') > n || g.peek('g_over'), 5, 0.02);
      if (g.peek('g_over')) break;
      e.make(c);
      const opp = e.playable(me), forced = !e.playable(3 - me) && opp && !(opp & (opp - 1));
      let t = 0, pressed = false;
      while (g.peek('g_n') === n + 1 && !g.peek('g_over') && t < 200) {
        g.m.runSeconds(0.05); t += 0.05;
        if (forced && mode === 'key' && !pressed && t >= 0.5) { g.m.press('SPACE', 3, 3); pressed = true; }
      }
      if (!forced) continue;
      const got = g.rec()[n + 1], blk = 31 - Math.clz32(opp);
      assert(got === blk, `${model}: move ${n + 2}: the block is col ${blk + 1}, played ${got + 1}`);
      seen[mode].push(t);
      console.log(`${model}: ${mode}: move ${n + 2}, col ${blk + 1} blocked after ${t.toFixed(2)} s`);
      if (mode === 'fast') assert(t < 0.5, `${model}: Fast: at once (${t.toFixed(2)} s)`);
      if (mode === 'natural') assert(t >= 1.4 && t < 2.2, `${model}: Natural: the book's pause (${t.toFixed(2)} s)`);
      if (mode === 'key') assert(t < 1.0, `${model}: a key cuts the pause short (${t.toFixed(2)} s)`);
    }
    g.waitFor(() => g.peek('g_over') === 2, 30); g.m.runSeconds(1);
    g.key('EXE', 2);
  }
  assert(seen.fast.length && seen.natural.length && seen.key.length, `${model}: each pace seen: ${JSON.stringify(seen)}`);
  total += seen.fast.length + seen.natural.length + seen.key.length;
  // levels 1-2 (depth only, no time to search): at Pace Natural the pause too (19 Nov); Fast at once
  if (g.peek('g_over')) { g.waitFor(() => g.peek('g_over') === 2, 30); g.m.runSeconds(1); g.key('EXE', 2); }
  for (const [lv, pace] of [[1, 0], [2, 0], [1, 1], [2, 1]]) {
    g.poke('st_level', lv);
    let met = 0;
    for (let i = 0; i < 12 && met < 2; i++) {
      g.poke('st_pace', pace);
      g.waitFor(() => g.peek('g_over') || g.humanTurn(), 200, 0.05);
      if (g.peek('g_over')) { g.waitFor(() => g.peek('g_over') === 2, 30); g.m.runSeconds(1); g.key('EXE', 2); continue; }
      const e = new Engine(); for (const c of g.rec()) e.make(c);
      const legal = [0, 1, 2, 3, 4, 5, 6].filter(c => e.canPlay(c)), c = legal[rand(legal.length)];
      const n = g.peek('g_n');
      g.key('UVWOPQI'[c], 0.05); g.key('EXE', 0.05);
      g.waitFor(() => g.peek('g_n') > n || g.peek('g_over'), 5, 0.02);
      if (g.peek('g_over')) continue;
      let t = 0;
      while (g.peek('g_n') === n + 1 && !g.peek('g_over') && t < 30) { g.m.runSeconds(0.05); t += 0.05; }
      if (g.peek('g_n') < n + 2) continue;
      // (t includes your disc falling: up to 0.3 s more from the top row)
      if (pace === 0) assert(t >= 1.4 && t < 2.5, `${model}: level ${lv}, Natural: the pause (${t.toFixed(2)} s)`);
      else assert(t < 1.0, `${model}: level ${lv}, Fast: at once (${t.toFixed(2)} s)`);
      console.log(`${model}: level ${lv}, ${pace ? 'Fast' : 'Natural'}: replied after ${t.toFixed(2)} s`);
      met++;
    }
    assert(met === 2, `${model}: level ${lv} pace ${pace}: ${met} replies timed`);
  }
}
console.log(`forced ok: ${total} blocks`);
