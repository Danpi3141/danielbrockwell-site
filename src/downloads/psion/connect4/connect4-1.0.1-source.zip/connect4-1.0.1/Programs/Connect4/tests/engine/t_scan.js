'use strict';
const { Harness } = require('./harness');
const E = require('../../ref/engine');
const h = new Harness({ build: false });
const [seq, noise, seed] = [process.argv[2], +process.argv[3], +process.argv[4]];
const e = new E.Engine(); h.call('eng_reset');
for (const ch of seq) { e.make(+ch - 1); h.call('e_make', +ch - 1); }
for (let lim = 2; lim <= 1000; lim++) {
  const o = { nodes: lim, depth: 0, noise, seed };
  const w = e.think(o), g = h.think(o);
  if (w.move !== g.move || w.score !== g.score || w.depth !== g.depth) {
    console.log('first difference at limit', lim, 'ref', JSON.stringify(w), 'asm', JSON.stringify(g)); break;
  }
}
