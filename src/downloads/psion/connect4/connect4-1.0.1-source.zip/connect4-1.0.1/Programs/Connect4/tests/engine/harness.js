'use strict';
// Runs the assembled engine (tests/engine/out/etest.bin) on the emulated HD6303 of a booted
// Organiser and exposes its routines to tests. The image is placed at BASE with its fix-ups applied.
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const { Machine } = require('../../tools/emu.js');

const BASE = 0x3000, TRAMP = 0x5FE0, SENT = TRAMP + 3;
const ABS = new Set(['E_FR', 'E_TT', 'E_KIL', 'E_SCRATCH_END']);

function build() {
  execSync('python "' + path.join(__dirname, 'build_test.py') + '"', { stdio: 'pipe' });
}

class Harness {
  constructor(opts = {}) {
    if (opts.build !== false) build();
    const out = path.join(__dirname, 'out');
    const img = fs.readFileSync(path.join(out, 'etest.bin'));
    const meta = JSON.parse(fs.readFileSync(path.join(out, 'etest.json'), 'utf8'));
    this.sym = meta.sym;
    this.seg = meta.seg;
    const bytes = Uint8Array.from(img);
    for (const f of meta.fix) {
      const v = ((bytes[f] << 8) | bytes[f + 1]) + BASE;
      bytes[f] = (v >> 8) & 255; bytes[f + 1] = v & 255;
    }
    this.size = bytes.length;
    if (BASE + this.size > TRAMP) throw new Error('test image too big: ' + this.size);
    const m = this.m = new Machine(opts.rom ? { rom: opts.rom, ram: opts.ram } : {});
    m.boot();
    this.stack = m.dbg.sp() - 8;
    m.write(BASE, Array.from(bytes));
    m.write(TRAMP, [0x0F, 0xAD, 0x00, 0x01, 0x20, 0xFE]);   // sei, jsr 0,x, nop, bra *
    this.ints = !!opts.ints;
    this.call('eng_reset');
  }
  a(name) {
    const v = this.sym[name];
    if (v === undefined) throw new Error('no symbol ' + name);
    return this.seg[name] === 'abs' ? v : v + BASE;
  }
  peek(name, off = 0) { return this.m.peek(this.a(name) + off); }
  peekw(name, off = 0) { return this.m.peekw(this.a(name) + off); }
  poke(name, v, off = 0) { this.m.poke(this.a(name) + off, v); }
  pokew(name, v, off = 0) { this.m.pokew(this.a(name) + off, v); }
  bytes(name, n, off = 0) { return this.m.read(this.a(name) + off, n); }
  sb(name, off = 0) { const v = this.peek(name, off); return v > 127 ? v - 256 : v; }
  sw(name, off = 0) { const v = this.peekw(name, off); return v & 0x8000 ? v - 0x10000 : v; }

  // call a routine: returns {a, b, x, c, cycles}
  call(name, a = 0, b = 0, maxCycles = 921600 * 3600) {
    const m = this.m, d = m.dbg;
    m.poke(0x7D, 255);                         // keep auto switch-off away
    m.poke(TRAMP, this.ints ? 0x0E : 0x0F);
    d.setSP(this.stack);
    d.setA(a); d.setB(b);
    d.setX(typeof name === 'number' ? name : this.a(name));
    d.setPC(TRAMP);
    d.wake();
    const c0 = m.cycles();
    const hit = m.runTo(SENT, maxCycles);
    if (hit !== SENT) throw new Error(`${name} did not return (pc=${d.pc().toString(16)}, sp=${d.sp().toString(16)})`);
    const res = { a: d.a(), b: d.b(), x: d.x(), c: d.p() & 1, sp: d.sp(), cycles: m.cycles() - c0 };
    this.m.cpu.execute(1);
    return res;
  }
  // the engine's state as the reference engine holds it
  state() {
    const key = this.bytes('e_key', 3);
    return {
      bd: this.bytes('e_bd', 49), thr: this.bytes('e_thr', 49), lc: this.bytes('e_lc', 69),
      land: this.bytes('e_land', 7), ev: this.sw('e_ev'), key: key[0] | key[1] << 8 | key[2] << 16,
      n: this.peek('e_n'), won: this.peek('e_won'),
    };
  }
  think(o) {
    this.pokew('e_limit', o.nodes || 0);
    this.poke('e_fixd', o.depth || 0);
    this.poke('e_noise', o.noise || 0);
    this.poke('e_nseed', (o.seed || 0) & 255);
    this.pokew('e_poll', o.poll ? this.a(o.poll) : 0);
    const r = this.call('e_think');
    const mv = this.peek('e_move');
    return { move: mv === 7 ? -1 : mv, score: this.sb('e_score'), depth: this.peek('e_depth'),
      nodes: this.peekw('e_nodes'), exact: !!this.peek('e_exact'), cycles: r.cycles };
  }
}

module.exports = { Harness, BASE };
