// The menu's features on both displays: take back, hint, coach, move list, settings (kept
// across leaving), export and import, set-up, resign, help.
'use strict';
const { Game, assert } = require('./lib');
const E = require('../../ref/engine');

function menu(g, letter, times = 1) {        // open the menu and pick an item by its letter
  g.key('ON', 0.5);
  for (let i = 0; i < times; i++) g.key(letter, 0.3);
  g.key('EXE', 0.8);
}

for (const model of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'lz64']) {
  const g = new Game(model).start();
  g.waitHuman(60);
  g.poke('st_pace', 1);
  g.poke('st_level', 3);
  g.poke('st_you', 0);                       // you first
  menu(g, 'N'); g.key('EXE', 1.5);           // new game, one player
  assert(g.peek('g_psion') === 2, 'the Psion second');
  // ---- play two moves, then take back
  g.drop(3); g.waitHuman(); g.drop(2); g.waitHuman();
  assert(g.peek('g_n') === 4, 'four discs');
  g.key('DEL', 1.0);
  assert(g.peek('g_n') === 2, 'take back: two discs gone (' + g.peek('g_n') + ')');
  // ---- hint: the chosen column is the 1,000-position search's move
  const e = new E.Engine(); for (const c of g.rec()) e.make(c);
  const want = e.think({ nodes: 600 }).move;
  g.key('SPACE', 0.5);
  g.waitFor(() => !/depth/.test(g.text()), 30);
  g.m.runSeconds(0.5);
  assert(g.peek('g_chosen') === want, `hint: ${g.peek('g_chosen') + 1}, reference ${want + 1}`);
  // ---- move list
  g.key('UP', 0.6);
  const lst = g.panel().join('|');
  assert(/1\.4\d/.test(lst), 'move list shows move 1: ' + lst);
  g.key('EXE', 0.6);
  // ---- coach on request
  g.key('MODE', 1.0);
  const co = g.panel().join('|');
  assert(/Coach: (win|draw|lost)|Can't tell/.test(co), 'coach: ' + co);
  g.key('EXE', 0.6);                         // (shown until a key)
  // ---- settings: level 3 -> 4 through the menu's Level item; kept after leaving
  menu(g, 'L');
  g.key('RIGHT', 0.4);
  assert(g.peek('st_level') === 4, 'level 4: ' + g.peek('st_level'));
  g.key('ON', 1.0);
  // ---- export
  menu(g, 'E');
  assert(/Saved C4G1/.test(g.text()), 'export: ' + g.text());
  g.key('EXE', 0.6);
  const rec = g.recStr();
  // ---- leave, come back: settings and game kept
  menu(g, 'L', 2);
  g.start(); g.waitHuman(60);
  assert(g.peek('st_level') === 4 && g.recStr() === rec, 'resumed: level ' + g.peek('st_level') + ' record ' + g.recStr());
  // ---- a new game, then import the exported one
  menu(g, 'N'); g.key('EXE', 1.5);
  g.waitHuman(60);
  menu(g, 'I');                              // Import game: the list, the first file
  g.key('EXE', 1.5);
  assert(g.recStr() === rec, 'imported ' + g.recStr() + ' want ' + rec);
  // ---- set up: column 7 gets S, then H; EXE plays on from there
  g.waitHuman(60);
  const land = g.bytes('e_land', 7)[6] - 42;     // column 7's next free row
  menu(g, 'S', 2);                           // (S: Swap sides, then Set up)
  for (let i = 0; i < 4; i++) g.key('RIGHT', 0.2);   // column 4 -> 7 (starts at 4)
  g.key('S', 0.3); g.key('H', 0.3);
  g.key('EXE', 1.5);
  const b = g.board();
  assert(b[5 - land][6] === 'S' && b[4 - land][6] === 'H', 'set up column 7 from row ' + land + ': ' + b.join('/'));
  // ---- a refused set-up: two Solid discs more
  g.waitHuman(60);
  menu(g, 'S', 2);
  g.key('S', 0.2); g.key('S', 0.2); g.key('EXE', 0.8);
  assert(/Not possible/.test(g.text()), 'refused set-up: ' + g.text());
  g.key('EXE', 0.5); g.key('ON', 1.5);       // (leave it as it was)
  // ---- help
  menu(g, 'H', 2);                           // (H: Hint, then Help)
  assert(/Drop discs/.test(g.text()), 'help: ' + g.text());
  g.key('ON', 0.8);
  // ---- resign
  menu(g, 'R', 2);                           // (R: Review game, then Resign)
  g.waitText(/You resigned/, 5);
  assert(/Psion wins/.test(g.text()), 'resign: ' + g.text());
  console.log(model, 'features ok');
}
