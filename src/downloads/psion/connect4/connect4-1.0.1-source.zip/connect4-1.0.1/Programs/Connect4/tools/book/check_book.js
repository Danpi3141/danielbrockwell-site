// Checks the book's verdicts against John Tromp's 8-ply database (spec: "Every 8-disc position
// on the way checked against Tromp's database"):
//  - Psion first: entries with 8 discs on the board (the Psion, x, to move): verdict v Tromp.
//  - Psion second: the position after the Psion's book move at 7 discs (8 discs, the opponent,
//    x, to move): Tromp's result for x must be the opposite of the Psion's verdict.
// Positions Tromp leaves out (a forced next move, or a four made) are skipped.
'use strict';
const fs = require('fs'), path = require('path');
const S = require('../solver/solver');
const T = require('../solver/tromp');
const db = new Map(T.load().map(e => [e.key, e.res]));
const keyOf = p => (p.cl + p.ml) + (p.ch + p.mh) * 268435456;
const verdict = code => (code <= 7 ? 1 : code <= 14 ? 0 : -1);   // for the Psion
const DATA = path.join(__dirname, '..', '..', 'data');
const allLines = () => fs.readdirSync(DATA).filter(f => /^book_nodes.*\.jsonl$/.test(f))
  .flatMap(f => fs.readFileSync(path.join(DATA, f), 'utf8').split('\n'));
let checked = 0, bad = 0, skipped = 0;
for (const line of allLines()) {
  if (!line.trim()) continue;
  const r = JSON.parse(line);
  const p = S.fromMoves(r.seq);
  if (r.t === 'F' && p.n === 8) {
    const res = db.get(keyOf(p));
    if (res === undefined) { skipped++; continue; }
    checked++;
    if (res !== verdict(r.code)) { bad++; if (bad < 10) console.log('F differs', r.seq.map(c => c + 1).join(''), 'book', verdict(r.code), 'Tromp', res); }
  } else if (r.t === 'S' && p.n === 7) {
    if (S.isWinningMove(p, r.move)) { skipped++; continue; }
    S.play(p, r.move);
    const res = db.get(keyOf(p));
    if (res === undefined) { skipped++; continue; }
    checked++;
    if (res !== -verdict(r.code)) { bad++; if (bad < 10) console.log('S differs', r.seq.map(c => c + 1).join(''), '+', r.move + 1, 'book', verdict(r.code), 'Tromp', res); }
  }
}
console.log(`8-disc positions checked against Tromp's database: ${checked}, differing ${bad}, skipped ${skipped} (not in the database)`);

// Consistency down the tree: an entry's verdict must be the worst, over the opponent's replies
// to the Psion's book move, of the next entries' verdicts (a reply that makes four: a loss;
// a book move that makes four: a win). Entries at the last depth have no children.
{
  const recs = new Map();
  for (const line of allLines()) {
    if (!line.trim()) continue;
    const r = JSON.parse(line);
    recs.set(r.t + r.opp.join(','), r);
  }
  let ok = 0, wrong = 0;
  for (const r of recs.values()) {
    if (r.opp.length >= 5) continue;                    // the last depth
    const p = S.fromMoves(r.seq);
    if (S.isWinningMove(p, r.move)) { if (verdict(r.code) === 1) ok++; else wrong++; continue; }
    S.play(p, r.move);
    let worst = 1, missing = false;
    for (let c = 0; c < 7; c++) {
      if (!S.canPlay(p, c)) continue;
      if (S.isWinningMove(p, c)) { worst = -1; continue; }
      const ch = recs.get(r.t + r.opp.concat([c]).join(','));
      if (!ch) { missing = true; continue; }
      worst = Math.min(worst, verdict(ch.code));
    }
    if (missing) continue;
    if (worst === verdict(r.code)) ok++;
    else { wrong++; if (wrong < 10) console.log('inconsistent', r.t, r.seq.map(c => c + 1).join(''), 'verdict', verdict(r.code), 'replies give', worst); }
  }
  console.log(`tree consistency: ${ok} entries agree with their replies, ${wrong} do not`);
}
