// UI test helpers: the game on an emulated Organiser (tools/emu.js), its variables read from RAM
// through the build's symbol table (the kernel is found by its "C4K1" tag).
'use strict';
const fs = require('fs'), path = require('path');
const { Machine } = require('../../tools/emu');

const ROOT = path.join(__dirname, '..', '..');
const MODELS = {
  cm: { rom: '33-cm.rom', ram: 8 }, cm24: { rom: '24-cm.rom', ram: 8 }, cm26: { rom: '26-cm.rom', ram: 8 },
  xp: { rom: '31-xp.rom', ram: 16 }, xp24: { rom: '24-xp.rom', ram: 16 }, xp26: { rom: '26-xp.rom', ram: 16 },
  la: { rom: '36-la.rom', ram: 32 }, lz: { rom: '46-lz.rom', ram: 32 }, lz64: { rom: '46a-lz64.rom', ram: 64 },
};

// every Organiser ROM the emulator has (not the POS terminals), and its RAM in K
const ROMS = {
  '24-cm.rom': 8, '26-cm.rom': 8, '33-cm.rom': 8, '33-cmf.rom': 8, '36-cmf.rom': 8,
  '24-xp.rom': 16, '26-xp.rom': 16, '31-xp.rom': 16,
  '30-lahp.rom': 32, '33-la.rom': 32, '34-lag.rom': 32, '36-la.rom': 32, '36-laf.rom': 32, '36-lag.rom': 32, '37-lam.rom': 32,
  '42-lz.rom': 32, '44-lz.rom': 32, '45-lz.rom': 32, '45-lzi.rom': 32, '45-lzs.rom': 32, '46-lz.rom': 32, '46-lzi.rom': 32,
  '43-lz64.rom': 64, '44-lz64.rom': 64, '45-lz64.rom': 64, '46a-lz64.rom': 64, '46b-lz64.rom': 64, '46-lz64i.rom': 64, '46-lz64s.rom': 64,
};

class Game {
  constructor(model, opts = {}) {
    this.model = model;
    const mm = MODELS[model] || (ROMS[model] ? { rom: model, ram: ROMS[model] } : null);
    if (!mm) throw new Error('no model ' + model);
    this.opts = opts;
    this.m = new Machine({ rom: mm.rom, ram: mm.ram });
    this.sym = JSON.parse(fs.readFileSync(path.join(ROOT, 'build', 'game', 'kernel.sym.json'), 'utf8'));
    this.m.boot();
    this.m.insertPack(opts.pack || path.join(ROOT, 'build', 'game', 'C4.opk'), 0);
    this.base = -1;
    if (process.env.C4_COVER) this.cover(process.env.C4_COVER);
  }
  // coverage (env C4_COVER=<folder>): every instruction the game executes, credited to its unit
  // (the kernel, the driver, the overlay in slot A by kv_res, OV_THINK while a search runs); written
  // to <folder>/cov_<pid>_<n>.json when the process ends. (dbg.setTrace still works for tests: it
  // is chained.)
  cover(dir) {
    const s = this.sym, DRV = s.DRV[0], SLOTA = s.SLOTA[0], THINKAT = s.THINKAT[0];
    const RES = s.kv_res[0], KDRV = s.kv_drv[0];
    const ids = Object.fromEntries(fs.readFileSync(path.join(ROOT, 'build', 'game', 'gen', 'ids.inc'), 'utf8')
      .split('\n').map(l => l.match(/^(\w+) = (\d+)/)).filter(Boolean).map(m => [+m[2], m[1]]));
    const size = JSON.parse(fs.readFileSync(path.join(ROOT, 'build', 'game', 'build.json'), 'utf8')).total;
    const cov = {}, self = this, dbg = this.m.dbg;
    let user = null;
    const add = (u, o) => { (cov[u] || (cov[u] = new Set())).add(o); };
    dbg.setTrace((pc) => {
      const b = self.base;
      if (b >= 0 && pc >= b && pc < b + size) {
        const o = pc - b;
        if (o < DRV) add('kernel', o);
        else if (o < SLOTA) add(ids[self.m.peek(b + KDRV)] || 'DRV?', o - DRV);
        else {
          const r = self.m.peek(b + RES);
          if (o >= THINKAT && (r === 0 || ids[r] === 'OV_THINK')) add('OV_THINK', o - THINKAT);
          else add(r ? ids[r] || 'u' + r : 'kinit', o - SLOTA);
        }
      }
      if (user) user(pc);
    });
    dbg.setTrace = (f) => { user = f; };
    const n = (Game._covN = (Game._covN || 0) + 1);
    process.on('exit', () => {
      fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(path.join(dir, `cov_${process.pid}_${n}.json`), JSON.stringify(Object.fromEntries(Object.entries(cov).map(([u, v]) => [u, [...v]]))));
    });
  }
  // run C4 from the Prog menu and wait for the game (past the title)
  start(maxS = 20) {
    for (let i = 0; i < 4 && !/Find|FIND|PROG|Prog/.test(this.text()); i++) { this.m.press('ON', 3, 10); this.m.runSeconds(0.3); }
    // a game left earlier leaves its kernel (and "C4K1" tag) in freed RAM, and the new array may
    // be elsewhere: clear old tags so findBase finds the running one
    for (let a; (a = this.m.find([0x43, 0x34, 0x4B, 0x31], 0x2000, 0x8000)) >= 0;) this.m.poke(a, 0);
    this.base = -1;
    this.m.runProc('C4', 'B');
    this.waitFor(() => this.findBase() >= 0 && this.peek('kv_plines') > 0, 5);
    this.m.runSeconds(2.5);           // the title
    return this;
  }
  findBase() {
    const a = this.m.find([0x43, 0x34, 0x4B, 0x31], 0x2000, 0x8000);   // "C4K1"
    this.base = a < 0 ? -1 : a - 3;
    return this.base;
  }
  a(name) {
    const v = this.sym[name];
    if (!v) throw new Error('no symbol ' + name);
    return v[1] === 'rel' ? this.base + v[0] : v[0];
  }
  // On the LZ64 the array is in the banked window $4000-$7FFF: while the OS has another bank
  // in (file and pack services, some interrupts) reads show other RAM. Run on until the
  // kernel's tag is back at its address before trusting a read.
  sync() {
    if (this.base < 0) return;
    const ok = () => this.m.peek(this.base + 3) === 0x43 && this.m.peek(this.base + 4) === 0x34 &&
      this.m.peek(this.base + 5) === 0x4B && this.m.peek(this.base + 6) === 0x31;
    for (let i = 0; i < 2000 && !ok(); i++) this.m.run(200);
  }
  peek(n, o = 0) { this.sync(); return this.m.peek(this.a(n) + o); }
  poke(n, v, o = 0) { this.sync(); this.m.poke(this.a(n) + o, v); }
  peekw(n, o = 0) { this.sync(); return this.m.peekw(this.a(n) + o); }
  bytes(n, k, o = 0) { this.sync(); return this.m.read(this.a(n) + o, k); }
  recAt(i) { return (this.peek('g_rec', i >> 1) >> ((i & 1) * 4)) & 15; }   // (two moves a byte)
  rec() { const b = this.bytes('g_rec', 21), n = this.peek('g_n'); return Array.from({ length: n }, (_, i) => (b[i >> 1] >> ((i & 1) * 4)) & 15); }
  recStr() { return this.rec().map(c => c + 1).join(''); }
  screen() { return this.m.screen(); }
  text() { return this.m.screenText(); }
  // the panel's lines (12 characters from the driver's positions)
  panel() {
    const s = this.screen(), four = this.m.lines === 4;
    return four ? s.map(l => l.slice(8, 20)) : s.map(l => l.slice(4, 16));
  }
  waitFor(pred, maxS = 30, step = 0.1) {
    for (let t = 0; t < maxS; t += step) { if (pred()) return true; this.m.runSeconds(step); }
    return pred();
  }
  waitText(re, maxS = 30) {
    if (!this.waitFor(() => re.test(this.text()), maxS)) throw new Error('timed out waiting for ' + re + '\n' + this.text());
  }
  key(k, after = 0.4) { this.m.press(k, 3, 3); this.m.runSeconds(after); }
  keys(list, after = 0.4) { for (const k of list) this.key(k, after); }
  // the side to move and whether it is a human's turn on the play screen ("You: col 4", or
  // with the move timer running "ANN:4 17")
  humanTurn() { return /:( *col|\d \d)/.test(this.panel().join('|')); }
  // (the first time: Keep set to Off, so EXE on a result starts a new game without asking
  // "Export game?"; opts.keep leaves the setting alone: tests/ui/t_keep.js)
  waitHuman(maxS = 400) {
    if (!this.waitFor(() => this.humanTurn(), maxS, 0.2)) throw new Error('no human turn\n' + this.text());
    if (!this.opts.keep && !this._keepOff) { this.poke('st_keep', 2); this._keepOff = true; }
  }
  // drop in column c (0-6) from the play screen
  drop(c) {
    this.waitHuman();
    const digit = 'UVWOPQI'[c];      // the key carrying the digit
    this.key(digit, 0.2);
    this.key('EXE', 0.6);
  }
  // after choosing Two players: the two name prompts (EXE keeps each name as it is)
  names(n1, n2) {
    for (const nm of [n1, n2]) {
      if (!this.waitFor(() => /Player/.test(this.text()), 5)) return;
      for (const ch of nm || '') this.key(ch, 0.15);
      this.key('EXE', 0.5);
    }
    this.m.runSeconds(1);
  }
  board() {   // engine board as rows top-down: . S H
    const bd = this.bytes('e_bd', 49), rows = [];
    for (let r = 5; r >= 0; r--) { let s = ''; for (let c = 0; c < 7; c++) s += '.SH?'[bd[c * 7 + r]]; rows.push(s); }
    return rows;
  }
}

function assert(cond, msg) { if (!cond) throw new Error('FAIL: ' + msg); }

module.exports = { Game, MODELS, ROMS, assert, ROOT };
