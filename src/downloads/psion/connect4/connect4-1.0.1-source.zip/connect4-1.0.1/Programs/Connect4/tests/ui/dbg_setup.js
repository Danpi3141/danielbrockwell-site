'use strict';
const { Game } = require('./lib');
const g = new Game('lz64').start();
g.waitHuman(60);
g.poke('st_pace', 1);
const step = (k, t) => { g.key(k, t || 0.5); console.log('--', k, 'n', g.peek('g_n'), g.recStr(), '|', g.panel().join('|')); console.log(g.board().join(' ')); };
for (const k of ['ON', 'S', 'EXE', 'RIGHT', 'RIGHT', 'RIGHT', 'S', 'H', 'EXE']) step(k);
g.m.runSeconds(3); console.log(g.board().join(' '), g.recStr());
