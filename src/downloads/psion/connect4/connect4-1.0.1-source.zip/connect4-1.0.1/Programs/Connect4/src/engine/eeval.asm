; =====================================================================
; Evaluation (ref/engine.js evalRaw / evaluate)
; open lines (kept in e_ev) + threat parity: each column scanned upwards
; from its landing cell. Solid's threats on rows 1,3,5 and Hollow's on
; rows 2,4,6 score 16, others 4; a threat above an opponent's threat in
; the same column scores nothing. Seen from the side to move, plus the
; level's noise, clamped to -50..50.
; =====================================================================

; e_eval: A = the score
e_eval: clra
        clrb
        std  e_par
        clr  e_c7
        ldx  #e_land
        stx  e_lp
.col:   ldx  e_lp
        ldab 0,x                ; the landing cell
        ldaa e_c7
        adda #6
        sba                     ; A = empty cells in the column
        beq  .ncol
        clr  e_seen             ; 1 Solid's threat seen below, 2 Hollow's
        ldx  #e_thr
        abx
        tab                     ; B counts down: the row index is 6 - B
.cell:  ldaa 0,x
        bne  .thr
.nx:    inx
        decb
        bne  .cell
.ncol:  ldx  e_lp
        inx
        stx  e_lp
        ldaa e_c7
        adda #7
        staa e_c7
        cmpa #49
        bne  .col
        bra  .sum
; a threat cell: A = its byte, B = 6 - row
.thr:   staa e_t
        stx  e_xp
        stab e_cnt
        bita #$0F
        beq  .h
        ldaa e_seen
        bita #2
        bne  .h                 ; above a Hollow threat: buried
        ldaa #16                ; rows 1, 3, 5 (B even)
        bitb #1
        beq  .s
        ldaa #4
.s:     tab
        clra
        addd e_par
        std  e_par
.h:     ldaa e_t
        bita #$F0
        beq  .mk
        ldaa e_seen
        bita #1
        bne  .mk
        ldab e_cnt
        ldaa #4
        bitb #1
        beq  .hs
        ldaa #16                ; rows 2, 4, 6
.hs:    tab
        clra
        std  e_tmp
        ldd  e_par
        subd e_tmp
        std  e_par
.mk:    ldaa e_t
        ldab e_seen
        bita #$0F
        beq  .m2
        orab #1
.m2:    bita #$F0
        beq  .m3
        orab #2
.m3:    stab e_seen
        ldx  e_xp
        ldab e_cnt
        bra  .nx
.sum:
        ldd  e_ev
        addd e_par
        std  e_v16
        ldaa e_n                ; Hollow to move: negate
        anda #1
        beq  .nz
        clra
        clrb
        subd e_v16
        std  e_v16
.nz:    ldab e_noise
        beq  .clamp
        ldaa e_key              ; h = k0 ^ seed ^ k1
        eora e_nseed
        eora e_key+1
        staa e_t
        bmi  .pos
        nega                    ; h < 128: size 128 - h
        suba #128
        bra  .mul
.pos:   anda #$7F               ; h >= 128: size h - 128
.mul:   mul                     ; D = size * k
        asld
        tab                     ; B = (size * k) >> 7
        clra
        tst  e_t
        bmi  .add
        std  e_tmp
        ldd  e_v16
        subd e_tmp
        bra  .st
.add:   addd e_v16
.st:    std  e_v16
.clamp: ldd  e_v16
        subd #51
        blt  .lo
        ldaa #50
        rts
.lo:    ldd  e_v16
        addd #50
        bge  .ok
        ldaa #-50
        rts
.ok:    ldaa e_v16+1
        rts
