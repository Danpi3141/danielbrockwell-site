// The largest array the real launcher C4 (same code, bootstrap that returns at once) can
// declare on a blank CM: builds C4 with array N and sees whether it starts.
'use strict';
const fs = require('fs'), path = require('path'), { execSync } = require('child_process');
const { Machine } = require('../../tools/emu');
const out = path.join(__dirname, '..', '..', 'build', 'lowmem');
const src = fs.readFileSync(path.join(__dirname, '..', '..', 'build', 'game', 'C4.opl'), 'latin1');
function tryN(n, rom, ram) {
  // the same launcher, its array resized; the USR call replaced by a marker print
  let s = src.replace(/LOCAL m%\(\d+\)/, `LOCAL m%(${Math.ceil(n / 2)})`).replace(/i%=USR\(a%,ADDR\(v%\(\)\)\)/, 'PRINT "OK";FREE :GET :RETURN');
  fs.writeFileSync(path.join(out, 'C4.opl'), s, 'latin1');
  execSync(`python "${path.join(__dirname, '..', '..', '..', '..', 'Tools', 'opl2opk.py')}" -f --target cm "${path.join(out, 't.opk')}" "${path.join(out, 'C4.opl')}"`, { stdio: 'pipe' });
  const m = new Machine({ rom, ram });
  m.boot(); m.insertPack(path.join(out, 't.opk'), 0); m.runProc('C4', 'B'); m.runSeconds(3);
  const t = m.screen().join(' ');
  return /OK/.test(t) ? +(t.match(/OK\s*(\d+)/) || [0, 0])[1] : -1;
}
for (const [rom, ram] of [['33-cm.rom', 8], ['24-cm.rom', 8]]) {
  let lo = 4000, hi = 7000;
  while (hi - lo > 2) { const mid = (lo + hi) >> 1; if (tryN(mid, rom, ram) >= 0) lo = mid; else hi = mid; }
  console.log(rom, 'largest array', lo, 'FREE left then', tryN(lo, rom, ram));
}
