; ---------------------------------------------------------------------
; The history g_hv: 2 bits a ply (ply p in byte p/4, bits 2*(p mod 4)),
; the value of the position after p moves for the side to move there,
; when the book or a solved search knew it: 0 not known, 1 a win,
; 2 a draw, 3 a loss. Written at the Psion's turns (OV_BOOK: the book,
; OV_FX X_MARK: a solved search), read by the review (OV_REVIEW), cut by
; OV_GAME. (Included by those overlays.)
; ---------------------------------------------------------------------

; B = ply: X = its byte, A = ply mod 4 (hv_ax: X = another such table,
; as the review's tactics RV_TAC)
hv_at:  ldx  #g_hv
hv_ax:  tba
        anda #3
        lsrb
        lsrb
        abx
        rts

        if   HV_GET
; B = ply: A = its value
hv_get: bsr  hv_at
hv_rd:  ldab 0,x                ; (X, A from hv_at or hv_ax)
.s:     deca
        bmi  .d
        lsrb
        lsrb
        bra  .s
.d:     andb #3
        tba
        rts
        endif

        if   HV_SET
; A = a value (0-3), B = ply: into the history
hv_set: staa hv_v
        bsr  hv_at
        ldab #$FC               ; the mask and the value, moved to the ply's bits
        stab hv_m
.s:     deca
        bmi  .d
        sec
        rol  hv_m
        sec
        rol  hv_m
        asl  hv_v
        asl  hv_v
        bra  .s
.d:     ldab 0,x
        andb hv_m
        orab hv_v
        stab 0,x
        rts
hv_v:   fcb  0
hv_m:   fcb  0
        endif
