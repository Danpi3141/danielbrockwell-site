// the sequence of makes (ply:col) in one search, ref v asm, up to the first difference
'use strict';
const { Harness } = require('./harness');
const E = require('../../ref/engine');
const h = new Harness({ build: false });
const [seq, noise, seed, lim] = [process.argv[2], +process.argv[3], +process.argv[4], +process.argv[5]];
const e = new E.Engine(); h.call('eng_reset');
for (const ch of seq) { e.make(+ch - 1); h.call('e_make', +ch - 1); }
const n0 = e.n;
const refLog = [];
const mk = e.make.bind(e);
e.make = (c) => { refLog.push((e.n - n0) + ':' + c); return mk(c); };
e.think({ nodes: lim, noise, seed });
const asmLog = [];
const m = h.m, at = h.a('e_make');
m.dbg.setTrace((pc) => { if (pc === at) asmLog.push((h.peek('e_n') - n0) + ':' + m.dbg.a()); });
h.think({ nodes: lim, noise, seed });
m.dbg.setTrace(null);
let i = 0;
while (i < refLog.length && refLog[i] === asmLog[i]) i++;
console.log('makes ref', refLog.length, 'asm', asmLog.length, 'first difference at', i);
console.log('ref', refLog.slice(Math.max(0, i - 12), i + 6).join(' '));
console.log('asm', asmLog.slice(Math.max(0, i - 12), i + 6).join(' '));
