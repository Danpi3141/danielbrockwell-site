; =====================================================================
; OV_PANEL: before your move, the panel's lines that do not change while
; you choose: 1 the last move, 3 the level, a solved ending or the match,
; 4 the move number (one player); then on to OV_PLAY (one player) or
; OV_PLAY2 (two players), which draw line 2 (and OV_PLAY2 line 4, the
; clocks). Entry 1, from OV_COACH: asked out of the book, the solved
; ending or "Not known", shown until a key. Entry 2 (P_WARN), from OV_LIST's
; check of your drop (the coach on): the mark, X = 1 "Missed a win",
; 2 "Allows four", 3 "Allows fork", and "EXE drops it"; EXE or DOWN drops
; it (the kernel's cm_drop, column kv_arg), any other key goes back to
; choosing.
; =====================================================================
        include "../defs.inc"

        jmp  pp_start
        jmp  pp_unk
        jmp  pp_warn

pp_start:
        jsr  side_to_move
        staa pl_side
        jsr  pl_show1
        jsr  pl_show34
        ldaa #OV_PLAY
        ldab g_mode
        cmpb #1
        bne  .p
        ldaa #OV_PLAY2
.p:     clrb
        jmp  ov_call

pp_unk: jsr  lb_clr
        jsr  ex_text
        bcc  .put
        ldx  #pp_nk
        jsr  lb_fcl
.put:   ldaa kv_plines          ; line 3 of four, line 1 of two
        suba #2
        jsr  lb_put
        clra
        jmp  key_wait

pp_warn:
        pshx
        jsr  lb_clr
        pula                    ; D = the mark
        pulb
        aslb
        ldx  #pp_wt-2
        abx
        ldx  0,x
        jsr  lb_fcl
        ldaa kv_plines          ; the coach's line: 3 of four, 1 of two
        suba #2
        jsr  lb_put
        jsr  lb_clr
        jsr  lb_s
        fcl  "EXE drops it"
        ldaa #1
        jsr  lb_put
        ldx  #snd_buzz
        jsr  snd_play
        clra
        jsr  key_wait
        cmpb #K_EXE
        beq  .go
        cmpb #K_DOWN
        bne  .x
.go:    ldab kv_arg
        jmp  cm_drop
.x:     rts
pp_wt:  fdb  pp_mw, pp_a4, pp_fk
pp_mw:  fcl  "Missed a win"
pp_a4:  fcl  "Allows four"
pp_fk:  fcl  "Allows fork"

; the side's name: X = string
pl_name:
        ldx  #pl_you
        tst  g_psion
        bne  .x
        ldx  #g_names           ; two players: the player's name, if any
        cmpa g_p1
        beq  .p1
        ldab #7
        abx
.p1:    tst  0,x
        bne  .x
        ldx  #pl_sol
        cmpa #1
        beq  .x
        ldx  #pl_hol
.x:     rts
pl_you: fcl  "You"
pl_psi: fcl  "Psion"
pl_sol: fcl  "Solid"
pl_hol: fcl  "Hollow"

; the side's disc on four lines, then its name
pl_who: psha
        ldab kv_plines
        cmpb #4
        bne  .n
        jsr  DRV+DV_MARK
        jsr  lb_ch
.n:     pula
        bsr  pl_name
        jmp  lb_fcl

; " col N" fitted to the line: padded to column 7 (6 on two lines, with
; no disc mark), the space before N only if there is room. A = column.
pl_col: psha
        ldab kv_plines
        lsrb
        addb #5                 ; 7 on four lines, 6 on two
.pad:   cmpb kv_lp
        bls  .c
        pshb
        jsr  lb_sp
        pulb
        bra  .pad
.c:     ldab kv_lp              ; a space before "col" when it fits and the
        cmpb #7                 ; line does not end in one
        bhi  .cl
        ldx  #kv_lb-1
        abx
        ldaa 0,x
        cmpa #' '
        beq  .cl
        jsr  lb_sp
.cl:    jsr  lb_s
        fcl  "col"
        ldab kv_lp
        cmpb #10
        bhi  .d
        jsr  lb_sp
.d:     pula
        adda #'1'
        jmp  lb_ch

; line 1: the last move
pl_show1:
        jsr  lb_clr
        tst  g_psion            ; one player, two lines, the coach on: a solved ending here
        beq  .nx
        ldab kv_plines
        cmpb #2
        bne  .nx
        tst  st_coach
        beq  .nx
        jsr  ex_text
        bcc  .p
        jsr  lb_clr
.nx:
        ldab g_n
        beq  .p
        ldaa pl_side
        eora #3                 ; the side that moved
        ldab g_psion
        beq  .two
        ldab kv_plines
        cmpb #4
        bne  .nm
        jsr  DRV+DV_MARK
        jsr  lb_ch
.nm:    ldx  #pl_psi
        jsr  lb_fcl
        bra  .col
.two:   bsr  pl_who
.col:   ldab g_n
        decb
        jsr  rec_get
        jsr  pl_col
.p:     clra
        jmp  lb_put

; lines 3 and 4 (four lines). One player: the level, or a solved ending
; with the coach on; the move number. Two players: the match (line 4, the
; clocks or the move number, is OV_PLAY2's).
pl_show34:
        jsr  lb_clr
        tst  g_psion
        beq  .two
        tst  st_coach           ; the coach on: a solved ending instead of the level
        beq  .lv
        jsr  ex_text
        bcc  .l3
        jsr  lb_clr
.lv:    jsr  lb_s
        fcl  "Level "
        ldaa st_level           ; the level in force (Auto: g_alv; the kernel's
        cmpa #9                 ; level until 20 Nov 2026)
        bne  .lvp
        ldaa g_alv
.lvp:
        tab
        clra
        jsr  lb_num
        ldaa st_level
        cmpa #9
        bne  .l3
        jsr  lb_s
        fcl  " Auto"
.l3:    bsr  pp_l3
        jsr  lb_clr
        jsr  lb_s
        fcl  "Move "
        ldab g_n
        incb
        clra
        jsr  lb_num
        ldaa #3
        jmp  lb_put
.two:   tst  st_match
        beq  .m3
        ldx  #pl_sol            ; the match: player 1's side and the score
        ldaa g_p1
        cmpa #1
        beq  .s
        ldx  #pl_hol
.s:     jsr  lb_fcl
        jsr  lb_sp
        ldab g_score
        clra
        jsr  lb_num
        ldaa #'-'
        jsr  lb_ch
        ldab g_score+1
        clra
        jsr  lb_num
.m3:
; line 3 (the level, a solved ending or the match); on two lines, before
; the first move (line 1 has no last move yet), on line 1 instead
pp_l3:  ldaa #2
        ldab kv_plines
        cmpb #2
        bne  .p
        tst  g_n
        bne  .p
        clra
.p:     jmp  lb_put

        include "kexact.asm"

REC_PUT = 0
        include "krec.asm"

pp_nk:  fcl  "Can't tell"
pl_side: fcb 0
