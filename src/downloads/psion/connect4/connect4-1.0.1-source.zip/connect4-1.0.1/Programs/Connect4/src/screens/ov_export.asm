; =====================================================================
; OV_EXPORT: games to and from the files on A:.
;  X_EXPORT (the menu, E on the result): the game to the first free
;    A:C4G1..A:C4G99, one record of column digits such as 4435362 (the
;    notation PC solvers take); after the end that marks the result kept
;    (g_res bit 7). Then the game is saved.
;  X_READ (OV_IMPORT): X = n: A:C4Gn (0: A:C4LAST) read and every move
;    checked (a column 1-7 with room, no four before the last move); a bad
;    file leaves the game as it was (OV_GAME: G_RSAVE or G_REPLAY).
;  X_NEW (OV_END's E_NEW, when "Export game?" was answered yes): the
;    export, then the new game (kv_arg = the mode).
;  X_END (OV_RESULT, as a result is counted): A:C4LAST, the game as an
;    export but padded to LASTLEN bytes so it never grows; with Keep "All"
;    the export too. Then the game is saved.
; The names and records are built and read in the screen driver's area
; (DRV: 286 bytes, and a record can be 254), which is read in again after:
; so none of slot A is a buffer. (Until 19 Nov the top 256 bytes were.)
; A file is made only while C4 could still start again after it: the gap
; between the files (ALA_FREE) and the array must stay over KEEP_GAP
; (build.py; until 19 Nov an export could leave C4 a few bytes short).
; =====================================================================
        include "../defs.inc"

FN      = DRV                   ; a file name, with its length
RD      = DRV+16                ; a record, with its length (up to 255 bytes)
LASTLEN = 43                    ; A:C4LAST's record: the number of moves, then the digits

        if   FX_EMPTY
OV_NEWG = OV_FX*256+X_EMPTY     ; (as in the kernel's command table until 19 Nov)
        else
OV_NEWG = OV_GAME*256+G_NEWG
        endif

        jmp  ex_start
        jmp  ex_read
        jmp  ex_new
        jmp  ex_end

ex_start:
        clra                    ; (its message waits for a key)
        bsr  ex_save
ex_sv:  ldd  #OV_GAME*256+G_SAVE  ; no command: your move or the result again
        jmp  ov_call

; the game to the next A:C4Gk; A = the frames its message stays (0: a key)
ex_save:
        staa ex_w
        jsr  pn_clear           ; (the message alone: not under the result or the question)
        ldab g_n
        beq  .say               ; nothing to write
        ldaa #1
        staa ex_k
.find:  jsr  ex_name
        clr  kv_pkok
        ldx  #FN
        os   FL$OPEN
        bcs  .free
        inc  ex_k
        ldaa ex_k
        cmpa #100
        bne  .find
        bra  .fail
.free:  bsr  ex_room
        bcs  .fail
        ldx  #FN
        os   FL$CRET
        bcs  .fail
        tab
        os   FL$RECT
        ldab g_n                ; the record: length, then the digits
        stab RD
        ldx  #RD+1
        bsr  ex_dig
        ldx  #RD
        os   FL$WRIT
        bcs  .del
        tst  g_over             ; after the end: the result kept
        beq  .m
        ldaa g_res
        oraa #$80
        staa g_res
.m:     jsr  lb_s
        fcl  "Saved "
        ldab FN                 ; the name without "A:"
        subb #2
        stab FN+2
        ldx  #FN+2
        jsr  lb_fcl
        bra  .say
.del:   ldx  #FN                ; no room: the empty file goes again
        os   FL$DELN
.fail:  jsr  lb_clr
        jsr  lb_s
        fcl  "Cannot save"
.say:   bsr  ex_drv
        clra
        jsr  lb_put
        ldaa ex_w
        jmp  key_wait

; C set if a new file could leave C4 unable to start again
ex_room:
        ldd  kv_base
        subd ALA_FREE           ; the gap below the array
        bcs  .ok                ; (the array is not above the files: no limit)
        subd #KEEP_GAP
        rts
.ok:    clc
        rts

; the driver read in again (its area was the buffer); the game's pack
ex_drv: clr  kv_pkok
        ldaa kv_drv
        jmp  ov_load

; X = where: g_n digits, '1'-'7'
ex_dig: clra
.d:     cmpa g_n
        beq  .x
        psha
        tab
        jsr  rec_get            ; (X kept)
        adda #'1'
        staa 0,x
        inx
        pula
        inca
        bra  .d
.x:     rts

; ---------------------------------------------------------------------
ex_read:
        xgdx                    ; X = the file's number
        stab ex_k
        jsr  ex_name
        clr  kv_pkok
        ldx  #FN
        os   FL$OPEN
        bcs  .bad
        tab
        os   FL$RECT
        clra
        clrb
        os   FL$SETP
        ldd  #1
        os   FL$RSET
        bcs  .bad
        ldx  #RD
        os   FL$READ
        bcs  .bad
        clr  kv_pkok
        ldx  #RD                ; the count, then the digits
        tst  ex_k
        bne  .p
        inx                     ; (A:C4LAST: its own count after the length)
.p:     stx  ex_p
        jsr  eng_reset          ; check every move
        ldx  ex_p
        ldab 0,x
        beq  .bad
        cmpb #42
        bhi  .bad
        clr  ex_i
.mv:    ldab ex_i
        ldx  ex_p
        abx
        ldaa 1,x
        suba #'1'
        cmpa #7
        bhs  .bad
        tab                     ; room in the column?
        pshb
        ldx  #e_land
        abx
        ldab 0,x
        ldx  #e_bd
        abx
        ldab 0,x
        pula
        cmpb #3
        beq  .bad
        tst  e_won              ; a four before this move
        bne  .bad
        jsr  e_make
        inc  ex_i
        ldaa ex_i
        ldx  ex_p
        cmpa 0,x
        bne  .mv
        ldab 0,x                ; good: it becomes the game, two moves a byte
        stab g_n
        incb
        lsrb
        stab ex_i
        inx
        stx  kv_t0
        ldx  #g_rec
.cp:    pshx
        ldx  kv_t0
        ldd  0,x                ; (past the end: a nibble never read)
        inx
        inx
        stx  kv_t0
        pulx
        suba #'1'
        subb #'1'
        aslb
        aslb
        aslb
        aslb
        aba
        staa 0,x
        inx
        dec  ex_i
        bne  .cp
        bsr  ex_drv
        ldd  #OV_GAME*256+G_RSAVE ; the new record replayed and saved
        jmp  ov_call
.bad:   jsr  lb_clr
        jsr  lb_s
        fcl  "Bad game"
        bsr  ex_drv
        clra
        jsr  lb_put
        clra
        jsr  key_wait
        ldd  #OV_GAME*256+G_REPLAY  ; the game as it was (the engine was used)
        jmp  ov_call

; FN = "A:C4Gk" with a leading length (k = ex_k), or "A:C4LAST" (k = 0)
ex_name:
        ldd  #'A'*256+':'
        std  FN+1
        ldd  #'C'*256+'4'
        std  FN+3
        ldab ex_k
        bne  .g
        ldd  #'L'*256+'A'
        std  FN+5
        ldd  #'S'*256+'T'
        std  FN+7
        ldab #8
        bra  .n
.g:     ldaa #'G'
        staa FN+5
        ldx  #FN+6
        clra
        os   UT$UTOB
        addb #5
.n:     stab FN
        rts

; ---------------------------------------------------------------------
; X_NEW (OV_END asked "Export game?" before a new game, and EXE said yes)
ex_new: ldaa #30                ; "Saved C4G3" for 1.5 s (or a key)
        jsr  ex_save
        ldd  #OV_NEWG           ; then the new game (kv_arg = the mode)
        jmp  ov_call

; X_END: a result just counted
ex_end: ldaa g_mode
        cmpa #2
        beq  .sv                ; (not the demo)
        ldab g_n
        beq  .sv
        clr  ex_k               ; A:C4LAST
        jsr  ex_name
        ldx  #RD+1              ; its record: the count, the digits, spaces
        ldab #LASTLEN
        stab RD
        ldaa #' '
.sp:    staa 0,x
        inx
        decb
        bne  .sp
        ldab g_n
        stab RD+1
        ldx  #RD+2
        jsr  ex_dig
        clr  kv_pkok
        ldx  #FN
        os   FL$OPEN
        bcs  .mk
        tab
        os   FL$RECT
        clra
        clrb
        os   FL$SETP
        ldd  #1
        os   FL$RSET
        os   FL$ERAS
        bra  .w
.mk:    jsr  ex_room            ; a new file: only with room for it
        bcs  .dr
        ldx  #FN
        os   FL$CRET
        bcs  .dr
        tab
        os   FL$RECT
.w:     ldx  #RD
        os   FL$WRIT
.dr:    ldaa st_keep
        deca                    ; 1: all exported
        bne  .nd
        ldaa #30                ; "Saved C4G3" for 1.5 s (or a key)
        jsr  ex_save
        bra  .sv
.nd:    jsr  ex_drv
.sv:    jmp  ex_sv

ex_k:   fcb  0
ex_i:   fcb  0
ex_w:   fcb  0
ex_p:   fdb  0

REC_PUT = 0
        include "krec.asm"
