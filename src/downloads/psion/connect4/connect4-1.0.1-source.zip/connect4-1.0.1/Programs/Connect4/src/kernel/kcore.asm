; ---------------------------------------------------------------------
; The game loop
; g_rec   the moves so far (columns 0-6), g_n of them
; g_mode  0 one player, 1 two players, 2 demo
; g_psion the side the Psion plays: 0 none, 1 Solid, 2 Hollow, 3 both
; g_over  0 playing, 1 over, 2 over and counted in the tally / match;
;         g_res 1 Solid won, 2 Hollow won, 3 draw; +4 by resignation, +8 on time;
;         bits 4-5 the winning player (two players), 6 the tally due, 7 kept (exported)
; ---------------------------------------------------------------------

gm_main:
        lds  kv_sp              ; (every command comes back here)
        tst  g_over
        beq  .play
        ldd  #OV_RESULT*256     ; the result; returns a command
        jsr  ov_call
        bra  gm_cmd
.play:  jsr  psion_to_move
        beq  .human
        jsr  psion_move
        bra  gm_main
.human: ldd  #OV_PANEL*256      ; your move: OV_PANEL, then OV_PLAY or OV_PLAY2;
        jsr  ov_call            ; returns a command
gm_cmd: jsr  do_cmd
        bra  gm_main

; Z clear if the Psion plays the side to move
psion_to_move:
        jsr  side_to_move
        anda g_psion
        rts

; do_cmd: A = command, B = argument (also in kv_arg). The command table
; (kcmd.asm, read from the start of block C4B0; in RAM until 20 Nov 2026)
; holds a kernel routine's offset + $8000, or an overlay's id and entry to
; call: the commands that are only an overlay.
do_cmd: cmpa #C_FLAG
        bhi  .x
        stab kv_arg
        asla                    ; (B0_CMD = 0)
        tab
        clra
        xgdx
        clrb
        jsr  pk_at
        os   PK$RWRD            ; D = its entry
        tsta
        bmi  .k
        beq  .g                 ; the pack is gone (it reads as 0s)
        jmp  ov_call            ; an overlay: A = its id, B = the entry
.k:     anda #$7F               ; a kernel routine
        addd kv_base
        xgdx
        ldab kv_arg
        jmp  0,x
.g:     jmp  pk_gone
.x:     rts

; (a new game goes through OV_END's E_NEW: with Keep Ask, a result not kept
; is asked about; then the board empties, OV_FX X_EMPTY, and OV_GAME G_NEWG)
gm_x:   rts

cm_drop:
        tba
        jsr  play_move          ; your move
        bcs  .x
        tst  g_over
        bne  .x
        tst  g_mode             ; one player, with the coach on: its verdict
        bne  .x
        tst  st_coach
        beq  .x
        ldaa #1
        staa kv_arg
        ldd  #OV_COACH*256+B_COACH
        jmp  ov_call
.x:     rts
cm_set: ldd  #OV_SET*256        ; (kv_arg: the first item)
        jsr  ov_call
        jmp  save
cm_leave:
        jsr  save
        ldab #E_OK
        jmp  quit

; (the menu, swap sides, resign, out of time and the game's end are overlay
; code since 20 Nov 2026: OV_MENU, OV_CMD, src/screens/kover.asm)

; A = side to move (1 or 2)
side_to_move:
        ldaa e_n
        anda #1
        inca
        rts

; ---------------------------------------------------------------------
; play_move: A = column. C set if refused (no column, or full); else OV_FX
; X_FALL records it, lets it fall, makes and shows it, and saves it or ends
; the game (on a four or a full board).
; ---------------------------------------------------------------------
play_move:
        cmpa #7
        bhs  .no
        tab
        ldx  #e_land
        abx
        ldab 0,x
        ldx  #e_bd
        abx
        ldab 0,x
        cmpb #3
        beq  .no                ; full
        staa kv_col
        ldab #X_FALL
        jsr  fx_call
        clc
        rts
.no:    ldx  #snd_buzz
        jsr  snd_play
        sec
        rts

; B = an OV_FX entry (the falling disc takes its column from kv_col)
fx_call:
        ldaa #OV_FX
        jmp  ov_call

; save the game (OV_GAME)
save:   ldd  #OV_GAME*256+G_SAVE
        jmp  ov_call

; ---------------------------------------------------------------------
; The Psion's move: OV_BOOK shows "Thinking", gives the book's move
; (after the natural pause) or sets e_limit, e_fixd, e_noise, e_nseed for a search
; ---------------------------------------------------------------------
psion_move:
        ldd  #OV_BOOK*256+B_TURN
        jsr  ov_call            ; A = a column from the book, or 7
        cmpa #7
        blo  .play
        jsr  think_run
        clr  kv_xsc             ; a solved ending: its score kept for the coach
        tst  e_exact
        beq  .nx
        ldaa e_score
        eora #$80
        staa kv_xsc
.nx:    ldaa e_move
.play:  staa kv_col
        jsr  play_move
        ldab #X_MARK            ; its value into the history; its disc blinks, or the
        jsr  fx_call            ; demo's pause (OV_FX): A = C_MENU if a key stopped the demo
        tsta
        beq  .x
        jmp  do_cmd
.x:     rts

; D = positions: a search with no depth limit and no noise
set_search:
        std  e_limit
        clr  e_fixd
        clr  e_noise
        rts

; run the search with the thinking display; any key stops it. The display
; (OV_THINK) is read in to the top of slot A, above the search's table and
; scratch: it is only needed while the search runs.
think_run:
        ldaa #OV_THINK
        jsr  ov_load
        ldd  TMW_FRAM           ; its ot_tstart: the top two bytes of slot A
        std  SLOTA+SLOTA_SIZE-2
        clr  kv_kstop
        jsr  think
        os   KB$FLSH
        rts

; ---------------------------------------------------------------------
; hint: a short search for your move; its column becomes the chosen one
; ---------------------------------------------------------------------
hint:   ldd  #600               ; (about 2 s; OV_PLAY and OV_MENU refuse it when hints are off)
        jsr  set_search
        jsr  think_run
        ldaa e_move
        staa g_chosen
        ldaa #12                ; its landing cell blinks fast for a moment
        staa kv_flash
        rts
