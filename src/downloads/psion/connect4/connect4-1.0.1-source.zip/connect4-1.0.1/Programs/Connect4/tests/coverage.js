// Code the game never ran: reads the coverage files the UI tests write with C4_COVER=<folder>
// (tests/ui/lib.js) and lists, unit by unit, the runs of instructions never executed, from the
// build's listings.
//   C4_COVER=build/cover node tests/ui/t_features.js cm ...   then   node tests/coverage.js build/cover
'use strict';
const fs = require('fs'), path = require('path');
const ROOT = path.join(__dirname, '..'), G = path.join(ROOT, 'build', 'game');
const dir = process.argv[2] || path.join(ROOT, 'build', 'cover');
const seen = {};
for (const f of fs.readdirSync(dir).filter(f => /^cov_.*\.json$/.test(f))) {
  for (const [u, offs] of Object.entries(JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8')))) {
    const s = seen[u] || (seen[u] = new Set());
    offs.forEach(o => s.add(o));
  }
}
const DATA = /^\s*(fcb|fdb|fcc|fcl|rmb|include|if|else|endif|org)\b/i;
const units = ['kernel', ...fs.readFileSync(path.join(G, 'gen', 'ids.inc'), 'utf8').split('\n')
  .map(l => l.match(/^(\w+) = \d+/)).filter(Boolean).map(m => m[1]).filter(n => n !== 'N_UNITS')];
let totalI = 0, totalRun = 0;
const out = [];
for (const u of units) {
  const lst = path.join(G, u.toLowerCase() + '.lst');
  if (!fs.existsSync(lst)) continue;
  const lines = fs.readFileSync(lst, 'utf8').split(/\r?\n/);
  let origin = -1;
  const ins = [];               // [offset, text]
  for (const l of lines) {
    const m = l.match(/^([0-9A-F]{4})  ([0-9A-F]+)\s+(.*)$/);
    if (!m) continue;
    const a = parseInt(m[1], 16);
    if (origin < 0) origin = a;
    const src = m[3].replace(/^\S*:\s*/, '').replace(/^\.\w+:\s*/, '');
    if (DATA.test(' ' + src.trim())) continue;
    ins.push([a - origin, m[3].trim()]);
  }
  if (u === 'kernel') {         // the kernel's listing includes the engine and variables; the start-up code runs elsewhere
  }
  const s = seen[u] || new Set();
  let ran = 0;
  const runs = [];
  let cur = null;
  for (const [o, t] of ins) {
    if (s.has(o)) { ran++; cur = null; continue; }
    if (!cur) { cur = { from: o, n: 0, first: t }; runs.push(cur); }
    cur.n++;
  }
  totalI += ins.length; totalRun += ran;
  out.push(`== ${u}: ${ran} of ${ins.length} instructions ran (${(100 * ran / Math.max(ins.length, 1)).toFixed(1)}%)`);
  for (const r of runs) out.push(`   +${r.from.toString(16).padStart(4, '0')}  ${String(r.n).padStart(3)} never: ${r.first}`);
}
out.unshift(`all units: ${totalRun} of ${totalI} instructions ran (${(100 * totalRun / totalI).toFixed(1)}%)`);
console.log(out.join('\n'));
