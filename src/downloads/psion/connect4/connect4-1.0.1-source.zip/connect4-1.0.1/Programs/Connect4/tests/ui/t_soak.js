// Soak: the demo plays itself (levels 3 and 4) for N emulated minutes; every finished game's
// record is checked against the rules (legal moves, the result) and the kernel must still be there.
'use strict';
const { Game, assert } = require('./lib');
const S = require('../../tools/solver/solver');
const model = process.argv[2] || 'cm', mins = +(process.argv[3] || 20);
const g = new Game(model).start();
g.waitHuman(60);
g.poke('st_dlv1', 3); g.poke('st_dlv2', 4);
g.key('ON', 0.4); g.key('EXE', 0.4);
for (let i = 0; i < 3 && !g.text().includes('>Demo'); i++) g.key('DOWN', 0.3);
g.key('EXE', 1);
let games = 0, res = { 1: 0, 2: 0, 3: 0 };
const t0 = g.m.cycles();
let lastRec = '';
while ((g.m.cycles() - t0) / 921600 < mins * 60) {
  g.m.runSeconds(1);
  g.sync();                                  // (LZ64: the OS may have another bank in)
  assert(g.m.peek(g.base + 3) === 0x43 && g.m.peek(g.base + 6) === 0x31, 'the kernel is gone');
  const el = Math.round((g.m.cycles() - t0) / 921600);
  if (process.env.DBG && el % 60 === 0) console.log(el, 's: n', g.peek('g_n'), 'over', g.peek('g_over'), g.screen().join('|'));
  if (process.env.DBG && g.peek('g_over')) console.log('over seen at', Math.round((g.m.cycles() - t0) / 921600), g.recStr());
  if (g.peek('g_over') && g.recStr() !== lastRec) {
    lastRec = g.recStr();
    const p = S.fromMoves([]); let winner = 0;
    g.rec().forEach((c, i) => { assert(S.canPlay(p, c), 'illegal move in ' + lastRec); if (S.isWinningMove(p, c)) winner = (i % 2) + 1; S.play(p, c); });
    const r = g.peek('g_res') & 3;
    assert(winner ? r === winner : r === 3 && g.peek('g_n') === 42, `result ${r} for ${lastRec}`);
    res[r]++; games++;
  }
}
console.log(`${model}: ${games} demo games in ${mins} emulated minutes, Solid ${res[1]}, Hollow ${res[2]}, draws ${res[3]}: all legal, results right`);
