// Book walk (spec: 10,000 random opening sequences, with and without mirroring): the opponent
// plays at random, the Psion follows the book; at each of the Psion's turns walk.js must give
// the generator's own entry for that position (looked up by the opponent's moves, mirrored).
'use strict';
const fs = require('fs'), path = require('path');
const S = require('../solver/solver');
const W = require('./walk');
const DATA = path.join(__dirname, '..', '..', 'data');
const recs = new Map();
for (const f of fs.readdirSync(DATA).filter(f => /^book_nodes.*\.jsonl$/.test(f))) {
  for (const line of fs.readFileSync(path.join(DATA, f), 'utf8').split('\n')) {
    if (!line.trim()) continue; const r = JSON.parse(line); recs.set(r.t + r.opp.join(','), r);
  }
}
let rnd = 2468; const rand = n => { rnd = (rnd * 1103515245 + 12345) & 0x7fffffff; return rnd % n; };
let checked = 0, mirrored = 0, missing = 0;
for (let i = 0; i < 10000; i++) {
  const psionFirst = i % 2 === 0;
  const rec = [], p = S.fromMoves([]);
  for (let ply = 0; ply < 12; ply++) {
    const psion = (ply % 2 === 0) === psionFirst;
    if (psion) {
      const code = W.walk(rec, psionFirst);
      // the generator's entry for this position
      if (psionFirst && rec.length === 0) { if (code !== 4) throw new Error('empty board'); }
      else {
        const opp = rec.filter((c, k) => (k % 2 === 0) !== psionFirst);
        const mir = opp[0] >= 4;
        const key = (psionFirst ? 'F' : 'S') + opp.map(c => (mir ? 6 - c : c)).join(',');
        const r = recs.get(key);
        if (!r) { if (code) throw new Error('walk found an entry the generator has not: ' + key); if (opp.length <= 5) throw new Error('no entry within the book: ' + key); missing++; break; }
        if (r.code !== code) throw new Error(`walk ${code} generator ${r.code} at ${rec.map(c => c + 1).join('')}`);
        if (mir) mirrored++;
      }
      checked++;
      if (!code) break;
      const col = W.codeCol(code, rec, psionFirst);
      if (S.isWinningMove(p, col)) break;
      rec.push(col); S.play(p, col);
    } else {
      const ok = [0, 1, 2, 3, 4, 5, 6].filter(c => S.canPlay(p, c));
      const c = ok[rand(ok.length)];
      if (S.isWinningMove(p, c)) break;
      rec.push(c); S.play(p, c);
    }
  }
}
console.log(`book walk: ${checked} positions on 10,000 random openings agree with the generator (${mirrored} mirrored); ${missing} walks went past the book's last depth`);
