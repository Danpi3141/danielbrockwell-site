; ---------------------------------------------------------------------
; ex_text: the solved ending (kv_xsc) in kv_lb for you: "Win in 9",
; "Loss in 4", "A draw". C clear if there is one (included by OV_PANEL).
; ---------------------------------------------------------------------
ex_text:
        ldaa kv_xsc
        bne  .y
        sec
        rts
.y:     eora #$80               ; the Psion's score when it moved
        bne  .wl
        jsr  lb_s
        fcl  "A draw"
        clc
        rts
.wl:    bmi  .you               ; below 0: you win
        nega
        adda #100-1             ; it wins in p = 100 - score plies: you have (p-1)/2 moves
        lsra
        psha
        jsr  lb_s
        fcl  "Loss in "
        bra  .n
.you:   adda #100               ; you win at ply p = 100 + score: p/2 of your moves
        lsra
        psha
        jsr  lb_s
        fcl  "Win in "
.n:     pulb
        clra
        jsr  lb_num
        clc
        rts
