; =====================================================================
; OV_REVIEW: step through the game on the board. LEFT/RIGHT a move back
; or on, UP the start, DOWN the next marked move (a verdict worse than
; "Still", or a tactic; else the end), EXE, ON/CLEAR or MODE leave (the
; position as it was). Reached from the menu and, at the end of a game,
; with MODE (both go on to it through OV_LIST's L_TACT). Returns A = 0.
; Panel: the move (its side and column), then what it did, when the
; history (khist.asm) knows the value before and after it:
; "Win -> draw", "Still a win" and so on, and "Makes four" on the winning
; move (until 19 Nov 2026 "Still a win"); where that is none or "Still a
; loss", what the move let happen (RV_TAC, from OV_LIST on the way here):
; "Missed a win", "Allows four", "Allows fork"; else the move number.
; =====================================================================
        include "../defs.inc"

RV_TAC  = SLOTA+SLOTA_SIZE-11   ; the review's tactics (defs.inc)

HV_GET  = 1
HV_SET  = 0

        jmp  rv_start

rv_start:                       ; (OV_LIST buzzed if there are no moves)
        ldaa g_n
        staa rv_r               ; from the end (so on to .show)
.nx:    ldaa rv_r               ; DOWN: on to the next marked move, or the end
        cmpa g_n
        beq  .show
        inc  rv_r
        bsr  rv_pos
        jsr  rv_show
        ldx  rv_vx              ; marked: the texts from rv_wd on
        cpx  #rv_wd
        blo  .nx
.show:  bsr  rv_pos             ; (drawn again: no matter)
        jsr  rv_show
.key:   clra
        jsr  key_wait
        ldaa rv_r
        cmpb #K_LEFT
        bne  .rt
        deca
        bmi  .show
        bra  .set
.rt:    cmpb #K_RIGHT
        bne  .up
        cmpa g_n
        beq  .show
        inca
        bra  .set
.up:    cmpb #K_UP
        bne  .dn
        clra
        bra  .set
.dn:    cmpb #K_DOWN
        beq  .nx
.q:     cmpb #K_EXE
        beq  .out
        cmpb #K_ON
        beq  .out
        cmpb #K_MODE
        bne  .show
.out:   ldaa g_n                ; the position as it is
        staa rv_r
        bsr  rv_pos
        clra                    ; (no command)
        rts
.set:   staa rv_r
        bra  .show

; the position after rv_r moves, shown (g_over and the rest untouched)
rv_pos: jsr  eng_reset
        clr  rv_i
.l:     ldab rv_i
        cmpb rv_r
        beq  .d
        jsr  rec_get
        jsr  e_make
        inc  rv_i
        bra  .l
.d:     jmp  DRV+DV_BOARD

; the panel
rv_show:
        jsr  lb_clr             ; line 1: the move, "Hollow col 3"
        ldab rv_r
        bne  .mv
        jsr  lb_s
        fcl  "Start"
        bra  .l0
.mv:    decb                    ; the side that moved: Solid from even plies
        andb #1
        incb
        tba
        psha
        ldab kv_plines          ; four lines: its disc first
        cmpb #4
        bne  .nm
        jsr  DRV+DV_MARK
        jsr  lb_ch
.nm:    pula
        ldx  #rv_sol
        cmpa #1
        beq  .n
        ldx  #rv_hol
.n:     jsr  lb_fcl
        jsr  lb_s
        fcl  " col"
        ldab kv_lp              ; the space before the column when it fits
        cmpb #10
        bhi  .c
        jsr  lb_sp
.c:     ldab rv_r
        decb
        jsr  rec_get
        adda #'1'
        jsr  lb_ch
.l0:    clra
        jsr  lb_put
        jsr  rv_verdict         ; line 2: what the move did, if known
        stx  rv_vx
        beq  .t
        cpx  #rv_sl             ; (none, or "Still a loss": its tactic, if any)
        bne  .k
.t:     ldab rv_r
        beq  .k
        decb
        ldx  #RV_TAC
        jsr  hv_ax
        jsr  hv_rd              ; A = the tactic (OV_LIST)
        beq  .k
        ldx  #rv_mw             ; its text
        bsr  rv_nth
        stx  rv_vx
.k:     jsr  lb_clr
        ldx  rv_vx
        beq  .nv
        jsr  lb_fcl
.nv:    ldab kv_plines
        cmpb #4
        beq  .four
        ldx  rv_vx              ; two lines: else the move number
        bne  .p1
        bsr  rv_num
.p1:    ldaa #1
        jmp  lb_put
.four:  ldaa #1
        jsr  lb_put
        jsr  lb_clr
        bsr  rv_num
        ldaa #2
        jsr  lb_put
        jsr  lb_clr
        jsr  lb_s
        fcl  "Review"
        ldaa #3
        jmp  lb_put

; "Move 14/30"
rv_num: jsr  lb_s
        fcl  "Move "
        ldab rv_r
        clra
        jsr  lb_num
        ldaa #'/'
        jsr  lb_ch
        ldab g_n
        clra
        jmp  lb_num

; X = the text for move rv_r (the engine has the position after it), or 0.
; For the side that moved: before = the history at its ply, or the
; opposite of the ply before (the Psion moved there, and played the
; book's or a solved best move); after = a win if it made four, a draw on
; a full board, else the opposite of the history after it, or (the Psion
; moved: a best move) the value before.
rv_verdict:
        ldab rv_r
        beq  .no
        decb
        stab rv_i
        jsr  hv_get             ; its ply
        staa rv_rec
        staa rv_bef
        bne  .af
        ldab rv_i
        beq  .af
        decb
        jsr  hv_get             ; the ply before
        tsta
        beq  .af
        nega
        adda #4
        staa rv_bef
.af:    ldx  #rv_mf             ; four: "Makes four" (before rv_wd: not a mark)
        tst  e_won
        bne  .r
        ldaa #2                 ; full: a draw
        ldab rv_r
        cmpb #42
        beq  .ha
        jsr  hv_get             ; after it, for the other side
        tsta
        beq  .nr
        nega
        adda #4
        bra  .ha
.nr:    ldaa rv_rec
        beq  .no
        ldaa rv_bef
.ha:    ldab rv_bef             ; A = after, B = before (1 win, 2 draw, 3 loss)
        beq  .no
        cba
        bhi  .worse
        ldx  #rv_sw             ; kept: "Still a ..."
        bra  rv_nth
.worse: ldx  #rv_dl
        cmpb #2
        beq  .r
        ldx  #rv_wd
        cmpa #2
        beq  .r
        ldx  #rv_wl
.r:     rts
.no:    ldx  #0
        rts

; X = the first of some texts, A = n (1-): X = the nth
rv_nth: deca
        beq  .x
        ldab 0,x
        abx
        inx
        bra  rv_nth
.x:     rts

        include "khist.asm"

REC_PUT = 0
        include "krec.asm"

rv_sw:  fcl  "Still a win"
rv_sd:  fcl  "Still a draw"
rv_sl:  fcl  "Still a loss"
rv_mf:  fcl  "Makes four"
rv_wd:  fcl  "Win -> draw"     ; (the marks: from here on)
rv_wl:  fcl  "Win -> loss"
rv_dl:  fcl  "Draw -> loss"
rv_mw:  fcl  "Missed a win"
rv_a4:  fcl  "Allows four"
rv_fk:  fcl  "Allows fork"
rv_sol: fcl  "Solid"
rv_hol: fcl  "Hollow"
rv_r:   fcb  0
rv_i:   fcb  0
rv_rec: fcb  0
rv_bef: fcb  0
rv_vx:  fdb  0
