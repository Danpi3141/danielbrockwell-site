; =====================================================================
; Connect 4 kernel: stays in RAM while the game runs. Assembled at offset
; 0 of the game's array m%(); the bootstrap has added the array's address
; to every fix-up. The engine is part of this image.
;
; Array: kernel + engine code and tables | variables | screen driver (DRV)
;        | slot A (overlays). While the engine searches, its 512-byte table
;        (E_TT) starts at DRV and its scratch (E_FR) follows: the driver is
;        not used during a search and is read in again after it.
;
; Entry (from the bootstrap): D = ADDR(v%()): 0 array address, 2 array
; size, 4 device. Returns to the launcher with X = result code (E_*).
; =====================================================================
        include "../defs.inc"

entry:  jmp  kv_first           ; must be the first instruction: the start-up code
                                ; (kinit.asm), where it is stored, copies itself into R
        fcc  "C4K1"             ; kernel format tag

        include "ids.inc"

E_TT    = TTBASE                ; (= DRV)
E_FR    = SCRATCH               ; (= DRV + 512)


; leave the game from any depth: B = result code
quit:   lds  kv_sp
        pshb
        os   PK$PKOF
        ldaa #12
        os   DP$EMIT
        tst  kv_four            ; back to the display mode we found
        beq  .d
        ldaa kv_omode
        os   DP$MSET
.d:     os   KB$FLSH
        pulb
        clra
        xgdx
        rts

; ---------------------------------------------------------------------
; ov_call: A = overlay id, B = entry: load the overlay into slot A (if it
; isn't there) and call the entry with X unchanged. Registers come back
; from the overlay.
; ---------------------------------------------------------------------
ov_call:
        stx  kv_rx
        pshb
        jsr  ov_load
        pulb
        ldaa #3
        mul
        addd #SLOTA
        std  kv_rtgt
        ldx  kv_rtgt
        pshx
        ldx  kv_rx
        rts                     ; into the entry; its rts returns to our caller

; ---------------------------------------------------------------------
; think: the engine searches (its table and scratch cover the driver and
; slot A, so the overlay there is gone afterwards and the driver is read in
; again). e_limit etc. set by the caller.
; ---------------------------------------------------------------------
think:  clr  kv_res
        jsr  e_think
        ldaa kv_drv             ; the table covered the driver: read it in again
        jmp  ov_load            ; (the search's results, after the table, are kept)

; C4B0 starts with two tables the kernel reads from the pack (written by
; tools/build.py; in RAM until 20 Nov 2026): the command table (kcmd.asm)
; and the units' offsets in C4B0
B0_CMD  = 0
B0_OVT  = B0_CMD+2*(C_FLAG+1)

        include "kpack.asm"
        include "kkeys.asm"
        include "kpanel.asm"
        include "ksound.asm"
        include "kcore.asm"
        include "../engine/engine.asm"
        include "kvars.inc"
kernel_end:
