// Two players: a game to a four, the result screen, then save and resume.
'use strict';
const { Game, assert } = require('./lib');
for (const model of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'lz64']) {
  const g = new Game(model).start();
  g.waitHuman();
  g.keys(['ON', 'EXE'], 0.5);                 // menu, New game
  g.keys(['DOWN', 'EXE'], 0.5);               // Two players
  g.names('ANN', '');                         // player 1 is ANN, player 2 has no name
  assert(g.peek('g_mode') === 1 && g.peek('g_psion') === 0, 'two-player mode');
  for (const c of [0, 1, 0, 1, 0, 1]) g.drop(c);
  assert(g.recStr() === '121212', 'record ' + g.recStr());
  // leave and come back: the same position
  g.keys(['ON', 'L', 'L', 'EXE'], 2);
  assert(/RUN|Run|EDIT|Edit/.test(g.text()), 'left the game: ' + g.text());
  g.start();
  g.waitHuman();
  assert(g.recStr() === '121212', 'resumed record ' + g.recStr());
  g.drop(0);                                  // Solid's fourth in column 1
  g.waitText(/ANN wins|Solid wins/, 5);
  g.m.runSeconds(0.5);
  assert(/ANN wins/.test(g.text()), 'the winner by name: ' + g.text());
  assert(/in 7 moves/.test(g.text()), 'result line: ' + g.text());
  console.log(model, 'ok:', g.panel().map(s => s.trim()).filter(Boolean).join(' | '));
  console.log(g.board().join('\n'));
}
