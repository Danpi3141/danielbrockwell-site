// Self-play: the game in the emulator against the reference engine playing "you" through the
// keys, whole games, coach on. Checks every move of the game against the engine's record, the
// result screen against the rules (the solver's four / full board), and that solved endings are
// announced. node tests/ui/t_selfplay.js [model] [games] [psion level] [your level]
'use strict';
const { Game, assert } = require('./lib');
const E = require('../../ref/engine');
const S = require('../../tools/solver/solver');
const model = process.argv[2] || 'lz64', games = +(process.argv[3] || 2);
const plv = +(process.argv[4] || 5), ylv = +(process.argv[5] || 4);
let rnd = 2024; const rand = n => { rnd = (rnd * 1103515245 + 12345) & 0x7fffffff; return rnd % n; };
const tally = { psion: 0, you: 0, draw: 0 };
let solvedSeen = 0;
for (let gi = 0; gi < games; gi++) {
  const g = new Game(model).start();
  g.waitHuman(60);
  g.poke('st_level', plv); g.poke('st_pace', 1); g.poke('st_coach', 1); g.poke('st_you', gi % 2);
  g.key('ON', 0.4); g.key('EXE', 0.4); g.key('EXE', 1.5);    // New game, One player
  const youFirst = g.peek('g_psion') === 2;
  const lv = E.LEVELS[ylv];
  for (let k = 0; k < 50; k++) {
    g.waitFor(() => g.peek('g_over') || g.humanTurn(), 600, 0.2);
    if (process.env.DBG) console.log('k', k, 'over', g.peek('g_over'), 'n', g.peek('g_n'), 'base', g.base.toString(16), g.findBase().toString(16), g.screen().join('|'));
    if (g.peek('g_over')) break;
    if (/Win in|Loss in|A draw/.test(g.panel().join('|'))) solvedSeen++;
    const e = new E.Engine();
    for (const c of g.rec()) e.make(c);
    const r = e.think({ nodes: lv.nodes, depth: lv.depth, noise: lv.noise, seed: rand(256) });
    if (process.env.DBG) console.log('n', g.peek('g_n'), g.recStr(), 'move', r.move + 1, '|', g.panel().join('|'));
    g.drop(r.move);
  }
  // the result against the rules
  const rec = g.rec(), p = S.fromMoves([]);
  let winner = 0;
  rec.forEach((c, i) => { if (S.isWinningMove(p, c)) winner = (i % 2) + 1; S.play(p, c); });
  const res = g.peek('g_res') & 3;
  if (winner) assert(res === winner, `result ${res}, four by side ${winner} (${g.recStr()})`);
  else assert(res === 3 && rec.length === 42, `draw expected (${g.recStr()}) result ${res}`);
  const psionSide = youFirst ? 2 : 1;
  const who = res === 3 ? 'draw' : res === psionSide ? 'psion' : 'you';
  tally[who]++;
  g.waitText(/wins|win!|A draw/, 20);
  const txt = g.text();
  assert(who === 'draw' ? /A draw/.test(txt) : who === 'psion' ? /Psion wins/.test(txt) : /You win/.test(txt), 'result screen: ' + txt);
  console.log(model, 'game', gi, youFirst ? 'you first' : 'Psion first', g.recStr(), '->', who);
}
console.log(`${model}: Psion (level ${plv}) ${tally.psion}, you (reference level ${ylv}) ${tally.you}, draws ${tally.draw}; solved endings shown ${solvedSeen} times`);
