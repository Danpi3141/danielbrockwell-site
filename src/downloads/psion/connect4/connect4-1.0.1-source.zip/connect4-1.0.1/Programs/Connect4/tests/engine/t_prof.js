// Profile: instructions executed in each routine of the engine during searches.
'use strict';
const { Harness, BASE } = require('./harness');
const E = require('../../ref/engine');
const h = new Harness({ build: false });
const labels = Object.entries(h.sym).filter(([k, v]) => /^[a-z_][a-z0-9_]*$/i.test(k) && !k.includes('.') && v < 0x4000)
  .map(([k, v]) => [v + BASE, k]).sort((a, b) => a[0] - b[0]);
const count = new Map();
const owner = new Array(65536).fill(null);
for (let i = 0; i < labels.length; i++) { const end = i + 1 < labels.length ? labels[i + 1][0] : labels[i][0] + 64; for (let a = labels[i][0]; a < end; a++) owner[a] = labels[i][1]; }
let total = 0, prevPc = -1, prevCyc = 0;
h.m.dbg.setTrace(pc => {
  const c = h.m.dbg.cycles();
  if (prevPc >= 0) { const o = owner[prevPc] || '?'; count.set(o, (count.get(o) || 0) + (c - prevCyc)); total += c - prevCyc; }
  prevPc = pc; prevCyc = c;
});
let rnd = 99; const rand = n => { rnd = (rnd * 1103515245 + 12345) & 0x7fffffff; return rnd % n; };
let nodes = 0;
for (let i = 0; i < 6; i++) {
  h.call('eng_reset'); const e = new E.Engine();
  for (let k = 0; k < 10 + i; k++) { const l = [0,1,2,3,4,5,6].filter(c => e.canPlay(c)); const c = l[rand(l.length)]; if (e.make(c)) break; h.call('e_make', c); }
  nodes += h.think({ nodes: 3000 }).nodes;
}
const rows = [...count.entries()].sort((a, b) => b[1] - a[1]).slice(0, 25);
for (const [k, v] of rows) console.log(k.padEnd(14), (v / nodes).toFixed(0).padStart(6), 'cycles/position', (100 * v / total).toFixed(1) + '%');
console.log('total', (total / nodes).toFixed(0), 'cycles/position');
