'use strict';
const { Harness } = require('./harness');
const E = require('../../ref/engine');
const h = new Harness({ build: false });
const [seq, noise, seed, lim] = [process.argv[2], +process.argv[3], +process.argv[4], +process.argv[5]];
const e = new E.Engine(); h.call('eng_reset');
for (const ch of seq) { e.make(+ch - 1); h.call('e_make', +ch - 1); }
// find the first make after which the tables differ
const refT = []; let k = 0;
const mk = e.make.bind(e);
e.make = (c) => { refT.push({ tt: e.tt.slice(), k: k++, c, n: e.n, key: e.key }); return mk(c); };
e.think({ nodes: lim, noise, seed });
let j = 0, done = false; const m = h.m, mpc = h.a('e_make'), tt = h.a('E_TT');
m.dbg.setTrace((pc) => { if (pc === mpc && !done) {
  const a = m.read(tt, 512), r = refT[j++];
  if (!r) return;
  const diff = []; for (let i = 0; i < 512; i++) if (a[i] !== r.tt[i]) diff.push(i);
  if (diff.length) {
    done = true;
    const p = refT[j - 2];
    console.log('tables differ before make', j - 1, 'previous make', p && p.k, 'col', p && p.c);
    const ents = [...new Set(diff.map(i => i >> 2))];
    for (const en of ents) console.log(' entry', en, 'asm', a.slice(en * 4, en * 4 + 4).join(','), 'ref', r.tt.slice(en * 4, en * 4 + 4).join(','));
  }
} });
h.think({ nodes: lim, noise, seed });
