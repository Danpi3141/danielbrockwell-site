; ---------------------------------------------------------------------
; The move record g_rec: two moves a byte (move k in byte k/2: the low
; nibble for even k, the high one for odd k). (Included by the overlays
; that read or write it; until 19 Nov it was a byte a move.)
; ---------------------------------------------------------------------

; B = move number: A = its column (B and X kept)
rec_get:
        pshx
        pshb
        lsrb
        ldx  #g_rec
        abx
        ldaa 0,x
        pulb
        bitb #1
        beq  .e
        lsra
        lsra
        lsra
        lsra
.e:     anda #$0F
        pulx
        rts

        if   REC_PUT
; A = a column, B = move number: into the record (A, B and X kept)
rec_put:
        pshx
        pshb
        staa rc_v
        lsrb
        ldx  #g_rec
        abx
        pulb
        pshb
        bitb #1
        bne  .hi
        ldaa 0,x                ; even: the low nibble
        anda #$F0
        oraa rc_v
        bra  .st
.hi:    ldaa rc_v               ; odd: the high nibble
        asla
        asla
        asla
        asla
        ldab 0,x
        andb #$0F
        aba
.st:    staa 0,x
        ldaa rc_v
        pulb
        pulx
        rts
rc_v:   fcb  0
        endif
