; =====================================================================
; OV_RESULT: the result. Counts it once (Auto level, match; a one-player
; result marks the tally due: g_res bit 6), then OV_EXPORT's X_END (the
; last game kept, Keep All) saves it; and shows it, then goes on to
; OV_HELP's H_TALLY for the tally line and OV_END for the keys and the
; winning four's blinking. The panel's last line is kept in RS_LINE for
; OV_END, which names the keys there in turn and then puts it back.
; =====================================================================
        include "../defs.inc"

RS_LINE = SLOTA+SLOTA_SIZE-12   ; (OV_HELP and OV_END load below it)

        jmp  rs_start

rs_start:
        ldaa g_over
        cmpa #1
        bne  .show
        inc  g_over             ; counted once
        bsr  rs_count
        ldd  #OV_EXPORT*256+X_END ; the last game kept, then saved: no command, so the
        jmp  ov_call            ; loop brings the result back (an overlay never calls one)
.show:  jsr  pn_clear
        jsr  lb_clr
        ldaa g_res
        anda #3
        cmpa #3
        bne  .win
        jsr  lb_s
        fcl  "A draw"
        bra  .l1
.win:   staa rs_w
        ldab g_psion
        beq  .side
        cmpb #3
        beq  .side
        cmpa g_psion            ; one player: you or the Psion
        bne  .you
        jsr  lb_s
        fcl  "Psion wins"
        bra  .l1
.you:   jsr  lb_s
        fcl  "You win!"
        bra  .l1
.side:  ldx  #g_names           ; two players: the winning player's name, if any
        ldab g_res              ; (kept in g_res bits 4-5 when it was counted)
        andb #$30
        beq  .sn
        cmpb #$10
        beq  .p1
        ldab #7
        abx
.p1:    tst  0,x
        bne  .n
.sn:    ldx  #rs_sol
        cmpa #1
        beq  .n
        ldx  #rs_hol
.n:     jsr  lb_fcl
        jsr  lb_s
        fcl  " wins"
.l1:    clra
        jsr  lb_put
        jsr  lb_clr             ; how
        ldaa g_res
        bita #4                 ; resigned: one player, by you (the Psion never
        beq  .t                 ; resigns); two players, by the one not named
        ldab g_psion
        beq  .rs
        cmpb #3
        beq  .rs
        jsr  lb_s
        fcl  "You resigned"
        bra  .l2
.rs:    jsr  lb_s
        fcl  "by surrender"
        bra  .l2
.t:     bita #8
        beq  .m
        jsr  lb_s
        fcl  "on time"
        bra  .l2
.m:     jsr  lb_s
        fcl  "in "
        ldab g_n
        clra
        jsr  lb_num
        jsr  lb_s
        fcl  " moves"
.l2:    ldaa #1
        jsr  lb_put
        bsr  rs_keep            ; (two lines: the last)
        jsr  lb_clr             ; four lines: the match (the tally: OV_END), and what next
        ldaa g_mode
        cmpa #1
        bne  .l3
        tst  st_match
        beq  .l3
        bsr  rs_tgt             ; a match won?
        ldaa #'1'
        cmpb g_score
        beq  .mw
        inca
        cmpb g_score+1
        bne  .sc
.mw:    psha
        ldaa #'P'
        jsr  lb_ch
        pula
        jsr  lb_ch
        jsr  lb_s
        fcl  " wins match"
        bra  .l3
.sc:    jsr  lb_s
        fcl  "P1 "
        ldab g_score
        clra
        jsr  lb_num
        jsr  lb_s
        fcl  " - P2 "
        ldab g_score+1
        clra
        jsr  lb_num
.l3:    ldaa #2
        jsr  lb_put
        jsr  lb_clr
        jsr  lb_s
        fcl  "EXE new game"
        ldaa #3
        jsr  lb_put
        ldab kv_plines
        cmpb #4
        bne  .tl
        bsr  rs_keep            ; (four lines: the last)
.tl:    ldd  #OV_HELP*256+H_TALLY
        jmp  ov_call

; the line just shown (kv_lb) into RS_LINE
rs_keep:
        ldd  #12
        std  T0
        ldx  #kv_lb
        ldd  #RS_LINE
        os   UT$CPYB
        rts

; count the result once
rs_count:
        ldaa g_mode
        bne  .two
        ldaa g_res              ; one player: your win, draw or loss
        anda #3
        clrb                    ; 0 win
        cmpa #3
        bne  .wl
        ldab #1                 ; draw
        bra  .c
.wl:    cmpa g_psion
        bne  .c
        ldab #2                 ; loss
.c:     stab rs_w
        ldaa g_res              ; the tally is due (OV_END counts it)
        oraa #$40
        staa g_res
        ldaa st_level           ; Auto: up after a win, down after a loss
        cmpa #9
        bne  .x
        ldaa g_alv
        ldab rs_w
        bne  .lo
        cmpa #8
        beq  .x
        inca
        bra  .s
.lo:    cmpb #2
        bne  .x
        cmpa #1
        beq  .x
        deca
.s:     staa g_alv
.x:     rts
.two:   cmpa #1
        bne  .x
        ldaa g_res              ; two players: the winner's game, and who starts next
        anda #3
        cmpa #3
        beq  .who
        ldx  #g_score
        ldab #$10               ; (the winning player, kept for the result's name)
        cmpa g_p1
        beq  .p
        inx
        ldab #$20
.p:     inc  0,x
        orab g_res
        stab g_res
.who:   ldab st_who             ; 0 alternate, 1 loser starts, 2 winner starts
        bne  .lw
        ldaa g_p1               ; alternate: player 1 takes the other side
        eora #3
        bra  .set
.lw:    ldaa g_res
        anda #3
        cmpa #3
        beq  .x                 ; a draw: as it was
        cmpa g_p1
        beq  .p1w
        ldaa #1                 ; player 2 won: loser starts -> P1 Solid
        cmpb #1
        beq  .set
        ldaa #2                 ; winner starts -> P1 Hollow
        bra  .set
.p1w:   ldaa #2                 ; player 1 won: loser starts -> P1 Hollow
        cmpb #1
        beq  .set
        ldaa #1
.set:   staa g_p1
        rts

; B = 3, 5 or 10: the wins a match needs (st_match 1-3)
rs_tgt: ldx  #rs_t-1
        ldab st_match
        abx
        ldab 0,x
        rts
rs_t:   fcb  3,5,10

rs_sol: fcl  "Solid"
rs_hol: fcl  "Hollow"
rs_w:   fcb  0
