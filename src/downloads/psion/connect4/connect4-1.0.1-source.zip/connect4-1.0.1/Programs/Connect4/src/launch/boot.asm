; =====================================================================
; Connect 4 bootstrap (from Chess): poked into the top of the game's array by the launcher CHGn,
; run with  i% = USR(a%, ADDR(v%()))
; It finds the kernel block C4M on C:, B: or A: with the OS's FL$BOPN (until
; 17 Nov it read the packs' directories itself: 145 of its 253 bytes), reads
; the kernel into the game's array m%() and the rest of the block after it, and
; runs the fixer there (src/launch/fixer.asm, until 19 Nov part of this code:
; C4G, which holds this as a string, stays in RAM all game).
;
; v%() layout (bytes): 0 array address  2 array size  4 device (the kernel
; reads these); then the bootstrap's own: 10 kernel length, 13 encoded fix-up
; length.
; Position independent: only relative branches; across OS calls everything is
; on the stack.
; It contains no byte 0, 9, 10 or 13 (an OPL string cannot hold them, and the
; build refuses them): X points one byte below v%() so no field is at offset
; 0, 9, 10 or 13, and constants are added as subtractions.
; Returns X = 1 (E_NOPACK) if no device holds CHK.
; =====================================================================
        include "../defs.inc"

; offsets from X = v%()-1 (none may be 0, 9, 10 or 13)
V_BASE  = 1                     ; the array (from C4G)
V_DEV   = 5                     ; the device: A: 0, B: 1, C: 2 (for the kernel)
V_KLEN  = 7                     ; the kernel's length (for the fixer)
V_ALL   = 11                    ; the kernel, the fixer and the fix-ups (for the fixer)

boot:   addd #$FFFF             ; (dex is byte 9)
        xgdx                    ; X = v%()-1
        pshx
        bsr  .find              ; (pushes the name's address)
.name:  fcb  5
        fcc  "B:C4M"
.find:  ldaa #3                 ; C:, then B:, then A:
.dev:   pulx                    ; X = the name
        pshx
        psha
        adda #'A'-1
        staa 1,x                ; its device letter
        ldab #$83               ; a procedure (a block file of type $83)
        os   FL$BOPN            ; found: the pack address is at its data
        bcs  .nx
        clra
        ldab #16                ; past the object length (2) and the CM RETURN stub (14)
        os   PK$SKIP
        os   PK$RWRD            ; the build it belongs to: another's (another version's, on another
        subd #BUILD             ; pack) is passed over
        beq  .found
.nx:    pula
        deca
        bne  .dev
        pulx                    ; not found: X = 1
        pulx
        ldab #1
        clra
        xgdx
        rts

; C4M's data: the object length (2) and the CM RETURN stub (14), the build (2), the kernel's
; length, the length of all that follows it, then the kernel, the fixer
; (src/launch/fixer.asm, position independent) and the encoded fix-ups, read
; in one go; the fixer is run where it lands, with X = v%()-1: it fixes the
; kernel and jumps to it.
.found: pula                    ; the device
        pulx                    ; (the name)
        pulx                    ; X = v%()-1
        deca                    ; A: 0, B: 1, C: 2
        staa V_DEV,x
        pshx
        os   PK$RWRD            ; D = the kernel's length
        pulx
        std  V_KLEN,x
        pshx
        os   PK$RWRD            ; D = all of it
        pulx
        std  V_ALL,x
        pshx
        ldx  V_BASE,x
        os   PK$READ            ; into m%()
        pulx                    ; X = v%()-1
        ldd  V_KLEN,x
        addd V_BASE,x
        pshb                    ; into the fixer, just after the kernel
        psha
        rts
