; =====================================================================
; OV_LIST: the move list, two moves (four discs) a line: "1.44  2.35".
; UP/DOWN scroll, any other key goes back.
; Entry L_TACT: the review's tactics (RV_TAC), then the review.
; Entry L_DROP: the command C_DROP, checked first with the coach on.
; =====================================================================
        include "../defs.inc"

RV_TAC  = SLOTA+SLOTA_SIZE-11   ; the review's tactics (defs.inc)

        jmp  ls_start
        jmp  tc_run
        jmp  dr_chk

ls_start:
        clr  ls_top             ; the first line shown (a line = 2 moves)
        ldab g_n                ; the last screen first
        addb #3
        lsrb
        lsrb                    ; lines needed: ceil(discs / 4)
        subb kv_plines
        bcs  .sh
        incb
        stab ls_top
.sh:    clr  ls_ln
.ln:    jsr  lb_clr
        ldaa ls_top
        adda ls_ln
        asla                    ; move number - 1 of the line's first move
        bsr  ls_mv
        jsr  lb_sp
        ldaa ls_top
        adda ls_ln
        asla
        inca
        bsr  ls_mv
        ldaa ls_ln
        jsr  lb_put
        inc  ls_ln
        ldaa ls_ln
        cmpa kv_plines
        bne  .ln
        clra
        jsr  key_wait
        cmpb #K_UP
        bne  .dn
        tst  ls_top
        beq  .sh
        dec  ls_top
        bra  .sh
.dn:    cmpb #K_DOWN
        bne  .x
        ldaa ls_top
        adda kv_plines
        asla
        asla                    ; discs before the line after the screen
        cmpa g_n
        bhs  .sh
        inc  ls_top
        bra  .sh
.x:     rts

; A = move number - 1: "n.ab " (Solid's column, then Hollow's), if played
ls_mv:  staa ls_m
        asla
        cmpa g_n
        bhs  .x
        staa ls_d
        ldab ls_m
        incb
        clra
        jsr  lb_num
        ldaa #'.'
        jsr  lb_ch
        ldab ls_d
        bsr  .one
        ldab ls_d
        incb
        cmpb g_n
        bhs  .sp
        bsr  .one
.sp:    jmp  lb_sp
.one:   jsr  rec_get
        adda #'1'
        jmp  lb_ch
.x:     rts

; ---------------------------------------------------------------------
; L_TACT, on the way to the review (OV_MENU, OV_END): for each move that
; made no four, into RV_TAC (as defs.inc): 1 the mover had a four to make
; and didn't; 2 the other side has one now; 3 the other side has a move
; after which the mover can't stop a four (the mover has none to make,
; and the other side two, or one with another of its own just above:
; blocking that gives it the one above). 2 and 3 only when another move
; would have let neither happen. Then OV_REVIEW, which leaves the
; engine's position as the game's.
; ---------------------------------------------------------------------
tc_run: ldaa g_n
        bne  .t
        ldx  #snd_buzz          ; no moves yet
        jsr  snd_play
        clra
        rts
.t:     ldx  #RV_TAC
.z:     clr  0,x
        inx
        cpx  #RV_TAC+11
        bne  .z
        jsr  eng_reset
        clr  tc_r               ; the moves made
.m:     ldab tc_r
        cmpb g_n
        beq  .go
        jsr  rec_get
        staa tc_c
        ldaa #$0F               ; the mover's mask: Solid's after an even
        bitb #1                 ; number of moves
        beq  .h
        ldaa #$F0
.h:     staa tc_mm
        bsr  tc_thr             ; its fours to make, before the move
        stab tc_k
        ldaa tc_c
        jsr  e_make
        inc  tc_r               ; (C kept)
        bcs  .m                 ; it made four
        ldaa #1
        tst  tc_k
        bne  .st                ; missed a win
        bsr  tc_bad
        beq  .m
        staa tc_k               ; 2 or 3: could another move have helped?
        ldaa tc_c
        jsr  e_unmake
        bsr  tc_alt
        psha                    ; (A = 0: it could)
        ldaa tc_c
        jsr  e_make             ; the move again
        pula
        tsta
        bne  .m
        ldaa tc_k
.st:    ldab tc_r               ; A = the code, into its move's 2 bits
        decb
        pshb
        andb #3
.sh:    decb
        bmi  .o
        asla
        asla
        bra  .sh
.o:     pulb
        lsrb
        lsrb
        ldx  #RV_TAC
        abx
        oraa 0,x
        staa 0,x
        bra  .m
.go:    ldd  #OV_REVIEW*256
        jmp  ov_call

; before a move of the mover's (tc_mm) that would let the other side make
; four or fork: A = 0 (Z set) if another move would let neither happen
tc_alt: clr  tc_i
.a:     ldab tc_i
        bsr  tc_room
        bne  .na
        ldaa tc_i
        jsr  e_make
        bsr  tc_bad
        psha
        ldaa tc_i
        jsr  e_unmake
        pula
        tsta
        beq  .x                 ; yes
.na:    inc  tc_i
        ldab tc_i
        cmpb #7
        bne  .a
.x:     tsta                    ; (no: the move's own column left A not 0)
        rts

; ---------------------------------------------------------------------
; L_DROP: C_DROP, column kv_arg. With the coach on (one or two players),
; a drop that the review would mark is named first (OV_PANEL P_WARN, with
; X = the mark: 1 missed a win, 2 allows four, 3 allows fork). Else the
; kernel's cm_drop.
; ---------------------------------------------------------------------
dr_chk: tst  st_coach
        beq  .go
        ldaa g_mode             ; two players, the move timer run out (its
        deca                    ; seconds, kv_xsc, 0): the drop is the timer's
        bne  .c
        tst  st_timer
        beq  .c
        tst  kv_xsc
        beq  .go
.c:     ldab kv_arg
        bsr  tc_room
        bne  .go                ; full: cm_drop buzzes
        jsr  side_to_move
        ldab #$0F               ; the mover's mask: Solid's low
        deca
        beq  .s
        ldab #$F0
.s:     stab tc_mm
        tba
        bsr  tc_thr             ; its fours to make
        stab tc_k
        ldaa kv_arg
        jsr  e_make
        ldaa #0                 ; (C kept)
        bcs  .u                 ; it makes four
        inca
        tst  tc_k
        bne  .u                 ; 1: it misses one
        bsr  tc_bad             ; 2, 3 or 0
.u:     psha
        ldaa kv_arg
        jsr  e_unmake
        pula
        cmpa #1
        bcs  .go
        beq  .warn
        staa tc_k
        bsr  tc_alt
        bne  .go                ; it had to
        ldaa tc_k
.warn:  tab
        clra
        xgdx
        ldd  #OV_PANEL*256+P_WARN
        jmp  ov_call
.go:    ldab kv_arg
        jmp  cm_drop

; B = a column: Z set if it has room
tc_room:
        ldx  #e_land
        abx
        ldab 0,x
        ldx  #e_bd
        abx
        tst  0,x                ; (the stop row: 3)
        rts

; after a move of the mover's (tc_mm) that made no four: A = 2 the other
; side has a four to make, 3 it has a fork, else 0 (Z set)
tc_bad: bsr  tc_oth
        ldaa #2
        tstb
        bne  .r
        clr  tc_j               ; each reply that has room
.f:     ldab tc_j
        bsr  tc_room
        bne  .nx
        ldaa tc_j
        jsr  e_make
        ldaa tc_mm
        bsr  tc_thr             ; the mover's fours to make
        pshb
        bsr  tc_oth             ; the other side's
        pula
        tsta
        sec
        bne  .u                 ; (the mover makes four first)
        cmpb #2                 ; C clear: a fork
.u:     ldab #0
        rolb
        pshb
        ldaa tc_j
        jsr  e_unmake
        pulb
        ldaa #3
        tstb
        beq  .r
.nx:    inc  tc_j
        ldab tc_j
        cmpb #7
        bne  .f
        clra
.r:     tsta
        rts

; B = the other side's (not the mover's) fours to make now
tc_oth: ldaa tc_mm
        coma
; A = a side's mask ($0F Solid, $F0 Hollow): B = the cells where it makes
; four now (one with another of its own just above counts two)
tc_thr: staa tc_m
        clrb
        ldx  #e_land
.c:     pshx
        pshb
        ldab 0,x                ; (a full column: the stop cell, never a threat)
        ldx  #e_thr
        abx
        pulb
        ldaa 0,x
        anda tc_m
        beq  .n
        incb
        ldaa 1,x                ; (above row 5: the stop row's, 0)
        anda tc_m
        beq  .n
        incb
.n:     pulx
        inx
        cpx  #e_land+7
        bne  .c
        rts

tc_r:   fcb  0
tc_c:   fcb  0
tc_i:   fcb  0
tc_j:   fcb  0
tc_k:   fcb  0
tc_m:   fcb  0
tc_mm:  fcb  0
ls_top: fcb  0
ls_ln:  fcb  0
ls_m:   fcb  0
ls_d:   fcb  0

REC_PUT = 0
        include "krec.asm"
