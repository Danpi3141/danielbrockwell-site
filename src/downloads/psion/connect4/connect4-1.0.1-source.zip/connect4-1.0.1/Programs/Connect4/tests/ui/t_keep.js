// Keeping finished games (19 Nov): on each model, two-player games of 7 to 9 moves (a four in a column)
//  - the result's last line names the keys in turn (EXE new game, E export, MODE review, UP move
//    list), then is put back;
//  - Keep Ask (the default): EXE asks "Export game?"; ON: a new game, nothing saved; E on the
//    result exports (and the question is not asked then); EXE at the question exports;
//  - Import game lists "Last game" first (A:C4LAST, the last game finished), then each C4Gn with
//    its moves; the last game imports; ON in the list leaves the board as it was;
//  - Keep All: the result is exported as it is shown; Keep in Settings.
//   node tests/ui/t_keep.js [models...] (default cm lz64)
'use strict';
const { Game, assert } = require('./lib');
const models = process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'lz64'];
const lastLine = (g) => g.panel().map(s => s.trim())[g.m.lines - 1];
const DISC = /[⓪①-⑧]/;                  // the board's glyphs, as the emulator shows them

for (const model of models) {
  const g = new Game(model, { keep: true }).start();
  g.waitHuman(60);
  assert(g.peek('st_keep') === 0, `${model}: Keep is Ask at first`);
  g.poke('st_clock', 0); g.poke('st_timer', 0); g.poke('st_swap', 0); g.poke('st_match', 0); g.poke('st_pace', 1);
  const SEQ = [0, 1, 0, 1, 0, 1, 0];
  const finish = (cols) => {
    for (const c of cols) { if (g.peek('g_over')) break; g.drop(c); }
    g.waitFor(() => g.peek('g_over') === 2, 30);
    g.waitText(/in \d+ moves/, 10);
    g.m.runSeconds(0.3);
  };

  // ---- the keys named in turn (a two-player game)
  g.keys(['ON', 'N', 'EXE'], 0.5);
  g.waitText(/One player/, 10);
  for (let i = 0; i < 3 && !g.text().includes('>Two players'); i++) g.key('DOWN', 0.3);
  g.key('EXE', 0.5);
  g.names();
  finish(SEQ);
  const how = lastLine(g);
  assert(how === (g.m.lines === 4 ? 'EXE new game' : 'in 7 moves'), `${model}: the last line at first: "${how}"`);
  const seen = [];
  for (let t = 0; t < 18; t += 0.25) {
    g.m.runSeconds(0.25);
    const l = lastLine(g);
    if (!/^(in 7 moves|EXE new game|E export|MODE review|UP move list)$/.test(l)) continue;   // (caught mid-write)
    if (seen[seen.length - 1] !== l) seen.push(l);
  }
  const want = g.m.lines === 4
    ? ['EXE new game', 'E export', 'MODE review', 'UP move list', 'EXE new game']
    : ['in 7 moves', 'EXE new game', 'E export', 'MODE review', 'UP move list', 'in 7 moves'];
  assert(seen.slice(0, want.length).join('|') === want.join('|'), `${model}: hints ${seen.join('|')}`);
  assert(lastLine(g) === how, `${model}: the line put back: "${lastLine(g)}"`);
  console.log(`${model}: hints ${seen.join(' | ')}`);

  // ---- Keep Ask: EXE asks; ON: a new game, nothing saved
  g.key('EXE', 0.8);
  assert(/Export game\?/.test(g.text()) && /EXE=Y  ON=N/.test(g.text()), `${model}: EXE asks:\n${g.text()}`);
  g.key('ON', 1.5);
  assert(!g.peek('g_over') && g.peek('g_n') === 0, `${model}: ON: a new game`);

  // ---- E on the result exports; then no question
  finish([0].concat(SEQ.slice(1).map(c => c ^ 1), [0]));
  const rec1 = g.recStr();
  g.key('E', 0.3);
  g.waitText(/Saved C4G1/, 5);
  g.key('EXE', 1.0);
  g.waitText(/in \d+ moves/, 10);
  assert(g.peek('g_res') & 0x80, `${model}: exported: kept`);
  const seen2 = [];
  for (let t = 0; t < 9; t += 0.25) { g.m.runSeconds(0.25); const l = lastLine(g); if (seen2[seen2.length - 1] !== l) seen2.push(l); }
  assert(!seen2.includes('E export'), `${model}: kept: no "E export": ${seen2.join('|')}`);
  g.key('EXE', 1.5);
  assert(!/Export game/.test(g.text()) && !g.peek('g_over'), `${model}: kept: no question`);

  // ---- EXE at the question exports
  finish(SEQ);
  const rec2 = g.recStr();
  g.key('EXE', 0.8);
  g.waitText(/Export game\?/, 5);
  g.key('EXE', 0.3);
  g.waitText(/Saved C4G2/, 5);
  g.waitFor(() => !g.peek('g_over') && g.humanTurn(), 10);

  // ---- Import: "Last game" first, then C4G1, C4G2 with their moves; the last game imports
  g.key('ON', 0.5); g.key('I', 0.3); g.key('EXE', 0.1);
  let tl = 0.1;
  while (!/>/.test(g.panel().join('')) && tl < 8) { g.m.runSeconds(0.05); tl += 0.05; }
  console.log(`${model}: the import list up in ${tl.toFixed(2)} s`);
  g.m.runSeconds(0.3);
  const items = g.panel().map(s => s.trim()).filter(Boolean);
  console.log(`${model}: import list ${items.join(' | ')}`);
  assert(items[0] === '>Last game', `${model}: Last game first`);
  if (g.m.lines === 4) assert(items[1] === `C4G1   ${rec1.length}` && items[2] === `C4G2   ${rec2.length}`, `${model}: the list ${items.join('|')}`);
  else { g.key('DOWN', 0.4); assert(g.panel().map(s => s.trim()).includes(`>C4G1   ${rec1.length}`), `${model}: C4G1 with its moves`); g.key('UP', 0.4); }
  g.key('EXE', 2);
  g.waitFor(() => g.peek('g_over') === 2, 10);
  assert(g.recStr() === rec2, `${model}: the last game imported: ${g.recStr()} (${rec2})`);
  g.m.runSeconds(1);
  assert(DISC.test(g.text()), `${model}: the board shown (the driver read in again):\n${g.text()}`);
  g.key('EXE', 1.5);                                   // (an imported result is not kept: asked)
  assert(/Export game\?/.test(g.text()), `${model}: an imported result: asked`);
  g.key('ON', 1.5);

  // ---- ON in the list: the driver back, the board drawn
  g.waitHuman(10);
  g.drop(3);
  g.key('ON', 0.5); g.key('I', 0.3); g.key('EXE', 0.1);
  g.waitFor(() => />/.test(g.panel().join('')), 8);
  g.key('ON', 1.0);
  g.waitHuman(10);
  g.drop(3);
  g.m.runSeconds(0.5);
  assert(DISC.test(g.text()) && g.peek('g_n') === 2, `${model}: after ON in the list: the board:\n${g.text()}`);

  // ---- Keep All: exported as the result is shown
  g.poke('st_keep', 1);
  finish([1, 2, 1, 2, 1, 2, 1]);
  assert(g.peek('g_res') & 0x80, `${model}: Keep All: kept`);
  g.key('EXE', 1.5);
  assert(!/Export game/.test(g.text()), `${model}: Keep All: no question`);
  g.waitHuman(10);
  g.key('ON', 0.5); g.key('I', 0.3); g.key('EXE', 0.1);
  g.waitFor(() => />/.test(g.panel().join('')), 8);
  for (let i = 0; i < 3; i++) g.key('DOWN', 0.3);
  assert(g.panel().map(s => s.trim()).includes('>C4G3   9'), `${model}: Keep All: C4G3 (9 moves):\n${g.text()}`);
  g.key('ON', 1.0);

  // ---- Settings: Keep
  g.waitHuman(10);
  g.key('ON', 0.5); g.key('S', 0.3); g.key('S', 0.3); g.key('S', 0.3); g.key('EXE', 0.8);
  g.key('K', 0.4);
  assert(g.panel().map(s => s.trim()).includes('>Keep   All'), `${model}: Settings Keep:\n${g.text()}`);
  g.key('RIGHT', 0.4);
  assert(g.panel().map(s => s.trim()).includes('>Keep   Off') && g.peek('st_keep') === 2, `${model}: Keep Off`);
  g.key('ON', 1);
  console.log(`${model}: keep ok`);
}
console.log('keep ok');
