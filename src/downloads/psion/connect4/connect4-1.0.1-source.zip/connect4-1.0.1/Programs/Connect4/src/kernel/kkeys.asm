; ---------------------------------------------------------------------
; Keys (from Chess's kkeys.asm)
; ---------------------------------------------------------------------

; key_wait: A = frames (50 ms) to wait, 0 = until a key. Out: B = key, or 0
; if the time ran out. The packs are switched off first. Every key stirs
; the free-running timer into the random seed.
key_wait:
        staa kv_left
        tst  kv_pkok
        beq  .on
        os   PK$PKOF
        clr  kv_pkok
.on:    ldaa kv_left
        bne  .tm
        bsr  kw_sleep
        bra  kw_key
.tm:    bsr  kw_timed
kw_key: tstb
        beq  .x
        ldaa FRC+1              ; the seed: timer stirred in
        eora kv_seed
        staa kv_seed
        ldaa FRC
        adda kv_seed+1
        staa kv_seed+1
        cmpb #'a'               ; a to z become A to Z
        blo  .x
        cmpb #'z'
        bhi  .x
        subb #32
.x:     rts                     ; every way out (tests stop here)

; wait up to kv_left frames for a key: B = key or 0
kw_timed:
        ldaa TMW_FRAM+1
        staa kv_t0
.l:     ldx  TMW_TCNT           ; no switching off in a timed wait
        stx  TMW_TOUT
        os   KB$TEST
        tstb
        bne  .got
        ldaa TMW_FRAM+1
        suba kv_t0
        cmpa kv_left
        bhs  .out
        slp
        bra  .l
.got:   os   KB$GETK
        rts
.out:   clrb
        rts

; Wait for a key with no time limit, switching off after the Organiser's
; idle time (TMW_TCNT seconds, 0 = never) with BT$SWOF. The OS puts back
; its copy of the screen on switching on (all text is printed through the
; OS), but the glyphs must be sent again: the driver's entry DV_GLYPHS.
kw_sleep:
        clr  kv_aidle
        clr  kv_aidle+1
        ldaa TMW_FRAM+1
        staa kv_afr
.l:     ldx  TMW_TCNT
        stx  TMW_TOUT
        os   KB$TEST
        tstb
        bne  .key
        slp
        ldaa TMW_FRAM+1
        cmpa kv_afr
        beq  .l
        staa kv_afr
        ldd  kv_aidle
        addd #1
        std  kv_aidle
        ldx  TMW_TCNT
        beq  .l
        xgdx                    ; seconds -> frames: * 20
        asld
        asld
        std  kv_t0
        asld
        asld
        addd kv_t0
        subd kv_aidle
        bhi  .l
        os   BT$SWOF            ; off; back here when ON is pressed
        jsr  DRV+DV_GLYPHS
        os   KB$FLSH
        bra  kw_sleep
.key:   os   KB$GETK
        rts

