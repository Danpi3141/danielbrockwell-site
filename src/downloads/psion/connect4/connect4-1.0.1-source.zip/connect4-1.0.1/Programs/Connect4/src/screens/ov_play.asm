; =====================================================================
; OV_PLAY (TWO = 0: one player and the demo) and OV_PLAY2 (TWO = 1: two
; players, with the clocks, the move timer, the swap rule and the match),
; assembled from this one file. Your move: shows the panel, takes keys,
; returns a command: A = C_*, B = the column for C_DROP.
; Panel: 1 the last move and 3 the level, a solved ending or the match
; (drawn first by OV_PANEL, which then goes on to this), 2 the side to move
; and the chosen column, 4 the move number or (OV_PLAY2) the clocks.
; Stretch goals here: the ghost disc (the chosen column's landing cell
; blinks about 3 times a second; after a hint, faster for a moment) and
; the threat cells. (The Psion's newest disc blinks in OV_FX; the swap
; rule's question is in OV_GAME.)
; =====================================================================
        include "../defs.inc"

BLINK   = 6                     ; frames (50 ms) a blink lasts
FLASH   = 2                     ; after a hint
IDLE    = 50                    ; blinks before the ghost rests (the Organiser may switch off)

pl_start:                       ; (the one entry: the slot's first byte)
        jsr  side_to_move
        staa pl_side
        if   TWO
        ldab pl_tmr             ; the move timer goes on where it was (after the
        bne  .tm                ; menu, the list, the coach: until 19 Nov it
        ldaa st_timer           ; started again), else 10, 20, 30 s
        ldab #10
        mul
        stab pl_tmr
.tm:    ldaa TMW_FRAM+1
        staa pl_sec
        endif
        bsr  pl_fix             ; a chosen column with room
        if   TWO
        bsr  pl_show4           ; (OV_PANEL has drawn lines 1 and 3)
        endif
        ldaa #IDLE
        staa pl_idle
.loop:  bsr  pl_show2
.wait:  bsr  pl_ghost           ; the ghost disc on (or off)
        ldaa #BLINK
        if   1-TWO              ; (after a hint: two players have none)
        tst  kv_flash
        beq  .w
        dec  kv_flash
        ldaa #FLASH
        endif
.w:     tst  pl_idle            ; resting: wait for a key (switching off may happen)
        bne  .t
        if   TWO
        tst  st_clock           ; (two players: only with no clock or move timer
        bne  .t                 ; running; until 19 Nov never)
        tst  pl_tmr
        bne  .t
        endif
        clra
.t:     jsr  key_wait
        tstb
        bne  .key
        tst  pl_idle
        beq  .tk
        dec  pl_idle
.tk:    com  pl_gon             ; the blink
        if   1-TWO
        bsr  pl_thr             ; the coach on: threat cells blink slowly
        endif
        if   TWO
        bsr  pl_tick            ; a whole second passed? clocks, timer
        bcs  .out
        endif
        bra  .wait
.key:   pshb
        clr  pl_gon             ; the ghost off before anything else
        bsr  pl_ghost
        if   1-TWO
        clr  kv_flash           ; (a key ends the hint's fast blink and its label)
        endif
        pulb
        ldaa #IDLE
        staa pl_idle
        cmpb #K_LEFT
        bne  .r
        ldaa #$FF
        bra  .mv
.r:     cmpb #K_RIGHT
        bne  .e
        ldaa #1
.mv:    bsr  pl_step
        bra  .loop
.e:     cmpb #K_EXE
        beq  .drop
        cmpb #K_DOWN
        beq  .drop
        ldx  #pl_keys           ; commands on single keys
.k:     ldaa 0,x
        beq  .dig
        cmpb 0,x
        beq  .cmd
        inx
        inx
        bra  .k
.cmd:   ldaa 1,x
        clrb                    ; (no argument: the coach is asked)
        if   1-TWO
        cmpa #C_HINT            ; hints off: a buzz, and on
        bne  .out
        tst  st_hints
        beq  .out
        ldx  #snd_buzz
        jsr  snd_play
        jmp  .loop
        endif
.out:   rts
.dig:   ldx  #pl_dk             ; a digit key: 1-7, or the letter it is on
        clra
.d:     cmpb 0,x
        beq  .dg
        cmpb 7,x
        beq  .dg
        inx
        inca
        cmpa #7
        bne  .d
        bra  .loop
.dg:    staa g_chosen
        tst  st_digits
        bne  .drop
        bra  .loop
.drop:  ldab g_chosen
        ldaa #C_DROP
        rts

pl_keys: fcb K_DEL,C_BACK, K_MODE,C_COACH, K_UP,C_LIST, K_ON,C_MENU
        if   1-TWO
        fcb  K_SPACE,C_HINT     ; (two players: no hints, as the spec has them off)
        endif
        fcb  0
pl_dk:  fcc  "1234567"
        fcc  "UVWOPQI"

; the ghost disc: pl_gon set - the side's disc in the chosen column's
; landing cell, clear - the cell as it is. Drawn by putting the disc on
; the board for a moment (the driver draws from the board).
pl_ghost:
        ldab g_chosen
        ldx  #e_land
        abx
        ldab 0,x                ; the landing cell
        stab pl_cell
        ldx  #e_bd
        abx
        ldaa 0,x
        cmpa #3
        beq  .x                 ; (full)
        tst  pl_gon
        beq  .d
        ldaa pl_side
        staa 0,x
.d:     stx  pl_gx
        ldaa g_chosen           ; row = cell - column * 7
        ldab #7
        mul
        negb
        addb pl_cell
        ldaa g_chosen
        jsr  DRV+DV_CELL
        ldx  pl_gx
        clr  0,x                ; (empty again on the board)
.x:     rts

        if   1-TWO
; stretch goal 6: with the coach on, every empty cell where a side would
; make four blinks slowly in that side's disc (every 4 blinks: on, off)
pl_thr: tst  st_coach
        beq  .x
        inc  pl_tc
        ldaa pl_tc
        anda #3
        bne  .x
        ldaa pl_tc
        anda #4
        beq  .off
        ldx  #e_bd              ; on: the threats into the board, shown, out again
.l:     ldaa 0,x
        bne  .n
        ldab 49,x               ; its threat byte
        beq  .n
        ldaa #1                 ; Solid's (or both: Solid's shown)
        bitb #$0F
        bne  .s
        ldaa #2
.s:     staa 0,x
.n:     inx
        cpx  #e_bd+49
        bne  .l
        jsr  DRV+DV_BOARD
        ldx  #e_bd
.c:     ldab 49,x               ; (a threat byte is only set on empty cells)
        beq  .cn
        ldaa 0,x
        cmpa #3
        beq  .cn
        clr  0,x
.cn:    inx
        cpx  #e_bd+49
        bne  .c
        rts
.off:   jmp  DRV+DV_BOARD
.x:     rts
        endif

; a chosen column with room: the one chosen, else the nearest to the centre
pl_fix: ldaa g_chosen
        bsr  pl_room
        bcc  .x
        ldx  #e_order
.l:     ldaa 0,x
        inx
        bsr  pl_room
        bcs  .l
        staa g_chosen
.x:     rts

; C clear if column A (0-6) has room
pl_room:
        cmpa #7
        bhs  .no
        tab
        pshx
        ldx  #e_land
        abx
        ldab 0,x
        ldx  #e_bd
        abx
        ldab 0,x
        pulx
        cmpb #3
        beq  .no
        clc
        rts
.no:    sec
        rts

; A = +1 or -1: the next column with room that way
pl_step:
        staa pl_dir
        ldaa g_chosen
.l:     adda pl_dir
        cmpa #7
        bhs  .x                 ; (off the edge: stay)
        psha
        bsr  pl_room
        pula
        bcs  .l
        staa g_chosen
.x:     rts

; the side's name (A = the side to move): X = string. One player: it is
; you; two players: the player's name, else Solid or Hollow
pl_name:
        if   1-TWO
        ldx  #pl_you
        tst  kv_flash           ; just after a hint: "Hint: col 5"
        beq  .x
        ldx  #pl_hnt
.x:     rts
pl_you: fcl  "You"
pl_hnt: fcl  "Hint"
        else
        ldx  #g_names           ; two players: the player's name, if any
        cmpa g_p1
        beq  .p1
        ldab #7
        abx
.p1:    tst  0,x
        bne  .x
        ldx  #pl_sol
        cmpa #1
        beq  .x
        ldx  #pl_hol
.x:     rts
pl_sol: fcl  "Solid"
pl_hol: fcl  "Hollow"
        endif

; the side's disc on four lines, then its name
pl_who: psha
        ldab kv_plines
        cmpb #4
        bne  .n
        jsr  DRV+DV_MARK
        jsr  lb_ch
.n:     pula
        bsr  pl_name
        jmp  lb_fcl

; " col N" fitted to the line: padded to column 7 (6 on two lines, with
; no disc mark), the space before N only if there is room. A = column.
pl_col: psha
        ldab kv_plines
        lsrb
        addb #5                 ; 7 on four lines, 6 on two
.pad:   cmpb kv_lp
        bls  .c
        pshb
        jsr  lb_sp
        pulb
        bra  .pad
.c:     ldab kv_lp              ; a space before "col" when it fits and the
        cmpb #7                 ; line does not end in one
        bhi  .cl
        ldx  #kv_lb-1
        abx
        ldaa 0,x
        cmpa #' '
        beq  .cl
        jsr  lb_sp
.cl:    jsr  lb_s
        fcl  "col"
        ldab kv_lp
        cmpb #10
        bhi  .d
        jsr  lb_sp
.d:     pula
        adda #'1'
        jmp  lb_ch

; line 2: the side to move and the chosen column
pl_show2:
        jsr  lb_clr
        ldaa pl_side
        bsr  pl_who
        ldaa #':'
        jsr  lb_ch
        ldaa g_chosen
        if   TWO
        tst  pl_tmr             ; the move timer: "Hollow:4 17" (with "col" the
        beq  .c                 ; seconds did not fit: until 19 Nov never shown)
        adda #'1'
        jsr  lb_ch
        jsr  lb_sp
        ldab pl_tmr
        clra
        jsr  lb_num
        bra  .p
.c:
        endif
        bsr  pl_col
.p:     ldaa #1
        jmp  lb_put

        if   TWO
; line 4: the clocks, or the move number
pl_show4:
        jsr  lb_clr
        tst  st_clock
        beq  .mv
        ldd  g_clk              ; the clocks: Solid's, then Hollow's
        bsr  pl_mmss
        jsr  lb_sp
        jsr  lb_sp
        ldd  g_clk+2
        bsr  pl_mmss
        ldaa kv_plines          ; two lines: on line 1, in place of the last
        suba #2                 ; move (until 19 Nov not shown at all)
        beq  .p5
        bra  .p4
.mv:    jsr  lb_s
        fcl  "Move "
        ldab g_n
        incb
        clra
        jsr  lb_num
.p4:    ldaa #3
.p5:    jmp  lb_put

; D = seconds as m:ss
pl_mmss:
        xgdx
        ldd  #60
        os   UT$UDIV            ; X = minutes, D = seconds
        pshb
        xgdx
        jsr  lb_num
        ldaa #':'
        jsr  lb_ch
        pulb
        clra
        cmpb #10
        bhs  .n
        pshb
        ldaa #'0'
        jsr  lb_ch
        pulb
        clra
.n:     jmp  lb_num

; a blink passed: if a whole second has, the clocks and the move timer.
; C set with A, B = a command when one ends the move.
pl_tick:
        ldaa TMW_FRAM+1
        suba pl_sec
        cmpa #20
        bhs  .sec
        clc
        rts
.sec:   ldaa pl_sec
        adda #20
        staa pl_sec
        tst  st_clock
        beq  .t
        ldx  #g_clk
        ldaa pl_side
        cmpa #1
        beq  .c
        inx
        inx
.c:     ldd  0,x
        beq  .t
        subd #1
        std  0,x
        bne  .sh
        ldaa #C_FLAG            ; out of time
        sec
        rts
.sh:    bsr  pl_show4
.t:     tst  pl_tmr
        beq  .x
        dec  pl_tmr
        bne  .sh2
        ldaa #C_DROP            ; the timer: the disc drops in the chosen column
        ldab g_chosen
        sec
        rts
.sh2:   bsr  pl_show2
.x:     clc
        rts

        endif


pl_side: fcb 0
pl_dir: fcb  0
pl_gon: fcb  0
pl_idle: fcb 0
pl_cell: fcb 0
pl_gx:  fdb  0
        if   TWO
pl_tmr  = kv_xsc                ; the move timer's seconds left: kept while the
pl_sec: fcb  0                  ; overlay is away (two players have no solved
        endif                   ; scores; a move or g_replay clears it)
        if   1-TWO
pl_tc:  fcb  0
        endif
