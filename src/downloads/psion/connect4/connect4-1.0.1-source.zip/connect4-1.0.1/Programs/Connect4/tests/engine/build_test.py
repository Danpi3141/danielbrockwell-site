"""Assembles tests/engine/etest.asm (the engine + test drivers) for harness.js."""
import json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', '..', 'tools'))
import asm
a = asm.assemble(os.path.join(HERE, 'etest.asm'), incdirs=[os.path.join(HERE, '..', '..', 'src', 'engine'), os.path.join(HERE, '..', '..', 'src')])
out = os.path.join(HERE, 'out')
os.makedirs(out, exist_ok=True)
open(os.path.join(out, 'etest.bin'), 'wb').write(a.out)
json.dump({'fix': a.fix, 'sym': {k: v[0] for k, v in a.symbols().items()}, 'seg': {k: v[1] for k, v in a.symbols().items()}}, open(os.path.join(out, 'etest.json'), 'w'))
open(os.path.join(out, 'etest.lst'), 'w').write(a.listing_text())
print('etest: %d bytes, %d fix-ups' % (len(a.out), len(a.fix)))
