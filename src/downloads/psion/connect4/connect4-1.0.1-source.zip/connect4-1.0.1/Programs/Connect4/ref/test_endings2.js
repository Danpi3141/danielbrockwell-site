// Exact endings on realistic positions: engine-v-engine games (level 6) from Tromp's 8-ply
// positions, stopped at 14..8 empty cells; the engine's exact search against the solver.
'use strict';
const E = require('./engine'), S = require('../tools/solver/solver'), T = require('../tools/solver/tromp');
S.ttInit();
const db = T.load();
let rnd = 77; const rand = n => { rnd = (rnd * 1103515245 + 12345) & 0x7fffffff; return rnd % n; };
const N = +(process.argv[2] || 60);
let ok = 0, bad = 0, nodes = 0, made = 0, tries = 0;
while (made < N && tries < N * 20) {
  tries++;
  const start = db[rand(db.length)];
  // a move order for the 8-ply position
  const p = S.clone(start.p);
  const cols = require('./strength_moves')(p);
  const e = new E.Engine(); for (const c of cols) e.make(c);
  const q = S.clone(start.p);
  const stopAt = 8 + rand(7);               // empty cells left: 8..14
  let dead = false;
  while (42 - q.n > stopAt) {
    const r = e.think({ nodes: 3000 });
    if (S.isWinningMove(q, r.move)) { dead = true; break; }
    e.make(r.move); S.play(q, r.move);
  }
  if (dead || S.canWinNext(q)) continue;
  made++;
  const truth = S.solve(q, false);
  const want = truth > 0 ? 100 - S.pliesToEnd(truth, q.n) : truth < 0 ? -(100 - S.pliesToEnd(truth, q.n)) : 0;
  const r = e.think({});
  nodes += r.nodes;
  const an = S.analyse(q, false);
  if (r.score === want && r.exact && an[r.move] === truth) ok++;
  else { bad++; console.log('mismatch at', 42 - q.n, 'empty: engine', r.score, 'want', want, 'move', r.move + 1, an); }
}
console.log(`realistic endings: ${ok} right, ${bad} wrong of ${made}; ${Math.round(nodes / Math.max(made, 1))} positions on average (${(nodes / Math.max(made, 1) / 300).toFixed(1)} s at 300 a second)`);
