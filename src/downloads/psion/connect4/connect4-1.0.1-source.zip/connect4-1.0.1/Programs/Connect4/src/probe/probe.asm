; =====================================================================
; Milestone 1 probe: loaded by the bootstrap like the kernel will be.
; Records in v%(): v%(7) model byte, v%(8) D after DP$MSET 1 (LZ only),
; v%(9) the free-running counter at two moments (difference: cycles for
; one glyph's 8 rows written to the display chip).
; Shows glyphs 0 and 1 (0 has its 8th row set) and waits for a key.
; =====================================================================
        include "../defs.inc"

entry:  jmp  start
        fcc  "C4K1"

start:  std  vptr
        ldx  vptr
        ldab MODEL
        clra
        std  12,x               ; v%(7)
        clr  islz
        cmpb #13
        beq  .lz
        cmpb #14
        beq  .lz
        cmpb #29
        beq  .lz
        cmpb #30
        bne  .two
.lz:    inc  islz
        ldaa #1
        os   DP$MSET            ; four-line mode
        ldx  vptr
        std  14,x               ; v%(8) = what it returns
        staa oldmode
        ldab #$80
        os   DP$CSET            ; the clock leaves the glyphs alone
.two:   clra
        clrb
        os   DP$STAT            ; cursor off
        ldaa #12
        os   DP$EMIT            ; clear the screen
        ; glyphs 0 and 1 straight into the display chip's CG RAM
        ldd  FRC
        std  t0
        ldab #$40
        bsr  lcdcmd
        ldx  #glyphs
.g:     ldab 0,x
        bsr  lcddat
        inx
        cpx  #glyphs+8
        bne  .g
        ldd  FRC
        subd t0
        ldx  vptr
        std  16,x               ; v%(9) = cycles for one glyph
        ldab #$48
        bsr  lcdcmd
        ldx  #glyphs+8
.g2:    ldab 0,x
        bsr  lcddat
        inx
        cpx  #glyphs+16
        bne  .g2
        ldx  #msg
        ldab #msgend-msg
        os   DP$PRNT
        os   KB$GETK
        tst  islz
        beq  .out
        ldaa oldmode
        os   DP$MSET            ; back to the mode we found
.out:   ldx  #0
        rts

; B to the display chip's instruction / data register, waiting while busy
lcdcmd: ldaa LCD_CTRL
        bmi  lcdcmd
        stab LCD_CTRL
        rts
lcddat: ldaa LCD_CTRL
        bmi  lcddat
        stab LCD_DATA
        rts

glyphs: fcb  $1F,$11,$11,$11,$11,$11,$11,$1F
        fcb  $1F,$1F,$1F,$1F,$1F,$1F,$1F,$1F
msg:    fcc  "UDG"
        fcb  0,1,0,1
        fcc  " OK"
msgend:

vptr:   fdb  0
t0:     fdb  0
islz:   fcb  0
oldmode: fcb 0
