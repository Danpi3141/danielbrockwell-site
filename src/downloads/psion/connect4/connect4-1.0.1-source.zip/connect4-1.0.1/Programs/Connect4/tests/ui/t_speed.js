// Positions a second in the game (the OS running): every search of a game at a level is timed
// from the start of think_run to its return (breakpoints by listing address).
'use strict';
const fs = require('fs'), path = require('path');
const { Game } = require('./lib');
const lst = fs.readFileSync(path.join(__dirname, '..', '..', 'build', 'game', 'kernel.lst'), 'utf8').split(/\r?\n/);
const after = parseInt(lst[lst.findIndex(l => /jsr\s+think\s*$/.test(l)) + 1].slice(0, 4), 16);
const model = process.argv[2] || 'lz64', level = +(process.argv[3] || 6), games = +(process.argv[4] || 2);
let tn = 0, tc = 0, n = 0;
for (let gi = 0; gi < games; gi++) {
  const g = new Game(model).start();
  g.waitHuman(60);
  g.poke('st_level', level); g.poke('st_pace', 1); g.poke('st_you', gi % 2); g.poke('st_dlv1', level); g.poke('st_dlv2', level);
  g.key('ON', 0.4); g.key('EXE', 0.4); g.key('DOWN', 0.3); g.key('DOWN', 0.3); g.key('EXE', 1);   // demo: both sides search
  const start = g.a('think_run'), done = g.base + after;
  let c0 = 0;
  for (let k = 0; k < 40 && !g.peek('g_over'); k++) {
    const h1 = g.m.runTo([start], 921600 * 120); if (h1 !== start) { console.log('no start', h1, g.text()); break; }
    c0 = g.m.cycles(); g.m.cpu.execute(1);
    const h2 = g.m.runTo([done], 921600 * 600); if (h2 !== done) { console.log('no done', h2, done.toString(16), g.text()); break; }
    const nodes = g.peekw('e_nodes'), cyc = g.m.cycles() - c0;
    g.m.cpu.execute(1);
    if (nodes > 200) { tn += nodes; tc += cyc; n++; }
  }
}
console.log(`${model} level ${level}: ${n} searches, ${tn} positions, ${(tn * 921600 / tc).toFixed(0)} positions a second with the OS`);
