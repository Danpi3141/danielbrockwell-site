// A tour of the game's screens on each display, saved as PNG screenshots for reviewing the UI:
//   node tests/ui/tour.js [cm|lz64 ...]  ->  build/shots/<model>/NN_name.png, index.json
'use strict';
const fs = require('fs'), path = require('path');
const { Game, ROOT } = require('./lib');
const { screenshot } = require('./shots');

const models = process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'lz64'];
const index = {};
for (const model of models) {
  const dir = path.join(ROOT, 'build', 'shots', model);
  fs.mkdirSync(dir, { recursive: true });
  for (const f of fs.readdirSync(dir)) fs.unlinkSync(path.join(dir, f));
  const list = index[model] = [];
  let n = 0;
  const g = new Game(model);
  const shot = (name, note = '') => {
    const file = `${String(++n).padStart(2, '0')}_${name}.png`;
    fs.writeFileSync(path.join(dir, file), screenshot(g.m));
    list.push({ file, name, note, text: g.text() });
  };
  const step = (name, fn) => { try { fn(); } catch (e) { list.push({ name, error: e.message.split('\n')[0] }); console.log(model, name, 'FAILED', e.message.split('\n')[0], JSON.stringify(g.text()), 'n', g.peek('g_n'), 'res', g.peek('kv_res'), 'over', g.peek('g_over')); } };
  const menu = (letter, times = 1, wait = 0.8) => { g.key('ON', 0.5); for (let i = 0; i < times; i++) g.key(letter, 0.3); g.key('EXE', wait); };
  const newGame = (mode) => {
    g.key('ON', 0.4); g.key('N', 0.3); g.key('EXE', 0.5);
    const want = ['One player', 'Two players', 'Demo'][mode];
    for (let i = 0; i < 3 && !g.text().includes('>' + want); i++) g.key('DOWN', 0.3);
    g.key('EXE', 0.5);
  };

  step('title', () => {
    g.start(); g.m.runSeconds(0.3); shot('title', 'the title, as the game starts');
  });
  step('start', () => {
    g.waitHuman(60);
    g.poke('st_pace', 1); g.poke('st_level', 3); g.poke('st_you', 0); g.poke('st_coach', 1);
    newGame(0); g.waitHuman(30); g.m.runSeconds(0.3);
    shot('your_turn', 'one player, a new game, your move');
    g.key('RIGHT', 0.3); g.key('RIGHT', 0.3); shot('cursor_moved', 'the chosen column moved right twice');
    g.key('LEFT', 0.3); g.key('LEFT', 0.3);
  });
  step('psion_book', () => {
    g.key('W', 0.2); g.key('EXE', 0.05); g.m.runSeconds(0.25); shot('disc_falling', 'your disc falling');
    g.m.runSeconds(0.5); shot('psion_turn', 'the Psion\'s turn (book)');
    g.waitHuman(30); g.m.runSeconds(0.2); shot('after_psion', 'your move again, the Psion\'s disc blinking');
  });
  step('menu', () => {
    g.key('ON', 0.6); shot('menu_top', 'the menu (ON)');
    for (let i = 0; i < 6; i++) g.key('DOWN', 0.15);
    g.m.runSeconds(0.3); shot('menu_down', 'the menu, six items down');
    g.key('ON', 0.6);
  });
  step('newgame_kinds', () => {
    g.key('ON', 0.4); g.key('N', 0.3); g.key('EXE', 0.6); shot('new_game_kind', 'New game: which kind');
    g.key('ON', 0.6); g.waitHuman(10);
  });
  step('level', () => { menu('L'); shot('level', 'Level'); g.key('ON', 0.8); g.waitHuman(10); });
  step('settings', () => {
    menu('S', 3); shot('settings', 'Settings');
    for (let i = 0; i < 3; i++) g.key('DOWN', 0.2);
    g.m.runSeconds(0.2); shot('settings_down', 'Settings, three down');
    for (let i = 0; i < 5; i++) g.key('DOWN', 0.2);
    g.m.runSeconds(0.2); shot('settings_more', 'Settings, eight down');
    g.key('ON', 0.8); g.waitHuman(10);
  });
  step('hint', () => {
    g.key('SPACE', 0.6); shot('hint_thinking', 'Hint: the search');
    g.waitFor(() => !/depth/.test(g.text()), 30); g.m.runSeconds(0.1); shot('hint_shown', 'Hint: the suggested column');
    g.m.runSeconds(2); shot('hint_later', 'Hint: a moment later');
  });
  step('list', () => { g.key('UP', 0.6); shot('move_list', 'Move list (UP)'); g.key('EXE', 0.6); });
  step('coach', () => { g.key('MODE', 1.0); shot('coach', 'the coach (MODE)'); g.key('EXE', 0.6); });
  step('help', () => {
    menu('H', 2); shot('help_1', 'Help');
    g.key('DOWN', 0.4); shot('help_2', 'Help, next');
    g.key('ON', 0.8); g.waitHuman(10);
  });
  step('setup', () => { menu('S', 2); shot('set_up', 'Set up'); g.key('ON', 1.2); g.waitHuman(10); });
  step('export', () => { menu('E'); shot('export', 'Export game'); g.key('EXE', 0.6); g.waitHuman(10); });
  step('import', () => { menu('I'); g.m.runSeconds(0.5); shot('import', 'Import game: the list'); g.key('ON', 1.0); g.waitHuman(10); });
  step('search', () => {
    newGame(0); g.waitHuman(30);
    g.poke('st_level', 6);
    for (const c of [3, 2, 4, 1, 5]) {
      if (g.peek('g_over')) break;
      g.drop(c);
      let got = false;
      for (let t = 0; t < 200 && !got; t++) { g.m.runSeconds(0.25); if (/depth +\d+ +[1-9]\d*s/.test(g.text()) && /\[=/.test(g.text())) got = true; }
      if (got) { shot('thinking', 'the Psion searching: depth, seconds, the bar'); break; }
      g.waitHuman(120);
    }
    g.waitFor(() => g.humanTurn() || g.peek('g_over'), 120);
  });
  step('review', () => {
    menu('R'); g.m.runSeconds(0.5); shot('review', 'Review game');
    g.key('LEFT', 0.5); shot('review_back', 'Review game, one move back');
    g.key('ON', 1.0);
  });
  step('resign', () => {
    g.waitHuman(30); menu('R', 2, 2); shot('resigned', 'the result after resigning');
    g.m.runSeconds(2.2); shot('result_keys', 'the result, 2 s on: the last line names the keys in turn');
    g.poke('st_keep', 0);                      // (lib sets Keep Off for the tests)
    g.key('EXE', 0.8); shot('keep_ask', 'EXE on a result not exported (Keep: Ask)');
    g.key('EXE', 0.4); shot('keep_saved', 'EXE: exported, then a new game');
    g.m.runSeconds(1.5); g.poke('st_keep', 2);
  });
  step('import_last', () => {
    g.waitHuman(30); menu('I', 1, 2.5); shot('import_last', 'Import game: the last game first, then each with its moves');
    g.key('ON', 1.0); g.waitHuman(10);
  });
  step('demo_result', () => {
    g.poke('st_dlv1', 1); g.poke('st_dlv2', 2);
    newGame(2);
    g.waitFor(() => g.peek('g_n') >= 3, 30); shot('demo', 'Demo');
    g.waitFor(() => g.peek('g_over') === 2, 300); g.m.runSeconds(1.0);
    shot('result_four', 'a result with a four (demo)');
    g.m.runSeconds(0.6); shot('result_four_b', 'the same a moment later');
    g.key('EXE', 1.5);
  });
  step('two_players', () => {
    g.waitFor(() => /New game/.test(g.text()) || g.humanTurn(), 10);
    if (/New game/.test(g.text())) g.key('ON', 0.6);
    g.poke('st_clock', 2); g.poke('st_swap', 1); g.poke('st_timer', 3);
    newGame(1);
    g.waitFor(() => /Player/.test(g.text()), 5); shot('name_prompt', 'Two players: a name');
    for (const ch of 'ANN') g.key(ch, 0.15);
    shot('name_typed', 'Two players: a name typed');
    g.key('EXE', 0.5); g.key('EXE', 1.0);
    g.waitHuman(10); shot('two_play', 'two players with the clock');
    g.drop(3); g.m.runSeconds(1.0); shot('swap_question', 'after the first disc (swap rule on)');
    g.key('ON', 1.0); g.waitHuman(10); g.m.runSeconds(1.2); shot('two_play_clock', 'two players, a move made, the clocks running');
    g.drop(2); g.m.runSeconds(1.2); shot('two_play_clock_b', 'the other player');
  });
  fs.writeFileSync(path.join(dir, 'index.json'), JSON.stringify(list, null, 1));
  console.log(model, list.length, 'steps,', list.filter(x => x.error).length, 'failed');
}
