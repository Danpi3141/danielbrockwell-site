// Connect 4 reference engine: the model the 6303 engine (src/engine) is matched against,
// node for node. Every structure mirrors a byte table of the assembler version.
//
// Cells: c = col*7 + row (row 0 = bottom .. 5; row 6 of each column is a stop).
// bd[c]   0 empty, 1 Solid, 2 Hollow, 3 stop
// ht[col] discs in the column
// lc[L]   line L's counts: Solid in the low nibble, Hollow in the high nibble
// thr[c]  threat counts: lines that would give Solid (low nibble) / Hollow (high) four at c
// ev      open-line score, Solid minus Hollow (16-bit): 1, 3, 9 for 1, 2, 3 discs
// key     24-bit hash (bytes k0 k1 k2); the transposition table's index is k0 & 127, its
//         13-bit check is k1 and the low 5 bits of k2
'use strict';

// ---------------- constant tables (src/engine/etab.inc is generated from these) ----------------
const STEP = [];          // per line: cell step 1 (up), 7 (across), 8 (up-right), 6 (up-left)
const LSTART = [];        // per line: first cell
for (let c = 0; c < 7; c++) for (let r = 0; r < 3; r++) { LSTART.push(c * 7 + r); STEP.push(1); }
for (let r = 0; r < 6; r++) for (let c = 0; c < 4; c++) { LSTART.push(c * 7 + r); STEP.push(7); }
for (let c = 0; c < 4; c++) for (let r = 0; r < 3; r++) { LSTART.push(c * 7 + r); STEP.push(8); }
for (let c = 0; c < 4; c++) for (let r = 3; r < 6; r++) { LSTART.push(c * 7 + r); STEP.push(6); }   // down-right
const NLINES = LSTART.length;   // 69
function lineStep(L) { return L < 21 ? 1 : L < 45 ? 7 : L < 57 ? 8 : 6; }
// cell -> lines through it
const CLINES = [];
for (let c = 0; c < 49; c++) CLINES.push([]);
for (let L = 0; L < NLINES; L++) for (let i = 0; i < 4; i++) CLINES[LSTART[L] + i * lineStep(L)].push(L);
const ORDER = [3, 2, 4, 1, 5, 0, 6];
const W = [0, 1, 3, 9];

// cell keys, computed with the 6303's 8x8 multiply (until 19 Nov an 84-byte table): real cell
// i = col*6+row, t = 2i: x = t + $CD, y = lo(x * $79), d = y * y; bytes b0 = hi(d),
// b1 = lo(d) ^ y, b2 = hi(y * $95). Solid's key is (b0, b1, b2), Hollow's the same bytes rotated
// (b1, b2, b0). Collisions on every position up to 8 discs and on sampled deeper ones are those of
// random keys (the table's were a little worse).
function cellBytes(c) {
  const t = (c - Math.floor(c / 7)) * 2;
  const x = (t + 0xcd) & 255, y = (x * 0x79) & 255, d = y * y;
  return [d >> 8, (d & 255) ^ y, (y * 0x95) >> 8];
}
function cellKey(c, side) {
  const [b0, b1, b2] = cellBytes(c);
  return side === 1 ? (b0 | b1 << 8 | b2 << 16) : (b1 | b2 << 8 | b0 << 16);
}

// levels: [node limit (0 = fixed depth), fixed depth, noise k, book moves]
const LEVELS = [
  null,
  { nodes: 0, depth: 2, noise: 48, book: 0 },
  { nodes: 0, depth: 2, noise: 24, book: 0 },
  { nodes: 600, depth: 0, noise: 12, book: 0 },
  { nodes: 900, depth: 0, noise: 6, book: 2 },
  { nodes: 1500, depth: 0, noise: 0, book: 3 },
  { nodes: 3000, depth: 0, noise: 0, book: 4 },
  { nodes: 9000, depth: 0, noise: 0, book: 99 },
  { nodes: 30000, depth: 0, noise: 0, book: 99 },
];

const WIN = 100;
const TT_N = 128;
const MAXPLY = 20;            // search frames (level 8 reached 17 at most in 900 searches with over 20 empty)

function sb(v) { v &= 255; return v > 127 ? v - 256 : v; }   // signed byte

class Engine {
  constructor(opts) {
    // experiment options (19 Nov 2026; all off = the engine the 6303 matches):
    //  weak  the last iteration (to the end of the game) with the window (-1, 1): win/draw/loss
    //  pvs   later moves searched with a null window first;  asp  aspiration window at the root
    //  hist  history ordering of the centre-out moves;  k2  a second killer;  tt2  2-way buckets
    this.opts = Object.assign({ tt: TT_N }, opts || {});
    this.pGood = this.opts.pGood || 16;     // a threat on its side's good rows (spec: 16)
    this.pOther = this.opts.pOther !== undefined ? this.opts.pOther : 4;
    this.reset();
  }

  reset() {
    this.bd = new Array(49).fill(0);
    for (let c = 0; c < 7; c++) this.bd[c * 7 + 6] = 3;
    this.ht = new Array(7).fill(0);
    this.lc = new Array(NLINES).fill(0);
    this.thr = new Array(49).fill(0);
    this.ev = 0;
    this.key = 0;
    this.n = 0;               // discs on the board
    this.won = 0;             // side that made four (set by make, cleared by unmake)
    this.hist = [];
    this.tt = new Array(this.opts.tt * 4).fill(0);
    this.seed = 0x5A3C;
  }

  side() { return (this.n & 1) ? 2 : 1; }   // to move

  // ---------- make / unmake ----------
  // Plays column col for the side to move. Returns 1 if it made four.
  make(col) {
    const s = this.side();
    const c = col * 7 + this.ht[col];
    this.bd[c] = s;
    this.ht[col]++;
    this.n++;
    this.key ^= cellKey(c, s);
    const sh = s === 1 ? 0 : 4, oh = 4 - sh;
    const sgn = s === 1 ? 1 : -1;
    let four = 0;
    for (const L of CLINES[c]) {
      const v = this.lc[L];
      const own = (v >> sh) & 15, opp = (v >> oh) & 15;
      if (opp === 0) {
        this.ev += sgn * (W[own + 1 > 3 ? 3 : own + 1] - W[own]);   // a four keeps the 9 (game over anyway)
        if (own + 1 === 4) four = 1;
        else if (own + 1 === 3) this.thr[this.emptyOf(L)] += 1 << sh;
      } else if (own === 0) {
        // the line dies: the opponent's score goes, and its threat (necessarily at c)
        this.ev += sgn * W[opp];
        if (opp === 3) this.thr[c] -= 1 << oh;
      }
      this.lc[L] = v + (1 << sh);
    }
    if (four) this.won = s;
    this.hist.push(col);
    return four;
  }

  unmake() {
    const col = this.hist.pop();
    this.ht[col]--;
    const c = col * 7 + this.ht[col];
    const s = this.bd[c];
    this.n--;
    this.key ^= cellKey(c, s);
    const sh = s === 1 ? 0 : 4, oh = 4 - sh;
    const sgn = s === 1 ? 1 : -1;
    this.won = 0;
    for (const L of CLINES[c]) {
      const v = this.lc[L] - (1 << sh);
      this.lc[L] = v;
      const own = (v >> sh) & 15, opp = (v >> oh) & 15;
      if (opp === 0) {
        this.ev -= sgn * (W[own + 1 > 3 ? 3 : own + 1] - W[own]);
        if (own + 1 === 3) this.thr[this.emptyOf(L)] -= 1 << sh;   // (c still holds the disc)
      } else if (own === 0) {
        this.ev -= sgn * W[opp];
        if (opp === 3) this.thr[c] += 1 << oh;
      }
    }
    this.bd[c] = 0;
    return col;
  }

  // the one empty cell of a line holding three of one side
  emptyOf(L) {
    let c = LSTART[L];
    const d = lineStep(L);
    while (this.bd[c]) c += d;
    return c;
  }

  // ---------- queries ----------
  canPlay(col) { return this.ht[col] < 6; }
  // cell where the side would land in column col, or -1
  landing(col) { return this.ht[col] < 6 ? col * 7 + this.ht[col] : -1; }
  // playable threat cells of side s: bitmask of columns
  playable(s) {
    const sh = s === 1 ? 0 : 4;
    let m = 0;
    for (let col = 0; col < 7; col++) {
      if (this.ht[col] < 6 && ((this.thr[col * 7 + this.ht[col]] >> sh) & 15)) m |= 1 << col;
    }
    return m;
  }

  // ---------- evaluation (side to move's view) ----------
  evalRaw() {
    let par = 0;   // Solid minus Hollow
    for (let col = 0; col < 7; col++) {
      let seenS = 0, seenH = 0;
      for (let r = this.ht[col]; r < 6; r++) {
        const t = this.thr[col * 7 + r];
        if (!t) continue;
        const odd = (r & 1) === 0;   // rows 1, 3, 5
        if ((t & 15) && !seenH) par += odd ? this.pGood : this.pOther;
        if ((t >> 4) && !seenS) par -= odd ? this.pOther : this.pGood;
        if (t & 15) seenS = 1;
        if (t >> 4) seenH = 1;
      }
    }
    let v = this.ev + par;
    if (this.side() === 2) v = -v;
    return v;
  }
  evaluate() {
    let v = this.evalRaw();
    if (this.noiseK) {
      // noise: a hash of the position and the search's seed, scaled by the level's k
      const h = ((this.key & 255) ^ (this.nseed & 255) ^ ((this.key >> 8) & 255)) & 255;
      const m = h >= 128 ? h - 128 : 128 - h;          // sign and size, as the 6303 does it
      const nz = (m * this.noiseK) >> 7;
      v += h >= 128 ? nz : -nz;
    }
    if (v > 50) v = 50; else if (v < -50) v = -50;
    return v;
  }

  // ---------- transposition table ----------
  ttIndex() { return (this.key & (this.opts.tt - 1)) * 4; }
  ttCheck() { return (((this.key >> 8) & 255) << 5) | ((this.key >> 16) & 31); }
  ttProbe() {
    if (this.opts.tt2) return this.ttProbe2();
    const i = this.ttIndex(), t = this.tt;
    if (!t[i + 3]) return null;
    const chk = (t[i] << 5) | (t[i + 1] >> 3);
    if (chk !== this.ttCheck()) return null;
    return { move: t[i + 1] & 7, score: sb(t[i + 2]), depth: t[i + 3] >> 2, flag: t[i + 3] & 3 };
  }
  ttProbe2() {
    const b = (this.key & (this.opts.tt / 2 - 1)) * 8, t = this.tt, chk = this.ttCheck();
    for (const i of [b, b + 4]) {
      if (!t[i + 3]) continue;
      if (((t[i] << 5) | (t[i + 1] >> 3)) !== chk) continue;
      return { move: t[i + 1] & 7, score: sb(t[i + 2]), depth: t[i + 3] >> 2, flag: t[i + 3] & 3 };
    }
    return null;
  }
  ttStore2(depth, flag, score, move) {
    // entry 0 keeps the deeper result, entry 1 the latest; the same position is replaced where it is
    const b = (this.key & (this.opts.tt / 2 - 1)) * 8, t = this.tt, chk = this.ttCheck();
    const same = i => t[i + 3] && ((t[i] << 5) | (t[i + 1] >> 3)) === chk;
    let i;
    if (same(b)) { if ((t[b + 3] >> 2) > depth) return; i = b; }
    else if (same(b + 4)) i = b + 4;
    else if (!t[b + 3] || (t[b + 3] >> 2) <= depth) { for (let k = 0; k < 4; k++) t[b + 4 + k] = t[b + k]; i = b; }
    else i = b + 4;
    t[i] = chk >> 5;
    t[i + 1] = ((chk & 31) << 3) | (move & 7);
    t[i + 2] = score & 255;
    t[i + 3] = (depth << 2) | flag;
  }
  ttStore(depth, flag, score, move) {
    if (this.opts.tt2) return this.ttStore2(depth, flag, score, move);
    const i = this.ttIndex(), t = this.tt;
    if (t[i + 3] && (t[i + 3] >> 2) > depth) return;    // a deeper result stays
    const chk = this.ttCheck();
    t[i] = chk >> 5;
    t[i + 1] = ((chk & 31) << 3) | (move & 7);
    t[i + 2] = score & 255;
    t[i + 3] = (depth << 2) | flag;
  }

  // ---------- search ----------
  // Searches the position for the side to move. opts: {nodes, depth, noise, seed, poll}
  // Returns {move, score, depth, nodes, exact}. The root is an ordinary node (ply 0) whose
  // best move is kept in this.rootMove, as the assembler keeps it in frame 0.
  think(o) {
    o = o || {};
    this.limit = o.nodes || 0;
    this.noiseK = o.noise || 0;
    this.nseed = (o.seed || 0) & 255;
    this.poll = o.poll || null;
    this.nodes = 0;
    this.abort = false;
    this.killer = new Array(MAXPLY + 2).fill(7);
    this.killer2 = new Array(MAXPLY + 2).fill(7);
    this.histT = new Array(98).fill(0);
    this.tt.fill(0);
    const s = this.side(), o2 = 3 - s;
    const empties = 42 - this.n;
    // a move that wins at once, or a lost position (two threats to block): no search
    const mine = this.playable(s);
    if (mine) return { move: 31 - Math.clz32(mine & -mine), score: WIN - 1, depth: 0, nodes: 0, exact: true };
    const oppp = this.playable(o2);
    if (oppp & (oppp - 1)) return { move: 31 - Math.clz32(oppp & -oppp), score: -(WIN - 2), depth: 0, nodes: 0, exact: true };
    // one threat: blocked, no search (any other move loses at once, so every search chose it).
    // Until 19 Nov a full search ran (up to 100 s at level 8); opts.searchForced keeps that, for tests
    if (oppp && !this.opts.searchForced) return { move: 31 - Math.clz32(oppp), score: 0, depth: 0, nodes: 0, exact: false };
    let maxd = o.depth ? Math.min(o.depth, empties) : empties;
    if (maxd > MAXPLY) maxd = MAXPLY;
    let best = -1, bestScore = 0, done = 0, exact = false;
    for (let d = 1; d <= maxd; d++) {
      this.inDepth1 = d === 1;
      this.rootMove = 7;
      let lo = -WIN - 1, hi = WIN + 1;
      if (this.opts.weak && d >= empties) { lo = -1; hi = 1; }
      else if (this.opts.asp && d > 2 && bestScore > -40 && bestScore < 40) { lo = bestScore - this.opts.asp; hi = bestScore + this.opts.asp; }
      let v = this.node(0, d, lo, hi);
      if (!this.abort && (lo > -WIN - 1 && !(this.opts.weak && d >= empties)) && (v <= lo || v >= hi)) {
        this.rootMove = 7;
        v = this.node(0, d, -WIN - 1, WIN + 1);    // outside the aspiration window: again, full
      }
      if (this.rootMove < 7) { best = this.rootMove; if (!this.abort) bestScore = v; }
      if (this.abort) break;
      done = d;
      if (d >= empties || bestScore > 50 || bestScore < -50) { exact = d >= empties || bestScore > 50 || bestScore < -50; break; }
    }
    return { move: best, score: bestScore, depth: done, nodes: this.nodes, exact };
  }

  // does playing col let the opponent o play a threat cell directly above it?
  feeds(col, o) {
    const r = this.ht[col] + 1;
    if (r > 5) return false;
    return !!((this.thr[col * 7 + r] >> (o === 1 ? 0 : 4)) & 15);
  }

  // the next move in search order (stage: 0 table's move, 1 killer, 2-8 centre out), or 7
  nextMove(f) {
    if (this.opts.hist || this.opts.k2) return this.nextMove2(f);
    for (;;) {
      const st = f.stage++;
      if (st > 8) return 7;
      let c;
      if (st === 0) c = f.tt;
      else if (st === 1) { c = this.killer[f.ply]; if (c === f.tt) continue; }
      else { c = ORDER[st - 2]; if (c === f.tt || c === this.killer[f.ply]) continue; }
      if (c < 7 && this.ht[c] < 6) return c;
    }
  }
  // the experiment's order: the table's move, killer 1, (killer 2), then the rest by history
  // (ties centre out) or centre out; f.done is a bitmask of the columns tried
  histIx(s, c) { return this.opts.hist === 2 ? (s === 1 ? 0 : 7) + c : (s === 1 ? 0 : 49) + c * 7 + this.ht[c]; }
  nextMove2(f) {
    if (f.done === undefined) f.done = 0;
    const ok = c => c < 7 && this.ht[c] < 6 && !((f.done >> c) & 1);
    for (;;) {
      const st = f.stage;
      let c = 7;
      if (st === 0) { f.stage = 1; c = f.tt; }
      else if (st === 1) { f.stage = 2; c = this.killer[f.ply]; }
      else if (st === 2) { f.stage = 3; if (this.opts.k2) c = this.killer2[f.ply]; }
      else {
        let bestC = 7, bestH = -1;
        const s = this.side(), base = s === 1 ? 0 : 49;
        for (const o of ORDER) {
          if (!ok(o)) continue;
          const h = this.opts.hist ? this.histT[this.histIx(s, o)] : 0;
          if (h > bestH) { bestH = h; bestC = o; }
        }
        if (bestC === 7) return 7;
        c = bestC;
      }
      if (ok(c)) { f.done |= 1 << c; return c; }
    }
  }

  node(ply, d, alpha, beta) {
    this.nodes++;
    if (this.limit && this.nodes >= this.limit && !this.inDepth1) this.abort = true;
    if (this.poll && (this.nodes & 63) === 0 && this.poll()) this.abort = true;
    if (this.abort && !this.inDepth1) return 0;
    const s = this.side(), o = 3 - s;
    // (s cannot win at once here: the parent blocked any playable threat of s, and a move that
    // would let s win straight above it is scored without being searched. Removed 19 Nov.)
    const oppp = this.playable(o);
    if (oppp & (oppp - 1)) return -(WIN - (ply + 2));
    if (this.n >= 42) return 0;
    if (d <= 0) return this.evaluate();
    const a0 = alpha;
    const f = { ply, stage: 0, tt: 7 };
    const e = this.ttProbe();
    if (e) {
      f.tt = e.move;
      if (e.depth >= d && ply) {
        let sc = e.score;
        if (sc > 50) sc -= ply; else if (sc < -50) sc += ply;
        if (e.flag === 3) return sc;
        if (e.flag === 2 && sc >= beta) return sc;
        if (e.flag === 1 && sc <= alpha) return sc;
      }
    }
    let forced = 7;
    if (oppp) { forced = 31 - Math.clz32(oppp); f.stage = 9; }
    let best = -WIN - 1, bestMove = 7;
    for (;;) {
      let col;
      if (forced < 7) { col = forced; forced = 8; } else if (forced === 8) break; else col = this.nextMove(f);
      if (col >= 7) break;
      let v;
      if (this.feeds(col, o)) v = -(WIN - (ply + 2));
      else {
        this.make(col);
        if (this.opts.pvs && bestMove < 7 && beta - alpha > 1) {
          v = -this.node(ply + 1, d - 1, -alpha - 1, -alpha);
          if (v > alpha && v < beta && !(this.abort && !this.inDepth1)) v = -this.node(ply + 1, d - 1, -beta, -alpha);
        } else v = -this.node(ply + 1, d - 1, -beta, -alpha);
        this.unmake();
        if (this.abort && !this.inDepth1) return 0;
      }
      if (v > best) { best = v; bestMove = col; if (!ply) this.rootMove = col; }
      if (v > alpha) alpha = v;
      if (alpha >= beta) {
        if (!oppp) {
          if (this.opts.k2 && this.killer[ply] !== col) this.killer2[ply] = this.killer[ply];
          this.killer[ply] = col;
          if (this.opts.hist) { const hb = this.histIx(s, col); this.histT[hb] = Math.min(255, this.histT[hb] + (this.opts.histw === 'dd' ? d * d : this.opts.histw === '1' ? 1 : d)); }
        }
        break;
      }
    }
    let st = best;
    if (st > 50) st += ply; else if (st < -50) st -= ply;
    this.ttStore(d, best <= a0 ? 1 : best >= beta ? 2 : 3, st, bestMove);
    return best;
  }
}

module.exports = { MAXPLY, Engine, LEVELS, NLINES, LSTART, lineStep, CLINES, cellKey, ORDER, W, WIN };
