; =====================================================================
; OV_HELP: the rules and the keys, a screen at a time. Any key turns the
; page, ON/CLEAR goes back.
; H_TALLY (after OV_RESULT, one player; the room was here, not in OV_END,
; where it was until 19 Nov): the tally, then OV_END for the keys. The
; tally is not kept in RAM: it is the one record of A:C4TAL ('T' and 27
; counts). A result marked due (g_res bit 6, set by OV_RESULT when it
; counted) is added and written here, the mark cleared and the game saved
; (the loop then shows the result again); so a result is counted once,
; even if the Organiser is switched off in between.
; =====================================================================
        include "../defs.inc"

        jmp  hp_start
        jmp  ta_start

ta_start:
        tst  g_mode             ; (one player only)
        bne  ta_end
        jsr  rs_tread           ; the tally (zeros if there is none)
        ldaa g_res
        bita #$40
        beq  .show
        anda #$BF               ; counted now: the mark goes
        staa g_res
        anda #3                 ; your win (0), draw (1) or loss (2)
        clrb
        cmpa #3
        bne  .wl
        ldab #1
        bra  .c
.wl:    cmpa g_psion
        bne  .c
        ldab #2
.c:     stab rs_w
        bsr  rs_row
        ldab rs_w
        abx
        inc  0,x
        jsr  rs_twrite          ; (if it cannot be written, the result is lost, not counted twice)
        ldd  #OV_GAME*256+G_SAVE  ; the mark's going saved: no command, the result again
        jmp  ov_call
.show:  jsr  lb_clr             ; line 3 (four lines): wins, draws, losses at this level
        bsr  rs_row
        ldaa #'W'
        bsr  rs_n
        ldaa #'D'
        bsr  rs_n
        ldaa #'L'
        bsr  rs_n
        ldaa #2
        jsr  lb_put
ta_end: ldd  #OV_END*256
        jmp  ov_call

; A = a letter, X = the count after it: "W3 "
rs_n:   pshx                    ; (lb_ch uses X)
        jsr  lb_ch
        pulx
        pshx
        ldab 0,x
        clra
        jsr  lb_num
        jsr  lb_sp
        pulx
        inx
        rts

; X = the tally row for the level played (1 player): wins, draws, losses
rs_row: ldaa st_level           ; the level in force (Auto: g_alv; the kernel's
        cmpa #9                 ; level until 20 Nov 2026)
        bne  .lvh
        ldaa g_alv
.lvh:
        ldab st_level           ; Auto has its own row (9)
        cmpb #9
        beq  .a
        tab
.a:     decb
        ldaa #3
        mul
        addd #rs_tb+2
        xgdx
        rts

; ---------------------------------------------------------------------
; The tally file A:C4TAL: one record, length 28, 'T', then wins, draws,
; losses for levels 1-8 and Auto
; ---------------------------------------------------------------------
; open it, record 1 current: C clear if it is there
rs_topen:
        clr  kv_pkok            ; (the file services select A:)
        ldx  #rs_fn
        os   FL$OPEN
        bcs  .x
        tab
        os   FL$RECT
        clra
        clrb
        os   FL$SETP
        ldd  #1
        os   FL$RSET
.x:     rts

; rs_tb = the tally, or zeros
rs_tread:
        bsr  rs_topen
        bcs  .z
        ldx  #rs_tb
        os   FL$READ
        bcs  .z
        ldd  rs_tb
        cmpa #28
        bne  .z
        cmpb #'T'
        beq  .x
.z:     ldx  #rs_tb
.c:     clr  0,x
        inx
        cpx  #rs_tb+29
        bne  .c
.x:     clr  kv_pkok
        rts

; rs_tb back to the file (made if it is not there)
rs_twrite:
        ldd  #28*256+'T'
        std  rs_tb
        bsr  rs_topen
        bcc  .old
        ldx  #rs_fn             ; no file yet
        os   FL$CRET
        bcs  .x
        tab
        os   FL$RECT
        bra  .w
.old:   os   FL$ERAS
.w:     ldx  #rs_tb
        os   FL$WRIT
.x:     clr  kv_pkok
        rts

rs_fn:  fcl  "A:C4TAL"
rs_tb:  rmb  29
rs_w:   fcb  0

; ---------------------------------------------------------------------

hp_start:
        ldx  #hp_text
.pg:    stx  hp_p
        clr  hp_ln
.ln:    jsr  lb_clr
        ldx  hp_p
        ldab 0,x
        beq  .x                 ; the end
        jsr  lb_fcl
        ldx  hp_p
        ldab 0,x
        incb
        abx
        stx  hp_p
        ldaa hp_ln
        jsr  lb_put
        inc  hp_ln
        ldaa hp_ln
        cmpa kv_plines
        bne  .ln
        clra
        jsr  key_wait
        cmpb #K_ON
        beq  .x
        ldx  hp_p
        bra  .pg
.x:     rts

hp_text:
        fcl  "Drop discs:"
        fcl  "four in a"
        fcl  "row wins -"
        fcl  "across, up,"
        fcl  "or diagonal."
        fcl  "Solid first."
        fcl  "LEFT RIGHT"
        fcl  " pick column"
        fcl  "1-7 a column"
        fcl  "EXE drops"
        fcl  "DEL takeback"
        fcl  "SPACE hint"
        fcl  "MODE coach"
        fcl  "UP move list"
        fcl  "ON the menu"
        fcl  "Review game:"
        fcl  "in the menu,"
        fcl  "or MODE when"
        fcl  "a game ends."
        fcl  "E exports a"
        fcl  "game at the"
        fcl  "end. Import:"
        fcl  "Last game."
        fcl  "Any key: the"
        fcl  "Psion moves"
        fcl  "now."
        fcb  0
hp_p:   fdb  0
hp_ln:  fcb  0
