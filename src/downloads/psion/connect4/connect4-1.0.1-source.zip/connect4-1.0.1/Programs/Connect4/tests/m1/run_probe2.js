const { Machine } = require('../../tools/emu');
for (const [rom, ram] of [['33-cm.rom', 8], ['46-lz.rom', 32]]) {
  const m = new Machine({ rom, ram });
  m.boot();
  m.insertPack(__dirname + '/../../build/probe/probe.opk', 0);
  m.runProc('C4', 'B');
  m.runSeconds(3);
  const out = [];
  for (let i = 0; i < 4; i++) { m.press('EXE', 3, 20); m.runSeconds(1); out.push(m.screen()[m.lines === 4 ? 1 : 0].trim()); }
  console.log(rom, JSON.stringify(out));
}
