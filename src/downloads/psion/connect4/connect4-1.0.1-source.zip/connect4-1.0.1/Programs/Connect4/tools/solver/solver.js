// Perfect Connect 4 solver (7x6) for building and checking the opening book.
// Bitboard layout as in Pascal Pons' solver: bit = col*7 + row, row 6 of each column is a
// sentinel. JS bit operations are 32-bit, so a 49-bit board is split: columns 0-3 in `lo`
// (28 bits), columns 4-6 in `hi` (21 bits). Functions that return a board return `lo` and
// leave `hi` in the module variable RH.
// Scores (Pons convention): 0 draw; positive = the side to move wins, 22 - (its stone count
// when it makes four); negative = it loses, -(22 - the opponent's stone count at its four).
'use strict';

const M28 = 0x0FFFFFFF;
const ORDER = [3, 2, 4, 1, 5, 0, 6];

let BOT_LO = 0, BOT_HI = 0, BRD_LO = 0, BRD_HI = 0;
const COL_LO = [], COL_HI = [];
for (let c = 0; c < 7; c++) {
  let cl = 0, ch = 0;
  for (let r = 0; r < 6; r++) {
    const b = c * 7 + r;
    if (b < 28) cl |= 1 << b; else ch |= 1 << (b - 28);
  }
  COL_LO.push(cl); COL_HI.push(ch);
  BRD_LO |= cl; BRD_HI |= ch;
  const b0 = c * 7;
  if (b0 < 28) BOT_LO |= 1 << b0; else BOT_HI |= 1 << (b0 - 28);
}

let RH = 0;

function pop32(x) {
  x = x - ((x >>> 1) & 0x55555555);
  x = (x & 0x33333333) + ((x >>> 2) & 0x33333333);
  return (Math.imul((x + (x >>> 4)) & 0x0F0F0F0F, 0x01010101) >>> 24);
}

// shifts of the 49-bit value (lo, hi)
function lL(l, s) { return (l << s) & M28; }
function lH(l, h, s) { return (h << s) | (l >>> (28 - s)); }
function rL(l, h, s) { return ((l >>> s) | (h << (28 - s))) & M28; }
function rH(h, s) { return h >>> s; }

// cells where stones `p` would complete a four (empty cells only, within the board)
function win(pl, ph, ml, mh) {
  // vertical
  let rl = lL(pl, 1) & lL(pl, 2) & lL(pl, 3);
  let rh = lH(pl, ph, 1) & lH(pl, ph, 2) & lH(pl, ph, 3);
  for (let i = 0; i < 3; i++) {
    const d = i === 0 ? 7 : i === 1 ? 6 : 8;
    const d2 = d * 2, d3 = d * 3;
    // p<<d & p<<2d
    let al = lL(pl, d) & lL(pl, d2), ah = lH(pl, ph, d) & lH(pl, ph, d2);
    rl |= al & lL(pl, d3); rh |= ah & lH(pl, ph, d3);
    rl |= al & rL(pl, ph, d); rh |= ah & rH(ph, d);
    al = rL(pl, ph, d) & rL(pl, ph, d2); ah = rH(ph, d) & rH(ph, d2);
    rl |= al & lL(pl, d); rh |= ah & lH(pl, ph, d);
    rl |= al & rL(pl, ph, d3); rh |= ah & rH(ph, d3);
  }
  RH = rh & (BRD_HI ^ mh);
  return rl & (BRD_LO ^ ml);
}

// ---------------- transposition table ----------------
const TT_BITS = 24;
let ttKL, ttKH, ttV;
function ttInit(bits) {
  const n = 1 << TT_BITS;
  ttKL = new Uint32Array(n); ttKH = new Uint32Array(n); ttV = new Uint8Array(n);
}
function ttIndex(kl, kh) {
  return (Math.imul(kl ^ Math.imul(kh, 0x27D4EB2F), 0x9E3779B1) ^ Math.imul(kh, 0x85EBCA77)) >>> (32 - TT_BITS);
}

let nodes = 0;

// negamax with alpha-beta on (cur, mask); n = discs on the board
function negamax(cl, ch, ml, mh, n, alpha, beta) {
  nodes++;
  const pl = (ml + BOT_LO) & BRD_LO, ph = (mh + BOT_HI) & BRD_HI;
  const ol = win(cl ^ ml, ch ^ mh, ml, mh), oh = RH;
  let vl = pl, vh = ph;
  const fl = pl & ol, fh = ph & oh;
  if (fl | fh) {
    if ((fl & (fl - 1)) || (fh & (fh - 1)) || (fl && fh)) return -((42 - n) >> 1);
    vl = fl; vh = fh;
  }
  vl &= ~rL(ol, oh, 1); vh &= ~rH(oh, 1);
  if (!(vl | vh)) return -((42 - n) >> 1);
  if (n >= 40) return 0;
  const min = -((40 - n) >> 1);
  if (alpha < min) { alpha = min; if (alpha >= beta) return alpha; }
  let max = (41 - n) >> 1;
  const kl = (cl + ml) >>> 0, kh = (ch + mh) >>> 0;
  const ix = ttIndex(kl, kh);
  if (ttKL[ix] === kl && ttKH[ix] === kh && ttV[ix]) {
    const e = ttV[ix];
    const v = (e & 63) - 32;
    if (e & 64) { if (v > alpha) { alpha = v; if (alpha >= beta) return alpha; } }
    else if (v < max) max = v;
  }
  if (beta > max) { beta = max; if (alpha >= beta) return beta; }

  // order moves: most winning cells created first; ties to the centre
  const mvl = [0, 0, 0, 0, 0, 0, 0], mvh = [0, 0, 0, 0, 0, 0, 0], sc = [0, 0, 0, 0, 0, 0, 0];
  let cnt = 0;
  for (let i = 6; i >= 0; i--) {
    const c = ORDER[i];
    const xl = vl & COL_LO[c], xh = vh & COL_HI[c];
    if (!(xl | xh)) continue;
    const s = pop32(win(cl | xl, ch | xh, ml, mh)) + pop32(RH);
    let p = cnt++;
    while (p && sc[p - 1] > s) { mvl[p] = mvl[p - 1]; mvh[p] = mvh[p - 1]; sc[p] = sc[p - 1]; p--; }
    mvl[p] = xl; mvh[p] = xh; sc[p] = s;
  }
  const ncl = cl ^ ml, nch = ch ^ mh;
  while (cnt) {
    cnt--;
    const s = -negamax(ncl, nch, ml | mvl[cnt], mh | mvh[cnt], n + 1, -beta, -alpha);
    if (s >= beta) { ttKL[ix] = kl; ttKH[ix] = kh; ttV[ix] = (s + 32) | 64; return s; }
    if (s > alpha) alpha = s;
  }
  ttKL[ix] = kl; ttKH[ix] = kh; ttV[ix] = alpha + 32;
  return alpha;
}

// ---------------- positions ----------------
// A position object: {cl, ch, ml, mh, n}; cur = stones of the side to move.
function fromMoves(seq) {
  const p = { cl: 0, ch: 0, ml: 0, mh: 0, n: 0 };
  for (const c of seq) if (!play(p, c)) return null;
  return p;
}
function height(p, c) {
  const l = p.ml & COL_LO[c], h = p.mh & COL_HI[c];
  return pop32(l) + pop32(h);
}
function canPlay(p, c) { return height(p, c) < 6; }
function moveBits(p, c) {
  // lowest empty cell of column c
  const l = ((p.ml + BOT_LO) & COL_LO[c]), h = ((p.mh + BOT_HI) & COL_HI[c]);
  return [l, h];
}
function isWinningMove(p, c) {
  if (!canPlay(p, c)) return false;
  const [l, h] = moveBits(p, c);
  const wl = win(p.cl, p.ch, p.ml, p.mh);
  return !!((wl & l) | (RH & h));
}
// plays column c (0-6); returns false if full or if it would play into a finished game
function play(p, c) {
  if (c < 0 || c > 6 || !canPlay(p, c)) return false;
  const [l, h] = moveBits(p, c);
  p.cl ^= p.ml; p.ch ^= p.mh; p.ml |= l; p.mh |= h; p.n++;
  return true;
}
function clone(p) { return { cl: p.cl, ch: p.ch, ml: p.ml, mh: p.mh, n: p.n }; }
function canWinNext(p) {
  const pl = (p.ml + BOT_LO) & BRD_LO, ph = (p.mh + BOT_HI) & BRD_HI;
  const wl = win(p.cl, p.ch, p.ml, p.mh);
  return !!((wl & pl) | (RH & ph));
}
// true if the side that just moved (not to move) has a four on the board
function lastMoverWon(p) {
  const ol = p.cl ^ p.ml, oh = p.ch ^ p.mh;  // stones of the side that just moved
  return hasFour(ol, oh);
}
function hasFour(l, h) {
  const sh = [1, 7, 6, 8];
  for (const d of sh) {
    const al = l & rL(l, h, d), ah = h & rH(h, d);
    const bl = al & rL(al, ah, 2 * d), bh = ah & rH(ah, 2 * d);
    if (bl | bh) return true;
  }
  return false;
}

// exact score (weak: only the sign, -1/0/1)
function solve(p, weak) {
  if (canWinNext(p)) return weak ? 1 : (43 - p.n) >> 1;
  let min = -((42 - p.n) >> 1), max = (43 - p.n) >> 1;
  if (weak) { min = -1; max = 1; }
  while (min < max) {
    let med = min + ((max - min) >> 1);
    if (med <= 0 && (min / 2 | 0) < med) med = (min / 2) | 0;
    else if (med >= 0 && (max / 2 | 0) > med) med = (max / 2) | 0;
    const r = negamax(p.cl, p.ch, p.ml, p.mh, p.n, med, med + 1);
    if (r <= med) max = r; else min = r;
  }
  return weak ? Math.sign(min) : min;
}

// score of each column for the side to move (null = full); a winning move scores directly
function analyse(p, weak) {
  const out = [];
  for (let c = 0; c < 7; c++) {
    if (!canPlay(p, c)) { out.push(null); continue; }
    if (isWinningMove(p, c)) { out.push(weak ? 1 : (43 - p.n) >> 1); continue; }
    const q = clone(p); play(q, c);
    out.push(-solve(q, weak));
  }
  return out;
}

// plies until the game ends with best play, from a score at a position with n discs
function pliesToEnd(score, n) {
  if (score > 0) return 2 * (22 - score - (n >> 1)) - 1;
  if (score < 0) return 2 * (22 + score - ((n + 1) >> 1));
  return 42 - n;
}

module.exports = {
  ttInit, solve, analyse, fromMoves, play, clone, canPlay, height, isWinningMove,
  canWinNext, lastMoverWon, pliesToEnd, getNodes: () => nodes, resetNodes: () => { nodes = 0; },
  _win: win, _rh: () => RH,
};
