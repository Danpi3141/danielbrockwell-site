// Packs data/book_nodes.jsonl into data/book.bin: 22,409 entries of 5 bits, big-endian bit
// order (entry n at bits 5n..5n+4), then one pad byte so the last entry reads as two bytes.
//   entry 0                         the empty board (the Psion first): column 4, a win
//   1 + b*2801 + base[d] + v        the Psion first: the opponent's first move b (0-3, mirrored),
//                                   then d more moves as a base-7 number v
//   11205 + b*2801 + base[d] + v    the Psion second: the same
// Code: 0 none, 1-7 play column 1-7 winning, 8-14 drawing, 15-21 losing.
'use strict';
const fs = require('fs'), path = require('path');
const DATA = path.join(__dirname, '..', '..', 'data');
const F_N = 11205, BRANCH = 2801, BASE = [0, 1, 8, 57, 400], TOTAL = 22409;

function index(t, opp) {
  const b = opp[0], d = opp.length - 1;
  let v = 0;
  for (let i = 1; i < opp.length; i++) v = v * 7 + opp[i];
  return (t === 'F' ? 1 : F_N) + b * BRANCH + BASE[d] + v;
}

function load() {
  const codes = new Uint8Array(TOTAL);
  codes[0] = 4;                                   // empty board: column 4, the first player wins
  let n = 0;
  // the generator's file, and any subtree finished separately (tools/book/gen_one.js)
  for (const f of fs.readdirSync(DATA).filter(f => /^book_nodes.*\.jsonl$/.test(f))) {
    for (const line of fs.readFileSync(path.join(DATA, f), 'utf8').split('\n')) {
      if (!line.trim()) continue;
      const r = JSON.parse(line);
      const i = index(r.t, r.opp);
      if (i <= 0 || i >= TOTAL) throw new Error('index out of range ' + JSON.stringify(r.opp));
      if (!codes[i]) n++;
      codes[i] = r.code;
    }
  }
  return { codes, n };
}

function pack(codes) {
  const bytes = new Uint8Array(Math.ceil(TOTAL * 5 / 8) + 1);
  for (let i = 0; i < TOTAL; i++) {
    for (let b = 0; b < 5; b++) {
      if ((codes[i] >> (4 - b)) & 1) {
        const bit = i * 5 + b;
        bytes[bit >> 3] |= 0x80 >> (bit & 7);
      }
    }
  }
  return bytes;
}

function read(bytes, i) {
  const bit = i * 5, by = bit >> 3, sh = bit & 7;
  return (((bytes[by] << 8) | bytes[by + 1]) >> (11 - sh)) & 31;
}

if (require.main === module) {
  const { codes, n } = load();
  const bytes = pack(codes);
  for (let i = 0; i < TOTAL; i++) if (read(bytes, i) !== codes[i]) throw new Error('pack check failed at ' + i);
  fs.writeFileSync(path.join(DATA, 'book.bin'), bytes);
  const used = codes.filter(c => c).length;
  console.log(`book.bin: ${bytes.length} bytes, ${n} entries from the generator, ${used} non-empty of ${TOTAL}`);
}

module.exports = { index, read, F_N, BRANCH, BASE, TOTAL };
