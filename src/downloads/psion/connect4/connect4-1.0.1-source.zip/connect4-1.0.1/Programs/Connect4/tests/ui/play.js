// Play keys and print the screen after each: node tests/ui/play.js rom ram keys,...
'use strict';
const { Machine } = require('../../tools/emu');
const rom = process.argv[2] || '46a-lz64.rom', ram = +(process.argv[3] || 64);
const m = new Machine({ rom, ram });
m.boot();
m.insertPack(__dirname + '/../../build/game/C4.opk', 0);
m.runProc('C4', 'B');
m.runSeconds(12);
console.log(m.screen().join('\n'));
for (const k of (process.argv[4] || '').split(',').filter(Boolean)) {
  if (/^w\d+$/.test(k)) { m.runSeconds(+k.slice(1)); } else m.press(k, 3, 10);
  m.runSeconds(0.5);
  console.log('--', k); console.log(m.screen().join('\n'));
}
