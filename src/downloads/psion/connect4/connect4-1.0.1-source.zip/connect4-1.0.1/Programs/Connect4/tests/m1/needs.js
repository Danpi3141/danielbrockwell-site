// The free RAM C4G really needs on a CM. A test procedure FILL takes k*2 bytes, prints FREE and
// calls C4G; a binary search on k finds the least FREE with which the game still starts. That
// figure (plus C4's own frame, about the same as FILL's) is what C4 must check for.
'use strict';
const fs = require('fs'), path = require('path'), { execSync } = require('child_process');
const { Machine } = require('../../tools/emu');
const ROOT = path.join(__dirname, '..', '..');
const out = path.join(ROOT, 'build', 'needs');
fs.mkdirSync(out, { recursive: true });
const meta = JSON.parse(fs.readFileSync(path.join(ROOT, 'build', 'game', 'build.json'), 'utf8'));
const Tools = path.join(ROOT, '..', '..', 'Tools');

function attempt(k, rom) {
  fs.writeFileSync(path.join(out, 'FILL.opl'), `FILL:\nLOCAL f%(${k})\nPRINT FREE :GET\nC4G:\n`, 'latin1');
  fs.copyFileSync(path.join(ROOT, 'build', 'game', 'C4G.opl'), path.join(out, 'C4G.opl'));
  execSync(`python "${path.join(Tools, 'opl2opk.py')}" -f --target cm "${path.join(out, 't.opk')}" "${path.join(out, 'FILL.opl')}" "${path.join(out, 'C4G.opl')}"`, { stdio: 'pipe' });
  // the game's blocks come from the real pack in slot C (FL$BOPN looks on B: then C:)
  const m = new Machine({ rom, ram: 8 });
  m.boot();
  m.insertPack(path.join(out, 't.opk'), 0);
  m.insertPack(path.join(ROOT, 'build', 'game', 'C4.opk'), 1);
  m.runProc('FILL', 'B');
  m.runSeconds(1.5);
  const free = +(m.screenText().match(/(\d+)/) || [0, -1])[1];
  m.press('EXE', 3, 10);
  m.runSeconds(4);
  const ok = m.find([0x43, 0x34, 0x4B, 0x31], 0x2000, 0x4000) >= 0 && !/MEMORY|ERROR/.test(m.screenText());
  return { free, ok, text: m.screenText() };
}

for (const rom of ['33-cm.rom', '24-cm.rom']) {
  let lo = 0, hi = 1200;                        // k: words taken
  while (hi - lo > 1) { const mid = (lo + hi) >> 1; if (attempt(mid, rom).ok) lo = mid; else hi = mid; }
  const a = attempt(lo, rom), b = attempt(hi, rom);
  console.log(`${rom}: starts with FREE ${a.free} (k=${lo}), not with FREE ${b.free}: array ${meta.total}, ` +
    `so C4G needs about ${a.free} free: overhead ${a.free - meta.total} (build assumes ${meta.needs - meta.total})`);
}
