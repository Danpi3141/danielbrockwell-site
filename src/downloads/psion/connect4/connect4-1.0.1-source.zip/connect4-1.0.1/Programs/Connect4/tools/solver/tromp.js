// Loads John Tromp's 8-ply database (ext/tromp/connect-4.data): x = first player, to move.
'use strict';
const fs = require('fs'), path = require('path');
function load() {
  const f = path.join(__dirname, '..', '..', 'ext', 'tromp', 'connect-4.data');
  return fs.readFileSync(f, 'utf8').trim().split(/\r?\n/).map(line => {
    const a = line.split(',');
    let cl = 0, ch = 0, ml = 0, mh = 0;
    for (let c = 0; c < 7; c++) for (let r = 0; r < 6; r++) {
      const v = a[c * 6 + r], b = c * 7 + r;
      if (v === 'b') continue;
      if (b < 28) { ml |= 1 << b; if (v === 'x') cl |= 1 << b; }
      else { mh |= 1 << (b - 28); if (v === 'x') ch |= 1 << (b - 28); }
    }
    const res = a[42] === 'win' ? 1 : a[42] === 'loss' ? -1 : 0;
    return { p: { cl, ch, ml, mh, n: 8 }, res, key: (cl + ml) + (ch + mh) * 268435456 };
  });
}
module.exports = { load };
