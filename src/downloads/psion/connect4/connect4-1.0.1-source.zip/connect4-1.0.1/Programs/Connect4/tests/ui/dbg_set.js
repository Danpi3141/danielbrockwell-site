'use strict';
const { Game } = require('./lib');
const g = new Game('lz64').start();
g.waitHuman(60);
g.poke('st_level', 3);
const step = (k, t) => { g.key(k, t || 0.5); console.log('--', k, 'level', g.peek('st_level'), '|', g.panel().join('|')); };
for (const k of ['ON', 'L', 'EXE', 'RIGHT', 'ON', 'ON', 'E', 'EXE']) step(k);
