; =====================================================================
; OV_BOOK (COACH = 0: the Psion's turn) and OV_COACH (COACH = 1: the
; coach), assembled from this one file: both walk the opening book.
; =====================================================================
        include "../defs.inc"

F_N     = 11205                 ; entries in the Psion-first table (the second follows)
BRANCH  = 2801                  ; entries in one branch: 1 + 7 + 49 + 343 + 2401
HV_GET  = 0
HV_SET  = 1-COACH

        if   COACH
        jmp  g_coach
        else
        jmp  g_turn
        endif

; ---------------------------------------------------------------------
; The book. Entry n is a nibble of block C4B1 (byte n/2, the high one for
; even n: tools/build.py book4; until 19 Nov 2026 5 bits). The Psion's
; table: 'first' when it is Solid. The opponent's moves (mirrored when
; its first is in columns 5-7) address the entry; each of the Psion's
; own moves so far must be the book's.
; bk_entry: A = code for the position now (Psion to move), 0 if none
; ---------------------------------------------------------------------
bk_entry:
        clr  bk_j               ; the Psion's moves checked so far
        ldaa g_psion
        cmpa #1
        bne  .s
        ldab g_n                ; first: the empty board is entry 0
        bne  .f1
        clra
        clrb
        jmp  bk_read
.f1:    clrb                    ; its first move must be column 4
        jsr  rec_get
        cmpa #3
        bne  bk_none
        ldab #1                 ; the opponent's first
        jsr  rec_get
        bsr  bk_mir
        inc  bk_j               ; (the Psion's move 2 is at the base of the branch)
        ldd  #1
        bra  .br
.s:     clrb                    ; second: the opponent's first move
        jsr  rec_get
        bsr  bk_mir
        ldd  #F_N
.br:    std  bk_st              ; the branch's start: + b * BRANCH
        ldab bk_b
.b:     tstb
        beq  .bd
        pshb
        ldd  bk_st
        addd #BRANCH
        std  bk_st
        pulb
        decb
        bra  .b
.bd:    clr  bk_v7              ; v: the extra moves as a base-7 number
        clr  bk_v7+1
        clr  bk_d               ; their count
.step:  ldab bk_d               ; the entry for depth d: start + base[d] + v
        cmpb #5
        bhs  bk_none            ; past the table
        aslb
        ldx  #bk_base
        abx
        ldd  0,x
        addd bk_v7
        addd bk_st
        std  bk_n
        ldab bk_j               ; the Psion's move j: at ply 2j (first) or 2j+1
        aslb
        ldaa g_psion
        cmpa #1
        beq  .pf
        incb
.pf:    cmpb g_n
        bhs  .now               ; the position now: this entry
        stab bk_p
        ldd  bk_n
        jsr  bk_read
        tsta
        beq  bk_none
        jsr  bk_col             ; A = its column
        psha
        ldab bk_p
        jsr  rec_get
        pulb
        cba
        bne  bk_none            ; the Psion left the book
        ldab bk_p               ; the opponent's reply
        incb
        jsr  rec_get
        tab
        jsr  bk_mirb
        stab bk_m
        ldd  bk_v7              ; v = v * 7 + m
        asld
        asld
        asld
        subd bk_v7
        addb bk_m
        adca #0
        std  bk_v7
        inc  bk_d
        inc  bk_j
        bra  .step
.now:   ldd  bk_n
        bra  bk_read
bk_none:
        clra
        rts

; A = the opponent's first move: the mirror flag, and bk_b = its branch
bk_mir: clr  bk_mr
        cmpa #4
        blo  .n
        inc  bk_mr
        nega
        adda #6
.n:     staa bk_b
        rts
; B = a column, mirrored if the game is
bk_mirb:
        tst  bk_mr
        beq  .x
        negb
        addb #6
.x:     rts
; A = a code: its column (0-6), in the game's orientation
bk_col: deca
.l:     cmpa #7
        blo  .x
        suba #7
        bra  .l
.x:     tab
        bsr  bk_mirb
        tba
        rts

; D = entry number: A = its code (0 none, 1-7 a win in column 1-7, 8-14
; a draw, 15-21 a loss). The nibble's 8-15 stand for the book's only
; other codes (tools/build.py BOOK_HI): 9-13, then 16, 18, 20.
bk_read:
        std  bk_n
        lsrd                    ; its byte
        xgdx
        ldab #1
        jsr  pk_at              ; (block C4B1)
        os   PK$RBYT
        ldaa bk_n+1
        lsra
        bcs  .lo                ; odd: the low nibble
        lsrb
        lsrb
        lsrb
        lsrb
.lo:    andb #15
        tba
        cmpa #8
        blo  .x
        inca                    ; 8-12: 9-13
        cmpa #14
        blo  .x
        asla                    ; 13-15: 16, 18, 20
        suba #12
.x:     rts

bk_base: fdb  0,1,8,57,400

REC_PUT = 0
        include "krec.asm"

        if   1-COACH
; ---------------------------------------------------------------------
; B_TURN: the Psion's move. "Thinking" shown; A = the book's column
; (after the natural pause), or 7 with e_limit, e_fixd, e_noise, e_nseed
; set for a search at the level (the demo: each side's own level; the
; pause too where the search takes no time: levels 1-2, a forced move). The history
; at this ply: the book's value, or not known (a solved search's value is
; put there by OV_FX X_MARK after the move).
; ---------------------------------------------------------------------
g_turn: jsr  lb_clr
        jsr  lb_s
        fcl  "Thinking"
        ldaa #1
        jsr  lb_put
        ldaa g_mode             ; the demo (four lines): the move number
        cmpa #2
        bne  .nd
        jsr  lb_clr
        jsr  lb_s
        fcl  "Move "
        ldab g_n
        incb
        clra
        jsr  lb_num
        ldaa #3
        jsr  lb_put
.nd:
        clr  kv_xsc             ; (a book move has no solved score)
        clra
        ldab g_n
        jsr  hv_set
        ldaa g_mode
        cmpa #2
        bne  .lv
        jsr  side_to_move       ; the demo: its levels
        ldab st_dlv1
        cmpa #1
        beq  .row
        ldab st_dlv2
        bra  .row
.lv:    ldaa st_level           ; the level in force (Auto: g_alv; the kernel's
        cmpa #9                 ; level until 20 Nov 2026)
        bne  .lvb
        ldaa g_alv
.lvb:
        tab
.row:   ldaa #5
        mul
        addd #lv_tab-5
        xgdx
        ldd  0,x
        std  e_limit
        ldd  2,x
        staa e_fixd
        stab e_noise
        ldaa kv_seed            ; the noise's seed
        eora kv_seed+1
        staa e_nseed
        ldaa g_mode
        cmpa #2
        beq  .srch              ; (the demo searches)
        ldaa 4,x                ; book moves allowed
        ldab e_n                ; the Psion's moves so far
        lsrb
        cba
        bls  .srch
        jsr  bk_entry
        tsta
        beq  .srch
        psha
        tab                     ; the history: 1 a win, 2 a draw, 3 a loss for the Psion
        ldaa #1
        cmpb #8
        blo  .h
        inca
        cmpb #15
        blo  .h
        inca
.h:     ldab g_n
        jsr  hv_set
        pula
        jsr  bk_col
.pz:    tst  st_pace            ; natural pace: a short pause
        bne  .x
        psha
        ldaa #30
        jsr  key_wait
        pula
.x:     rts
.srch:  ldaa #7                 ; a search; at levels 1-2 (depth only) it takes no time,
        ldx  e_limit            ; so the book's pause too (19 Nov); and where some column's
        beq  .pz                ; landing cell wins for either side (a win now, a win to stop)
        ldx  #e_land            ; the engine answers without one, so the pause instead
.c:     ldab 0,x                ; (19 Nov)
        pshx
        ldx  #e_thr
        abx
        tst  0,x                ; (a full column's stop cell: 0)
        pulx
        bne  .pz
        inx
        cpx  #e_land+7
        bne  .c
        rts

; levels: positions (word, 0 = depth only), depth, noise, book moves.
; The counts give the spec's times at the measured 300 positions a second
; (the spec's own counts assumed 500): about 2, 3, 5, 10, 30 and 100 s.
lv_tab: fdb  0
        fcb  2,48,0
        fdb  0
        fcb  2,24,0
        fdb  600
        fcb  0,12,0
        fdb  900
        fcb  0,6,2
        fdb  1500
        fcb  0,0,3
        fdb  3000
        fcb  0,0,4
        fdb  9000
        fcb  0,0,99
        fdb  30000
        fcb  0,0,99

        include "khist.asm"
        endif

        if   COACH
; ---------------------------------------------------------------------
; G_COACH: the verdict on the panel (line 3 on four lines, 1 on two).
; kv_arg = 1: after your move (compared with the last verdict), 0: asked.
; ---------------------------------------------------------------------
g_coach:
        ldaa g_psion
        beq  .x                 ; (one player only)
        cmpa #3
        beq  .x
        jsr  psion_to_move
        bne  .now
        ldab g_n                ; your turn: the entry before the Psion's last
        beq  .first             ; move, if it played the book's move
        dec  g_n
        jsr  bk_entry
        inc  g_n
        tsta
        beq  .unk
        psha
        jsr  bk_col
        psha
        ldab g_n                ; the Psion's last move
        decb
        jsr  rec_get
        pulb
        cba
        pula                    ; (pula leaves the flags)
        bne  .unk
        bra  .have
.first: clrb                    ; the empty board, you first: you can win
        bra  .v
.now:   jsr  bk_entry
        tsta
        beq  .unk
.have:  ldab #0                 ; for you: 0 win, 1 draw, 2 loss
        cmpa #8
        blo  .l                 ; the Psion wins: you lose
        cmpa #15
        blo  .d
        clrb                    ; the Psion loses: you win
        bra  .v
.l:     ldab #2
        bra  .v
.d:     ldab #1
.v:     stab bk_v
        jsr  lb_clr
        tst  kv_arg
        beq  .ask
        ldaa g_cv               ; before your move (1 + verdict; 0 unknown)
        beq  .ask
        deca
        cmpa bk_v
        beq  .same
        tsta
        bne  .dl
        ldx  #co_wd             ; was a win
        ldab bk_v
        cmpb #1
        beq  .p
        ldx  #co_wl
        bra  .p
.dl:    ldx  #co_dl
        bra  .p
.same:  ldx  #co_good
        tsta
        bne  .p
        ldx  #co_still
        bra  .p
.ask:   ldab bk_v
        ldx  #co_win
        tstb
        beq  .p
        ldx  #co_draw
        decb
        beq  .p
        ldx  #co_loss
.p:     jsr  lb_fcl
        ldaa bk_v
        inca
        staa g_cv
.put:   ldaa kv_plines          ; line 3 of four, line 1 of two
        suba #2
        jsr  lb_put
        tst  kv_arg             ; asked: shown until a key
        bne  .x
        clra
        jmp  key_wait
.unk:   clr  g_cv
        tst  kv_arg
        bne  .x
        ldd  #OV_PANEL*256+1    ; asked, out of the book: a solved ending, or "Not known"
        jmp  ov_call
.x:     rts

co_still: fcl "Still a win"
co_wd:  fcl  "Win -> draw"
co_wl:  fcl  "Win -> loss"
co_dl:  fcl  "Draw -> loss"
co_good: fcl "Good move"
co_win: fcl  "Coach: win"     ; (with best play; worded so that on two lines,
co_draw: fcl "Coach: draw"     ; in place of the last move while the Psion
co_loss: fcl "Coach: lost"     ; thinks, it cannot be read as the result)
        endif

bk_n:   fdb  0
bk_st:  fdb  0
bk_v7:  fdb  0
bk_j:   fcb  0
bk_b:   fcb  0
bk_d:   fcb  0
bk_p:   fcb  0
bk_m:   fcb  0
bk_mr:  fcb  0
bk_v:   fcb  0
