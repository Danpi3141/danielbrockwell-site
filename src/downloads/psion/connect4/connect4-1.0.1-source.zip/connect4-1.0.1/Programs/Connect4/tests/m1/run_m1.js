const { Machine } = require('../../tools/emu');
for (const [rom, ram] of [['33-cm.rom', 8], ['31-xp.rom', 16], ['36-la.rom', 32], ['46-lz.rom', 32], ['46a-lz64.rom', 64]]) {
  const m = new Machine({ rom, ram });
  m.boot();
  m.insertPack(__dirname + '/m1.opk', 0);
  m.runProc('M1', 'B');
  m.runSeconds(2);
  console.log(rom.padEnd(14), JSON.stringify(m.screen()));
}
