# Design notes

How the game is put together, for whoever changes it next. The spec it follows is *Connect 4 for the Psion Organiser II: design spec* (18 Nov 2026); `README.md` lists where it differs.

## One pack, every model

The pack holds:
- **C4:** the OPL launcher, translated for the CM/XP so every model runs it. It checks FREE, then calls C4G.
- **C4G:** makes the array, pokes in the bootstrap (`src/launch/boot.asm`, 75 bytes, from one string in one loop) and calls it. C4 and C4G stay in RAM all game: they need 323 bytes beyond the array (`tests/m1/needs.js`).
- **C4K:** two lengths (the kernel's, and the whole block's after them), the kernel block, then the fixer (`src/launch/fixer.asm`, position independent: the bootstrap reads it in after the kernel and runs it there, where the variables go; it applies the kernel's fix-ups and starts it) and the encoded fix-ups: steps two to a byte, the high nibble first, 1-15 on that far and fix the word there, 0 on 15 without one (`encode_fixups` in `tools/build.py`; a byte a gap until 19 Nov 2026). Each overlay and driver in C4B0 is its length (a word), its code, and its own list the same way with a one-byte length in front (the loader, `ov_load` in `src/kernel/kpack.asm`).
- **C4B0:** the command table (`src/kernel/kcmd.asm`: 17 words, a kernel routine's offset + $8000 or an overlay's id × 256 + entry; `do_cmd` reads its entry), the units' offsets in C4B0 (a word each; `ov_load` reads one, then the unit), then the screen drivers and the overlays. (The two tables were in the kernel, in RAM, until 20 Nov 2026.)
- **C4B1:** the book.

The data blocks are procedures whose object code is a RETURN, so running one by mistake does nothing. The bootstrap finds C4K with FL$BOPN (on C:, then B:, then A:), reads the two lengths, then reads kernel, fixer and fix-ups into the array in one PK$READ and jumps to the fixer, which adds the array's address to every fix-up.

## The array (4,528 bytes)

| Part | Bytes | |
|---|---|---|
| Kernel and engine code, tables | 3,298 | resident (kernel 1,069, engine 2,229) |
| Variables | 275 | (and 75 in C4G's string: see below) | cleared at the start; the saved part is the save file's record in place |
| Screen driver (DRV) | 286 | `drv2.asm` or `drv4.asm`, chosen from the model byte (DV_MARK is four-line only: DRV2 has no entry for it) |
| Slot A | 671 | one overlay at a time |

**During a search** the engine's 512-byte table starts at DRV and its scratch (20 frames, killers, variables: 267 bytes) follows, into slot A. The driver is not used during a search (the thinking display prints through the OS), and `think` reads it in again from the pack afterwards; the table goes first so that this only overwrites the table, not the search's results. `think` also marks slot A empty, so the next overlay call loads its overlay again. So slot A only has to hold the largest overlay (now OV_GAME, 671) and the engine needs only 779 - 286 = 493 of it.

- Overlays that need a buffer use the top bytes of slot A: BUF is the top 120, of which set-up uses the top 103 (from BUF+17); the review's tactics RV_TAC are the top 11 (OV_LIST writes them for OV_REVIEW); the result's last line RS_LINE the top 12 (OV_RESULT writes it, OV_HELP's H_TALLY loads between, OV_END reads it). They must stay below their part (`BUF_USERS` in `tools/build.py`). OV_EXPORT and OV_IMPORT use the screen driver's area instead (a name at DRV, records and the list from DRV+16: a record can be 254 bytes) and read the driver in again afterwards; until 19 Nov 2026 they used the top 256 and 120 bytes of the slot.
- The engine's busiest working variables are on the zero page ($41-$4C, the OS's utility scratch; see `src/engine/engine.asm`).
- **The search's display is not resident.** `think_run` reads OV_THINK (the poll: a key stops the search; depth, seconds, the bar) into the top 178 bytes of slot A (THINKAT), which the search's table and scratch leave free, before every search; the build checks it fits. (It uses 176 of them: 2 bytes to spare. Its own variables (seconds, depth, bar, start time) are in its image, so reading it in sets them; `think_run` writes the start time into its last two bytes, the top of slot A, and the build checks `ot_tstart` is there.)
- **Dead code removed (19 Nov, from `tests/coverage.js` and a static scan):** the demo-stop command (nothing sent it), the search's "win now" check below the root (unreachable: a parent blocks any playable threat and never feeds one; 9,275 searches identical without it), DRV2's disc mark, OV_THINK's two clamps, unused variables, the emptying board's stop-row test, the value code in plain menus (`MENU_V`), OV_PLAY2's hint flash. (OV_THINK then fitted exactly; the search inputs moved to evars later freed 7 bytes, and its own variables took 5 of them.)
- **Two engine tables are code now:** a cell's lines run from its offset to the next cell's (no end markers), and a line's first cell and step come from `e_line` (arithmetic, one MUL). Together 111 bytes less, the search about 2.7% slower.
- The move record holds two moves a byte (`src/screens/krec.asm`); OV_FX writes each move into it.
- The tally is not in RAM: it is the file A:C4TAL (`src/screens/ov_help.asm`, entry H_TALLY; in OV_END until 19 Nov 2026). The last game finished is A:C4LAST (OV_EXPORT's X_END), one record padded to 43 bytes so it never grows.
- Files the game makes (exports, A:C4LAST) are made only while the gap between the allocated cells (ALA_FREE, $2040) and the array stays over KEEP_GAP (build.py): so C4 can always start again.
- **Variables in C4G's string (19 Nov):** C4G pokes the bootstrap into the array from one string literal in its Q-code, and C4G stays in RAM all game. Once the bootstrap has run, nothing reads that string again, so the kernel's 75 working variables (`kh_first`..`kh_end` in `src/kernel/kvars.inc`) live there: at KH, 196 bytes below the array on all 29 ROMs (`tests/m1/holeprobe.js`). The build finds the string in C4G's object code and computes KH from it (plus `C4G_FRAME_GAP`, the 22 bytes of C4G's own variables), and fails if it moves or the variables outgrow it. They are ordinary array-relative addresses (fix-ups wrap below the array), and the start-up code clears them. Only the string is used: C4G's Q-code after the USR call must stay intact for the return to OPL.
- **Kernel cuts (19 Nov, late):** the commands that only loaded an overlay are now entries in `cmd_tab` itself (on the pack since 20 Nov 2026, `src/kernel/kcmd.asm`; below $2000: overlay id × 256 + entry, sent to `ov_call`; the build checks there are fewer than 32 units); the rest of playing a move (`e_make`, the cell, four in a row or a full board) moved into OV_FX's X_FALL; the demo's pause moved into OV_FX's X_MARK; the level's search inputs live in evars and OV_BOOK writes them. Kernel 1,267 → 1,080 bytes (then 1,069, with the thinking variables moved into OV_THINK); the engine plays identically (`tests/engine/t_match.js`).

The start-up code (`src/kernel/kinit.asm`) is stored after the kernel's code, where the variables go. The kernel's entry jumps to it where it is stored; its first lines copy it into R (absolute addresses only, so they run anywhere; the kernel did the copy until 20 Nov 2026), and it runs there once. It finds the blocks, picks the driver (switching an LZ to four lines with DP$MSET), seeds the random numbers, shows the title, and starts the game (OV_GAME's G_LOAD, returning to `gm_main`).

## Units

| Unit | Job |
|---|---|
| kernel | entry and exit, overlay loader (`ov_call`, `ov_load`), pack access, keys (own idle switch-off; the glyphs are sent again after switching on), the panel (12 characters a line, through the OS), sound, the game loop and its commands, playing a move, the Psion's search with the thinking display |
| DRV2, DRV4 | the board: show a cell, the whole board, the glyphs; the panel's position and height |
| OV_PANEL | before your move: the panel's fixed lines (last move, level or solved ending or match, move number), then on to OV_PLAY or OV_PLAY2; also the coach's out-of-the-book text, and (entry P_WARN) the coach's mark on a drop, "EXE drops it" |
| OV_PLAY / OV_PLAY2 | your move: line 2, the keys, ghost disc, threat cells (one source: OV_PLAY2 adds the two-player clocks, timer and names) |
| OV_GAME | save file, defaults, a new game, take back, replaying the record, the swap rule's question (asked when the first disc is saved) |
| OV_BOOK / OV_COACH | one source, both walking the book: the Psion's turn ("Thinking", the book, or the level's search inputs written straight to the engine's `e_limit`/`e_fixd`/`e_noise`/`e_nseed`, the history at that ply) / the coach (out of the book, asked: OV_PANEL) |
| OV_MENU, OV_SET | the menu (with player names; the command C_MENU, so it carries out the chosen command through `do_cmd`), the settings |
| OV_CMD | the rarer commands: swap sides, resign, out of time (kernel code until 20 Nov 2026); with OV_FX it includes `game_over` and the four-in-a-row tune (`src/screens/kover.asm`) |
| OV_RESULT | the result: Auto level, match, the tally marked due (g_res bit 6), then OV_EXPORT X_END; shown, its last line kept in RS_LINE; then OV_HELP H_TALLY |
| OV_END | the result's keys (named in turn on the last line, then RS_LINE put back), the winning four and the draw sweep; entry E_NEW (the command C_NEW): with Keep Ask, "Export game?" for a result not kept (g_res bit 7), then the new game |
| OV_FX | playing a move (X_FALL: into the record, the falling disc, `e_make`, the cell shown, then a tail call to OV_GAME's save or to `game_over`), the emptying board, the Psion's newest disc (and a solved value into the history; in the demo, the pause) |
| OV_REVIEW | stepping through the game, with verdicts from the history, and the tactics (RV_TAC); DOWN steps on to the next move whose text is a mark (the texts from `rv_wd` on) |
| OV_IMPORT / OV_EXPORT | choosing a game file ("Last game" first, each with its moves) / writing one (X_EXPORT; X_NEW after the question), reading the chosen one (X_READ), and at a result's count A:C4LAST and Keep All (X_END) |
| OV_LIST, OV_SETUP, OV_HELP | move list (and, entry L_TACT, the review's tactics into RV_TAC, the top 11 bytes of slot A; entry L_DROP, the command C_DROP: with the coach on, the same tactics for the drop, made and taken back), set-up, help (and, entry H_TALLY, the tally: A:C4TAL counted once when marked due, the game saved; its line shown) |

The menu routine (`src/kernel/kmenu.asm`) is assembled into each overlay that shows a list, and `kexact.asm` (a solved ending's text) and `khist.asm` (the history) into each that needs them. That costs pack space, not RAM.

**Overlays hand on with a tail call.** An overlay may finish with `ldd #OV_X*256+entry` / `jmp ov_call`: the new overlay is loaded over it and returns to the kernel's caller. It must never `jsr` a kernel routine that loads an overlay (`save`, `fx_call`, `play_move`, `think` ...): that overlay would be loaded over the caller, and the return would land in the middle of it. (Until 19 Nov 2026 OV_RESULT did this with `save`, and it worked only because the bytes it landed on happened to be harmless.) Chains in use: OV_RESULT → OV_EXPORT X_END → OV_GAME save (returns no command, so the loop shows the result again); OV_RESULT → OV_HELP H_TALLY → (tally due) OV_GAME save, or OV_END → (MODE) OV_LIST L_TACT → OV_REVIEW; the command C_NEW: OV_END E_NEW → (yes) OV_EXPORT X_NEW → OV_FX X_EMPTY, or OV_END E_NEW → OV_FX X_EMPTY; the command C_EXPORT: OV_EXPORT → OV_GAME save; OV_PANEL → OV_PLAY or OV_PLAY2; OV_COACH → OV_PANEL; OV_FX X_EMPTY → OV_GAME G_NEWG; OV_FX X_FALL → OV_GAME G_SAVE (or the kernel's `game_over`, a plain jump); OV_IMPORT → OV_EXPORT X_READ → OV_GAME G_RSAVE or G_REPLAY (the driver read in again first); OV_SETUP → OV_GAME; OV_MENU → OV_LIST L_TACT → OV_REVIEW; the command C_DROP: OV_LIST L_DROP → the kernel's `cm_drop` (a plain jump), or (a mark) OV_PANEL P_WARN → `cm_drop` or back to choosing.

**Resuming** keeps g_over and g_res as saved (replaying the record would count a finished game again, and forget a resignation or a flag; until 19 Nov 2026 it did).

## The history (`g_hv`, `src/screens/khist.asm`)

11 bytes in the save record, 2 bits a ply: the value of the position after p moves for the side to move there (0 not known, 1 win, 2 draw, 3 loss). It is written only at the Psion's turns: OV_BOOK puts the book's value there (or 0), and after the move OV_FX X_MARK puts a solved search's value there (`kv_xsc`). A new record (new game, import, set-up) clears it; take back clears the plies after the position kept. The review derives a move's value before it from the history at its ply, or from the ply before when the Psion moved there (its book or solved move kept the value), and after it from the next ply (or from the four or full board it made).

## The engine (`src/engine`, `ref/engine.js`)

The state:
- `e_bd`: 49 cells, col*7+row, with a stop row.
- `e_thr`: right after `e_bd`, so a cell's threat byte is `49,x` from its board byte.
- `e_lc`: 69 line counts as nibbles.
- `e_land`: the landing cells.
- `e_ev`: the open-line score.
- `e_key`: 24 bits.

Make and unmake are one loop for both sides. For Hollow, each count byte is read with its nibbles swapped, through a BRA/BRN patched at the start of each call.

The search is iterative deepening with alpha-beta on explicit 10-byte frames:
- Forced moves are handled at every node: a win now, two threats lost, one threat the only reply. At the root these return without a search, the one-threat block too since 19 Nov (score 0, not exact; until then it searched the whole budget for the move every search chose). OV_BOOK sees these turns beforehand (a threat count at some landing cell) and, at Pace Natural, gives them the book move's pause; also (19 Nov) every move at levels 1-2, whose depth-2 search takes no time.
- A move under an opponent's threat is scored as the loss it is.
- Move order: the table's move, the killer, then centre out.
- The table has 128 entries of 4 bytes.
- 20 frames: the search's depth is capped there (level 8 reached 17 at most in 900 searches with over 20 empty cells; with 20 or fewer empty the depth is at most the cells left).
- Scores are bytes; a win is 100 less the plies to it.

The JavaScript reference is the specification: `tests/engine/t_match.js` requires every state byte, evaluation, move, score, depth and node count to be identical. Any change goes into both.

## The book

`tools/book/gen_book.js` solves every entry with `tools/solver` (a Pons-style bitboard solver in Node, split into 28+21-bit halves).
- **Winning:** the fastest win.
- **Drawing:** the move that leaves the most losing replies.
- **Losing:** the fewest winning replies, then the slowest loss.

`make_book.js` packs 5-bit codes (`data/book.bin`); `tools/build.py` repacks them in 4 bits for the pack (19 Nov 2026: 11,205 bytes for 14,007): 1-7 a winning column as before, and 8-15 for the only 8 draw and loss codes the book has (`BOOK_HI`; OV_BOOK's `bk_read` turns them back, and the build checks the two agree). `check_book.js` checks them against Tromp's 8-ply database, and checks that each entry agrees with the entries for its replies.

## Gotchas

- `LDX` sets Z: compare after it, not before.
- A global label inside a routine ends the scope of its `.local` labels. Patch sites are `.sw` and are referred to as `e_make.sw`.
- On the LZ64 the array is in the banked window $4000-$7FFF. The OS has another bank in during file and pack services. Tests must check the kernel's tag before reading RAM (`tests/ui/lib.js` `sync`).
- A menu letter jumps to the *next* item starting with it (R: Review game, then Resign).
- Tests must judge your turn by the move count, not just the panel: for a moment after your move the panel still shows "You: col".
- **Battery:** a timed key wait (A > 0) stops the Organiser switching itself off. Anything that blinks must rest after a while and fall back to an untimed wait (the ghost disc after 50 blinks, the winning four after 38); only a running clock or move timer may keep it awake.
- **Buffers:** a file record can be up to 254 bytes, so FL$READ needs that much room (X_READ reads into the top 256 bytes of slot A).
- **Test harness:** a game left earlier leaves its kernel and its "C4K1" tag in freed RAM, and the next one may be elsewhere (`lib.js` start clears old tags); the OS's interrupt code sits in RAM just above the array, so "code in the array runs" must use the array's real size (`kv_size`).
