// Builds the one-sided opening book (spec: "The opening book") with the perfect solver.
// Tables: 'F' = the Psion moves first (its moves 1-6), 'S' = the Psion moves second (moves 1-5).
// Positions are in the mirrored frame: the opponent's first move is 1-4 (columns 0-3).
// Output: data/book_nodes.jsonl, one line per entry position where the Psion is to move:
//   {t, opp:[...], seq:[...], code, wdl, an:[per-column WDL or null], sc:[exact scores or null]}
// Run:  node tools/book/gen_book.js [workers]     (resumable: finished subtrees are skipped)
'use strict';
const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');
const fs = require('fs'), path = require('path');
const S = require('../solver/solver');

const OUT = path.join(__dirname, '..', '..', 'data', 'book_nodes.jsonl');
const ORDER = [3, 2, 4, 1, 5, 0, 6];
const MAXD = 4;           // opponent moves after the branch's first one (F) / incl. it (S)

// ---------------- the work for one entry ----------------
// seq: all moves so far (0-based), Psion to move. Returns the entry record.
function entry(t, opp, seq) {
  const p = S.fromMoves(seq);
  const rec = { t, opp, seq };
  const an = S.analyse(p, true);                      // WDL for the side to move (the Psion)
  rec.an = an;
  const best = Math.max(...an.filter(v => v !== null));
  rec.wdl = best;
  let pick = -1;
  const cands = ORDER.filter(c => an[c] === best);
  if (best > 0) {
    // fastest win
    const sc = [null, null, null, null, null, null, null];
    for (const c of cands) {
      if (S.isWinningMove(p, c)) { sc[c] = (43 - p.n) >> 1; continue; }
      const q = S.clone(p); S.play(q, c); sc[c] = -S.solve(q, false);
    }
    rec.sc = sc;
    let bs = -99;
    for (const c of cands) if (sc[c] > bs) { bs = sc[c]; pick = c; }
  } else {
    // count the opponent's replies after each candidate: wins for it (bad) / losses for it (good)
    const rep = [null, null, null, null, null, null, null];
    for (const c of cands) {
      const q = S.clone(p); S.play(q, c);
      let oppWins = 0, oppLoses = 0;
      for (let r = 0; r < 7; r++) {
        if (!S.canPlay(q, r)) continue;
        if (S.isWinningMove(q, r)) { oppWins++; continue; }
        const g = S.clone(q); S.play(g, r);
        const v = S.solve(g, true);                     // for the Psion, to move again
        if (v < 0) oppWins++; else if (v > 0) oppLoses++;
      }
      rep[c] = [oppWins, oppLoses];
    }
    rec.rep = rep;
    if (best === 0) {
      let bv = -1;
      for (const c of cands) if (rep[c][1] > bv) { bv = rep[c][1]; pick = c; }
    } else {
      let bv = 99; let tied = [];
      for (const c of cands) { if (rep[c][0] < bv) { bv = rep[c][0]; tied = [c]; } else if (rep[c][0] === bv) tied.push(c); }
      if (tied.length > 1) {
        const sc = [null, null, null, null, null, null, null];
        let bs = -99;
        for (const c of tied) {
          const q = S.clone(p); S.play(q, c); sc[c] = -S.solve(q, false);
          if (sc[c] > bs) { bs = sc[c]; pick = c; }
        }
        rec.sc = sc;
      } else pick = tied[0];
    }
  }
  rec.move = pick;
  rec.code = best > 0 ? pick + 1 : best === 0 ? pick + 8 : pick + 15;
  return rec;
}

// children of an entry: for each opponent reply, the next entry position (or null if none)
function children(rec) {
  const out = [];
  const p = S.fromMoves(rec.seq);
  if (S.isWinningMove(p, rec.move)) return out;        // the Psion's book move wins: game over
  S.play(p, rec.move);
  for (let r = 0; r < 7; r++) {
    if (!S.canPlay(p, r) || S.isWinningMove(p, r)) continue;   // illegal, or the opponent wins
    out.push({ opp: rec.opp.concat([r]), seq: rec.seq.concat([rec.move, r]) });
  }
  return out;
}

function depthOf(t, opp) { return t === 'F' ? opp.length - 1 : opp.length - 1; }

// whole subtree from a node, depth first (shares the transposition table)
function subtree(t, opp, seq, emit) {
  const rec = entry(t, opp, seq);
  emit(rec);
  if (depthOf(t, opp) >= MAXD) return;
  for (const ch of children(rec)) subtree(t, ch.opp, ch.seq, emit);
}

if (!isMainThread) {
  S.ttInit();
  parentPort.on('message', (job) => {
    const t0 = Date.now();
    const recs = [];
    if (job.whole) subtree(job.t, job.opp, job.seq, r => recs.push(r));
    else recs.push(entry(job.t, job.opp, job.seq));
    parentPort.postMessage({ job, recs, ms: Date.now() - t0 });
  });
} else if (require.main === module) {
  const NW = +process.argv[2] || 15;
  fs.mkdirSync(path.dirname(OUT), { recursive: true });
  // resume: records already written
  const done = new Map();
  if (fs.existsSync(OUT)) {
    for (const line of fs.readFileSync(OUT, 'utf8').split('\n')) {
      if (!line.trim()) continue;
      const r = JSON.parse(line);
      done.set(r.t + r.opp.join(''), r);
    }
  }
  const out = fs.createWriteStream(OUT, { flags: 'a' });
  const queue = [];
  let active = 0, nodes = 0;
  const t0 = Date.now();
  const workers = [];
  const idle = [];

  function haveSubtree(t, opp) {
    // a subtree counts as done when its root and all its reachable entries are recorded
    const root = done.get(t + opp.join(''));
    if (!root) return false;
    if (depthOf(t, opp) >= MAXD) return true;
    for (const ch of children(root)) if (!haveSubtree(t, ch.opp)) return false;
    return true;
  }

  function addNode(t, opp, seq) {
    const d = depthOf(t, opp);
    const key = t + opp.join('');
    if (d >= 1) {                                       // whole subtrees from depth 1 on
      if (haveSubtree(t, opp)) return;
      queue.push({ t, opp, seq, whole: true, d });
    } else {
      const r = done.get(key);
      if (r) { expand(r); return; }
      queue.push({ t, opp, seq, whole: false, d });
    }
  }
  function expand(rec) { for (const ch of children(rec)) addNode(rec.t, ch.opp, ch.seq); }

  function pump() {
    // deepest-last: shallow single nodes first (they unlock more work)
    queue.sort((a, b) => (a.whole - b.whole) || (a.d - b.d));
    while (idle.length && queue.length) {
      const w = idle.pop(); const job = queue.shift();
      active++; w.postMessage(job);
    }
    if (!active && !queue.length) {
      out.end();
      for (const w of workers) w.terminate();
      console.log(`done: ${nodes} new entries in ${((Date.now() - t0) / 60000).toFixed(1)} min`);
    }
  }

  for (let i = 0; i < NW; i++) {
    const w = new Worker(__filename, { workerData: {} });
    w.on('message', (m) => {
      active--; idle.push(w);
      for (const r of m.recs) {
        const key = r.t + r.opp.join('');
        if (!done.has(key)) { out.write(JSON.stringify(r) + '\n'); nodes++; }
        done.set(key, r);
      }
      const j = m.job;
      console.log(`${new Date().toISOString().slice(11, 19)} ${j.t}${j.opp.map(x => x + 1).join('')} ${j.whole ? 'subtree' : 'node'} ` +
        `${m.recs.length} entries ${(m.ms / 1000).toFixed(1)} s; queue ${queue.length}, active ${active}, total ${done.size}`);
      if (!j.whole) expand(m.recs[0]);
      pump();
    });
    w.on('error', (e) => { console.error('worker error', e); process.exit(1); });
    workers.push(w); idle.push(w);
  }
  // roots: F after Psion plays 4 (col index 3) and the opponent's first move 1-4; S after it
  for (let m1 = 0; m1 < 4; m1++) {
    addNode('F', [m1], [3, m1]);
    addNode('S', [m1], [m1]);
  }
  pump();
}

module.exports = { entry, children, subtree };
