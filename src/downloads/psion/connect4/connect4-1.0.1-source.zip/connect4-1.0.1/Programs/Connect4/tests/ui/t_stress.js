// Stress test: random keys on every ROM, checking the game never breaks.
//   node tests/ui/t_stress.js [all | rom ...] [emulated minutes per ROM, default 10] [seed]
// Random presses (weighted to the game's keys, with bursts, long holds, SHIFT, and idle spells
// long enough for the Organiser to switch itself off: its idle time is set to 20 s). Checks:
//  - every time the game waits for a key: the kernel and engine code are unchanged (only the
//    two self-patched branches may differ);
//  - on the play screen: the board is the move record replayed, g_n <= 42, the game not over,
//    and the stack is where it was the last time (nothing left on it);
//  - on the result screen: the record holds a four, a full board, or the game was resigned or
//    lost on time;
//  - the game keeps reaching a key wait (no hang), the processor is not stuck, and no OS error
//    appears; when it is left (Leave) it is started again and must resume the same record;
//    "C4 NEEDS ... BYTES" (A: filled with exported games) is fine: the Organiser is reset.
'use strict';
const fs = require('fs'), path = require('path');
const { Game, ROMS, ROOT } = require('./lib');
const S = require('../../tools/solver/solver');

const args = process.argv.slice(2);
const roms = !args[0] || args[0] === 'all' ? Object.keys(ROMS) : args.filter(a => /\.rom$/.test(a));
const minutes = +(args.find(a => /^\d+(\.\d+)?$/.test(a)) || 10);
const seed0 = +(args.find(a => /^s\d+$/.test(a)) || 's1').slice(1);
let seed = seed0;
const rand = n => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return (seed >> 8) % n; };
const ids = Object.fromEntries(fs.readFileSync(path.join(ROOT, 'build', 'game', 'gen', 'ids.inc'), 'utf8')
  .split('\n').map(l => l.match(/^(\w+) = (\d+)/)).filter(Boolean).map(m => [m[1], +m[2]]));
const KEYS = ['U', 'V', 'W', 'O', 'P', 'Q', 'I', 'LEFT', 'RIGHT', 'UP', 'DOWN', 'EXE', 'DEL', 'MODE', 'SPACE', 'ON'];
const WEIGHT = [3, 3, 3, 3, 3, 3, 3, 4, 4, 3, 3, 6, 3, 2, 1, 3];
const LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
const pick = () => {
  if (rand(10) === 0) return LETTERS[rand(26)];
  let t = rand(WEIGHT.reduce((a, b) => a + b, 0));
  for (let i = 0; i < KEYS.length; i++) { t -= WEIGHT[i]; if (t < 0) return KEYS[i]; }
  return 'EXE';
};
function rowsOf(rec) {
  const ht = [0, 0, 0, 0, 0, 0, 0], bd = Array.from({ length: 49 }, (_, c) => (c % 7 === 6 ? 3 : 0));
  rec.forEach((c, i) => { bd[c * 7 + ht[c]++] = i % 2 ? 2 : 1; });
  return bd;
}
const regs = m => { const a = []; m.cpu.getSnapshotData(a); return { pc: a[5] << 8 | a[6], sp: a[7] << 8 | a[8], sleep: a[9] }; };

let failures = 0;
const summary = [];
for (const rom of roms) {
  seed = seed0 * 1000003 + [...rom].reduce((h, c) => (h * 31 + c.charCodeAt(0)) & 0xffffff, 7);   // (each ROM its own sequence)
  const t0 = Date.now();
  let g = null, kimg = null, skip = null, kwAddr = 0, sp0 = -1, lastRec = null, lastOver = 0, asize = 0;
  let left = false, counter = null, quitInfo = null;
  const hist = [];
  // keys stop the moment the game leaves (quit runs): the rest of a burst must not reach the
  // OS's menus, where it could erase the save file
  const press = (k, h, gp) => { if (!left) { hist.push(k); g.m.press(k, h, gp); } };
  const st = { keys: 0, waits: 0, plays: 0, results: 0, games: 0, leaves: 0, offs: 0, full: 0, units: new Set() };
  const fail = (msg) => { throw new Error(`${rom}: ${msg}\n${g ? g.text() : ''}`); };
  const start = (fresh) => {
    if (fresh) { g = new Game(rom); }
    g.start();
    if (g.base < 0) fail('no kernel after starting');
    g.m.poke(0x20CD, 0); g.m.poke(0x20CE, 20);                 // switch off after 20 s idle
    const s = g.sym, vend = g.base + s['kv_first'][0];
    kimg = g.m.read(g.base, vend - g.base);
    skip = new Set([s['e_make.sw'][0], s['e_unmake.sw'][0]]);
    kwAddr = g.base + s['key_wait'][0];
    asize = g.peekw('kv_size');
    const qAddr = g.base + s['quit'][0];
    left = false; counter = null;
    g.m.dbg.setTrace((pc) => {
      if (pc === qAddr && !left) { left = true; const a = []; g.m.cpu.getSnapshotData(a); quitInfo = { code: a[1], rec: g.rec().join(''), n: g.m.peek(g.base + s['g_n'][0]), keys: hist.slice(-20).join(' '), text: g.text() }; }
      if (counter) counter(pc);
    });
    sp0 = -1;
  };
  try {
    start(true);
    let quietS = 0;
    const budget = minutes * 60;
    let emuS = 0;
    while (emuS < budget) {
      // one random action
      const r = rand(100);
      let spent = 0;
      if (r < 70) { const k = pick(); const h = 2 + rand(5), gp = rand(20); press(k, h, gp); st.keys++; spent = (h + gp) * 0.05; }
      else if (r < 80) { const n = 5 + rand(10); for (let i = 0; i < n; i++) { press(pick(), 2, rand(3)); st.keys++; } spent = n * 0.2; }
      else if (r < 85) { const k = ['LEFT', 'RIGHT', 'DEL', 'U', 'EXE', 'UP', 'DOWN'][rand(7)], h = 20 + rand(40); press(k, h, 5); st.keys++; spent = h * 0.05; }
      else if (r < 90) { const s = 1 + rand(30); g.m.runSeconds(s); spent = s; }
      else if (r < 95) { g.m.keyDown('SHIFT'); g.m.runTicks(1); press(pick(), 3, 1); g.m.keyUp('SHIFT'); g.m.runTicks(3); st.keys++; spent = 0.4; }
      else { press('ON', 3, 10); press(pick(), 3, 10); st.keys += 2; spent = 1; }   // (wakes it if off)
      emuS += spent;
      // where is it now? run on to the next key wait (or give up after a second)
      const hit = g.m.runTo([kwAddr], 921600);
      if (regs(g.m).sleep) st.offs++;
      // still the game? (it waited for a key, or code in its array runs; its tag stays in freed RAM)
      let alive = hit === kwAddr && !left;
      if (!alive && !left) {
        const pre = regs(g.m), pretext = g.text();
        let inArr = 0;                                  // (the array only: the OS's interrupt code is in RAM just above it)
        counter = (pc) => { if (pc >= g.base && pc < g.base + asize) inArr++; };
        for (let tries = 0; tries < 2 && !inArr; tries++) {
          if (!g.text().trim() || regs(g.m).sleep) { g.m.press('ON', 3, 10); st.keys++; }   // (switched off, or going off: wake it)
          for (let i = 0; i < 6 && !inArr; i++) g.m.runSeconds(0.5);   // (switching on can take a while)
        }
        counter = null;
        alive = inArr > 0;
        if (!alive && process.env.STRESS_DEBUG) console.log('check: before', JSON.stringify(pretext), 'pc', pre.pc.toString(16), 'sleep', pre.sleep, 'after', JSON.stringify(g.text()), 'pc', regs(g.m).pc.toString(16));
      }
      if (!alive && process.env.STRESS_DEBUG) {
        const r = regs(g.m), tags = [];
        for (let a = 0x2000; a < 0x8000; a++) if (g.m.peek(a) === 0x43 && g.m.peek(a + 1) === 0x34 && g.m.peek(a + 2) === 0x4B && g.m.peek(a + 3) === 0x31) tags.push((a - 3).toString(16));
        console.log('not alive:', JSON.stringify(g.text()), 'pc', r.pc.toString(16), 'sp', r.sp.toString(16), 'base', g.base.toString(16), 'size', asize, 'tags', tags.join(','), 'hit', hit);
        for (let i = 0; i < 4; i++) { g.m.press('ON', 3, 10); g.m.runSeconds(1); const r3 = regs(g.m); console.log('  ON', i, JSON.stringify(g.text()), 'pc', r3.pc.toString(16), 'res', g.peek('kv_res')); }
      }
      if (!alive) {
        const t = g.text();
        if (/NEEDS/.test(t)) { st.full++; start(true); lastRec = null; continue; }
        if (!/C4 ERROR/.test(t)) {                                // left to the OS (Leave)
          st.leaves++;
          for (let i = 0; i < 4; i++) { g.m.press('ON', 3, 10); g.m.runSeconds(0.3); }
          start(false);
          // a key wait after the saved game is loaded: not the title's (kv_res 0), and not while
          // OV_GAME is still the overlay (kv_res is OV_GAME before it has read the file)
          for (let t = 0; t < 30; t++) {
            if (g.m.runTo([kwAddr], 921600) === kwAddr && ![0, ids.OV_GAME].includes(g.peek('kv_res'))) break;
            g.m.cpu.execute(1);
          }
          if (process.env.STRESS_DEBUG) for (let i = 0; i < 8; i++) { console.log('  resume', i, JSON.stringify(g.text()), 'n', g.peek('g_n'), 'res', g.peek('kv_res'), 'rec', g.rec().join(''), 'mode', g.peek('g_mode')); g.m.runSeconds(0.5); }
          if ((process.env.STRESS_DEBUG || process.env.STRESS_QUIT) && quitInfo) console.log('  quit:', JSON.stringify(quitInfo), 'left seen', left);
          // the same record as when quit ran (not the last key wait checked: a burst of keys can start
          // a new game and play moves in between); the Psion may have moved since: the title takes 2.5 s
          const was = quitInfo ? quitInfo.rec : lastRec;
          if (was !== null) {
            const rec = g.rec().join('');
            if (!rec.startsWith(was) || (rec !== was && !g.peek('g_psion'))) fail(`resumed record ${rec} was ${was} when it left`);
          }
          quitInfo = null;
          continue;
        }
        fail('the game stopped with an error');
      }
      if (/ERROR|MISSING|BATTERY|STACK|OUT OF/i.test(g.text())) fail('an error message');
      if (hit !== kwAddr) {
        quietS += 1 + spent;
        if (quietS > 300) {
          const pcs = new Map();                        // where it runs: array offsets
          counter = (pc) => { if (pc >= g.base && pc < g.base + asize) { const o = pc - g.base; pcs.set(o, (pcs.get(o) || 0) + 1); } };
          g.m.runSeconds(1);
          counter = null;
          const top = [...pcs.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([o, c]) => o.toString(16) + 'x' + c).join(' ');
          const r2 = regs(g.m);
          fail(`no key wait for ${quietS.toFixed(0)} s: PC ${r2.pc.toString(16)} SP ${r2.sp.toString(16)} kv_res ${g.peek('kv_res')} mode ${g.peek('g_mode')} ` +
            `psion ${g.peek('g_psion')} g_n ${g.peek('g_n')} over ${g.peek('g_over')} level ${g.peek('st_level')}; array offsets run: ${top}; stack ${g.m.read(r2.sp + 1, 12).map(b => b.toString(16)).join(' ')}`);
        }
        continue;
      }
      quietS = 0;
      st.waits++;
      // at a key wait: the code, then the state
      const now = g.m.read(g.base, kimg.length);
      for (let i = 0; i < kimg.length; i++) if (now[i] !== kimg[i] && !skip.has(i)) fail(`kernel byte ${i} (${i.toString(16)}) changed from ${kimg[i]} to ${now[i]}`);
      const res = g.peek('kv_res'), n = g.peek('g_n'), rec = g.rec(), over = g.peek('g_over');
      st.units.add(res);
      if (process.env.STRESS_COACH && !g.peek('st_coach')) { g.poke('st_coach', 1); st.coach = (st.coach || 0) + 1; }   // (the drop check, 19 Nov)
      if (/EXE drops it/.test(g.text())) st.warns = (st.warns || 0) + 1;
      if (n > 42) fail(`g_n ${n}`);
      const prevOver = lastOver, prevRec = lastRec;
      lastRec = rec.join(''); lastOver = over;
      if (res === ids.OV_PLAY || res === ids.OV_PLAY2) {
        st.plays++;
        if (over) fail('the play screen with the game over');
        if (g.peek('e_n') !== n) fail(`e_n ${g.peek('e_n')}, g_n ${n}`);
        const want = rowsOf(rec), bd = g.bytes('e_bd', 49);
        for (let c = 0; c < 49; c++) if (bd[c] !== want[c]) fail(`board cell ${c} is ${bd[c]}, the record ${rec.map(x => x + 1).join('')} gives ${want[c]}`);
        const sp = regs(g.m).sp;
        if (sp0 < 0) sp0 = sp; else if (sp !== sp0) fail(`stack at ${sp.toString(16)}, was ${sp0.toString(16)}`);
      } else if (res === ids.OV_END) {
        if (over !== 2) fail(`result screen with g_over ${over}`);
        const gres = g.peek('g_res');
        const p = S.fromMoves(rec.slice(0, -1));
        const four = rec.length > 0 && S.isWinningMove(p, rec[rec.length - 1]);
        if (!four && rec.length < 42 && !(gres & 12)) fail(`result without a four, a full board, a resignation or a flag (g_res ${gres})`);
        if (prevOver !== 2 || prevRec !== lastRec) st.games++;   // (a new result, not the same one again)
        st.results++;
      }
    }
    const s = `${rom.padEnd(14)} ok   ${minutes} min, ${st.keys} keys, ${st.waits} key waits checked (${st.plays} on the play screen), ` +
      `${st.games} results, ${st.leaves} leaves, ${st.full} times A: full, overlays seen ${[...st.units].sort((a, b) => a - b).join(',')}, ${st.warns ? st.warns + ' drop warnings, ' : ''}${((Date.now() - t0) / 1000).toFixed(0)} s`;
    console.log(s); summary.push(s);
  } catch (e) {
    failures++;
    const s = `${rom.padEnd(14)} FAIL ${e.message.split('\n')[0].replace(rom + ': ', '')}`;
    console.log(s + '\n' + e.message.split('\n').slice(1).join('\n'));
    summary.push(s);
  }
}
console.log(failures ? `${failures} ROMs FAILED` : `all ${roms.length} ROMs passed`);
process.exit(failures ? 1 : 0);
