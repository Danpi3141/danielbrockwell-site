; Engine test image for harness.js: the engine, its variables and test drivers.
E_FR    = $6000
E_TT    = $6800
        include "engine.asm"
        include "evars.inc"
e_col:  rmb  1
e_cx:   rmb  2
e_four: rmb  1
e_ounit: rmb 1
e_ki:   rmb  1
e_stp:  rmb  1
; the kernel's hook: never stop
t_poll: clc
        rts
