// The 6303 engine against ref/engine.js: every state byte after each make / unmake, the
// evaluation, and searches (move, score, depth, positions searched).
//   node tests/engine/t_match.js [games] [searches]
'use strict';
const { Harness } = require('./harness');
const E = require('../../ref/engine');
const h = new Harness();
let rnd = 777;
function rand(n) { rnd = (rnd * 1103515245 + 12345) & 0x7fffffff; return rnd % n; }
function refState(e) {
  const land = [];
  for (let c = 0; c < 7; c++) land.push(c * 7 + e.ht[c]);
  return { bd: e.bd, thr: e.thr, lc: e.lc, land, ev: e.ev, key: e.key, n: e.n, won: e.won };
}
function same(a, b, where) {
  for (const k of Object.keys(b)) {
    if (JSON.stringify(a[k]) !== JSON.stringify(b[k])) throw new Error(`${where}: ${k} differs\n asm ${JSON.stringify(a[k])}\n ref ${JSON.stringify(b[k])}`);
  }
}
const games = +(process.argv[2] || 200), searches = +(process.argv[3] || 100);
let moves = 0, evals = 0, cyc = 0;
for (let g = 0; g < games; g++) {
  const e = new E.Engine();
  h.call('eng_reset');
  const cols = [];
  for (;;) {
    const legal = [0, 1, 2, 3, 4, 5, 6].filter(c => e.canPlay(c));
    if (!legal.length) break;
    for (const k of [0, 48]) {
      e.noiseK = k; e.nseed = g & 255;
      h.poke('e_noise', k); h.poke('e_nseed', g & 255);
      const r = h.call('e_eval');
      const a = r.a > 127 ? r.a - 256 : r.a;
      if (a !== e.evaluate()) throw new Error(`eval differs game ${g} at ${e.n}: asm ${a} ref ${e.evaluate()} (${e.hist.map(c => c + 1).join('')})`);
      evals++;
    }
    const col = legal[rand(legal.length)];
    const four = e.make(col);
    const r = h.call('e_make', col);
    cyc += r.cycles; moves++;
    if (r.c !== four) throw new Error(`four differs game ${g}`);
    same(h.state(), refState(e), `game ${g} after ${e.hist.map(c => c + 1).join('')}`);
    cols.push(col);
    if (four) break;
  }
  while (cols.length) {
    const col = cols.pop();
    e.unmake(); h.call('e_unmake', col);
    same(h.state(), refState(e), `game ${g} unmake to ${e.n}`);
  }
}
console.log(`make/unmake: ${moves} moves in ${games} games identical; ${evals} evaluations identical; make ${Math.round(cyc / Math.max(moves, 1))} cycles`);

// searches from random positions (no four yet), at each level in turn
let ok = 0, tn = 0, tc = 0;
for (let i = 0; i < searches; i++) {
  const e = new E.Engine(); h.call('eng_reset');
  const n = rand(30);
  let bad = false;
  for (let k = 0; k < n; k++) {
    const legal = [0, 1, 2, 3, 4, 5, 6].filter(c => e.canPlay(c));
    const col = legal[rand(legal.length)];
    if (e.make(col)) { bad = true; break; }
    h.call('e_make', col);
  }
  if (bad) { i--; continue; }
  const lvn = 1 + (i % 8), lv = E.LEVELS[lvn];
  const o = { nodes: lv.nodes, depth: lv.depth, noise: lv.noise, seed: i * 37 };
  const want = e.think(o);
  const got = h.think(o);
  const w = { move: want.move, score: want.score, depth: want.depth, nodes: want.nodes, exact: want.exact };
  const g2 = { move: got.move, score: got.score, depth: got.depth, nodes: got.nodes, exact: got.exact };
  if (JSON.stringify(w) !== JSON.stringify(g2)) {
    console.log('search differs', e.hist.map(c => c + 1).join(''), 'level', lvn, '\n ref', JSON.stringify(w), '\n asm', JSON.stringify(g2));
    process.exit(1);
  }
  ok++; tn += got.nodes; tc += got.cycles;
}
console.log(`searches: ${ok} identical; ${tn} positions, ${Math.round(tc / Math.max(tn, 1))} cycles a position (${Math.round(921600 * tn / Math.max(tc, 1))} a second, no OS)`);
