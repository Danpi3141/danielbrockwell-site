// The Psion's searched moves in the game against ref/engine.js at the same level
// (level 5: 2,500 positions, no noise), with random replies; also the time a search takes.
'use strict';
const { Game, assert } = require('./lib');
const E = require('../../ref/engine');
const model = process.argv[2] || 'lz64', games = +(process.argv[3] || 3), level = +(process.argv[4] || 5);
let rnd = 7; const rand = n => { rnd = (rnd * 1103515245 + 12345) & 0x7fffffff; return rnd % n; };
let checked = 0, secs = 0;
for (let gi = 0; gi < games; gi++) {
  const g = new Game(model).start();
  g.waitHuman(60);
  g.poke('st_level', level);
  g.poke('st_pace', 1);
  g.poke('st_you', gi % 2);
  g.keys(['ON', 'EXE', 'EXE'], 1.5);
  const psionFirst = g.peek('g_psion') === 1;
  for (let ply = 0; ply < 42 && !g.peek('g_over'); ply++) {
    const n = g.peek('g_n');
    const psionToMove = (n % 2 === 0) === psionFirst;
    if (psionToMove) {
      const rec = g.rec();
      const t0 = g.m.cycles();
      g.waitFor(() => g.peek('g_n') === n + 1, 120, 0.05);
      const got = g.recAt(n);
      if (n >= 6) {                          // past the level's 3 book moves
        const e = new E.Engine();
        for (const c of rec) e.make(c);
        const want = E.LEVELS[level];
        const r = e.think({ nodes: want.nodes, depth: want.depth, noise: 0 });
        assert(got === r.move, `search: after ${rec.map(c => c + 1).join('')} the Psion played ${got + 1}, reference ${r.move + 1}`);
        checked++; secs += (g.m.cycles() - t0) / 921600;
      }
    } else {
      g.waitFor(() => g.peek('g_over') || g.humanTurn(), 60, 0.1);
      if (g.peek('g_over')) break;
      let c; do { c = rand(7); } while (g.bytes('e_bd', 1, c * 7 + 5)[0] !== 0);
      g.waitFor(() => g.peek('g_over') || g.humanTurn(), 60, 0.1);
      if (g.peek('g_over')) break;
      g.key('UVWOPQI'[c], 0.1);
      g.m.press('EXE', 3, 0);
      g.waitFor(() => g.peek('g_n') === n + 1, 5, 0.02);
    }
  }
  console.log(model, 'game', gi, g.recStr(), 'result', g.peek('g_res'));
}
console.log(`searched moves checked: ${checked}, ${(secs / Math.max(checked, 1)).toFixed(1)} s a move on average`);
