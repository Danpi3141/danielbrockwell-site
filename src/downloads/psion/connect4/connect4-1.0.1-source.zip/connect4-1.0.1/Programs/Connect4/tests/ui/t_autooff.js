// Left alone, the Organiser must switch itself off (its idle time set to 20 s) on every screen
// where nothing has to keep time: your move (after the ghost disc's rest), the menu, the move
// list, the review, help, the result (after the winning four's 15 s of blinking), a two-player
// turn with no clock or timer; with a move timer it stays on and the timer drops the disc. After
// switching on, the board's glyphs are as before.
//   node tests/ui/t_autooff.js [model] (default cm)
'use strict';
const { Game, assert } = require('./lib');
const model = process.argv[2] || 'cm';
let udg0 = null;
const off = (g) => { const a = []; g.m.cpu.getSnapshotData(a); const pc = a[5] << 8 | a[6]; return !g.text().trim() && pc >= 0x8000; };
function idle(g, name, maxS = 120) {
  g.m.poke(0x20CD, 0); g.m.poke(0x20CE, 20);
  udg0 = g.m.udgs();
  let t = 0; for (; t < maxS && !off(g); t += 1) { udg0 = g.m.udgs(); g.m.runSeconds(1); }   // (the glyphs just before it went off)
  const ok = off(g);
  console.log(model, name.padEnd(28), ok ? `switched off after ${t} s` : `STILL ON after ${maxS} s: ${JSON.stringify(g.text())}`);
  assert(ok, `${model}: ${name}: it did not switch itself off`);
  const before = JSON.stringify(udg0);
  g.m.press('ON', 3, 10); g.m.runSeconds(1.5);
  assert(JSON.stringify(g.m.udgs()) === before, `${model}: ${name}: the glyphs after switching on`);
}
const g = new Game(model).start();
g.waitHuman(60);
g.poke('st_pace', 1);
idle(g, 'one player, your move');
g.key('ON', 1); idle(g, 'menu'); g.key('ON', 1);
g.waitHuman(30); g.key('UP', 1); idle(g, 'move list'); g.key('ON', 1);
g.waitHuman(30); g.keys(['ON', 'R', 'EXE'], 1); idle(g, 'review'); g.key('ON', 1);
g.waitHuman(30); g.keys(['ON', 'H', 'H', 'EXE'], 1); idle(g, 'help'); g.key('ON', 1);
g.waitHuman(30); g.keys(['ON', 'R', 'R', 'EXE'], 2); idle(g, 'result (resigned: no four)');
// a game the Psion wins with a four
g.key('EXE', 2); g.waitHuman(60); g.poke('st_level', 2);
for (let k = 0; k < 40 && !g.peek('g_over'); k++) { g.waitFor(() => g.peek('g_over') || (g.humanTurn() && (g.peek('g_n') % 2) + 1 !== g.peek('g_psion')), 60, 0.1); if (g.peek('g_over')) break; let c = 0; while (g.bytes('e_bd', 1, c * 7 + 5)[0]) c++; const n = g.peek('g_n'); g.key('UVWOPQI'[c], 0.1); g.key('EXE', 0.3); g.waitFor(() => g.peek('g_n') > n, 5, 0.05); }
g.waitFor(() => g.peek('g_over') === 2, 20); g.m.runSeconds(1);
idle(g, 'result (a four blinking)');
// two players, no clock, then with a clock
g.keys(['ON', 'EXE'], 0.5); g.keys(['DOWN', 'EXE'], 0.5); g.names('', ''); g.waitHuman(30);
idle(g, 'two players, no clock');
// two players with a move timer: it must stay on (the timer drops the disc)
g.poke('st_timer', 1); g.key('LEFT', 0.5); g.key('RIGHT', 0.5);
g.keys(['ON', 'EXE'], 0.5); g.keys(['DOWN', 'EXE'], 0.5); g.names('', ''); g.waitFor(() => g.humanTurn(), 30);
const n0 = g.peek('g_n'); g.m.runSeconds(25);
assert(g.peek('g_n') > n0, `${model}: the move timer did not drop a disc: ${g.text()}`);
console.log(model, 'two players, 10 s move timer    the timer dropped a disc (it stays on, as it should)');
console.log(model, 'auto switch-off ok');
