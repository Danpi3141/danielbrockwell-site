; ---------------------------------------------------------------------
; Pack: the game's blocks C4B0 (screens and drivers) and C4B1 (the book)
; are procedures on the device the kernel came from.
; ---------------------------------------------------------------------

; seek to kv_pa on the game's device (PK$SETP again only if another device
; may have been selected since: the file services clear kv_pkok)
pk_seek:
        tst  kv_pkok
        bne  .sel
        clra
        ldab kv_dev
        os   PK$SETP
        inc  kv_pkok
.sel:   ldab kv_pa
        ldx  kv_pa+1
        os   PK$SADD
        rts

; position the pack at offset X in block B (0 or 1)
pk_at:  stx  kv_t0
        ldaa #3
        mul
        addd #kv_dir
        xgdx
        ldd  1,x
        addd kv_t0
        std  kv_pa+1
        ldaa 0,x
        adca #0
        staa kv_pa
        bra  pk_seek

; ---------------------------------------------------------------------
; ov_load: A = id (1..). Loads it unless it is there already: an overlay
; into slot A, a screen driver (DRV2, DRV4) at DRV. Adds the array's
; address to its fix-ups. Its offset in block 0 is in the table at B0_OVT there.
; ---------------------------------------------------------------------
ov_load:
        cmpa kv_res
        beq  .x                 ; already there
        staa kv_t2
        ldx  #SLOTA
        cmpa #OV_THINK          ; (the search's poll: the top of slot A)
        bne  .t
        ldx  #THINKAT
.t:     cmpa #DRV2
        blo  .s
        cmpa #DRV4
        bhi  .s
        ldx  #DRV
.s:     stx  kv_t1              ; where it goes
        tab
        aslb
        addb #B0_OVT-2          ; its entry in the table at the start of block 0
        clra
        xgdx
        clrb
        jsr  pk_at
        os   PK$RWRD            ; D = its offset in block 0
        std  kv_t3
        beq  .gone              ; the pack is gone (it reads as 0s)
        xgdx
        clrb
        jsr  pk_at
        os   PK$RWRD            ; D = code length
        std  kv_t3
        beq  .gone              ; the pack is gone (it reads as 0s)
        ldx  kv_t1
        os   PK$READ            ; the code
        os   PK$RBYT            ; the fix-ups: their length (tools/build.py encode_fixups)
        stab kv_t3
        ldd  kv_t1
        std  kv_fo              ; where the last fix-up was (to start, the code)
.nx:    tst  kv_t3
        beq  .done
        bsr  ov_byte            ; two steps
        bra  .nx
.done:  ldaa kv_t2
        cmpa #DRV2
        blo  .r
        cmpa #DRV4
        bls  .x                 ; a driver: slot A unchanged
.r:     staa kv_res
.x:     rts
.gone:
pk_gone: ldab #E_NOPACK
        jmp  quit

; the next encoded fix-up byte from the pack: its two steps, the high
; nibble first
ov_byte:
        os   PK$RBYT
        dec  kv_t3
        pshb
        lsrb
        lsrb
        lsrb
        lsrb
        bsr  ov_step
        pulb
        andb #15
; B = a step: 1-15 on that far and add the array's address to the word
; there; 0 on 15
ov_step:
        tstb
        beq  .z
        bsr  .on
        ldd  0,x
        addd kv_base
        std  0,x
        rts
.z:     ldab #15
.on:    ldx  kv_fo
        abx
        stx  kv_fo
        rts
