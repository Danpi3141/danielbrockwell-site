# Psion Spins

A five-reel Christmas slot machine for play-money credits, in 6303 machine code, for every Organiser II from the 8K CM to the LZ64, built from *Psion Spins: a Christmas slot machine for the Psion Organiser II* (the spec, `docs/spec.docx`, 20 Nov 2026). One 32K Datapak serves every model: the start-up code reads the model byte and loads the two-line (CM, XP, LA: 5 reels by 2 rows) or four-line (LZ, LZ64: 5 by 4) screen driver; the game, its pay table and its return are the same on both.

The credits have no value; nothing can be bought, sold or cashed.

## Status (20 Nov 2026)

- **The whole core spec is built** and tested in the emulator on the CM, XP, LA, LZ and LZ64, and starts, plays a spin with Santa and leaves cleanly on all 29 Organiser ROMs the emulator has (`tests/t_roms.js`).
- **The game** matches the reference engine (`ref/game.js`) spin for spin: 100,000 spins on each grid, no difference (`tests/t_long.js`). The return, counted exactly from the strips: 95.732% (four lines), 95.726% (two lines), as the spec says.
- **Stretch goals**: the advent calendar, four more walk styles, the gamble, the elf helper, New Year, snow that settles, the session record and two-part music (below). Not done: sound-through drawing (only worth its 120 bytes if the gap at each frame start is heard on a real Organiser), and hold and nudge (it changes the return; the spec itself says it may not come).
- **Two-part music (20 Nov)**: every tune has a bass line (written for this game; the carol melodies are all published before 1900). The sound engine keeps two voices: while both sound the melody has two ticks in three and the bass one, while one rests the other has them all; the extra work is charged to the tick's budget, so tunes keep time as before (`tests/t_sound.js` checks both voices are heard and the time). It cost 126 bytes of the array: 85 of code, 11 of variables, and the tune buffer grew from 80 to 121 bytes (HARK), which makes region R 25 bytes bigger.
- **Title tune and autoplay (20 Nov, later)**: the opening Jingle Bells was hard to recognise: its repeated notes (E E E) are told apart only by a silent tick at each note's end, and the bass filled that silence, so they ran together. Now the bass keeps quiet in the melody's gap, the gap is 3 ticks (25 ms) on notes of 12 ticks or more, and the melody has two ticks in three. During autoplay the panel says AUTO through every spin (before, only for a moment at rest; the A key starts autoplay, as before), and the autoplay list (or the menu, after Spin) no longer leaves its letters between the reels.
- **Cuts and a bug hunt (20 Nov)**: the kernel lost 122 bytes with nothing changed that shows or sounds: the Xmas Spins' set-up and counting moved into OV_GAME (G_XINIT, G_FREE), every overlay call in the main loop is `bsr ovc` and two bytes (4 bytes instead of 6), the tone set-up's three range clamps share one routine, and 15 short branches the assembler had silently made long were brought back in range by moving code. Then new tests set out to break it (`t_watch.js`, `t_break.js`) and found three bugs, now fixed: the advent calendar never opened again in a later December; the Organiser switched itself off in the middle of autoplay, a long Xmas Spins or the snow (after its switch-off time, 5 minutes as it comes), leaving the screen blank and then garbled; and on a two-line model it never switched off at all while the game sat idle (each idle scene started the 5-minute count again). A save file whose checksum still agreed but whose settings were out of range is now put right as it is read.
- **RAM round (20 Nov)**: the array went from 5,774 to 4,849 bytes and a blank CM's spare RAM from 246 to 1,172 bytes, with every screen the same (below, *Where the RAM went*). Two bugs of the first build turned up and are fixed: a crash when several lines won (most often at Quick, so in autoplay), and Santa throwing with the wrong pose.
- **Not yet checked**: what only real hardware shows (below, *Real hardware*).

## Run

In Jape (https://www.jaapsch.net/psion/jape/jape.htm): **Select OPK file** → `build/game/SPINS.opk` → **Create** → **Slot B**, then **Prog → Run → B:SANTA**. The emulator has no buzzer: the sounds are in `build/sound/*.wav` (`node tools/sounds.js`), made from the game's own sound engine.

On a real Organiser: `python tools/build.py --psion` writes `psion/`: the pack's files as .OB3 procedures and RPLOAD's list, for sending to a Datapak through a Comms Link (as for Connect 4 and Reversi). Run SANTA.

## Build

```bash
python tools/build.py [--psion]
```

`build/game/SPINS.opk` (a 32K Datapak image), `build/game/budget.txt` (RAM and pack), listings and symbol tables. `node tools/maths.js both --sim 1000000` counts the return exactly and simulates a million plays on each grid.

## Playing

| Key at the reels | |
|---|---|
| EXE | Spin. During a spin: every reel stops at once. During any animation: skip it (the result is the same) |
| UP, DOWN | The line bet: 1, 2, 5, 10 (a spin is 20 line bets) |
| A | Autoplay: 10, 25, 50 spins, or until the Xmas Spins (at the Quick pace; Santa's walk in full) |
| P, L, S | Pay table, line viewer, statistics |
| G | After a win: gamble it (stretch goal) |
| MODE | The menu: Spin, Bet, Autoplay, Pay table, Lines, Statistics, Settings, Jukebox, Scenes, Help, New player, Quit |
| ON | Stops autoplay; otherwise asks "Leave?" (EXE leaves: the goodbye, saved) |

Settings: Animation (Full, Quick, Off), Santa's styles (All, Standard), Sound (On, Soft, Off), Music (On, Off), Glass speed (8, 10, 12, 15 frames a second), Show wins (Lines, Total), Autoplay stops (on a feature, on a big win, never), Idle scenes (On, Off). The balance, bet, settings, statistics and random state are saved in A:SANSAV after every spin (before its animation starts).

## How it is built

`docs/design.md` has the architecture; in short:

- **Files on the pack**: SANTA (checks the free memory: "SANTA NEEDS n BYTES MORE RAM"), SANTAG (makes the array and starts the bootstrap), SANK (the kernel, its fixer and fix-ups, then an index and every overlay and data item: art, scripts, tunes, effects, tables, the command table). The spec's SANB0-3 are sections of SANK, found through the index.
- **The array** (4,898 bytes, the same on every model): the kernel (3,001 of code: overlay loader, keys, text, the frame player, the sound engine, the script reader, the panel; 289 of variables) | the screen driver (94) | region R (1,514): one overlay, the data it reads in right after its code, and the playing tune at the top (121 bytes). The spec planned a fixed overlay slot and a separate 600-byte scene buffer; sharing one region is smaller.
- **Variables outside the array** (256 bytes, as Connect 4 and Reversi do): in the launchers' code that never runs again once the game has started. Below the array, SANTAG's code before its USR call (its copy of the bootstrap string among it) holds the screen model and the number's digits (175 of 178 bytes); above it, SANTA's code before its call of SANTAG holds Santa's pose and halo and the script stack (44 of 45), and SANTA's "NEEDS" message holds the wins and the 32-bit work (37 of 41). The build finds the holes in the launchers' translated code; the start-up code checks that SANTA's and SANTAG's code that does run again is where the build put it, and refuses with SPINS ERROR 3 if not (SANTAG run by itself); `tests/t_hidden.js` checks it all on every ROM.
- **The screen model**: what every cell should show (`kv_under`) against what the LCD shows (`kv_shown`); a frame sends only what changed, straight to the display controller, and the 8 defined characters from a shadow copy. The character rule of the spec holds: slots 0-3 the pictures (redrawn only in place), 4-7 the stage.
- **The frame player**: a frame draws, then sounds for the rest of its length, a tick (1/120 s) at a time; the drawing time (since the last frame ended, on the free-running counter) is taken off.
- **The sound engine**: a tone is a loop of 32 + 4S cycles (all 45 notes from E4 to C8 within 0.7% of pitch), with pulse width (bells that ring and die away; the Soft setting), slides, arpeggios, noise, clicks and vibrato; tunes in two parts, melody and bass, a tick each in turn; an effect and a tune play together, the effect heard. Frames keep time within 1% with sound on, soft or off (`tests/t_sound.js`).
- **Scripts**: the scenes are data (`scripts/*.scr`, assembled by `tools/script.py`), played by the resident script reader; directors (overlays) handle what a script cannot.
- **The compositor**: Santa (5 by 16 dots) in a moving window of the four stage characters, one dot at a time, with a halo one dot wide, over whatever the cells show (`src/screens/comp.inc`).

## The tests

`node tests/run_all.js [--quick]` runs the main suite (a few minutes). The long ones run on their own:

| Test | What it shows |
|---|---|
| `t_linefast.js` | The 6303's way to pay a line equals brute force on all 161,051 lines |
| `t_game.js`, `t_long.js` | OV_GAME against ref/game.js, spin for spin (100,000 on each grid: no difference); return, hit rate, chi-squared of the stops |
| `t_sound.js` | Pitch of every note; frame lengths with each sound and setting |
| `t_walk.js`, `t_delivery.js` | The compositor; Santa's delivery |
| `t_flow.js` | Whole plays (a Santa spin, a feature, a win): the credits end right on both models |
| `t_save.js`, `t_auto.js`, `t_xmasday.js`, `t_stretch.js` | The save file, autoplay, Christmas Day, the stretch goals |
| `t_skip.js` | EXE at every moment of a play ends in the same state as no key |
| `t_trace.js` | Every screen, frame by frame, of a set of plays (Santa, a win, the Xmas Spins at Full, Quick and Off; all ten walk styles; every scene; the menus and pages) against a reference recorded from another build (`--save --build dir`); the cosmetic random bytes are pinned so timing does not matter. The RAM round was checked against the first build (with its two bugs fixed): 6,080 screens on the LZ64 and 4,837 on the CM, the same |
| `t_hidden.js` | The variables in the launchers' code, on all 29 ROMs: the code that runs again intact after play, leaving clean, starting again resumes; SANTAG alone refused |
| `t_stress.js` | 20 minutes of random keys on the CM and the LZ64 |
| `t_watch.js` | Every memory write the game's own code makes, watched during long random play with random settings: anything outside the variables, region R, the holes, the stack, the LCD and the OS's switch-off count is reported with the instruction that made it; the kernel and driver checked unchanged after every key. 15 to 20 minutes each on the CM, XP, LZ and LZ64: none |
| `t_break.js` | Experiments: the advent calendar over two Decembers; save files damaged (length, tag, version, a byte) and with settings out of range; credits from 0 to 4,294,967,000; the pack pulled out; idle at rest until the Organiser switches off, then on; autoplay longer than the switch-off time; the pack in slot C; the Xmas Spins' count at the 250 cap against ref/game.js; the tune buffer intact while tunes play over Santa's walks and wins; EXE held for a minute |
| `t_roms.js` | All 29 ROMs |
| `m_mem.js`, `m_mem2.js` | The memory margin on the smallest machines (below): through SANTA as it is, and with SANTA's check made to pass (where the game itself runs short) |
| `tour.js`, `shots.js` | PNG screenshots (`build/shots/`) |

## Measured

| | |
|---|---|
| Return, exact | 95.732% (four lines), 95.726% (two lines) |
| 100,000 spins in the emulator | 94.6% (four), 98.6% (two): within sampling error; 0 differences from the reference |
| Santa lands, Xmas Spins | 1 spin in 8; 1 in 62.3; 13.5 free spins a feature |
| A spin, Full | about 2.5 s to the last reel; Santa's delivery about 4 s |
| Memory | Array 4,898 bytes; SANTA asks for 5,268 free on a machine without A:SANSAV, 5,148 once it exists |
| Spare RAM | 1,122 bytes on a blank CM (3.3 ROM; the spec planned about 340), at least 2,000 on an LZ (`tests/m_mem.js`: the largest padding with which SANTA still starts and plays). The game itself runs short at 1,172 (`m_mem2.js`): SANTA refuses cleanly 48 bytes before that |
| Pack | 27,418 of 32,768 bytes |

## Where the RAM went (20 Nov)

| | Before | After | How |
|---|---:|---:|---|
| Kernel code | 3,380 | 2,990 | The script reader keeps only the 19 commands the scenes use, and its commands no longer return a carry (-200); notes one byte each, the high byte from the note number (-35); numbers by dividing by 10 instead of a table of powers of ten, and `num_at` through `txt_at`; the command table on the pack (IT_CMDS); `ov_call` pushes the entry; `glyph_ld` by the OS's copy |
| Variables in the array | 579 | 276 | Dead ones gone (`kv_xtot`, `kv_size`, `kv_drv`, `kv_rtgt`, the handlers of the dropped commands); OV_GAME's own (stops, stars, the feature's count and total) in OV_GAME; the wins one byte a line (40 to 20); 256 bytes into the launchers' code |
| Region R | 1,721 | 1,489 | OV_WALK read every style's poses and effects (and five tunes it never used): now one small blob per style (WALK0-9), its style row in the blob; OV_SPINFX plays no tune, so needs no tune buffer above it. OV_SPINFX (1,277 + 212) sets the size now |
| **Array** | **5,774** | **4,849** | |
| Spare on a blank CM | 246 | 1,172 | |

Two bugs of the first build, found by the new frame-by-frame check and fixed:

- **A crash when several lines won**: OV_WINFX's line cells, characters and text buffer (21 bytes) were declared after the label where its line table is read in, so once one winning line had been shown, lines 1-5 had garbage rows and `put` wrote outside the screen model, into the screen driver's code. It showed most at Quick (autoplay) in the Xmas Spins.
- **Santa's throw**: `ldaa #P_THROW1` sat between the flag test and its branch, so every style threw with the tiptoe's finger-to-lips pose.

Not done from the list of savings: moving the statistics out to the save file (the save record could go into the launchers' code instead, but their holes are full), and the two-line models' smaller array (the screen model left the array altogether, so it would save only the driver's 41 bytes, with a model-dependent layout).

## What the bug hunt found (20 Nov)

| Found by | What happened | Fixed |
|---|---|---|
| `t_break.js advent` | The advent doors are bits in the save; nothing cleared them, so after one December no door opened again | The save keeps the year the doors were opened in (`st_dyear`, save version 2); a new year shuts them all |
| `t_break.js switchoff`, `autoplay` | The Organiser counts down its switch-off time and only the game's key waits set it back. Autoplay, a long Xmas Spins or the snow (four lines) run without one, so after 5 minutes (the Organiser's default) it switched off mid-play; on again the screen was blank, then garbled, autoplay going on | Every frame sets the count back (`frame_t`): the Organiser now switches off only in the game's own key wait, which redraws everything when it is on again |
| the same | On a two-line model the idle count lived in OV_REST's image, so every idle scene (each 80 s) started it again: it never reached 5 minutes and the Organiser never switched off at rest | The count is kept in `kv_idlen` over the snow and the scenes; the snow ends by itself after 25 s; a key starts the count again |
| `t_break.js gaps` (after a listen) | Choosing autoplay, or Spin from the menu, went straight into a spin with the list still in the screen; the spin redraws only the reels and the panel, so the list's letters stayed between the reels | The menu clears the screen before it hands over to a spin |
| a listen | The winning line's text, "LINE 12 +1234", is longer than the panel's 10 characters and was cut off, so the pay shown was wrong ("LINE 10 +4" for +40, even "LINE 2 +30" for +300) | As the other panel lines: the line on the left, its pay right-aligned, "L12   +120" (at most "L20  +8000"); the traces were checked: only that text changed |
| `t_break.js badsettings` | A save whose sum still agrees (one damaged file in 256) could hold settings out of range: frame lengths and lists read past their tables | Out of range: the setting's first choice |

Not changed: credits of a billion or more show their last 8 digits (the panel's room); a player would need millions of winning spins to get there. Pulling the pack out ends the game quietly (back to the Organiser's menu) without a message.

## Where this build differs from the spec

- **Interrupts during notes**: the spec masks the 50 ms keyboard interrupt while a note sounds. Here interrupts stay on: the emulator drops a timer interrupt that comes due while masked, so keys and the clock would stop there; on the Organiser the interrupt's few hundred cycles make a small gap every 50 ms. This is the first thing to judge by ear on real hardware.
- **Memory**: the array is 4,898 bytes (the spec planned 5,600), though the sound engine came out at about 700 bytes (planned 420) and the overlays are bigger than planned: region R is shared, and some variables live in the launchers' code.
- **Tunes keep their tempo** when Glass speed changes; only the animation frames scale.
- **Every position wild** (the "full house" scene) cannot happen with the spec's strips (no reel has enough houses); the scene can be seen from the Scenes menu.
- **Scenes** are simpler and mostly shorter than the spec's lengths, and their art is a first draft: the spec leaves the look to be judged on real glass.
- **Christmas Day** gives 250 credits (the spec does not say how many); the **advent** gift is three free spins at the line bet; the **gamble** is offered once per base win (G).
- **File layout**: one data file (SANK) with an index instead of SANB0-3.

## Real hardware (the spec's milestones that need it)

Glass: whether Santa's one-dot steps and the drums read as motion or smear (Glass speed is the setting to try). Sound: the gap of the keyboard interrupt in notes, pulse width (the bells and Soft), the frame-start gap, loudness. Battery drain over a session. The test plan's ROM and memory checks are done in the emulator.

## About this repository

One of the Psion Organiser II projects on Forgejo (`Daniel/Psion-*`). The build and test scripts expect the PsionII workspace layout:

```
PsionII/
  Emulator/          Jape, Jaap Scherphuis's emulator, with its ROM images (not in any repo:
                     https://www.jaapsch.net/psion/jape/jape.htm)
  Tools/             Daniel/Psion-Tools (opltran, opl2opk, RPBOOT/RPLOAD, ...)
  Programs/NAME/     this repository
```

`build/` is not committed: the build scripts recreate it.
