; =====================================================================
; RPLOAD's per-file work in machine code: timing each file, the ETA fit
; and drawing the status screen. OPL keeps the file list, the menu and
; XTRECV: itself, and calls this once per file:
;
;     mc%(1)=k% :USR(e%,ADDR(mc%()))
;
; mc%() holds this routine's variables (the first S bytes) and then the
; code. X points at mc%() throughout, so variables are n,x and the
; helpers in the first bytes of the code are called with jsr name,x.
; Nothing refers to an absolute address inside mc%() (calls are bsr,
; jsr name,x, or jsr FAR,x for distant ones), so the code needs no
; relocation. Tools/mkrpdata.py assembles this file and embeds it in
; RPLOAD; rpdec.asm unpacks it.
;
; Inputs, set by OPL (byte offset = 2*(index-1)):
;   K      mc%(1)  -1 mark the time; -2 A0 = time since the mark;
;                  0..n = files done so far (0 also clears the sums)
;   SZ     mc%(2)  size of file K, the one about to be fetched (<32768)
;   N      mc%(3)  number of files
;   TOT16  mc%(4)  total bytes / 16
;   FNAME  mc%(5)  address of f$ (name of file K)
;
; Time per file is fitted as  d = a + b*u  (d in 50 ms frames, u = size
; in 64-byte units) by least squares over the files done so far, as the
; OPL version did with floats; a and b are kept x16. Until 3 files are
; done (or if they don't fit), a is the time RPDATA took and b is worked
; out from the total so far, starting at 500 bytes/s.
; =====================================================================
TMB_MINS = $20C9
TMB_SECS = $20CA
TMW_FRAM = $20CB

; variables (offsets 10 and 13 are avoided: LF and CR in the code)
K       = 0
SZ      = 2
N       = 4
TOT16   = 6
FNAME   = 8
FPREV   = 11            ; frame counter at the last mark
CPREV   = 14            ; seconds into the hour at the last mark
PSZ     = 16            ; size of the file being fetched
A0      = 18            ; frames RPDATA took
AA      = 20            ; a x16
BB      = 22            ; b x16
MA      = 24            ; mul16 inputs
MB      = 26
Q       = 28            ; div8 quotient
W       = 30            ; percent done
REM     = 32            ; div8 remainder
DV      = 33            ; div8 divisor
LN      = 34            ; next column for putc (left part of a line)
RP      = 35            ; column putr wrote last (right part)
DONE    = 36            ; 32-bit, cleared at K=0: bytes fetched
SX      = 40            ;   sums of u, d, u*u, u*d
SY      = 44
SXX     = 48
SXY     = 52
NUMV    = 56            ; 32-bit work
R0      = 60
R1      = 64
R2      = 68
T3      = 72
E32     = 76
SY16    = 80
LBUF    = 84            ; 20 bytes: the line being built
S       = 104           ; code starts here
UU      = Q             ; size of the last file in units (not used with div8)
DD      = T3            ; frames it took (not used with div32)
CNOW    = R2            ; (elapsed only)
ESEC    = E32           ; ETA in seconds (after eta)

        seg  code
entry:  xgdx                    ; X = mc%() from here on
        jmp  MAINT,x

; ---------------------------------------------------------------------
; Helpers within reach of jsr NAME,x (S..255); NAME = S+name-entry

; jsr FAR,x / fdb S+target-entry: call a routine bsr can't reach, with
; X and D intact
far:    pshx                    ; room for the target address
        pshb
        psha
        pshx                    ; stack: 0 mc%(), 2 D, 4 target, 6 return
        tsx
        ldd  6,x                ; return address = the fdb
        addd #2
        std  6,x                ; return past it
        subd #2
        xgdx
        ldd  0,x                ; target offset in mc%()
        tsx
        addd 0,x                ; + mc%()
        std  4,x
        pulx
        pula
        pulb
        rts                     ; to the target

; append A to the left part of the line
putc:   pshx
        ldab LN,x
        inc  LN,x
        abx
        staa LBUF,x
        pulx
        rts

; R1 = the 32-bit variable at offset B
ldr1:   pshx
        abx
        ldd  2,x
        pshb
        psha
        ldd  0,x
        tsx
        ldx  2,x
        std  R1,x
        pula
        pulb
        std  R1+2,x
        pulx                    ; (the same mc%())
        rts

; R0 = the variable at offset B
ldr0:   bsr  ldr1
        ldd  R1,x
        std  R0,x
        ldd  R1+2,x
        std  R0+2,x
        rts

; variable at offset B += R0 (R0 = the sum)
accv:   pshb
        bsr  ldr1
        ldd  R0+2,x
        addd R1+2,x
        std  R0+2,x
        ldd  R0,x
        adcb R1+1,x
        adca R1,x
        std  R0,x
        pulb
;       fall into stv
; variable at offset B = R0
stv:    pshx
        abx
        pshx                    ; the variable's address
        tsx
        ldx  2,x                ; mc%()
        ldd  R0+2,x
        pshb
        psha
        ldd  R0,x
        tsx
        ldx  2,x                ; the variable
        std  0,x
        pula
        pulb
        std  2,x
        pulx
        pulx                    ; mc%()
        rts

; R0 = MA * MB (unsigned 16 x 16)
mul16:  ldaa MA+1,x
        ldab MB+1,x
        mul
        std  R0+2,x
        ldaa MA,x
        ldab MB,x
        mul
        std  R0,x
        ldaa MA+1,x
        ldab MB,x
        mul
        bsr  .mid
        ldaa MA,x
        ldab MB+1,x
        mul
.mid:   addd R0+1,x
        std  R0+1,x
        bcc  .r
        inc  R0,x
.r:     rts

maint:  bra  main

; frames since the last mark (frame counter, checked against the clock),
; then mark again
elapsed: ldaa TMB_MINS
        ldab #60
        mul
        addb TMB_SECS
        adca #0                 ; seconds into the hour
        std  CNOW,x
        subd CPREV,x
        bcc  .p
        addd #3600
.p:     subd #3000              ; at most 3000 s
        bls  .s
        clra
        clrb
.s:     addd #3000
        std  T3,x
        asld
        asld
        addd T3,x
        asld
        asld
        std  T3,x               ; frames by the clock
        ldd  TMW_FRAM
        pshb
        psha
        subd FPREV,x
        std  T3+2,x             ; frames by the counter
        pula
        pulb
        std  FPREV,x
        ldd  CNOW,x
        std  CPREV,x
        ldd  T3+2,x             ; trust the counter unless 1.5 s out
        subd T3,x
        addd #30
        subd #61
        ldd  T3+2,x
        bcs  .ok
        ldd  T3,x
.ok:    rts

; ---------------------------------------------------------------------
main:   ldd  K,x
        bpl  .k
        incb
        beq  elapsed            ; -1: mark the time
        bsr  elapsed            ; -2: time since the mark is RPDATA's
        std  A0,x
        rts
.k:     bne  .acc
        pshx                    ; 0: clear the sums, start the clock
        ldab #DONE
        abx
        ldaa #20
.z:     clr  0,x
        inx
        deca
        bne  .z
        pulx
        bsr  elapsed
        bra  .next
.acc:   bsr  elapsed            ; account for the file just fetched
        std  DD,x
        ldd  #1
        std  MB,x
        ldd  PSZ,x
        std  MA,x
        jsr  MUL16,x            ; R0 = size
        ldab #DONE
        jsr  ACCV,x
        ldd  PSZ,x
        addd #32
        lsrd
        lsrd
        lsrd
        lsrd
        lsrd
        lsrd
        std  UU,x
        std  MA,x
        jsr  MUL16,x            ; R0 = u
        ldab #SX
        jsr  ACCV,x
        ldd  DD,x
        std  MA,x
        jsr  MUL16,x            ; R0 = d
        ldab #SY
        jsr  ACCV,x
        ldd  UU,x
        std  MA,x
        std  MB,x
        jsr  MUL16,x
        ldab #SXX
        jsr  ACCV,x
        ldd  DD,x
        std  MB,x
        jsr  MUL16,x
        ldab #SXY
        jsr  ACCV,x
.next:  ldd  SZ,x
        std  PSZ,x
        jsr  FAR,x             ; percent = DONE/16*100 / TOT16, at most 100
        fdb  S+done16-entry
        std  MA,x
        ldd  #100
        std  MB,x
        jsr  MUL16,x
        ldd  TOT16,x
        jsr  FAR,x
        fdb  S+setr1-entry
        jsr  FAR,x
        fdb  S+div32-entry
        ldd  R0+2,x
        subd #100
        bls  .wok
        clra
        clrb
.wok:   addd #100
        std  W,x
        ldd  K,x
        subd N,x
        beq  .draw
        bsr  eta
.draw:  jsr  FAR,x
        fdb  S+draw-entry
        rts

; R0 <<= A
shl:    asl  R0+3,x
        rol  R0+2,x
        rol  R0+1,x
        rol  R0,x
        deca
        bne  shl
        rts

; append the text after the call: pshx / bsr puts / fcb "..",0 / pulx
puts:   pulx
.l:     ldaa 0,x
        inx
        tsta
        beq  .e
        pshx
        tsx
        ldx  2,x                ; mc%(), pushed by the caller
        jsr  PUTC,x
        pulx
        bra  .l
.e:     jmp  0,x

; ETA in seconds -> ESEC
eta:    ldab #SY                ; SY16 = SY*16
        jsr  LDR0,x
        ldaa #4
        bsr  shl
        ldab #SY16
        jsr  STV,x
        ldd  K,x
        subd #3
        bcs  .fb                ; no fit until 3 files are done
        ldd  SX+2,x             ; NUMV = SXY - SX*SY/k
        std  MA,x
        ldd  SY+2,x
        std  MB,x
        jsr  MUL16,x
        jsr  FAR,x
        fdb  S+divk-entry
        ldab #SXY
        jsr  FAR,x
        fdb  S+rsub-entry
        bcs  .fb
        ldab #NUMV
        jsr  STV,x
        ldd  SX+2,x             ; den = SXX - SX*SX/k -> E32
        std  MA,x
        std  MB,x
        jsr  MUL16,x
        jsr  FAR,x
        fdb  S+divk-entry
        ldab #SXX
        jsr  FAR,x
        fdb  S+rsub-entry
        bcs  .fb
        ldab #E32
        jsr  STV,x
        ldab #SXX               ; sizes too alike to fit if den < SXX/128
        jsr  LDR0,x
        ldaa #7
        jsr  FAR,x
        fdb  S+shr-entry
        ldab #E32
        jsr  FAR,x
        fdb  S+rsub-entry
        bcs  .fb
        ldab #NUMV              ; b16 = NUMV*16/den
        jsr  LDR0,x
        ldaa #4
        bsr  shl
        ldab #E32
        jsr  LDR1,x
        jsr  FAR,x
        fdb  S+div32-entry
        bcs  .fb
        beq  .fb
        std  BB,x
        std  MA,x               ; a16 = (SY*16 - b16*SX)/k
        ldd  SX+2,x
        std  MB,x
        jsr  MUL16,x
        ldab #SY16
        jsr  FAR,x
        fdb  S+rsub-entry
        bcs  .fb
        jsr  FAR,x
        fdb  S+divk-entry
        bcs  .fb
        std  AA,x
        bra  .have
.fb:    ldd  A0,x               ; a = RPDATA's time, b = 500 bytes/s
        asld
        asld
        asld
        asld
        std  AA,x
        ldd  #41
        std  BB,x
        ldd  K,x
        beq  .have
        std  MA,x               ; b16 = (SY*16 - k*a16)/SX
        ldd  AA,x
        std  MB,x
        jsr  MUL16,x
        ldab #SY16
        jsr  FAR,x
        fdb  S+rsub-entry
        bcs  .half
        ldab #SX
        jsr  LDR1,x
        jsr  FAR,x
        fdb  S+div32-entry
        bcs  .half
        beq  .half
        std  BB,x
        bra  .have
.half:  bsr  sy8                ; a16 = SY*8/k, b16 = SY*8/SX
        bsr  divk
        std  AA,x
        bsr  sy8
        ldab #SX
        jsr  LDR1,x
        bsr  div32
        bcs  .have
        std  BB,x
.have:  ldd  N,x                ; E = a16*(n-k) + b16*(TOT16-DONE16)/4
        subd K,x
        std  MA,x
        ldd  AA,x
        std  MB,x
        jsr  MUL16,x
        ldab #E32
        jsr  STV,x
        bsr  done16
        std  MB,x
        ldd  TOT16,x
        subd MB,x
        lsrd
        lsrd
        std  MA,x
        ldd  BB,x
        std  MB,x
        jsr  MUL16,x
        ldab #E32
        jsr  ACCV,x
        ldd  R0+2,x             ; seconds = (E + 160) / 320, at most 5999
        addd #160
        std  R0+2,x
        bcc  .nc
        inc  R0+1,x
.nc:    ldd  #320
        bsr  setr1
        bsr  div32
        bcs  .cap
        subd #5999
        bls  .e
.cap:   clra
        clrb
.e:     addd #5999
        std  ESEC,x
        rts

; text helpers

; R0 = SY*8
sy8:    ldab #SY16
        jsr  LDR0,x
        ldaa #1
        bra  shr

; D = DONE/16
done16: ldab #DONE
        jsr  LDR0,x
        ldaa #4
;       fall into shr

; R0 >>= A, D = its low word
shr:    lsr  R0,x
        ror  R0+1,x
        ror  R0+2,x
        ror  R0+3,x
        deca
        bne  shr
        ldd  R0+2,x
        rts

; R1 = D
setr1:  std  R1+2,x
        clra
        clrb
        std  R1,x
        rts

; R0 = R0 / k
divk:   ldd  K,x
        bsr  setr1
;       fall into div32

; R0 = R0 / R1, R2 = remainder (unsigned 32-bit), then chk
div32:  ldd  #0
        std  R2,x
        std  R2+2,x
        ldab #32
.lp:    asl  R0+3,x
        rol  R0+2,x
        rol  R0+1,x
        rol  R0,x
        rol  R2+3,x
        rol  R2+2,x
        rol  R2+1,x
        rol  R2,x
        ldaa R2+3,x
        suba R1+3,x
        staa T3+3,x
        ldaa R2+2,x
        sbca R1+2,x
        staa T3+2,x
        ldaa R2+1,x
        sbca R1+1,x
        staa T3+1,x
        ldaa R2,x
        sbca R1,x
        bcs  .no
        staa R2,x
        ldaa T3+1,x
        staa R2+1,x
        ldaa T3+2,x
        staa R2+2,x
        ldaa T3+3,x
        staa R2+3,x
        inc  R0+3,x
.no:    decb
        bne  .lp
;       fall into chk

; carry set if R0 >= 65536, else D = R0 (Z set if 0)
chk:    ldd  R0,x
        bne  .big
        ldd  R0+2,x
        clc
        rts
.big:   sec
        rts

; R0 = variable at offset B - R0, carry set if negative
rsub:   jsr  LDR1,x
        ldd  R1+2,x
        subd R0+2,x
        std  R0+2,x
        ldd  R1,x
        sbcb R0+1,x
        sbca R0,x
        std  R0,x
        rts

; append D seconds as m:ss to the left part
time:   pshb
        ldab #60
        stab DV,x
        pulb
        bsr  div8
        ldab REM,x
        pshb
        ldd  Q,x
        bsr  num
        ldaa #':'
        jsr  PUTC,x
        pulb
        clra
        bsr  div8               ; DV is 10 after num
        ldaa Q+1,x
        adda #'0'
        jsr  PUTC,x
        ldaa REM,x
        adda #'0'
        jmp  PUTC,x

; append D in decimal to the left part
num:    pshb
        ldab #10
        stab DV,x
        pulb
        clr  T3,x
.d:     bsr  div8
        ldab REM,x
        addb #'0'
        pshb
        inc  T3,x
        ldd  Q,x
        bne  .d
.o:     pula
        jsr  PUTC,x
        dec  T3,x
        bne  .o
        rts

; fill the gap between the parts with spaces, print the last B columns

; append D (bytes/16) as K with one decimal: tenths = (D*5+16)/32
numk:   std  MA,x
        ldd  #5
        std  MB,x
        jsr  MUL16,x
        ldd  R0+2,x
        addd #16
        std  R0+2,x
        bcc  .nc
        inc  R0+1,x
.nc:    ldaa #5
        jsr  FAR,x
        fdb  S+shr-entry
        pshb
        ldab #10
        stab DV,x
        pulb
        bsr  div8
        ldab REM,x
        pshb
        ldd  Q,x
        bsr  num
        ldaa #'.'
        jsr  PUTC,x
        pula
        adda #'0'
        jmp  PUTC,x

; prepend A to the right part of the line
putr:   pshx
        dec  RP,x
        ldab RP,x
        abx
        staa LBUF,x
        pulx
        rts

; D = D / DV, REM = remainder (DV < 128)
div8:   std  Q,x
        clr  REM,x
        ldab #16
.lp:    asl  Q+1,x
        rol  Q,x
        rol  REM,x
        ldaa REM,x
        suba DV,x
        bcs  .n
        staa REM,x
        inc  Q+1,x
.n:     decb
        bne  .lp
        ldd  Q,x
        rts

; prepend D seconds as m:ss to the right part
timer:  pshb
        ldab #60
        stab DV,x
        pulb
        bsr  div8
        ldd  Q,x
        pshb
        psha                    ; minutes
        ldab #10
        stab DV,x
        ldab REM,x
        clra
        bsr  div8
        ldaa REM,x
        adda #'0'
        bsr  putr
        ldaa Q+1,x
        adda #'0'
        bsr  putr
        ldaa #':'
        bsr  putr
        pula
        pulb
        bra  numr

; prepend D in decimal to the right part
numr:   pshb
        ldab #10
        stab DV,x
        pulb
.d:     bsr  div8
        ldaa REM,x
        adda #'0'
        bsr  putr
        ldd  Q,x
        bne  .d
        rts

; the four status lines
draw:   jsr  FAR,x                ; line 1: k/n at the right
        fdb  S+bol-entry
        ldd  N,x
        bsr  numr
        ldaa #'/'
        bsr  putr
        ldd  K,x
        bsr  numr
        ldaa #13
        ldab #7
        jsr  FAR,x
        fdb  S+eol-entry
        ldaa #5                 ; line 2: the bar, 5 steps per cell
        staa DV,x
        ldd  W,x
        bsr  div8
.full:  tstb
        beq  .part
        pshb
        ldaa #5
        jsr  PUTC,x
        pulb
        decb
        bra  .full
.part:  ldab W+1,x
        cmpb #100
        beq  .rest
        ldaa REM,x
        jsr  PUTC,x
.rest:  ldaa LN,x
        cmpa #20
        bcc  .bar
        clra
        jsr  PUTC,x
        bra  .rest
.bar:   ldaa #20
        ldab #20
        jsr  FAR,x
        fdb  S+eol-entry
        ldaa #'%'               ; line 3: 5.8/13.3K  43%, or DONE IN m:ss
        jsr  FAR,x
        fdb  S+putr-entry
        ldd  W,x
        bsr  numr
        ldd  K,x
        subd N,x
        beq  .fin
        jsr  FAR,x
        fdb  S+done16-entry
        jsr  FAR,x
        fdb  S+numk-entry
        ldaa #'/'
        jsr  PUTC,x
        ldd  TOT16,x
        jsr  FAR,x
        fdb  S+numk-entry
        ldaa #'K'
        jsr  PUTC,x
        bra  .l3
.fin:   pshx
        jsr  FAR,x
        fdb  S+puts-entry
        fcb  "DONE IN ",0
        pulx
        ldaa #20
        staa DV,x
        ldd  SY+2,x
        addd #10
        jsr  FAR,x
        fdb  S+div8-entry
        jsr  FAR,x
        fdb  S+time-entry
.l3:    ldaa #40
        ldab #20
        bsr  eol
        ldd  K,x                ; line 4: file name, ETA m:ss
        subd N,x
        beq  .ret
        clr  Q,x
.nm:    ldab Q,x
        pshx
        ldx  FNAME,x
        cmpb 0,x
        bcc  .nme
        abx
        ldaa 1,x
        pulx
        jsr  PUTC,x
        inc  Q,x
        bra  .nm
.nme:   pulx
        ldd  ESEC,x
        jsr  FAR,x
        fdb  S+timer-entry
        ldaa #' '
        jsr  FAR,x
        fdb  S+putr-entry
        ldaa #'A'
        jsr  FAR,x
        fdb  S+putr-entry
        ldaa #'T'
        jsr  FAR,x
        fdb  S+putr-entry
        ldaa #'E'
        jsr  FAR,x
        fdb  S+putr-entry
        ldaa #60
        ldab #20
        bsr  eol
.ret:   rts

; of the line at screen position A, and start the next line
eol:    psha
        pshb
.f:     ldaa LN,x
        cmpa RP,x
        bcc  .p
        ldaa #' '
        jsr  PUTC,x
        bra  .f
.p:     pulb
        pula
        pshx
        pshb
        clrb
        os   DP$STAT
        pulb
        pulx
        pshx
        pshb
        negb
        addb #LBUF+20
        abx
        pulb
        os   DP$PRNT
        pulx
;       fall into bol

; start a line
bol:    clr  LN,x
        ldaa #20
        staa RP,x
        rts

; offsets in mc%() of the helpers called with jsr NAME,x
FAR     = S+far-entry
PUTC    = S+putc-entry
MAINT   = S+maint-entry
LDR1    = S+ldr1-entry
LDR0    = S+ldr0-entry
ACCV    = S+accv-entry
STV     = S+stv-entry
MUL16   = S+mul16-entry
