#!/usr/bin/env python3
"""Tests for the loader (RPBOOT, RPLOAD, RPLOADCM) in the headless emulator.

    python Tools/tests/rpload/run.py            # everything (about a minute)
    python Tools/tests/rpload/run.py roms       # only the model check on every ROM

Builds into tests/rpload/build: two small folders run through mkrpdata.py, and Datapak
images holding RPBOOT as source (translated by the emulated Organiser's own editor, as
on a real one), a stand-in XTRECV: (XTRECV.opl) and the file list as a data file. Then
runs t_rpload.js under Node with Programs/Connect4/tools/emu.js (the Jape sources).
There is no Comms Link in the emulator, so the stand-in logs each call (B:XLOG), puts the
loaders onto A: (from copies on B:, with the OS's FL$COPY) and copies the file list; the
files in the list aren't written.
"""
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.dirname(os.path.dirname(HERE))
B = os.path.join(HERE, "build")
PY = sys.executable


def tool(*a):
    r = subprocess.run([PY, os.path.join(TOOLS, a[0]), *a[1:]], capture_output=True, text=True)
    if r.returncode:
        sys.exit(f"{a[0]} failed:\n{r.stdout}{r.stderr}")


def folder(name, files, title, run=None):
    d = os.path.join(B, name)
    os.makedirs(d)
    for f in files:
        shutil.copyfile(os.path.join(B, "HELLO.ob3"), os.path.join(d, f))
    with open(os.path.join(d, "MYDATA.ODB"), "wb") as f:
        f.write(b"ONE\tTWO\r\n")
    tool("mkrpdata.py", d, "--title", title, *(["--run", run] if run else []))
    shutil.copyfile(os.path.join(d, "RPDATA.ODB"), os.path.join(B, name + "_RPDSRC.odb"))
    return d


def pack(out, *inputs, translate=False):
    tool("opl2opk.py", "-f", *([] if translate else ["--no-translate"]), *(["--size", "16"]), os.path.join(B, out), *inputs)


def rename(src, name):
    """A copy of src named so that opl2opk gives the item that name on the pack."""
    d = os.path.join(B, "n_" + name)
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, name + os.path.splitext(src)[1])
    shutil.copyfile(src, p)
    return p


def main():
    shutil.rmtree(B, ignore_errors=True)
    os.makedirs(B)
    with open(os.path.join(B, "HELLO.opl"), "w") as f:
        f.write('HELLO:\nPRINT "HI"\nGET\n')
    tool("opltran.py", "--target", "cm", "-o", B, os.path.join(B, "HELLO.opl"), os.path.join(HERE, "XTRECV.opl"))
    ok = folder("ok", ["HELLO.OB3", "SECOND.OB3"], "TEST CM", "HELLO")       # HELLO, MYDATA, SECOND
    folder("fail", ["HELLO.OB3", "FAILME.OB3", "ZLAST.OB3"], "FAILTEST")
    boot, xt = os.path.join(ok, "RPBOOT.OPL"), os.path.join(B, "XTRECV.ob3")
    # the loaders, under other names: the stand-in XTRECV: copies them to A: when RPBOOT fetches one
    srcs = [rename(os.path.join(ok, "RPLOADCM.OB3"), "RPLCSRC"), rename(os.path.join(ok, "RPLOAD.OB3"), "RPLSRC")]
    pack("B.opk", boot, xt, rename(os.path.join(B, "ok_RPDSRC.odb"), "RPDSRC"), *srcs)
    pack("B2.opk", boot, xt, rename(os.path.join(B, "fail_RPDSRC.odb"), "RPDSRC"), *srcs)
    with open(os.path.join(B, "NORPD.odb"), "w") as f:
        f.write("X\n")
    pack("B3.opk", boot, xt, rename(os.path.join(B, "ok_RPDSRC.odb"), "RPDSRC"), os.path.join(B, "NORPD.odb"), *srcs)
    pack("C.opk", os.path.join(ok, "RPLOADCM.OB3"))
    pack("CL.opk", os.path.join(ok, "RPLOAD.OB3"))
    # RPLOADCM's source as mkrpdata translates it, for the Organisers' own translators
    with open(os.path.join(TOOLS, "RPLOADCM.opl"), encoding="latin-1") as f:
        src = [ln.strip() for ln in f.read().splitlines()]
    src = [ln for ln in src if ln and not ln.upper().startswith("REM")]
    with open(os.path.join(B, "RPLOADCM.opl"), "w", encoding="latin-1", newline="\n") as f:
        f.write("\n".join(src) + "\n")
    pack("T.opk", os.path.join(B, "RPLOADCM.opl"), xt)
    r = subprocess.run(["node", os.path.join(HERE, "t_rpload.js"), *sys.argv[1:]])
    return r.returncode


if __name__ == "__main__":
    sys.exit(main())
