#!/usr/bin/env python3
"""Translate every tests/src/*.opl with opltran.py and compare the object code
byte for byte with tests/expected/NAME.ob3 (produced by the LZ64 ROM in Jape)."""
import glob
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from opltran import translate, disassemble, read_ob3, TranslateError  # noqa: E402

verbose = "-v" in sys.argv
passed = failed = 0
for src in sorted(glob.glob(os.path.join(HERE, "src", "*.opl"))):
    text = open(src, "rb").read().decode("latin-1")
    name = re.match(r"\s*([A-Za-z][A-Za-z0-9]*[%$]?)", text).group(1).upper()
    exp_path = os.path.join(HERE, "expected", name + ".ob3")
    if not os.path.exists(exp_path):
        print(f"SKIP {name}: no expected output")
        continue
    want = read_ob3(exp_path)
    try:
        got = translate(text)
    except TranslateError as e:
        print(f"FAIL {name}: {e}")
        failed += 1
        continue
    if got == want:
        print(f"ok   {name} ({len(got)} bytes)")
        passed += 1
    else:
        failed += 1
        i = next((k for k in range(min(len(got), len(want))) if got[k] != want[k]), min(len(got), len(want)))
        print(f"FAIL {name}: differs at byte {i} (got {len(got)} bytes, expected {len(want)})")
        if verbose:
            g, w = disassemble(got).splitlines(), disassemble(want).splitlines()
            for k in range(max(len(g), len(w))):
                a = g[k] if k < len(g) else ""
                b = w[k] if k < len(w) else ""
                print(("   " if a == b else ">> ") + f"{a:<60} | {b}")
print(f"{passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
