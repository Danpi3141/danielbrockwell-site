// The loader on emulated Organisers (built by run.py into ./build). See run.py.
'use strict';
const fs = require('fs'), path = require('path'), assert = require('assert'), cp = require('child_process');
const { Machine } = require('../../../Programs/Connect4/tools/emu.js');
const B = path.join(__dirname, 'build');
const TOOLS = path.join(__dirname, '..', '..');

const ROMS = { '24-cm.rom': 8, '26-cm.rom': 8, '33-cm.rom': 8, '33-cmf.rom': 8, '36-cmf.rom': 8,
  '24-xp.rom': 16, '26-xp.rom': 16, '31-xp.rom': 16,
  '30-lahp.rom': 32, '33-la.rom': 32, '34-lag.rom': 32, '36-la.rom': 32, '36-laf.rom': 32, '36-lag.rom': 32, '37-lam.rom': 32,
  '42-lz.rom': 32, '44-lz.rom': 32, '45-lz.rom': 32, '46-lz.rom': 32,
  '43-lz64.rom': 64, '44-lz64.rom': 64, '45-lz64.rom': 64, '46a-lz64.rom': 64, '46b-lz64.rom': 64 };
const MENU = /Find|FIND|PROG|Prog|EDIT/;

function setup(rom, bPack) {
  const m = new Machine({ rom, ram: ROMS[rom] });
  m.boot();
  m.pkB = m.insertPack(path.join(B, bPack || 'B.opk'), 0);
  return m;
}
function toMenu(m) {
  for (let i = 0; i < 4 && !/Find|FIND|PROG|Prog/.test(m.screenText()); i++) { m.press('ON', 3, 10); m.runSeconds(0.3); }
}
// Prog > Edit B:name, MODE > Tran, save: the Organiser's own translator
function tran(m, name) {
  toMenu(m);
  m.press('P', 3, 10);
  if (m.lines === 4) m.press('E', 3, 10); else m.press('EXE', 3, 10);
  for (let i = 0; i < 4 && !/^[A-Z]+ B:/mi.test(m.screenText()); i++) m.press('MODE', 3, 12);
  if (m.lines === 4) { for (let i = 0; i < 10; i++) m.press('DEL', 2, 2); }
  m.type(name, 3, 3); m.press('EXE', 3, 20);
  m.press('MODE', 3, 12);
  if (m.lines === 4) m.press('T', 3, 12); else m.press('EXE', 3, 12);
  m.runSeconds(2);
  if (!m.screenText().includes('B:' + name)) throw new Error('translate failed: ' + m.screenText());
  m.press('EXE', 3, 12); m.runSeconds(8);           // (saving to a Datapak is slow on the LA)
  toMenu(m);
}
// Prog > Run dev:name, clearing a remembered name first (some ROMs fill it in)
function run(m, name, dev) {
  const prompt = () => m.screen().find((l) => /^\s*(RUN|EXEC|START)\s+\S:/i.test(l));
  toMenu(m);
  m.press('P', 3, 10); m.runTicks(4);
  if (m.lines === 4 || /RUN/.test(m.screenText())) m.press('R', 3, 10);
  else { for (let i = 0; i < 4; i++) m.press('RIGHT', 3, 3); m.press('EXE', 3, 10); }
  for (let i = 0; i < 4 && prompt() && !prompt().toUpperCase().includes(' ' + dev + ':'); i++) m.press('MODE', 3, 12);
  const l = prompt();
  if (!l || !l.toUpperCase().includes(' ' + dev + ':')) throw new Error('no Run prompt for ' + dev + ':\n' + m.screenText());
  if (l.slice(l.indexOf(':') + 1).trim()) m.press('ON', 3, 10);
  m.type(name, 3, 3); m.press('EXE', 3, 0);
}
// every distinct screen until one matches re
function watch(m, re, s) {
  const seen = [];
  for (let t = 0; t < (s || 60); t += 0.1) {
    const x = m.screenText(); if (!seen.includes(x)) seen.push(x);
    if (re.test(x)) return seen;
    m.runSeconds(0.1);
  }
  throw new Error('timed out waiting for ' + re + '\n' + m.screenText());
}
// the pack in slot B unpacked by opk2files: { recs: XLOG's records, files, dir }
function unpackB(m, keep) {
  const pk = m.pkB; let n = 0;
  while (pk.readByte(n) >= 0) n++;
  while (n > 2 && pk.readByte(n - 3) === 255) n--;            // (as Jape saves a pack)
  const d = Buffer.alloc(n + 6); d.write('OPK'); d[3] = (n - 2) >> 16; d[4] = ((n - 2) >> 8) & 255; d[5] = (n - 2) & 255;
  for (let i = 0; i < n; i++) d[6 + i] = pk.readByte(i);
  const f = path.join(B, 'out.opk'), dir = path.join(B, 'out');
  fs.writeFileSync(f, d); fs.rmSync(dir, { recursive: true, force: true });
  cp.execFileSync('python', [path.join(TOOLS, 'opk2files.py'), '-o', dir, f], { stdio: 'pipe' });
  const x = path.join(dir, 'XLOG.odb');
  const r = { recs: fs.existsSync(x) ? fs.readFileSync(x, 'latin1').split(/\r?\n/).filter(Boolean) : [], files: fs.readdirSync(dir), dir };
  if (!keep) fs.rmSync(dir, { recursive: true });
  return r;
}
// a procedure's object code (no source) as hex, through opltran's reader
function objHex(file) {
  const py = `import sys; sys.path.insert(0, sys.argv[1]); from opltran import read_ob3; print(read_ob3(sys.argv[2]).hex())`;
  return cp.execFileSync('python', ['-c', py, TOOLS, file]).toString().trim();
}
const ala = (m) => m.peekw(0x2040);                  // ALA_FREE: the top of A:'s files
const gap = (m) => m.peekw(0xA5) - ala(m);           // RTA_SP ($A5) - ALA_FREE: free RAM

let pass = 0;
const ok = (s) => { pass++; console.log('ok  ' + s); };
const only = process.argv[2];

// 1. RPBOOT, translated on the Organiser, picks the loader by model on every ROM and fetches it
for (const rom of Object.keys(ROMS)) {
  const m = setup(rom);
  tran(m, 'RPBOOT');
  const a0 = ala(m);
  run(m, 'RPBOOT', 'B');
  const lz = /lz/.test(rom);
  watch(m, lz ? /COPY TO/ : /TO A.B.C\?/, 20);
  assert.strictEqual(unpackB(m).recs[0], lz ? 'RPLOAD\tA:RPLOAD\t3' : 'RPLOADCM\tA:RPLOADCM\t3', rom);
  // (an LZ64 keeps A: in its other RAM banks, so $2040 doesn't show it there)
  if (!/lz64/.test(rom)) assert.ok(ala(m) > a0 + (lz ? 2400 : 450), 'the loader is not on A:');
  ok(`${rom}: RPBOOT fetches ${lz ? 'RPLOAD' : 'RPLOADCM'} into A: and runs it`);
}
if (only === 'roms') { console.log(pass + ' passed'); process.exit(0); }

// 2. the CM, XP and LA translators make the same RPLOADCM.OB3 as opltran --target cm
//    (CM 2.4 differs only in putting TRAP before a command's arguments; it runs either order)
const ours = objHex(path.join(B, 'ok', 'RPLOADCM.OB3'));
for (const rom of ['33-cm.rom', '24-cm.rom', '31-xp.rom', '36-la.rom']) {
  const m = setup(rom, 'T.opk');
  tran(m, 'RPLOADCM');
  const u = unpackB(m, true);
  const theirs = objHex(path.join(u.dir, 'RPLOADCM.ob3'));
  fs.rmSync(u.dir, { recursive: true });
  if (rom === '24-cm.rom') {
    assert.strictEqual(theirs.length, ours.length);
    assert.notStrictEqual(theirs, ours, 'CM 2.4 now matches: drop the special case');
    ok(`${rom}: translates RPLOADCM to the same ${ours.length / 2} bytes, but with TRAP before its arguments`);
  } else {
    assert.strictEqual(theirs, ours, rom + ' translates RPLOADCM differently');
    ok(`${rom}: translates RPLOADCM byte for byte as opltran --target cm`);
  }
}

// 3. RPLOADCM itself, on the CM (old and new ROMs), XP and LA
for (const rom of ['33-cm.rom', '24-cm.rom', '31-xp.rom', '36-la.rom']) {
  let m = setup(rom); tran(m, 'RPBOOT');
  const a0 = ala(m);
  run(m, 'RPBOOT', 'B'); watch(m, /TO A.B.C\?/, 15);
  assert.ok(ala(m) > a0 + 450, 'RPLOADCM is not on A:');
  m.press('B', 3, 10);
  let seen = watch(m, /DONE/);
  const ls = seen.map((s) => s.split('\n')[0].trim()).filter((s) => /^\d+\//.test(s));
  assert.deepStrictEqual(ls.filter((l) => !ls.some((o) => o !== l && o.startsWith(l))), ['1/3 HELLO', '2/3 MYDATA', '3/3 SECOND']);
  assert.ok(/RUN B:HELLO/.test(m.screenText()));
  let u = unpackB(m);
  assert.deepStrictEqual(u.recs, ['RPLOADCM\tA:RPLOADCM\t3', 'RPDATA\tB:RPDATA\t0', 'HELLO.OB3\tB:HELLO\t3', 'MYDATA.ODB\tB:MYDATA\t0', 'SECOND.OB3\tB:SECOND\t3']);
  assert.ok(!u.files.some((f) => /RPDATA/i.test(f)), 'RPDATA left on B:');
  m.press('EXE', 3, 10); m.runSeconds(1);
  assert.ok(MENU.test(m.screenText()), 'not back at the menu: ' + m.screenText());
  assert.ok(ala(m) <= a0, 'A: still holds ' + (ala(m) - a0) + ' bytes more: RPLOADCM not deleted?');
  ok(`${rom}: RPBOOT fetches RPLOADCM, which loads to B: (n/3 NAME, DONE / RUN B:HELLO), deletes the list and then itself`);
  // the next run fetches it again; cancelling keeps it on A:, and a run of A:RPLOADCM itself deletes it
  run(m, 'RPBOOT', 'B'); watch(m, /TO A.B.C\?/, 15);
  m.press('D', 3, 10); m.press('EXE', 3, 10); assert.ok(/TO A.B.C\?/.test(m.screenText()));
  m.press('ON', 3, 10); m.runSeconds(0.5);
  assert.ok(MENU.test(m.screenText()), 'not back at the menu: ' + m.screenText());
  u = unpackB(m);
  assert.strictEqual(u.recs.length, 6, 'cancelling fetched something');
  assert.strictEqual(u.recs[5], 'RPLOADCM\tA:RPLOADCM\t3', 'not fetched again');
  assert.ok(ala(m) > a0 + 450, 'cancelling deleted RPLOADCM');
  run(m, 'RPLOADCM', 'A'); watch(m, /TO A.B.C\?/, 15);
  m.press('B', 3, 10); watch(m, /DONE/); m.press('EXE', 3, 10); m.runSeconds(1);
  assert.ok(MENU.test(m.screenText()), 'not back at the menu: ' + m.screenText());
  assert.ok(ala(m) <= a0, 'A:RPLOADCM run on its own did not delete itself');
  ok(`${rom}: the next run fetches it again; D and EXE are ignored; ON/CLEAR cancels and keeps it; run from A: it deletes itself too`);

  m = setup(rom); m.insertPack(path.join(B, 'C.opk'), 1);
  const a1 = ala(m);
  run(m, 'RPLOADCM', 'C'); watch(m, /TO A.B.C\?/, 15);
  m.press('A', 3, 10); watch(m, /DONE/);
  assert.ok(/RUN A:HELLO/.test(m.screenText()));
  assert.deepStrictEqual(unpackB(m).recs.map((r) => r.split('\t')[1]), ['A:RPDATA', 'A:HELLO', 'A:MYDATA', 'A:SECOND']);
  m.press('EXE', 3, 10); m.runSeconds(1);
  assert.ok(ala(m) <= a1, 'the list was left on A:');
  ok(`${rom}: loads to A: (the list goes to A:, then is deleted)`);

  m = setup(rom, 'B2.opk'); m.insertPack(path.join(B, 'C.opk'), 1);
  run(m, 'RPLOADCM', 'C'); watch(m, /TO A.B.C\?/, 15);
  m.press('B', 3, 10); watch(m, /FAILED/); m.runSeconds(3);
  assert.ok(/^FAILED B:FAILME/.test(m.screenText()), m.screenText());
  u = unpackB(m);
  assert.deepStrictEqual(u.recs.map((r) => r.split('\t')[0]), ['RPDATA', 'FAILME.OB3']);
  assert.ok(!u.files.some((f) => /RPDATA/i.test(f)), 'RPDATA left after a failure');
  m.press('EXE', 3, 10); m.runSeconds(1);
  assert.ok(MENU.test(m.screenText()), m.screenText());
  ok(`${rom}: a failed transfer shows FAILED B:FAILME and the error, deletes the list`);

  m = setup(rom, 'B3.opk'); m.insertPack(path.join(B, 'C.opk'), 1);
  run(m, 'RPLOADCM', 'C'); watch(m, /TO A.B.C\?/, 15);
  m.press('B', 3, 10); watch(m, /FAILED/); m.runSeconds(3);
  assert.ok(/^FAILED B:RPDATA/.test(m.screenText()), m.screenText());
  m.press('EXE', 3, 10); m.runSeconds(1);
  assert.ok(MENU.test(m.screenText()), m.screenText());
  ok(`${rom}: no list from the PC shows FAILED B:RPDATA and the error`);
}

// 4. RAM in use while the loader waits at its device prompt (code, variables, and RPLOAD's
//    list on A:), from the free gap between A:'s files and the OPL stack
{
  let m = setup('33-cm.rom'); m.insertPack(path.join(B, 'C.opk'), 1);
  let base = gap(m);
  run(m, 'RPLOADCM', 'C'); watch(m, /TO A.B.C\?/, 15);
  const cm = base - gap(m);
  m = setup('46a-lz64.rom'); m.insertPack(path.join(B, 'CL.opk'), 1);
  base = gap(m);
  run(m, 'RPLOAD', 'C'); watch(m, /COPY TO/, 20);
  const lz = base - gap(m);
  assert.ok(cm < 600, 'RPLOADCM uses ' + cm);
  ok(`RAM in use at the device prompt: RPLOADCM ${cm} bytes (CM), RPLOAD ${lz} bytes (LZ64)`);
}
console.log(pass + ' passed');
