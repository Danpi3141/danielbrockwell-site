#!/usr/bin/env python3
"""
opk2files.py - unpack a Psion Organiser II pack image (.opk) into its files.

What gets written (into OUTDIR, default: a folder named after the pack):

  OPL procedures (type $83)
      NAME.opl   the procedure's source text, one line per line (if it has source)
      NAME.ob3   the whole procedure block, including translated object code
                 (only if it has been translated). opl2opk.py accepts .ob3
                 files, so translated procedures round-trip unchanged.
  Data files (type $81 + records)
      NAME.odb   one record per line, fields separated by TAB (only if non-empty)
  Notepads (LZ, type $87)
      NAME.ob7   the raw notepad block (lossless)
      NAME.txt   the note text (only if the notepad has no password)
  Any other block file (types $82, $84-$8F)
      NAME.obX   the raw block, X = low hex digit of the type

Deleted items are skipped unless --deleted is given; they then go into a
"deleted" sub-folder.

Text is written byte-for-byte as Latin-1 by default, so unusual Psion
characters (codes 128-255) survive a round trip through opl2opk.py.

Usage:
    python opk2files.py GUESS.opk
    python opk2files.py GUESS.opk -o out_folder --deleted
"""

import argparse
import os
import sys

BLOCK_EXT = {0x83: ".ob3", 0x87: ".ob7"}


def be16(b, i):
    return (b[i] << 8) | b[i + 1]


def read_pack(path):
    raw = open(path, "rb").read()
    if raw[:3] != b"OPK":
        sys.exit(f"{path}: not an OPK pack image (missing 'OPK' signature)")
    if len(raw) < 6 + 10:
        sys.exit(f"{path}: file too short to be a pack image")
    return raw[6:]  # pack data, starting with the 10-byte pack header


def describe_header(d):
    flags, size = d[0], d[1]
    if flags & 0x80:
        sys.exit("This looks like an Organiser I (MkI) pack, which is not supported.")
    kind = "Rampak" if not (flags & 0x02) else ("Flashpak" if not (flags & 0x40) else "Datapak")
    extras = []
    if flags & 0x04:
        extras.append("paged")
    if not (flags & 0x08):
        extras.append("write-protected")
    if not (flags & 0x10):
        extras.append("bootable")
    if not (flags & 0x20):
        extras.append("copy-protected")
    desc = f"{size * 8}K {kind}" + (f" ({', '.join(extras)})" if extras else "")
    if flags & 0x10:  # bytes 2-5 hold the date the pack was sized
        desc += f", sized {1900 + d[2]:04d}-{d[3] + 1:02d}-{d[4] + 1:02d} {d[5]:02d}h"
    else:  # bootable packs use those bytes for boot information instead
        desc += f", boot id ${d[3]:02X}"
    return desc


def parse_records(d):
    """Yield (offset, length_byte, type, data) for each record after the header."""
    p = 10
    n = len(d)
    while p + 1 < n:
        b0, t = d[p], d[p + 1]
        if b0 == 0xFF:  # $FFFF marks the end of the data on the pack
            return
        if b0 == 0x02 and (t & 0x7F) == 0x00:  # long record (live $80 or deleted $00)
            if p + 4 > n:
                break
            ln = be16(d, p + 2)
            yield p, b0, t, d[p + 4:p + 4 + ln]
            p += 4 + ln
        elif b0 == 0x00:
            print(f"warning: invalid zero-length record at pack offset {p}; stopping", file=sys.stderr)
            return
        else:
            yield p, b0, t, d[p + 2:p + 2 + b0]
            p += 2 + b0
    print("warning: pack data ended without the $FFFF end marker", file=sys.stderr)


def name_of(data):
    return data[:8].decode("latin-1").rstrip()


class Writer:
    def __init__(self, outdir, encoding):
        self.outdir = outdir
        self.encoding = encoding
        self.used = set()
        self.written = []

    def rel(self, p):
        return os.path.relpath(p, self.outdir).replace(os.sep, "/")

    def path(self, name, ext, deleted):
        folder = os.path.join(self.outdir, "deleted") if deleted else self.outdir
        os.makedirs(folder, exist_ok=True)
        base = name or "NONAME"
        cand = os.path.join(folder, base + ext)
        i = 2
        while cand.lower() in self.used:
            cand = os.path.join(folder, f"{base}_{i}{ext}")
            i += 1
        self.used.add(cand.lower())
        return cand

    def write_bytes(self, name, ext, deleted, data):
        p = self.path(name, ext, deleted)
        with open(p, "wb") as f:
            f.write(data)
        self.written.append(p)
        return p

    def write_lines(self, name, ext, deleted, lines, newline="\n"):
        p = self.path(name, ext, deleted)
        with open(p, "w", encoding=self.encoding, newline=newline) as f:
            for line in lines:
                f.write(line + "\n")
        self.written.append(p)
        return p


def split_zero_lines(b, encoding):
    lines = b.split(b"\x00")
    if lines and lines[-1] == b"":
        lines.pop()
    return [ln.decode(encoding) for ln in lines]


def ob_file(ftype, block):
    return b"ORG" + bytes([len(block) >> 8, len(block) & 0xFF, ftype]) + block


def main():
    ap = argparse.ArgumentParser(description="Unpack a Psion Organiser II .opk pack image into its files.")
    ap.add_argument("pack", help="the .opk file to unpack")
    ap.add_argument("-o", "--outdir", help="output folder (default: folder named after the pack)")
    ap.add_argument("--deleted", action="store_true", help="also extract deleted items into OUTDIR/deleted")
    ap.add_argument("--encoding", default="latin-1",
                    help="text encoding for .opl/.odb/.txt output (default: latin-1, byte-transparent)")
    args = ap.parse_args()

    d = read_pack(args.pack)
    outdir = args.outdir or os.path.splitext(args.pack)[0]
    w = Writer(outdir, args.encoding)
    print(f"{args.pack}: {describe_header(d)}")

    datafiles = {}   # id -> {"name", "deleted", "records": []}
    orphan_records = {}
    pending_block = None  # (type, name, deleted) waiting for its long record
    summary = []

    for off, b0, t, data in parse_records(d):
        live = bool(t & 0x80)
        typ = t | 0x80
        if b0 == 0x02 and (t & 0x7F) == 0x00:  # long record
            if pending_block is None:
                # On a bootable pack this is the machine-code boot block.
                bootable = not (d[0] & 0x10)
                label = "BOOTCODE" if bootable else f"ORPHAN_{off:05X}"
                p = w.write_bytes(label, ".bin", False, data)
                what = "boot code" if bootable else "long record with no file header"
                summary.append(f"  {what}  {len(data)} bytes -> {w.rel(p)}")
                continue
            btype, bname, bdeleted = pending_block
            pending_block = None
            if bdeleted and not args.deleted:
                continue
            summary.append(extract_block(w, btype, bname, bdeleted, data))
        elif typ == 0x81:  # data file header: name(8) + id
            fid = data[8] if len(data) > 8 else None
            entry = {"name": name_of(data), "deleted": not live, "records": []}
            if fid is not None:
                # a deleted file's id may be reused later; keep the deleted one separately
                key = fid if live else (fid, off)
                datafiles[key] = entry
                if live and fid in orphan_records:
                    entry["records"].extend(orphan_records.pop(fid))
        elif 0x82 <= typ <= 0x8F:  # block file header: name(8) + spare byte
            pending_block = (typ, name_of(data), not live)
        elif typ >= 0x90:  # data file record
            if not live:
                # deleted record: belongs to some deleted file with this id (or is a deleted record)
                if args.deleted:
                    orphan_records.setdefault(("deleted", typ), []).append(data)
                continue
            if typ in datafiles:
                datafiles[typ]["records"].append(data)
            else:
                orphan_records.setdefault(typ, []).append(data)
        else:
            print(f"warning: unknown record type ${t:02X} at offset {off}; skipped", file=sys.stderr)

    for key, f in datafiles.items():
        if f["deleted"] and not args.deleted:
            continue
        if not f["records"]:
            summary.append(f"  data file {f['name']:<8}  (empty, not written)")
            continue
        lines = [r.decode(args.encoding) for r in f["records"]]
        p = w.write_lines(f["name"], ".odb", f["deleted"], lines, newline="\r\n")
        summary.append(f"  data file {f['name']:<8}  {len(lines)} records -> {w.rel(p)}")

    for key, recs in orphan_records.items():
        if isinstance(key, tuple):
            lines = [r.decode(args.encoding) for r in recs]
            p = w.write_lines(f"RECORDS_{key[1]:02X}", ".odb", True, lines, newline="\r\n")
            summary.append(f"  deleted records ${key[1]:02X}  {len(lines)} records -> {w.rel(p)}")
        else:
            print(f"warning: {len(recs)} records for data file id ${key:02X} with no header", file=sys.stderr)

    print("\n".join(summary) if summary else "  (pack is empty)")


def extract_block(w, btype, name, deleted, block):
    tag = " (deleted)" if deleted else ""
    if btype == 0x83:
        ol = be16(block, 0)
        obj = block[2:2 + ol]
        sl = be16(block, 2 + ol)
        src = block[4 + ol:4 + ol + sl]
        out = []
        if sl:
            out.append(w.write_lines(name, ".opl", deleted, split_zero_lines(src, w.encoding)))
        if ol:
            out.append(w.write_bytes(name, ".ob3", deleted, ob_file(btype, block)))
        state = "translated" if ol else "not translated"
        if not sl:
            state += ", no source"
        return f"  procedure {name:<8}  {state}{tag} -> {', '.join(w.rel(x) for x in out)}"
    if btype == 0x87:
        out = [w.write_bytes(name, ".ob7", deleted, ob_file(btype, block))]
        hl = be16(block, 0)
        hdr = block[2:2 + hl]
        dl = be16(block, 2 + hl)
        text = block[4 + hl:4 + hl + dl]
        locked = len(hdr) > 1 and hdr[1] != 0
        if locked:
            note = "password protected, text not extracted"
        else:
            out.append(w.write_lines(name, ".txt", deleted, split_zero_lines(text, w.encoding)))
            note = "text extracted"
        return f"  notepad   {name:<8}  {note}{tag} -> {', '.join(w.rel(x) for x in out)}"
    ext = f".ob{btype & 0x0F:x}"
    p = w.write_bytes(name, ext, deleted, ob_file(btype, block))
    return f"  block ${btype:02X}  {name:<8}  {len(block)} bytes{tag} -> {w.rel(p)}"


if __name__ == "__main__":
    main()
