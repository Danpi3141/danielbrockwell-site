; =====================================================================
; rpdec: RPLOAD's unpacker, kept as raw bytes in d$. It copies the
; machine code (rpload.asm) out of OPL strings into mc%().
; Position independent, and free of tab, LF and CR bytes (opltran can't
; keep those in a string). Called with USR(ADDR(d$)+1,ADDR(x%())):
;   x%(1) = address of a string holding a piece of the code (length first)
;   x%(2) = where the piece goes; moved on past it
; In the string, ESC b^$40 stands for b (tab, LF, CR and ESC itself).
; =====================================================================
ESC     = $7E

        seg  code
rpdec:  xgdx                    ; X = x%()
        pshx
        ldd  2,x
        pshb
        psha                    ; destination
        ldx  0,x
        ldab 0,x                ; string length
        inx
.lp:    tstb
        beq  .end
        ldaa 0,x
        inx
        decb
        cmpa #ESC
        bne  .put
        ldaa 0,x
        inx
        decb
        eora #$40
.put:   pshx
        pshb                    ; stack: 0 count, 1 src, 3 dest, 5 x%()
        tsx
        ldx  3,x
        staa 0,x
        inx
        xgdx
        tsx
        std  3,x
        pulb
        pulx
        bra  .lp
.end:   pula
        pulb
        pulx
        std  2,x                ; x%(2) = end of the code so far
        rts
