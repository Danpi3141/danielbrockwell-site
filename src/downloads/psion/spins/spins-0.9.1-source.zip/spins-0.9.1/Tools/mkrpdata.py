#!/usr/bin/env python3
"""
mkrpdata.py - make a folder ready for the RPBOOT/RPLOAD loader.

RPLOAD (Tools/RPLOAD.opl) runs on the Organiser and copies a whole set of
files from a PC running Psi2Win (or Psion's CL) using the Comms Link's
XTRECV: command, with a progress bar and time estimate. It learns what to
fetch from RPDATA.ODB, a data file this script writes into the folder.

    python Tools/mkrpdata.py FOLDER --title "RAMPART LZ" --run RAMPART

This writes FOLDER/RPDATA.ODB and puts the loader in FOLDER as three files:
RPBOOT.OPL, a tiny starter procedure; RPLOAD.OB3, the LZ/LZ64 loader already
translated with no source (about 2.5K on the Organiser); and RPLOADCM.OB3, a
much smaller loader for the 2-line CM, XP and LA (about 0.5K: no bar or time
estimate; Tools/RPLOADCM.opl). RPBOOT runs whichever suits the model.
RPLOAD's status screen and time estimate are machine code (Tools/rpload.asm),
which this script assembles and embeds; see machine_code().
Run it again whenever the folder's contents change. Then:
  1. Psi2Win: Folder = FOLDER, Start!
  2. Organiser, first time only: COMMS > RECEIVE > PROCEDURE, RPBOOT, then
     PROG > EDIT RPBOOT > MODE > TRAN.
  3. PROG > RUN RPBOOT. If the loader (RPLOAD; RPLOADCM on a CM, XP or LA)
     isn't on the Organiser, RPBOOT fetches its .OB3 into A: (it stays
     there), then runs it.

Which files are sent (by extension; anything else in FOLDER is ignored):
  .ODB  data file (type 0)      .OPL  procedure, source only (type 1)
  .OB2  diary (type 2)          .OB3  translated procedure (type 3)
  .OB4  Comms Link setup (4)    .OB5  spreadsheet (type 5)
The loader's own files (RPBOOT.OPL, RPLOAD.OB3, RPLOADCM.OB3, RPDATA.ODB, and
the sources RPLOAD.OPL, RPLOADCM.OPL) are never listed.

Organiser names come from the PC names. Comms Link writes '%' as '_' on the
PC, so a procedure file ending in '_' (TITLE_.OB3) is loaded as TITLE%.

RPDATA.ODB format (tab-separated text, one record per line, CR LF):
  record 1      title, program to run (may be empty), total bytes, file count
  records 2..   Organiser name, PC file name, size in bytes, XTRECV type
"""

import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile

from asm6303 import assemble

TYPES = {".ODB": 0, ".OPL": 1, ".OB2": 2, ".OB3": 3, ".OB4": 4, ".OB5": 5}
SKIP = {"RPBOOT.OPL", "RPLOAD.OB3", "RPLOAD.OPL", "RPLOADCM.OB3", "RPLOADCM.OPL", "RPDATA.ODB"}
NAME_RE = re.compile(r"^[A-Z][A-Z0-9]{0,7}$")
HERE = os.path.dirname(os.path.abspath(__file__))
MAX_TITLE = 12  # leaves room for "999/999" on the 20-character top line
MAX_SIZE = 32767     # RPLOAD passes each size to its machine code as an integer
MAX_TOTAL = 524287   # ...and the total / 16
ESC = 0x7E               # must match Tools/rpdec.asm
BAD = (9, 10, 13)        # bytes opltran can't keep in a string: tab, LF, CR
CHUNK = 250              # the Organiser refuses a 255-byte string constant


def organiser_name(pc_base, ftype):
    name = pc_base.upper()
    proc = ftype in (1, 3)
    if proc and name.endswith("_"):
        name = name[:-1] + "%"
    core = name[:-1] if proc and name.endswith("%") else name
    if not NAME_RE.match(core) or len(name) > 8:
        raise SystemExit(f"{pc_base}: not a valid Organiser name (letter first, letters/digits, max 8"
                         f"{', may end in _ for %' if proc else ''})")
    return name


def scan(folder):
    files = []
    seen = {}
    for fn in sorted(os.listdir(folder), key=str.upper):
        path = os.path.join(folder, fn)
        base, ext = os.path.splitext(fn)
        if fn.upper() in SKIP or ext.upper() not in TYPES or not os.path.isfile(path):
            continue
        ftype = TYPES[ext.upper()]
        name = organiser_name(base, ftype)
        # two files of the same kind (procedure / other) with the same Organiser name would clash
        key = (name, ftype in (1, 3))
        if key in seen:
            raise SystemExit(f"{fn} and {seen[key]} would both become {name} on the Organiser")
        seen[key] = fn
        files.append((name, fn.upper(), os.path.getsize(path), ftype))
    return files


def check_field(text, what):
    if any(ord(c) < 32 for c in text) or len(text.encode("latin-1")) > 60:
        raise SystemExit(f"{what} {text!r}: no tabs or control characters, keep it short")


def opl_lines(name):
    """A procedure's source as sent through COMMS > RECEIVE: no indents, comments or blank lines."""
    with open(os.path.join(HERE, name), encoding="latin-1") as f:
        src = [ln.strip() for ln in f.read().splitlines()]
    src = [ln for ln in src if ln and not ln.upper().startswith("REM")]
    for ln in src:
        if any(ord(c) < 32 for c in ln) or len(ln) > 255:
            sys.exit(f"{name}: line too long or has a control character: {ln!r}")
    return src


def literal(b):
    return '"' + bytes(b).decode("latin-1").replace('"', '""') + '"'


def machine_code():
    """RPLOAD's machine code as OPL lines that load it into mc%().

    rpload.asm is embedded almost raw, in strings of up to CHUNK bytes, so it costs
    little more than its own size in RPLOAD.OB3 (hex would double it). rpdec.asm,
    kept raw in d$, copies each string into mc%() after the variables, turning
    ESC b^$40 back into b (tab, LF, CR and ESC, which a string can't hold or which
    would be read as an escape). The code calls only relative to itself or to
    mc%(), so it needs no relocation.
    Returns (lines, decoder length, words for mc%(), offset of the code in mc%()).
    """
    def asm(name):
        with open(os.path.join(HERE, name), encoding="utf-8") as f:
            return assemble(f.read(), 0, 0, name)
    dec, code = asm("rpdec.asm"), asm("rpload.asm")
    for a, name in ((dec, "rpdec.asm"), (code, "rpload.asm")):
        assert not a.fix["code"] and not a.fix["state"], f"{name} must not use absolute addresses of its own"
    assert not any(b in BAD for b in dec.out), "rpdec.asm contains a tab, LF or CR byte"
    start = code.symbols()["S"]["value"]
    enc = []
    for b in code.out:
        enc.append([ESC, b ^ 0x40] if b in BAD + (ESC,) else [b])
    chunks, cur = [], []
    for e in enc:
        if len(cur) + len(e) > CHUNK:
            chunks.append(cur)
            cur = []
        cur += e
    chunks.append(cur)
    lines = ["d$=" + literal(dec.out)]
    lines += ["x%(1)=ADDR(c$) :i%=ADDR(d$)+1 :w%=ADDR(x%())"]
    lines += [f"c$={literal(c)} :USR(i%,w%)" for c in chunks]
    return lines, len(dec.out), (start + len(code.out) + 1) // 2, start


def rpload_source():
    """RPLOAD.opl with the machine code in place of its @MCODE@ line."""
    mc, dlen, words, start = machine_code()
    out = []
    for ln in opl_lines("RPLOAD.opl"):
        if ln == "@MCODE@":
            out += mc
        else:
            out.append(ln.replace("@DLEN@", str(dlen)).replace("@MWORDS@", str(words))
                       .replace("@MSTART@", str(start)))
    return out


def translate(lines, name, target):
    """A procedure's lines translated by opltran with no source kept: the .ob3 bytes."""
    tmp = tempfile.mkdtemp(prefix="rpload_")
    try:
        with open(os.path.join(tmp, name + ".opl"), "w", encoding="latin-1", newline="\n") as f:
            f.write("\n".join(lines) + "\n")
        r = subprocess.run([sys.executable, os.path.join(HERE, "opltran.py"), "--no-source", "--target", target,
                            "-o", tmp, os.path.join(tmp, name + ".opl")], capture_output=True, text=True)
        if r.returncode:
            sys.exit(f"translating {name}.opl failed:\n" + r.stderr + r.stdout)
        with open(os.path.join(tmp, name + ".ob3"), "rb") as f:
            return f.read()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def install_loader(folder):
    """RPBOOT.OPL (source, received through the COMMS menu), and the loaders RPBOOT fetches, code
    only: RPLOAD.OB3 for the LZ/LZ64 and RPLOADCM.OB3, translated for the 2-line CM/XP/LA."""
    with open(os.path.join(folder, "RPBOOT.OPL"), "w", encoding="latin-1", newline="\r\n") as f:
        f.write("\n".join(opl_lines("RPBOOT.opl")) + "\n")
    for name, lines, target in (("RPLOAD", rpload_source(), "lz"), ("RPLOADCM", opl_lines("RPLOADCM.opl"), "cm")):
        with open(os.path.join(folder, name + ".OB3"), "wb") as f:
            f.write(translate(lines, name, target))
    old = os.path.join(folder, "RPLOAD.OPL")
    if os.path.exists(old):
        os.remove(old)  # the old single-file loader, replaced by RPBOOT + RPLOAD.OB3


def main():
    ap = argparse.ArgumentParser(description="Write RPDATA.ODB, RPBOOT.OPL, RPLOAD.OB3 and RPLOADCM.OB3 into a folder for the RPLOAD loader.")
    ap.add_argument("folder", help="the folder Psi2Win will serve")
    ap.add_argument("--title", help=f"name shown while loading (max {MAX_TITLE} chars; default: --run or the folder name)")
    ap.add_argument("--run", default="", help="procedure RPLOAD tells you to run when it has finished")
    ap.add_argument("--no-loader", action="store_true", help="don't put RPBOOT.OPL, RPLOAD.OB3 and RPLOADCM.OB3 in the folder")
    a = ap.parse_args()

    folder = a.folder
    if not os.path.isdir(folder):
        sys.exit(f"{folder}: no such folder")
    files = scan(folder)
    if not files:
        sys.exit(f"{folder}: no .OB3/.ODB/.OPL (etc.) files to list")
    if len(files) > 999:
        sys.exit("RPLOAD handles up to 999 files")
    big = [pc for _, pc, sz, _ in files if sz > MAX_SIZE]
    if big:
        sys.exit(f"{big[0]}: RPLOAD handles files of up to {MAX_SIZE} bytes")

    run = a.run.upper()
    if run and run not in {n for n, _, _, t in files if t in (1, 3)}:
        sys.exit(f"--run {run}: no procedure of that name in {folder}")
    title = (a.title or run or os.path.basename(os.path.abspath(folder))).upper()
    if len(title) > MAX_TITLE:
        sys.exit(f"--title {title!r} is longer than {MAX_TITLE} characters")
    check_field(title, "--title")

    total = sum(s for _, _, s, _ in files)
    if total > MAX_TOTAL:
        sys.exit(f"{total} bytes in all: RPLOAD handles up to {MAX_TOTAL}")
    lines = [f"{title}\t{run}\t{total}\t{len(files)}"]
    lines += [f"{n}\t{pc}\t{s}\t{t}" for n, pc, s, t in files]
    with open(os.path.join(folder, "RPDATA.ODB"), "w", encoding="latin-1", newline="\r\n") as f:
        f.write("\n".join(lines) + "\n")

    if not a.no_loader:
        install_loader(folder)

    print(f"{folder}: RPDATA.ODB lists {len(files)} files, {total} bytes"
          f"{'' if a.no_loader else ' (+ RPBOOT.OPL, RPLOAD.OB3, RPLOADCM.OB3)'}; title {title!r}"
          f"{', runs ' + run if run else ''}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
