#!/usr/bin/env python3
"""
opltran.py - translate Psion Organiser II OPL source into QCode object code,
the same way the Organiser's own Prog > Tran does.

The output matches the LZ/LZ64 ROM translator byte for byte on the test
procedures in tests/ (run tests/run_tests.py). Procedures are translated for
the 4-line LZ/LZ64 by default (they start with the LZ "stop sign"); use
--target cm for the 2-line CM/XP.

Usage:
    python opltran.py GUESS.opl              -> GUESS.ob3 (object code + source)
    python opltran.py *.opl -o outdir
    python opltran.py --dis GUESS.ob3        disassemble a translated procedure

As a module (used by opl2opk.py):
    from opltran import translate, TranslateError
    obj = translate(source_text, target="lz")      # object code bytes
"""

import argparse
import decimal
import glob
import os
import re
import sys

# --------------------------------------------------------------------------
# Tables

T_INT, T_FLT, T_STR = "I", "F", "S"
TYPE_BYTE = {T_INT: 0, T_FLT: 1, T_STR: 2}          # +3 for arrays

# functions: name -> (opcode, argument types, result type, lz_only)
# argument codes: I/F/S values, "L" = MAX/MIN/... list, "A" = ADDR argument
FUNCTIONS = {
    "ADDR": (None, "A", T_INT, False),
    "ASC": (0x8B, "S", T_INT, False), "DAY": (0x8C, "", T_INT, False),
    "DISP": (0x8D, "IS", T_INT, False), "ERR": (0x8E, "", T_INT, False),
    "FIND": (0x8F, "S", T_INT, False), "FREE": (0x90, "", T_INT, False),
    "GET": (0x91, "", T_INT, False), "HOUR": (0x92, "", T_INT, False),
    "IABS": (0x93, "I", T_INT, False), "INT": (0x94, "F", T_INT, False),
    "KEY": (0x95, "", T_INT, False), "LEN": (0x96, "S", T_INT, False),
    "LOC": (0x97, "SS", T_INT, False), "MENU": (0x98, "S", T_INT, False),
    "MINUTE": (0x99, "", T_INT, False), "MONTH": (0x9A, "", T_INT, False),
    "PEEKB": (0x9B, "I", T_INT, False), "PEEKW": (0x9C, "I", T_INT, False),
    "RECSIZE": (0x9D, "", T_INT, False), "SECOND": (0x9E, "", T_INT, False),
    "USR": (0x9F, "II", T_INT, False), "VIEW": (0xA0, "IS", T_INT, False),
    "YEAR": (0xA1, "", T_INT, False), "COUNT": (0xA2, "", T_INT, False),
    "EOF": (0xA3, "", T_INT, False), "EXIST": (0xA4, "S", T_INT, False),
    "POS": (0xA5, "", T_INT, False),
    "ABS": (0xA6, "F", T_FLT, False), "ATAN": (0xA7, "F", T_FLT, False),
    "COS": (0xA8, "F", T_FLT, False), "DEG": (0xA9, "F", T_FLT, False),
    "EXP": (0xAA, "F", T_FLT, False), "FLT": (0xAB, "I", T_FLT, False),
    "INTF": (0xAC, "F", T_FLT, False), "LN": (0xAD, "F", T_FLT, False),
    "LOG": (0xAE, "F", T_FLT, False), "PI": (0xAF, "", T_FLT, False),
    "RAD": (0xB0, "F", T_FLT, False), "RND": (0xB1, "", T_FLT, False),
    "SIN": (0xB2, "F", T_FLT, False), "SQR": (0xB3, "F", T_FLT, False),
    "TAN": (0xB4, "F", T_FLT, False), "VAL": (0xB5, "S", T_FLT, False),
    "SPACE": (0xB6, "", T_FLT, False),
    "DIR$": (0xB7, "S", T_STR, False), "CHR$": (0xB8, "I", T_STR, False),
    "DATIM$": (0xB9, "", T_STR, False), "ERR$": (0xBA, "I", T_STR, False),
    "FIX$": (0xBB, "FII", T_STR, False), "GEN$": (0xBC, "FI", T_STR, False),
    "GET$": (0xBD, "", T_STR, False), "HEX$": (0xBE, "I", T_STR, False),
    "KEY$": (0xBF, "", T_STR, False), "LEFT$": (0xC0, "SI", T_STR, False),
    "LOWER$": (0xC1, "S", T_STR, False), "MID$": (0xC2, "SII", T_STR, False),
    "NUM$": (0xC3, "FI", T_STR, False), "RIGHT$": (0xC4, "SI", T_STR, False),
    "REPT$": (0xC5, "SI", T_STR, False), "SCI$": (0xC6, "FII", T_STR, False),
    "UPPER$": (0xC7, "S", T_STR, False), "USR$": (0xC8, "II", T_STR, False),
    # LZ only
    "CLOCK": (0xD6, "I", T_INT, True), "DOW": (0xD7, "III", T_INT, True),
    "FINDW": (0xD8, "S", T_INT, True), "MENUN": (0xD9, "IS", T_INT, True),
    "WEEK": (0xDA, "III", T_INT, True), "ACOS": (0xDB, "F", T_FLT, True),
    "ASIN": (0xDC, "F", T_FLT, True), "DAYS": (0xDD, "III", T_FLT, True),
    "MAX": (0xDE, "L", T_FLT, True), "MEAN": (0xDF, "L", T_FLT, True),
    "MIN": (0xE0, "L", T_FLT, True), "STD": (0xE1, "L", T_FLT, True),
    "SUM": (0xE2, "L", T_FLT, True), "VAR": (0xE3, "L", T_FLT, True),
    "DAYNAME$": (0xE4, "I", T_STR, True), "DIRW$": (0xE5, "S", T_STR, True),
    "MONTH$": (0xE6, "I", T_STR, True),
}

# simple statements: name -> (opcode, argument types, lz_only, trappable)
SIMPLE_STATEMENTS = {
    "APPEND": (0x5B, "", False, True), "AT": (0x4C, "II", False, False),
    "BACK": (0x64, "", False, True), "BEEP": (0x4D, "II", False, False),
    "CLOSE": (0x5C, "", False, True), "CLS": (0x4E, "", False, False),
    "COPY": (0x5D, "SS", False, True), "DELETE": (0x5F, "S", False, True),
    "ERASE": (0x60, "", False, True), "FIRST": (0x61, "", False, True),
    "KSTAT": (0x6A, "I", False, False), "LAST": (0x62, "", False, True),
    "NEXT": (0x63, "", False, True), "PAUSE": (0x54, "I", False, False),
    "POKEB": (0x55, "II", False, False), "POKEW": (0x56, "II", False, False),
    "POSITION": (0x66, "I", False, True), "RAISE": (0x57, "I", False, False),
    "RANDOMIZE": (0x58, "F", False, False), "RENAME": (0x67, "SS", False, True),
    "STOP": (0x59, "", False, False), "UPDATE": (0x68, "", False, True),
    "COPYW": (0xD3, "SS", True, True), "DELETEW": (0xD4, "S", True, True),
    "UDG": (0xD5, "IIIIIIIII", True, False),
}

OTHER_STATEMENTS = {
    "BREAK", "CONTINUE", "CREATE", "CURSOR", "DO", "EDIT", "ELSE", "ELSEIF",
    "ENDIF", "ENDWH", "ESCAPE", "GLOBAL", "GOTO", "IF", "INPUT", "LOCAL",
    "LPRINT", "OFF", "ONERR", "OPEN", "PRINT", "REM", "RETURN", "TRAP",
    "UNTIL", "USE", "WHILE",
}
OPERATOR_WORDS = {"AND", "OR", "NOT"}
RESERVED = set(FUNCTIONS) | set(SIMPLE_STATEMENTS) | OTHER_STATEMENTS | OPERATOR_WORDS

BINOPS = {  # operator -> (int opcode, float opcode, string opcode)
    "<": (0x27, 0x36, 0x45), "<=": (0x28, 0x37, 0x46), ">": (0x29, 0x38, 0x47),
    ">=": (0x2A, 0x39, 0x48), "<>": (0x2B, 0x3A, 0x49), "=": (0x2C, 0x3B, 0x4A),
    "+": (0x2D, 0x3C, 0x4B), "-": (0x2E, 0x3D, None), "*": (0x2F, 0x3E, None),
    "/": (0x30, 0x3F, None), "**": (0x31, 0x40, None),
    "AND": (0x34, 0x43, None), "OR": (0x35, 0x44, None),
}
COMPARISONS = {"<", "<=", ">", ">=", "<>", "="}
PRECEDENCE = [["AND", "OR"], ["<", "<=", ">", ">=", "<>", "="], ["+", "-"], ["*", "/"]]


class TranslateError(Exception):
    def __init__(self, msg, line=None):
        super().__init__(msg)
        self.msg = msg
        self.line = line

    def __str__(self):
        return f"line {self.line}: {self.msg}" if self.line else self.msg


def type_of_name(name):
    return T_INT if name.endswith("%") else T_STR if name.endswith("$") else T_FLT


# --------------------------------------------------------------------------
# Lexer

TOKEN_RE = re.compile(r"""
    (?P<ws>\s+)
  | (?P<str>"(?:[^"]|"")*")
  | (?P<hex>\$[0-9A-Fa-f]+)
  | (?P<num>(?:\d+\.?\d*|\.\d+)(?:[Ee][+-]?\d+)?)
  | (?P<field>[A-Da-d]\.[A-Za-z][A-Za-z0-9]*[%$]?)
  | (?P<id>[A-Za-z][A-Za-z0-9]*[%$]?)(?P<colons>::?)?
  | (?P<op>\*\*|<=|>=|<>|[-+*/=<>(),;:])
""", re.VERBOSE)


class Tok:
    __slots__ = ("kind", "val", "col")

    def __init__(self, kind, val, col):
        self.kind, self.val, self.col = kind, val, col

    def __repr__(self):
        return f"{self.kind}:{self.val}"


def ends_operand(tok):
    """True if tok can end an operand, so a '%' after it is a percentage
    operator (200+5%) rather than a character code (%A)."""
    if tok.kind in ("int", "flt", "str", "field", "call"):
        return True
    if tok.kind == "op":
        return tok.val == ")"
    if tok.kind == "id":
        return tok.val in FUNCTIONS or tok.val not in RESERVED
    return False


def lex(line, lineno):
    toks = []
    pos = 0
    while pos < len(line):
        if line[pos] == "%":
            # %A is the character code of A (any character, even space or ").
            # The ROM reads it wherever an operand can start, also after + and <,
            # so 1+%B is 1+66. A % straight after an operand is an LZ percentage
            # operator (200+5%, 50-10%, ...), which isn't supported.
            if toks and ends_operand(toks[-1]):
                raise TranslateError("percentage operators (200+5%, 50-10%, ...) are not supported", lineno)
            if pos + 1 >= len(line):
                raise TranslateError("% must be followed by a character", lineno)
            toks.append(Tok("int", ord(line[pos + 1]), pos))
            pos += 2
            continue
        m = TOKEN_RE.match(line, pos)
        if not m:
            if line[pos] == '"':
                raise TranslateError("string has no closing quote", lineno)
            raise TranslateError(f"unexpected character {line[pos]!r}", lineno)
        pos = m.end()
        k = m.lastgroup if m.lastgroup != "colons" else "id"
        if k == "ws":
            continue
        if k == "str":
            toks.append(Tok("str", m.group("str")[1:-1].replace('""', '"'), m.start()))
        elif k == "hex":
            v = int(m.group("hex")[1:], 16)
            if v > 0xFFFF:
                raise TranslateError(f"hex constant {m.group('hex')} too large", lineno)
            toks.append(Tok("int", v, m.start()))
        elif k == "num":
            txt = m.group("num")
            if re.fullmatch(r"\d+", txt) and int(txt) <= 32767:
                toks.append(Tok("int", int(txt), m.start()))
            else:
                toks.append(Tok("flt", txt, m.start()))
        elif k == "field":
            f, name = m.group("field").split(".")
            toks.append(Tok("field", (ord(f.upper()) - ord("A"), name.upper()), m.start()))
        elif k == "id":
            name = m.group("id").upper()
            colons = m.group("colons")
            if name == "REM" and not colons:
                break  # rest of the line is a comment
            if colons == "::":
                toks.append(Tok("label", name, m.start()))
            elif colons == ":" and name not in RESERVED:
                toks.append(Tok("call", name, m.start()))
            else:
                toks.append(Tok("id", name, m.start()))
                if colons:
                    toks.append(Tok("op", ":", m.end() - 1))
        else:
            toks.append(Tok("op", m.group("op"), m.start()))
    toks.append(Tok("end", None, len(line)))
    return toks


# --------------------------------------------------------------------------
# Float constants

def float_const(txt, lineno):
    try:
        d = decimal.Decimal(txt)
    except decimal.InvalidOperation:
        raise TranslateError(f"bad number {txt}", lineno)
    if d == 0:
        return bytes([0x02, 0x00, 0x00])
    sign, digits, exp = d.as_tuple()
    digits = list(digits)
    while digits and digits[0] == 0:
        digits.pop(0)
    e10 = len(digits) + exp - 1  # exponent of the first significant digit
    if len(digits) > 12:  # round to 12 significant digits
        q = decimal.Decimal((0, digits, 0)).quantize(decimal.Decimal(f"1E{len(digits) - 12}"),
                                                     rounding=decimal.ROUND_HALF_UP)
        digits = list(q.as_tuple().digits)
        if len(digits) > 12:  # carry: 999.. -> 1000..
            e10 += 1
        digits = digits[:12]
    if not -99 <= e10 <= 99:
        raise TranslateError(f"number {txt} is out of range", lineno)
    digits += [0] * (12 - len(digits))
    mant = [digits[i] * 16 + digits[i + 1] for i in range(0, 12, 2)]  # most significant first
    while len(mant) > 1 and mant[-1] == 0:
        mant.pop()
    return bytes([len(mant) + 1] + mant[::-1] + [e10 & 0xFF])


# --------------------------------------------------------------------------
# Parser: expressions become small tuples

class Parser:
    def __init__(self, toks, lineno):
        self.toks = toks
        self.i = 0
        self.lineno = lineno

    def peek(self, k=0):
        return self.toks[self.i + k]

    def next(self):
        t = self.toks[self.i]
        self.i += 1
        return t

    def is_op(self, v, k=0):
        t = self.peek(k)
        return t.kind == "op" and t.val == v

    def is_word(self, v, k=0):
        t = self.peek(k)
        return t.kind == "id" and t.val == v

    def expect_op(self, v):
        t = self.next()
        if t.kind != "op" or t.val != v:
            raise self.error(f"expected '{v}'", t)
        return t

    def error(self, msg, tok=None):
        tok = tok or self.peek()
        if tok.kind == "end":
            msg += " at end of statement"
        else:
            msg += f" near '{tok.val if tok.kind != 'field' else tok.val[1]}'"
        return TranslateError(msg, self.lineno)

    def at_stmt_end(self):
        t = self.peek()
        return t.kind == "end" or (t.kind == "op" and t.val == ":")

    # expression grammar
    def expr(self, level=0):
        if level == len(PRECEDENCE):
            return self.power()
        left = self.expr(level + 1)
        while True:
            t = self.peek()
            ops = PRECEDENCE[level]
            if (t.kind == "op" and t.val in ops) or (t.kind == "id" and t.val in ops):
                self.next()
                right = self.expr(level + 1)
                left = ("bin", t.val, left, right)
            else:
                return left

    def power(self):
        left = self.unary()
        while self.is_op("**"):
            self.next()
            left = ("bin", "**", left, self.unary())
        return left

    def unary(self):
        if self.is_op("-"):
            self.next()
            return ("neg", self.unary())
        if self.is_op("+"):
            self.next()
            return self.unary()
        if self.is_word("NOT"):
            self.next()
            return ("not", self.unary())
        return self.primary()

    def args(self):
        """Parse '(a,b,...)'; returns list (may contain ('whole', name))."""
        self.expect_op("(")
        out = []
        if self.is_op(")"):
            self.next()
            return out
        while True:
            t = self.peek()
            if t.kind == "id" and self.is_op("(", 1) and self.is_op(")", 2) and t.val not in RESERVED:
                self.i += 3
                out.append(("whole", t.val))
            else:
                out.append(self.expr())
            if self.is_op(","):
                self.next()
                continue
            self.expect_op(")")
            return out

    def primary(self):
        t = self.next()
        if t.kind == "int":
            return ("int", t.val)
        if t.kind == "flt":
            return ("flt", t.val)
        if t.kind == "str":
            if len(t.val.encode("latin-1")) > 255:
                raise self.error("string constant too long", t)
            return ("str", t.val)
        if t.kind == "op" and t.val == "(":
            e = self.expr()
            self.expect_op(")")
            return e
        if t.kind == "field":
            return ("field", t.val[0], t.val[1])
        if t.kind == "call":
            args = self.args() if self.is_op("(") else []
            return ("call", t.val, args)
        if t.kind == "id":
            name = t.val
            if name in FUNCTIONS:
                spec = FUNCTIONS[name][1]
                args = self.args() if (spec or self.is_op("(")) else []
                return ("fn", name, args)
            if name in RESERVED:
                raise self.error("unexpected keyword", t)
            if re.fullmatch(r"M[0-9]", name):
                return ("mem", int(name[1]))
            if self.is_op("("):
                self.next()
                idx = self.expr()
                self.expect_op(")")
                return ("elem", name, idx)
            return ("var", name)
        raise self.error("syntax error", t)

    def lvalue(self):
        t = self.peek()
        e = self.primary()
        if e[0] not in ("var", "elem", "field", "mem"):
            raise self.error("expected a variable", t)
        return e


# --------------------------------------------------------------------------
# Code generation

class Var:
    def __init__(self, name, typ, kind, size=0, count=0):
        self.name, self.typ, self.kind = name, typ, kind  # kind: local/global/param/ext
        self.size = size        # string max length
        self.count = count      # array elements (0 = not an array)
        self.addr = None

    @property
    def is_array(self):
        return self.count > 0

    @property
    def type_byte(self):
        return TYPE_BYTE[self.typ] + (3 if self.is_array else 0)

    def storage(self):
        t, n, m = self.typ, self.count, self.size
        if n:
            return {T_INT: 2 + 2 * n, T_FLT: 2 + 8 * n, T_STR: n * (m + 1) + 3}[t]
        return {T_INT: 2, T_FLT: 8, T_STR: m + 2}[t]


class Code:
    def __init__(self):
        self.b = bytearray()

    def op(self, *bs):
        self.b.extend(bs)

    def word(self, w):
        self.b.extend([(w >> 8) & 0xFF, w & 0xFF])

    def pos(self):
        return len(self.b)

    def jump(self, opcode, target=None):
        """Emit a jump; returns the patch position of its distance word."""
        self.op(opcode)
        p = self.pos()
        self.word(0)
        if target is not None:
            self.patch(p, target)
        return p

    def patch(self, p, target):
        d = (target - p) & 0xFFFF
        self.b[p] = d >> 8
        self.b[p + 1] = d & 0xFF


class Proc:
    """One procedure being translated."""

    def __init__(self, lines, target):
        self.lines = lines
        self.lz = target == "lz"
        self.name = None
        self.ret = None
        self.params = []
        self.decls = []          # locals and globals in source order
        self.vars = {}           # name -> Var (params, locals, globals)
        self.externals = []      # in order of first use
        self.ext_by_name = {}
        self.stmts = []          # (lineno, parser) for executable lines

    # ---- pass 1: header, declarations, statements
    def parse(self):
        lines = [(n, ln) for n, ln in self.lines]
        if not lines:
            raise TranslateError("empty procedure")
        n0, title = lines[0]
        m = re.fullmatch(r"\s*([A-Za-z][A-Za-z0-9]*[%$]?)\s*:\s*(?:\((.*)\))?\s*", title)
        if not m:
            raise TranslateError("first line must be the procedure name, e.g. NAME: or NAME:(a%,b$)", n0)
        self.name = m.group(1).upper()
        if len(self.name) > 8:
            raise TranslateError(f"procedure name {self.name} is longer than 8 characters", n0)
        self.ret = type_of_name(self.name)
        if m.group(2) is not None and m.group(2).strip():
            for p in m.group(2).split(","):
                p = p.strip().upper()
                if not re.fullmatch(r"[A-Z][A-Z0-9]*[%$]?", p) or p in RESERVED or len(p) > 8:
                    raise TranslateError(f"bad parameter name '{p}'", n0)
                self.add_var(Var(p, type_of_name(p), "param"), n0)
                self.params.append(self.vars[p])
        if len(self.params) > 16:
            raise TranslateError("too many parameters", n0)
        seen_code = False
        for n, ln in lines[1:]:
            toks = lex(ln, n)
            if toks[0].kind == "id" and toks[0].val in ("LOCAL", "GLOBAL"):
                if seen_code:
                    raise TranslateError(f"{toks[0].val} must come before the procedure's statements", n)
                self.parse_decl(Parser(toks, n))
            elif toks[0].kind != "end":
                seen_code = True
                self.stmts.append((n, toks))

    def add_var(self, v, n):
        if v.name in self.vars:
            raise TranslateError(f"{v.name} is declared twice", n)
        if v.name in RESERVED or re.fullmatch(r"M[0-9]", v.name):
            raise TranslateError(f"{v.name} is a reserved word", n)
        if len(v.name) > 8:
            raise TranslateError(f"variable name {v.name} is longer than 8 characters", n)
        self.vars[v.name] = v

    def parse_decl(self, p):
        kind = p.next().val.lower()
        while True:
            t = p.next()
            if t.kind != "id":
                raise p.error("expected a variable name", t)
            name = t.val
            typ = type_of_name(name)
            size = count = 0
            if p.is_op("("):
                p.next()
                nums = [p.next()]
                while p.is_op(","):
                    p.next()
                    nums.append(p.next())
                p.expect_op(")")
                if any(x.kind != "int" for x in nums):
                    raise p.error("array sizes and string lengths must be whole numbers", t)
                vals = [x.val for x in nums]
                if typ == T_STR:
                    if len(vals) == 1:
                        size = vals[0]
                    elif len(vals) == 2:
                        count, size = vals
                    else:
                        raise p.error("string arrays take (count,length)", t)
                else:
                    if len(vals) != 1:
                        raise p.error("numeric arrays take a single size", t)
                    count = vals[0]
                if typ == T_STR and not 1 <= size <= 255:
                    raise p.error("string length must be 1 to 255", t)
                if (count or len(vals) > 1) and count < 1:
                    raise p.error("array size must be at least 1", t)
            elif typ == T_STR:
                raise p.error(f"string {name} needs a length, e.g. {name}(10)", t)
            v = Var(name, typ, kind, size, count)
            self.add_var(v, p.lineno)
            self.decls.append(v)
            if p.is_op(","):
                p.next()
                continue
            if not p.at_stmt_end() or p.peek().kind != "end":
                raise p.error("unexpected text after declaration")
            return

    # ---- variable lookup
    def lookup(self, name, array, n):
        v = self.vars.get(name)
        if v is None:
            v = self.ext_by_name.get(name)
        if v is None:
            v = Var(name, type_of_name(name), "ext", count=1 if array else 0)
            self.ext_by_name[name] = v
            self.externals.append(v)
            v.addr = 0
            if self.layout_done:
                raise TranslateError(f"internal error: new external {name}", n)
        if v.is_array != array:
            raise TranslateError(f"{name} is {'an array' if v.is_array else 'not an array'}", n)
        return v

    def layout(self):
        gtable = bytearray()
        globs = [v for v in self.decls if v.kind == "global"]
        cur = 0x10000 - 2
        for v in globs:  # name table size is needed before addresses
            gtable += bytes([len(v.name)]) + v.name.encode() + b"\0\0\0"
        cur -= len(gtable)
        for v in self.params + self.externals:
            cur -= 2
            v.addr = cur
        for v in globs + [v for v in self.decls if v.kind == "local"]:
            cur -= v.storage()
            v.addr = cur + (1 if v.typ == T_STR else 0)
        if cur < 0x10000 - 0x7FFF:
            raise TranslateError("too much variable space")
        self.varspace = 0x10000 - cur

    # ---- header
    def header(self, qcode):
        out = bytearray()

        def w(x):
            out.extend([(x >> 8) & 0xFF, x & 0xFF])

        w(self.varspace)
        w(len(qcode))
        out.append(len(self.params))
        out.extend(TYPE_BYTE[p.typ] for p in reversed(self.params))
        tbl = bytearray()
        for v in self.decls:
            if v.kind == "global":
                tbl += bytes([len(v.name)]) + v.name.encode() + bytes([v.type_byte, v.addr >> 8, v.addr & 0xFF])
        w(len(tbl))
        out += tbl
        tbl = bytearray()
        for v in self.externals:
            tbl += bytes([len(v.name)]) + v.name.encode() + bytes([v.type_byte])
        w(len(tbl))
        out += tbl
        tbl = bytearray()
        for v in self.decls:
            if v.typ == T_STR:
                a = (v.addr - 1) & 0xFFFF
                tbl += bytes([a >> 8, a & 0xFF, v.size])
        w(len(tbl))
        out += tbl
        tbl = bytearray()
        for v in self.decls:
            if v.is_array:
                tbl += bytes([v.addr >> 8, v.addr & 0xFF, v.count >> 8, v.count & 0xFF])
        w(len(tbl))
        out += tbl
        return bytes(out) + qcode

    # ---- driver
    def translate(self):
        self.parse()
        self.layout_done = False
        self.layout()         # provisional addresses (externals not known yet)
        self.gen()            # first pass finds the externals
        self.layout()
        self.layout_done = True
        return self.header(self.gen())

    # ---- statements
    def gen(self):
        c = self.c = Code()
        self.blocks = []
        self.labels = {}
        self.gotos = []
        if self.lz:
            c.op(0x59, 0xB2)
        last_return = False
        for n, toks in self.stmts:
            p = Parser(toks, n)
            while True:
                if p.peek().kind == "end":
                    break
                last_return = self.statement(p)
                if p.peek().kind == "end":
                    break
                if p.is_op(":"):
                    p.next()
                    continue
                raise p.error("syntax error")
        if self.blocks:
            kind, _, n = self.blocks[-1][:3]
            end = {"IF": "ENDIF", "WHILE": "ENDWH", "DO": "UNTIL"}[kind]
            raise TranslateError(f"{kind} without matching {end}", n)
        for p_, label, n in self.gotos:
            if label not in self.labels:
                raise TranslateError(f"label {label}:: not found", n)
            c.patch(p_, self.labels[label])
        if not last_return:
            c.op({T_INT: 0x7A, T_FLT: 0x7B, T_STR: 0x7C}[self.ret])
        return bytes(c.b)

    def statement(self, p):
        """Compile one statement; returns True if it was a RETURN."""
        c = self.c
        n = p.lineno
        t = p.next()
        if t.kind == "label":
            if t.val in self.labels:
                raise TranslateError(f"label {t.val}:: defined twice", n)
            self.labels[t.val] = c.pos()
            if p.at_stmt_end():
                return False
            t = p.next()
        if t.kind == "call":
            args = p.args() if p.is_op("(") else []
            typ = self.call(t.val, args, n)
            c.op({T_INT: 0x83, T_FLT: 0x84, T_STR: 0x85}[typ])
            return False
        if t.kind == "id" and t.val in FUNCTIONS:
            p.i -= 1
            typ = self.expr(p.primary(), n)
            c.op({T_INT: 0x83, T_FLT: 0x84, T_STR: 0x85}[typ])
            return False
        if t.kind == "id" and t.val in SIMPLE_STATEMENTS:
            opcode, spec, lz, _ = SIMPLE_STATEMENTS[t.val]
            self.check_lz(t.val, lz, n)
            self.arglist(p, spec, t.val)
            c.op(opcode)
            return False
        if t.kind == "id" and t.val in RESERVED:
            return self.keyword(t.val, p)
        # assignment
        p.i -= 1
        target = p.lvalue()
        if not p.is_op("="):
            raise p.error("expected '='")
        p.next()
        value = p.expr()
        self.assign(target, value, n)
        return False

    def check_lz(self, name, lz, n):
        if lz and not self.lz:
            raise TranslateError(f"{name} is only available on the LZ/LZ64", n)

    def arglist(self, p, spec, name):
        """Statement arguments: comma separated, no brackets."""
        n = p.lineno
        for k, want in enumerate(spec):
            if k:
                p.expect_op(",")
            e = p.expr()
            self.convert(self.expr(e, n), want, n)
        if not p.at_stmt_end():
            raise p.error(f"too many arguments for {name}")

    def keyword(self, kw, p):
        c, n = self.c, p.lineno
        if kw in ("PRINT", "LPRINT"):
            base = 0x6F if kw == "PRINT" else 0x74
            newline = True
            while not p.at_stmt_end():
                typ = self.expr(p.expr(), n)
                c.op(base + {T_INT: 0, T_FLT: 1, T_STR: 2}[typ])
                newline = True
                if p.is_op(";"):
                    p.next()
                    newline = False
                elif p.is_op(","):
                    p.next()
                    c.op(base + 3)
                    newline = False
                elif not p.at_stmt_end():
                    raise p.error("expected ';' or ','")
            if newline:
                c.op(base + 4)
        elif kw in ("INPUT", "EDIT"):
            trap = False
            target = p.lvalue()
            typ = self.ref(target, n)
            if kw == "EDIT":
                if typ != T_STR:
                    raise TranslateError("EDIT needs a string variable", n)
                c.op(0x6B)
            else:
                c.op({T_INT: 0x6C, T_FLT: 0x6D, T_STR: 0x6E}[typ])
        elif kw == "TRAP":
            t = p.next()
            if t.kind != "id":
                raise p.error("TRAP must be followed by a command", t)
            self.trap(t.val, p)
        elif kw in ("CREATE", "OPEN"):
            self.open_create(kw, p, False)
        elif kw == "USE":
            c.op(0x69, self.logical_file(p))
        elif kw in ("CURSOR", "ESCAPE"):
            t = p.next()
            if t.kind != "id" or t.val not in ("ON", "OFF"):
                raise p.error(f"{kw} must be followed by ON or OFF", t)
            c.op(0x4F if kw == "CURSOR" else 0x50, 1 if t.val == "ON" else 0)
        elif kw == "OFF":
            if p.at_stmt_end():
                c.op(0x52)
            else:
                self.check_lz("OFF n", True, n)
                self.arglist(p, "I", "OFF")
                c.op(0xD2)
        elif kw == "GOTO":
            self.gotos.append((c.jump(0x51), self.label_name(p), n))
        elif kw == "ONERR":
            if p.is_word("OFF"):
                p.next()
                c.op(0x53, 0, 0)
            else:
                self.gotos.append((c.jump(0x53), self.label_name(p), n))
        elif kw == "RETURN":
            if p.at_stmt_end():
                c.op({T_INT: 0x7A, T_FLT: 0x7B, T_STR: 0x7C}[self.ret])
            else:
                typ = self.expr(p.expr(), n)
                self.convert(typ, self.ret, n)
                c.op(0x79)
            return True
        elif kw == "IF":
            blk = ["IF", None, n, []]
            self.cond(p)
            blk[1] = c.jump(0x7E)
            self.blocks.append(blk)
        elif kw in ("ELSEIF", "ELSE"):
            blk = self.top_block(("IF",), kw, n)
            if blk[1] is None:
                raise TranslateError(f"{kw} after ELSE", n)
            blk[3].append(c.jump(0x51))
            c.patch(blk[1], c.pos())
            blk[1] = None
            if kw == "ELSEIF":
                self.cond(p)
                blk[1] = c.jump(0x7E)
        elif kw == "ENDIF":
            blk = self.top_block(("IF",), kw, n)
            self.blocks.pop()
            for q in ([blk[1]] if blk[1] is not None else []) + blk[3]:
                c.patch(q, c.pos())
        elif kw == "WHILE":
            start = c.pos()
            self.cond(p)
            self.blocks.append(["WHILE", c.jump(0x7E), n, [], start])
        elif kw == "ENDWH":
            blk = self.top_block(("WHILE",), kw, n)
            self.blocks.pop()
            c.jump(0x51, blk[4])
            for q in [blk[1]] + blk[3]:
                c.patch(q, c.pos())
        elif kw == "DO":
            self.blocks.append(["DO", None, n, [], c.pos(), []])
        elif kw == "UNTIL":
            blk = self.top_block(("DO",), kw, n)
            self.blocks.pop()
            for q in blk[5]:
                c.patch(q, c.pos())
            self.cond(p)
            c.jump(0x7E, blk[4])
            for q in blk[3]:
                c.patch(q, c.pos())
        elif kw in ("BREAK", "CONTINUE"):
            loop = next((b for b in reversed(self.blocks) if b[0] in ("WHILE", "DO")), None)
            if loop is None:
                raise TranslateError(f"{kw} outside a loop", n)
            if kw == "BREAK":
                loop[3].append(c.jump(0x51))
            elif loop[0] == "WHILE":
                c.jump(0x51, loop[4])
            else:
                loop[5].append(c.jump(0x51))
        elif kw in ("LOCAL", "GLOBAL"):
            raise TranslateError(f"{kw} must come before the procedure's statements", n)
        else:
            raise TranslateError(f"{kw} cannot be used here", n)
        return False

    def top_block(self, kinds, kw, n):
        if not self.blocks or self.blocks[-1][0] not in kinds:
            raise TranslateError(f"{kw} without matching {kinds[0]}", n)
        return self.blocks[-1]

    def label_name(self, p):
        t = p.next()
        if t.kind not in ("label", "id"):
            raise p.error("expected a label", t)
        return t.val

    def logical_file(self, p):
        t = p.next()
        if t.kind != "id" or t.val not in ("A", "B", "C", "D"):
            raise p.error("expected logical file name A, B, C or D", t)
        return ord(t.val) - ord("A")

    def open_create(self, kw, p, trap):
        c, n = self.c, p.lineno
        self.convert(self.expr(p.expr(), n), T_STR, n)
        p.expect_op(",")
        f = self.logical_file(p)
        fields = []
        while p.is_op(","):
            p.next()
            t = p.next()
            if t.kind != "id" or t.val in RESERVED:
                raise p.error("bad field name", t)
            fields.append(t.val)
        if not fields:
            raise TranslateError(f"{kw} needs at least one field name", n)
        if trap:
            c.op(0x5A)
        c.op(0x5E if kw == "CREATE" else 0x65, f)
        for name in fields:
            c.op(TYPE_BYTE[type_of_name(name)], len(name))
            c.b.extend(name.encode())
        c.op(0x88)

    def trap(self, cmd, p):
        c, n = self.c, p.lineno
        if cmd in SIMPLE_STATEMENTS and SIMPLE_STATEMENTS[cmd][3]:
            opcode, spec, lz, _ = SIMPLE_STATEMENTS[cmd]
            self.check_lz(cmd, lz, n)
            self.arglist(p, spec, cmd)
            c.op(0x5A, opcode)
        elif cmd in ("CREATE", "OPEN"):
            self.open_create(cmd, p, True)
        elif cmd == "USE":
            c.op(0x5A, 0x69, self.logical_file(p))
        elif cmd in ("INPUT", "EDIT"):
            typ = self.ref(p.lvalue(), n)
            if cmd == "EDIT" and typ != T_STR:
                raise TranslateError("EDIT needs a string variable", n)
            c.op(0x5A, 0x6B if cmd == "EDIT" else {T_INT: 0x6C, T_FLT: 0x6D, T_STR: 0x6E}[typ])
        else:
            raise TranslateError(f"TRAP cannot be used with {cmd}", n)

    def cond(self, p):
        n = p.lineno
        typ = self.expr(p.expr(), n)
        if typ == T_FLT:
            self.c.op(0x23, 0x02, 0x00, 0x00, 0x3A)
        elif typ == T_STR:
            raise TranslateError("a condition cannot be a string", n)

    # ---- assignment and references
    def assign(self, target, value, n):
        typ = self.ref(target, n)
        if target[0] == "var" and self.vars.get(target[1]) in self.params:
            raise TranslateError(f"parameter {target[1]} cannot be assigned to", n)
        self.convert(self.expr(value, n), typ, n)
        self.c.op({T_INT: 0x7F, T_FLT: 0x80, T_STR: 0x81}[typ])

    def var_op(self, e, n, ref):
        """Push a variable's value (ref=False) or reference (ref=True)."""
        c = self.c
        kind = e[0]
        if kind == "mem":
            c.op(0x13 if ref else 0x06)
            c.word(e[1] * 8)
            return T_FLT
        if kind == "field":
            name = e[2]
            typ = type_of_name(name)
            c.op(0x24, len(name))
            c.b.extend(name.encode())
            c.op((0x1D if ref else 0x1A) + TYPE_BYTE[typ], e[1])
            return typ
        name = e[1]
        if name in RESERVED:
            raise TranslateError(f"{name} is a reserved word", n)
        if len(name) > 8:
            raise TranslateError(f"variable name {name} is longer than 8 characters", n)
        v = self.lookup(name, kind == "elem", n)
        if kind == "elem":
            self.convert(self.expr(e[2], n), T_INT, n)
        base = 0x0D if ref else 0x00
        if v.kind in ("param", "ext"):
            base += 0x07
        if kind == "elem":
            base += 3
        c.op(base + TYPE_BYTE[v.typ])
        c.word(v.addr)
        return v.typ

    def ref(self, e, n):
        return self.var_op(e, n, True)

    # ---- expressions
    def convert(self, have, want, n):
        if have == want:
            return
        if have == T_INT and want == T_FLT:
            self.c.op(0x86)
        elif have == T_FLT and want == T_INT:
            self.c.op(0x87)
        else:
            names = {T_INT: "number", T_FLT: "number", T_STR: "string"}
            raise TranslateError(f"type mismatch: expected a {names[want]}", n)

    def expr_type(self, e, n):
        """Type of an expression without emitting code."""
        k = e[0]
        if k == "int":
            return T_INT
        if k == "flt":
            return T_FLT
        if k == "str":
            return T_STR
        if k in ("var", "elem"):
            v = self.vars.get(e[1]) or self.ext_by_name.get(e[1])
            return v.typ if v else type_of_name(e[1])
        if k == "field":
            return type_of_name(e[2])
        if k == "mem":
            return T_FLT
        if k == "neg":
            return self.expr_type(e[1], n)
        if k == "not":
            return T_INT
        if k == "fn":
            return FUNCTIONS[e[1]][2]
        if k == "call":
            return type_of_name(e[1])
        if k == "bin":
            if e[1] in COMPARISONS or e[1] in ("AND", "OR"):
                return T_INT
            lt, rt = self.expr_type(e[2], n), self.expr_type(e[3], n)
            if T_STR in (lt, rt):
                return T_STR
            return T_FLT if T_FLT in (lt, rt) else T_INT
        raise TranslateError("bad expression", n)

    def expr(self, e, n):
        """Emit code for an expression; returns its type."""
        c = self.c
        k = e[0]
        if k == "int":
            c.op(0x22)
            c.word(e[1])
            return T_INT
        if k == "flt":
            c.op(0x23)
            c.b.extend(float_const(e[1], n))
            return T_FLT
        if k == "str":
            b = e[1].encode("latin-1")
            c.op(0x24, len(b))
            c.b.extend(b)
            return T_STR
        if k in ("var", "elem", "field", "mem"):
            return self.var_op(e, n, False)
        if k == "neg":
            typ = self.expr(e[1], n)
            if typ == T_STR:
                raise TranslateError("cannot negate a string", n)
            c.op(0x32 if typ == T_INT else 0x41)
            return typ
        if k == "not":
            typ = self.expr(e[1], n)
            if typ == T_STR:
                raise TranslateError("NOT cannot be used on a string", n)
            c.op(0x33 if typ == T_INT else 0x42)
            return T_INT
        if k == "bin":
            return self.binop(e, n)
        if k == "fn":
            return self.function(e[1], e[2], n)
        if k == "call":
            return self.call(e[1], e[2], n)
        raise TranslateError("bad expression", n)

    def binop(self, e, n):
        op, l, r = e[1], e[2], e[3]
        lt_, rt_ = self.expr_type(l, n), self.expr_type(r, n)
        if (lt_ == T_STR) != (rt_ == T_STR):
            raise TranslateError(f"type mismatch in '{op}'", n)
        if lt_ == T_STR:
            code = BINOPS[op][2]
            if code is None:
                raise TranslateError(f"'{op}' cannot be used on strings", n)
            self.expr(l, n)
            self.expr(r, n)
            self.c.op(code)
            return T_STR if op == "+" else T_INT
        flt = T_FLT in (lt_, rt_)
        self.convert(self.expr(l, n), T_FLT if flt else T_INT, n)
        self.convert(self.expr(r, n), T_FLT if flt else T_INT, n)
        self.c.op(BINOPS[op][1 if flt else 0])
        if op in COMPARISONS or op in ("AND", "OR"):
            return T_INT
        return T_FLT if flt else T_INT

    def function(self, name, args, n):
        c = self.c
        opcode, spec, ret, lz = FUNCTIONS[name]
        self.check_lz(name, lz, n)
        if spec == "A":  # ADDR(var)
            if len(args) != 1:
                raise TranslateError("ADDR takes one variable", n)
            a = args[0]
            if a[0] == "whole":
                v = self.lookup(a[1], True, n)
                a = ("elem", a[1], ("int", 1))
            if a[0] not in ("var", "elem"):
                raise TranslateError("ADDR needs a variable", n)
            typ = self.ref(a, n)
            c.op(0xC9 if typ == T_STR else 0x8A)
            return T_INT
        if spec == "L":  # MAX, MIN, ... : list of numbers or (array(), count)
            if args and args[0][0] == "whole":
                if len(args) != 2:
                    raise TranslateError(f"{name}(array(),count) needs two arguments", n)
                v = self.lookup(args[0][1], True, n)
                if v.typ != T_FLT:
                    raise TranslateError(f"{name} needs a floating point array", n)
                self.ref(("elem", args[0][1], ("int", 1)), n)
                self.convert(self.expr(args[1], n), T_INT, n)
                c.op(0x20, 0x00, opcode)
                return T_FLT
            if not args:
                raise TranslateError(f"{name} needs arguments", n)
            for a in args:
                if a[0] == "whole":
                    raise TranslateError(f"bad arguments for {name}", n)
                self.convert(self.expr(a, n), T_FLT, n)
            c.op(0x20, len(args), 0x20, 0x01, opcode)
            return ret
        if len(args) != len(spec):
            raise TranslateError(f"{name} takes {len(spec)} argument(s)", n)
        for a, want in zip(args, spec):
            if a[0] == "whole":
                raise TranslateError(f"bad argument for {name}", n)
            self.convert(self.expr(a, n), want, n)
        c.op(opcode)
        return ret

    def call(self, name, args, n):
        c = self.c
        if len(name) > 8:
            raise TranslateError(f"procedure name {name} is longer than 8 characters", n)
        for a in args:
            if a[0] == "whole":
                raise TranslateError("arrays cannot be passed to procedures", n)
            typ = self.expr(a, n)
            c.op(0x20, TYPE_BYTE[typ])
        c.op(0x20, len(args), 0x7D, len(name))
        c.b.extend(name.encode())
        return type_of_name(name)


# --------------------------------------------------------------------------
# Public API

def split_lines(text):
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    out = []
    for i, ln in enumerate(lines, 1):
        if ln.strip():
            out.append((i, ln.expandtabs(1)))
    return out


def translate(text, target="lz"):
    """Translate OPL source text; returns the object code bytes."""
    if target not in ("lz", "cm"):
        raise ValueError("target must be 'lz' or 'cm'")
    return Proc(split_lines(text), target).translate()


def procedure_block(obj, source_lines, encoding="latin-1"):
    src = b"".join(ln.encode(encoding) + b"\0" for ln in source_lines)
    return (len(obj).to_bytes(2, "big") + obj + len(src).to_bytes(2, "big") + src)


# --------------------------------------------------------------------------
# Disassembler

OPCODE_NAMES = {
    0x20: "PUSH.B", 0x21: "PUSH.W", 0x22: "PUSH.I", 0x23: "PUSH.F", 0x24: "PUSH.S",
    0x27: "<", 0x28: "<=", 0x29: ">", 0x2A: ">=", 0x2B: "<>", 0x2C: "=", 0x2D: "+", 0x2E: "-",
    0x2F: "*", 0x30: "/", 0x31: "**", 0x32: "NEG", 0x33: "NOT", 0x34: "AND", 0x35: "OR",
    0x36: "<.F", 0x37: "<=.F", 0x38: ">.F", 0x39: ">=.F", 0x3A: "<>.F", 0x3B: "=.F", 0x3C: "+.F",
    0x3D: "-.F", 0x3E: "*.F", 0x3F: "/.F", 0x40: "**.F", 0x41: "NEG.F", 0x42: "NOT.F",
    0x43: "AND.F", 0x44: "OR.F", 0x45: "<.S", 0x46: "<=.S", 0x47: ">.S", 0x48: ">=.S",
    0x49: "<>.S", 0x4A: "=.S", 0x4B: "+.S", 0x51: "GOTO", 0x52: "OFF", 0x53: "ONERR",
    0x5A: "TRAP", 0x6B: "EDIT", 0x6C: "INPUT.I", 0x6D: "INPUT.F", 0x6E: "INPUT.S",
    0x6F: "PRINT.I", 0x70: "PRINT.F", 0x71: "PRINT.S", 0x72: "PRINT ,", 0x73: "PRINT NL",
    0x74: "LPRINT.I", 0x75: "LPRINT.F", 0x76: "LPRINT.S", 0x77: "LPRINT ,", 0x78: "LPRINT NL",
    0x79: "RETURN", 0x7A: "RETURN 0", 0x7B: "RETURN 0.0", 0x7C: 'RETURN ""', 0x7D: "CALL",
    0x7E: "BRANCH IF FALSE", 0x7F: "ASSIGN.I", 0x80: "ASSIGN.F", 0x81: "ASSIGN.S",
    0x82: "DROP.B", 0x83: "DROP.I", 0x84: "DROP.F", 0x85: "DROP.S", 0x86: "INT>FLT",
    0x87: "FLT>INT", 0x8A: "ADDR", 0xC9: "ADDR.S", 0x4F: "CURSOR", 0x50: "ESCAPE",
    0x5E: "CREATE", 0x65: "OPEN", 0x69: "USE", 0xD2: "OFF n",
}
for _n, (_op, _s, _r, _lz) in FUNCTIONS.items():
    if _op is not None:
        OPCODE_NAMES.setdefault(_op, _n)
for _n, (_op, _s, _lz, _t) in SIMPLE_STATEMENTS.items():
    OPCODE_NAMES.setdefault(_op, _n)
_VARNAMES = ["value.I", "value.F", "value.S", "value.I()", "value.F()", "value.S()"]
for _i in range(6):
    OPCODE_NAMES[0x00 + _i] = "local " + _VARNAMES[_i]
    OPCODE_NAMES[0x07 + _i] = "extern " + _VARNAMES[_i]
    OPCODE_NAMES[0x0D + _i] = "local " + _VARNAMES[_i].replace("value", "ref")
    OPCODE_NAMES[0x14 + _i] = "extern " + _VARNAMES[_i].replace("value", "ref")
OPCODE_NAMES.update({0x06: "memory value", 0x13: "memory ref", 0x1A: "field value.I",
                     0x1B: "field value.F", 0x1C: "field value.S", 0x1D: "field ref.I",
                     0x1E: "field ref.F", 0x1F: "field ref.S"})


def disassemble(obj):
    """Return a text listing of a procedure's object code."""
    def w(i):
        return (obj[i] << 8) | obj[i + 1]

    out = []
    vs, ql, np_ = w(0), w(2), obj[4]
    out.append(f"variable space {vs:04X}, qcode {ql:04X} bytes, {np_} parameter(s)"
               + (f" types {obj[5:5 + np_][::-1].hex(' ')}" if np_ else ""))
    p = 5 + np_
    for title in ("globals", "externals", "string fixups", "array fixups"):
        n = w(p)
        if n:
            out.append(f"{title}: {obj[p + 2:p + 2 + n].hex(' ')}")
        p += 2 + n
    q = obj[p:p + ql]
    i = 0
    while i < len(q):
        op = q[i]
        start = i
        i += 1
        arg = ""
        if op <= 0x19 or op in (0x21, 0x22):
            arg = f"{(q[i] << 8) | q[i + 1]:04X}"
            i += 2
        elif op in (0x51, 0x53, 0x7E):
            d = (q[i] << 8) | q[i + 1]
            arg = f"-> {(i + d) & 0xFFFF:04X}"
            i += 2
        elif 0x1A <= op <= 0x1F or op in (0x20, 0x4F, 0x50, 0x69):
            arg = f"{q[i]:02X}"
            i += 1
        elif op == 0x23:
            n = q[i] & 0x7F
            arg = q[i:i + 1 + n].hex(" ")
            i += 1 + n
        elif op in (0x24, 0x7D):
            n = q[i]
            arg = '"' + q[i + 1:i + 1 + n].decode("latin-1") + '"'
            i += 1 + n
        elif op in (0x5E, 0x65):
            arg = "ABCD"[q[i] & 3]
            i += 1
            while i < len(q) and q[i] != 0x88:
                n = q[i + 1]
                arg += "," + q[i + 2:i + 2 + n].decode("latin-1")
                i += 2 + n
            i += 1
        name = OPCODE_NAMES.get(op, "?")
        if start == 0 and q[:2] == b"\x59\xb2":
            name, i = "LZ stop sign", 2
        out.append(f"  {start:04X}  {q[start:i].hex(' '):<24} {name} {arg}".rstrip())
    return "\n".join(out)


# --------------------------------------------------------------------------
# Command line

def read_ob3(path):
    raw = open(path, "rb").read()
    if raw[:3] != b"ORG" or raw[5] != 0x83:
        raise TranslateError(f"{path} is not an OB3 procedure file")
    block = raw[6:6 + ((raw[3] << 8) | raw[4])]
    ol = (block[0] << 8) | block[1]
    return block[2:2 + ol]


def main():
    ap = argparse.ArgumentParser(description="Translate Psion Organiser II OPL source into object code (.ob3).")
    ap.add_argument("files", nargs="+", help=".opl files (or .ob3 files with --dis)")
    ap.add_argument("-o", "--outdir", help="folder for the .ob3 files (default: next to each .opl)")
    ap.add_argument("--target", choices=["lz", "cm"], default="lz",
                    help="lz = 4-line LZ/LZ64 (default), cm = 2-line CM/XP")
    ap.add_argument("--no-source", action="store_true", help="leave the source text out of the .ob3")
    ap.add_argument("--dis", action="store_true", help="disassemble .ob3 files instead")
    ap.add_argument("--encoding", default="latin-1")
    args = ap.parse_args()

    files = []
    for f in args.files:
        files += sorted(glob.glob(f)) or [f]
    status = 0
    for path in files:
        try:
            if args.dis:
                print(f"{path}:")
                print(disassemble(read_ob3(path)))
                continue
            raw = open(path, "rb").read()
            if raw.startswith(b"\xef\xbb\xbf"):  # UTF-8 byte order mark from Windows editors
                raw = raw[3:]
            text = raw.decode(args.encoding)
            obj = translate(text, args.target)
            lines = [ln for _, ln in split_lines(text)]
            name = re.match(r"\s*([A-Za-z][A-Za-z0-9]*[%$]?)", lines[0]).group(1).upper()
            block = procedure_block(obj, [] if args.no_source else lines, args.encoding)
            out = os.path.join(args.outdir or os.path.dirname(path) or ".", name + ".ob3")
            if args.outdir:
                os.makedirs(args.outdir, exist_ok=True)
            with open(out, "wb") as f:
                f.write(b"ORG" + len(block).to_bytes(2, "big") + b"\x83" + block)
            print(f"{path}: {name} translated, {len(obj)} bytes of object code -> {out}")
        except TranslateError as e:
            print(f"{path}: error: {e}", file=sys.stderr)
            status = 1
        except OSError as e:
            print(f"{path}: {e}", file=sys.stderr)
            status = 1
    sys.exit(status)


if __name__ == "__main__":
    main()
