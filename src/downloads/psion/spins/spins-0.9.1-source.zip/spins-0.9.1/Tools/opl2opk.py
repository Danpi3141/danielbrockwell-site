#!/usr/bin/env python3
"""
opl2opk.py - build a Psion Organiser II pack image (.opk) from files.

Accepted input files (wildcards like *.opl are expanded, folders are searched):

  .opl        OPL source text, one procedure per file. It is translated with
              opltran.py (same output as the Organiser's own translator), so
              it runs straight away; the source is kept too, so it can still
              be edited on the Organiser. --no-translate stores source only,
              like Prog > Save (translate later with Prog > Edit, MODE > Tran).
  .ob3        A procedure block (as written by opk2files.py), copied as is,
              so already-translated procedures keep their object code.
  .ob2-.obf   Any other block file (e.g. .ob7 notepads), copied as is.
  .odb        A data file: one record per line, fields separated by TAB.
              MAIN.odb fills the MAIN file; other names make new data files.

The procedure name comes from the title line (e.g. "GUESS:" or "VAT1:(p)");
if the file has no title line, one is added from the file name.

Usage:
    python opl2opk.py MYPACK.opk GUESS.opl
    python opl2opk.py MYPACK.opk *.opl EXTRA.ob3 ADDRESS.odb --size 32
    python opl2opk.py MYPACK.opk Programs --rampak
    python opl2opk.py MYPACK.opk GUESS.opl --target cm     (for a 2-line CM/XP)

Load the result in Jape with "Select OPK file...", give it a name, Create,
then put it in Slot B or C.
"""

import argparse
import datetime
import glob
import os
import random
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from opltran import translate, TranslateError  # noqa: E402

SIZES_K = [8, 16, 32, 64, 128, 256]
NAME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9]*$")
PROC_NAME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9]*[%$]?$")
TITLE_RE = re.compile(r"^\s*([A-Za-z][A-Za-z0-9]*[%$]?)\s*:\s*(\(.*\))?\s*$")


class PackError(Exception):
    pass


def be16(n):
    return bytes([(n >> 8) & 0xFF, n & 0xFF])


def short_record(rtype, data):
    if not 1 <= len(data) <= 254:
        raise PackError(f"record of {len(data)} bytes does not fit in a short record (1-254)")
    return bytes([len(data), rtype]) + data


def long_record(data):
    if len(data) > 0xFFFF:
        raise PackError(f"block of {len(data)} bytes is too long (max 65535)")
    return b"\x02\x80" + be16(len(data)) + data


def name8(name):
    return name.upper().encode("ascii").ljust(8, b" ")


def block_file(ftype, name, block):
    """Block file = 11-byte header record + long record."""
    return short_record(ftype, name8(name) + b"\x00") + long_record(block)


# ---------------------------------------------------------------- inputs

def read_text_lines(path, encoding):
    raw = open(path, "rb").read()
    if raw.startswith(b"\xef\xbb\xbf"):  # UTF-8 BOM from Windows editors
        raw = raw[3:]
    text = raw.decode(encoding)
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    while lines and lines[-1].strip() == "":
        lines.pop()
    return lines


def encode_line(line, encoding, where, quiet=False):
    b = line.encode(encoding)
    if b"\x00" in b:
        raise PackError(f"{where}: line contains a NUL character")
    if not quiet and any(c >= 128 for c in b):
        print(f"warning: {where}: non-ASCII characters; Psion codes 128-255 differ from PC "
              f"character sets, so consider CHR$() instead", file=sys.stderr)
    return b


def ob3_source(blockfile):
    """Source text bytes inside a procedure block file (header + long record)."""
    block = blockfile[11 + 4:]
    ol = (block[0] << 8) | block[1]
    sl = (block[2 + ol] << 8) | block[3 + ol]
    return block[4 + ol:4 + ol + sl]


def opl_procedure(path, args, quiet=False):
    stem = os.path.splitext(os.path.basename(path))[0]
    lines = read_text_lines(path, args.encoding)
    if args.strip_indent:
        lines = [ln.strip() for ln in lines]
    else:
        lines = [ln.rstrip().expandtabs(2) for ln in lines]
    # drop leading blank lines; the title must be the first line
    first = 0  # line number offset, so translator errors point at the real file line
    while lines and lines[0] == "":
        lines.pop(0)
        first += 1
    m = TITLE_RE.match(lines[0]) if lines else None
    if m and not lines[0].rstrip().endswith("::"):
        name = m.group(1).upper()
    else:
        name = stem.upper()
        lines.insert(0, f"{name}:")
        first -= 1
        if not quiet:
            print(f"note: {path}: no title line, added '{name}:'", file=sys.stderr)
    if len(name) > 8 or not PROC_NAME_RE.match(name):
        raise PackError(f"{path}: procedure name '{name}' must start with a letter, use letters/digits "
                        f"(optionally ending in % or $) and be at most 8 characters")
    if any(ln == "" for ln in lines):
        # The Organiser editor never stores empty lines; keep them as a single space
        lines = [ln if ln else " " for ln in lines]
    src = b"".join(encode_line(ln, args.encoding, f"{path} line {i + 1}", quiet) + b"\x00"
                   for i, ln in enumerate(lines))
    for i, ln in enumerate(lines):
        if len(ln) > 255 and not quiet:
            print(f"warning: {path} line {i + 1} is longer than 255 characters", file=sys.stderr)
    obj = b""
    if not args.no_translate:
        try:
            obj = translate("\n".join(lines), args.target)
        except TranslateError as e:
            where = f"line {e.line + first}: " if e.line else ""
            raise PackError(f"{path}: {where}{e.msg}\n"
                            f"  (use --no-translate to store it untranslated and translate it on the Organiser)")
    block = be16(len(obj)) + obj + be16(len(src)) + src  # no object code = untranslated
    state = f"translated, {len(obj)} bytes" if obj else f"source only, {len(lines)} lines"
    return name, block_file(0x83, name, block), f"procedure {name:<8} ({state})"


def ob_block(path):
    raw = open(path, "rb").read()
    if raw[:3] != b"ORG" or len(raw) < 6:
        raise PackError(f"{path}: not an OBx file (missing 'ORG' signature)")
    ln = (raw[3] << 8) | raw[4]
    ftype = raw[5]
    block = raw[6:6 + ln]
    if len(block) != ln:
        raise PackError(f"{path}: file is shorter than its length field says")
    if not 0x82 <= ftype <= 0x8F:
        raise PackError(f"{path}: file type ${ftype:02X} is not a block file type ($82-$8F)")
    name = os.path.splitext(os.path.basename(path))[0].upper()
    if len(name) > 8 or not PROC_NAME_RE.match(name):
        raise PackError(f"{path}: file name '{name}' is not a valid Organiser name (max 8 chars)")
    what = "procedure" if ftype == 0x83 else f"block ${ftype:02X}"
    if ftype == 0x83:
        state = "translated" if (block[0] << 8 | block[1]) else "source"
        what += f" {name:<8} ({state})"
    else:
        what += f" {name:<8} ({len(block)} bytes)"
    return name, block_file(ftype, name, block), what


def odb_records(path, args):
    name = os.path.splitext(os.path.basename(path))[0].upper()
    if len(name) > 8 or not NAME_RE.match(name):
        raise PackError(f"{path}: data file name '{name}' must be letters/digits, max 8, starting with a letter")
    recs = []
    for i, ln in enumerate(read_text_lines(path, args.encoding)):
        if ln == "":
            print(f"note: {path} line {i + 1}: empty line skipped (records cannot be empty)", file=sys.stderr)
            continue
        b = encode_line(ln, args.encoding, f"{path} line {i + 1}")
        if len(b) > 254:
            raise PackError(f"{path} line {i + 1}: record is {len(b)} bytes, max is 254")
        recs.append(b)
    return name, recs


def expand_inputs(items):
    out = []
    for item in items:
        if os.path.isdir(item):
            for ext in ("*.opl", "*.ob?", "*.odb"):
                out += sorted(glob.glob(os.path.join(item, ext)))
            continue
        matches = sorted(glob.glob(item))
        if not matches and not os.path.exists(item):
            raise PackError(f"{item}: no such file")
        out += matches or [item]
    seen, uniq = set(), []
    for p in out:
        k = os.path.normcase(os.path.abspath(p))
        if k not in seen:
            seen.add(k)
            uniq.append(p)
    return uniq


# ---------------------------------------------------------------- pack

def pack_header(size_k, rampak):
    flags = 0x78 if rampak else 0x7A   # RDWRT, NOBOOT, COPYPK, NYIMPL set; bit1 = datapak
    if size_k >= 32:
        flags |= 0x04                    # page-counted pack
    now = datetime.datetime.now()
    frame = random.randrange(0x10000)
    h = bytes([flags, size_k // 8, now.year - 1900 & 0xFF, now.month - 1, now.day - 1, now.hour]) + be16(frame)
    checksum = sum((h[i] << 8) | h[i + 1] for i in range(0, 8, 2)) & 0xFFFF
    return h + be16(checksum)


def build(args):
    files = expand_inputs(args.inputs)
    if not files:
        raise PackError("no input files")

    blocks, names, lines = [], {}, []
    datafiles = {"MAIN": []}

    def claim(name, kind, path):
        key = name.upper()
        if key in names:
            raise PackError(f"{path}: name {key} is already used by {names[key]}")
        names[key] = path

    # NAME.opl next to NAME.ob3 (as opk2files.py writes them): use the .ob3,
    # which keeps the translated code, unless the .opl has been edited since.
    ob3_by_name = {}
    for path in files:
        if os.path.splitext(path)[1].lower() == ".ob3":
            ob3_by_name[os.path.splitext(os.path.basename(path))[0].upper()] = path
    skip = set()
    for path in files:
        if os.path.splitext(path)[1].lower() != ".opl":
            continue
        pname, pdata, _ = opl_procedure(path, args, quiet=True)
        ob3 = ob3_by_name.get(pname)
        if not ob3:
            continue
        _, odata, _ = ob_block(ob3)
        if ob3_source(odata) == ob3_source(pdata):
            skip.add(path)
            print(f"note: {pname}: {os.path.basename(path)} matches {os.path.basename(ob3)}; "
                  f"using the translated .ob3", file=sys.stderr)
        else:
            skip.add(ob3)
            print(f"note: {pname}: {os.path.basename(path)} differs from {os.path.basename(ob3)}; "
                  f"using the edited .opl (translate it again on the Organiser)", file=sys.stderr)

    for path in files:
        if path in skip:
            continue
        ext = os.path.splitext(path)[1].lower()
        if ext == ".opl":
            name, data, what = opl_procedure(path, args)
        elif re.fullmatch(r"\.ob[0-9a-f]", ext):
            name, data, what = ob_block(path)
        elif ext == ".odb":
            name, recs = odb_records(path, args)
            if name in datafiles and datafiles[name]:
                raise PackError(f"{path}: data file {name} given twice")
            datafiles[name] = recs
            lines.append(f"data file {name:<8} ({len(recs)} records)")
            continue
        else:
            raise PackError(f"{path}: don't know what to do with '{ext}' files")
        claim(name, "block", path)
        blocks.append(data)
        lines.append(what)

    # data files: MAIN is always present (id $90); others get $91, $92, ...
    body = b""
    next_id = 0x90
    for name, recs in datafiles.items():
        if name != "MAIN":
            claim(name, "data", name)
        if next_id > 0xFE:
            raise PackError("too many data files (max 111)")
        fid = next_id
        next_id += 1
        body += short_record(0x81, name8(name) + bytes([fid]))
        for r in recs:
            body += short_record(fid, r)
    body += b"".join(blocks)

    need = 10 + len(body) + 2  # header + records + $FFFF end marker
    if args.size:
        size_k = args.size
        if need > size_k * 1024:
            raise PackError(f"contents need {need} bytes, which does not fit in a {size_k}K pack")
    else:
        choices = [s for s in SIZES_K if (32 <= s if args.rampak else s <= 128)]
        size_k = next((s for s in choices if need <= s * 1024), None)
        if size_k is None:
            raise PackError(f"contents need {need} bytes, more than the largest pack")

    data = pack_header(size_k, args.rampak) + body + b"\xFF\xFF"
    # Same convention as Jape: the length excludes the final $FFFF
    opk = b"OPK" + bytes([(len(data) - 2) >> 16 & 0xFF, (len(data) - 2) >> 8 & 0xFF, (len(data) - 2) & 0xFF]) + data
    return opk, size_k, need, lines


def main():
    ap = argparse.ArgumentParser(description="Build a Psion Organiser II .opk pack image from .opl/.obX/.odb files.")
    ap.add_argument("output", help="the .opk file to create")
    ap.add_argument("inputs", nargs="+", help=".opl, .ob3 (etc.) and .odb files, wildcards or folders")
    ap.add_argument("--size", type=int, choices=SIZES_K, help="pack size in K (default: smallest that fits)")
    ap.add_argument("--rampak", action="store_true", help="make a Rampak instead of a Datapak (min 32K)")
    ap.add_argument("--no-translate", action="store_true",
                    help="store .opl procedures as source only (translate them on the Organiser)")
    ap.add_argument("--target", choices=["lz", "cm"], default="lz",
                    help="translate for lz = 4-line LZ/LZ64 (default) or cm = 2-line CM/XP")
    ap.add_argument("--strip-indent", action="store_true",
                    help="remove leading spaces from OPL lines (saves pack space)")
    ap.add_argument("--encoding", default="latin-1",
                    help="text encoding of input files (default: latin-1, byte-transparent)")
    ap.add_argument("-f", "--force", action="store_true", help="overwrite the output file if it exists")
    args = ap.parse_args()

    if not args.output.lower().endswith(".opk"):
        sys.exit("error: the first argument is the .opk file to create, e.g. MYPACK.opk")
    if args.rampak and args.size and args.size < 32:
        sys.exit("error: Rampaks are 32K or larger")
    if not args.rampak and args.size == 256:
        sys.exit("error: Datapaks go up to 128K; use --rampak for 256K")
    if os.path.exists(args.output) and not args.force:
        sys.exit(f"error: {args.output} already exists (use -f to overwrite)")
    try:
        opk, size_k, need, lines = build(args)
    except PackError as e:
        sys.exit(f"error: {e}")
    with open(args.output, "wb") as f:
        f.write(opk)
    kind = "Rampak" if args.rampak else "Datapak"
    print(f"{args.output}: {size_k}K {kind}, {need} of {size_k * 1024} bytes used")
    for ln in lines:
        print("  " + ln)
    if any("(source only" in ln for ln in lines):
        print("Source-only procedures must be translated on the Organiser before running:\n"
              "  Prog > Edit > NAME, then MODE > Tran > EXE")


if __name__ == "__main__":
    main()
