# Psion Organiser II tools

Python 3 scripts (and one OPL loader) for getting OPL programs onto the Organiser, or the Jape emulator, and back off again.

| Script | What it does |
|---|---|
| `opl2opk.py` | Builds a `.opk` pack image from `.opl`, `.ob3` and `.odb` files. `.opl` files are translated, so they run straight away. |
| `opk2files.py` | Unpacks a `.opk` into `.opl` (source), `.ob3` (translated procedure), `.odb` (data file) and other files. |
| `opltran.py` | The OPL translator that `opl2opk.py` uses. It can also be run on its own to make `.ob3` files or to disassemble them. |
| `asm6303.py` | A small HD6303 assembler (from Phaselock), used by `mkrpdata.py` for `RPLOAD`'s machine code. |
| `mkrpdata.py` | Gets a whole folder of files onto a real Organiser through Psi2Win (or Psion's CL) in one go, using the OPL loaders `RPBOOT.opl`, `RPLOAD.opl` and `RPLOADCM.opl`. See below. |

## Quick start

```bash
python Tools/opl2opk.py MYPACK.opk Programs
```

In Jape: **Select OPK file...** → pick `MYPACK.opk` → type a name → **Create** → **Slot B**.
On the Organiser: **Prog → Run**, press MODE until it shows `B:`, type the procedure name, EXE.

```bash
python Tools/opk2files.py MYPACK.opk
```

## The translator

`opltran.py` produces the same object code as the LZ/LZ64 ROM's own translator.
`tests/` holds 19 procedures translated by the real ROM in Jape, and `python Tools/tests/run_tests.py` checks that every one matches byte for byte.

```bash
python Tools/opltran.py GUESS.opl
```
```bash
python Tools/opltran.py --dis GUESS.ob3
```

Options:

- `--target cm` translates for the 2-line CM/XP (no LZ "stop sign", and LZ-only keywords are refused).
- `--no-source` leaves the source out of the `.ob3`: smaller, but the procedure can't be edited on the Organiser.
- `-o FOLDER` writes the `.ob3` files to another folder.
- `opl2opk.py --no-translate` stores source only, like **Prog → Save** on the Organiser.

What it supports: the full Organiser II OPL language, with these exceptions:

- the LZ percentage operators (`+%`, `-%`, `*%`, `/%`, `<%`, `>%`, written after the second number, as in `200+5%`) are not supported.
  Character codes such as `%A` (65) work anywhere a number can go, including `k%=%Q`, `1+%B` and `CHR$(% )`.
- CM/XP output (`--target cm`) has been checked against the Organisers' own translators for one procedure only, `RPLOADCM`: the CM 3.3, XP 3.1 and LA 3.6 ROMs give the same bytes. CM 2.4 puts `TRAP` before a command's arguments instead of after them, and runs either order.

## Loading a real Organiser: RPBOOT and RPLOAD

Psi2Win can't write pack images, but the Comms Link's `XTRECV:` command can fetch any file from the folder Psi2Win serves, including translated `.OB3` procedures. `RPLOAD` is one OPL procedure that does this for a whole list of files, with a progress bar and a time estimate. Between files it runs a machine-code routine, so it adds about 0.15 s per file to the transfer time rather than the 0.5 s the all-OPL version took (see *Speed* below). `RPLOAD` needs an LZ or LZ64. On the 2-line CM, XP and LA, `RPLOADCM` does the same job with no bar or estimate, in an eighth of the RAM, and deletes itself when it has finished (see *On a CM, XP or LA* below). `RPBOOT` is a tiny starter that runs whichever loader suits the model, and fetches it first if it isn't on the Organiser.

| File | What it is |
|---|---|
| `mkrpdata.py` | Run on the PC: writes the file list and puts the loader into a folder |
| `RPBOOT.opl` | The starter, sent to the Organiser as source and translated there: 209 bytes of source, 179 of code (see *RPBOOT* below) |
| `RPLOAD.opl` | The loader's OPL part: the file list, the menu, `XTRECV:` and error screens. Translate it with `mkrpdata.py` only: its `@MCODE@` line is where the machine code goes |
| `rpload.asm` | The machine code: timing each file, the time estimate and drawing the status screen (about 1.3K) |
| `rpdec.asm` | A 50-byte routine that unpacks the machine code from the strings it is stored in |
| `RPLOADCM.opl` | The loader for the 2-line CM, XP and LA: plain OPL, translated for those models by `mkrpdata.py` into `RPLOADCM.OB3` (445 bytes: 435 of code) |
| `tests/rpload/` | Tests for all three in the headless emulator (`python Tools/tests/rpload/run.py`) |

`mkrpdata.py` assembles `rpload.asm`, puts it in `RPLOAD` as string constants (almost byte for byte, so it costs little more than its own size), and translates the result into `RPLOAD.OB3` with no source: about 2.5K on the Organiser.

### On the PC

```bash
python Tools/mkrpdata.py FOLDER --title "MY GAME" --run MYGAME
```

This writes four files into `FOLDER`: `RPDATA.ODB` (the file list), `RPBOOT.OPL`, `RPLOAD.OB3` and `RPLOADCM.OB3`. Run it again whenever the folder's contents change.

- The list includes every `.OB3`, `.ODB`, `.OPL`, `.OB2`, `.OB4` and `.OB5` file in the folder, in alphabetical order. Other files and subfolders are ignored, and so are the loader's own files.
- Organiser names come from the PC names. A procedure file ending in `_` (`TITLE_.OB3`) is loaded as `TITLE%`, because Comms Link writes `%` as `_` on the PC.
- `--title` is shown while loading: at most 12 characters, defaulting to `--run` or the folder name.
- `--run` names the procedure to start afterwards. The loader shows it as `NOW RUN B:MYGAME`, because Organiser II OPL can't call a procedure whose name is in a variable.
- `--no-loader` writes only `RPDATA.ODB`.
- It refuses names the Organiser can't use (letter first, then letters and digits, at most 8), two files that would get the same Organiser name, more than 999 files, a file over 32767 bytes, more than 512K in all, and a `--run` that isn't in the folder.
- `.OPL` files arrive as source only and must be translated on the Organiser (**PROG → EDIT** → MODE → **TRAN**) before they run. Send `.OB3` files to avoid this; `opltran.py --no-source` makes them.

### On the Organiser

1. In Psi2Win, set **Folder** to `FOLDER` and click **Start!**.
2. First time only: **COMMS → RECEIVE → PROCEDURE**, type `RPBOOT`, EXE. Then **PROG → EDIT** `RPBOOT` → MODE → **TRAN**. `RPBOOT` stays on the Organiser and works with any folder.
3. **PROG → RUN** `RPBOOT`. On an LZ or LZ64 it runs `RPLOAD`; on a CM, XP or LA, `RPLOADCM` (below). If that loader isn't on any pack, `RPBOOT` fetches its `.OB3` into `A:` first (the screen doesn't change while it does). `RPLOAD` stays there, so later runs start straight away; `RPLOADCM` deletes itself after a full load, so it is fetched again each time. To update `RPLOAD`, delete it (**PROG → DELETE**) and run `RPBOOT` again. An `RPBOOT` received before 20 Nov 2026 only knows `RPLOAD`: receive and translate the new one.
4. `RPLOAD` fetches `RPDATA` into `A:` and shows the title, the number of files and the total size. If the total is more than `A:` has free, it says so (`A: ONLY 12.3K FREE`). Pick A:, B: or C:, or press ON/CLEAR to cancel.

While it loads, the screen shows:

```
MY GAME         12/29      title, files done
█████████▌░░░░░░░░░░       progress bar (by bytes, 100 steps)
5.8/13.3K         43%      bytes done
TITLE%      ETA 0:28       file being fetched, time left
```

When it finishes, the third line shows the total time (`DONE IN 1:06`) and the fourth `NOW RUN B:MYGAME` (or `PRESS A KEY` without `--run`).

The time left comes from fitting *time per file = overhead + bytes × rate* to the files fetched so far, because small files are slower per byte: each one has a fixed cost (opening, closing and writing the file). Until there are enough files for a fit, the time `RPDATA` took to arrive serves as the overhead estimate. That first guess tends to come out high, up to about double, but the estimate settles within a few files. Each file is timed with the 50 ms frame counter, checked against the clock.

**Speed.** `XTRECV:` itself is already machine code (in the Comms Link), and the serial link, its handshakes and the PC set the transfer rate, so nothing in `RPLOAD` can make a file arrive faster. What `RPLOAD` controls is the gap between files, when the link sits idle. In the all-OPL version the status screen and the time estimate took 0.53 s per file (measured in the emulator with an `XTRECV:` that returns at once), about 15 s for a 29-file game. The machine-code routine cuts that gap to about 0.15 s: the routine itself takes 0.08 s, the rest is OPL reading the next entry of `RPDATA` and calling `XTRECV:`. The cost is size: `RPLOAD.OB3` is 2.5K instead of 2.0K.

`RPLOAD` deletes `A:RPDATA` when it finishes, when you cancel, and when a transfer fails.

### When something goes wrong

| Screen | Meaning |
|---|---|
| `NO RPDATA.ODB ON PC` | Psi2Win isn't running, its folder is wrong, or `mkrpdata.py` hasn't been run on it. If the next line says `MISSING PROC`, the Comms Link software isn't loaded (see below) |
| `FAILED ON B:NAME` | One file failed. The screen shows the error, the PC file name and how many files were done. Fix the cause and run `RPBOOT` again; files already loaded are simply replaced |
| `MISSING PROC` / `XTRECV` (the Organiser's own message) | The Comms Link software isn't loaded. Plug the link in and switch the Organiser off and on |
| Out of memory | Not enough room on the chosen pack. While it runs, `RPLOAD` also needs about 4.5K of `A:` (its code and variables) |

Re-running on a Datapak leaves the replaced copies taking up space until the pack is formatted, so a Rampak or `A:` is better for repeated loads.

### On a CM, XP or LA: RPLOADCM

`RPLOAD` can't run on the 2-line models: it uses `UDG` and `MENUN`, which only the LZ has, and its status screen needs four lines. On those models `RPBOOT` runs `RPLOADCM` instead. It does only what loading needs, because the Comms Link takes most of a CM's RAM:

```
TO A/B/C?                press A, B or C (ON/CLEAR cancels)
3/29 TITLE%              while loading: file number, name
DONE                     at the end, with the program to run
RUN B:MYGAME
```

- **RAM.** 492 bytes while it runs (its code and variables), against about 4.5K for `RPLOAD`. `A:RPLOADCM` takes about 0.45K of `A:` while it's there.
- **It deletes itself.** After a full load (`DONE`), `RPLOADCM` deletes `A:RPLOADCM`, so between loads only `RPBOOT` is left on `A:` (about 0.4K: its source and code). `RPBOOT` fetches it again next time, which adds one 0.45K transfer to each load. After a cancel or a failure it stays, so you can run `RPLOADCM` again straight away. Run from a pack, it deletes nothing. OPL can't delete a procedure on a CM, so this is 7 bytes of machine code in a string: the OS's `FL$BDEL` (block delete, service $23) with X = the name `A:RPLOADCM` and B = $83 (OPL procedure). It is safe while the procedure runs because OPL runs a copy of a procedure's code on its stack, loaded at each call.
- **The file list** (`RPDATA`) goes onto the pack you load to, not into `A:`, so it costs no RAM unless you load into `A:`. It is deleted at the end, after a failure, and after a cancel. On a Datapak each run leaves a deleted copy (a few hundred bytes) until the pack is formatted.
- **No checks or extras:** no bar, time estimate, title, total size or free-space check. If a file doesn't fit, `XTRECV:` fails and `RPLOADCM` shows `FAILED B:NAME` and the Organiser's error message. Fix the cause and run `RPBOOT` again; files already loaded are simply replaced. `FAILED B:RPDATA` means the list didn't arrive (Psi2Win not running, wrong folder, `mkrpdata.py` not run, or no Comms Link software: `MISSING PROC`).
- It reads the same `RPDATA.ODB` as `RPLOAD`, so one folder serves every model.

### RPBOOT

`RPBOOT` stays on the Organiser (source and code, about 0.4K of `A:`), so it is cut to the bone, with no comments:

```
RPBOOT:
ONERR e::
IF PEEKB(-24) AND 8 :RPLOAD: :ELSE :RPLOADCM: :ENDIF
RETURN
e::
ONERR OFF
IF PEEKB(-24) AND 8
XTRECV:("RPLOAD","A:RPLOAD",3) :RPLOAD:
ELSE
XTRECV:("RPLOADCM","A:RPLOADCM",3) :RPLOADCM:
ENDIF
```

- **The model.** `PEEKB(-24)` reads the ROM's model byte at `$FFE8`; bit 3 (`AND 8`) is set only on the 4-line LZ and LZ64 (CM 0, XP 1, LA 2, LA HP 34, LZ 14, LZ64 13). It is read twice rather than kept in a variable, which comes out smaller.
- **Any error fetches the loader.** The first call fails with `MISSING PROC` (203) when the loader isn't on any pack, and `RPBOOT` then fetches it. It doesn't check that the error was 203: an error that escapes a loader (they handle their own) also makes `RPBOOT` fetch and run it once more, and if that fails too the Organiser shows the error, since `ONERR OFF` comes first. Without the Comms Link software that is `MISSING PROC` for `XTRECV`.
- **No extension.** The PC names are `RPLOAD` and `RPLOADCM`: `XTRECV:` adds `.OB3` for type 3 itself (Comms Link manual, 7.5). `RPLOADCM` asks for its list as `RPDATA` the same way (`.ODB` for type 0); `RPLOAD` still says `RPDATA.ODB`. That is the one part of the loaders that can't be tested in the emulator. If Psi2Win doesn't find the files, change the two names in `RPBOOT` to `RPLOAD.OB3` and `RPLOADCM.OB3`, and `f$="RPDATA"` in `RPLOADCM.opl` to keep the name and add the extension only in the `XTRECV:` call.
- **No message.** It shows nothing while it fetches the loader; the Prog menu's `RUN B:RPBOOT` stays on the screen for the few seconds it takes.
- The translated `.OB3` can't be received through the COMMS menu, which takes procedures as source only. Only `XTRECV:` with type 3, called from OPL, can fetch one: that is why `RPBOOT` exists.

### How RPLOADCM was cut down

From 505 bytes of code to 435 (and 556 to 492 bytes of RAM), with the same behaviour:

- The list's name is built once, in `g$` (`B:RPDATA`), instead of `d$+"RPDATA"` in four places; the device for the files is `LEFT$(g$,2)`. (A separate `d$` saves 2 bytes of code but costs 3 of variables.)
- `k%=GET AND 95` makes a lower-case letter upper case (and leaves ON/CLEAR's 1 alone), so no separate test.
- No title line, the prompt is `TO A/B/C?`, and the progress line uses `,` for its space.
- The error handler prints `ERR$(ERR)` before the `TRAP`s (a `TRAP` resets `ERR`), so `ERR` needn't be saved; it deletes the list after the message is up.
- `f$` starts as `RPDATA`, which is both the PC name for the list and what `FAILED B:RPDATA` shows if it doesn't come.

Left in, though they'd save a few bytes: the check that skips `RUN B:` when the list names no program (9 bytes), and `TRAP CLOSE` in the error handler, in case the list was open when the error came.

### RPDATA.ODB

Plain tab-separated text with CR LF line ends, so it's easy to write by hand. The first line is *title, program to run (may be empty), total bytes, number of files*. Each following line is *Organiser name, PC file name, size in bytes, XTRECV type* (0 data, 1 procedure source, 2 diary, 3 translated procedure, 4 Comms Link setup, 5 spreadsheet).

### Requirements and testing

`RPLOAD` needs an LZ or LZ64 (it uses `UDG` and `MENUN`); `RPLOADCM` runs on every model; `RPBOOT` picks between them by bit 3 of the ROM's model byte at `$FFE8`, which only the 4-line models set. All need a Comms Link, and Psi2Win or Psion's CL on the PC. They were tested in Jape with a stand-in for `XTRECV:`, because Jape has no Comms Link: the fetch-once bootstrap, cancelling, a failed transfer and a full run. The all-OPL `RPLOAD` was also used on a real Organiser through Psi2Win. The machine-code version was tested in the headless emulator (`Programs/Phaselock/tools/emu.js`, the real LZ64 ROM) with a stand-in `XTRECV:` that takes 0.5 s + 800 bytes/s per file: Rampart's 29 files, 1 and 2 files, files all the same size, 5-byte files, 500K in 17 files, and a failed transfer. Its time estimates match the OPL version's, and a simulated Rampart load took 37 s instead of 47 s. It has not yet run on a real Organiser.

`tests/rpload/run.py` (49 checks, under a minute) runs all three in the headless emulator with a stand-in `XTRECV:`, since the emulator has no Comms Link. It logs each call, really puts the loaders onto `A:` (copying them from `B:` with the OS's `FL$COPY`), and copies the file list, but doesn't write the listed files:

- `RPBOOT`, translated by each Organiser's own editor, fetches and runs the right loader on all 24 Organiser ROMs: CM 2.4, 2.6, 3.3, 3.3 French, 3.6 French; XP 2.4, 2.6, 3.1; LA 3.0 (HP), 3.3, 3.4 German, 3.6, 3.6 French, 3.6 German, 3.7 multilingual; LZ 4.2–4.6 and LZ64 4.3–4.6b.
- `RPLOADCM` on CM 3.3, CM 2.4, XP 3.1 and LA 3.6: loading to B: and to A:, deleting itself (A: back to exactly where it was, whether `RPBOOT` started it or it was run from A:), the next run fetching it again, cancelling (it stays), keys that aren't A, B or C, a failed file, and a missing list. Each time the right calls are made and the list is deleted.
- Those four ROMs' own translators against `RPLOADCM.OB3` (see the `--target cm` note above), and the RAM each loader uses.

`RPLOADCM` has not yet run on a real Organiser.

## Notes

- One procedure per `.opl` file. The first line is the title, e.g. `GUESS:` or `ADD%:(x%,y%)`.
- Jape's keyboard has no `!` or `?`, but source written on a PC can use them freely. Codes 128–255 differ between the PC and the Psion, so use `CHR$()` for those.
- `opk2files.py` writes `NAME.opl` and `NAME.ob3` side by side. If you feed that folder back to `opl2opk.py`, it uses the `.ob3` when the `.opl` is unchanged and re-translates the `.opl` if you've edited it.

## Examples

Two small OPL programs from the start of the project, as source and as ready-made packs:

| Folder | What it is |
|---|---|
| `examples/Guess/` | `GUESS`: guess a number from 1 to 100 in one procedure. `GUESS.opk` is an 8K Datapak image with the translated procedure and its source. |
| `examples/Countdown/` | `COUNTDN`: the Countdown numbers game (reach a target from six numbers), in 7 procedures. `COUNTDN.opk` holds them all. |

## About this repository

`Daniel/Psion-Tools` on Forgejo, shared by the `Daniel/Psion-*` program repos. They expect the PsionII workspace layout:

```
PsionII/
  Emulator/          Jape, Jaap Scherphuis's emulator, with its ROM images (not in any repo:
                     https://www.jaapsch.net/psion/jape/jape.htm)
  Tools/             this repository
  Programs/NAME/     one repository per program (Psion-Chess, Psion-Connect4, ...)
```
