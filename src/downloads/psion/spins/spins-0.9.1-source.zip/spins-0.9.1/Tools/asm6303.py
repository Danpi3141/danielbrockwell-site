#!/usr/bin/env python3
"""Small two-pass assembler for the Hitachi HD6303X (Psion Organiser II).

Syntax (Motorola style):

    label:  ldaa  #$10        ; comment
    .loop:  staa  3,x         ; a label starting with '.' is local to the last global label
            ldab  count       ; direct page when the address is absolute and < $100
            jsr   draw
            os    DP$EMIT     ; SWI + service number
    name    =     expr        ; or: name equ expr
            org   expr
            seg   code|state|abs
            fcb   1,2,"text"
            fdb   label, $1234
            rmb   n
            lbeq  far         ; long conditional branch (inverse branch over a jmp)

Relocation: symbols defined in `seg code` or `seg state` are relocatable. Every 16-bit
operand that depends on one is recorded in a fix-up list (the offset of its high byte),
so a loader can add the run-time base address. 8-bit operands must be absolute.
"""
import re
import sys

INH = {
    'nop': 0x01, 'lsrd': 0x04, 'asld': 0x05, 'tap': 0x06, 'tpa': 0x07, 'inx': 0x08, 'dex': 0x09,
    'clv': 0x0A, 'sev': 0x0B, 'clc': 0x0C, 'sec': 0x0D, 'cli': 0x0E, 'sei': 0x0F, 'sba': 0x10,
    'cba': 0x11, 'tab': 0x16, 'tba': 0x17, 'xgdx': 0x18, 'daa': 0x19, 'slp': 0x1A, 'aba': 0x1B,
    'tsx': 0x30, 'ins': 0x31, 'pula': 0x32, 'pulb': 0x33, 'des': 0x34, 'txs': 0x35, 'psha': 0x36,
    'pshb': 0x37, 'pulx': 0x38, 'rts': 0x39, 'abx': 0x3A, 'rti': 0x3B, 'pshx': 0x3C, 'mul': 0x3D,
    'wai': 0x3E, 'swi': 0x3F,
    'nega': 0x40, 'coma': 0x43, 'lsra': 0x44, 'rora': 0x46, 'asra': 0x47, 'asla': 0x48, 'rola': 0x49,
    'deca': 0x4A, 'inca': 0x4C, 'tsta': 0x4D, 'clra': 0x4F,
    'negb': 0x50, 'comb': 0x53, 'lsrb': 0x54, 'rorb': 0x56, 'asrb': 0x57, 'aslb': 0x58, 'rolb': 0x59,
    'decb': 0x5A, 'incb': 0x5C, 'tstb': 0x5D, 'clrb': 0x5F,
}
BRANCH = {
    'bra': 0x20, 'brn': 0x21, 'bhi': 0x22, 'bls': 0x23, 'bcc': 0x24, 'bhs': 0x24, 'bcs': 0x25, 'blo': 0x25,
    'bne': 0x26, 'beq': 0x27, 'bvc': 0x28, 'bvs': 0x29, 'bpl': 0x2A, 'bmi': 0x2B, 'bge': 0x2C,
    'blt': 0x2D, 'bgt': 0x2E, 'ble': 0x2F, 'bsr': 0x8D,
}
INVERSE = {'beq': 'bne', 'bne': 'beq', 'bcc': 'bcs', 'bcs': 'bcc', 'bhs': 'blo', 'blo': 'bhs',
           'bhi': 'bls', 'bls': 'bhi', 'bpl': 'bmi', 'bmi': 'bpl', 'bge': 'blt', 'blt': 'bge',
           'bgt': 'ble', 'ble': 'bgt', 'bvc': 'bvs', 'bvs': 'bvc'}
# memory operations: indexed opcode (extended = +0x10)
MEM = {'neg': 0x60, 'com': 0x63, 'lsr': 0x64, 'ror': 0x66, 'asr': 0x67, 'asl': 0x68, 'rol': 0x69,
       'dec': 0x6A, 'inc': 0x6C, 'tst': 0x6D, 'jmp': 0x6E, 'clr': 0x6F}
# bit operations with an immediate: "aim #mask,addr" (direct 0x7n / indexed 0x6n)
BITIMM = {'aim': 0x01, 'oim': 0x02, 'eim': 0x05, 'tim': 0x0B}
# accumulator / register operations: immediate opcode; dir +0x10, idx +0x20, ext +0x30
REG = {
    'suba': (0x80, 1), 'cmpa': (0x81, 1), 'sbca': (0x82, 1), 'subd': (0x83, 2), 'anda': (0x84, 1),
    'bita': (0x85, 1), 'ldaa': (0x86, 1), 'staa': (0x87, 0), 'eora': (0x88, 1), 'adca': (0x89, 1),
    'oraa': (0x8A, 1), 'adda': (0x8B, 1), 'cpx': (0x8C, 2), 'jsr': (0x8D, 0), 'lds': (0x8E, 2),
    'sts': (0x8F, 0),
    'subb': (0xC0, 1), 'cmpb': (0xC1, 1), 'sbcb': (0xC2, 1), 'addd': (0xC3, 2), 'andb': (0xC4, 1),
    'bitb': (0xC5, 1), 'ldab': (0xC6, 1), 'stab': (0xC7, 0), 'eorb': (0xC8, 1), 'adcb': (0xC9, 1),
    'orab': (0xCA, 1), 'addb': (0xCB, 1), 'ldd': (0xCC, 2), 'std': (0xCD, 0), 'ldx': (0xCE, 2),
    'stx': (0xCF, 0),
}

SERVICES = {
    'BZ$TONE': 15, 'BZ$BELL': 14, 'DP$EMIT': 16, 'DP$PRNT': 17, 'DP$STAT': 20, 'KB$BREK': 70,
    'KB$FLSH': 71, 'KB$GETK': 72, 'KB$TEST': 75, 'DP$CSET': 131, 'DP$MSET': 130, 'DP$UDG': 133,
}


class AsmError(Exception):
    pass


class Assembler:
    def __init__(self, source, code_base=0, state_base=0, name='<asm>'):
        self.lines = source.split('\n')
        self.name = name
        self.bases = {'code': code_base, 'state': state_base, 'abs': 0}
        self.sym = {}            # name -> (value without base, segment)
        self.out = bytearray()
        self.fix = {'code': [], 'state': []}
        self.listing = []

    # ---- expressions ----
    def _tokens(self, expr, scope):
        def repl_ident(m):
            n = m.group(0)
            if n.startswith('.'):
                n = scope + n
            return 'S[%r]' % n
        e = expr
        e = re.sub(r"'(.)'", lambda m: str(ord(m.group(1))), e)
        e = re.sub(r'\$([0-9A-Fa-f]+)', lambda m: str(int(m.group(1), 16)), e)
        e = re.sub(r'%([01]+)', lambda m: str(int(m.group(1), 2)), e)
        e = re.sub(r'(?<![\w.\]])\.?[A-Za-z_][\w.]*', repl_ident, e)
        return e.replace('/', '//')

    def eval(self, expr, scope, final):
        """Returns (value, segment). Unknown symbols give (None, 'abs') unless final."""
        e = self._tokens(expr.strip(), scope)
        used = re.findall(r"S\['([^']+)'\]", e)
        for n in used:
            if n not in self.sym:
                if final:
                    raise AsmError('undefined symbol %s' % n)
                return None, 'unknown'

        def val(extra):
            tab = {n: self.sym[n][0] + self.bases[self.sym[n][1]] + extra.get(self.sym[n][1], 0) for n in used}
            try:
                return eval(e, {'__builtins__': {}}, {'S': tab})
            except Exception as ex:
                raise AsmError('bad expression %r: %s' % (expr, ex))
        v = val({})
        seg = 'abs'
        for s in ('code', 'state'):
            d = val({s: 0x100}) - v
            if d == 0x100:
                if seg != 'abs':
                    raise AsmError('expression mixes segments: %r' % expr)
                seg = s
            elif d != 0:
                raise AsmError('expression not relocatable: %r' % expr)
        return v, seg

    # ---- passes ----
    def assemble(self):
        for final in (False, True):
            self.pc = 0
            self.seg = 'code'
            self.out = bytearray()
            self.fix = {'code': [], 'state': []}
            self.listing = []
            self.scope = ''
            self.pcs = {'code': 0, 'state': 0, 'abs': 0}
            for no, raw in enumerate(self.lines, 1):
                try:
                    self.line(raw, final)
                except AsmError as ex:
                    raise AsmError('%s:%d: %s\n    %s' % (self.name, no, ex, raw.strip()))
        return self

    def emit(self, data, raw):
        if self.seg != 'code':
            raise AsmError('code or data outside the code segment')
        if self.pc != len(self.out):
            raise AsmError('internal: pc out of step')
        self.listing.append((self.pc, bytes(data), raw))
        self.out += bytes(data)
        self.pc += len(data)

    def word(self, v, seg, at):
        """16-bit value at offset `at` from the instruction start; records fix-ups."""
        if seg in self.fix:
            self.fix[seg].append(self.pc + at)
        v &= 0xFFFF
        return [v >> 8, v & 255]

    def byte(self, v, seg, what):
        if seg not in ('abs', 'unknown'):
            raise AsmError('%s must not be relocatable' % what)
        if v is None:
            return 0
        if not -128 <= v <= 255:
            raise AsmError('%s out of range: %d' % (what, v))
        return v & 255

    def line(self, raw, final):
        text = raw
        # strip comment (not inside quotes)
        m = re.match(r'^((?:[^;"\']|"[^"]*"|\'.\')*)', text)
        text = m.group(1).rstrip()
        if not text.strip():
            return
        label = None
        m = re.match(r'^(\.?[A-Za-z_][\w.]*):?\s*(.*)$', text) if not text[0].isspace() else None
        if m:
            label, rest = m.group(1), m.group(2)
        else:
            rest = text.strip()
            m2 = re.match(r'^(\.?[A-Za-z_][\w.]*):\s*(.*)$', rest)
            if m2:
                label, rest = m2.group(1), m2.group(2)
        parts = rest.split(None, 1)
        op = parts[0].lower() if parts else ''
        arg = parts[1].strip() if len(parts) > 1 else ''

        if op in ('=', 'equ'):
            v, seg = self.eval(arg, self.scope, final)
            if v is None:
                raise AsmError('equ needs a known value')
            self.define(label, v - self.bases.get(seg, 0), seg, final)
            return
        if label:
            if not label.startswith('.'):
                self.scope = label
            self.define(label, self.pc, self.seg, final)
        if not op:
            return
        if op == 'seg':
            self.pcs[self.seg] = self.pc
            self.seg = arg.lower()
            self.pc = self.pcs[self.seg]
            return
        if op == 'org':
            v, seg = self.eval(arg, self.scope, True)
            if self.seg == 'code':
                if v < self.pc:
                    raise AsmError('org moves backwards')
                self.emit(bytes(v - self.pc), raw)
            else:
                self.pc = v
            return
        if op == 'rmb':
            v, seg = self.eval(arg, self.scope, True)
            if self.seg == 'code':
                self.emit(bytes(v), raw)
            else:
                self.pc += v
            return
        if op == 'fcb':
            data = []
            for item in split_args(arg):
                if item.startswith('"'):
                    data += list(item[1:-1].encode('latin-1'))
                else:
                    v, seg = self.eval(item, self.scope, final)
                    data.append(self.byte(v, seg, 'fcb value'))
            self.emit(data, raw)
            return
        if op == 'fdb':
            data = []
            for item in split_args(arg):
                v, seg = self.eval(item, self.scope, final)
                data += self.word(v or 0, seg, len(data))
            self.emit(data, raw)
            return
        if op == 'os':
            if arg not in SERVICES:
                raise AsmError('unknown service %s' % arg)
            self.emit([0x3F, SERVICES[arg]], raw)
            return
        if op in INH:
            if arg:
                raise AsmError('%s takes no operand' % op)
            self.emit([INH[op]], raw)
            return
        if op in BRANCH:
            v, seg = self.eval(arg, self.scope, final)
            off = 0
            if final:
                off = v - self.bases[self.seg] - (self.pc + 2) if seg == self.seg else None
                if off is None:
                    raise AsmError('branch to another segment')
                if not -128 <= off <= 127:
                    raise AsmError('branch out of range (%d); use l%s' % (off, op))
            self.emit([BRANCH[op], off & 255], raw)
            return
        if op.startswith('l') and op[1:] in INVERSE:
            v, seg = self.eval(arg, self.scope, final)
            self.emit([BRANCH[INVERSE[op[1:]]], 3, 0x7E] + self.word(v or 0, seg if final else 'abs', 3), raw)
            return
        if op in BITIMM:
            a = split_args(arg)
            if len(a) < 2 or not a[0].startswith('#'):
                raise AsmError('%s needs #mask,address' % op)
            mv, ms = self.eval(a[0][1:], self.scope, final)
            mask = self.byte(mv, ms, 'mask')
            if len(a) == 3 and a[2].lower() == 'x':
                v, seg = self.eval(a[1], self.scope, final)
                self.emit([0x60 + BITIMM[op], mask, self.byte(v, seg, 'index offset')], raw)
            else:
                v, seg = self.eval(a[1].lstrip('<'), self.scope, final)
                self.emit([0x70 + BITIMM[op], mask, self.byte(v, seg, 'direct address')], raw)
            return
        if op in MEM or op in REG:
            mode, expr = self.operand(arg)
            v, seg = self.eval(expr, self.scope, final)
            if op in MEM:
                base = MEM[op]
                if mode == 'imm':
                    raise AsmError('%s cannot be immediate' % op)
                if mode == 'idx':
                    self.emit([base, self.byte(v, seg, 'index offset')], raw)
                else:
                    self.emit([base + 0x10] + self.word(v or 0, seg, 1), raw)
                return
            base, immsize = REG[op]
            if mode == 'imm':
                if immsize == 0:
                    raise AsmError('%s cannot be immediate' % op)
                if immsize == 1:
                    self.emit([base, self.byte(v, seg, 'immediate')], raw)
                else:
                    self.emit([base] + self.word(v or 0, seg, 1), raw)
            elif mode == 'idx':
                self.emit([base + 0x20, self.byte(v, seg, 'index offset')], raw)
            elif mode == 'dir' or (mode == 'auto' and seg == 'abs' and v is not None and 0 <= v < 0x100):
                self.emit([base + 0x10, self.byte(v, seg, 'direct address')], raw)
            else:
                self.emit([base + 0x30] + self.word(v or 0, seg, 1), raw)
            return
        raise AsmError('unknown instruction %s' % op)

    def operand(self, arg):
        if not arg:
            raise AsmError('operand missing')
        if arg.startswith('#'):
            return 'imm', arg[1:]
        m = re.match(r'^(.*),\s*[xX]$', arg)
        if m:
            return 'idx', m.group(1).strip() or '0'
        if arg.startswith('<'):
            return 'dir', arg[1:]
        if arg.startswith('>'):
            return 'ext', arg[1:]
        return 'auto', arg

    def define(self, label, value, seg, final):
        if label is None:
            raise AsmError('label missing')
        name = self.scope + label if label.startswith('.') else label
        if not final:
            if name in self.sym:
                raise AsmError('duplicate symbol %s' % name)
            self.sym[name] = (value, seg)
        elif self.sym[name] != (value, seg):
            raise AsmError('phase error at %s (%r -> %r)' % (name, self.sym[name], (value, seg)))

    def symbols(self):
        return {n: {'value': v, 'seg': s} for n, (v, s) in self.sym.items()}

    def listing_text(self):
        out = []
        for pc, data, raw in self.listing:
            hx = data.hex().upper()
            out.append('%04X  %-12s %s' % (pc, hx[:12], raw.rstrip()))
            for i in range(12, len(hx), 12):
                out.append('      %-12s' % hx[i:i + 12])
        return '\n'.join(out)


def split_args(arg):
    out, cur, q = [], '', None
    for ch in arg:
        if q:
            cur += ch
            if ch == q:
                q = None
        elif ch in '"\'':
            q = ch
            cur += ch
        elif ch == ',':
            out.append(cur.strip())
            cur = ''
        else:
            cur += ch
    if cur.strip():
        out.append(cur.strip())
    return out


def assemble(source, code_base=0, state_base=0, name='<asm>'):
    return Assembler(source, code_base, state_base, name).assemble()


if __name__ == '__main__':
    src = open(sys.argv[1], encoding='utf-8').read()
    try:
        a = assemble(src, name=sys.argv[1])
    except AsmError as ex:
        sys.exit(str(ex))
    print(a.listing_text())
    print('; %d bytes, %d code fix-ups, %d state fix-ups' % (len(a.out), len(a.fix['code']), len(a.fix['state'])))
