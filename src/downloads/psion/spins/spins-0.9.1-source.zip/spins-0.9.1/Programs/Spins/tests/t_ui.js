// The screens: title, menu, settings, pay table, lines, statistics, help, jukebox, scenes.
//   node tests/t_ui.js [model]
const { Game } = require('./lib');
const model = process.argv[2] || 'lz64';
const g = new Game(model, {});
const show = (what) => console.log(`--- ${what}\n` + g.scr().join('\n'));
g.m.runProc('SANTA', 'B');
g.run(1.5); show('title (1.5 s)');
g.start(20, false);
show('rest');
const key = (k, s = 0.4) => { g.press(k); g.run(s); };
key('MODE'); show('menu');
key('DOWN'); key('DOWN'); show('menu, two down');
key('ON');
key('P'); show('pay table p1');
key('DOWN'); show('pay table p2');
for (let i = 0; i < 9; i++) key('DOWN');
show('pay table (rules)');
key('ON');
key('L'); show('lines 1'); key('DOWN'); show('line 2'); key('ON');
key('S'); show('stats'); key('ON');
key('MODE'); key('S'); key('S'); key('EXE'); show('settings'); key('EXE'); show('settings: animation changed'); key('ON', 1);
console.log('anim now', g.peek('kv_anim'));
key('MODE'); key('H'); key('EXE'); show('help'); key('ON');
key('MODE'); key('J'); key('EXE'); show('jukebox'); key('EXE', 1.0); show('playing'); key('ON'); key('ON');
key('MODE'); key('S'); key('S'); key('S'); key('EXE'); show('scenes list');
key('EXE', 3); show('scene 0 replay at 3 s');
g.run(10); show('after');
