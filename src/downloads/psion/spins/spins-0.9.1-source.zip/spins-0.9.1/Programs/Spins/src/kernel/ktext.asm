; ---------------------------------------------------------------------
; Text and numbers into the screen model (kv_under)
; ---------------------------------------------------------------------

; txt_at: X = a string with a leading length, B = the first cell
txt_at: stab kv_t3
        ldab 0,x
        beq  .x
        stab kv_t3+1
.l:     inx
        ldaa 0,x
        ldab kv_t3
        pshx
        jsr  put
        pulx
        inc  kv_t3
        dec  kv_t3+1
        bne  .l
.x:     rts

; txt_s: B = the first cell; the string after the call (leading length)
txt_s:  pulx
        pshx
        bsr  txt_at
        pulx                    ; on past the string
        ldab 0,x
        incb
        abx
        jmp  0,x

; num_dec: X = a 4-byte number (high byte first): kv_nb holds it in
; decimal, 10 characters, leading spaces (0 is "         0"). Digits from
; the right: the number divided by 10 until nothing is left.
num_dec:
        ldd  0,x
        std  kv_n
        ldd  2,x
        std  kv_n+2
        ldx  #kv_nb+10
.d:     clra                    ; kv_n / 10: the remainder in A
        ldab #32
.b:     asl  kv_n+3
        rol  kv_n+2
        rol  kv_n+1
        rol  kv_n
        rola
        cmpa #10
        blo  .n
        suba #10
        inc  kv_n+3             ; (a quotient bit)
.n:     decb
        bne  .b
        adda #'0'
        dex
        staa 0,x
        ldd  kv_n
        bne  .d
        ldd  kv_n+2
        bne  .d
        ldaa #' '               ; spaces before it
.s:     cpx  #kv_nb
        beq  .x
        dex
        staa 0,x
        bra  .s
.x:     rts

; num_at: X = a 4-byte number, A = field width (1-10), B = first cell:
; the number right-justified in the field
num_at: pshb
        psha
        bsr  num_dec
        ldd  #kv_nb+9           ; the field's last width characters, a
        tsx                     ; length byte before them (kv_nbl at most)
        subb 0,x
        sbca #0
        xgdx
        pula
        staa 0,x
        pulb
        jmp  txt_at

; set32: D = a 16-bit number: X = kv_n32 holding it (for num_at)
set32:  std  kv_n32+2
        clr  kv_n32
        clr  kv_n32+1
        ldx  #kv_n32
        rts

; pn_text: A = panel line 0-3, X = a string (length first): the line,
; padded with spaces to the panel's 10 characters. On two lines line 0
; is the top line and the others share the bottom one.
pn_text:
        stx  kv_t2
        jsr  pn_cell
        stab kv_t3              ; the first cell
        ldx  kv_t2
        ldaa 0,x
        staa kv_t3+1            ; characters left in the string
        ldaa #10
        staa kv_t1              ; cells left
.l:     ldaa #' '
        tst  kv_t3+1
        beq  .p
        dec  kv_t3+1
        ldx  kv_t2
        inx
        stx  kv_t2
        ldaa 0,x
.p:     ldab kv_t3
        jsr  put
        inc  kv_t3
        dec  kv_t1
        bne  .l
        rts

; pn_cell: A = panel line: B = its first cell
pn_cell:
        tst  kv_four
        bne  .f
        tsta
        beq  .t
        ldaa #1
.t:     ldab #16
        mul
        addb #6
        rts
.f:     ldab #20
        mul
        addb #10
        rts
