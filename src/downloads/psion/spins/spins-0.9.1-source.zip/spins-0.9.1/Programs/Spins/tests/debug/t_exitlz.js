const { Game } = require('../lib');
const g = new Game('lz64');
console.log('before:\n' + g.text());
g.m.press('P',3,10); g.run(0.5); console.log('prog:\n'+g.text()); g.m.press('ON',3,10); g.run(0.5);
g.start(); g.run(1); g.press('EXE'); g.run(2);
console.log('after:\n' + g.text());
g.m.press('ON',3,10); g.run(2);
console.log('after ON:\n' + g.text());
console.log('clock var', g.m.peek(0x2095).toString(16), 'mode', g.m.peek(0x2184));
