// One play through the whole flow, forced to a kind of spin: santa | feature | win | any
//   node tests/t_flow.js [model] [kind] [stepms]
const { Game } = require('./lib');
const model = process.argv[2] || 'lz64';
const kind = process.argv[3] || 'feature';
const step = +(process.argv[4] || 500) / 1000;
const g = new Game(model);
g.start();
const pred = { santa: (b) => b.santa && b.houses >= 1 && !b.freeSpins, feature: (b) => b.freeSpins > 0,
  win: (b) => b.total >= 20 && !b.santa, any: () => true }[kind];
const seed = g.seedFor(pred, 1000);
const R = require('../ref/game.js');
const G = R.grid(g.m.lines === 4 ? 'four' : 'two');
const p = R.play(G, new R.Rng(seed));
console.log('seed', seed, 'ref: base', p.base.total, 'lines', p.base.wins.length, 'feature', p.feature ? p.feature.count + ' spins ' + p.feature.total : '-', 'total', p.total);
const W = g.m.cols;
const shots = [];
const t = g.spin(seed, step, (t) => shots.push([t, g.scr()]));
for (let i = 0; i < shots.length; i += 4) {
  const part = shots.slice(i, i + 4);
  for (let y = 0; y < g.m.lines; y++) console.log(part.map(([, s]) => s[y]).join(' | '));
  console.log(part.map(([t]) => t.toFixed(1).padEnd(W)).join(' | ') + '\n');
}
const bal = g.peek32('kv_bal'), dbal = g.peek32('kv_dbal');
console.log(`took ${t.toFixed(1)} s; balance ${bal} (shown ${dbal}); expected ${1000 - 20 + p.total}`);
console.log(g.scr().join('\n'));
process.exit(bal === dbal && bal === 1000 - 20 + p.total ? 0 : 1);
