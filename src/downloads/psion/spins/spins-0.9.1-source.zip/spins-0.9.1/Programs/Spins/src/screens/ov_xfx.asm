; =====================================================================
; OV_XFX: Xmas Spins. Entry 0: after a free spin, if a house shows,
; Santa throws from reel 1: a present (glyph 6) flies along his row and
; the houses become presents as it reaches the first of them. Entry 1:
; before a free spin, the panel's "XMAS n/m".
; =====================================================================
        include "../defs.inc"

P_STAND = 0                     ; the XFX blob: poses
P_THROW1 = 1
P_THROW2 = 2
A_PRESENT = 0                   ; art: the present, the change
A_CH1   = 1
E_THROW = 0                     ; effects
E_PRESENT = 1
E_CHANGE = 2
E_TICK  = 3
A_ELF   = 4

        jmp  xf_throw
        jmp  xf_panel

xf_throw:
        clr  xf_hc              ; the first column with a house ($FF none)
        dec  xf_hc
        ldaa #1
        staa xf_r
.r:     ldaa xf_r
        asla
        asla
        tab
        ldx  #kv_grid
        abx
        ldab kv_rows
.y:     ldaa 0,x
        cmpa #8
        beq  .h
        inx
        decb
        bne  .y
        inc  xf_r
        ldaa xf_r
        cmpa #5
        bne  .r
        rts                     ; no house: no throw
.h:     ldx  #kv_reelx
        ldab xf_r
        abx
        ldaa 0,x
        staa xf_hc
        ldaa #IT_XFX
        ldx  #xf_data
        stx  kv_scene
        jsr  pk_load
        tst  kv_anim
        bne  .go
        ldaa #A_CH1+2           ; Off: the houses change at once
        bra  xf_art3
.go:    ldaa #P_THROW1          ; arm back
        bsr  xf_pose
        ldaa #6
        jsr  frame
        ldaa #P_THROW2          ; and forward: the present goes
        bsr  xf_pose
        ldaa #E_THROW
        bsr  xf_fx
        ldaa #A_PRESENT
        ldab #2
        jsr  sc_tab
        ldaa #6
        jsr  glyph_ld
        clr  xf_k               ; (the change's step)
        ldaa #1                 ; the present's row: Santa's upper one
        tst  kv_four
        bne  .rw
        clra
.rw:    ldab kv_w
        mul
        stab xf_row
        ldaa #1                 ; from the column after reel 1 to reel 5
        staa xf_c
.f:     ldab xf_row
        addb xf_c
        stab xf_cell
        ldx  #kv_under
        abx
        ldaa 0,x
        staa xf_save
        ldaa #6
        jsr  put
        ldaa xf_c               ; at the first house's column, the change begins
        cmpa xf_hc
        blo  .n
        ldaa xf_k
        cmpa #3
        beq  .n
        bne  .ch
.ch:    tst  xf_k
        bne  .cs
        ldaa #E_CHANGE
        bsr  xf_fx
.cs:    ldaa xf_k
        adda #A_CH1
        bsr  xf_art3
        inc  xf_k
.n:     ldaa #4
        jsr  frame
        ldaa xf_save
        ldab xf_cell
        jsr  put
        inc  xf_c
        ldx  #kv_reelx+4
        ldaa 0,x
        cmpa xf_c
        bhs  .f
.fin:   ldaa xf_k               ; (any steps left of the change)
        cmpa #3
        beq  .st
        adda #A_CH1
        bsr  xf_art3
        inc  xf_k
        bra  .fin
.st:    ldaa #P_STAND
        bsr  xf_pose
        ldaa #6
        jsr  frame
; the elf helper (stretch goal): along the bottom row, collecting the
; presents (each sparkles as it passes, with a tick)
        ldaa kv_rows            ; the bottom row
        deca
        ldab kv_w
        mul
        stab xf_row
        ldaa #1
        staa xf_c
.e:     ldab xf_row
        addb xf_c
        stab xf_cell
        ldx  #kv_under
        abx
        ldaa 0,x
        staa xf_save
        cmpa #3                 ; a present: collected
        bne  .run
        ldaa #E_TICK
        jsr  xf_fx
.run:   ldaa xf_c               ; the elf: its two frames in turn (glyph 7)
        anda #1
        adda #A_ELF
        ldab #2
        jsr  sc_tab
        ldaa #7
        jsr  glyph_ld
        ldaa #7
        ldab xf_cell
        jsr  put
        ldaa #5
        jsr  frame
        ldaa xf_save            ; behind it, presents sparkle once
        cmpa #3
        bne  .rs
        ldaa #'*'
.rs:    ldab xf_cell
        jsr  put
        inc  xf_c
        ldx  #kv_reelx+4
        ldaa 0,x
        inca
        cmpa xf_c
        bhs  .e
        ldaa #6
        jsr  frame
        ldab #1                 ; the presents back (the sparkles out)
.b:     stab xf_c
        ldab xf_row
        addb xf_c
        ldx  #kv_under
        abx
        ldaa 0,x
        cmpa #'*'
        bne  .bn
        ldaa #3
        staa 0,x
        inc  kv_cdirty
.bn:    ldab xf_c
        incb
        cmpb #10
        bne  .b
        ldaa #4
        jmp  frame

; A = art: glyph 3 (the house) becomes it
xf_art3:
        ldab #2
        jsr  sc_tab
        ldaa #3
        jmp  glyph_ld
; A = a pose: Santa in glyphs 4 and 5
xf_pose:
        clrb
        jsr  sc_tab
        jsr  pose_unpack
        ldaa #4
        ldx  #kv_pose
        jsr  glyph_ld
        ldaa #5
        ldx  #kv_pose+8
        jmp  glyph_ld
; A = an effect of the blob
xf_fx:  ldab #6
        jsr  sc_tab
        jmp  snd_fx

; entry 1: the panel's Xmas line, "XMAS n/m"
xf_panel:
        ldx  #xf_buf+1
        stx  xf_p
        ldx  #xf_sx
        ldab #5
.s:     ldaa 0,x
        bsr  .ch
        inx
        decb
        bne  .s
        ldab kv_fidx
        bsr  .num
        ldaa #'/'
        bsr  .ch
        ldab kv_fsofar
        bsr  .num
        ldd  xf_p
        subd #xf_buf+1
        stab xf_buf
        ldaa #1
        ldx  #xf_buf
        jmp  pn_text
.num:   clra                    ; B in decimal
        jsr  set32
        jsr  num_dec
        ldx  #kv_nb+7
.ns:    ldaa 0,x
        cmpa #' '
        bne  .nd
        inx
        bra  .ns
.nd:    ldaa 0,x
        bsr  .ch
        inx
        cpx  #kv_nb+10
        bne  .nd
        rts
.ch:    pshx
        ldx  xf_p
        staa 0,x
        inx
        stx  xf_p
        pulx
        rts
xf_sx:  fcc  "XMAS "

xf_r:   fcb  0
xf_hc:  fcb  0
xf_k:   fcb  0
xf_c:   fcb  0
xf_row: fcb  0
xf_cell: fcb 0
xf_save: fcb 0
xf_p:   fdb  0
xf_buf: rmb  11
xf_data:                        ; the blob, read in here
