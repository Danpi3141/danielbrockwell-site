; =====================================================================
; OV_MENU: the menu, autoplay's count, and the questions before leaving
; and before a new player. Each entry returns A = the next command.
; =====================================================================
        include "../defs.inc"

        jmp  om_menu            ; C_MENU
        jmp  om_auto            ; C_AUTO
        jmp  om_leave           ; C_LEAVE
        jmp  om_new             ; C_NEW

om_menu:
        clr  ls_lr
        clra
        ldx  #om_list
        jsr  ls_run
        bcs  .back
        ldx  #om_cmds
        abx
        ldaa 0,x
        cmpa #$FF               ; Bet: chosen here
        beq  om_bet
        cmpa #C_SPIN            ; a spin straight away: the list cleared
        bne  .r                 ; first (the spin redraws only the reels and
        jsr  cls                ; the panel, not the gaps between them)
        ldaa #C_SPIN
.r:     rts
.back:  clra
        rts
om_list: fcl "MENU"
        fcb  12
        fcl  "Spin"
        fcl  "Bet"
        fcl  "Autoplay"
        fcl  "Pay table"
        fcl  "Lines"
        fcl  "Statistics"
        fcl  "Settings"
        fcl  "Jukebox"
        fcl  "Scenes"
        fcl  "Help"
        fcl  "New player"
        fcl  "Quit"
om_cmds: fcb C_SPIN,$FF,C_AUTO,C_PAYS,C_LINES,C_STATS,C_SET,C_JUKE,C_SCENES,C_HELP,C_NEW,C_LEAVE

; the line bet: 1, 2, 5 or 10
om_bet: ldaa kv_bet
        ldx  #om_bets
        jsr  ls_run
        bcs  .x
        stab kv_bet
.x:     clra
        rts
om_bets: fcl "LINE BET"
        fcb  4
        fcl  "1 (20 a spin)"
        fcl  "2 (40 a spin)"
        fcl  "5 (100 a spin)"
        fcl  "10 (200 a spin)"

; autoplay: a count, then the first spin
om_auto:
        clra
        ldx  #om_alist
        jsr  ls_run
        bcs  .x
        ldx  #om_acnt
        abx
        ldaa 0,x
        staa kv_auto
        ldx  #om_aon
        jsr  snd_fx
        ldaa #10
        jsr  frame_t
        jsr  cls                ; (the list cleared: see om_menu)
        ldaa #C_SPIN
        rts
.x:     clra
        rts
om_alist: fcl "AUTOPLAY"
        fcb  4
        fcl  "10 spins"
        fcl  "25 spins"
        fcl  "50 spins"
        fcl  "Until Xmas"
om_acnt: fcb 10,25,50,255
om_aon: fcb  1,3,32,1, 1,3,36,1, 1,6,39,1, $FF

; ON at the reels: leave? (saved, then the goodbye)
om_leave:
        ldx  #om_lq
        bsr  om_ask
        ldaa #C_QUIT
        bcc  .x
        clra
.x:     rts
om_lq:  fcl  "Leave? EXE=yes"

; a new player: the credits and statistics start again
om_new: ldx  #om_nq
        bsr  om_ask
        ldaa #C_BANKNEW
        bcc  .x
        clra
.x:     rts
om_nq:  fcl  "New player? EXE"

; X = a question: carry clear if EXE answers it
om_ask: pshx
        jsr  cls
        pulx
        clrb
        jsr  txt_at
        clra
        jsr  key_wait
        cmpb #K_EXE
        beq  .y
        sec
        rts
.y:     clc
        rts

        include "list.inc"
