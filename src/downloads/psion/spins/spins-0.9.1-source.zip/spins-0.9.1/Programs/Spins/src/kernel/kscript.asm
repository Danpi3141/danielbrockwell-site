; ---------------------------------------------------------------------
; The script reader. A blob (a scene, a walk, a set of cues) is read into
; the scene buffer: a header of six words, offsets from the blob's start
; to its tables: poses (10 bytes each, packed), art (8 bytes each), then offset
; tables for tunes, effects, cels and scripts. sc_play runs a script
; until END, a frame at a time; a key ends it at once (carry set).
;
; Commands (tools/script.py assembles them; only those the scenes use):
;  0 END            1 FRAME t        2 TUNE n ($FF stop)  3 EFFECT n
;  4 LOOP n         5 AGAIN          6 CALL off (word)    7 BACK
;  8 PICK n,off...  9 IF2 len       10 IF4 len           11 HOOK n
; 12 JUMP off (word)
; 13-16 stage commands, passed to the director's stage handler
;       (kv_stage): 13 CEL n,x,y  14 WIPE  15 WINDOW shape,col,row
;       16 SLIDE dc
; 17 NOKEY (keys no longer end it)  18 TXT col,row,len,chars
; A command's handler returns to the loop; only END and a key end the
; script (they leave through the loop's return address).
; ---------------------------------------------------------------------
SC_LAST = 18

; sc_play: A = script number (in the blob at SCENE): run it.
; Out: carry set if a key ended it.
sc_play:
        ldab #10                ; the scripts' table: the header's 6th word
        jsr  sc_tab
        stx  kv_ip
        clr  kv_sdep            ; no loops or calls yet
        clr  kv_nokey
sc_next:
        bsr  sc_arg
        cmpa #SC_LAST
        bhi  sc_end             ; (a bad command ends it)
        asla
        tab
        ldx  #sc_tab_cmds
        abx
        ldx  0,x
        jsr  0,x
        bra  sc_next
sc_end: sec
        rts

c_end:  pulx                    ; the end: out of sc_play, carry clear
        clc
        rts

c_frame:
        bsr  sc_arg
        jsr  frame
        tst  kv_nokey
        bne  .ok
        tst  kv_key
        bne  .stop
.ok:    rts
.stop:  pulx                    ; a key: out of sc_play, carry set
        sec
        rts

c_tune: bsr  sc_arg             ; a tune item number (tools/script.py), or
        cmpa #$FF               ; $FF: stop
        bne  .t
        clr  kv_tnt
        rts
.t:     ldab #4                 ; the blob's tunes table holds item numbers
        jsr  sc_item
        jmp  tune_go
c_effect:
        bsr  sc_arg
        ldab #6
        jsr  sc_tab
        jmp  snd_fx
; LOOP n: push the count and where the section starts
c_loop: bsr  sc_arg
        bra  sc_push
c_again:
        bsr  sc_top             ; the top entry: count, address
        dec  0,x
        beq  sc_pop
        ldx  1,x
        stx  kv_ip
        rts
; CALL off: push a return (count 0), go there
c_call: bsr  sc_word
        pshx
        clra
        bsr  sc_push
        pulx
        stx  kv_ip
        rts
c_back: bsr  sc_top
        ldx  1,x
        stx  kv_ip
        bra  sc_pop
c_jump: bsr  sc_word
        stx  kv_ip
        rts
; a byte argument: A = the next byte
sc_arg: ldx  kv_ip
        ldaa 0,x
        inx
        stx  kv_ip
        rts

; a word argument: X = SCENE + it
sc_word:
        ldx  kv_ip
        ldd  0,x
        inx
        inx
        stx  kv_ip
        addd kv_scene
        xgdx
        rts

; push A (a count) and kv_ip
sc_push:
        ldx  #kv_sstk
        ldab kv_sdep
        abx
        staa 0,x
        ldd  kv_ip
        std  1,x
        ldaa kv_sdep
        adda #3
        staa kv_sdep
        rts
; X = the stack's top entry
sc_top: ldx  #kv_sstk-3
        ldab kv_sdep
        abx
        rts
sc_pop: ldaa kv_sdep
        suba #3
        staa kv_sdep
        rts

; PICK n, off...: one of n places at random (cosmetic bits only)
c_pick: bsr  sc_arg
        staa kv_t3
        jsr  rng_cos            ; A = a random byte
        ldab kv_t3
.m:     cba                     ; A mod n
        blo  .k
        sba
        bra  .m
.k:     asla
        tab
        bsr  sc_skip
        bra  c_jump
c_if2:  ldab kv_four            ; skip unless two lines
        bra  c_ifs
c_if4:  ldab kv_four            ; skip unless four lines
        eorb #1
c_ifs:  bsr  sc_arg
        tstb
        beq  .x
        tab
        bra  sc_skip
.x:     rts
c_hook: bsr  sc_arg
        ldx  kv_hook
        jmp  0,x
c_txt:  bsr  sc_arg             ; TXT col, row, string
        psha
        bsr  sc_arg
        ldab kv_w
        mul
        pula
        aba
        tab
        ldx  kv_ip
        jsr  txt_at
        ldx  kv_ip              ; past it
        ldab 0,x
        incb
; sc_skip: B bytes of the script skipped
sc_skip:
        ldx  kv_ip
        abx
        stx  kv_ip
        rts
c_nokey:
        inc  kv_nokey
        rts
c_stage:
        ldx  kv_ip              ; A = the command; the handler reads its
        dex                     ; arguments with sc_arg
        ldaa 0,x
        ldx  kv_stage
        jmp  0,x

; sc_tab: A = index, B = header word offset (0 poses, 2 art, 4 tunes,
; 6 effects, 8 cels, 10 scripts): X = the item (poses and art are rows of
; 10 and 8 bytes; the others are found through their offset tables)
sc_tab: stab kv_sct
        staa kv_sci
        ldx  kv_scene
        abx
        ldd  0,x                ; the table's offset in the blob
        addd kv_scene
        std  kv_t0
        ldab kv_sct
        cmpb #4
        bhs  .off
        ldaa kv_sci             ; poses: A * 10, art: A * 8
        ldab #10
        tst  kv_sct
        beq  .m
        ldab #8
.m:     mul
        addd kv_t0
        xgdx
        rts
.off:   ldab kv_sci             ; an offset table: its entry
        aslb
        ldx  kv_t0
        abx
        ldd  0,x
        addd kv_scene
        xgdx
        rts

sc_tab_cmds:
        fdb  c_end, c_frame, c_tune, c_effect, c_loop, c_again, c_call, c_back
        fdb  c_pick, c_if2, c_if4, c_hook, c_jump, c_stage, c_stage, c_stage
        fdb  c_stage, c_nokey, c_txt


; rng_cos: A = a cosmetic random byte (its own state: the game's results
; never depend on what is shown)
rng_cos:
        ldaa kv_cos
        ldab #5                 ; x = 5x + 1 (mod 256), mixed with the timer
        mul
        incb
        eorb FRC+1
        stab kv_cos
        tba
        rts

; tune_go: A = a tune's item: read into the top of the scene buffer, and
; started
tune_go:
        ldx  #TUNEAT
        jsr  pk_load
        jmp  snd_tune

; pose_unpack: X = a pose (10 bytes: 80 dots): kv_pose = its 16 rows
pose_unpack:
        stx  kv_t0
        ldx  #kv_pose
        stx  kv_t1
        clr  kv_t2+1            ; bits left in the byte
        ldab #16
.r:     pshb
        clra                    ; a row: five bits
        ldab #5
.b:     tst  kv_t2+1
        bne  .h
        pshx
        ldx  kv_t0
        psha
        ldaa 0,x
        staa kv_t2
        pula
        inx
        stx  kv_t0
        pulx
        psha
        ldaa #8
        staa kv_t2+1
        pula
.h:     asl  kv_t2
        rola
        dec  kv_t2+1
        decb
        bne  .b
        ldx  kv_t1
        staa 0,x
        inx
        stx  kv_t1
        pulb
        decb
        bne  .r
        rts

; sc_item: A = index, B = header word offset: A = the table's raw entry
; (an item number)
sc_item:
        ldx  kv_scene
        abx
        psha
        ldd  0,x
        addd kv_scene
        xgdx
        pulb
        aslb
        abx
        ldaa 1,x
        rts
