// A spin as a sequence of screens (characters; glyphs as digits), every N ms.
//   node tests/t_spinseq.js [model] [stepms] [totalms] [key...]
const { Game } = require('./lib');
const model = process.argv[2] || 'lz64';
const step = +process.argv[3] || 100, total = +process.argv[4] || 3000;
const g = new Game(model);
g.start();
g.m.keyDown('EXE'); g.m.runTicks(2); g.m.keyUp('EXE');
const rows = [];
for (let t = step; t <= total; t += step) {
  g.run(step / 1000);
  rows.push([t, g.scr()]);
}
console.log('grid', g.gridText());
for (let y = 0; y < g.m.lines; y++) {
  let line = '';
  for (const [t, s] of rows) line += s[y].slice(0, g.m.lines === 4 ? 10 : 6) + ' ';
  console.log(line);
}
console.log(rows.map(([t]) => String(t).padEnd(g.m.lines === 4 ? 10 : 6)).join(' '));
console.log('final:\n' + g.scr().join('\n'));
