// Stretch goals: the advent calendar (a door, three Xmas Spins, paid), New Year, the gamble.
const { Game } = require('./lib');
const model = process.argv[2] || 'lz64';
let bad = 0;
const ok = (c, m) => { console.log((c ? 'ok   ' : 'FAIL ') + m); if (!c) bad++; };
{ // advent: 5 December
  const g = new Game(model);
  g.m.poke(0x20C6, 11); g.m.poke(0x20C7, 4);
  g.m.runProc('SANTA', 'B');
  let sawDoor = false, sawXmas = false;
  for (let i = 0; i < 2400; i++) {
    g.run(0.25);
    const t = g.text();
    if (/ADVENT/.test(t)) sawDoor = true;
    if (/XMAS/.test(t)) sawXmas = true;
    if (sawXmas && g.sync() >= 0 && g.peek('kv_res') === g.ids().OV_REST && g.peek('kv_fleft') === 0) break;
  }
  g.start(20, false);
  ok(sawDoor && sawXmas, `advent: door ${sawDoor}, Xmas Spins ${sawXmas}; credits ${g.peek32('kv_bal')} shown ${g.peek32('kv_dbal')}, door bits ${g.peek('st_door')}`);
  ok(g.peek32('kv_bal') === g.peek32('kv_dbal') && g.peek('st_door') === 16, 'advent paid and the door marked');
}
{ // New Year
  const g = new Game(model);
  g.m.poke(0x20C6, 0); g.m.poke(0x20C7, 0);
  g.m.runProc('SANTA', 'B');
  let saw = false;
  for (let i = 0; i < 120 && !saw; i++) { g.run(0.25); if (/NEW YEAR/.test(g.text())) saw = true; }
  ok(saw, 'New Year scene');
}
{ // the gamble
  const g = new Game(model);
  g.start();
  g.spin(g.seedFor((b) => b.total > 0 && !b.freeSpins && !b.santa, 30), 1);
  const win = g.peek32('kv_win'), bal = g.peek32('kv_bal');
  ok(g.peek('kv_gok') === 1, `a win of ${win}: may be gambled (${g.scr()[3] || g.scr()[1]})`);
  g.press('G'); g.run(1);
  console.log(g.scr().join('\n'));
  g.press('LEFT'); g.run(2);
  console.log(g.scr().join('\n'));
  g.start(20, false);
  const nb = g.peek32('kv_bal');
  ok(nb === bal + win || nb === bal - win, `gamble: credits ${bal} -> ${nb} (win ${win}); shown ${g.peek32('kv_dbal')}`);
  ok(g.peek('kv_gok') === 0, 'once only');
}
process.exit(bad ? 1 : 0);
