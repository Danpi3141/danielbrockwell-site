const { Game } = require('../lib');
const fs = require('fs');
const g = new Game(process.argv[2] || 'lz64');
g.start();
const S = JSON.parse(fs.readFileSync('build/game/ov_spinfx.sym.json'));
const v = (n, k = 0) => g.m.peek(g.base + S[n][0] + k);
const seed = g.seedFor((b) => b.freeSpins > 0, 1000);
let n = 0;
try {
  g.spin(seed, 0.25, (t) => {
    if (t > 1.5 && n++ < 30) console.log(t.toFixed(2), 't', v('sf_t'), 'cur', v('sf_cur'), 'next', v('sf_next'), 'ph', v('sf_ph'), 'row', v('sf_row'), 'inv', v('sf_inv'), 'at', [0,1,2,3,4].map(i=>v('sf_at',i)).join(','), 'st', [0,1,2,3,4].map(i=>v('sf_st',i)).join(','), g.scr()[0].slice(0,10));
  }, 10);
} catch (e) { console.log(e.message); }
