; =====================================================================
; The start-up code: stored after the kernel's code (where the variables
; go), copied into slot A by the kernel's entry and run there once.
; Clears the variables, finds area B, picks the screen driver from the
; model byte (an LZ is switched to four lines), loads the pictures.
; =====================================================================
        include "../defs.inc"

kinit:  pula                    ; D = ADDR(v%()), pushed by the entry
        pulb
        ldx  KR_KEEP            ; SANTA's code must be just above the array and
        cpx  #$847B             ; SANTAG's below it (some variables live in their
        bne  .bad               ; code: kvars.inc), as when SANTA runs SANTAG;
        ldx  KH_KEEP            ; not if SANTAG is run by itself
        cpx  #$9F7F
        beq  .run
.bad:   sts  kv_sp
        clr  kv_four
        ldab #E_RUN
        jmp  quit
.run:   ldx  #KH                ; the holes cleared
.h:     clr  0,x
        inx
        cpx  #KH+KH_LEN
        bne  .h
        ldx  #KR
.r:     clr  0,x
        inx
        cpx  #KR+KR_LEN
        bne  .r
        ldx  #KS
.s:     clr  0,x
        inx
        cpx  #KS+KS_LEN
        bne  .s
        ldx  #kv_first          ; the variables are not on the pack: clear them
.z:     clr  0,x
        inx
        cpx  #kv_end
        bne  .z
        sts  kv_sp              ; (the launcher's return address is on top)
        xgdx
        ldd  0,x
        std  kv_base
        ldaa 4,x
        staa kv_dev
        os   PK$QADD            ; B:X: where the bootstrap stopped reading
        stab kv_bpa             ; SANK: area B
        stx  kv_bpa+1
        os   PK$PKOF

        ldaa #DRV2              ; the model byte: 13, 14, 29, 30 have four lines
        ldab MODEL
        cmpb #13
        beq  .four
        cmpb #14
        beq  .four
        cmpb #29
        beq  .four
        cmpb #30
        bne  .drv
.four:  ldab #$80               ; the clock off (its old state kept)
        os   DP$CSET
        stab kv_oclk
        ldaa #1
        os   DP$MSET            ; four lines; A = the mode it replaced
        staa kv_omode
        inc  kv_four
        ldaa #DRV4
.drv:   jsr  ov_load
        jsr  DRV+DV_INIT
        clra                    ; cursor off
        clrb
        os   DP$STAT
        jsr  cls
        jsr  redraw
        ldaa #IT_PICS           ; the four pictures
        ldx  #kv_glyph
        jsr  pk_load
        ldaa #$0F
        staa kv_gdirty
        os   KB$FLSH
        ldd  TMB_MIN            ; the random state from the clock and timer
        eora FRC
        eorb FRC+1
        std  kv_rng+2
        ldd  TMB_YEAR
        std  kv_rng
        oraa #1
        staa kv_rng
        jmp  kinit_done
