// Skipping: a play (Santa, lines, the Xmas Spins), with EXE pressed at every moment in turn; each
// time the game must come to rest with the same credits, the credits shown equal, the same
// reels and the same pictures as when nothing is pressed.
//   node tests/t_skip.js [model] [kind] [stepms]
const { Game } = require('./lib');
const model = process.argv[2] || 'lz64';
const kind = process.argv[3] || 'santa';
const step = +(process.argv[4] || 300) / 1000;
const pred = { santa: (b) => b.santa && b.houses >= 2 && b.total > 0 && !b.freeSpins, feature: (b) => b.freeSpins > 0 && b.total > 0 }[kind];
function play(skipAt) {
  const g = new Game(model);
  g.start();
  const seed = g.seedFor(pred, 2000);
  let t = 0, pressed = false;
  const total = g.spin(seed, 0.05, (tt) => { t = tt; if (!pressed && t >= skipAt) { g.m.keyDown('EXE'); g.m.runTicks(1); g.m.keyUp('EXE'); pressed = true; } }, 300);
  g.run(0.3);
  return { bal: g.peek32('kv_bal'), dbal: g.peek32('kv_dbal'), scr: g.scr().join('|'), udg: g.m.udgs().slice(0, 4).map((u) => u.join(',')).join(';'), total, spins: g.peek32('st_spins') };
}
const ref = play(1e9);
console.log(`${model} ${kind}: unskipped play ${ref.total.toFixed(1)} s, credits ${ref.bal}`);
let bad = 0;
for (let at = step; at < ref.total; at += step) {
  const r = play(at);
  if (r.spins > 1) { console.log(`EXE at ${at.toFixed(2)} s: after the play (a new spin started): not a skip`); continue; }
  const same = r.bal === ref.bal && r.dbal === r.bal && r.scr === ref.scr && r.udg === ref.udg;
  if (!same) {
    bad++;
    console.log(`EXE at ${at.toFixed(2)} s: credits ${r.bal} shown ${r.dbal}${r.scr !== ref.scr ? '\n  screen ' + r.scr + '\n  should ' + ref.scr : ''}${r.udg !== ref.udg ? '\n  pictures differ' : ''}`);
  }
}
console.log(bad ? `${bad} differ` : `skipped at every ${step} s: all the same`);
process.exit(bad ? 1 : 0);
