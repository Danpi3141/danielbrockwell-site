// Puts the tour's screens (build/shots/tour_<model>.json, from tests/tour.js) into docs/report.html.
//   node tests/tour.js lz64 && node tests/tour.js cm && node tools/report.js
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const shots = {};
for (const m of ['lz64', 'cm']) {
  const list = JSON.parse(fs.readFileSync(path.join(root, 'build', 'shots', `tour_${m}.json`), 'utf8'));
  shots[m] = list.map((e) => ({ n: e.name, c: e.label, t: Array.from({ length: e.lines }, (_, i) => String.fromCharCode(...e.cells.slice(i * e.cols, (i + 1) * e.cols))), u: e.udg }));
}
const p = path.join(root, 'docs', 'report.html');
const html = fs.readFileSync(p, 'utf8');
const out = html.replace(/^const SHOTS = .*$/m, () => 'const SHOTS = ' + JSON.stringify(shots) + ';');
if (out === html && !html.includes('const SHOTS = {')) throw new Error('no SHOTS line');
fs.writeFileSync(p, out);
console.log('report.html', out.length, 'bytes');
