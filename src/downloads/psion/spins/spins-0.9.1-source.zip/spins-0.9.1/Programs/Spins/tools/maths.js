// The maths program: the return counted exactly from the strips and pay table, then a simulation
// of whole plays (base spin + feature) with the game's own random numbers.
//   node tools/maths.js [four|two|both] [--sim N] [--seed S]
'use strict';
const G = require('../ref/game.js');

function exact(kind) {
  const g = G.grid(kind);
  const R = g.rows;
  const N = 32 ** 5;
  const win = (strip, p) => G.windowOf(strip, p, R);
  const bw = g.base.map((s) => Array.from({ length: 32 }, (_, p) => win(s, p)));
  const fw = g.free.map((s) => s && Array.from({ length: 32 }, (_, p) => win(s, p)));
  // checks the spec states: no window shows two stars or two Santas
  for (const [nm, arr] of [['base', bw], ['free', fw]]) {
    arr.forEach((ws, r) => ws && ws.forEach((w, p) => {
      if (w.filter((c) => c === '*').length > 1 || w.filter((c) => c === 'S').length > 1) {
        throw new Error(`${kind} ${nm} reel ${r + 1} stop ${p}: two stars or Santas`);
      }
    }));
  }
  // free spin: mean pay and stars
  let fpay = 0;
  for (let a = 0; a < 32; a++) for (let b = 0; b < 32; b++) for (let c = 0; c < 32; c++) for (let d = 0; d < 32; d++) {
    fpay += G.payGrid(g, [new Array(R).fill('S'), fw[1][a], fw[2][b], fw[3][c], fw[4][d]], true).total;
  }
  fpay /= 32 ** 4;
  const es = [2, 4].reduce((n, r) => n + fw[r].filter((w) => w.includes('*')).length / 32, 0);
  let tot = 0, lines = 0, santaPay = 0, santaN = 0, walk = 0, trig = 0, xmas = 0, fullN = 0;
  for (let a = 0; a < 32; a++) {
    const w0 = bw[0][a]; const santa = w0.includes('S'); const s0 = w0.includes('*') ? 1 : 0;
    for (let b = 0; b < 32; b++) {
      const w1 = bw[1][b]; const s1 = s0 + (w1.includes('*') ? 1 : 0);
      for (let c = 0; c < 32; c++) {
        const w2 = bw[2][c]; const s2 = s1 + (w2.includes('*') ? 1 : 0);
        for (let d = 0; d < 32; d++) {
          const w3 = bw[3][d]; const s3 = s2 + (w3.includes('*') ? 1 : 0);
          for (let e = 0; e < 32; e++) {
            const w4 = bw[4][e]; const st = s3 + (w4.includes('*') ? 1 : 0);
            const p = G.payGrid(g, [w0, w1, w2, w3, w4], santa).total;
            tot += p;
            if (santa) {
              santaPay += p; santaN++;
              if ([w1, w2, w3, w4].some((w) => w.includes('H'))) walk++;
              if ([w1, w2, w3, w4].every((w) => w.every((x) => x === 'H'))) fullN++;
            } else lines += p;
            if (st >= 3) {
              trig++;
              const v = G.T.feature_spins[Math.min(st, 5)] / (1 - es) * fpay;
              xmas += v; tot += v;
            }
          }
        }
      }
    }
  }
  const pc = (v) => (v / N / 20 * 100);
  return { kind, rtp: pc(tot), lines: pc(lines), santa: pc(santaPay), xmas: pc(xmas),
    santaEvery: N / santaN, walk: walk / santaN, trigEvery: N / trig,
    featureX: xmas / trig / 20, featureSpins: 0, fpay, extraPerSpin: es, fullEvery: fullN ? N / fullN : Infinity };
}

function simulate(kind, n, seed) {
  const g = G.grid(kind);
  const rng = new G.Rng(seed);
  let staked = 0, paid = 0, hits = 0, x10 = 0, x50 = 0, big = 0, feats = 0, fspins = 0;
  for (let i = 0; i < n; i++) {
    const p = G.play(g, rng);
    staked += 20;
    paid += p.total;
    if (p.total > 0) hits++;
    if (p.total >= 200) x10++;
    if (p.total >= 1000) x50++;
    if (p.total > big) big = p.total;
    if (p.feature) { feats++; fspins += p.feature.count; }
  }
  return { kind, n, rtp: paid / staked * 100, hitRate: hits / n, x10: x10 / n, x50: x50 / n,
    biggest: big / 20, features: feats, spinsPerFeature: fspins / feats };
}

if (require.main === module) {
  const a = process.argv.slice(2);
  const which = a[0] && !a[0].startsWith('--') ? a[0] : 'both';
  const simN = a.includes('--sim') ? +a[a.indexOf('--sim') + 1] : 0;
  const seed = a.includes('--seed') ? +a[a.indexOf('--seed') + 1] : 12345;
  for (const kind of which === 'both' ? ['four', 'two'] : [which]) {
    const e = exact(kind);
    console.log(`${kind}: return ${e.rtp.toFixed(3)}%  (lines ${e.lines.toFixed(2)}, Santa ${e.santa.toFixed(2)}, Xmas Spins ${e.xmas.toFixed(2)})`);
    console.log(`  Santa 1 in ${e.santaEvery.toFixed(2)}, walks ${(e.walk * 100).toFixed(1)}%, feature 1 in ${e.trigEvery.toFixed(1)}, feature ${e.featureX.toFixed(1)}x stake, full house 1 in ${e.fullEvery.toExponential(2)}`);
    if (simN) {
      const s = simulate(kind, simN, seed);
      console.log(`  sim ${s.n}: return ${s.rtp.toFixed(2)}%, pays ${(s.hitRate * 100).toFixed(1)}%, 10x+ ${(s.x10 * 100).toFixed(2)}%, 50x+ ${(s.x50 * 100).toFixed(3)}%, biggest ${s.biggest}x, spins/feature ${s.spinsPerFeature.toFixed(2)}`);
    }
  }
}

module.exports = { exact, simulate };
