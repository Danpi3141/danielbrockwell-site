// What the game shows, frame by frame, for a fixed set of plays: a Santa spin, a feature, a win,
// and every scene. The cosmetic random bytes (rng_cos) are pinned (the timer is not stirred in),
// so the trace does not depend on timing: a change that should not show leaves it the same.
//   node tests/t_trace.js [model] --save [--build dir]   record build/trace_<model>.json
//   node tests/t_trace.js [model] [--build dir]          compare with it
'use strict';
const fs = require('fs'), path = require('path');
const { Game, ROOT } = require('./lib');
const args = process.argv.slice(2);
const model = args.find((a) => !a.startsWith('--') && args[args.indexOf(a) - 1] !== '--build') || 'lz64';
const save = args.includes('--save');
const bi = args.indexOf('--build');
const build = bi >= 0 ? args[bi + 1] : undefined;
const g = new Game(model, { build });
g.start();
const m = g.m, dbg = m.dbg;

// pin rng_cos: the eorb of the timer's low byte becomes nops
const rc = g.addr('rng_cos');
let pinned = false;
for (let a = rc; a < rc + 12; a++) {
  const op = m.peek(a);
  if (op === 0xD8 && m.peek(a + 1) === 0x0A) { m.poke(a, 1); m.poke(a + 1, 1); pinned = true; break; }
  if (op === 0xF8 && m.peek(a + 1) === 0x00 && m.peek(a + 2) === 0x0A) { m.poke(a, 1); m.poke(a + 1, 1); m.poke(a + 2, 1); pinned = true; break; }
}
if (!pinned) throw new Error('rng_cos: no eorb FRC+1 found');
g.poke('kv_cos', 0);

const trace = [];
// DEBUGDRV=1: stop at the first instruction after which the screen driver's code has changed
if (process.env.DEBUGDRV) {
  let names = Object.entries(g.sym);
  for (const f of fs.readdirSync(g.bdir).filter((f) => /^ov_.*sym.json$/.test(f))) names = names.concat(Object.entries(JSON.parse(fs.readFileSync(path.join(g.bdir, f)))).map(([n, v]) => [f.slice(3, -9) + ':' + n, v]));
  names = names.filter(([n, v]) => v[1] === 'rel').sort((a, b) => a[1][0] - b[1][0]);
  const where = (pc) => { const o = pc - g.base; if (o < 0 || o >= g.meta.total) return pc.toString(16); let best = '?'; for (const [n, v] of names) if (v[0] <= o) best = n + '+' + (o - v[0]); return best; };
  const drv = g.addr('DRV'), ref = m.read(drv, 94).join(',');
  const ring = [];
  let stop = false;
  dbg.setTrace((pc) => {
    if (stop) return;
    ring.push([pc, dbg.x(), dbg.b(), dbg.a()]); if (ring.length > 40) ring.shift();
    if (pc >= g.base && pc < g.base + g.meta.total && m.read(drv, 94).join(',') !== ref) {
      stop = true;
      console.log('the driver changed; res', g.peek('kv_res'), 'screen', trace[trace.length - 1]);
      { const wf = JSON.parse(fs.readFileSync(path.join(g.bdir, 'ov_winfx.sym.json'))); const a = g.base + wf.wf_data[0];
        console.log('LN', m.read(a, 40).join(','), 'pays', m.read(a + 100, 12).join(','), 'pkok', g.peek('kv_pkok'), 'dev', g.peek('kv_dev'), 'li', m.peek(g.base + wf.wf_li[0]), 'n', m.peek(g.base + wf.wf_n[0]), 'nwin', g.peek('kv_nwin'), 'wins', g.m.read(g.addr('kv_wins'), 8).join(',')); }
      console.log(ring.map(([p, x, b, a]) => where(p) + ' x=' + (x - g.base) + ' a=' + a + ' b=' + b).join(' | '));
      process.exit(2);
    }
  });
}
let last = '';
function look(tag) {
  const c = m.cells(), u = m.udgs();
  const shown = [...new Set(c.filter((ch) => ch < 16).map((ch) => ch & 7))].sort();
  const s = g.scr().join('|') + ' ' + shown.map((k) => k + ':' + u[k].join(',')).join(' ');
  if (s !== last) { trace.push(tag ? tag + ' ' + s : s); last = s; }
}
const FT = g.addr('frame_t');
const idles = g.idles();
// run until the game waits for a key again (or done), looking at each frame
function runToRest(extra = [], onBp = null, maxSec = 600) {
  const c0 = m.cycles();
  for (;;) {
    const r = m.runTo([FT, ...idles, ...extra], 921600 * 2);
    if (r === FT) { look(); continue; }
    if (onBp && extra.includes(r)) { if (onBp(r)) return r; continue; }
    if (idles.includes(r) && m.cycles() - c0 > 921600 * 0.3) { look(); return r; }
    if ((m.cycles() - c0) / 921600 > maxSec) throw new Error('never came to rest: ' + trace[trace.length - 1] + ' pc ' + (dbg.pc() - g.base) + ' res ' + g.peek('kv_res'));
  }
}
const ogs = JSON.parse(fs.readFileSync(path.join(g.bdir, 'ov_game.sym.json'))).og_spin[0];
function spin(seed, tag) {
  trace.push('== ' + tag);
  g.toIdle();
  const bp = g.base + ogs;
  m.keyDown('EXE'); m.runTicks(2); m.keyUp('EXE');
  let seeded = false;
  runToRest([bp], (r) => { if (!seeded && g.peek('kv_res') === g.ids().OV_GAME) { g.setRng(seed); seeded = true; } return false; });
  trace.push(`credits ${g.peek32('kv_bal')} shown ${g.peek32('kv_dbal')}`);
}
spin(g.seedFor((b) => b.santa && b.houses >= 2 && b.total > 0 && !b.freeSpins, 3000), 'santa');
spin(g.seedFor((b) => b.santa && b.houses === 0 && !b.freeSpins, 1), 'santa, no house');
spin(g.seedFor((b) => !b.santa && b.total >= 20 && !b.freeSpins, 1), 'a win');
spin(g.seedFor((b) => b.freeSpins > 0, 1000), 'feature');
for (const [anim, name] of [[1, 'Quick'], [0, 'Off']]) {      // (autoplay plays at Quick)
  g.poke('kv_anim', anim);
  spin(g.seedFor((b) => b.santa && b.houses >= 1 && b.total > 0 && !b.freeSpins, 5000), 'santa, ' + name);
  spin(g.seedFor((b) => b.freeSpins > 0, 3000), 'feature, ' + name);
}
g.poke('kv_anim', 2);
// every walk style: a Santa spin's grid, then OV_HOME's set-up with the style forced, the walk and home
function callOv(id, entry, poke) {
  const idle = g.toIdle();
  const keep = g.keepSlot();
  if (poke) poke();
  dbg.setA(id); dbg.setB(entry);
  dbg.setPC(g.addr('t_call'));
  runToRest([g.addr('t_done')], (r) => r === g.addr('t_done'));
  const a = dbg.a();
  look();
  dbg.setPC(idle);
  keep();
  return a;
}
{
  const ids = g.ids();
  const seed = g.seedFor((b) => b.santa && b.houses >= 2 && !b.freeSpins, 100);
  for (let st = 0; st < 10; st++) {
    trace.push('== walk style ' + st);
    callOv(ids.OV_GAME, 0, () => g.setRng(seed));
    callOv(ids.OV_SPINFX, 0);
    callOv(ids.OV_HOME, 1, () => g.poke('kv_styles', 1));        // (the standard walk, then its style forced)
    g.poke('kv_arg', st, 1);
    const how = callOv(ids.OV_WALK, 0);
    callOv(ids.OV_HOME, 0, () => g.poke('kv_arg', how));
  }
  g.poke('kv_styles', 0);
}
// every scene, called as the Scenes menu does
const done = g.addr('t_done');
for (let sc = 0; sc < 14; sc++) {
  trace.push('== scene ' + sc);
  const idle = g.toIdle();
  const keep = g.keepSlot();
  g.poke('kv_arg', sc);
  dbg.setA(g.ids().OV_SCENE); dbg.setB(0);
  dbg.setPC(g.addr('t_call'));
  runToRest([done], (r) => r === done);
  look();
  dbg.setPC(idle);
  keep();
}
// the menus and pages, a key at a time
function key(k) {
  g.toIdle();
  m.keyDown(k);
  const c0 = m.cycles();
  while (m.cycles() - c0 < 921600 * 0.15) if (m.runTo([FT], 921600 * 0.15 - (m.cycles() - c0)) === FT) look();
  m.keyUp(k);
  runToRest();
}
for (const seq of [['MODE', 'DOWN', 'DOWN', 'DOWN', 'UP', 'ON'], ['P', 'DOWN', 'DOWN', 'RIGHT', 'DOWN', 'ON'], ['L', 'DOWN', 'DOWN', 'DOWN', 'ON'],
  ['S', 'DOWN', 'DOWN', 'DOWN', 'ON'], ['MODE', 'S', 'S', 'EXE', 'DOWN', 'DOWN', 'DOWN', 'DOWN', 'ON'], ['MODE', 'H', 'EXE', 'DOWN', 'DOWN', 'ON'],
  ['UP', 'UP', 'DOWN']]) {
  trace.push('== keys ' + seq.join(' '));
  for (const k of seq) key(k);
}
const file = path.join(ROOT, 'build', `trace_${model}.json`);
if (save) {
  fs.writeFileSync(file, JSON.stringify(trace, null, 0));
  console.log(`${model}: ${trace.length} screens recorded`);
} else {
  const ref = JSON.parse(fs.readFileSync(file, 'utf8'));
  let i = 0;
  while (i < ref.length && i < trace.length && ref[i] === trace[i]) i++;
  if (i === ref.length && i === trace.length) { console.log(`${model}: ${trace.length} screens, the same`); process.exit(0); }
  console.log(`${model}: differs at ${i} of ${ref.length} (now ${trace.length})`);
  for (let k = Math.max(0, i - 2); k < i + 3; k++) console.log(`  was ${ref[k]}\n  now ${trace[k]}`);
  process.exit(1);
}
