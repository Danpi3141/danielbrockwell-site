const { Game } = require('../lib');
const g = new Game('lz64'); g.start(); const ids = g.ids();
g.poke('kv_arg', 3); g.poke('kv_arg', 1, 1); g.poke('kv_spx', 0);
g.call(ids.OV_TEST, 3);
g.call(ids.OV_TEST, 4);
console.log('shown r1', [0,1,2].map(i=>g.peek('kv_shown',20+i)), 'r2', [0,1,2].map(i=>g.peek('kv_shown',40+i)));
const d = g.m.disp.getSnapshotData ? null : null;
console.log('cells r1', g.m.cells().slice(20,23), 'r2', g.m.cells().slice(40,43));
