// Exact RTP from the spec's strips. Usage: node rtp.js 4|2
const G = process.argv[2]==='2' ? 2 : 4;
const S4 = {
 base:['JKAAJMBRBKWQSAQMQJBAQQKKR*RJJJKW','RQWJQKMJJBKJJQWB*WQAHRKBJABHKAAM','JKKARWQBQHWWBHMBJMQA*RBKAJAQJKJJ','KBBKQQJHWJMAMRKJQKBA*AJHWRWJAQBJ','KHABMQWWKAAWK*HJBMQJJQRJBKRJJQBA'],
 free:[null,'KJMAKQKJAQAQBBJKQRJMJAHBKWRJQQWW','*QKRAQWKJRMMQJAAKHBJJBKQBKWQJQAW','KAAJKQQRWJBQKKJJWMJJMAQQRQBAKHBW','WJKJRBQQKQQMQKQBJAWBRAKAAW*HMJJK'],
 lines:'22222 33333 11111 44444 12321 43234 21112 34443 12221 43334 23332 32223 11211 44344 22122 33433 23432 32123 12121 43434'};
const S2 = {
 base:['JKAWSMBRBKWK*AQMQSBAQQAKR*RJJJKW','RQWJQAMQ*BKQJKWB*WQAHRKBJARHKAAM','JKKARWQBQHWWBHMBQMKA*RRKAQAQ*AJJ','KRBKQQJHWJMAMRKQQABA*AQHWRWJAKB*','KKMWQHJAJQKARARHKABAJBWQ*QMB*WQR'],
 free:[null,'KJMAKQKJAQAQBBJKQRJMJAHBKWRJQQWW','*QKRAQWKJRMMQJAAKHBJJBKJBKWQ*QAW','KAAJKQQRWJBQKKJJWMJJMAQQRQBAKHBW','WJK*RBQQKQQMQKJBJAWBRAKAAW*HMJJK'],
 lines:'11111 22222 12121 21212 11211 22122 12221 21112 11122 22211 11222 22111 12211 21122 11221 22112 12111 21222 11112 22221'};
const S = G===4?S4:S2;
const PAY = {M:[40,200,800],R:[20,80,300],B:[15,50,200],W:[10,30,100],A:[5,15,40],K:[4,12,30],Q:[3,8,20],J:[2,5,10]};
const lines = S.lines.split(' ').map(l=>[...l].map(c=>+c-1));
for (const s of [...S.base,...S.free.slice(1)]) if (s.length!==32) throw 'len '+s;
const syms='MRBWAKQJ';
// window of reel r at stop p: rows 0..G-1 = strip[(p+i)%32]
function win(strip,p){const w=[];for(let i=0;i<G;i++)w.push(strip[(p+i)%32]);return w;}
function lineWin(cells){ // cells[5] chars; 'X' = wild
  let best=0;
  for(const x of syms){let n=0;while(n<5&&(cells[n]===x||cells[n]==='X'))n++; if(n>=3)best=Math.max(best,PAY[x][n-3]);}
  return best;
}
function spinPay(wins, santa){ // wins[5][G]; reel1 replaced if santa
  let tot=0;
  for(const L of lines){const c=[];for(let r=0;r<5;r++){let s=wins[r][L[r]]; if(santa&&(r===0||s==='H'))s='X'; c.push(s);} tot+=lineWin(c);}
  return tot;
}
// Precompute windows
const bw=S.base.map(s=>Array.from({length:32},(_,p)=>win(s,p)));
const fw=S.free.map(s=>s&&Array.from({length:32},(_,p)=>win(s,p)));
// checks
for(const [nm,arr] of [['base',bw],['free',fw]]) arr.forEach((ws,r)=>ws&&ws.forEach((w,p)=>{const st=w.filter(c=>c==='*').length, sa=w.filter(c=>c==='S').length; if(st>1||sa>1) console.log('DOUBLE',nm,r,p,w.join(''));}));
// free spins: expected pay per free spin, expected stars
let fpay=0,fstar=0,fmax=0;
for(let a=0;a<32;a++)for(let b=0;b<32;b++)for(let c=0;c<32;c++)for(let d=0;d<32;d++){
  const w=[['X','X','X','X'].slice(0,G),fw[1][a],fw[2][b],fw[3][c],fw[4][d]];
  const p=spinPay(w,true); fpay+=p; if(p>fmax)fmax=p;
}
fpay/=32**4;
let es=0; for(const r of [2,4]) es+=fw[r].filter(w=>w.includes('*')).length/32;
const fExpSpins=n=>n/(1-es);
console.log('G',G,'free: mean pay/spin',fpay.toFixed(4),'max',fmax,'E stars/spin',es);
// base enumeration
let tot=0,line0=0,santaPay=0,hits=0,trig=0,trigVal=0,santaN=0,walk=0; const N=32**5;
const FS={3:10,4:12,5:15};
for(let a=0;a<32;a++){const w0=bw[0][a]; const santa=w0.includes('S'); const st0=w0.includes('*')?1:0;
 for(let b=0;b<32;b++){const w1=bw[1][b];const st1=st0+(w1.includes('*')?1:0);
 for(let c=0;c<32;c++){const w2=bw[2][c];const st2=st1+(w2.includes('*')?1:0);
 for(let d=0;d<32;d++){const w3=bw[3][d];const st3=st2+(w3.includes('*')?1:0);
 for(let e=0;e<32;e++){const w4=bw[4][e];const st=st3+(w4.includes('*')?1:0);
   const p=spinPay([w0,w1,w2,w3,w4],santa);
   tot+=p; if(santa){santaPay+=p;santaN++; if(w1.includes('H')||w2.includes('H')||w3.includes('H')||w4.includes('H'))walk++;} else line0+=p;
   if(st>=3){trig++; const v=fExpSpins(FS[st])*fpay; trigVal+=v; tot+=v;}
 }}}}}
const stake=20;
console.log('RTP',(tot/N/stake*100).toFixed(3)+'%','lines',(line0/N/stake*100).toFixed(2),'santa',(santaPay/N/stake*100).toFixed(2),'xmas',(trigVal/N/stake*100).toFixed(2));
console.log('santa 1 in',(N/santaN).toFixed(2),'walk',(walk/santaN*100).toFixed(1)+'%','trigger 1 in',(N/trig).toFixed(1),'avg feature x stake',(trigVal/trig/stake).toFixed(1));
