const { Game } = require('../lib');
const g = new Game('lz64');
g.start();
const ids = g.ids();
g.poke('kv_arg', 0);
const fa = g.addr('frame_t'), done = g.addr('t_done');
g.toIdle();
g.m.dbg.setA(ids.OV_SCENE); g.m.dbg.setB(0); g.m.dbg.setPC(g.addr('t_call'));
let last = g.m.cycles(), n = 0;
for (;;) {
  const r = g.m.runTo([fa, done], 921600 * 10);
  if (r === done || r === -1) { console.log('end', r); break; }
  const c = g.m.cycles();
  if (n++ < 12) console.log('frame_t A=', g.m.dbg.a(), 'since last', c - last, 'tnt', g.peek('kv_tnt'), 'tns', g.peekw('kv_tns'), 'unit', g.peek('kv_tunit'), 'glass', g.peek('kv_glass'));
  last = c;
  g.m.run(5);
}
