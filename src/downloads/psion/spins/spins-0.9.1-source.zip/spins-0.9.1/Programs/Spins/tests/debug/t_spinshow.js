// Watch a spin: the LCD at intervals after EXE.  node tests/t_spinshow.js [model] [ms,ms,...]
const { Game } = require('../lib');
const model = process.argv[2] || 'lz64';
const at = (process.argv[3] || '100,500,900,1300,2600').split(',').map(Number);
const g = new Game(model);
g.start();
const cols = g.m.lines === 4 ? 20 : 16;
console.log('rest:\n' + g.lcd(cols));
g.m.keyDown('EXE'); g.m.runTicks(2); g.m.keyUp('EXE');
let t = 100;
for (const ms of at) {
  g.run((ms - t) / 1000); t = ms;
  console.log(`\n${ms} ms: (grid ${[...Array(5)].map((_, r) => [...Array(g.m.lines)].map((_, y) => 'MRBWAKQJHS*'[g.peek('kv_grid', r * 4 + y)]).join('')).join(' ')})\n` + g.lcd(cols));
}
