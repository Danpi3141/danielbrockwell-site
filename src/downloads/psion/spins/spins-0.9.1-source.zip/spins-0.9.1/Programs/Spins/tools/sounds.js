// The buzzer's output as WAV files: every tune and effect played by the game's own sound engine
// on the emulated Organiser (OV_TEST), its edges turned into a square wave.
//   node tools/sounds.js [names...]     -> build/sound/<name>.wav
'use strict';
const fs = require('fs'), path = require('path');
const { Game } = require('../tests/lib');
const ROOT = path.join(__dirname, '..');
const data = JSON.parse(fs.readFileSync(path.join(ROOT, 'build', 'sounds.json')));
const out = path.join(ROOT, 'build', 'sound');
fs.mkdirSync(out, { recursive: true });
const want = process.argv.slice(2);
const RATE = 22050, CLK = 921600;
function wav(edges, c0, c1) {
  const n = Math.ceil((c1 - c0) / CLK * RATE);
  const pcm = Buffer.alloc(n, 128);
  let e = 0, level = 0;
  for (let i = 0; i < n; i++) {
    const t = c0 + i * CLK / RATE;
    while (e < edges.length && edges[e][0] <= t) { level = edges[e][1]; e++; }
    pcm[i] = level ? 200 : 56;
  }
  const h = Buffer.alloc(44);
  h.write('RIFF', 0); h.writeUInt32LE(36 + n, 4); h.write('WAVE', 8); h.write('fmt ', 12);
  h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(1, 22); h.writeUInt32LE(RATE, 24);
  h.writeUInt32LE(RATE, 28); h.writeUInt16LE(1, 32); h.writeUInt16LE(8, 34); h.write('data', 36); h.writeUInt32LE(n, 40);
  return Buffer.concat([h, pcm]);
}
const g = new Game('lz64');
g.start();
const ids = g.ids();
const T = JSON.parse(fs.readFileSync(path.join(ROOT, 'build', 'game', 'ov_test.sym.json')));
const buf = g.base + T.ts_data[0];
function play(kind, name, bytes) {
  g.m.write(buf, bytes);
  let frames;
  if (kind === 'tune') {                  // its length in ticks / 10, and a little more
    const lens = [1, 2, 3, 4, 6, 8, 12, 16];
    const ticks = bytes.slice(3, bytes.indexOf(255, 3)).reduce((s, b) => s + lens[b & 7] * (bytes[1] & 127), 0);
    frames = Math.min(250, Math.ceil(ticks / 10) + 3);
  } else {
    let ticks = 0;
    const L = [2, 4, 4, 5, 3, 2, 3, 4];
    for (let i = 0; bytes[i] !== 255; i += L[bytes[i]]) ticks += bytes[i + 1];
    frames = Math.ceil(ticks / 10) + 2;
  }
  g.poke('kv_arg', frames);
  g.m.buzzStart();
  const c0 = g.m.cycles();
  g.call(ids.OV_TEST, kind === 'tune' ? 1 : 0, { x: buf });
  const edges = g.m.buzzEdges();
  g.m.buzzStop();
  fs.writeFileSync(path.join(out, `${kind}_${name}.wav`), wav(edges, c0, g.m.cycles()));
  return frames;
}
for (const [n, b] of Object.entries(data.tunes)) if (!want.length || want.includes(n)) console.log('tune', n, play('tune', n, b), 'frames');
for (const [n, b] of Object.entries(data.effects)) if (!want.length || want.includes(n)) play('effect', n, b);
console.log('written to', out);
