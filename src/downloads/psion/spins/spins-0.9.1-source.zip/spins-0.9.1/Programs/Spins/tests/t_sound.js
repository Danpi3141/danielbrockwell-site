// The sound engine: every note's pitch (within 1%), and frames keeping time with sound on,
// soft and off.   node tests/t_sound.js [model]
const { Game } = require('./lib');
const model = process.argv[2] || 'lz64';
const g = new Game(model);
g.start();
const ids = g.ids();
const SCENE = g.base + JSON.parse(require('fs').readFileSync(require('path').join(__dirname, '..', 'build', 'game', 'ov_test.sym.json'))).ts_data[0];
const freq = (n) => 440 * 2 ** ((n - 5) / 12);      // note 0 = E4 (A4 is 5 above)
let bad = 0;
function play(bytes, frames, entry = 0) {
  g.m.write(SCENE, bytes);
  g.poke('kv_arg', frames);
  g.m.buzzStart();
  const c0 = g.m.cycles();
  g.call(ids.OV_TEST, entry, { x: SCENE, keep: false });
  const cyc = g.m.cycles() - c0;
  return { tones: g.m.buzzStop(), cyc };
}
// pitches
let worst = 0;
for (let n = 0; n <= 44; n++) {
  play([1, 24, n, 1, 0xFF], 3);
  // the most common period between rising edges
  const ups = g.m.buzzEdges().filter((e) => e[1] === 1).map((e) => e[0]);
  const cnt = {};
  for (let i = 1; i < ups.length; i++) { const p = ups[i] - ups[i - 1]; cnt[p] = (cnt[p] || 0) + 1; }
  const p = +Object.entries(cnt).sort((a, b) => b[1] - a[1])[0][0];
  const t = { hz: 921600 / p };
  const err = (t.hz - freq(n)) / freq(n);
  worst = Math.max(worst, Math.abs(err));
  if (Math.abs(err) > 0.01) { bad++; console.log('note', n, 'want', freq(n).toFixed(1), 'got', t && t.hz); }
}
console.log(`pitches: 45 notes, worst ${(worst * 100).toFixed(2)}% off`);
// timing: 12 frames of 10 ticks = 1 s, sound on / soft / off, a tone and a noise
for (const [name, fx] of [['tone', [1, 200, 20, 1, 0xFF]], ['noise', [4, 200, 3, 0xFF]], ['bell', [6, 200, 30, 0xFF]], ['silence', [0, 200, 0xFF]]]) {
  for (const snd of [0, 1, 2]) {
    g.poke('kv_sound', snd);
    const { cyc } = play(fx, 12);
    const err = (cyc - 921600) / 921600;
    if (Math.abs(err) > 0.03) bad++;
    console.log(`${name} sound ${snd}: 1 s took ${(cyc / 921.6).toFixed(1)} ms (${(err * 100).toFixed(2)}%)`);
  }
}
g.poke('kv_sound', 0);
// two voices: a C6 melody over a C5 bass (16-unit notes of 10 ticks): both heard, the melody two
// ticks in three, and the tune keeps time
{
  const n = (p) => (p << 3) | 7;
  const { cyc } = play([20, 10, 6, n(0), n(0), 255, n(8), n(8), 255], 12, 1);
  const ups = g.m.buzzEdges().filter((e) => e[1] === 1).map((e) => e[0]);
  const cnt = {};
  for (let i = 1; i < ups.length; i++) { const p = ups[i] - ups[i - 1]; cnt[p] = (cnt[p] || 0) + 1; }
  const near = (want) => Object.entries(cnt).filter(([p]) => Math.abs(921600 / p - want) / want < 0.01).reduce((s, [, c]) => s + c, 0);
  const mel = near(freq(20)), bass = near(freq(8));
  let swaps = 0, last = null;
  for (let i = 1; i < ups.length; i++) {
    const hz = 921600 / (ups[i] - ups[i - 1]);
    const v = Math.abs(hz - freq(20)) / freq(20) < 0.01 ? 'm' : Math.abs(hz - freq(8)) / freq(8) < 0.01 ? 'b' : null;
    if (v && last && v !== last) swaps++;
    if (v) last = v;
  }
  const err = (cyc - 921600) / 921600;
  const ok = mel > 2.5 * bass && bass > 80 && swaps > 70 && Math.abs(err) < 0.03;   // (two ticks in three the melody)
  if (!ok) bad++;
  console.log(`two voices: ${mel} melody periods, ${bass} bass, ${swaps} changes; 1 s took ${(cyc / 921.6).toFixed(1)} ms ${ok ? 'ok' : 'BAD'}`);
}
process.exit(bad ? 1 : 0);
