; ---------------------------------------------------------------------
; The sound engine: one buzzer, played by the processor in counted loops,
; a tick (1/120 s) at a time, between the frames' drawing.
;
; A tone is a loop of 32 + 4*S cycles a period (S = H + L1 + L2, three
; delay loops; the buzzer's line is high during H): 921,600 / (32 + 4 S)
; Hz. snd_tick plays one tick: it adds a tick's cycles to the budget
; (zero page SB) and sounds until the budget is spent; what is over is
; taken off the next tick, so the ticks keep time.
;
; Voices: an effect (a list of cells) and a tune (one byte a note) run
; together, in step; the effect is heard while there is one.
;
; Effect cells: type, ticks, then the type's bytes; $FF ends the list.
;   0 rest                  1 tone: note, shift (1 square .. 4 narrow)
;   2 slide: note, step (S changes by step, signed, every tick)
;   3 arpeggio: n1, n2, n3 ($FF: two notes)
;   4 noise: rate           5 click
;   6 bell: note (the pulse narrows: it rings and dies away)
;   7 vibrato: note, depth
;
; A tune: base note, ticks a unit (bit 7: it loops), the bass's offset
; from the tune's start (0: none), then the melody, one byte a note:
; pitch (5 bits, above the base; 31 a rest) << 3 | length (in units: 1 2
; 3 4 6 8 12 16), $FF; then the bass the same way (its base is note 0,
; E4), $FF. The two parts are the same length (tools/script.py checks).
; While both sound, the melody has two ticks in three and the bass one;
; while one rests, the other has every tick. A note's last tick (3 if it
; is 12 or longer) is silent, the bass too while the melody's is.
; ---------------------------------------------------------------------
SB      = T0                    ; cycle budget (signed)
SP_     = T2                    ; the period being played, cycles
SH      = T4                    ; delay counts
SL1     = T5
SL2     = T6
SNL     = T7                    ; noise shift register (2 bytes)
SOVH    = 238                   ; cycles a tick spends choosing, and the keyboard
                                ; interrupt's share (measured: tests/t_sound.js)
TOVH    = 253                   ; a tone's set-up, more (with clamp's three calls)
TOVC    = 177                   ; a tone kept from the last tick
NOVH    = 35
VOVH    = 167                   ; a tick that alternates the tune's two voices
TOFF    = 55                    ; a tone with sound off                    ; a noise's

; snd_tick: one tick of sound (or of silence, the same length)
snd_tick:
        ldd  SB
        addd #TICK_CYC-SOVH
        std  SB
        bmi  .skip              ; still paying for the drawing: a silent tick
        tst  kv_fxt             ; an effect?
        beq  .tune
        jsr  fx_tick
        bra  .adv
.tune:  tst  kv_tnt             ; a tune, music on
        beq  .rest
        tst  kv_music
        bne  .rest
        tst  kv_tune+VLAST      ; the gap at a melody note's end: silent
        bne  .rest              ; (the bass does not fill it)
        ldab #1
        stab kv_sh
        ldx  #kv_tune
        bsr  v_snd
        std  kv_s               ; the melody's S (0: silent this tick)
        ldx  #kv_bass
        bsr  v_snd
        beq  .m                 ; no bass now: the melody
        ldx  kv_s
        beq  .t                 ; no melody now: the bass
        std  kv_ss              ; (free outside effects)
        ldd  SB                 ; both: a new tone every tick, uncounted
        subd #VOVH
        std  SB
        inc  kv_alt             ; two ticks the melody, one the bass
        ldaa kv_alt
        cmpa #3
        blo  .m
        clr  kv_alt
        ldd  kv_ss
        bra  .t
.m:     ldd  kv_s
        beq  .rest
.t:     jsr  tone_s
        bra  .adv
.rest:  jsr  quiet
.adv:   jmp  tn_adv             ; the tune moves on, in step
.skip:  tst  kv_fxt             ; (the effect moves on too)
        beq  .adv
        jsr  fx_adv
        bra  .adv

; v_snd: X = a voice: D = its S now, Z set if it is silent this tick
v_snd:  tst  VT,x
        beq  .z
        tst  VLAST,x
        bne  .z
        ldd  VS,x
        rts
.z:     clra
        clrb
        rts

; ---- the loops ----

; quiet: silence until the budget runs out (14 cycles a pass)
quiet:  ldd  SB                 ; 4
        subd #14                ; 3
        std  SB                 ; 4
        bpl  quiet              ; 3
        rts

; clamp: B = D held to 1..255
clamp:  tsta
        beq  .z
        ldab #255
.z:     tstb
        bne  .x
        incb
.x:     rts

; tone_n: A = note number, B = pulse shift (1 square, 2-4 narrower)
tone_n: stab kv_sh
        tab
        jsr  note_s
; tone_s: D = S, kv_sh = pulse shift: a tone until the budget is spent.
; The loop's counts are kept: the same tone next tick starts at once.
tone_s: std  kv_s
        ldab kv_sound
        cmpb #2
        bne  .on
        ldd  SB                 ; Off: the same time in silence
        subd #TOFF
        std  SB
        jmp  quiet
.on:    ldab kv_sh
        tst  kv_sound
        beq  .sh
        addb #2                 ; Soft: two steps narrower
.sh:    cmpb kv_lsh             ; the same as last time?
        bne  .new
        ldx  kv_s
        cpx  kv_ls
        bne  .new
        ldd  SB
        subd #TOVC
        std  SB
        bra  tloop
.new:   stab kv_lsh
        ldx  kv_s
        stx  kv_ls
        stab SL2                ; H = S >> shift, 1..255
        ldd  kv_s
.s:     lsrd
        dec  SL2
        bne  .s
        bsr  clamp
        stab SH
        ldd  kv_s               ; L1 = (S - H) / 2, 1..255
        subb SH
        sbca #0
        lsrd
        bsr  clamp
        stab SL1
        ldd  kv_s               ; L2 = S - H - L1, 1..255
        subb SH
        sbca #0
        subb SL1
        sbca #0
        bpl  .p                 ; (below 0: 1)
        clra
        clrb
.p:     bsr  clamp
        stab SL2
        clra                    ; the period from the counts: 32 + 4 S
        ldab SH
        addb SL1
        adca #0
        addb SL2
        adca #0
        asld
        asld
        addd #32
        std  SP_
        ldd  SB
        subd #TOVH
        std  SB
; the tone loop: 32 + 4 (H + L1 + L2) cycles a period
tloop:  tst  BZ_ON              ; 4
        ldab SH                 ; 3
.h:     decb                    ; 4 H
        bne  .h
        tst  BZ_OFF             ; 4
        ldab SL1                ; 3
.l1:    decb                    ; 4 L1
        bne  .l1
        ldab SL2                ; 3
.l2:    decb                    ; 4 L2
        bne  .l2
        ldd  SB                 ; 4
        subd SP_                ; 4
        std  SB                 ; 4
        bpl  tloop              ; 3
        rts

; noise: A = rate: the line set from a shift register's bits, a step
; every 39 + 4 * rate cycles
noise:  clr  kv_lsh            ; (the cached tone's counts are overwritten)
        ldab kv_sound
        cmpb #2
        beq  quiet
        staa SH
        tab
        clra
        asld
        asld
        addd #39
        std  SP_
        ldd  SB
        subd #NOVH
        std  SB
.n:     ldd  SNL                ; 4
        lsrd                    ; 1
        bcc  .z                 ; 3
        eora #$B4               ; 2
        std  SNL                ; 4
        tst  BZ_ON              ; 4
        bra  .d                 ; 3
.z:     std  SNL                ; 4
        tst  BZ_OFF             ; 4
        brn  .z                 ; 3
        nop                     ; 1
        nop                     ; 1
.d:     ldab SH                 ; 3
.r:     decb                    ; 4 rate
        bne  .r
        ldd  SB                 ; 4
        subd SP_                ; 4
        std  SB                 ; 4
        bpl  .n                 ; 3
        rts

; click: a short pulse, then silence
click:  ldab kv_sound
        cmpb #2
        beq  quiet
        tst  BZ_ON
        ldab #40
.d:     decb
        bne  .d
        tst  BZ_OFF
        jmp  quiet

; note_s: B = note: D = its S (the table holds the low bytes; S is 512 or
; more below note NOTE_HI2, 256 or more below NOTE_HI1: tools/build.py)
note_s: ldx  #notes
        abx
        clra
        cmpb #NOTE_HI1
        bhs  .x
        inca
        cmpb #NOTE_HI2
        bhs  .x
        inca
.x:     ldab 0,x
        rts

; ---------------------------------------------------------------------
; Effects. kv_fxp: the cell; kv_fxt its ticks left (0: no effect);
; kv_fxi: the tick within the cell.
; ---------------------------------------------------------------------

; snd_fx: X = an effect's cells: it starts at the next tick
snd_fx: stx  kv_fxp
fx_new: ldx  kv_fxp             ; the cell at kv_fxp starts
        clr  kv_fxt
        ldaa 0,x
        cmpa #$FF
        beq  .x
        ldab 1,x
        stab kv_fxt
        clr  kv_fxi
.x:     rts

; one tick of the effect's cell, then on
fx_tick:
        ldx  kv_fxp
        ldab 0,x
        aslb
        ldx  #fx_tab
        abx
        ldx  0,x
        jsr  0,x
; fx_adv: the effect's next tick (or cell)
fx_adv: inc  kv_fxi
        dec  kv_fxt
        bne  .x
        ldx  kv_fxp             ; the next cell
        ldab 0,x
        ldx  #fx_len
        abx
        ldab 0,x
        ldx  kv_fxp
        abx
        stx  kv_fxp
        jmp  fx_new
.x:     rts
fx_tab: fdb  quiet, fx_tone, fx_slide, fx_arp, fx_noise, fx_click, fx_bell, fx_vib
fx_len: fcb  2, 4, 4, 5, 3, 2, 3, 4

fx_tone: ldx kv_fxp
        ldaa 2,x
        ldab 3,x
        jmp  tone_n
fx_noise: ldx kv_fxp
        ldaa 2,x
        jmp  noise
fx_click:
        tst  kv_fxi             ; the click at the cell's first tick only
        bne  .q
        jmp  click
.q:     jmp  quiet
; a slide: S starts at the note's and moves by step every tick
fx_slide:
        ldx  kv_fxp
        tst  kv_fxi
        bne  .on
        ldab 2,x
        jsr  note_s
        std  kv_ss
        bra  .go
.on:    ldab 3,x                ; S + step (signed)
        clra
        tstb
        bpl  .p
        coma
.p:     addd kv_ss
        std  kv_ss
.go:    ldab #1
        stab kv_sh
        ldd  kv_ss
        jmp  tone_s
; an arpeggio: the notes in turn, a tick each
fx_arp: ldx  kv_fxp
        ldaa kv_fxi
        ldab 4,x                ; three notes or two
        cmpb #$FF
        beq  .two
.m3:    cmpa #3
        blo  .n
        suba #3
        bra  .m3
.two:   anda #1
.n:     tab
        abx
        ldaa 2,x
        ldab #1
        jmp  tone_n
; a bell: the pulse narrows in four steps over the cell
fx_bell: ldx kv_fxp
        ldaa kv_fxi
        asla
        asla
        clrb                    ; shift = 1 + (4 i) / ticks
.b:     cmpa 1,x
        blo  .d
        suba 1,x
        incb
        bra  .b
.d:     incb
        ldaa 2,x
        jmp  tone_n
; vibrato: the note's S up and down by depth, four ticks each way
fx_vib: ldx  kv_fxp
        ldab 3,x
        clra
        std  kv_ss
        ldab 2,x
        jsr  note_s
        psha
        ldaa kv_fxi
        bita #4
        pula
        beq  .up
        subd kv_ss
        bra  .go
.up:    addd kv_ss
.go:    pshb
        ldab #1
        stab kv_sh
        pulb
        jmp  tone_s

; ---------------------------------------------------------------------
; Tunes: two voices, kv_tune (the melody) and kv_bass, each a record:
; VP the next byte, V0 the first, VT ticks left of this note (0: none;
; the melody's is kv_tnt: 0 no tune), VS its S (0 a rest), VLEN its
; ticks, VLAST its last tick (silent), VBASE the base note.
; ---------------------------------------------------------------------
VP      = 0
V0      = 2
VT      = 4
VS      = 5
VLEN    = 7
VLAST   = 8
VBASE   = 9

; snd_tune: X = a tune: it starts at the next tick
snd_tune:
        ldaa 0,x
        staa kv_tune+VBASE
        clr  kv_tloop
        ldaa 1,x                ; (bit 7: it loops)
        bpl  .u
        inc  kv_tloop
        anda #$7F
.u:     staa kv_tunit
        clr  kv_bass+VT
        ldab 2,x                ; the bass
        beq  .m
        pshx
        abx
        stx  kv_bass+VP
        stx  kv_bass+V0
        ldx  #kv_bass
        bsr  v_next
        pulx
.m:     inx
        inx
        inx
        stx  kv_tune+VP
        stx  kv_tune+V0
        ldx  #kv_tune
        bra  v_next

; the tune moves on a tick (the bass only while the melody plays)
tn_adv: ldx  #kv_tune
        tst  VT,x
        beq  v_x
        bsr  v_adv
        ldx  #kv_bass
        tst  VT,x
        beq  v_x
; v_adv: X = a voice: on a tick
v_adv:  dec  VT,x
        beq  v_next
        ldab VLEN,x             ; a note's last ticks are silent, so repeated
        cmpb #3                 ; notes sound apart: 1 of a note of 3-11
        blo  v_x                ; ticks, 3 of a longer one
        ldaa #1
        cmpb #12
        blo  .g
        ldaa #3
.g:     cmpa VT,x
        blo  v_x
        inc  VLAST,x
v_x:    rts
; v_next: X = a voice: its next note (kv_s holds the voice meanwhile)
v_next: clr  VLAST,x
        stx  kv_s
        ldx  VP,x
        ldaa 0,x
        cmpa #$FF
        bne  .n
        tst  kv_tloop
        beq  .end
        ldx  kv_s               ; round again
        ldx  V0,x
        ldaa 0,x
.n:     inx
        psha
        pshx
        ldx  kv_s
        pula
        pulb
        std  VP,x
        pulb                    ; the length: units * ticks a unit
        pshb
        andb #7
        ldx  #tn_lens
        abx
        ldab 0,x
        ldaa kv_tunit
        mul
        tsta
        beq  .l
        ldab #255
.l:     ldx  kv_s
        stab VT,x
        stab VLEN,x
        pulb                    ; the pitch
        lsrb
        lsrb
        lsrb
        cmpb #31
        beq  .rest
        addb VBASE,x
        jsr  note_s
        ldx  kv_s
        std  VS,x
        rts
.end:   ldx  kv_s
        clr  VT,x
.rest:  clr  VS,x
        clr  VS+1,x
        rts
tn_lens: fcb 1, 2, 3, 4, 6, 8, 12, 16

; snd_stop: no tune, no effect
snd_stop:
        clr  kv_tnt
        clr  kv_fxt
        rts

; the notes: S for each, from tools/build.py (notes_table)
        include "notes.inc"
