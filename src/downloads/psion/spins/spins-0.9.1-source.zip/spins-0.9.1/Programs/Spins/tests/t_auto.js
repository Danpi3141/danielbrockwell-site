// Autoplay: A, 10 spins; it plays them (unless a feature stops it) and stops; a key stops it.
const { Game } = require('./lib');
const model = process.argv[2] || 'lz64';
const g = new Game(model);
g.start();
g.press('A'); g.run(0.5);
console.log(g.scr().join('|'));
g.press('EXE');
const t0 = g.m.cycles();
let n = 0;
for (let i = 0; i < 600; i++) {
  g.run(0.5);
  const s = g.peek32('st_spins');
  if (s !== n) { n = s; }
  if (!g.peek('kv_auto') && g.peek('kv_res') === g.ids().OV_REST) { g.run(0.5); if (!g.peek('kv_auto')) break; }
}
const secs = (g.m.cycles() - t0) / 921600;
console.log(`autoplay: ${g.peek32('st_spins')} spins in ${secs.toFixed(1)} s, features ${g.peek('st_feats', 1)}, credits ${g.peek32('kv_bal')} shown ${g.peek32('kv_dbal')}`);
console.log(g.scr().join('\n'));
const ok = g.peek32('st_spins') === 10 || g.peek('st_feats', 1) > 0;
process.exit(ok && g.peek32('kv_bal') === g.peek32('kv_dbal') ? 0 : 1);
