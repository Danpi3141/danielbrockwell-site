const { Game } = require('../lib');
const g = new Game(process.argv[2] || 'lz64');
g.start();
const seed = g.seedFor((b) => b.freeSpins > 0, 1000);
let n = 0;
try {
  g.spin(seed, 1, (t) => {
    if (n++ % 5 === 0) console.log(t, 'res', g.peek('kv_res'), 'pc', g.m.dbg.pc().toString(16), 'base', g.base.toString(16), 'fidx', g.peek('kv_fidx'), 'fleft', g.peek('kv_fleft'), g.scr()[1]);
  }, 40);
} catch (e) { console.log(e.message); }
console.log(g.scr().join('\n'));
