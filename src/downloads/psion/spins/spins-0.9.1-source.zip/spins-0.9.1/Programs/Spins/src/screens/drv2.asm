; =====================================================================
; Two-line screen driver (CM, XP, LA). Loaded at DRV.
; Reels in columns 1-5 (1-based), two rows; column 6 blank; the panel in
; columns 7-16.
; =====================================================================
        include "../defs.inc"

        jmp  d2_init
        jmp  d2_addr

d2_init:
        ldd  #$1002             ; 16 x 2
        std  kv_w
        ldaa #32
        staa kv_ncell
        ldd  #kv_under+32
        std  kv_cend
        ldaa #6
        staa kv_px
        ldaa #2
        staa kv_rows
        ldx  #kv_reelx
        clra
.r:     staa 0,x
        inx
        inca
        cmpa #5
        bne  .r
        rts

; A = a cell index (0-31): A = its DDRAM address
d2_addr:
        cmpa #16
        blo  .x
        adda #$40-16
.x:     rts
