#!/usr/bin/env python3
"""Pack images (.opk) for Connect 4 (from Drakeloft/Chess): Datapak, Rampak or Flashpak, from block files.

A block file is (type, name, body): type $83 for a procedure. The game's own data blocks are
procedures whose object code is a stub that only returns, followed by the data (see blockfile()),
so running one by mistake does nothing, and RPLOAD/XTRECV move them like any other .OB3.
"""
import os
import sys
import datetime

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', '..', 'Tools'))
import opl2opk  # noqa: E402  (record writers and the OPL translator)

SIZES = (8, 16, 32, 64, 128, 256)

# The stub at the start of every data block's object code, laid out as the ROM translator lays out
#   STUB:
#   RETURN
# (checked byte for byte in tests/m0): variable space 2, QCode length, no parameters, globals,
# externals or fix-ups, then QCode 59 B2 (the LZ "stop sign") and 7B (RETURN 0). The data follows
# the RETURN and is counted in the QCode length, so a block is a well-formed procedure that does
# nothing if it is run by mistake.
# Connect 4 runs on the CM/XP too, so its blocks use the CM/XP translator's stub (checked against
# opltran.py --target cm): QCode 7B (RETURN) only, no LZ stop sign. The data starts 14 bytes into
# the object code, 16 after the start of the block's body (the object length word first).
DATA_OFFSET = 14
DATA_OFFSET_LZ = 16


def stub_block(data, target='cm'):
    """Body of a $83 block file for a data block: object length, stub + data, no source."""
    if target == 'cm':
        q = 1 + len(data)
        obj = bytes([0, 2, q >> 8, q & 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x7B]) + bytes(data)
        assert len(obj) == DATA_OFFSET + len(data)
    else:
        q = 3 + len(data)
        obj = bytes([0, 2, q >> 8, q & 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x59, 0xB2, 0x7B]) + bytes(data)
        assert len(obj) == DATA_OFFSET_LZ + len(data)
    return opl2opk.be16(len(obj)) + obj + bytes(2)


def strip_source(rec):
    """A procedure's records (name, then its block: object length, object code, source length,
    source) with the source left out (its length 0): the Organiser runs only the object code."""
    if rec[11:13] != b'\x02\x80':
        raise ValueError('not a procedure block')
    body = rec[15:15 + (rec[13] << 8 | rec[14])]
    olen = body[0] << 8 | body[1]
    return rec[:11] + opl2opk.long_record(body[:2 + olen] + bytes(2))


def header(size_k, kind):
    """10-byte pack header. kind: 'datapak', 'rampak' or 'flashpak'."""
    flags = {'datapak': 0x7A, 'rampak': 0x78, 'flashpak': 0x3A}[kind]
    if size_k >= 32:
        flags |= 0x04
    now = datetime.datetime(2026, 11, 15, 12)
    frame = 0x4452  # fixed so builds are reproducible
    h = bytes([flags, size_k // 8, now.year - 1900 & 0xFF, now.month - 1, now.day - 1, now.hour]) + opl2opk.be16(frame)
    checksum = sum((h[i] << 8) | h[i + 1] for i in range(0, 8, 2)) & 0xFFFF
    return h + opl2opk.be16(checksum)


class PackImage:
    def __init__(self, kind='datapak', size_k=None, target='cm'):
        self.target = target
        self.kind = kind
        self.size_k = size_k
        self.body = bytearray()
        self.files = []          # (name, type, pack address of the body's first byte, body length)

    def add(self, ftype, name, body):
        """Adds a block file; returns the pack address of the first byte of its body."""
        rec = opl2opk.short_record(ftype, opl2opk.name8(name) + b'\x00')
        addr = 10 + len(self.body) + len(rec) + 4
        self.body += rec + opl2opk.long_record(body)
        self.files.append((name.upper(), ftype, addr, len(body)))
        return addr

    def add_proc_ob3(self, path):
        name, rec, _ = opl2opk.ob_block(path)
        addr = 10 + len(self.body)
        self.body += rec
        self.files.append((name, 0x83, addr, len(rec)))

    def add_opl(self, path, source=True):
        tgt = self.target

        class A:
            no_translate = False
            target = tgt
            strip_indent = True
            encoding = 'latin-1'
        name, rec, _ = opl2opk.opl_procedure(path, A, quiet=True)
        if not source:
            rec = strip_source(rec)
        self.body += rec
        return name

    def add_data(self, name, data):
        """A data block: returns the pack address of the data's first byte."""
        body = stub_block(data, self.target)
        a = self.add(0x83, name, body)
        return a + 2 + (DATA_OFFSET if self.target == 'cm' else DATA_OFFSET_LZ)

    def bytes(self):
        need = 10 + len(self.body) + 2
        size = self.size_k
        if size is None:
            size = next(s for s in SIZES if need <= s * 1024 and (self.kind != 'rampak' or s >= 32))
        if need > size * 1024:
            raise ValueError('pack contents %d bytes do not fit %dK' % (need, size))
        data = header(size, self.kind) + bytes(self.body) + b'\xFF\xFF'
        return b'OPK' + bytes([(len(data) >> 16) & 255, (len(data) >> 8) & 255, len(data) & 255]) + data, size, need

    def write(self, path):
        img, size, need = self.bytes()
        with open(path, 'wb') as f:
            f.write(img)
        return size, need
