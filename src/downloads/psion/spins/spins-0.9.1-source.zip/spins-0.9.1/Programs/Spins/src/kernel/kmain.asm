; ---------------------------------------------------------------------
; The game's main loop: the screen at rest (OV_REST) returns a command.
; A spin: the stake (OV_BANK), the result (OV_GAME), paid and saved
; (OV_BANK), then shown (the directors). Overlays cannot call overlays,
; so the order lives here.
; ---------------------------------------------------------------------
gm_main:
        bsr  ovc
        fcb  OV_BANK, B_LOAD
        ldaa #S_TITLE           ; the title (any key skips it)
        bsr  cm_scene
        bsr  ovc                ; Christmas Day?
        fcb  OV_BANK, B_DATE
        bra  gm_cmd
gm_loop:
        bsr  ovc                ; A = a command
        fcb  OV_REST, 0
; gm_cmd: A = a command: done; each overlay's entry returns the next one
gm_cmd: tsta
        beq  gm_loop
        cmpa #C_SPIN
        beq  .sp
        cmpa #C_QUIT
        beq  .quit
        cmpa #C_XMAS            ; (a gift's Xmas Spins)
        beq  .xm
        cmpa #C_LAST
        bhi  gm_loop
        suba #C_MENU            ; the table on the pack (IT_CMDS, tools/build.py
        asla                    ; CMDS): overlay and entry
        staa kv_t0
        ldaa #IT_CMDS
        jsr  pk_item
        os   PK$RWRD            ; (its length)
        clra
        ldab kv_t0
        os   PK$SKIP
        os   PK$RWRD
        jsr  ov_call
        bra  gm_cmd
.quit:  ldaa #S_BYE             ; the goodbye, then saved and out
        bsr  cm_scene
        bsr  ovc
        fcb  OV_BANK, B_SAVE
        rts
.sp:    bsr  cm_spin
        bra  gm_loop
.xm:    bsr  cm_xmas
        bra  gm_loop

; ovc: calls the overlay and entry in the two bytes after the bsr (returns
; past them, with ov_call's A and carry)
ovc:    pulx
        ldd  0,x
        inx
        inx
        pshx
        jmp  ov_call

; A = a scene: played
cm_scene:
        staa kv_arg
        ldd  #OV_SCENE*256
        jmp  ov_call

cm_spin:
        bsr  ovc
        fcb  OV_BANK, B_STAKE
        bcs  .short             ; not enough (OV_BANK has said so)
        bsr  ovc
        fcb  OV_GAME, G_SPIN
        bsr  ovc
        fcb  OV_BANK, B_SETTLE
        bsr  ovc
        fcb  OV_SPINFX, SF_BASE
        tst  kv_santa
        beq  .w
        bsr  ovc                ; the walk's style and its tune
        fcb  OV_HOME, 1
        bsr  ovc                ; A: how his walk ended
        fcb  OV_WALK, 0
        staa kv_arg
        bsr  ovc
        fcb  OV_HOME, 0
.w:     bsr  ovc
        fcb  OV_WINFX, WF_BASE
        ldaa kv_screq           ; a big win (1) or a huge one (2): its scene
        beq  .f
        adda #S_BIG-1
        bsr  cm_scene
.f:     tst  kv_fn            ; the Xmas Spins (cm_xmas returns for us)
        bne  cm_xmas
.x:     rts
.short: inc  kv_short            ; (autoplay stops)
        cmpa #2                 ; topped up: Santa brings 500
        bne  .x
        ldaa #S_BROKE
        bsr  cm_scene
        bra  cm_cu

; the Xmas Spins, replayed from their random state (already paid); OV_GAME
; sets the show up and counts the spins as they come
cm_xmas:
        bsr  ovc
        fcb  OV_GAME, G_XINIT
        ldaa #S_XSTART
        bsr  cm_scene
.l:     inc  kv_fidx
        bsr  ovc
        fcb  OV_XFX, X_PANEL
        bsr  ovc
        fcb  OV_GAME, G_FREE
        bsr  ovc
        fcb  OV_SPINFX, SF_FREE
        bsr  ovc
        fcb  OV_XFX, X_THROW
        bsr  ovc
        fcb  OV_WINFX, WF_FREE
        tst  kv_fleft
        bne  .l
        ldaa #S_XEND            ; the feature's pay counts up in its scene
        bsr  cm_scene
cm_cu:  bsr  ovc                ; (and here, if that was cut short)
        fcb  OV_WINFX, WF_COUNT
        rts
