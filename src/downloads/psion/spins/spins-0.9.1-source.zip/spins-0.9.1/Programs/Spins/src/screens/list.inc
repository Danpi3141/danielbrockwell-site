; ---------------------------------------------------------------------
; (Included by the overlays with lists: the menu, settings, jukebox...)
; ls_run: X = a list (a title with its length, then the count, then the
; items, each with its length), A = the item to start on. The whole
; screen: the title on the top line, then the items, the chosen one
; marked >. UP and DOWN move (round), a letter goes to the next item
; starting with it, EXE chooses, ON or MODE goes back.
; Out: B = the item, carry clear; carry set: back. A = the key that
; chose (EXE, LEFT or RIGHT: ls_lr set lets LEFT and RIGHT choose too).
; ---------------------------------------------------------------------
ls_run: staa ls_sel
        stx  ls_ttl
        ldab 0,x                ; the items: after the title
        incb
        abx
        ldaa 0,x
        staa ls_n
        inx
        stx  ls_it
.draw:  jsr  cls
        ldx  ls_ttl             ; the title
        clrb
        jsr  txt_at
        ldaa kv_h               ; the first item shown: the chosen one is on
        deca                    ; screen (h - 1 lines for items)
        staa ls_t
        clrb
        ldaa ls_sel
        suba ls_t
        bmi  .f
        inca
        tab
.f:     stab ls_top
        ldaa #1                 ; screen line 1 on
        staa ls_ln
.it:    ldab ls_top
        cmpb ls_n
        bhs  .key
        ldaa ls_ln
        cmpa kv_h
        beq  .key
        jsr  ls_item            ; X = item ls_top
        ldaa ls_ln
        ldab kv_w
        mul
        incb
        pshb
        jsr  txt_at
        pulb
        decb
        ldaa ls_top             ; the marker
        cmpa ls_sel
        bne  .nm
        ldaa #'>'
        jsr  put
.nm:    inc  ls_top
        inc  ls_ln
        bra  .it
.key:   clra
        jsr  key_wait
        cmpb #K_DOWN
        bne  .up
        inc  ls_sel
        ldaa ls_sel
        cmpa ls_n
        bne  .mv
        clr  ls_sel
        bra  .mv
.up:    cmpb #K_UP
        bne  .ex
        dec  ls_sel
        bpl  .mv
        ldaa ls_n
        deca
        staa ls_sel
.mv:    ldx  #ls_click
        jsr  snd_fx
        ldaa #2
        jsr  frame_t
        jmp  .draw
.ex:    cmpb #K_EXE
        beq  .ch
        tst  ls_lr
        beq  .on
        cmpb #K_LEFT
        beq  .ch
        cmpb #K_RIGHT
        beq  .ch
.on:    cmpb #K_ON
        beq  .back
        cmpb #K_MODE
        beq  .back
        cmpb #'A'               ; a letter: the next item starting with it
        blo  .key
        cmpb #'Z'
        bhi  .key
        stab ls_t
        ldaa ls_sel
        staa ls_ln
.lt:    inc  ls_ln
        ldaa ls_ln
        cmpa ls_n
        blo  .lc
        clr  ls_ln
.lc:    ldab ls_ln
        cmpb ls_sel
        beq  .key               ; (round again: none)
        stab ls_top
        jsr  ls_item
        ldaa 1,x
        cmpa ls_t
        bne  .lt
        ldaa ls_ln
        staa ls_sel
        bra  .mv
.ch:    tba
        ldab ls_sel
        clc
        rts
.back:  sec
        rts

; X = item ls_top of the list
ls_item:
        ldx  ls_it
        ldab ls_top
        beq  .x
.l:     pshb
        ldab 0,x
        incb
        abx
        pulb
        decb
        bne  .l
.x:     rts

ls_click: fcb 5,2,$FF
ls_sel: fcb  0
ls_n:   fcb  0
ls_top: fcb  0
ls_ln:  fcb  0
ls_t:   fcb  0
ls_lr:  fcb  0
ls_ttl: fdb  0
ls_it:  fdb  0
