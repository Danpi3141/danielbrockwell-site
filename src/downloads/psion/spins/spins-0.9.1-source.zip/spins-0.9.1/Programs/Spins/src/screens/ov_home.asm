; =====================================================================
; OV_HOME: the end of Santa's visit, after OV_WALK (kv_arg = how it
; ended: 0 he shrugged, 1 he cheers on the far side, 2 the houses change
; at once). The houses become presents (in three steps while he
; cheers), he vanishes and is back on reel 1 with a sleigh bell.
; =====================================================================
        include "../defs.inc"

A_CH1   = 0                     ; the HOME blob: the change's three steps
E_CHANGE = 0
E_SLEIGH = 1

        jmp  oh_go
        jmp  oh_pre             ; 1: before the walk

; entry 1, before OV_WALK: kv_arg = the reels with a house (bits 1-4),
; kv_arg+1 = the style (at random, or the standard walk: kv_styles); its
; tune starts
oh_pre: clr  oh_k               ; the house reels
        ldaa #1
        staa oh_r
.m:     clr  oh_y
.y:     jsr  oh_sym
        cmpa #8
        bne  .ny
        ldab oh_r
        jsr  gbit
        oraa oh_k
        staa oh_k
.ny:    inc  oh_y
        ldaa oh_y
        cmpa kv_rows
        bne  .y
        inc  oh_r
        ldaa oh_r
        cmpa #5
        bne  .m
        clrb                    ; the style
        tst  kv_styles
        bne  .st
        jsr  rng_cos
        anda #31
        ldab #$FF               ; (0-31: 10 walk, 4 heavy, 4 tiptoe, 3 skip,
                                ; 3 ice, 3 sledge; 2 pogo, 1 moonwalk, 1 reindeer,
                                ; 1 parachute)
        ldx  #oh_pick
.pk:    incb
        cmpa 0,x
        inx
        bhs  .pk
.st:    ldaa oh_k
        std  kv_arg
        tst  kv_anim
        beq  .x
        ldx  #oh_tunes          ; its tune
        abx
        ldaa 0,x
        jsr  tune_go
.x:     rts
oh_pick: fcb 10,14,18,21,24,27,29,30,31,255
oh_tunes: fcb IT_T_JINGLE,IT_T_WENCES,IT_T_DINGDONG,IT_T_GODREST,IT_T_JINGLE,IT_T_NOWELL
        fcb  IT_T_JOY,IT_T_DECK,IT_T_JINGLE,IT_T_HARK
; A = the symbol at reel oh_r, row oh_y
oh_sym: ldaa oh_r
        asla
        asla
        adda oh_y
        tab
        ldx  #kv_grid
        abx
        ldaa 0,x
        rts

oh_go:  ldaa #IT_HOME
        ldx  #oh_data
        stx  kv_scene
        jsr  pk_load
        ldaa kv_arg
        cmpa #1
        bne  .now
        ldaa #E_CHANGE          ; the change, while he cheers
        bsr  oh_fx
        clr  oh_k
.c:     ldaa oh_k
        bsr  oh_art3
        bsr  oh_settle
        ldaa #4
        jsr  frame
        inc  oh_k
        ldaa oh_k
        cmpa #3
        bne  .c
        clr  oh_k               ; he vanishes: the frozen window's cells back
.v:     ldab oh_k
        ldx  #kv_wsave
        abx
        ldaa 0,x
        cmpa #$FF
        beq  .vn
        staa oh_c
        ldaa kv_spy             ; its cell: (spy + k / 2) * w + wc + k mod 2
        ldab oh_k
        bitb #2
        beq  .vr
        inca
.vr:    ldab kv_w
        mul
        addb kv_wc
        stab oh_y
        ldab oh_k
        andb #1
        addb oh_y
        ldaa oh_c
        jsr  put
.vn:    inc  oh_k
        ldaa oh_k
        cmpa #4
        bne  .v
        bra  oh_home
.now:   tsta                    ; (0: he shrugged: nothing to change)
        beq  oh_home
        ldaa #A_CH1+2
        bsr  oh_art3
; home: every house shows its glyph again; Santa back on reel 1
oh_home:
        bsr  oh_settle
        ldx  #oh_none
        jsr  pn_msg
        clr  kv_tnt             ; (the tune stops)
        ldaa #IT_SANTA          ; him standing: glyphs 4 and 5
        ldx  #kv_glyph+32
        jsr  pk_load
        ldaa kv_gdirty
        oraa #$30
        staa kv_gdirty
        clrb                    ; his cells (a + above and below on four lines)
        tst  kv_four
        beq  .t
        ldaa #'+'
        jsr  put
        ldaa #'+'
        ldab #60
        jsr  put
        ldab #20
.t:     ldaa #4
        pshb
        jsr  put
        pulb
        addb kv_w
        ldaa #5
        jsr  put
        ldaa #E_SLEIGH
        bsr  oh_fx
        ldaa #10
        jmp  frame

; A = art: glyph 3 (the house) becomes it
oh_art3:
        ldab #2
        jsr  sc_tab
        ldaa #3
        jmp  glyph_ld
; A = an effect of the blob
oh_fx:  ldab #6
        jsr  sc_tab
        jmp  snd_fx
; every house cell on reels 2-5 shows the house glyph (not +)
oh_settle:
        ldaa #1
        staa oh_r
.r:     clr  oh_y
.y:     ldaa oh_r               ; kv_grid[reel * 4 + row]
        asla
        asla
        adda oh_y
        tab
        ldx  #kv_grid
        abx
        ldaa 0,x
        cmpa #8
        bne  .n
        ldx  #kv_reelx          ; its cell
        ldab oh_r
        abx
        ldaa oh_y
        ldab kv_w
        mul
        addb 0,x
        ldaa #3
        jsr  put
.n:     inc  oh_y
        ldaa oh_y
        cmpa kv_rows
        bne  .y
        inc  oh_r
        ldaa oh_r
        cmpa #5
        bne  .r
        rts

oh_none: fcb 0
oh_k:   fcb  0
oh_c:   fcb  0
oh_r:   fcb  0
oh_y:   fcb  0
oh_data:                        ; the blob, read in here
