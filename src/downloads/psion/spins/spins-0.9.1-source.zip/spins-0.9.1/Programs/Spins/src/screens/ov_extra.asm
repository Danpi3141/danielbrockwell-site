; =====================================================================
; OV_EXTRA: the jukebox (any of the twelve carols; any key stops one)
; and the scenes already seen, to play again.
; =====================================================================
        include "../defs.inc"

        jmp  ox_juke
        jmp  ox_scenes

ox_juke:
        clr  ls_lr
        clr  ox_at
.l:     ldaa ox_at
        ldx  #ox_tunes
        jsr  ls_run
        bcs  .x
        stab ox_at
        ldx  #ox_items          ; its item: played under empty frames
        abx
        ldaa 0,x
        jsr  tune_go
        ldx  #ox_play           ; "PLAYING" on the title line
        ldab #9
        jsr  txt_at
.p:     ldaa #10
        jsr  frame_t
        tst  kv_key
        bne  .k
        tst  kv_tnt
        bne  .p
        bra  .l
.k:     os   KB$GETK
        jsr  snd_stop
        bra  .l
.x:     clra
        rts
ox_play: fcl "PLAYING"
ox_items: fcb IT_T_JINGLE,IT_T_DECK,IT_T_WISH,IT_T_JOY,IT_T_WENCES,IT_T_DINGDONG
        fcb  IT_T_SILENT,IT_T_HARK,IT_T_TREE,IT_T_GODREST,IT_T_NOWELL,IT_T_MANGER
ox_tunes: fcl "JUKEBOX"
        fcb  12
        fcl  "Jingle Bells"
        fcl  "Deck the Halls"
        fcl  "We Wish You"
        fcl  "Joy to the World"
        fcl  "King Wenceslas"
        fcl  "Ding Dong"
        fcl  "Silent Night"
        fcl  "Hark the Herald"
        fcl  "O Xmas Tree"
        fcl  "God Rest Ye"
        fcl  "First Nowell"
        fcl  "Away in a Manger"

; the scenes: any one seen already
ox_scenes:
        clr  ls_lr
.l:     clra
        ldx  #ox_snames
        jsr  ls_run
        bcs  .x
        stab kv_arg             ; seen?
        ldaa st_seen+1
        cmpb #8
        blo  .b
        ldaa st_seen
        subb #8
.b:     tstb
        beq  .t
.s:     lsra
        decb
        bne  .s
.t:     lsra
        bcs  .go
        ldx  #ox_err            ; not yet
        jsr  snd_fx
        ldaa #10
        jsr  frame_t
        bra  .l
.go:    ldaa #C_SCENE
        rts
.x:     clra
        rts
ox_err: fcb  1,20,0,1,$FF
ox_snames: fcl "SCENES"
        fcb  14
        fcl  "Title"
        fcl  "Xmas Spins"
        fcl  "Xmas Spins end"
        fcl  "Big win"
        fcl  "Huge win"
        fcl  "Full house"
        fcl  "Out of credits"
        fcl  "Village"
        fcl  "Chimney"
        fcl  "Reindeer"
        fcl  "Goodbye"
        fcl  "Christmas Day"
        fcl  "Advent"
        fcl  "New Year"
ox_at:  fcb  0

        include "list.inc"
