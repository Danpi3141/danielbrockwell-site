// The variables kept outside the array (src/kernel/kvars.inc), in the launchers' code that never
// runs again once the game has started: KH in SANTAG's code before its USR call (below the array),
// KR in SANTA's code before its call of SANTAG (above it). Checked on every ROM: the launchers'
// code that does run again (SANTAG from USR on, SANTA's 84 7B after the call) is in RAM where the
// build says, intact, after some play; leaving goes back to the OS cleanly (no "SPINS ERROR", no
// OPL error), and starting again resumes with the same credits. And SANTAG run by itself is
// refused ("SPINS ERROR 3") before it touches anything.
//   node tests/t_hidden.js [all | rom,rom...]
'use strict';
const fs = require('fs'), path = require('path');
const { Game, ROMS, ROOT } = require('./lib');

const bdir = path.join(ROOT, 'build', 'game');
const meta = JSON.parse(fs.readFileSync(path.join(bdir, 'build.json'), 'utf8'));
const opk = fs.readFileSync(path.join(bdir, 'SPINS.opk'));
function qcode(name) {
  const i = opk.indexOf(Buffer.from(name.padEnd(8)));
  const b = i + 9 + 4, ol = opk[b] << 8 | opk[b + 1];
  const obj = opk.slice(b + 2, b + 2 + ol), ql = obj[2] << 8 | obj[3];
  return obj.slice(obj.length - ql);
}
const qg = qcode('SANTAG'), qs = qcode('SANTA');
const keepG = qg.slice(meta.kh_len);                       // SANTAG from USR on
const assert = (c, m) => { if (!c) throw new Error(m); };
const arg = process.argv[2] || 'all';
const roms = arg === 'all' ? Object.keys(ROMS) : arg.split(',');
let bad = 0;
for (const rom of roms) {
  try {
    const g = new Game(rom);
    g.start();
    const check = (when) => {
      g.sync();
      const ga = g.base + meta.kh + meta.kh_len;
      const got = g.m.read(ga, keepG.length);
      assert(got.every((v, i) => v === keepG[i]), `${when}: SANTAG's code from USR on at ${meta.kh + meta.kh_len}: ` + Buffer.from(got).toString('hex'));
      const ra = g.base + meta.kr + meta.kr_len;
      const gr = g.m.read(ra, 2);
      assert(gr[0] === 0x84 && gr[1] === 0x7B, `${when}: SANTA's 84 7B at ${meta.kr + meta.kr_len}: ` + gr.map((v) => v.toString(16)).join(' '));
      // and SANTA's code before the hole is SANTA's (the hole is where the build says)
      const pre = g.m.read(ra - meta.kr_len - 0, meta.kr_len + 2);
      assert(pre.length === meta.kr_len + 2, 'read');
    };
    check('at the start');
    const seed = g.seedFor((b) => b.santa && b.houses >= 1 && b.total > 0 && !b.freeSpins, 1);
    g.spin(seed, 1);
    g.press('MODE'); g.run(0.6); g.press('ON'); g.run(0.5);
    g.spin(g.seedFor((b) => b.freeSpins > 0, 1), 2);
    check('after play');
    const bal = g.peek32('kv_bal');
    g.press('ON'); g.run(0.6); g.press('EXE'); g.run(6);
    assert(!/ERROR|FEHLER|ERREUR|ERRORE|FEL/.test(g.text()), 'after leaving: ' + g.text());
    assert(g.m.isOn(), 'switched off after leaving');
    g.m.runSeconds(1.5);
    assert(!/ERROR|FEHLER|ERREUR|ERRORE|FEL/.test(g.text()), 'an error after leaving: ' + g.text());
    g.start(30, true);
    assert(g.peek32('kv_bal') === bal, `resumed with ${g.peek32('kv_bal')} credits (were ${bal})`);
    check('after starting again');
    console.log(`${rom.padEnd(14)} ok   (credits ${bal})`);
  } catch (e) {
    bad++;
    console.log(`${rom.padEnd(14)} FAIL ${e.message.split('\n').slice(0, 3).join(' | ')}`);
  }
}
// SANTAG by itself: refused
{
  const g = new Game('lz64');
  g.m.runProc('SANTAG', 'B');
  g.run(4);
  const ok = /SPINS ERROR 3/.test(g.text());
  console.log(`SANTAG alone   ${ok ? 'ok   refused' : 'FAIL ' + g.text().replace(/\n/g, '|')}`);
  if (!ok) bad++;
}
console.log(bad ? `${bad} FAILED` : `all ${roms.length} ROMs ok`);
process.exit(bad ? 1 : 0);
