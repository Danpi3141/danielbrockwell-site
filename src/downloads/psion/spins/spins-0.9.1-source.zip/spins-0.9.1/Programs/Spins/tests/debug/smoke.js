const { Game } = require('../lib');
for (const model of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'lz64']) {
  const g = new Game(model);
  g.start();
  g.run(1);
  console.log(model, 'base', g.base.toString(16));
  console.log(g.text());
  console.log('udg0', g.m.udg(0), 'udg3', g.m.udg(3));
  g.press('EXE'); g.run(1);
  console.log('after EXE:\n' + g.text());
}
