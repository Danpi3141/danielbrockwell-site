const { Game } = require('../lib');
const g = new Game(process.argv[2] || 'lz64');
g.start();
const seed = 4608;
const names = Object.fromEntries(Object.entries(g.ids()).map(([k, v]) => [v, k]));
let n = 0;
try {
  g.spin(seed, 0.5, (t) => {
    if (n++ < 30) console.log(t, names[g.peek('kv_res')], 'pc', (g.m.dbg.pc() - g.base).toString(16), 'sp', g.m.dbg.sp().toString(16), g.scr().map(l=>l.slice(0,10)).join('|'));
  }, 15);
} catch (e) { console.log(e.message); }
