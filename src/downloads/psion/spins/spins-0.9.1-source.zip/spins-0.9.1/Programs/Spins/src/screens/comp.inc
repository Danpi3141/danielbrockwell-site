; ---------------------------------------------------------------------
; (Included by the directors that show Santa: the frame player calls
; compose through kv_comp while one of them is in slot A.)
; The compositor: Santa (or any 5 x 16 pose) in a window of the four
; stage characters 4-7, two columns by two rows, over whatever the cells
; show, with a halo one dot wide cleared round him.
;
; Steps: six to a character (five dots and the unlit gap). kv_spx is his
; left edge in steps from the screen's left; kv_spy the window's top row.
; The window's cells keep their own characters in kv_wsave ($FF: a cell
; not taken, such as panel text, whose shape is not known: left alone).
; Window cells: 0 top left (glyph 4), 1 top right (5), 2 bottom left
; (6), 3 bottom right (7). Writes to cells go through wput.
; ---------------------------------------------------------------------

; sp_on: A = top row: the window opens at kv_spx (pose already set)
sp_on:  staa kv_spy
        ldaa #$FF               ; (no cells taken yet)
        staa kv_wc
        ldx  #compose           ; the frame player calls it
        stx  kv_comp
        rts

; sp_off: the window closes, its cells get their own characters back
sp_off: ldx  kv_comp
        beq  sp_x
        bsr  w_give
; sp_freeze: the window stays as drawn, but no longer follows Santa
sp_freeze:
        clr  kv_comp
        clr  kv_comp+1
sp_x:   rts

; sp_pose: X = a pose (10 bytes, packed): it and its halo set
sp_pose:
        jsr  pose_unpack
        ldx  #kv_pose           ; halo: the rows above and below and this, grown
        clrb                    ; one dot each way (7 bits: positions -1..5);
        clr  kv_t1              ; the line gap parts the two characters
.h:     ldaa 0,x
        oraa kv_t1              ; the row above
        cmpb #7
        beq  .h2
        cmpb #15
        beq  .h2
        oraa 1,x                ; the row below
.h2:    staa kv_t0
        asla                    ; q | q<<1 | q<<2
        oraa kv_t0
        asla
        oraa kv_t0
        staa 16,x               ; kv_halo follows kv_pose
        ldaa 0,x
        cmpb #7
        bne  .h3
        clra
.h3:    staa kv_t1
        inx
        incb
        cmpb #16
        bne  .h
        rts

; compose: the window to kv_spx, and its four glyphs built (by frame)
compose:
        clra                    ; col = spx / 6, o = spx mod 6
        ldab kv_spx
.d:     cmpb #6
        blo  .dn
        subb #6
        inca
        bra  .d
.dn:    stab kv_wo
        cmpa kv_wc
        beq  .same
        psha
        bsr  w_give             ; the old cells back
        pula
        staa kv_wc
        bsr  w_take             ; the new ones into the window
.same:  clr  kv_t2              ; rows 0-15: both of the row's cells at once
.r:     ldx  #kv_pose
        ldab kv_t2
        abx
        ldaa 0,x                ; the sprite: p << (7 - o)
        ldab #7
        bsr  .place
        std  kv_wsp
        ldaa 16,x               ; its halo: h << (6 - o)
        ldab #6
        bsr  .place
        std  kv_whl
        clrb                    ; the left cell: bits 11-7
        ldaa kv_t2
        cmpa #8
        blo  .t
        ldab #2
.t:     stab kv_t3              ; window cell 0 or 2
        ldd  kv_wsp
        asld
        anda #$1F
        staa kv_t0
        ldd  kv_whl
        asld
        anda #$1F
        bsr  .mix
        inc  kv_t3              ; the right cell: bits 5-1
        ldd  kv_wsp
        lsrd
        andb #$1F
        stab kv_t0
        ldd  kv_whl
        lsrd
        tba
        anda #$1F
        bsr  .mix
        inc  kv_t2
        ldaa kv_t2
        cmpa #16
        bne  .r
        ldaa kv_gdirty
        oraa #$F0
        staa kv_gdirty
        rts
; A = halo bits, kv_t0 = sprite bits, kv_t3 = window cell: this row of
; its glyph = (its own shape's row & ~halo) | sprite
.mix:   coma
        staa kv_t1
        ldab kv_t3
        ldx  #kv_wsave
        abx
        ldaa 0,x
        bsr  w_shape            ; X = the shape's rows (blank if not known)
        ldab kv_t2              ; the row within the glyph
        andb #7
        stab kv_wcnt
        abx
        ldaa 0,x
        anda kv_t1
        oraa kv_t0
        psha
        ldab kv_t3              ; glyph 4 + cell
        addb #4
        aslb
        aslb
        aslb
        addb kv_wcnt
        ldx  #kv_glyph
        abx
        pula
        staa 0,x
        rts
; A = bits, B = shift base: D = A << (B - o) (o = kv_wo; B - o >= 1)
.place: subb kv_wo
        stab kv_wcnt
        tab
        clra
.s:     asld
        dec  kv_wcnt
        bne  .s
        rts

; w_cell: B = window cell 0-3: B = its screen index (kv_wc, kv_spy)
w_cell: pshb
        ldaa kv_spy
        bitb #2
        beq  .r
        inca
.r:     ldab kv_w
        mul
        addb kv_wc
        pula
        bita #1
        beq  .x
        incb
.x:     rts

; w_take: the window's cells: their characters into kv_wsave, the stage
; characters into kv_under (if their shapes are known; else $FF kept)
w_take: clr  kv_t3
.l:     ldab kv_t3
        ldx  #kv_wsave
        abx
        stx  kv_t0
        ldaa #$FF               ; (not taken)
        staa 0,x
        bitb #1                 ; a right-hand cell past the screen's edge?
        beq  .in
        ldaa kv_wc
        inca
        cmpa kv_w
        bhs  .n
.in:    bsr  w_cell
        ldx  #kv_under
        abx
        stx  kv_t1
        ldaa 0,x
        bsr  w_shape            ; a shape we know?
        bcs  .n
        ldx  kv_t1
        ldaa 0,x
        ldx  kv_t0
        staa 0,x
        ldaa kv_t3
        adda #4
        ldx  kv_t1
        staa 0,x
        inc  kv_cdirty
.n:     inc  kv_t3
        ldaa kv_t3
        cmpa #4
        bne  .l
        rts

; w_give: the window's cells get their characters back
w_give: ldaa kv_wc
        cmpa #$FF
        beq  .x
        clrb
.l:     pshb
        ldx  #kv_wsave
        abx
        ldaa 0,x
        cmpa #$FF
        beq  .n
        psha
        bsr  w_cell
        pula
        jsr  put
.n:     pulb
        incb
        cmpb #4
        bne  .l
        ldaa #$FF
        staa kv_wc
.x:     rts

; wput: A = character, B = screen index: into the cell, or into the
; window's copy of it if the window holds that cell
wput:   ldx  kv_comp
        beq  .u
        psha
        pshb
        clrb
.l:     stab kv_t3
        bsr  w_cell
        tsx
        cmpb 0,x
        bne  .n
        ldab kv_t3              ; a window cell
        ldx  #kv_wsave
        abx
        ldaa 0,x
        cmpa #$FF
        beq  .uu                ; (not taken: the cell itself)
        pulb
        pula
        staa 0,x
        rts
.n:     ldab kv_t3
        incb
        cmpb #4
        bne  .l
.uu:    pulb
        pula
.u:     jmp  put

; w_shape: A = a character: X = its 8 rows, carry clear; carry set (and
; X = a blank shape) if its shape is not known. Glyphs 0-3 from
; kv_glyph; others from the font table at kv_fontp (count, then a
; character and its 8 rows each).
w_shape:
        cmpa #4
        bhs  .f
        tab
        aslb
        aslb
        aslb
        ldx  #kv_glyph
        abx
        clc
        rts
.f:     ldx  #w_blank
        cmpa #' '
        beq  .k
        ldx  kv_fontp
        ldab 0,x
        inx
.l:     cmpa 0,x
        beq  .y
        pshb
        ldab #9
        abx
        pulb
        decb
        bne  .l
.no:    ldx  #w_blank
        sec
        rts
.y:     inx
.k:     clc
        rts
w_blank: fcb 0,0,0,0,0,0,0,0
