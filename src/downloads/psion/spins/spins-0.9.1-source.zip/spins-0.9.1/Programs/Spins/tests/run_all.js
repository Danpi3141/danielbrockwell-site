// The test suite: node tests/run_all.js [--quick]
// (--quick: fewer spins, one model per test; the long ones - t_long, t_stress, t_roms, t_skip,
// m_mem - are listed in the README and run on their own)
'use strict';
const { execFileSync } = require('child_process');
const path = require('path');
const quick = process.argv.includes('--quick');
const T = (f, ...a) => [f, a];
const tests = [
  T('t_linefast.js'),
  T('t_game.js', 'lz64', quick ? '100' : '500'), T('t_game.js', 'cm', quick ? '100' : '500'),
  T('t_sound.js', 'lz64'),
  T('t_walk.js', 'lz64', '99'), T('t_walk.js', 'cm', '99'),
  T('t_flow.js', 'lz64', 'santa', '30000'), T('t_flow.js', 'cm', 'feature', '30000'),
  ...(quick ? [] : [T('t_flow.js', 'lz64', 'feature', '30000'), T('t_flow.js', 'cm', 'santa', '30000'), T('t_flow.js', 'lz64', 'win', '30000')]),
  T('t_save.js', 'cm'), ...(quick ? [] : [T('t_save.js', 'lz64')]),
  T('t_auto.js', 'lz64'),
  T('t_xmasday.js', 'cm'),
  T('t_stretch.js', quick ? 'lz64' : 'cm'),
];
let bad = 0;
for (const [f, a] of tests) {
  const t0 = Date.now();
  let ok = true;
  try { execFileSync('node', [path.join(__dirname, f), ...a], { stdio: 'pipe', timeout: 1800000 }); } catch (e) { ok = false; bad++; console.log(String(e.stdout || '').slice(-2000)); }
  console.log(`${ok ? 'ok  ' : 'FAIL'} ${f} ${a.join(' ')} (${((Date.now() - t0) / 1000).toFixed(0)} s)`);
}
console.log(bad ? `${bad} failed` : 'all passed');
process.exit(bad ? 1 : 0);
