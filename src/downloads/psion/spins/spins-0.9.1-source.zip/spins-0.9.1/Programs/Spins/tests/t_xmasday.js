// Christmas Day: on 25 December the greeting and 250 credits, once a year.
const { Game } = require('./lib');
const model = process.argv[2] || 'lz64';
const g = new Game(model);
g.m.poke(0x20C6, 11); g.m.poke(0x20C7, 24);       // the clock: 25 December
g.m.runProc('SANTA', 'B');
const seen = [];
for (let i = 0; i < 80; i++) { g.run(0.25); const t = g.text(); if (/CHRISTMAS/.test(t) && !seen.length) seen.push(t); if (g.sync() >= 0 && g.peek('kv_res') === g.ids().OV_REST) break; }
g.start(20, false);
console.log(seen[0] || 'no greeting seen');
console.log('credits', g.peek32('kv_bal'), 'gift year', g.peek('st_gift'));
const ok = seen.length && g.peek32('kv_bal') === 1250;
process.exit(ok ? 0 : 1);
