// PNG pictures of the LCD (no dependencies): lcdPng(game) -> Buffer; sheet(frames, cols) -> Buffer
'use strict';
const zlib = require('zlib');
const CRC = (() => { const t = []; for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t.push(c >>> 0); } return t; })();
function crc(buf) { let c = 0xFFFFFFFF; for (const b of buf) c = CRC[(c ^ b) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
function chunk(type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type), data]);
  const c = Buffer.alloc(4); c.writeUInt32BE(crc(td));
  return Buffer.concat([len, td, c]);
}
function png(w, h, rgb) {   // rgb: Uint8Array w*h*3
  const raw = Buffer.alloc((w * 3 + 1) * h);
  for (let y = 0; y < h; y++) { raw[y * (w * 3 + 1)] = 0; rgb.copy ? rgb.copy(raw, y * (w * 3 + 1) + 1, y * w * 3, (y + 1) * w * 3) : raw.set(rgb.subarray(y * w * 3, (y + 1) * w * 3), y * (w * 3 + 1) + 1); }
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}
const BG = [0x9e, 0xae, 0x8a], ON = [0x22, 0x26, 0x1e], OFF = [0x92, 0xa2, 0x80], EDGE = [0x30, 0x34, 0x2c];
// the LCD as a bitmap: S pixels a dot, a 1-dot gap between characters and lines
function lcdBitmap(g, S = 4) {
  const m = g.m, W = m.cols, H = m.lines, c = m.cells(), font = m.font(), u = m.udgs();
  const pw = (W * 6 + 1) * S, ph = (H * 9 + 1) * S;
  const px = new Uint8Array(pw * ph * 3);
  for (let i = 0; i < pw * ph; i++) px.set(BG, i * 3);
  for (let r = 0; r < H; r++) for (let x = 0; x < W; x++) {
    const ch = c[r * W + x];
    for (let y = 0; y < 8; y++) {
      const row = ch < 8 ? u[ch][y] : (ch >= 32 ? font[(ch - 32) * 8 + y] : 0);
      for (let b = 0; b < 5; b++) {
        const lit = (row >> (4 - b)) & 1;
        const X0 = (x * 6 + 1 + b) * S, Y0 = (r * 9 + 1 + y) * S;
        for (let dy = 0; dy < S - 1; dy++) for (let dx = 0; dx < S - 1; dx++) px.set(lit ? ON : OFF, ((Y0 + dy) * pw + X0 + dx) * 3);
      }
    }
  }
  return { w: pw, h: ph, px };
}
function lcdPng(g, S) { const b = lcdBitmap(g, S); return png(b.w, b.h, b.px); }
// several bitmaps in a grid, with a border
function sheet(bms, cols = 4, pad = 6) {
  const w = bms[0].w, h = bms[0].h, rows = Math.ceil(bms.length / cols);
  const W = cols * (w + pad) + pad, H = rows * (h + pad) + pad;
  const px = new Uint8Array(W * H * 3);
  for (let i = 0; i < W * H; i++) px.set(EDGE, i * 3);
  bms.forEach((b, i) => {
    const ox = pad + (i % cols) * (w + pad), oy = pad + Math.floor(i / cols) * (h + pad);
    for (let y = 0; y < h; y++) px.set(b.px.subarray(y * w * 3, (y + 1) * w * 3), ((oy + y) * W + ox) * 3);
  });
  return png(W, H, px);
}
module.exports = { png, lcdBitmap, lcdPng, sheet };
