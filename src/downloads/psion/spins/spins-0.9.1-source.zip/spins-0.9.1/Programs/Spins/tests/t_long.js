// The long check (spec: "100,000 recorded spins give the same pay as the maths program, spin
// for spin"; "a million stops on each reel are evenly spread, by a chi-squared test"; "a long
// run lands within sampling error of the return"). One random sequence, as play goes: the
// 6303 engine (OV_GAME) against ref/game.js, every spin; the return, the hit rate; the stops'
// spread (base reels, and the free reels during features).
//   node tests/t_long.js [model] [spins] [seed]
const { Game } = require('./lib');
const R = require('../ref/game.js');
const model = process.argv[2] || 'lz64';
const N = +process.argv[3] || 100000;
const seed = +(process.argv[4] || 20261120) >>> 0;
const g = new Game(model);
g.start();
const four = g.m.lines === 4;
const G = R.grid(four ? 'four' : 'two');
const ids = g.ids();
const rng = new R.Rng(seed);
g.setRng(seed);
g.poke('kv_bet', 0);
const SYMS = 'MRBWAKQJHS*';
let bad = 0, paid = 0, hits = 0, feats = 0, big = 0;
const counts = [...Array(5)].map(() => new Array(32).fill(0));
const t0 = Date.now();
for (let i = 0; i < N; i++) {
  g.call(ids.OV_GAME, 0, { keep: false });
  const p = R.play(G, rng);
  const b = p.base;
  let err = '';
  for (let r = 0; r < 5; r++) { const s = g.peek('og_stops', r); counts[r][s]++; if (s !== b.stops[r]) err = 'stops'; }
  if (g.peekw('kv_lwin') !== b.total) err += ' lines';
  if (g.peek32('kv_win') !== p.total) err += ' win ' + g.peek32('kv_win') + ' v ' + p.total;
  if (g.peek32('kv_rng') !== rng.x) err += ' rng';
  if (err) { if (bad++ < 5) console.log('spin', i, err); g.setRng(rng.x); }
  paid += p.total;
  if (p.total) hits++;
  if (p.feature) feats++;
  if (p.total > big) big = p.total;
  if ((i + 1) % 20000 === 0) console.log(`${i + 1} spins, ${((Date.now() - t0) / 1000).toFixed(0)} s, return so far ${(paid / (i + 1) / 20 * 100).toFixed(2)}%`);
}
// chi-squared of the base stops: 31 degrees of freedom; 99.9% point 61.1
const chi = counts.map((c) => { const e = N / 32; return c.reduce((s, v) => s + (v - e) ** 2 / e, 0); });
console.log(`${model}: ${N} spins, ${bad} differ from the reference`);
console.log(`  return ${(paid / N / 20 * 100).toFixed(2)}% (exact ${four ? '95.73' : '95.73'}%), pays ${(hits / N * 100).toFixed(1)}%, features 1 in ${(N / feats).toFixed(1)}, biggest ${big / 20}x`);
console.log(`  stops chi-squared (31 df; 99.9% point 61.1): ${chi.map((c) => c.toFixed(1)).join(' ')}`);
process.exit(bad || chi.some((c) => c > 61.1) ? 1 : 0);
