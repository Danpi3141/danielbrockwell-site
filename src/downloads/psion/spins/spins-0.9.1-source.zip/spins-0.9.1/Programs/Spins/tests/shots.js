// Contact sheets: every scene, sampled at intervals, on a model. Writes build/shots/<model>_scene<n>.png
//   node tests/shots.js [model] [scene,...] [stepms]
const fs = require('fs'), path = require('path');
const { Game } = require('./lib');
const { lcdBitmap, sheet } = require('./png');
const model = process.argv[2] || 'lz64';
const which = (process.argv[3] || '0,1,2,3,4,5,6,7,8,9,10,11').split(',').map(Number);
const step = +(process.argv[4] || 250) / 1000;
const out = path.join(__dirname, '..', 'build', 'shots');
fs.mkdirSync(out, { recursive: true });
const g = new Game(model);
g.start();
const ids = g.ids();
for (const sc of which) {
  const bms = [];
  g.poke('kv_arg', sc);
  g.poke('kv_fn', 12);
  g.callSteps(ids.OV_SCENE, 0, step, () => { if (bms.length < 40) bms.push(lcdBitmap(g, 3)); }, 60);
  const f = path.join(out, `${model}_scene${sc}.png`);
  fs.writeFileSync(f, sheet(bms, g.m.lines === 4 ? 4 : 5));
  console.log(f, bms.length, 'frames');
}
