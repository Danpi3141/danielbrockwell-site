// Every memory write the game's own code makes, watched: while the processor runs code in the array
// (the kernel, the driver, an overlay), a write anywhere but the variables, region R, the holes in
// the launchers' code, the stack, the LCD and a short list of the OS's own variables is reported
// with the instruction that made it. The kernel's code and the driver are checked unchanged after
// every key. Random keys, random settings (poked at rest), random lengths of play.
//   node tests/t_watch.js [model] [seconds] [seed]
'use strict';
const { Game } = require('./lib');
const model = process.argv[2] || 'lz64';
const secs = +(process.argv[3] || 300);
let seed = +(process.argv[4] || 11);
const rnd = () => { seed = (seed * 1103515245 + 12345) >>> 0; return seed / 4294967296; };
const pick = (a) => a[Math.floor(rnd() * a.length)];
const g = new Game(model);
g.start();
const m = g.m, dbg = m.dbg, M = g.meta;
let base = g.base;
const OS_OK = new Set([0x7D, 0x7E]);    // OS variables the game writes: TMW_TOUT (the switch-off count, reset while waiting)
let lastPC = 0;
const inGame = (pc) => pc >= base && pc < base + M.total;
const odd = new Map();                    // 'pc>addr' -> count
let writes = 0;
dbg.setTrace((pc) => { lastPC = pc; });
const orig = m.bus.write.bind(m.bus);
m.bus.write = function (a, b) {
  if (base >= 0 && inGame(lastPC)) {
    writes++;
    const o = a - base;
    const ok = (o >= M.vstart && o < M.kmax) ||                         // kernel variables
      (o >= M.kmax + M.drv && o < M.total) ||                           // region R
      (o >= M.kh && o < M.kh + M.kh_used) || (o >= M.kr && o < M.kr + M.kr_used) || (o >= M.ks && o < M.ks + M.ks_used) ||
      (a >= 0x41 && a <= 0x49) ||                                       // T0-T7 (T7 two bytes): the sound engine's
      (a === 0x180 || a === 0x181) ||                                   // the LCD
      (Math.abs(a - dbg.sp()) <= 24) ||                                 // the stack
      OS_OK.has(a) || (o === 3 && lastPC - base === 0x22);           // (quit wipes the kernel's tag)
    if (!ok) {
      const k = `${(lastPC - base).toString(16)}>${a.toString(16)}${a >= base - 512 && a < base + M.total + 512 ? ' (array' + (o >= 0 ? '+' : '') + o + ')' : ''}`;
      odd.set(k, (odd.get(k) || 0) + 1);
    }
  }
  return orig(a, b);
};
const snap = () => m.read(base, M.vstart).concat(m.read(base + M.kmax, M.drv));
let code = snap();
const KEYS = ['EXE', 'EXE', 'EXE', 'EXE', 'UP', 'DOWN', 'LEFT', 'RIGHT', 'ON', 'MODE', 'A', 'P', 'L', 'S', 'G', 'J', 'H', 'X', 'M', 'B',
  'SPACE', 'DEL', 'Y', 'N', 'SHIFT', 'Z', 'Q'];
const SETS = [['kv_anim', 3], ['kv_styles', 2], ['kv_sound', 3], ['kv_music', 2], ['kv_glass', 4], ['kv_showw', 2], ['kv_astop', 3], ['kv_idle', 2], ['kv_bet', 4]];
let t = 0, keys = 0, restarts = 0, bad = 0, changed = 0;
const fail = (s) => { bad++; console.log(`FAIL at ${t.toFixed(0)} s: ${s}\n${g.text()}`); };
const rest = g.ids().OV_REST;
while (t < secs && bad < 3) {
  if (g.sync() >= 0 && g.peek('kv_res') === rest && rnd() < 0.15) {   // new settings at rest
    for (const [v, n] of SETS) if (rnd() < 0.5) g.poke(v, Math.floor(rnd() * n));
  }
  const k = pick(KEYS);
  const hold = rnd() < 0.1 ? 10 + Math.floor(rnd() * 40) : 2 + Math.floor(rnd() * 3);
  g.press(k, hold, 1 + Math.floor(rnd() * 4));
  keys++;
  const wait = rnd() < 0.6 ? rnd() * 0.5 : rnd() < 0.8 ? rnd() * 4 : rnd() * 40;
  g.run(wait); t += wait + hold / 20;
  if (!m.isOn()) { fail('switched off'); break; }
  if (/ERROR|MEMORY|TRAP|ERR:/i.test(g.text())) { fail('an error'); break; }
  if (g.sync() < 0) {
    base = -1;
    if (!/Edit|EDIT|Prog|PROG|Run|RUN|Find|FIND/.test(g.text())) { g.run(3); t += 3; if (g.sync() >= 0) { base = g.base; continue; } }
    try { g.start(30); restarts++; base = g.base; code = snap(); } catch (e) { fail('could not start again: ' + e.message.split('\n')[0]); }
    continue;
  }
  if (g.base !== base) { base = g.base; code = snap(); }
  const now = snap();
  for (let i = 0; i < now.length; i++) if (now[i] !== code[i]) { changed++; fail(`kernel/driver byte ${i} changed ${code[i]} -> ${now[i]}`); code = now; break; }
}
console.log(`${model}: ${t.toFixed(0)} s, ${keys} keys, ${restarts} restarts, ${writes} writes by game code`);
if (odd.size) {
  console.log('writes outside the expected places (pc in the array > address):');
  for (const [k, n] of [...odd.entries()].sort((a, b) => b[1] - a[1]).slice(0, 40)) console.log('  ', k, n);
}
console.log(bad || odd.size ? 'FAILED or to review' : 'ok');
process.exit(bad ? 1 : 0);
