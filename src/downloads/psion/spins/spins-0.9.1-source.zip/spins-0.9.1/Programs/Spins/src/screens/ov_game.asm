; =====================================================================
; OV_GAME: the game engine. Draws the stops, reads the windows, applies
; Santa and the stars, pays the lines, and works out a whole Xmas Spins
; feature when one starts. Checked spin for spin against ref/game.js
; (tests/t_game.js).
;
; The tables (IT_TAB4 or IT_TAB2, tools/build.py make_tables) are read
; into the scene buffer first:
;   TB_BASE  5 reels x 35 (a strip of 32 and its first 3 again)
;   TB_FREE  reels 2-5 x 35 (the free strips)
;   TB_LINES 20 lines x 5 rows (0 = top)
;   TB_PAYS  8 symbols x 3 words (3, 4, 5 of a kind)
; Symbols: 0 Mrs Claus, 1 reindeer, 2 bell, 3 wreath, 4 A, 5 K, 6 Q, 7 J,
; 8 house, 9 Santa, 10 star.
; =====================================================================
        include "../defs.inc"

        jmp  og_spin            ; G_SPIN
        jmp  og_free            ; G_FREE
        jmp  og_tabs            ; G_TABS
        jmp  og_paytab          ; G_PAY: A = symbol, B = count: D = pay
        jmp  og_gift            ; G_GIFT: an advent gift of three free spins
        jmp  og_xinit           ; G_XINIT: the Xmas Spins' show starts

; G_XINIT: the show of a feature: from its random state, kv_fn spins to
; show, none shown yet, no win shown
og_xinit:
        ldd  kv_fseed
        std  kv_frng
        ldd  kv_fseed+2
        std  kv_frng+2
        ldaa kv_fn
        staa kv_fleft
        staa kv_fsofar
        clr  kv_fidx
        clra
        clrb
        std  kv_dwin
        std  kv_dwin+2
        rts

; G_GIFT: a feature of three free spins, drawn and counted now (as after
; three stars); A = C_GSETTLE (paid next, then shown)
og_gift:
        clr  kv_tnt
        jsr  og_tabs
        ldaa #3
        staa kv_fn
        clr  kv_santa
        clr  kv_nwin
        clra
        clrb
        std  kv_lwin
        std  og_ftot
        std  og_ftot+2
        ldd  kv_rng
        std  kv_fseed
        ldd  kv_rng+2
        std  kv_fseed+2
        jsr  og_feat
        jsr  og_credit
        ldaa #C_GSETTLE
        rts

; ---------------------------------------------------------------------
; G_SPIN: a base spin. kv_rng moves on; og_stops, kv_grid, kv_santa,
; og_nstar, the lines (kv_nwin, kv_wins, kv_lwin); if three or more
; stars, the whole feature (kv_fn spins to start, kv_fseed its random
; state, og_fcount its spins, og_ftot its pay in line bets); kv_win the
; whole play's pay in credits (line bets times the bet).
; ---------------------------------------------------------------------
og_spin:
        clr  kv_tnt             ; (its data covers the tune buffer)
        bsr  og_tabs
        clr  kv_santa
        clr  kv_fn
        clr  og_fcount
        clra
        clrb
        std  og_ftot
        std  og_ftot+2
        ldd  #og_data+TB_BASE
        std  og_sb
        clr  og_r               ; reel 0-4
.r:     jsr  rng_stop
        ldab og_r
        ldx  #og_stops
        abx
        staa 0,x
        tab
        ldaa og_r
        jsr  og_win
        inc  og_r
        ldaa og_r
        cmpa #5
        bne  .r
        ldx  #kv_grid           ; Santa: anywhere on reel 1
        ldab kv_rows
.s:     ldaa 0,x
        cmpa #9
        bne  .sn
        inc  kv_santa
.sn:    inx
        decb
        bne  .s
        jsr  og_stars
        staa og_nstar
        jsr  og_pay
        ldaa og_nstar          ; the feature
        cmpa #3
        blo  .cr
        ldab #10
        cmpa #3
        beq  .fn
        ldab #12
        cmpa #4
        beq  .fn
        ldab #15
.fn:    stab kv_fn
        ldd  kv_rng             ; its random state, for the show
        std  kv_fseed
        ldd  kv_rng+2
        std  kv_fseed+2
        jsr  og_feat
        jsr  og_pay             ; (the base spin's lines again)
; the pay in credits: (lines + feature) * bet
.cr:    jmp  og_credit
og_credit:
        ldd  og_ftot
        std  kv_win
        ldd  og_ftot+2
        std  kv_win+2
        ldd  kv_lwin
        jsr  set32
        ldx  #kv_win
        jsr  add32
        ldd  kv_win
        std  kv_n32
        ldd  kv_win+2
        std  kv_n32+2
        ldab kv_bet
        ldx  #og_bets
        abx
        ldab 0,x
        jsr  mul32
        ldd  kv_n32
        std  kv_win
        ldd  kv_n32+2
        std  kv_win+2
        rts
og_bets: fcb 1,2,5,10

; G_TABS: the tables into the scene buffer
og_tabs:
        ldaa #IT_TAB2
        tst  kv_four
        beq  .t
        ldaa #IT_TAB4
.t:     ldx  #og_data
        jmp  pk_load

; og_win: A = reel, B = stop: the reel's window into kv_grid (rows from
; og_sb + reel * 35 + stop)
og_win: stab og_t
        staa og_t2
        ldab #35
        mul
        addd og_sb
        addb og_t
        adca #0
        std  og_src
        ldab og_t2
        aslb
        aslb
        ldx  #kv_grid
        abx
        stx  og_dst
        ldab kv_rows
.l:     ldx  og_src
        ldaa 0,x
        inx
        stx  og_src
        ldx  og_dst
        staa 0,x
        inx
        stx  og_dst
        decb
        bne  .l
        rts

; og_stars: A = how many reels show a star
og_stars:
        clr  og_n
        clra
.r:     psha
        bsr  og_rstar
        pula
        inca
        cmpa #5
        bne  .r
        ldaa og_n
        rts
; og_rstar: A = reel: og_n + 1 if its window shows a star
og_rstar:
        asla
        asla
        tab
        ldx  #kv_grid
        abx
        ldab kv_rows
.c:     ldaa 0,x
        cmpa #10
        beq  .y
        inx
        decb
        bne  .c
        rts
.y:     inc  og_n
        rts

; ---------------------------------------------------------------------
; og_pay: the 20 lines of kv_grid: kv_nwin, kv_wins (for each line 0,
; or symbol << 4 | count), kv_lwin (their pay in line bets). With
; kv_santa reel 1 and every house are wild.
; ---------------------------------------------------------------------
og_pay: clr  kv_nwin
        clr  kv_lwin
        clr  kv_lwin+1
        ldx  #kv_wins
        ldab #20
.z:     clr  0,x
        inx
        decb
        bne  .z
        ldx  #og_data+TB_LINES
        stx  og_lp
        clr  og_li
.line:  clr  og_r
.cell:  ldx  og_lp              ; this reel's row on the line
        ldab og_r
        abx
        ldab 0,x
        ldaa og_r
        asla
        asla
        aba
        tab
        ldx  #kv_grid
        abx
        ldaa 0,x                ; the symbol there
        tst  kv_santa
        beq  .nw
        tst  og_r
        beq  .wild
        cmpa #8
        bne  .nw
.wild:  ldaa #$FF
.nw:    ldx  #og_c
        ldab og_r
        abx
        staa 0,x
        inc  og_r
        ldaa og_r
        cmpa #5
        bne  .cell
        ldx  #og_c              ; w = leading wilds
        clrb
.w:     ldaa 0,x
        cmpa #$FF
        bne  .wx
        inx
        incb
        cmpb #5
        bne  .w
        clra                    ; all wild: five Mrs Claus
        bra  .rec
.wx:    stab og_w
        staa og_x               ; X, the first other symbol, and its run
        incb
.run:   cmpb #5
        beq  .re
        inx
        ldaa 0,x
        cmpa og_x
        beq  .ok
        cmpa #$FF
        bne  .re
.ok:    incb
        bra  .run
.re:    stab og_n
        clra
        clrb
        std  og_px
        std  og_pw
        ldaa og_x               ; X's pay, if it pays
        cmpa #8
        bhs  .pw
        ldab og_n
        cmpb #3
        blo  .pw
        bsr  og_paytab
        std  og_px
.pw:    ldab og_w               ; the leading wilds as Mrs Claus
        cmpb #3
        blo  .cmp
        clra
        bsr  og_paytab
        std  og_pw
.cmp:   ldd  og_px
        subd og_pw
        bhi  .tx
        ldd  og_pw
        beq  .next
        clra
        ldab og_w
        bra  .rec
.tx:    ldaa og_x
        ldab og_n
.rec:   staa og_t               ; A = symbol, B = count: kept and paid
        stab og_t2
        ldab og_li
        ldx  #kv_wins
        abx
        asla
        asla
        asla
        asla
        adda og_t2
        staa 0,x
        inc  kv_nwin
        ldaa og_t
        ldab og_t2
        bsr  og_paytab
        addd kv_lwin
        std  kv_lwin
.next:  ldx  og_lp
        ldab #5
        abx
        stx  og_lp
        inc  og_li
        ldaa og_li
        cmpa #20
        bne  .line
        rts

; og_paytab: A = symbol (0-7), B = count (3-5): D = its pay in line bets
og_paytab:
        subb #3
        stab og_t3
        ldab #3
        mul
        addb og_t3
        aslb
        ldx  #og_data+TB_PAYS
        abx
        ldd  0,x
        rts

; ---------------------------------------------------------------------
; og_feat: the whole feature from kv_rng: og_fcount, og_ftot. The base
; spin's grid and Santa are kept (og_save), and its stops (free spins use og_fstop).
; ---------------------------------------------------------------------
og_feat:
        ldd  #21
        std  T0
        ldx  #kv_grid
        ldd  #og_save
        os   UT$CPYB
        ldaa kv_fn
        staa og_left
        staa og_fcount
.spin:  bsr  og_fspin
        ldd  og_ftot+2
        addd kv_lwin
        std  og_ftot+2
        ldd  og_ftot
        adcb #0
        adca #0
        std  og_ftot
        dec  og_left
        ldaa #250               ; add = min(extras, 250 - count)
        suba og_fcount
        cmpa og_n
        bls  .a
        ldaa og_n
.a:     tab
        addb og_left
        stab og_left
        adda og_fcount
        staa og_fcount
        tst  og_left
        bne  .spin
        ldd  #21
        std  T0
        ldx  #og_save
        ldd  #kv_grid
        os   UT$CPYB
        rts

; og_fspin: one free spin from kv_rng: reel 1 Santa, reels 2-5 from the
; free strips; kv_grid, the lines; og_n = the extra spins (a star on
; reel 3 or 5)
og_fspin:
        ldaa #1
        staa kv_santa
        ldx  #kv_grid
        ldaa #9
        ldab #4
.s:     staa 0,x
        inx
        decb
        bne  .s
        clr  og_fstop
        ldd  #og_data+TB_FREE-35
        std  og_sb
        ldaa #1
        staa og_r
.r:     jsr  rng_stop
        ldab og_r
        ldx  #og_fstop
        abx
        staa 0,x
        tab
        ldaa og_r
        jsr  og_win
        inc  og_r
        ldaa og_r
        cmpa #5
        bne  .r
        jsr  og_pay
        clr  og_n
        ldaa #2
        jsr  og_rstar
        ldaa #4
        jmp  og_rstar

; G_FREE: the next spin of the show, from kv_frng (the main random state
; is kept): kv_grid, the lines; A = its extra spins
og_free:
        clr  kv_tnt
        jsr  og_tabs
        bsr  og_swap
        bsr  og_fspin
        bsr  og_swap
        dec  kv_fleft           ; one shown; its extra spins added (as og_feat
        ldaa #250               ; counted them: at most 250 in all)
        suba kv_fsofar
        cmpa og_n
        bls  .a
        ldaa og_n
.a:     tab
        addb kv_fleft
        stab kv_fleft
        adda kv_fsofar
        staa kv_fsofar
        ldaa og_n               ; A = its extra spins
        rts
og_swap:
        ldx  #kv_rng
        ldab #4
.l:     ldaa 0,x
        psha
        ldaa kv_frng-kv_rng,x
        staa 0,x
        pula
        staa kv_frng-kv_rng,x
        inx
        decb
        bne  .l
        rts

; the overlay's variables
og_sb:  fdb  0                  ; the strips' base
og_src: fdb  0
og_dst: fdb  0
og_lp:  fdb  0                  ; this line's rows
og_px:  fdb  0
og_pw:  fdb  0
og_r:   fcb  0
og_t:   fcb  0
og_t2:  fcb  0
og_t3:  fcb  0
og_n:   fcb  0
og_w:   fcb  0
og_x:   fcb  0
og_li:  fcb  0
og_left: fcb 0
og_c:   rmb  5                  ; a line's five cells ($FF wild)
og_save: rmb 21                 ; the base spin's grid and Santa
og_fstop: rmb 5                 ; a free spin's stops (the base spin's kept)
og_stops: rmb 5                 ; the reels' stops
og_nstar: fcb 0                ; stars showing
og_fcount: fcb 0                ; a feature's spins in all
og_ftot: rmb  4                 ; and its pay in line bets
og_data:                        ; the tables, read in here
