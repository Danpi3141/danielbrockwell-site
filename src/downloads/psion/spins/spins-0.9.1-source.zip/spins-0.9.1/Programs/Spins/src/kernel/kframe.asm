; ---------------------------------------------------------------------
; The frame player: a frame is drawn (what changed is sent to the
; display), then sounds for the rest of its length, a tick at a time.
; The drawing time, measured on the free-running counter, is taken off
; the first tick. A waiting key sets kv_key (the key stays waiting).
; ---------------------------------------------------------------------

; frame: A = length in ticks at 12 frames a second (scaled by Glass)
frame:  jsr  fscale
; frame_t: A = length in ticks, unscaled
frame_t:
        staa kv_fl
        ldx  TMW_TCNT           ; the Organiser's switch-off count starts again:
        stx  TMW_TOUT           ; it may switch off only while waiting for a key
        ldx  kv_comp            ; the sprite window, if a director shows one
        beq  .f
        jsr  0,x
.f:     jsr  flush
        ldd  FRC                ; the time since the last frame ended: drawing,
        subd kv_f0              ; and the director's own work
        bcc  .p
        addd #46080             ; (the emulator's counter restarts every 50 ms;
        bcc  .z                 ; the Organiser's wraps at 65536: a gap across
.p:     cmpa #$75               ; that wrap is not counted; at most 30,000:
        blo  .b                 ; the budget is signed)
        ldd  #30000
        bra  .b
.z:     clra
        clrb
.b:     coma                    ; the budget starts that far below 0
        comb
        addd #1
        std  SB
        clr  kv_lsh             ; (the tone loop's counts live in zero page,
        tst  kv_fl              ; which other code uses between frames)
        beq  .k
.t:     jsr  snd_tick
        dec  kv_fl
        bne  .t
.k:     ldd  FRC
        std  kv_f0
        os   KB$TEST
        stab kv_key
        rts

; fscale: A = ticks at 12 frames a second: A = ticks at the Glass speed
; (kv_glass 0-3: 8, 10, 12, 15 frames a second: * 6/4, 5/4, 4/4, 3/4)
fscale: ldab kv_glass
        ldx  #fs_k
        abx
        ldab 0,x
        mul
        lsrd
        lsrd
        tsta
        beq  .x
        ldab #255
.x:     tba
        rts
fs_k:   fcb  6, 5, 4, 3
