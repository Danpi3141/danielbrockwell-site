// OV_GAME against ref/game.js, spin for spin: the stops, the grid, the lines, the feature.
//   node tests/t_game.js [model] [spins]
const { Game } = require('./lib');
const R = require('../ref/game.js');
const model = process.argv[2] || 'lz64';
const N = +process.argv[3] || 300;
const g = new Game(model);
g.start();
const four = g.m.lines === 4;
const G = R.grid(four ? 'four' : 'two');
const ids = g.ids();
const SYMS = 'MRBWAKQJHS*';
let bad = 0, feats = 0, wins = 0;
let seed = 0x2468ACE1;
for (let i = 0; i < N; i++) {
  // force some features: every 10th spin, search a seed that starts one
  seed = (seed * 1103515245 + 12345) >>> 0;
  let s = seed || 1;
  if (i % 10 === 0) { for (;;) { const r = new R.Rng(s); if (R.baseSpin(G, r).freeSpins) break; s = (s * 69069 + 1) >>> 0 || 1; } }
  const bet = i % 4;
  for (let k = 0; k < 4; k++) g.poke('kv_rng', (s >>> (24 - 8 * k)) & 255, k);
  g.poke('kv_bet', bet);
  const out = g.call(ids.OV_GAME, 0, { keep: false });
  const rng = new R.Rng(s);
  const p = R.play(G, rng);
  const b = p.base;
  const errs = [];
  const stops = [...Array(5)].map((_, r) => g.peek('og_stops', r));
  if (stops.join() !== b.stops.join()) errs.push('stops ' + stops + ' v ' + b.stops);
  for (let r = 0; r < 5; r++) for (let y = 0; y < G.rows; y++) {
    if (SYMS[g.peek('kv_grid', r * 4 + y)] !== b.win[r][y]) errs.push(`grid ${r},${y}`);
  }
  if (!!g.peek('kv_santa') !== b.santa) errs.push('santa');
  if (g.peek('og_nstar') !== b.stars) errs.push('stars');
  const nw = g.peek('kv_nwin');
  const ws = [...Array(20)].map((_, j) => g.peek('kv_wins', j)).map((v, j) => ({ line: j + 1, sym: SYMS[v >> 4], n: v & 15, v })).filter((w) => w.v).map(({ line, sym, n }) => ({ line, sym, n }));
  if (ws.length !== nw) errs.push('nwin ' + nw + ' v ' + ws.length);
  const rw = b.wins.map((w) => ({ line: w.line, sym: w.sym, n: w.n }));
  if (JSON.stringify(ws) !== JSON.stringify(rw)) errs.push('wins ' + JSON.stringify(ws) + ' v ' + JSON.stringify(rw));
  if (g.peekw('kv_lwin') !== b.total) errs.push('lwin ' + g.peekw('kv_lwin') + ' v ' + b.total);
  if (b.total) wins++;
  if (g.peek('kv_fn') !== b.freeSpins) errs.push('fn');
  if (p.feature) {
    feats++;
    if (g.peek('og_fcount') !== p.feature.count) errs.push('fcount ' + g.peek('og_fcount') + ' v ' + p.feature.count);
    if (g.peek32('og_ftot') !== p.feature.total) errs.push('ftot ' + g.peek32('og_ftot') + ' v ' + p.feature.total);
  }
  const want = p.total * [1, 2, 5, 10][bet];
  if (g.peek32('kv_win') !== want) errs.push('win ' + g.peek32('kv_win') + ' v ' + want);
  if (g.peek32('kv_rng') !== rng.x) errs.push('rng after');
  if (errs.length) { bad++; if (bad < 6) console.log('spin', i, 'seed', s.toString(16), errs.join('; ')); }
}
console.log(`${model}: ${N} spins, ${wins} paying, ${feats} features, ${bad} differ`);
process.exit(bad ? 1 : 0);
