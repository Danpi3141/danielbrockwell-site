; =====================================================================
; OV_WALK: Santa's delivery. He steps out of reel 1 and walks across the
; reels in a moving window of the stage characters (comp.inc), stopping
; to throw at every reel with a house; the houses twinkle; on the far
; side HO HO HO; the houses become presents; he jumps home. With no
; house showing he looks both ways, shrugs and goes back. Six styles,
; picked at random (or the standard walk: setting kv_styles).
; Quick: out a step, back; Off: nothing (OV_HOME changes the houses).
; The pays were counted before: this only shows them coming. It ends
; with A (for OV_HOME, which changes the houses and brings him home):
; 0 he shrugged and came back, 1 he cheers on the far side (the window
; frozen there), 2 cut short or Quick or Off: the houses change at once.
; =====================================================================
        include "../defs.inc"

P_STAND = 0                     ; poses in the WALKn blob (scripts/walk.scr)
P_THROW1 = 2
P_THROW2 = 3
P_CHEER = 4
P_SHRUG = 5
P_LEFT  = 6
P_HUSH  = 7                     ; (tiptoe's)
P_ICE   = 7                     ; (ice's)
E_FOOT  = 0                     ; effects
E_HOHO  = 1
E_WHISTLE = 2
FL_HUSH = 1                     ; style flags
FL_ICE  = 2
FL_GLIDE = 4

        jmp  wk_go

wk_go:  ldaa kv_arg+1             ; the style's blob
        adda #IT_WALK0
        ldx  #wk_data
        stx  kv_scene
        jsr  pk_load
        ldd  #$0008             ; the font's shapes: data 0 (the cels' table)
        jsr  sc_tab
        stx  kv_fontp
        clr  wk_tw
        clr  wk_f
        clr  wk_n
        clr  wk_ice
        ldaa #2
        tst  kv_anim            ; Off: OV_HOME does it all
        bne  .on
        rts
.on:    ldaa kv_arg             ; from OV_HOME: the house reels (bits 1-4)
        staa wk_mask
        ldd  #$0108             ; the style: data 1 (its cycle, its flags)
        jsr  sc_tab
        stx  wk_sty
        ldab kv_rows            ; Santa off reel 1: its cells empty
.c:     decb
        pshb
        ldaa kv_w
        mul
        ldaa #' '
        jsr  put
        pulb
        tstb
        bne  .c
        clr  kv_spx
        ldaa #P_STAND
        jsr  wk_pose
        clra                    ; the window: rows 2-3 on four lines, 1-2 on two
        tst  kv_four
        beq  .w
        inca
.w:     jsr  sp_on
        ldaa #1                 ; steps a frame: 1 on two lines, 2 on four
        tst  kv_four
        beq  .s
        inca
.s:     staa wk_step
        tst  wk_mask
        bne  .go
        jmp  wk_shrug
.go:    ldaa kv_anim
        cmpa #2
        beq  wk_walk
        jmp  wk_quick

; ---- the walk: reel 1 to the far side, 24 frames ----
wk_walk:
        ldx  #kv_reelx+4        ; the far side: one column past reel 5
        ldaa 0,x
        inca
        ldab #6
        mul
        stab wk_end
.l:     jsr  wk_house           ; a house reel here: he throws
        bcs  wk_skip
        ldx  wk_sty             ; the pose: the style's cycle, a pose a frame
        ldab wk_f
        andb #3
        abx
        ldaa 0,x
        ldx  wk_sty
        ldab 4,x
        bitb #FL_ICE            ; ice: from the 16th frame on he slides
        beq  .p
        ldab wk_f
        cmpb #16
        blo  .p
        ldaa #P_ICE
        tst  wk_ice
        bne  .p
        inc  wk_ice
        psha
        ldaa #E_WHISTLE
        jsr  wk_fx
        pula
.p:     jsr  wk_pose
        ldaa wk_f               ; a footfall every other frame
        anda #1
        bne  .mv
        tst  wk_ice
        bne  .mv
        ldaa #E_FOOT
        jsr  wk_fx
.mv:    ldaa kv_spx
        adda wk_step
        staa kv_spx
        jsr  wk_frame
        bcs  wk_skip
        ldaa kv_spx
        cmpa wk_end
        blo  .l
; the far side: he turns out and cheers
        ldaa #P_CHEER
        jsr  wk_pose
        ldx  #wk_hoho
        jsr  pn_msg
        ldaa #E_HOHO
        jsr  wk_fx
        ldab #12
.h:     pshb
        jsr  wk_frame
        pulb
        bcs  wk_skip
        decb
        bne  .h
        jsr  sp_freeze          ; he stays there; OV_HOME goes on
        ldaa #1
        rts
wk_skip:
        jsr  sp_off
        ldaa #2
        rts

; Quick: out a step and back
wk_quick:
        ldab #3
.o:     pshb
        ldaa kv_spx
        adda wk_step
        staa kv_spx
        jsr  wk_frame
        pulb
        decb
        bne  .o
        bra  wk_skip

; no house: out a step, looks both ways, shrugs, back
wk_shrug:
        ldab #3
.o:     pshb
        ldaa kv_spx
        adda wk_step
        staa kv_spx
        jsr  wk_frame
        pulb
        bcs  .x
        decb
        bne  .o
        ldaa #P_LEFT
        bsr  .look
        bcs  .x
        ldaa #P_STAND+1
        bsr  .look
        bcs  .x
        ldaa #P_SHRUG
        bsr  .look
        bcs  .x
        ldaa #P_LEFT            ; and back
        jsr  wk_pose
.b:     ldaa kv_spx
        suba wk_step
        staa kv_spx
        jsr  wk_frame
        bcs  .x
        tst  kv_spx
        bne  .b
.x:     jsr  sp_off
        clra
        rts
.look:  jsr  wk_pose
        ldab #4
.lf:    pshb
        jsr  wk_frame
        pulb
        bcs  .lx
        decb
        bne  .lf
.lx:    rts

; wk_house: at a reel with a house not yet visited: he throws (two
; frames), the reel's houses start to twinkle, a bell climbs
wk_house:
        ldab #1
.r:     ldx  #kv_reelx
        abx
        ldaa 0,x
        pshb
        ldab #6
        mul
        cmpb kv_spx
        pulb
        bne  .n
        jsr  gbit
        bita wk_mask
        beq  .n
        bita wk_tw
        bne  .n
        oraa wk_tw              ; this reel's houses twinkle from now
        staa wk_tw
        ldx  wk_sty
        ldab 4,x
        ldaa #P_THROW1          ; (the load before the test: it sets Z too)
        bitb #FL_HUSH
        beq  .t1
        ldaa #P_HUSH
.t1:    jsr  wk_pose
        bsr  wk_frame
        bcs  .x
        ldaa #P_THROW2
        jsr  wk_pose
        inc  wk_n               ; the bell: higher for each house reel
        ldaa wk_n
        ldab #3
        mul
        addb #26
        stab wk_bell+2
        ldx  #wk_bell
        jsr  snd_fx
        bra  wk_frame
.n:     incb
        cmpb #5
        bne  .r
        clc
.x:     rts
wk_bell: fcb 6,14,0,$FF

; wk_frame: the twinkling houses, then a frame of 10 ticks. Carry set:
; a key (it is taken)
wk_frame:
        inc  wk_f
        ldaa #1
        staa wk_r
.r:     ldab wk_r
        jsr  gbit
        bita wk_tw
        beq  .n
        clr  wk_y
.y:     jsr  wk_sym
        cmpa #8
        bne  .ny
        ldaa #3                 ; a house: itself, or + in turn
        ldab wk_f
        bitb #2
        beq  .c
        ldaa #'+'
.c:     psha
        jsr  wk_cell
        pula
        jsr  wput
.ny:    inc  wk_y
        ldaa wk_y
        cmpa kv_rows
        bne  .y
.n:     inc  wk_r
        ldaa wk_r
        cmpa #5
        bne  .r
        ldaa #10
        jsr  frame
        tst  kv_key
        beq  .x
        os   KB$GETK
        sec
        rts
.x:     clc
        rts

; A = an effect of the blob
wk_fx:  ldab #6
        jsr  sc_tab
        jmp  snd_fx
; A = a pose of the blob: Santa's pose
wk_pose:
        clrb
        jsr  sc_tab
        jmp  sp_pose
; A = the symbol at reel wk_r, row wk_y
wk_sym: ldaa wk_r
        asla
        asla
        adda wk_y
        tab
        ldx  #kv_grid
        abx
        ldaa 0,x
        rts
; B = the cell of reel wk_r, row wk_y
wk_cell:
        ldx  #kv_reelx
        ldab wk_r
        abx
        ldaa wk_y
        ldab kv_w
        mul
        addb 0,x
        rts

wk_hoho: fcl "HO HO HO!"

wk_sty: fdb  0
wk_mask: fcb 0                  ; reels with a house
wk_tw:  fcb  0                  ; reels whose houses twinkle
wk_f:   fcb  0                  ; frames
wk_n:   fcb  0                  ; house reels visited
wk_r:   fcb  0
wk_y:   fcb  0
wk_step: fcb 0
wk_end: fcb  0
wk_ice: fcb  0

        include "comp.inc"
wk_data:                        ; the blob, read in here
