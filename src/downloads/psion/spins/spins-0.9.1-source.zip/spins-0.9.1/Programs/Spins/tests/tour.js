// A tour: PNG screenshots of the game's moments on a model, for the report.
//   node tests/tour.js [model]   -> build/shots/tour_<model>_<nn>_<name>.png and tour_<model>.json
const fs = require('fs'), path = require('path');
const { Game } = require('./lib');
const { lcdPng } = require('./png');
const model = process.argv[2] || 'lz64';
const out = path.join(__dirname, '..', 'build', 'shots');
fs.mkdirSync(out, { recursive: true });
const list = [];
let n = 0;
function shot(g, name, label) {
  const f = `tour_${model}_${String(n++).padStart(2, '0')}_${name}.png`;
  fs.writeFileSync(path.join(out, f), lcdPng(g, 4));
  // the screen as data too: the character codes, and the 8 defined characters' rows
  list.push({ file: f, name, label, lines: g.m.lines, cols: g.m.cols, cells: g.m.cells(), udg: g.m.udgs() });
}
// 1. the title and the reels at rest
{
  const g = new Game(model);
  g.m.runProc('SANTA', 'B');
  for (let i = 0; i < 16; i++) { g.run(0.25); if (i === 5) shot(g, 'title1', 'The title: a sleigh and two reindeer fly across'); }
  g.start(20, false);
  for (let i = 0; i < 12; i++) { g.run(0.25); }
  shot(g, 'title2', 'The title types out');
}
{
  const g = new Game(model);
  g.start();
  shot(g, 'rest', 'At rest: five reels, the panel on the right');
  // 2. a spin: the drums, the cascade
  const seedSanta = g.seedFor((b) => b.santa && b.houses >= 2 && b.total > 0 && !b.freeSpins, 3000);
  let t = 0;
  const marks = { 0.4: ['spin1', 'Spinning: three drums turn, a few dots out of step'], 1.1: ['spin2', 'Reel 1 stops: the lander slides each row in'] };
  const taken = new Set();
  g.spin(seedSanta, 0.05, (tt) => {
    t = tt;
    for (const [k, v] of Object.entries(marks)) if (!taken.has(k) && t >= +k) { taken.add(k); shot(g, v[0], v[1]); }
    if (!taken.has('w1') && g.peek('kv_res') === g.ids().OV_WALK && t > 3.3) { taken.add('w1'); shot(g, 'walk1', 'Santa steps out of reel 1'); }
    if (!taken.has('w2') && g.peek('kv_res') === g.ids().OV_WALK && t > 4.3) { taken.add('w2'); shot(g, 'walk2', 'He walks across the reels, the symbols showing round him'); }
    if (!taken.has('w3') && g.peek('kv_res') === g.ids().OV_WALK && t > 5.3) { taken.add('w3'); shot(g, 'walk3', 'He has thrown at a house reel: its houses twinkle'); }
    if (!taken.has('ho') && /HO HO/.test(g.text())) { taken.add('ho'); shot(g, 'hoho', 'The far side: HO HO HO!'); }
    if (!taken.has('pr') && g.peek('kv_res') === g.ids().OV_WINFX && t > 6) { taken.add('pr'); shot(g, 'wins', 'The houses are presents, wild: the lines are shown'); }
  });
  shot(g, 'after', 'The win counted up');
  // 3. menus
  g.press('MODE'); g.run(0.5); shot(g, 'menu', 'The menu');
  g.press('ON'); g.run(0.4);
  g.press('P'); g.run(0.5); shot(g, 'pays', 'The pay table: a page for each symbol');
  g.press('ON'); g.run(0.4);
  g.press('L'); g.run(0.5); g.press('DOWN'); g.run(0.3); g.press('DOWN'); g.run(0.3); g.press('DOWN'); g.run(0.3); g.press('DOWN'); g.run(0.3); shot(g, 'lines', 'The line viewer');
  g.press('ON'); g.run(0.4);
  g.press('MODE'); g.run(0.4); g.press('S'); g.run(0.2); g.press('S'); g.run(0.2); g.press('EXE'); g.run(0.5); shot(g, 'settings', 'Settings');
  g.press('ON'); g.run(1);
}
// 4. the Xmas Spins
{
  const g = new Game(model);
  g.start();
  const seed = g.seedFor((b) => b.freeSpins > 0, 1000);
  const taken = new Set();
  g.spin(seed, 0.1, (t) => {
    const txt = g.text();
    if (!taken.has('xs') && /XMAS SPINS/.test(txt) && /SPINS/.test(txt) && t > 3) { taken.add('xs'); g.run(1.2); shot(g, 'xstart', 'Three stars: the Xmas Spins begin'); }
    if (!taken.has('x1') && g.peek('kv_res') === g.ids().OV_XFX && /XMAS/.test(txt)) { taken.add('x1'); shot(g, 'xthrow', 'An Xmas Spin: Santa throws a present along his row'); }
    if (taken.has('x1') && !taken.has('el') && g.peek('kv_res') === g.ids().OV_XFX && g.scr()[g.m.lines - 1].includes('7')) { taken.add('el'); shot(g, 'elf', 'The elf runs along the bottom row, collecting presents'); }
    if (!taken.has('xe') && /TOTAL/.test(txt)) { taken.add('xe'); g.run(0.8); shot(g, 'xend', 'The Xmas Spins end: the total counts up'); }
  });
}
// 5. scenes
{
  const g = new Game(model);
  g.start();
  const ids = g.ids();
  for (const [sc, at, name, label] of [[3, 1.4, 'bigwin', 'A big win: fireworks'], [4, 1.0, 'hugewin', 'A huge win: Santa dances while coins fall'],
    [6, 2.2, 'broke', 'Out of credits: Santa brings a sack of 500'], [7, 2.0, 'village', 'Idle: a village in the snow'],
    [8, 1.2, 'chimney', 'Idle: stuck in the chimney'], [12, 2.6, 'advent', 'The advent calendar: today\'s door']]) {
    g.poke('kv_arg', sc);
    let done = false;
    g.callSteps(ids.OV_SCENE, 0, 0.1, (t) => { if (!done && t >= at) { done = true; shot(g, name, label); } }, 60);
  }
}
fs.writeFileSync(path.join(out, `tour_${model}.json`), JSON.stringify(list, null, 1));
console.log(list.length, 'shots');
