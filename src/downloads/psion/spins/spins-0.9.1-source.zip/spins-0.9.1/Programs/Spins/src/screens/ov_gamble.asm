; =====================================================================
; OV_GAMBLE (stretch goal): after a win (not a feature), Santa hides it
; in one hand: the right one doubles it, the wrong one loses it. The
; hand is drawn from the random state when the choice is made, the
; credits settled and saved, then the hand opens. Even odds: the return
; is unchanged. Returns A = C_SAVE (saved again, as everything is).
; =====================================================================
        include "../defs.inc"

        jmp  og_go

og_go:  tst  kv_gok
        bne  .ok
        ldx  #og_err            ; nothing to gamble
        jsr  snd_fx
        ldaa #10
        jsr  frame_t
        clra
        rts
.ok:    clr  kv_gok
        ldaa #IT_SANTA          ; Santa (glyphs 4, 5), his fists (6), a present (7)
        ldx  #kv_glyph+32
        jsr  pk_load
        ldaa #IT_GAMBLE
        ldx  #kv_glyph+48
        jsr  pk_load
        ldaa #$F0
        oraa kv_gdirty
        staa kv_gdirty
        jsr  cls
        ldx  #og_t1             ; "GAMBLE" and the win, beside Santa
        ldab #5
        jsr  txt_at
        ldaa #5
        ldx  #kv_win
        ldab #11
        jsr  num_at
        jsr  og_figure
        ldx  #og_t2
        ldab kv_w               ; "LEFT/RIGHT" on the next line
        addb #5
        jsr  txt_at
.k:     clra
        jsr  key_wait
        cmpb #K_LEFT
        beq  .c
        cmpb #K_RIGHT
        bne  .k
.c:     clra                    ; the choice: 0 left, 1 right
        cmpb #K_RIGHT
        bne  .ch
        inca
.ch:    staa og_ch
        jsr  rng_next           ; the hand: the top bit of the next number
        clrb
        ldaa kv_rng
        rola
        rolb
        stab og_hand
        ldd  kv_win             ; staked: the win
        std  kv_n32
        ldd  kv_win+2
        std  kv_n32+2
        ldx  #st_staked
        jsr  add32
        ldaa og_hand
        cmpa og_ch
        bne  .lose
        ldx  #kv_bal            ; right: the win again (doubled), paid twice
        jsr  add32
        ldx  #st_paid
        jsr  add32
        jsr  add32
        bra  .shw
.lose:  ldx  #kv_bal            ; wrong: the win goes back
        jsr  sub32
.shw:   ldaa og_hand            ; the hand opens: the present, or nothing
        ldab kv_w
        incb
        tsta
        beq  .o
        addb #2
.o:     ldaa #7
        jsr  put
        ldab kv_w               ; the other: empty
        incb
        ldaa og_hand
        bne  .e
        addb #2
.e:     ldaa #' '
        jsr  put
        ldx  #og_won
        ldaa og_hand
        cmpa og_ch
        beq  .w
        ldx  #og_lost
.w:     pshx
        ldab kv_w
        addb #5
        jsr  txt_at
        pulx
        ldaa og_hand
        cmpa og_ch
        bne  .s
        ldx  #og_jing
        bra  .f
.s:     ldx  #og_sad
.f:     jsr  snd_fx
        ldaa #60
        jsr  frame_t
        ldd  kv_bal             ; the credits shown are the credits
        std  kv_dbal
        ldd  kv_bal+2
        std  kv_dbal+2
        clra
        clrb
        std  kv_dwin
        std  kv_dwin+2
        ldaa #20
        jsr  frame_t
        ldaa #C_SAVE
        rts

; Santa with a fist either side: row 1 (and 2) columns 2-4
og_figure:
        ldaa #4
        ldab #2
        jsr  put
        ldab kv_w
        addb #2
        ldaa #5
        jsr  put
        ldab kv_w
        incb
        ldaa #6
        jsr  put
        ldab kv_w
        addb #3
        ldaa #6
        jmp  put

og_t1:  fcl  "GAMBLE"
og_t2:  fcl  "LEFT/RIGHT"
og_won: fcl  "DOUBLED!  "
og_lost: fcl "GONE      "
og_err: fcb  1,20,0,1,$FF
og_jing: fcb 3,10,20,24,27, 3,16,24,27,32, $FF
og_sad:  fcb 2,30,20,4, $FF
og_ch:  fcb  0
og_hand: fcb 0
