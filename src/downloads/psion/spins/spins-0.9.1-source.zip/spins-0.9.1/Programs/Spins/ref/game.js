// Psion Spins: the reference game engine. The 6303 game engine is checked against this,
// spin for spin (tests/game). Plain JavaScript, no dependencies.
'use strict';
const fs = require('fs');
const path = require('path');

const T = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data', 'tables.json'), 'utf8'));
const PAYSYM = 'MRBWAKQJ';          // paying symbols, best first (ties: the first wins)
const MAX_SPINS = 250;              // Xmas Spins in one feature, at most (a byte on the Psion)

function grid(kind) {               // kind: 'four' or 'two'
  const g = T[kind];
  return {
    kind, rows: g.rows,
    base: g.base, free: g.free,
    lines: g.lines.map((l) => [...l].map((c) => +c - 1)),
  };
}

// ---- random numbers: Marsaglia's xorshift32 (13, 17, 5); a stop is the top five bits
function Rng(seed) { this.x = (seed >>> 0) || 1; }
Rng.prototype.next = function () {
  let x = this.x;
  x ^= x << 13; x >>>= 0;
  x ^= x >>> 17;
  x ^= x << 5; x >>>= 0;
  this.x = x;
  return x;
};
Rng.prototype.stop = function () { return this.next() >>> 27; };

// the window a reel shows at a stop: rows top to bottom
function windowOf(strip, stop, rows) {
  const w = [];
  for (let i = 0; i < rows; i++) w.push(strip[(stop + i) % 32]);
  return w;
}

// one line: cells (5 symbols, 'X' = wild) -> {sym, n, pay} or null. Brute force over the symbols.
function lineWin(cells) {
  let best = null;
  for (const s of PAYSYM) {
    let n = 0;
    while (n < 5 && (cells[n] === s || cells[n] === 'X')) n++;
    if (n >= 3) {
      const p = T.pays[s][n - 3];
      if (!best || p > best.pay) best = { sym: s, n, pay: p };
    }
  }
  return best;
}

// pays for a grid of windows (win[5][rows]); santa: reel 1 and every house wild
function payGrid(G, win, santa) {
  const wins = [];
  let total = 0;
  G.lines.forEach((L, li) => {
    const c = [];
    for (let r = 0; r < 5; r++) {
      let s = win[r][L[r]];
      if (santa && (r === 0 || s === 'H')) s = 'X';
      c.push(s);
    }
    const w = lineWin(c);
    if (w) { wins.push({ line: li + 1, sym: w.sym, n: w.n, pay: w.pay }); total += w.pay; }
  });
  return { wins, total };
}

function countStars(win) { return win.reduce((n, w) => n + (w.includes('*') ? 1 : 0), 0); }

// a base spin: five stops from rng
function baseSpin(G, rng) {
  const stops = [];
  const win = [];
  for (let r = 0; r < 5; r++) {
    const s = rng.stop();
    stops.push(s);
    win.push(windowOf(G.base[r], s, G.rows));
  }
  const santa = win[0].includes('S');
  const stars = countStars(win);
  const { wins, total } = payGrid(G, win, santa);
  const houses = santa ? win.slice(1).reduce((n, w) => n + w.filter((c) => c === 'H').length, 0) : 0;
  const full = santa && win.slice(1).every((w) => w.every((c) => c === 'H'));
  return { stops, win, santa, stars, wins, total, houses, full,
    freeSpins: stars >= 3 ? T.feature_spins[Math.min(stars, 5)] : 0 };
}

// one free spin: reels 2-5 from the free strips, reel 1 Santa
function freeSpin(G, rng) {
  const stops = [0];
  const win = [new Array(G.rows).fill('S')];
  for (let r = 1; r < 5; r++) {
    const s = rng.stop();
    stops.push(s);
    win.push(windowOf(G.free[r], s, G.rows));
  }
  const { wins, total } = payGrid(G, win, true);
  const extra = (win[2].includes('*') ? 1 : 0) + (win[4].includes('*') ? 1 : 0);
  return { stops, win, wins, total, extra };
}

// the whole feature from rng: its spins and its total (in line bets)
function feature(G, rng, n) {
  const spins = [];
  let total = 0;
  let left = n;
  let count = n;
  while (left > 0) {
    const f = freeSpin(G, rng);
    left--;
    const add = Math.min(f.extra, MAX_SPINS - count);
    left += add; count += add;
    f.added = add;
    spins.push(f);
    total += f.total;
  }
  return { spins, total, count };
}

// a whole play: the base spin and, if it starts one, the feature (drawn straight after it)
function play(G, rng) {
  const b = baseSpin(G, rng);
  let f = null;
  if (b.freeSpins) f = feature(G, rng, b.freeSpins);
  return { base: b, feature: f, total: b.total + (f ? f.total : 0) };
}

module.exports = { T, PAYSYM, MAX_SPINS, grid, Rng, windowOf, lineWin, payGrid, baseSpin, freeSpin, feature, play };

// The 6303's way to pay a line (src/screens/ov_game.asm): w leading wilds; X the first other
// symbol and its run; the best of X's run and the leading wilds as Mrs Claus (ties: Mrs Claus,
// who comes first). Proven equal to lineWin over every grid tested (tests/t_linefast.js).
function lineWinFast(cells) {
  let w = 0;
  while (w < 5 && cells[w] === 'X') w++;
  if (w === 5) return { sym: 'M', n: 5, pay: T.pays.M[2] };
  const X = cells[w];
  let n = w + 1;
  while (n < 5 && (cells[n] === X || cells[n] === 'X')) n++;
  const px = PAYSYM.includes(X) && n >= 3 ? T.pays[X][n - 3] : 0;
  const pw = w >= 3 ? T.pays.M[w - 3] : 0;
  if (px > pw) return { sym: X, n, pay: px };
  if (pw > 0) return { sym: 'M', n: w, pay: pw };
  return null;
}
module.exports.lineWinFast = lineWinFast;
