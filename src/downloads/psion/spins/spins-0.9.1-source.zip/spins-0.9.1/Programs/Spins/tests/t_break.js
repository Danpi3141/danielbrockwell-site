// Trying to break it: situations the other tests do not set up. Each experiment says what it
// expects and what happened.   node tests/t_break.js [model] [names...]
'use strict';
const path = require('path');
const { Game } = require('./lib');
const model = process.argv[2] || 'lz64';
const only = process.argv.slice(3);
let bad = 0;
const ok = (c, m) => { console.log((c ? 'ok   ' : 'FAIL ') + m); if (!c) bad++; return c; };
const one = (s) => String(s).replace(/\n/g, ' | ');
const DATE = (g, y, mon, day) => { g.m.poke(0x20C5, y - 1900); g.m.poke(0x20C6, mon - 1); g.m.poke(0x20C7, day - 1); };
const isErr = (g) => /ERROR|MEMORY|TRAP|ERR:/i.test(g.text());
// run until the game waits at rest (no feature to show), or `sec` runs out; seen: texts that showed
function toRest(g, sec = 600, seen = null) {
  const rest = g.ids().OV_REST;
  for (let t = 0; t < sec; t += 0.25) {
    g.run(0.25);
    if (seen) seen.push(g.text());
    if (isErr(g)) return 'error: ' + one(g.text());
    if (g.sync() >= 0 && g.peek('kv_res') === rest && g.peek('kv_fleft') === 0) {
      const idles = g.idles();
      if (idles.includes(g.m.runTo(idles, 921600))) return 'rest';
    }
  }
  return 'timeout: ' + one(g.text());
}
function quit(g) {                       // ON, EXE at rest: the goodbye, saved, back to the OS
  g.lastBase = g.base; g.saveVer = g.m.peek(g.addr('sv_tag') + 1); g.svLen = svLen(g); g.lastBal = g.m.read(g.addr('kv_bal'), 4);
  g.press('ON'); g.run(1); g.press('EXE');
  for (let i = 0; i < 120 && g.sync() >= 0; i++) g.run(0.25);
  return g.sync() < 0;
}
// the save record in A:'s RAM (found by its tag and the credits): the address of sv_first
function findSave(g, bal) {
  const pat = [0x53, g.saveVer, ...bal];
  const top = g.m.lines === 4 ? 0x8000 : 0x2000 + (g.mramK() << 10);
  for (let a = 0x2000; a < top - 8; a++) {
    if (a >= g.lastBase - 300 && a < g.lastBase + g.meta.total + 100) continue;   // (the old array's copy)
    let k = 0; while (k < pat.length && g.m.peek(a + k) === pat[k]) k++;
    if (k === pat.length) return a + 2;
  }
  return -1;
}
function svLen(g) { return g.addr('sv_end') - g.addr('sv_first'); }
function fixSum(g, at) { let s = 0; for (let i = 0; i < g.svLen; i++) s += g.m.peek(at + i); g.m.poke(at + g.svLen, s & 255); }
// keys pressed around the game for a while: survives? (no error; still running or left cleanly)
function bash(g, sec, seed) {
  let x = seed;
  const r = () => { x = (x * 1103515245 + 12345) >>> 0; return x / 4294967296; };
  const K = ['EXE', 'EXE', 'MODE', 'UP', 'DOWN', 'LEFT', 'RIGHT', 'S', 'P', 'L', 'H', 'G', 'EXE', 'A'];
  for (let t = 0; t < sec; t += 0.5) {
    g.press(K[Math.floor(r() * K.length)]); g.run(0.4);
    if (!g.m.isOn()) return 'switched off';
    if (g.sync() < 0) return 'left the game: ' + one(g.text());
    if (isErr(g)) return 'error: ' + one(g.text());
  }
  return 'ok';
}
const runs = {
  // the advent calendar in two Decembers: a door each day each year, once
  advent() {
    const g = new Game(model);
    DATE(g, 2026, 12, 5);
    g.m.runProc('SANTA', 'B');
    const seen = [];
    const r1 = toRest(g, 900, seen);
    ok(r1 === 'rest' && seen.some((t) => /ADVENT/.test(t)), `5 Dec 2026: a door (${r1}), door bits ${g.peek('st_door')}`);
    ok(quit(g), 'quit');
    DATE(g, 2027, 12, 5);
    g.m.runProc('SANTA', 'B');
    const seen2 = [];
    const r2 = toRest(g, 900, seen2);
    ok(r2 === 'rest' && seen2.some((t) => /ADVENT/.test(t)), `5 Dec 2027: a door (${r2})`);
    ok(quit(g), 'quit');
    g.m.runProc('SANTA', 'B');
    const seen3 = [];
    toRest(g, 300, seen3);
    ok(!seen3.some((t) => /ADVENT/.test(t)), '5 Dec 2027 again: no second door');
    quit(g);
    DATE(g, 2027, 12, 6);
    g.m.runProc('SANTA', 'B');
    const seen4 = [];
    toRest(g, 900, seen4);
    ok(seen4.some((t) => /ADVENT/.test(t)) && g.peek('st_door') === 48, `6 Dec 2027: the next door (bits ${g.peek('st_door')})`);
  },
  // a save file that passes its checksum but holds settings out of range (a weak battery, a
  // copied file): each setting at 255 in turn, then the game played
  badsettings() {
    if (model.includes('64')) { console.log('     (the LZ64 keeps A: in banked RAM this rig cannot search: run on lz)'); return; }
    for (const v of ['kv_bet', 'kv_anim', 'kv_styles', 'kv_sound', 'kv_music', 'kv_glass', 'kv_showw', 'kv_astop', 'kv_idle']) {
      const g = new Game(model);
      g.start();
      const off = g.addr(v) - g.addr('sv_first');
      quit(g);
      const at = findSave(g, g.lastBal);
      if (!ok(at > 0, `${v}: the save record found`)) continue;
      g.m.poke(at + off, 255); fixSum(g, at);
      g.m.runProc('SANTA', 'B');
      g.run(8);
      const r = bash(g, 120, 5);
      ok(r === 'ok', `${v} = 255 in the save: ${r} (now ${g.sync() >= 0 ? g.peek(v) : '-'})`);
    }
  },
  // a save file damaged: its length, its tag, its version, a byte of it (checksum wrong): a new
  // player, no crash
  badfile() {
    if (model.includes('64')) { console.log('     (the LZ64 keeps A: in banked RAM this rig cannot search: run on lz)'); return; }
    for (const [what, f] of [['length', (g, at) => g.m.poke(at - 3, 7)], ['tag', (g, at) => g.m.poke(at - 2, 0x41)],
      ['version', (g, at) => g.m.poke(at - 1, 1)], ['a byte', (g, at) => g.m.poke(at + 3, g.m.peek(at + 3) ^ 0x40)]]) {
      const g = new Game(model);
      g.start();
      [0, 0, 0x30, 0x39].forEach((b, k) => g.poke('kv_bal', b, k));        // 12,345 credits
      quit(g);
      const at = findSave(g, g.lastBal);
      if (!ok(at > 0, `${what}: the save record found`)) continue;
      f(g, at);
      g.m.runProc('SANTA', 'B');
      g.run(8);
      const fresh = g.sync() >= 0 && g.peek32('kv_bal') === 1000;
      const r = bash(g, 60, 9);
      ok(fresh && r === 'ok', `damaged ${what}: a new player ${fresh}, ${r}`);
    }
  },
  // credits at the edges: none, one short of a stake, and more than the panel has room for
  balances() {
    for (const [bal, bet] of [[0, 0], [19, 0], [20, 0], [39, 1], [199, 3], [99999, 3], [999999, 3], [9999999, 3], [99999999, 3], [999999999, 3], [4294967000, 3]]) {
      const g = new Game(model);
      g.start();
      for (let k = 0; k < 4; k++) { g.poke('kv_bal', (bal >>> (24 - 8 * k)) & 255, k); g.poke('kv_dbal', (bal >>> (24 - 8 * k)) & 255, k); }
      g.poke('kv_bet', bet);
      let r = 'ok', last = '';
      for (let i = 0; i < 6 && r === 'ok'; i++) {
        try { g.spin(undefined, 1); } catch (e) { r = e.message; }
        last = g.scr().join(' | ');
        if (isErr(g)) r = 'error';
      }
      const b = g.peek32('kv_bal'), d = g.peek32('kv_dbal');
      ok(r === 'ok' && b === d && (bal < 4e9 ? b < 4e9 : true), `credits ${bal} bet ${[1, 2, 5, 10][bet]}: ${r}; now ${b} shown ${d}; ${last}`);
    }
  },
  // the pack pulled out at rest, a key pressed; then put back
  pack() {
    const g = new Game(model);
    g.start();
    g.m.removePack(0);
    g.press('EXE'); g.run(10);
    console.log('     pack out, EXE:', one(g.text()), '| on', g.m.isOn(), '| kernel', g.sync() >= 0);
    g.m.insertPack(path.join(g.bdir, 'SPINS.opk'), 0);
    g.press('EXE'); g.run(10);
    console.log('     pack back, EXE:', one(g.text()));
    ok(g.m.isOn(), 'still on after the pack came out and back');
  },
  // left at rest with idle scenes on and the Organiser set to switch off after 15 s: it does so
  // only once the game has been idle 5 minutes (not in the middle of the snow or a scene); on
  // again, the screen as it was and play goes on
  switchoff() {
    const g = new Game(model);
    g.start();
    const before = g.scr().join('|');
    g.m.pokew(0x20CD, 15);
    let t = 0;
    while (g.m.isOn() && t < 600) { g.run(1); t++; }
    ok(t >= 300 && t < 420, `switched off after ${t} s idle (5 minutes, then the Organiser's 15 s)`);
    g.press('ON', 4, 4); g.run(3);
    const after = g.scr().join('|');
    ok(g.m.isOn() && after === before, `on again: the same screen ${after === before}\n     ${before}\n     ${after}`);
    try { g.spin(undefined, 1); ok(!isErr(g), 'a spin after'); } catch (e) { ok(false, 'a spin after: ' + e.message); }
  },
  // autoplay for longer than the Organiser's switch-off time: never switched off in the middle
  autoplay() {
    const g = new Game(model);
    g.start();
    g.m.pokew(0x20CD, 15);
    g.press('MODE'); g.run(1); g.press('DOWN'); g.run(0.3); g.press('DOWN'); g.run(0.3); g.press('EXE'); g.run(1);
    g.press('DOWN'); g.run(0.3); g.press('DOWN'); g.run(0.3); g.press('EXE'); g.run(1);   // 50 spins
    const n = g.peek('kv_auto');
    let t = 0;
    while (g.m.isOn() && g.peek('kv_auto') && t < 900) { g.run(1); t++; }
    ok(n === 50 && g.m.isOn() && g.peek('kv_auto') === 0, `autoplay of ${n}: on ${g.m.isOn()} after ${t} s, ${g.peek('kv_auto')} left`);
  },
  // the Xmas Spins' show counted by OV_GAME (G_XINIT, G_FREE) against ref/game.js, at the
  // 250-spin cap: a feature of 249 whose first spin adds two (one is allowed), and of 20
  cap() {
    const R = require('../ref/game.js');
    const g = new Game(model);
    g.start();
    const G = R.grid(g.m.lines === 4 ? 'four' : 'two');
    let seed = 1;
    while (R.freeSpin(G, new R.Rng(seed)).extra < 2) seed++;
    for (const n of [249, 20, 1]) {
      const ref = R.feature(G, new R.Rng(seed), n);
      for (let k = 0; k < 4; k++) g.poke('kv_fseed', (seed >>> (24 - 8 * k)) & 255, k);
      g.poke('kv_fn', n);
      const id = g.ids().OV_GAME;
      g.call(id, 5);                                  // G_XINIT
      const ok0 = g.peek('kv_fleft') === n && g.peek('kv_fsofar') === n && g.peek('kv_fidx') === 0;
      let calls = 0, same = true;
      while (g.peek('kv_fleft') && calls < 300) {
        g.poke('kv_fidx', g.peek('kv_fidx') + 1);
        const r = g.call(id, 1);                      // G_FREE: A = its extra spins
        if (r.a !== ref.spins[calls].extra) same = false;
        calls++;
      }
      ok(ok0 && same && calls === ref.spins.length && g.peek('kv_fsofar') === ref.count,
        `a feature of ${n} (seed ${seed}): ${calls} spins shown, ${g.peek('kv_fsofar')} known; ref ${ref.spins.length}, ${ref.count}`);
    }
  },
  // while a tune plays (Santa's walks, wins, scenes), the tune buffer holds that tune intact and
  // both voices read inside it
  tunebuf() {
    const fs = require('fs');
    const tunes = Object.entries(JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'build', 'sounds.json'))).tunes);
    const g = new Game(model);
    g.start();
    g.poke('kv_styles', 0);
    const T = g.addr('TUNEAT'), voice = (v) => g.addr(v);
    let samples = 0, badn = 0, names = new Set(), note = '';
    const check = () => {
      if (g.m.peek(g.base + 3) !== 0x53) return;      // (an LZ64 mid-file-call: the other bank is in)
      if (!g.peek('kv_tnt')) return;
      samples++;
      const buf = g.m.read(T, 121);
      const hit = tunes.find(([, b]) => b.every((x, i) => buf[i] === x));
      const vp = g.m.peekw(voice('kv_tune')), bp = g.m.peekw(voice('kv_bass'));
      const inb = (p, len) => p >= T && p <= T + len;
      if (!hit || !inb(vp, hit[1].length) || (buf[2] && g.peek('kv_bass', 4) && !inb(bp, hit[1].length))) {
        badn++; if (!note) note = `buffer ${buf.slice(0, 8)} vp ${vp - T} bp ${bp - T} res ${g.peek('kv_res')}`;
      } else names.add(hit[0]);
    };
    for (let i = 0; i < 38; i++) {
      const s = g.seedFor(i < 30 ? (b) => b.santa : (b) => b.total > 100, 1 + i * 997);
      try { g.spin(s, 0.05, check); } catch (e) { badn++; note = note || e.message; }
    }
    ok(badn === 0 && samples > 100, `${samples} samples while a tune played (${[...names].join(' ')}): ${badn} bad ${note}`);
  },
  // EXE held down for a minute (the keyboard repeats it): spin after spin, then let go
  holdexe() {
    const g = new Game(model);
    g.start();
    const s0 = g.peek32('st_spins');
    g.m.keyDown('EXE');
    let err = '';
    for (let t = 0; t < 60 && !err; t++) { g.run(1); if (isErr(g) || !g.m.isOn()) err = one(g.text()); }
    g.m.keyUp('EXE');
    const r = toRest(g, 300);
    ok(!err && r === 'rest' && g.peek32('kv_bal') === g.peek32('kv_dbal'),
      `${g.peek32('st_spins') - s0} spins with EXE held; ${err || r}; credits ${g.peek32('kv_bal')} shown ${g.peek32('kv_dbal')}`);
  },
  // autoplay chosen (A) or Spin chosen from the menu: the list's letters must not stay in the gaps
  // between the reels while the spin plays (a letter counts if it is still there 50 ms later)
  gaps() {
    for (const how of ['A', 'menu']) {
      const g = new Game(model);
      g.start();
      if (how === 'A') { g.press('A'); g.run(1); g.press('EXE'); } else { g.press('MODE'); g.run(1); g.press('EXE'); }
      const gaps = g.m.lines === 4 ? [1, 3, 5, 7, 9] : [5];
      const junk = new Set(); let prev = new Set();
      for (let t = 0; t < 8; t += 0.05) {
        g.run(0.05);
        const c = g.scr(), now = new Set();
        for (let y = 0; y < c.length; y++) for (const x of gaps) if (!/[ 0-7.=_+]/.test(c[y][x])) now.add(`${c[y][x]}@${y},${x}`);
        for (const k of now) if (prev.has(k)) junk.add(k);
        prev = now;
      }
      ok(!junk.size, `${how === 'A' ? 'autoplay chosen' : 'Spin from the menu'}: ${junk.size ? 'letters between the reels ' + [...junk].join(' ') : 'nothing between the reels'}`);
    }
  },
  // the last reel's last cell: its half-landed frame (the lander, glyph 7) is replaced by the
  // symbol within a frame or two, not left on the screen while the next overlay loads
  landing() {
    const g = new Game(model);
    g.start();
    const W = g.m.cols, cell = g.m.lines === 4 ? 3 * W + 8 : W + 4;
    let worst = 0;
    for (let k = 0; k < 8; k++) {
      let since = -1;
      const s = g.seedFor(k % 2 ? (b) => b.santa : (b) => !b.santa, 1 + k * 311);
      g.spin(s, 0.002, (t) => {
        const ch = g.m.cells()[cell];
        if (ch === 7) { if (since < 0 && g.peek('kv_res') === g.ids().OV_SPINFX) since = t; } else if (since >= 0) { worst = Math.max(worst, t - since); since = -1; }   // (glyph 7 is also Santa's window later)
      }, 300);
    }
    ok(worst < 0.1, `the bottom-right cell's half-landed frame stays at most ${(worst * 1000).toFixed(0)} ms`);
  },
  // the pack in slot C instead of B
  slotc() {
    const g = new Game(model);
    g.m.removePack(0);
    g.m.insertPack(path.join(g.bdir, 'SPINS.opk'), 1);
    g.m.runProc('SANTA', 'C');
    let started = false;
    for (let i = 0; i < 100 && !started; i++) { g.run(0.25); started = g.sync() >= 0; }
    const r = started ? toRest(g, 120) : 'did not start: ' + one(g.text());
    ok(started && r === 'rest', `run from C: ${r}`);
    if (started) { try { g.spin(undefined, 1); ok(!isErr(g), 'a spin from C'); } catch (e) { ok(false, 'spin from C: ' + e.message); } }
  },
};
for (const [n, f] of Object.entries(runs)) {
  if (only.length && !only.includes(n)) continue;
  console.log(`-- ${n}`);
  try { f(); } catch (e) { ok(false, `${n} threw ${e.message.split('\n')[0]}`); }
}
console.log(bad ? `${bad} FAILED` : 'all ok');
process.exit(bad ? 1 : 0);
