; =====================================================================
; OV_IDLE: when the reels are left alone. Entry 0: snow falls in the
; lanes between the reels (four lines; stage characters 4 and 5 tiled,
; their rows turning) until a key. Entry 1: an idle scene, in turn.
; =====================================================================
        include "../defs.inc"

        jmp  oi_snow
        jmp  oi_scene

oi_snow:
        clr  oi_n
        ldx  #oi_f1             ; the two flake patterns
        ldaa #4
        jsr  glyph_ld
        ldx  #oi_f2
        ldaa #5
        jsr  glyph_ld
        ldaa #4                 ; the lanes: columns 2, 4, 6, 8, 10 (1-based)
        bsr  oi_lanes
.l:     ldx  #kv_glyph+32       ; the snow falls: each glyph's rows turn down
        bsr  oi_turn
        ldx  #kv_glyph+40
        bsr  oi_turn
        ldaa #$30
        oraa kv_gdirty
        staa kv_gdirty
        ldaa #12
        jsr  frame
        tst  kv_key
        bne  .x
        inc  oi_n               ; 256 frames (about 25 s), then back to the
        bne  .l                 ; reels (still idle)
.x:     ldaa #' '               ; a key: the lanes clear (the key is kept)
        bsr  oi_lanes
        jsr  flush
        clra
        rts
; A = 4 (snow) or ' ': into the lane cells, 4 and 5 in turn
oi_lanes:
        staa oi_c
        ldab #1
.c:     stab oi_col
        clr  oi_row
.r:     ldaa oi_row
        ldab #20
        mul
        addb oi_col
        ldaa oi_c
        cmpa #' '
        beq  .p
        ldaa oi_row             ; 4 and 5 alternate down and across
        adda oi_col
        anda #1
        adda #4
.p:     jsr  put
        inc  oi_row
        ldaa oi_row
        cmpa #4
        bne  .r
        ldab oi_col
        addb #2
        cmpb #11
        blo  .c
        rts
; X = a glyph: its rows turned down by one (the bottom one to the top)
oi_turn:
        ldaa 7,x
        ldab #7
.t:     pshb
        ldab 6,x
        stab 7,x
        pulb
        dex
        decb
        bne  .t
        staa 7,x
        rts
oi_f1:  fcb  $04,$00,$00,$10,$00,$02,$00,$00
oi_f2:  fcb  $00,$08,$00,$00,$01,$00,$00,$10

; entry 1: the village, the chimney, the reindeer: one at random
oi_scene:
        jsr  rng_cos
.m:     cmpa #3
        blo  .k
        suba #3
        bra  .m
.k:     adda #S_VILLAGE
        staa kv_arg
        ldaa #C_SCENE
        rts

oi_c:   fcb  0
oi_n:   fcb  0                  ; the snow's frames
oi_col: fcb  0
oi_row: fcb  0
