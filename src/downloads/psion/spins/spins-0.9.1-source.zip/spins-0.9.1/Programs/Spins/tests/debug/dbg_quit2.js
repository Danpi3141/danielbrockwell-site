const { Game } = require('../lib');
const g = new Game(process.argv[2] || 'lz64');
g.start();
const names = Object.fromEntries(Object.entries(g.ids()).map(([k, v]) => [v, k]));
g.spin(g.seedFor((b) => b.total > 0 && !b.santa && !b.freeSpins, 50), 1);
g.m.press('UP', 3, 6); g.m.press('UP', 3, 6);
g.run(0.5);
console.log(g.scr().join('|'));
g.m.press('ON', 3, 10); g.run(0.5);
console.log(g.scr().join('|'));
g.m.press('EXE', 3, 10);
for (let i = 0; i < 14; i++) { g.run(0.5); console.log((i/2+0.5).toFixed(1), names[g.peek('kv_res')], g.text().split('\n').join('|')); }
const prof = require('../profile');
const p = prof(g, 'OV_SCENE', () => g.run(1));
console.log(p.slice(0, 8));
console.log('kv_sdep', g.peek('kv_sdep'), 'ip', (g.peekw('kv_ip') - g.base).toString(16), 'scene', (g.peekw('kv_scene') - g.base).toString(16));
console.log('on', g.m.isOn(), 'pc', g.m.dbg.pc().toString(16), 'sleep', g.m.dbg.sleeping(), 'tout', g.m.peekw(0x7d), 'tcnt', g.m.peekw(0x20cd), 'I', (g.m.dbg.p() & 0x10) ? 'masked' : 'on');
