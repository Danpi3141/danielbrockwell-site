#!/usr/bin/env python3
"""The script assembler, tune compiler and effect compiler.

A blob (scripts/*.scr) is what one director reads into the scene buffer:

    blob NAME                   the item IT_NAME
    pose STAND WALK1 ...        poses from art/santa.txt, numbered in this order
    art  HOUSE PRESENT ...      glyphs from art/*.txt (8 bytes each)
    tune JINGLE ...             tunes from data/tunes.txt
    effect STEP THROW ...       effects from data/effects.txt
    cel  STAR TREE ...          cels from art/cels.txt
    script NAME                 a script, to 'end'
      COMMAND args             (see src/kernel/kscript.asm)
      label:                   for JUMP, CALL and PICK
      IF2: ... ENDIF            only on two lines (IF4: on four)
      SETTING n: ... ENDSET     only at Animation n or above
    end

Arguments are numbers, names (poses, art, tunes, effects, cels, scripts, labels), "text", or
{a|b}: a on two lines, b on four (the command is assembled twice, under IF2 and IF4).

The blob: six words (offsets from its start) to its poses, art, tunes table, effects table,
cels table and scripts table; then those.
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import art  # noqa: E402

CMDS = {'END': 0, 'FRAME': 1, 'TUNE': 2, 'EFFECT': 3, 'LOOP': 4, 'AGAIN': 5, 'CALL': 6, 'BACK': 7,
        'PICK': 8, 'IF2': 9, 'IF4': 10, 'HOOK': 11, 'JUMP': 12, 'CEL': 13, 'WIPE': 14, 'WINDOW': 15,
        'SLIDE': 16, 'NOKEY': 17, 'TXT': 18}      # (src/kernel/kscript.asm; ov_scene.asm: the stage's)
# argument kinds: b byte, s signed byte, w word offset (a label or script), t text, n (PICK) count + words
ARGS = {'FRAME': 'b', 'TUNE': 'u', 'EFFECT': 'e', 'LOOP': 'b', 'CALL': 'w', 'HOOK': 'b', 'JUMP': 'w',
        'CEL': 'css', 'WINDOW': 'bsb', 'SLIDE': 's', 'PICK': 'n', 'TXT': 'bbt'}

NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
LENS = {1: 0, 2: 1, 3: 2, 4: 3, 6: 4, 8: 5, 12: 6, 16: 7}


class ScriptError(Exception):
    pass


def semis(n):
    n = n.strip()
    m = re.match(r'^([A-G]#?)(\d)$', n)
    if not m:
        raise ScriptError('not a note: %r' % n)
    return NOTE_NAMES.index(m.group(1)) + 12 * int(m.group(2))


def note_number(n):
    """The game's note number: E4 = 0, C8 = 44."""
    v = semis(n) - semis('E4')
    if not 0 <= v <= 44:
        raise ScriptError('note %s out of range (E4..C8)' % n)
    return v


# ---------------------------------------------------------------- tunes
def parse_tunes(path):
    """data/tunes.txt: 'tune NAME base=C5 unit=15 [loop]' then notes 'E5:2' (pitch:units),
    'R:2' a rest, '|' bar lines (ignored), ';' comments, until the next tune. Lines that start
    'bass' are the second part (notes E4..A#6, from note 0), as long as the melody."""
    tunes = {}
    cur = None
    with open(path, encoding='utf-8') as f:
        for no, line in enumerate(f, 1):
            line = line.split(';', 1)[0].strip()
            if not line:
                continue
            m = re.match(r'^tune\s+(\w+)\s+base=(\S+)\s+unit=(\d+)(\s+loop)?$', line)
            if m:
                cur = {'name': m.group(1), 'base': note_number(m.group(2)), 'unit': int(m.group(3)),
                       'loop': bool(m.group(4)), 'notes': [], 'bass': []}
                tunes[cur['name']] = cur
                continue
            if cur is None:
                raise ScriptError('%s:%d: notes before a tune' % (path, no))
            part, base = cur['notes'], cur['base']
            if line.startswith('bass'):
                part, base, line = cur['bass'], 0, line[4:]
            for tok in line.replace('|', ' ').split():
                p, _, l = tok.partition(':')
                units = int(l or 1)
                if units not in LENS:
                    raise ScriptError('%s:%d: length %d (1 2 3 4 6 8 12 16)' % (path, no, units))
                if p.upper() == 'R':
                    pc = 31
                else:
                    pc = note_number(p) - base
                    if not 0 <= pc <= 30:
                        raise ScriptError('%s:%d: %s is %d above the base' % (path, no, p, pc))
                part.append(pc << 3 | LENS[units])
    units = {v: k for k, v in LENS.items()}
    for t in tunes.values():
        a, b = (sum(units[n & 7] for n in t[k]) for k in ('notes', 'bass'))
        if t['bass'] and a != b:
            raise ScriptError('tune %s: the melody is %d units, the bass %d' % (t['name'], a, b))
    return tunes


def tune_bytes(t):
    if not 1 <= t['unit'] <= 127:
        raise ScriptError('tune %s: unit %d' % (t['name'], t['unit']))
    bass = bytes(t['bass']) + b'\xff' if t['bass'] else b''
    return (bytes([t['base'], t['unit'] | (128 if t['loop'] else 0), len(t['notes']) + 4 if bass else 0]) +
            bytes(t['notes']) + b'\xff' + bass)


# ---------------------------------------------------------------- effects
FX = {'rest': 0, 'tone': 1, 'slide': 2, 'arp': 3, 'noise': 4, 'click': 5, 'bell': 6, 'vib': 7}


def parse_effects(path):
    """data/effects.txt: 'effect NAME: cell; cell; ...' (a line may continue on the next ones,
    indented). Cells: rest T | tone NOTE T [shift] | slide NOTE STEP T | arp N1 N2 [N3] T |
    noise RATE T | click T | bell NOTE T | vib NOTE DEPTH T   (T = ticks of 1/120 s)."""
    effects = {}
    text = open(path, encoding='utf-8').read()
    text = re.sub(r'\n[ \t]+', ' ', text)
    for no, line in enumerate(text.splitlines(), 1):
        line = re.sub(r'\s;;.*$', '', line).strip()
        if not line or line.startswith(';;'):
            continue
        m = re.match(r'^effect\s+(\w+)\s*:(.*)$', line)
        if not m:
            raise ScriptError('%s: what is %r' % (path, line))
        out = bytearray()
        for cell in m.group(2).split(';'):
            w = cell.split()
            if not w:
                continue
            k = w[0]
            if k not in FX:
                raise ScriptError('effect %s: no cell %r' % (m.group(1), k))
            a = w[1:]
            if k == 'rest' or k == 'click':
                out += bytes([FX[k], int(a[0])])
            elif k == 'tone':
                out += bytes([FX[k], int(a[1]), note_number(a[0]), int(a[2]) if len(a) > 2 else 1])
            elif k == 'slide':
                out += bytes([FX[k], int(a[2]), note_number(a[0]), int(a[1]) & 255])
            elif k == 'arp':
                notes = [note_number(x) for x in a[:-1]]
                out += bytes([FX[k], int(a[-1]), notes[0], notes[1], notes[2] if len(notes) > 2 else 255])
            elif k == 'noise':
                out += bytes([FX[k], int(a[1]), int(a[0])])
            elif k == 'bell':
                out += bytes([FX[k], int(a[1]), note_number(a[0])])
            elif k == 'vib':
                out += bytes([FX[k], int(a[2]), note_number(a[0]), int(a[1])])
            if out[-1 if k in ('rest', 'click') else 1] == 0 and k not in ('rest', 'click'):
                pass
        effects[m.group(1)] = bytes(out) + b'\xff'
    return effects


# ---------------------------------------------------------------- blobs
class Blob:
    def __init__(self, name):
        self.name = name
        self.lists = {'pose': [], 'art': [], 'tune': [], 'effect': [], 'cel': []}
        self.scripts = []          # (name, lines)


def parse_scripts(path):
    blobs = []
    cur = None
    script = None
    with open(path, encoding='utf-8') as f:
        for no, raw in enumerate(f, 1):
            line = re.sub(r'(^|\s);.*$', '', raw).strip()
            if not line:
                continue
            w = line.split()
            if script is not None:
                if w[0].lower() == 'end' and len(w) == 1:
                    cur.scripts.append(script)
                    script = None
                else:
                    script[1].append((no, line))
                continue
            if w[0] == 'blob':
                cur = Blob(w[1])
                blobs.append(cur)
            elif w[0] in ('pose', 'art', 'tune', 'effect', 'cel'):
                cur.lists[w[0]] += w[1:]
            elif w[0] == 'data':                 # raw data, kept with the cels
                cur.lists['cel'] += ['=' + n for n in w[1:]]
            elif w[0] == 'bytes':                # literal bytes, kept with the cels
                if not all(re.match(r'^\d+$', v) and int(v) < 256 for v in w[1:]):
                    raise ScriptError('%s:%d: bytes are numbers 0-255' % (path, no))
                cur.lists['cel'].append('#' + ','.join(w[1:]))
            elif w[0] == 'script':
                script = (w[1], [])
            else:
                raise ScriptError('%s:%d: what is %r' % (path, no, line))
    return blobs


def split_args(s):
    out = []
    for m in re.finditer(r'"[^"]*"|\{[^}]*\}|[^\s,]+', s):
        out.append(m.group(0))
    return out


class Assembler:
    def __init__(self, blob, where):
        self.blob = blob
        self.where = where
        self.names = {}
        for kind, lst in blob.lists.items():
            for i, n in enumerate(lst):
                self.names[(kind, n.lstrip('='))] = i
        self.script_names = [s[0] for s in blob.scripts]

    def value(self, tok, kind, two):
        if tok.startswith('{'):
            a, b = tok[1:-1].split('|')
            tok = (a if two else b).strip()
        if re.match(r'^-?(\d+|\$[0-9A-Fa-f]+)$', tok):
            return int(tok.replace('$', '0x'), 0)
        if len(tok) == 3 and tok[0] == "'" and tok[2] == "'":
            return ord(tok[1])
        for k in kind:
            if (k, tok) in self.names:
                return self.names[(k, tok)]
        raise ScriptError('%s: unknown %s %r' % (self.where, '/'.join(kind), tok))

    def assemble(self, name, lines):
        """-> (bytes, fixups) where fixups are (offset, label) for word offsets in the blob."""
        out = bytearray()
        labels = {}
        refs = []          # (offset in out, label)
        stack = []
        for no, line in lines:
            where = '%s, script %s, line %d' % (self.where, name, no)
            self.where_line = where
            if line.endswith(':') and re.match(r'^\.?\w+:$', line):
                labels[line[:-1]] = len(out)
                continue
            w = line.split(None, 1)
            op = w[0].upper()
            rest = w[1] if len(w) > 1 else ''
            if op in ('IF2:', 'IF4:', 'SETTING'):
                if op == 'SETTING':
                    m = re.match(r'^(\d+)\s*:$', rest)
                    if not m:
                        raise ScriptError(where + ': SETTING n:')
                    out += bytes([CMDS['SETTING'], int(m.group(1)), 0])
                else:
                    out += bytes([CMDS[op[:-1]], 0])
                stack.append((op, len(out)))
                continue
            if op in ('ENDIF', 'ENDSET'):
                if not stack:
                    raise ScriptError(where + ': %s without a start' % op)
                kind, at = stack.pop()
                n = len(out) - at
                if n > 255:
                    raise ScriptError(where + ': a section of %d bytes' % n)
                out[at - 1] = n
                continue
            if op not in CMDS:
                raise ScriptError(where + ': no command %s' % op)
            args = split_args(rest)
            if any(a.startswith('{') for a in args):
                for two, cond in ((True, 'IF2'), (False, 'IF4')):
                    body, brefs = self.command(op, args, two, where)
                    out += bytes([CMDS[cond], len(body)])
                    refs += [(len(out) + o, l) for o, l in brefs]
                    out += body
            else:
                body, brefs = self.command(op, args, True, where)
                refs += [(len(out) + o, l) for o, l in brefs]
                out += body
        if stack:
            raise ScriptError('%s, script %s: %s not closed' % (self.where, name, stack[-1][0]))
        if not out or out[-1] != 0:
            out.append(0)
        return bytes(out), labels, refs

    def command(self, op, args, two, where):
        kinds = ARGS.get(op, '')
        out = bytearray([CMDS[op]])
        refs = []
        if op == 'PICK':
            out.append(len(args))
            for a in args:
                refs.append((len(out), a))
                out += b'\0\0'
            return out, refs
        if len(args) != len(kinds):
            raise ScriptError('%s: %s takes %d arguments' % (where, op, len(kinds)))
        for k, a in zip(kinds, args):
            if k == 'b':
                v = self.value(a, (), two)
                if not 0 <= v <= 255:
                    raise ScriptError('%s: %d is not a byte' % (where, v))
                out.append(v)
            elif k == 's':
                v = self.value(a, (), two)
                if not -128 <= v <= 127:
                    raise ScriptError('%s: %d is not a signed byte' % (where, v))
                out.append(v & 255)
            elif k == 'p':
                out.append(self.value(a, ('pose',), two))
            elif k == 'a':
                out.append(self.value(a, ('art',), two))
            elif k == 'u':
                out.append(255 if a.upper() == 'STOP' else self.value(a, ('tune',), two))
            elif k == 'e':
                out.append(self.value(a, ('effect',), two))
            elif k == 'c':
                if a.startswith('P:'):                  # a pose as a cel: 128 + its number
                    out.append(128 + self.value(a[2:], ('pose',), two))
                else:
                    out.append(self.value(a, ('cel',), two))
            elif k == 't':
                if not (a.startswith('"') and a.endswith('"')):
                    raise ScriptError('%s: text in quotes' % where)
                t = a[1:-1].replace('_', ' ')
                out += bytes([len(t)]) + t.encode('latin-1')
            elif k == 'w':
                refs.append((len(out), a))
                out += b'\0\0'
        return out, refs


def build_blob(blob, sources, where, limit=None):
    """sources: {'poses', 'art', 'tunes', 'effects', 'cels'} dicts of name -> bytes."""
    asm = Assembler(blob, where)
    poses = b''.join(_need(sources['poses'], n, 'pose', where) for n in blob.lists['pose'])
    arts = b''.join(_need(sources['art'], n, 'art', where) for n in blob.lists['art'])
    tunes = [_need(sources['tune_items'], n, 'tune', where) for n in blob.lists['tune']]
    effects = [_need(sources['effects'], n, 'effect', where) for n in blob.lists['effect']]
    cels = [_need(sources['data'], n[1:], 'data', where) if n.startswith('=') else
            bytes(int(v) for v in n[1:].split(',')) if n.startswith('#') else _need(sources['cels'], n, 'cel', where)
            for n in blob.lists['cel']]
    out = bytearray(12)

    def table(items):
        at = len(out)
        out.extend(bytes(2 * len(items)))
        for i, it in enumerate(items):
            out[at + 2 * i:at + 2 * i + 2] = len(out).to_bytes(2, 'big')
            out.extend(it)
        return at

    hdr = [0] * 6
    hdr[0] = len(out)
    out += poses
    hdr[1] = len(out)
    out += arts
    hdr[2] = len(out)                       # the tunes: their item numbers
    for t in tunes:
        out.extend(t.to_bytes(2, 'big'))
    hdr[3] = table(effects)
    hdr[4] = table(cels)
    # scripts: assembled, then their labels (and other scripts' names) resolved
    sc = [asm.assemble(n, lines) for n, lines in blob.scripts]
    hdr[5] = len(out)
    out.extend(bytes(2 * len(sc)))
    starts = []
    for i, (code, labels, refs) in enumerate(sc):
        starts.append(len(out))
        out[hdr[5] + 2 * i:hdr[5] + 2 * i + 2] = len(out).to_bytes(2, 'big')
        out.extend(code)
    names = {n: starts[i] for i, (n, _) in enumerate(blob.scripts)}
    for i, (code, labels, refs) in enumerate(sc):
        for off, lab in refs:
            if lab in labels:
                v = starts[i] + labels[lab]
            elif lab in names:
                v = names[lab]
            else:
                raise ScriptError('%s, script %s: no label %s' % (where, blob.scripts[i][0], lab))
            out[starts[i] + off:starts[i] + off + 2] = v.to_bytes(2, 'big')
    for i, v in enumerate(hdr):
        out[2 * i:2 * i + 2] = v.to_bytes(2, 'big')
    if limit is not None and len(out) > limit:
        raise ScriptError('blob %s is %d bytes, over the scene buffer (%d)' % (blob.name, len(out), limit))
    return bytes(out), {n: i for i, (n, _) in enumerate(blob.scripts)}


def _need(d, n, kind, where):
    if n not in d:
        raise ScriptError('%s: no %s %s' % (where, kind, n))
    return d[n]


def load_sources():
    """All the art, tunes and effects by name."""
    poses = {}
    glyphs = {}
    cels = {}
    for fn in sorted(os.listdir(os.path.join(ROOT, 'art'))):
        if not fn.endswith('.txt'):
            continue
        items, order = art.parse(os.path.join(ROOT, 'art', fn))
        for n in order:
            it = items[n]
            d = {'pose': poses, 'glyph': glyphs, 'cel': cels}[it['kind']]
            if n in d:
                raise ScriptError('art %s twice' % n)
            d[n] = art.encode(it)
    tunes = {}
    tp = os.path.join(ROOT, 'data', 'tunes.txt')
    if os.path.exists(tp):
        tunes = {n: tune_bytes(t) for n, t in parse_tunes(tp).items()}
    effects = {}
    ep = os.path.join(ROOT, 'data', 'effects.txt')
    if os.path.exists(ep):
        effects = parse_effects(ep)
    return {'poses': poses, 'art': glyphs, 'cels': cels, 'tunes': tunes, 'effects': effects, 'data': dict(DATA),
            'tune_items': dict(TUNE_ITEMS)}


TUNE_ITEMS = {}  # tune name -> its item number (set by tools/build.py)
DATA = {}       # raw data items for blobs (set by tools/build.py: the font table, ...)
