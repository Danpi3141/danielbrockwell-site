; ---------------------------------------------------------------------
; (Included by OV_PAYS and OV_INFO: the pages viewer and line builders)
; ---------------------------------------------------------------------
; ---- the pages viewer: oi_n pages (halves on two lines), oi_page
; called with A = page to set X to its four lines ----
oi_view:
        clr  oi_k
.d:     jsr  cls
        ldaa oi_k               ; the page (and on two lines, which half)
        tst  kv_four
        bne  .f
        lsra
.f:     jsr  oi_get
        stx  oi_x
        clr  oi_ln
        ldaa oi_k               ; two lines: the second half starts at line 2
        tst  kv_four
        bne  .l
        anda #1
        asla
        staa oi_ln
        ldx  oi_x
        tsta
        beq  .l
        bsr  .skip
        bsr  .skip
        stx  oi_x
.l:     ldaa oi_ln              ; this screen line: page line - first line
        tst  kv_four
        bne  .r
        anda #1
.r:     ldab kv_w
        mul
        ldx  oi_x
        pshx
        jsr  txt_at
        pulx
        bsr  .skip
        stx  oi_x
        inc  oi_ln
        ldaa oi_ln
        tst  kv_four
        bne  .e
        anda #1
        bne  .l
        bra  .k
.e:     cmpa #4
        bne  .l
.k:     clra
        jsr  key_wait
        cmpb #K_DOWN
        beq  .dn
        cmpb #K_RIGHT
        beq  .dn
        cmpb #K_UP
        beq  .up
        cmpb #K_LEFT
        beq  .up
        clra                    ; any other key: back
        rts
.dn:    inc  oi_k
        ldaa oi_k
        cmpa oi_n
        bne  .d
        clr  oi_k
        bra  .d
.up:    dec  oi_k
        bpl  .d
        ldaa oi_n
        deca
        staa oi_k
        bra  .d
.skip:  ldab 0,x                ; X past a string with its length
        incb
        abx
        rts

; oi_n = A pages (doubled on two lines)
oi_pages:
        tst  kv_four
        bne  .x
        asla
.x:     staa oi_n
        rts

; A = page: X = its lines
oi_get: ldx  oi_fn
        jmp  0,x

; A = page: X = the first of its four lines, from a list of pages at X
oi_nth: asla
        asla
        tab
oi_skipb:
        tstb
        beq  .x
.l:     pshb
        ldab 0,x
        incb
        abx
        pulb
        decb
        bne  .l
.x:     rts
; ---- building lines in oi_buf ----
oi_lstart:
        ldx  oi_p
        stx  oi_lp
        inx
        stx  oi_p
        rts
oi_lend:
        ldd  oi_p
        subd oi_lp
        decb
        ldx  oi_lp
        stab 0,x
        rts
oi_ch:  ldx  oi_p
        staa 0,x
        inx
        stx  oi_p
        rts
; X = a string with its length: appended
oi_str: ldab 0,x
        beq  .x
.l:     inx
        ldaa 0,x
        pshx
        bsr  oi_ch
        pulx
        decb
        bne  .l
.x:     rts
; D = a number: appended in decimal / X = a 4-byte number
oi_num: jsr  set32
oi_num32:
        jsr  num_dec
        ldx  #kv_nb
.s:     ldaa 0,x
        cmpa #' '
        bne  .d
        inx
        bra  .s
.d:     ldaa 0,x
        pshx
        bsr  oi_ch
        pulx
        inx
        cpx  #kv_nb+10
        bne  .d
        rts

oi_fn:  fdb  0
oi_x:   fdb  0
oi_p:   fdb  0
oi_lp:  fdb  0
oi_t:   fdb  0
oi_k:   fcb  0
oi_n:   fcb  0
oi_ln:  fcb  0
oi_s:   fcb  0
oi_c:   fcb  0
oi_c2:  fcb  0
oi_nn:  rmb  4
oi_dd:  rmb  4
oi_q:   rmb  4
oi_r:   rmb  4
oi_buf: rmb  72
oi_data:                        ; the tables, read in here
