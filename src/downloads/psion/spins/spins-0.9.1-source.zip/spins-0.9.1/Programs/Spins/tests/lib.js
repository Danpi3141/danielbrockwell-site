// Test helpers: Psion Spins on an emulated Organiser (tools/emu.js). The kernel is found in RAM
// by its "SPK1" tag; its variables are read through the build's symbol table.
'use strict';
const fs = require('fs');
const path = require('path');
const { Machine } = require('../tools/emu');

const ROOT = path.join(__dirname, '..');
const TAG = [0x53, 0x50, 0x4B, 0x31];   // "SPK1"
const MODELS = {
  cm: { rom: '33-cm.rom', ram: 8 }, cm24: { rom: '24-cm.rom', ram: 8 }, cm26: { rom: '26-cm.rom', ram: 8 },
  xp: { rom: '31-xp.rom', ram: 16 }, xp24: { rom: '24-xp.rom', ram: 16 }, xp26: { rom: '26-xp.rom', ram: 16 },
  la: { rom: '36-la.rom', ram: 32 }, lz: { rom: '46-lz.rom', ram: 32 }, lz64: { rom: '46a-lz64.rom', ram: 64 },
};
// every Organiser ROM the emulator has (not the POS terminals), and its RAM in K
const ROMS = {
  '24-cm.rom': 8, '26-cm.rom': 8, '33-cm.rom': 8, '33-cmf.rom': 8, '36-cmf.rom': 8,
  '24-xp.rom': 16, '26-xp.rom': 16, '31-xp.rom': 16,
  '30-lahp.rom': 32, '33-la.rom': 32, '34-lag.rom': 32, '36-la.rom': 32, '36-laf.rom': 32, '36-lag.rom': 32, '37-lam.rom': 32,
  '42-lz.rom': 32, '44-lz.rom': 32, '45-lz.rom': 32, '45-lzi.rom': 32, '45-lzs.rom': 32, '46-lz.rom': 32, '46-lzi.rom': 32,
  '43-lz64.rom': 64, '44-lz64.rom': 64, '45-lz64.rom': 64, '46a-lz64.rom': 64, '46b-lz64.rom': 64, '46-lz64i.rom': 64, '46-lz64s.rom': 64,
};

class Game {
  constructor(model, opts = {}) {
    this.model = model;
    const mm = MODELS[model] || (ROMS[model] ? { rom: model, ram: ROMS[model] } : null);
    if (!mm) throw new Error('no model ' + model);
    this.m = new Machine({ rom: mm.rom, ram: mm.ram, deferOCI: opts.deferOCI });
    const bdir = opts.build || path.join(ROOT, 'build', 'game');
    this.bdir = bdir;
    this.sym = JSON.parse(fs.readFileSync(path.join(bdir, 'kernel.sym.json'), 'utf8'));
    this.meta = JSON.parse(fs.readFileSync(path.join(bdir, 'build.json'), 'utf8'));
    this.m.boot();
    this.m.insertPack(opts.pack || path.join(bdir, 'SPINS.opk'), 0);
    this.base = -1;
  }
  text() { return this.m.screenText(); }
  // run SANTA from B: and wait until the kernel is in RAM (its tag) and the screen settles
  start(maxSec = 20, run = true) {
    if (run) this.m.runProc('SANTA', 'B');
    for (let i = 0; i < maxSec * 10; i++) {
      this.m.runSeconds(0.1);
      if (this.sync() >= 0) {
        const idles = this.idles();
        if (!idles.includes(this.m.runTo(idles, 921600 * 20))) throw new Error('SANTA never waits for a key: ' + this.text());
        return this;
      }
    }
    throw new Error('SANTA did not start\n' + this.text());
  }
  // find the kernel by its tag (it moves with the array)
  sync() {
    const lo = 0x2000, hi = this.m.lines === 4 ? 0x8000 : 0x2000 + (this.mramK() << 10);
    const a = this.m.find(TAG, lo, Math.min(hi, 0xFFFF));
    this.base = a >= 0 ? a - 3 : -1;
    return this.base;
  }
  mramK() { return MODELS[this.model] ? MODELS[this.model].ram : ROMS[this.model]; }
  addr(name) {
    let s = this.sym[name];
    if (!s) s = this.ovSym(name);
    if (!s) throw new Error('no symbol ' + name);
    return s[1] === 'abs' ? s[0] : this.base + s[0];
  }
  // an overlay's own symbol (its variables live in its image, in region R while it is there)
  ovSym(name) {
    if (!this.ovs) {
      this.ovs = {};
      for (const f of fs.readdirSync(this.bdir).filter((f) => /^ov_.*\.sym\.json$/.test(f))) {
        const t = JSON.parse(fs.readFileSync(path.join(this.bdir, f), 'utf8'));
        for (const [n, v] of Object.entries(t)) if (!(n in this.ovs) && !n.startsWith('.')) this.ovs[n] = v;
      }
    }
    return this.ovs[name];
  }
  peek(name, off = 0) { return this.m.peek(this.addr(name) + off); }
  peekw(name, off = 0) { return this.m.peekw(this.addr(name) + off); }
  peek32(name) { const a = this.addr(name); return ((this.m.peek(a) << 24) | (this.m.peek(a + 1) << 16) | (this.m.peek(a + 2) << 8) | this.m.peek(a + 3)) >>> 0; }
  poke(name, v, off = 0) { this.m.poke(this.addr(name) + off, v); }
  press(k, hold = 3, gap = 6) { this.m.press(k, hold, gap); }
  run(s) { this.m.runSeconds(s); }
}

module.exports = { Game, MODELS, ROMS, ROOT };

// call an overlay entry on the Organiser: from the idle key wait, D = id*256+entry, regs {x}
Game.prototype.call = function (id, entry, regs = {}, maxSec = 30) {
  const m = this.m, dbg = m.dbg;
  const done = this.addr('t_done');
  const idle = this.toIdle();
  const keep = regs.keep === false ? null : this.keepSlot();
  dbg.setA(id); dbg.setB(entry);
  if (regs.x !== undefined) dbg.setX(regs.x);
  dbg.setPC(this.addr('t_call'));
  if (m.runTo([done], 921600 * maxSec) !== done) throw new Error('call did not finish');
  const out = { a: dbg.a(), b: dbg.b(), x: dbg.x(), cycles: 0 };
  dbg.setPC(idle);
  if (keep) keep();
  return out;
};
Game.prototype.ids = function () { return this.meta.ids; };

// the LCD as dots: '#' lit, '.' unlit, ' ' the gaps between characters and lines
Game.prototype.lcd = function (cols) {
  const m = this.m, W = m.cols, H = m.lines, c = m.cells(), font = m.font(), u = m.udgs();
  cols = cols || W;
  const out = [];
  for (let r = 0; r < H; r++) {
    for (let y = 0; y < 8; y++) {
      let s = '';
      for (let x = 0; x < cols; x++) {
        const ch = c[r * W + x];
        const row = ch < 8 ? u[ch][y] : (ch >= 32 ? font[(ch - 32) * 8 + y] : 0);
        for (let b = 4; b >= 0; b--) s += (row >> b) & 1 ? '#' : '.';
        s += ' ';
      }
      out.push(s);
    }
    if (r < H - 1) out.push('');
  }
  return out.join('\n');
};

// the screen as text, defined characters as digits 0-7
Game.prototype.scr = function () {
  const m = this.m, W = m.cols, c = m.cells();
  const out = [];
  for (let r = 0; r < m.lines; r++) out.push(c.slice(r * W, r * W + W).map((ch) => (ch < 8 ? String(ch) : String.fromCharCode(ch))).join(''));
  return out;
};
Game.prototype.gridText = function () {
  return [...Array(5)].map((_, r) => [...Array(this.m.lines)].map((_, y) => 'MRBWAKQJHS*'[this.peek('kv_grid', r * 4 + y)]).join('')).join(' ');
};

// start an overlay entry from the idle key wait and run it in steps of `stepSec`, calling
// onStep() after each, until it returns (t_done)
Game.prototype.callSteps = function (id, entry, stepSec, onStep, maxSec = 60) {
  const m = this.m, dbg = m.dbg;
  const done = this.addr('t_done');
  const idle = this.toIdle();
  dbg.setA(id); dbg.setB(entry);
  dbg.setPC(this.addr('t_call'));
  for (let t = 0; t < maxSec; t += stepSec) {
    const r = m.runTo([done], Math.round(921600 * stepSec));
    if (r === done) { dbg.setPC(idle); return t; }
    onStep(t + stepSec);
  }
  throw new Error('did not finish');
};
// a seed (for kv_rng) whose base spin matches pred(spin) under ref/game.js
Game.prototype.seedFor = function (pred, from = 1) {
  const R = require('../ref/game.js');
  const G = R.grid(this.m.lines === 4 ? 'four' : 'two');
  for (let s = from; s < from + 1e6; s++) { if (pred(R.baseSpin(G, new R.Rng(s)))) return s; }
  throw new Error('no seed');
};
Game.prototype.setRng = function (s) { for (let k = 0; k < 4; k++) this.poke('kv_rng', (s >>> (24 - 8 * k)) & 255, k); };

// play one spin from the screen at rest: EXE, then (if seed) the random state is set as OV_GAME's
// G_SPIN starts; runs until the game waits for a key again. onStep(t) every stepSec.
Game.prototype.spin = function (seed, stepSec = 0.5, onStep = null, maxSec = 120) {
  const m = this.m;
  const idles = this.idles();
  this.toIdle();
  const ogs = JSON.parse(require('fs').readFileSync(require('path').join(this.bdir, 'ov_game.sym.json'))).og_spin[0];
  const bp = this.base + ogs;
  const c0 = m.cycles();
  m.keyDown('EXE'); m.runTicks(2); m.keyUp('EXE');
  let t = 0, seeded = seed === undefined || seed === null;
  for (;;) {
    const r = m.runTo(seeded ? idles : [bp, ...idles], Math.round(921600 * stepSec));
    if (r === bp && this.peek('kv_res') === this.ids().OV_GAME) { this.setRng(seed); seeded = true; continue; }
    if (idles.includes(r) && m.cycles() - c0 > 921600 * 0.3) return (m.cycles() - c0) / 921600;
    if (r === -1) { t += stepSec; if (onStep) onStep(t); if (t > maxSec) throw new Error('spin never ended'); }
  }
};

// the places the game waits for a key (tests call overlays from them)
Game.prototype.idles = function () { return [this.addr('kw_idle'), this.addr('kw_tidle')]; };
Game.prototype.toIdle = function () {
  const idles = this.idles();
  const r = this.m.runTo(idles, 921600 * 5);
  if (!idles.includes(r)) throw new Error('not idle');
  return r;
};

// the overlay region and kv_res as they are: a function that puts them back (a call from the
// key wait replaces the overlay that is waiting)
Game.prototype.keepSlot = function () {
  const a = this.addr('SLOTA'), n = this.meta.slot, res = this.peek('kv_res');
  const bytes = this.m.read(a, n);
  return () => { this.m.write(a, bytes); this.poke('kv_res', res); };
};
