; ---------------------------------------------------------------------
; The game's resident arithmetic: random numbers and 32-bit credits.
; ---------------------------------------------------------------------

; rng_next: kv_rng = xorshift32(kv_rng): x ^= x << 13; x ^= x >> 17;
; x ^= x << 5 (high byte first). Uses T0-T3.
rng_next:
        ldaa kv_rng+1           ; t = x << 8 ...
        staa T0
        ldaa kv_rng+2
        staa T1
        ldaa kv_rng+3
        staa T2
        clr  T3
        ldab #5                 ; ... << 5 = x << 13
        bsr  rn_shl
        ldd  kv_rng             ; x ^= x >> 17: (x >> 16) >> 1 into the low word
        lsrd
        eora kv_rng+2
        eorb kv_rng+3
        std  kv_rng+2
        ldd  kv_rng             ; t = x << 5
        std  T0
        ldd  kv_rng+2
        std  T2
        ldab #5
rn_shl: asl  T3                 ; t <<= B, then x ^= t
        rol  T2
        rol  T1
        rol  T0
        decb
        bne  rn_shl
        ldd  kv_rng
        eora T0
        eorb T1
        std  kv_rng
        ldd  kv_rng+2
        eora T2
        eorb T3
        std  kv_rng+2
        rts

; rng_stop: A = a reel stop, the top five bits of the next number
rng_stop:
        bsr  rng_next
        ldaa kv_rng
        lsra
        lsra
        lsra
        rts

; add32: X = a 4-byte number, kv_n32 added to it
add32:  ldd  2,x
        addd kv_n32+2
        std  2,x
        ldd  0,x
        adcb kv_n32+1
        adca kv_n32
        std  0,x
        rts

; sub32: X = a 4-byte number, kv_n32 taken from it; carry set if it went below 0
sub32:  ldd  2,x
        subd kv_n32+2
        std  2,x
        ldd  0,x
        sbcb kv_n32+1
        sbca kv_n32
        std  0,x
        rts

; mul32: kv_n32 = kv_n32 * B (B small: a bet)
mul32:  pshb
        ldd  kv_n32
        std  kv_m32
        ldd  kv_n32+2
        std  kv_m32+2
        clr  kv_n32
        clr  kv_n32+1
        clr  kv_n32+2
        clr  kv_n32+3
        pulb
        tstb
        beq  .x
.l:     pshb
        ldd  kv_n32+2
        addd kv_m32+2
        std  kv_n32+2
        ldd  kv_n32
        adcb kv_m32+1
        adca kv_m32
        std  kv_n32
        pulb
        decb
        bne  .l
.x:     rts
