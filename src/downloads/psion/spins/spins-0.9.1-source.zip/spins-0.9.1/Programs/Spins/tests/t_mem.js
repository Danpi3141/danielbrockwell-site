// Memory on the smallest machines: FREE at the Prog menu, what SANTA asks for, and whether it starts.
//   node tests/t_mem.js [model]
const { Game } = require('./lib');
const model = process.argv[2] || 'cm';
const g = new Game(model);
const meta = g.meta;
// FREE as OPL sees it: a one-line procedure on A: printing FREE would need typing; instead read
// the allocator's free gap: ALA_FREE ($2040) is the first byte above the allocated cells; the
// stack's floor is below the top of RAM. Simpler: start SANTA and see what it says.
g.m.runProc('SANTA', 'B');
for (let i = 0; i < 100; i++) { g.run(0.1); if (g.sync() >= 0 || /NEEDS/.test(g.text())) break; }
console.log(model, 'array', meta.total, 'SANTA needs', meta.needs, '=>', g.sync() >= 0 ? 'started' : g.text().replace(/\n/g, ' | '));
