; ---------------------------------------------------------------------
; The panel: four logical lines of 10 characters (pn_text). The LZ shows
; all four; a two-line machine shows line 0 above and, below, whichever
; was written last (callers write in order of preference).
;   0 CR and the credits shown (kv_dbal)   1 BET and the stake
;   2 WIN and the win shown (kv_dwin)      3 a message
; ---------------------------------------------------------------------
pn_cr:  clra
        ldx  #pn_scr
        jsr  pn_text
        clra
        jsr  pn_cell
        addb #2
        ldaa #8
        ldx  #kv_dbal
        jmp  num_at
pn_bet: ldaa #1
        ldx  #pn_sbet
        jsr  pn_text
        jsr  stake
        ldaa #1
        jsr  pn_cell
        addb #3
        ldaa #7
        ldx  #kv_n32
        jmp  num_at
pn_win: ldaa #2
        ldx  #pn_swin
        jsr  pn_text
        ldaa #2
        jsr  pn_cell
        addb #3
        ldaa #7
        ldx  #kv_dwin
        jmp  num_at
; pn_msg: X = a message for line 3 (none during autoplay: AUTO, so it
; shows through every spin)
pn_msg: tst  kv_auto
        beq  .m
        tst  0,x
        bne  .m
        ldx  #pn_sauto
.m:     ldaa #3
        jmp  pn_text
pn_sauto: fcl "AUTO"
pn_scr: fcl  "CR"
pn_sbet: fcl "BET"
pn_swin: fcl "WIN"

; stake: kv_n32 = 20 times the line bet
stake:  ldab kv_bet
        ldx  #bets
        abx
        ldaa 0,x
        ldab #20
        mul
        jmp  set32
bets:   fcb  1,2,5,10

