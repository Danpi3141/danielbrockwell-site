; =====================================================================
; OV_INFO: the statistics and the help. Each entry returns A = 0.
; =====================================================================
        include "../defs.inc"

        jmp  oi_stats           ; C_STATS
        jmp  oi_help            ; C_HELP

; ---------------------------------------------------------------------
; the statistics
; ---------------------------------------------------------------------
oi_stats:
        ldaa #3
        jsr  oi_pages
        ldx  #oi_spage
        stx  oi_fn
        jmp  oi_view
; A = page: four statistics
oi_spage:
        ldab #4
        mul
        stab oi_s               ; the first
        ldx  #oi_buf
        stx  oi_p
        clr  oi_c
.l:     jsr  oi_lstart
        ldx  #oi_snames
        ldab oi_s
        jsr  oi_skipb
        jsr  oi_str
        ldaa #' '
        jsr  oi_ch
        ldaa oi_s
        asla
        tab
        ldx  #oi_svars
        abx
        ldx  0,x
        ldaa oi_s
        cmpa #3                 ; the return: paid / staked, %
        beq  .ret
        cmpa #11                ; (the empty last line)
        beq  .e
        cmpa #9                 ; the 1-byte ones
        bhs  .n8
        cmpa #8                 ; the 4-byte ones, then the 2-byte ones
        beq  .n32
        cmpa #5
        bhs  .n16
.n32:   jsr  oi_num32
        bra  .e
.n8:    ldab 0,x
        clra
        jsr  oi_num
        bra  .e
.n16:   ldd  0,x
        jsr  oi_num
        bra  .e
.ret:   jsr  oi_ret
.e:     jsr  oi_lend
        inc  oi_s
        inc  oi_c
        ldaa oi_c
        cmpa #4
        bne  .l
        ldx  #oi_buf
        rts
oi_snames:
        fcl  "Spins"
        fcl  "Staked"
        fcl  "Paid"
        fcl  "Return"
        fcl  "Best win"
        fcl  "Santa"
        fcl  "Xmas Spins"
        fcl  "Top-ups"
        fcl  "Best bal."
        fcl  "Best run"
        fcl  "Most houses"
        fcb  0
oi_svars:
        fdb  st_spins, st_staked, st_paid, 0, st_big
        fdb  st_santa, st_feats, st_topups, st_bestb, st_run, st_mosth, 0

; the return: paid * 1000 / staked, as nn.n%
oi_ret: ldd  st_staked
        bne  .go
        ldd  st_staked+2
        bne  .go
        ldaa #'-'
        jmp  oi_ch
.go:    ldx  #st_paid           ; n = paid, d = staked, both halved till n < 2^22
        ldd  0,x
        std  oi_nn
        ldd  2,x
        std  oi_nn+2
        ldd  st_staked
        std  oi_dd
        ldd  st_staked+2
        std  oi_dd+2
.h:     ldaa oi_nn
        bne  .sh
        ldaa oi_nn+1
        anda #$C0
        beq  .m
.sh:    lsr  oi_nn
        ror  oi_nn+1
        ror  oi_nn+2
        ror  oi_nn+3
        lsr  oi_dd
        ror  oi_dd+1
        ror  oi_dd+2
        ror  oi_dd+3
        bra  .h
.m:     ldd  oi_nn              ; n * 1000
        std  kv_n32
        ldd  oi_nn+2
        std  kv_n32+2
        ldab #250
        jsr  mul32
        ldab #4
        jsr  mul32
        ldd  kv_n32             ; n / d: shift and subtract
        std  oi_nn
        ldd  kv_n32+2
        std  oi_nn+2
        clra
        clrb
        std  oi_q
        std  oi_q+2
        std  oi_r
        std  oi_r+2
        ldab #32
        stab oi_c2
.dv:    asl  oi_nn+3
        rol  oi_nn+2
        rol  oi_nn+1
        rol  oi_nn
        rol  oi_r+3
        rol  oi_r+2
        rol  oi_r+1
        rol  oi_r
        ldd  oi_r+2             ; r >= d?
        subd oi_dd+2
        std  oi_t
        ldd  oi_r
        sbcb oi_dd+1
        sbca oi_dd
        bcs  .no
        std  oi_r
        ldd  oi_t
        std  oi_r+2
        sec
        bra  .q
.no:    clc
.q:     rol  oi_q+3
        rol  oi_q+2
        rol  oi_q+1
        rol  oi_q
        dec  oi_c2
        bne  .dv
        ldx  #oi_q              ; nnn: "nn.n%"
        jsr  num_dec
        ldx  #kv_nb
.s:     ldaa 0,x
        cmpa #' '
        bne  .d
        inx
        bra  .s
.d:     cpx  #kv_nb+9           ; (under 1.0: a 0 first)
        bne  .dd
        pshx
        ldaa #'0'
        jsr  oi_ch
        pulx
.dd:    ldaa 0,x
        cpx  #kv_nb+9
        bne  .c
        pshx
        psha
        ldaa #'.'
        jsr  oi_ch
        pula
        pulx
.c:     pshx
        jsr  oi_ch
        pulx
        inx
        cpx  #kv_nb+10
        bne  .dd
        ldaa #'%'
        jmp  oi_ch

; ---------------------------------------------------------------------
; the help: five pages
; ---------------------------------------------------------------------
oi_help:
        ldaa #5
        jsr  oi_pages
        ldx  #oi_hpage
        stx  oi_fn
        jmp  oi_view
oi_hpage:
        ldx  #oi_htext
        jmp  oi_nth
oi_htext:
        fcl  "PSION SPINS"
        fcl  "Five reels,"
        fcl  "twenty lines."
        fcl  "EXE spins."
        fcl  "UP, DOWN: the"
        fcl  "line bet (1 2 5"
        fcl  "or 10). A spin"
        fcl  "is 20 line bets."
        fcl  "A autoplay"
        fcl  "P pays  L lines"
        fcl  "S stats  MODE"
        fcl  "menu  ON leave"
        fcl  "Any key ends an"
        fcl  "animation; the"
        fcl  "win is the same."
        fcl  "Credits: no value"
        fcl  "1,000 to start;"
        fcl  "Santa tops up by"
        fcl  "500 when you run"
        fcl  "out. Daniel+Claude"

        include "pages.inc"
