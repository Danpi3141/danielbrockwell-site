// Stress: random keys at random moments (EXE most often), for a long time. Checks: the Organiser
// stays on (no illegal instruction), the kernel stays in RAM while the game runs, no OPL error,
// and every time the game is at rest the credits shown equal the credits. When the game is left
// (ON, EXE), it is started again.   node tests/t_stress.js [model] [seconds] [seed]
const { Game } = require('./lib');
const model = process.argv[2] || 'lz64';
const secs = +(process.argv[3] || 600);
let seed = +(process.argv[4] || 7);
const rnd = () => { seed = (seed * 1103515245 + 12345) >>> 0; return seed / 4294967296; };
const KEYS = ['EXE', 'EXE', 'EXE', 'EXE', 'EXE', 'UP', 'DOWN', 'LEFT', 'RIGHT', 'ON', 'MODE', 'A', 'P', 'L', 'S', 'G', 'J', 'H', 'X', 'SPACE', 'DEL'];
const g = new Game(model);
g.start();
const rest = g.ids().OV_REST;
let t = 0, keys = 0, restarts = 0, checks = 0, bad = 0;
const fail = (m) => { bad++; console.log(`FAIL at ${t.toFixed(0)} s: ${m}\n${g.text()}`); };
while (t < secs && bad < 3) {
  const k = KEYS[Math.floor(rnd() * KEYS.length)];
  g.press(k, 2 + Math.floor(rnd() * 3), 1 + Math.floor(rnd() * 4));
  keys++;
  const wait = rnd() < 0.7 ? rnd() * 0.6 : rnd() * 6;
  g.run(wait); t += wait + 0.1;
  if (!g.m.isOn()) { fail('switched off (a crash?)'); break; }
  if (/ERROR|MEMORY|TRAP|ERR:/i.test(g.text())) { fail('an error'); break; }
  if (g.sync() < 0) {                       // left: start again
    if (!/Edit|EDIT|Prog|PROG|Run|RUN|Find|FIND/.test(g.text())) { g.run(3); t += 3; if (g.sync() >= 0) continue; }
    try { g.start(30); restarts++; } catch (e) { fail('could not start again: ' + e.message.split('\n')[0]); }
    continue;
  }
  if (g.peek('kv_res') === rest && !g.peek('kv_auto')) {
    const idles = g.idles();
    if (idles.includes(g.m.dbg.pc()) || idles.includes(g.m.runTo(idles, 20000))) {
      checks++;
      if (g.peek32('kv_bal') !== g.peek32('kv_dbal')) fail(`credits ${g.peek32('kv_bal')} shown ${g.peek32('kv_dbal')}`);
    }
  }
}
console.log(`${model}: ${t.toFixed(0)} s, ${keys} keys, ${restarts} restarts, ${checks} checks at rest, spins ${g.sync() >= 0 ? g.peek32('st_spins') : '?'}: ${bad ? 'FAILED' : 'ok'}`);
process.exit(bad ? 1 : 0);
