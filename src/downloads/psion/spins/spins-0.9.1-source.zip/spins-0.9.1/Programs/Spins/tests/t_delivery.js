// Santa's delivery: a spin forced to land Santa with houses, then the walk, screen by screen.
//   node tests/t_delivery.js [model] [houses-min] [stepms]
const { Game } = require('./lib');
const model = process.argv[2] || 'lz64';
const hmin = +(process.argv[3] || 2);
const step = +(process.argv[4] || 250) / 1000;
const g = new Game(model);
g.start();
const ids = g.ids();
const seed = g.seedFor((b) => b.santa && b.houses >= hmin);
g.setRng(seed);
g.call(ids.OV_GAME, 0);
console.log('seed', seed, 'grid', g.gridText(), 'lines', g.peek('kv_nwin'), 'pay', g.peekw('kv_lwin'));
g.call(ids.OV_SPINFX, 0);
console.log('after spin:\n' + g.scr().join('\n'));
const shots = [];
g.call(ids.OV_HOME, 1);
let t = g.callSteps(ids.OV_WALK, 0, step, (t) => shots.push([t, g.scr()]));
g.poke('kv_arg', g.m.dbg.a());
t += g.callSteps(ids.OV_HOME, 0, step, (tt) => shots.push([t + tt, g.scr()]));
const W = g.m.lines === 4 ? 10 : 6;
for (let i = 0; i < shots.length; i += 12) {
  const part = shots.slice(i, i + 12);
  for (let y = 0; y < g.m.lines; y++) console.log(part.map(([, s]) => s[y].slice(0, W)).join(' | '));
  console.log(part.map(([t]) => t.toFixed(2).padEnd(W)).join(' | '));
  console.log('');
}
console.log(`walk took ${t.toFixed(2)} s\nend:\n` + g.scr().join('\n'));
console.log('glyph 3 (house/present):', g.m.udg(3).join(','));
