// Every Organiser ROM the emulator has: SANTA starts, picks the right screen driver, plays a
// spin with Santa (the walk), opens the menu, plays a scene, and leaves cleanly.
//   node tests/t_roms.js [rom...]
const { Game, ROMS } = require('./lib');
const roms = process.argv.slice(2).length ? process.argv.slice(2) : Object.keys(ROMS);
let bad = 0;
for (const rom of roms) {
  let msg = '';
  try {
    const g = new Game(rom);
    g.start(30);
    const four = g.m.lines === 4;
    const drv = g.peek('kv_four') + 1, model = g.m.peek(0xFFE8);
    if ((drv === 2) !== four) throw new Error(`driver ${drv} for a ${g.m.lines}-line machine (model byte ${model})`);
    const R = require('../ref/game.js');
    const seed = g.seedFor((b) => b.santa && b.houses >= 1 && !b.freeSpins, 100);
    const p = R.play(R.grid(four ? 'four' : 'two'), new R.Rng(seed));
    g.spin(seed, 2);
    const bal = g.peek32('kv_bal');
    if (bal !== 1000 - 20 + p.total || g.peek32('kv_dbal') !== bal) throw new Error(`credits ${bal} (shown ${g.peek32('kv_dbal')}), expected ${1000 - 20 + p.total}`);
    g.press('MODE'); g.run(0.6);
    if (!/MENU/.test(g.text())) throw new Error('no menu: ' + g.text());
    g.press('ON'); g.run(0.5);
    g.press('ON'); g.run(0.6); g.press('EXE'); g.run(5);
    if (/CR /.test(g.text()) || !g.m.isOn()) throw new Error('did not leave: ' + g.text());
    msg = `ok   model ${model}, ${g.m.lines} lines, driver ${drv}, Santa spin paid ${p.total}`;
  } catch (e) { bad++; msg = 'FAIL ' + e.message.split('\n')[0]; }
  console.log(rom.padEnd(14), msg);
}
console.log(bad ? `${bad} failed` : 'all passed');
process.exit(bad ? 1 : 0);
