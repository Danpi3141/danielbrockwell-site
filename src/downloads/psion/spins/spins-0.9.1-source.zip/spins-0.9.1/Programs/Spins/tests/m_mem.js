// The memory margin: PAD (a padding array, then SANTA) at sizes found by binary search.
// Reports the largest padding at which SANTA starts (the spare RAM), and checks that SANTA
// refuses ("NEEDS") rather than failing at any size.  node tests/m_mem.js [model]
const { execFileSync } = require('child_process');
const path = require('path'), fs = require('fs');
const { Game } = require('./lib');
const model = process.argv[2] || 'cm';
const tmp = path.join(__dirname, '..', 'build', 'mem');
fs.mkdirSync(tmp, { recursive: true });
function trial(words) {
  const opk = path.join(tmp, `pad${words}.opk`);
  execFileSync('python', [path.join(__dirname, '..', 'tools', 'padpack.py'), String(words), opk]);
  const g = new Game(model, { pack: opk });
  g.m.runProc('PAD', 'B');
  for (let i = 0; i < 120; i++) {
    g.run(0.25);
    const t = g.text();
    if (/NEEDS/.test(t)) return { r: 'needs', t };
    if (/MEMORY|ERROR|ERR/i.test(t)) return { r: 'error', t };
    if (g.sync() >= 0) {
      try { g.start(20, false); g.spin(null, 1); return { r: 'ok', g }; } catch (e) { return { r: 'error', t: e.message + ' ' + g.text() }; }
    }
  }
  return { r: 'timeout', t: g.text() };
}
let lo = 0, hi = 1000;            // words
while (hi - lo > 1) {
  const mid = (lo + hi) >> 1;
  const r = trial(mid);
  console.log(`pad ${2 * mid} bytes: ${r.r}${r.r === 'error' || r.r === 'timeout' ? ' ' + r.t.replace(/\n/g, '|') : ''}`);
  if (r.r === 'error' || r.r === 'timeout') { console.log('FAIL: not refused cleanly'); process.exit(1); }
  if (r.r === 'ok') lo = mid; else hi = mid;
}
console.log(`${model}: spare on a blank machine about ${2 * lo} bytes (SANTA refuses beyond)`);
