// Where the game itself stops working (SANTA with its check made to pass): the true limit.
//   node tests/m_mem2.js [model]
const { execFileSync } = require('child_process');
const path = require('path'), fs = require('fs');
const { Game } = require('./lib');
const model = process.argv[2] || 'cm';
const tmp = path.join(__dirname, '..', 'build', 'mem');
fs.mkdirSync(tmp, { recursive: true });
function trial(words) {
  const opk = path.join(tmp, `padg${words}.opk`);
  execFileSync('python', [path.join(__dirname, '..', 'tools', 'padpack.py'), String(words), opk], { env: { ...process.env, PADSANTA: 'nocheck' } });
  const g = new Game(model, { pack: opk });
  g.m.runProc('PAD', 'B');
  for (let i = 0; i < 120; i++) {
    g.run(0.25);
    const t = g.text();
    if (/MEMORY|ERROR|ERR/i.test(t)) return { r: 'error', t };
    if (g.sync() >= 0) {
      try {
        g.start(20, false); g.spin(null, 1);
        g.press('ON'); g.run(0.5); g.press('EXE'); g.run(4);
        return /MEMORY|ERR/i.test(g.text()) ? { r: 'error', t: g.text() } : { r: 'ok' };
      } catch (e) { return { r: 'error', t: e.message + ' ' + g.text() }; }
    }
  }
  return { r: 'timeout', t: g.text() };
}
let lo = 100, hi = 700;
while (hi - lo > 1) {
  const mid = (lo + hi) >> 1;
  const r = trial(mid);
  console.log(`pad ${2 * mid}: ${r.r} ${r.t ? r.t.replace(/\n/g, '|') : ''}`);
  if (r.r === 'ok') lo = mid; else hi = mid;
}
console.log(`${model}: the game works with up to ${2 * lo} bytes of padding (SANTA's check passed)`);
