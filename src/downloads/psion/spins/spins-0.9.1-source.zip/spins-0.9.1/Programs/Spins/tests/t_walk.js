// The compositor: Santa walked across the test screen, dot by dot. Prints the LCD at some steps
// and checks that the cells get their own characters back when the window closes.
//   node tests/t_walk.js [model] [x,x,...]
const { Game } = require('./lib');
const model = process.argv[2] || 'lz64';
const show = (process.argv[3] || '0,3,8,14').split(',').map(Number);
const g = new Game(model);
g.start();
const ids = g.ids();
const four = g.m.lines === 4;
const before = g.m.cells().join();
g.poke('kv_arg', 1);                // WALK1
g.poke('kv_arg', four ? 1 : 0, 1);  // the window's top row
g.poke('kv_spx', 0);
g.call(ids.OV_TEST, 3);
const cols = four ? 10 : 7;
for (let x = 0; x <= (four ? 54 : 30); x++) {
  g.poke('kv_spx', x);
  g.poke('kv_arg', 1 + (x >> 1) % 4);   // the walk cycle
  g.call(ids.OV_TEST, 6);
  g.call(ids.OV_TEST, 4);
  if (show.includes(x)) console.log(`x = ${x}\n${g.lcd(cols)}\n`);
}
g.call(ids.OV_TEST, 5);
g.call(ids.OV_TEST, 4);
const after = g.m.cells().join();
console.log(after === before ? 'cells restored' : 'CELLS DIFFER\n' + before + '\n' + after);
process.exit(after === before ? 0 : 1);
