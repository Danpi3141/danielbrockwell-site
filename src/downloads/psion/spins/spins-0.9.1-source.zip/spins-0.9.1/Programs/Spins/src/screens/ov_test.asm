; =====================================================================
; OV_TEST: entries for the tests (tests/t_sound.js): sounds played under
; frames that draw nothing.
; =====================================================================
        include "../defs.inc"

        jmp  ts_fx              ; 0: X = an effect, kv_arg = frames of 10 ticks
        jmp  ts_tune            ; 1: X = a tune, kv_arg = frames
        jmp  ts_frames          ; 2: kv_arg = frames of kv_arg+1 ticks, nothing else
        jmp  ts_spon
        jmp  ts_draw            ; 4: a frame of 1 tick (draws)
        jmp  sp_off             ; 5: the window closed
        jmp  ts_pose            ; 6: pose kv_arg

ts_fx:  jsr  snd_stop
        jsr  snd_fx
        bra  ts_run
ts_tune:
        jsr  snd_stop
        jsr  snd_tune
ts_run: ldaa #10
        staa kv_arg+1
ts_frames:
.l:     ldaa kv_arg+1
        jsr  frame_t
        dec  kv_arg
        bne  .l
        jmp  snd_stop

; 3: the font and poses read in, pose kv_arg, the window opened on row kv_arg+1
ts_spon:
        ldd  kv_arg              ; (pk_load uses kv_arg)
        std  ts_p
        ldaa #IT_FONT
        ldx  #ts_data
        jsr  pk_load
        stx  kv_fontp
        ldaa #IT_POSES
        ldx  #ts_data+80
        jsr  pk_load
        ldd  ts_p
        std  kv_arg
        bsr  ts_pose
        ldaa ts_p+1
        jmp  sp_on
ts_p:   fdb  0
ts_pose:
        ldab kv_arg
        ldaa #10
        mul
        addd #ts_data+80
        xgdx
        jmp  sp_pose
ts_draw:
        ldaa #1
        jmp  frame_t

        include "comp.inc"
ts_data:
