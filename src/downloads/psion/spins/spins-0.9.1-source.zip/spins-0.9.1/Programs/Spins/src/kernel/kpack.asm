; ---------------------------------------------------------------------
; The pack: everything after the kernel in SANK is area B, starting with
; an index of 2-byte offsets (one per item: code units, then data). The
; start-up code found B's pack address (kv_bpa, 3 bytes).
; ---------------------------------------------------------------------

; seek to B + D on the game's device
pk_off: addd kv_bpa+1
        std  kv_pa+1
        ldaa kv_bpa
        adca #0
        staa kv_pa
        tst  kv_pkok            ; PK$SETP again only if it may be needed
        bne  .sel
        clra
        ldab kv_dev
        os   PK$SETP
        inc  kv_pkok
.sel:   ldab kv_pa
        ldx  kv_pa+1
        os   PK$SADD
        rts

; pk_item: A = item id (1..): seek to its data; D = its offset in B
pk_item:
        tab
        clra
        asld                    ; (id-1)*2: the index entry
        subd #2
        bsr  pk_off
        os   PK$RWRD
        pshb
        psha
        bsr  pk_off
        pula
        pulb
        rts

; pk_load: A = item id, X = where, D on stack? -- simple form:
; A = item id, X = destination: the item's length word then its bytes;
; returns D = length, X = destination
pk_load:
        stx  kv_t1
        bsr  pk_item
        os   PK$RWRD            ; D = length
        std  kv_t3
        beq  .x
        ldx  kv_t1
        os   PK$READ
.x:     ldx  kv_t1
        ldd  kv_t3
        rts

; ---------------------------------------------------------------------
; ov_load: A = unit id. Loads it unless it is there already: an overlay
; into slot A, a screen driver at DRV. Adds the array's address to its
; fix-ups (a list after the code: tools/build.py encode_fixups).
; ---------------------------------------------------------------------
ov_load:
        cmpa kv_res
        beq  .x                 ; already there
        staa kv_t2
        ldx  #SLOTA
        cmpa #DRV4
        bhi  .s
        ldx  #DRV               ; (DRV2 and DRV4 are units 1 and 2)
.s:     stx  kv_t1
        jsr  pk_item
        os   PK$RWRD            ; D = code length
        std  kv_t3
        beq  .gone              ; the pack is gone (it reads as 0s)
        ldx  kv_t1
        os   PK$READ            ; the code
        os   PK$RBYT            ; the fix-ups: their length in bytes
        stab kv_t3
        ldd  kv_t1
        std  kv_fo              ; where the last fix-up was (to start, the code)
.nx:    tst  kv_t3
        beq  .done
        bsr  ov_byte            ; two steps
        bra  .nx
.done:  ldaa kv_t2
        cmpa #DRV4
        bls  .x                 ; a driver: slot A unchanged
        staa kv_res
        clr  kv_fxt             ; (an effect's cells may have been in the old one)
.x:     rts
.gone:  ldab #E_NOPACK
        jmp  quit

; the next encoded fix-up byte from the pack: its two steps, high nibble first
ov_byte:
        os   PK$RBYT
        dec  kv_t3
        pshb
        lsrb
        lsrb
        lsrb
        lsrb
        bsr  ov_step
        pulb
        andb #15
; B = a step: 1-15 on that far and add the array's address to the word
; there; 0 on 15
ov_step:
        tstb
        beq  .z
        bsr  .on
        ldd  0,x
        addd kv_base
        std  0,x
        rts
.z:     ldab #15
.on:    ldx  kv_fo
        abx
        stx  kv_fo
        rts

; ---------------------------------------------------------------------
; ov_call: A = overlay id, B = entry: load the overlay into slot A (if it
; isn't there) and call the entry (slot A + 3 * entry) with X unchanged.
; ---------------------------------------------------------------------
ov_call:
        stx  kv_rx
        pshb
        jsr  ov_load
        pulb
        ldaa #3
        mul
        addd #SLOTA
        pshb                    ; (as pshx would)
        psha
        ldx  kv_rx
        rts                     ; into the entry; its rts returns to our caller
