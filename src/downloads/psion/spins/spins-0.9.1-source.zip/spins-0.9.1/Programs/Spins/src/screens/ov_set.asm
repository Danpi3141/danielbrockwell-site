; =====================================================================
; OV_SET: the settings. Each line is a setting and its value; EXE, LEFT
; or RIGHT changes the value (round); ON or MODE goes back, saved.
; =====================================================================
        include "../defs.inc"

        jmp  os_go

os_go:  clr  os_at
        ldaa #1
        staa ls_lr
.l:     jsr  os_build           ; the list, with the values as they are now
        ldaa os_at
        ldx  #os_buf
        jsr  ls_run
        bcs  .x
        stab os_at
        jsr  os_ent             ; X = the setting's entry
        ldx  1,x                ; its variable: the next value, round
        ldaa 0,x
        inca
        pshx
        jsr  os_ent
        ldab 0,x                ; its count
        pulx
        cba
        blo  .s
        clra
.s:     staa 0,x
        bra  .l
.x:     clr  ls_lr
        ldaa #C_SAVE
        rts

; X = the entry of setting os_at: count, variable, then the values
os_ent: ldx  #os_tab
        ldab os_at
.l:     beq  .x
        pshb
        ldab 0,x                ; count of values: past the name and values
        stab os_n
        ldab 3,x                ; the name's length
        incb
        addb #3
        abx
.v:     ldab 0,x
        incb
        abx
        dec  os_n
        bne  .v
        pulb
        decb
        bra  .l
.x:     rts

; the list: title, count, then "Name Value" for each
os_build:
        ldx  #os_buf
        stx  os_p
        ldx  #os_title
        ldab #9
        jsr  os_copy            ; "SETTINGS" with its length (9 bytes)
        ldx  os_p
        ldaa #OS_N
        staa 0,x
        inx
        stx  os_p
        clr  os_i
.e:     ldaa os_at
        psha
        ldaa os_i
        staa os_at
        jsr  os_ent
        pula
        staa os_at
        stx  os_e
        ldx  os_p               ; the item's length byte, filled in after
        stx  os_lp
        inx
        stx  os_p
        ldx  os_e               ; the name
        ldab 3,x
        inx
        inx
        inx
        inx
        jsr  os_cpyn
        ldaa #' '
        jsr  os_ch
        ldx  os_e               ; the value: skip to it
        ldx  1,x
        ldab 0,x                ; its index
        stab os_v
        ldx  os_e
        ldab 3,x
        incb
        addb #3
        abx
.sk:    tst  os_v
        beq  .vv
        ldab 0,x
        incb
        abx
        dec  os_v
        bra  .sk
.vv:    ldab 0,x
        inx
        jsr  os_cpyn
        ldd  os_p               ; the item's length
        subd os_lp
        decb
        ldx  os_lp
        stab 0,x
        inc  os_i
        ldaa os_i
        cmpa #OS_N
        bne  .e
        rts
; copy B bytes from X / B characters from X
os_copy:
os_cpyn:
        tstb
        beq  .x
.l:     ldaa 0,x
        pshx
        bsr  os_ch
        pulx
        inx
        decb
        bne  .l
.x:     rts
os_ch:  ldx  os_p
        staa 0,x
        inx
        stx  os_p
        rts

os_title: fcl "SETTINGS"
; the settings: count of values, the variable, the name, the values
OS_N    = 8
os_tab: fcb  3
        fdb  kv_anim
        fcl  "Animation"
        fcl  "Off"
        fcl  "Quick"
        fcl  "Full"
        fcb  2
        fdb  kv_styles
        fcl  "Santa"
        fcl  "All six"
        fcl  "Standard"
        fcb  3
        fdb  kv_sound
        fcl  "Sound"
        fcl  "On"
        fcl  "Soft"
        fcl  "Off"
        fcb  2
        fdb  kv_music
        fcl  "Music"
        fcl  "On"
        fcl  "Off"
        fcb  4
        fdb  kv_glass
        fcl  "Glass"
        fcl  "8/s"
        fcl  "10/s"
        fcl  "12/s"
        fcl  "15/s"
        fcb  2
        fdb  kv_showw
        fcl  "Wins"
        fcl  "Lines"
        fcl  "Total"
        fcb  3
        fdb  kv_astop
        fcl  "Auto stop"
        fcl  "Feature"
        fcl  "Big win"
        fcl  "Never"
        fcb  2
        fdb  kv_idle
        fcl  "Idle"
        fcl  "On"
        fcl  "Off"

os_at:  fcb  0
os_i:   fcb  0
os_n:   fcb  0
os_v:   fcb  0
os_p:   fdb  0
os_lp:  fdb  0
os_e:   fdb  0
os_buf: rmb  180

        include "list.inc"
