#!/usr/bin/env python3
"""The art packer: glyphs (5 x 8) and Santa's poses (5 x 16) drawn as text grids.

    glyph NAME      then 8 lines of '#' and '.'
    pose NAME       then 16 lines (the top character's 8 rows, then the bottom's)
    cel NAME W H    then H lines of W dots

A glyph is 8 bytes (dots in bits 4-0, bit 4 the left). A pose is its 80 dots packed in 10 bytes.
A cel is W, H, then H rows of W bits each, packed (row by row, bit 7 first)."""
import re


class ArtError(Exception):
    pass


def parse(path):
    items = {}
    order = []
    cur = None
    with open(path, encoding='utf-8') as f:
        for no, raw in enumerate(f, 1):
            line = raw.split('#', 1)[0].rstrip() if not re.match(r'^[#.]+\s*(#.*)?$', raw.strip()) else raw.strip().split(' ', 1)[0]
            if not line.strip():
                continue
            m = re.match(r'^(glyph|pose|cel)\s+(\w+)(?:\s+(\d+)\s+(\d+))?', line)
            if m:
                kind, name = m.group(1), m.group(2)
                if kind == 'glyph':
                    w, h = 5, 8
                elif kind == 'pose':
                    w, h = 5, 16
                else:
                    w, h = int(m.group(3)), int(m.group(4))
                if name in items:
                    raise ArtError('%s:%d: %s twice' % (path, no, name))
                cur = {'kind': kind, 'name': name, 'w': w, 'h': h, 'rows': [], 'line': no}
                items[name] = cur
                order.append(name)
                continue
            if cur is None or not re.match(r'^[#.]+$', line):
                raise ArtError('%s:%d: what is %r' % (path, no, line))
            if len(line) != cur['w']:
                raise ArtError('%s:%d: %s: a row of %d dots, not %d' % (path, no, cur['name'], len(line), cur['w']))
            cur['rows'].append(line)
    for n in order:
        it = items[n]
        if len(it['rows']) != it['h']:
            raise ArtError('%s:%d: %s has %d rows, not %d' % (path, it['line'], n, len(it['rows']), it['h']))
    return items, order


def rowbits(row):
    v = 0
    for ch in row:
        v = v * 2 + (ch == '#')
    return v


def encode(it):
    if it['kind'] == 'glyph':
        return bytes(rowbits(r) for r in it['rows'])
    if it['kind'] == 'pose':                    # 16 rows of 5 dots: 80 bits, 10 bytes
        bits = ''.join(r.replace('#', '1').replace('.', '0') for r in it['rows'])
        return bytes(int(bits[i:i + 8], 2) for i in range(0, 80, 8))
    bits = ''.join(r.replace('#', '1').replace('.', '0') for r in it['rows'])
    bits += '0' * (-len(bits) % 8)
    return bytes([it['w'], it['h']]) + bytes(int(bits[i:i + 8], 2) for i in range(0, len(bits), 8))
