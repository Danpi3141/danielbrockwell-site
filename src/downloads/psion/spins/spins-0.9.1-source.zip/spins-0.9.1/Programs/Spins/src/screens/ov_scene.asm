; =====================================================================
; OV_SCENE: the full-screen scenes (kv_arg = which). The reels are
; cleared and the eight defined characters are a canvas: a block four
; across and two down (24 steps by 16 rows) or a strip of eight (48 by
; 8), placed on the screen as a window that can slide. Cels (and poses)
; are drawn on it at any dot. The scene is a script (tools/script.py) in
; its blob; its stage commands come here:
;   CEL n,x,y  WIPE  WINDOW shape,col,row (0 none, 1 block, 2 strip)
;   SLIDE dc
; and its HOOKs: 1 the Xmas Spins' count, 2 the feature's total counts
; up, 3 the top-up counts up, 4 the win shown, 5 the gift of credits.
; Afterwards: the pictures and the panel back; the scene is marked seen.
; =====================================================================
        include "../defs.inc"

        jmp  sn_go

sn_go:  ldab kv_arg             ; marked seen (for the replay menu)
        jsr  sn_bit
        oraa st_seen+1
        staa st_seen+1
        ldab kv_arg
        subb #8
        bcs  .s
        jsr  sn_bit
        oraa st_seen
        staa st_seen
.s:     ldab kv_arg             ; its blob
        ldx  #sn_items
        abx
        ldaa 0,x
        ldx  #sn_data
        stx  kv_scene
        jsr  pk_load
        ldx  #sn_stage
        stx  kv_stage
        ldx  #sn_hook
        stx  kv_hook
        clr  sn_shape
        jsr  cls
        jsr  sn_wipe
        clra                    ; its script
        jsr  sc_play
        jsr  snd_stop
        ldaa #IT_PICS           ; the pictures back
        ldx  #kv_glyph
        jsr  pk_load
        ldaa #$FF
        staa kv_gdirty
        jsr  cls
        jsr  pn_cr              ; and the panel
        jsr  pn_bet
        ldd  kv_dwin
        bne  .w
        ldd  kv_dwin+2
        beq  .x
.w:     jsr  pn_win
.x:     clra                    ; next: nothing, or the advent gift
        ldab kv_arg
        cmpb #S_ADVENT
        bne  .r
        ldaa #C_GIFT
.r:     rts
; B = 0-7: A = 1 << B
sn_bit: ldaa #1
        andb #7
        beq  .x
.l:     asla
        decb
        bne  .l
.x:     rts
sn_items: fcb IT_S00,IT_S01,IT_S02,IT_S03,IT_S04,IT_S05,IT_S06,IT_S07,IT_S08,IT_S09,IT_S10,IT_S11
        fcb  IT_S12,IT_S13

; ---- the stage commands (A = the command; arguments by sc_arg) ----
sn_stage:
        cmpa #14                ; (tools/script.py CMDS)
        beq  sn_wipe
        cmpa #15
        beq  sn_window
        cmpa #16
        beq  sn_slide
; CEL n, x, y: a cel (or pose 128+) drawn on the canvas
sn_cel: jsr  sc_arg
        staa sn_n
        jsr  sc_arg
        staa sn_x
        jsr  sc_arg
        staa sn_y
        ldaa sn_n
        bpl  .cel
        anda #$7F               ; a pose: unpacked, 5 x 16 in bytes
        clrb
        jsr  sc_tab
        jsr  pose_unpack
        ldx  #kv_pose
        stx  sn_p
        ldd  #$0510
        std  sn_w
        ldaa #$FF               ; (rows in bytes, bits 4-0)
        staa sn_rb
        bra  .draw
.cel:   ldab #8
        jsr  sc_tab
        ldd  0,x                ; width, height, then bits packed
        std  sn_w
        inx
        inx
        stx  sn_p
        clr  sn_rb
.draw:  ldaa #$80
        staa sn_m               ; the bit to read
        clr  sn_cy
.y:     clr  sn_cx
        tst  sn_rb              ; a pose: each row starts a new byte, bit 4
        beq  .x
        ldaa #$10
        staa sn_m
.x:     ldx  sn_p
        ldaa 0,x
        anda sn_m
        beq  .nd
        ldaa sn_x
        adda sn_cx
        ldab sn_y
        addb sn_cy
        jsr  sn_dot
.nd:    lsr  sn_m               ; the next bit
        bne  .nb
        ldaa #$80
        staa sn_m
        ldx  sn_p
        inx
        stx  sn_p
.nb:    inc  sn_cx
        ldaa sn_cx
        cmpa sn_w
        bne  .x
        inc  sn_cy
        ldaa sn_cy
        cmpa sn_h
        bne  .y
        rts

; A = x (steps), B = y (rows): that dot lit on the canvas (off it, or on
; a gap step: nothing)
sn_dot: tsta
        bmi  .x
        tstb
        bmi  .x
        stab sn_t
        clrb                    ; col = x / 6, d = x mod 6
.d:     cmpa #6
        blo  .dn
        suba #6
        incb
        bra  .d
.dn:    cmpa #5
        beq  .x                 ; the gap
        staa sn_d
        ldaa sn_t               ; row: y / 8
        lsra
        lsra
        lsra
        tst  sn_strip
        bne  .st
        cmpb #4                 ; the block: 4 columns, 2 rows
        bhs  .x
        cmpa #2
        bhs  .x
        asla
        asla
        aba                     ; glyph = row * 4 + col
        bra  .g
.st:    cmpb #8                 ; the strip: 8 columns, 1 row
        bhs  .x
        tsta
        bne  .x
        tba
.g:     asla                    ; its row byte: glyph * 8 + y mod 8
        asla
        asla
        ldab sn_t
        andb #7
        aba
        tab
        ldx  #kv_glyph
        abx
        ldab sn_d               ; the bit: 4 - d
        ldaa #$10
.b:     tstb
        beq  .o
        lsra
        decb
        bra  .b
.o:     oraa 0,x
        staa 0,x
        ldaa #$FF
        staa kv_gdirty
.x:     rts

; WIPE: the canvas blank
sn_wipe:
        ldx  #kv_glyph
.l:     clr  0,x
        inx
        cpx  #kv_glyph+64
        bne  .l
        ldaa #$FF
        staa kv_gdirty
        rts

; WINDOW shape, col, row: the canvas shown there (0: hidden)
sn_window:
        bsr  sn_hide
        jsr  sc_arg
        staa sn_shape
        clr  sn_strip
        cmpa #2
        bne  .b
        inc  sn_strip
.b:     jsr  sc_arg
        staa sn_col
        jsr  sc_arg
        staa sn_row
        bsr  sn_show
        rts
; SLIDE dc: the window moved sideways
sn_slide:
        bsr  sn_hide
        jsr  sc_arg
        adda sn_col
        staa sn_col
        bsr  sn_show
        rts
; the window's cells: spaces / the canvas's characters (clipped to the
; screen)
sn_hide:
        ldaa #$FF
        bra  sn_cells
sn_show:
        clra
sn_cells:
        staa sn_t
        tst  sn_shape
        beq  .x
        clr  sn_k               ; glyph 0-7
.k:     ldaa sn_k               ; its column and row on the screen
        ldab sn_k
        tst  sn_strip
        bne  .s
        anda #3
        lsrb
        lsrb
        bra  .p
.s:     clrb
.p:     adda sn_col
        bmi  .n
        cmpa kv_w
        bhs  .n
        addb sn_row
        cmpb kv_h
        bhs  .n
        psha
        ldaa kv_w
        mul
        pula
        aba
        tab
        ldaa sn_k
        tst  sn_t
        beq  .put
        ldaa #' '
.put:   jsr  put
.n:     inc  sn_k
        ldaa sn_k
        cmpa #8
        bne  .k
.x:     rts

; ---- hooks ----
sn_hook:
        cmpa #1
        bne  .h2
        ldaa #1                 ; 1: "nn SPINS" on line 2: the feature's count
        jsr  pn_cell            ; (written on the panel's second line)
        pshb
        clra
        ldab kv_fn
        jsr  set32
        jsr  num_dec
        pulb
        ldx  #kv_nb+7
        ldaa #3
.c:     psha
        ldaa 0,x
        pshx
        pshb
        jsr  put
        pulb
        pulx
        inx
        incb
        pula
        deca
        bne  .c
        rts
.h2:    cmpa #2                 ; 2, 3: the credits count up to the balance
        beq  .cu
        cmpa #3
        bne  .h4
.cu:    jsr  pn_cr
        ldx  #kv_bal
        jsr  count_up
        rts
.h4:    cmpa #4                 ; 4: the win on the panel
        bne  .h5
        jsr  pn_win
        rts
.h5:    cmpa #5                 ; 5: the day of December on line 2
        bne  .h6
        ldaa #1
        jsr  pn_cell
        pshb
        clra
        ldab kv_arg+1
        incb
        jsr  set32
        jsr  num_dec
        pulb
        ldx  #kv_nb+8
        ldaa 0,x
        jsr  put
        incb
        ldaa 1,x
        jsr  put
.h6:    rts

sn_n:   fcb  0
sn_x:   fcb  0
sn_y:   fcb  0
sn_w:   fcb  0                  ; (sn_w, sn_h together)
sn_h:   fcb  0
sn_m:   fcb  0
sn_rb:  fcb  0
sn_cx:  fcb  0
sn_cy:  fcb  0
sn_t:   fcb  0
sn_d:   fcb  0
sn_k:   fcb  0
sn_shape: fcb 0
sn_strip: fcb 0
sn_col: fcb  0
sn_row: fcb  0
sn_p:   fdb  0
        include "cu.inc"
sn_data:                        ; the scene's blob, read in here
