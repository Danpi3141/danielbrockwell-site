// Profile: cycles by routine (kernel and the overlay in slot A) while fn() runs.
const fs = require('fs'), path = require('path');
module.exports = function profile(g, unit, fn) {
  const bdir = path.join(__dirname, '..', 'build', 'game');
  const ks = JSON.parse(fs.readFileSync(path.join(bdir, 'kernel.sym.json')));
  const us = unit ? JSON.parse(fs.readFileSync(path.join(bdir, unit.toLowerCase() + '.sym.json'))) : {};
  const syms = [];
  for (const [n, v] of Object.entries(ks)) if (v[1] === 'rel' && !n.includes('.') && !n.startsWith('kv_')) syms.push([v[0], n]);
  for (const [n, v] of Object.entries(us)) if (v[1] === 'rel' && !n.includes('.')) syms.push([v[0], unit + ':' + n]);
  syms.sort((a, b) => a[0] - b[0]);
  const base = g.base, dbg = g.m.dbg;
  const acc = {};
  let last = dbg.cycles(), lastName = 'os';
  dbg.setTrace((pc) => {
    const c = dbg.cycles();
    acc[lastName] = (acc[lastName] || 0) + (c - last);
    last = c;
    const o = pc - base;
    let name = 'os';
    if (o >= 0 && o < 0x2000) {
      let lo = 0, hi = syms.length - 1, k = -1;
      while (lo <= hi) { const mid = (lo + hi) >> 1; if (syms[mid][0] <= o) { k = mid; lo = mid + 1; } else hi = mid - 1; }
      if (k >= 0) name = syms[k][1];
    }
    lastName = name;
  });
  fn();
  dbg.setTrace(null);
  return Object.entries(acc).sort((a, b) => b[1] - a[1]);
};
