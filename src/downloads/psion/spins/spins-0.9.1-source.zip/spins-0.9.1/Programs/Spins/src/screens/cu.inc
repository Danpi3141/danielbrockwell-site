; ---------------------------------------------------------------------
; (Included by OV_WINFX and OV_SCENE: the credits counting up)
; ---------------------------------------------------------------------
; count_up: X = a target (4 bytes): the credits shown count up to it, in
; steps of a power of ten that make 10-99 steps, a rising tick each; a
; key goes straight there
count_up:
        ldd  0,x
        std  kv_tgt
        ldd  2,x
        std  kv_tgt+2
        clr  kv_cnt
.l:     ldd  kv_tgt             ; the difference
        std  kv_n32
        ldd  kv_tgt+2
        std  kv_n32+2
        ldd  kv_dbal
        std  kv_m32
        ldd  kv_dbal+2
        std  kv_m32+2
        ldx  #kv_n32
        ldd  kv_n32+2
        subd kv_m32+2
        std  kv_n32+2
        ldd  kv_n32
        sbcb kv_m32+1
        sbca kv_m32
        std  kv_n32
        bcs  .end               ; (past it: there)
        oraa kv_n32+1
        oraa kv_n32+2
        oraa kv_n32+3
        beq  .end
        jsr  num_dec            ; its digits: the step is 10^(digits - 2)
        ldx  #kv_nb
        ldab #1                 ; (k = leading spaces + 1, at most 9)
.s:     ldaa 0,x
        cmpa #' '
        bne  .k
        inx
        incb
        cmpb #9
        bne  .s
.k:     cmpb #9
        bls  .p
        ldab #9
.p:     negb                    ; the step: 10^(9 - k)
        addb #9
        pshb
        ldd  #1
        jsr  set32
        pulb
.m:     tstb
        beq  .a
        pshb
        ldab #10
        jsr  mul32
        pulb
        decb
        bra  .m
.a:     ldx  #kv_dbal
        jsr  add32
        jsr  pn_cr
        inc  kv_cnt             ; a tick, rising
        ldaa kv_cnt
        anda #15
        adda #24
        staa cu_fx+2
        ldx  #cu_fx
        jsr  snd_fx
        ldaa #3
        jsr  frame_t
        tst  kv_key
        beq  .l
        os   KB$GETK
.end:   ldd  kv_tgt
        std  kv_dbal
        ldd  kv_tgt+2
        std  kv_dbal+2
        jmp  pn_cr
cu_fx:  fcb  6,2,30,$FF
