; =====================================================================
; Four-line screen driver (LZ, LZ64). Loaded at DRV.
; Reels in columns 1, 3, 5, 7, 9 (1-based), four rows; lanes between;
; column 10 blank; the panel in columns 11-20.
; =====================================================================
        include "../defs.inc"

        jmp  d4_init
        jmp  d4_addr

d4_init:
        ldd  #$1404             ; 20 x 4
        std  kv_w
        ldaa #80
        staa kv_ncell
        ldd  #kv_under+80
        std  kv_cend
        ldaa #10
        staa kv_px
        ldaa #4
        staa kv_rows
        ldx  #kv_reelx
        clra
.r:     staa 0,x
        inx
        adda #2
        cmpa #10
        bne  .r
        rts

; A = a cell index (0-79): A = its DDRAM address. The LZ's controller
; holds each line in three pieces (the emulator's screen2mem4).
d4_addr:
        clrb
.r:     cmpa #20
        blo  .c
        suba #20
        incb
        bra  .r
.c:     ldx  #d4_t0
        cmpa #4
        blo  .s
        suba #4
        ldx  #d4_t1
        cmpa #8
        blo  .s
        suba #8
        ldx  #d4_t2
.s:     abx
        adda 0,x
        rts
d4_t0:  fcb  0,64,4,68
d4_t1:  fcb  8,72,16,80
d4_t2:  fcb  24,88,32,96
