# Psion Spins: build design notes

How this build implements the spec (`docs/spec.docx`), and where it deliberately differs.

## Files on the pack
- `SANTA` (OPL): checks FREE, calls SANTAG ("SANTA NEEDS n BYTES MORE RAM" if short).
- `SANTAG` (OPL): declares the array `m%()`, pokes the bootstrap (`src/launch/boot.asm`) into its top from one string, runs it with USR.
- `SANK` (data block): the kernel image + start-up code, the fixer and the kernel's fix-ups (read in one go by the bootstrap), then everything else as one data area (`B`) with an index at its start: code units (overlays, drivers) with fix-up lists, art, scripts, tunes, effects, tables. The spec's SANB0-3 are sections of B, found through the index (a skin is another set of sections).

## The array (one build for every model)
```
KH      (below the array) SANTAG's code before USR: the screen model (under[], shown[]), digits
0       kernel code: frame player, sound, script reader, keys, text, panel, overlay loader
KV      kernel variables (cleared at start; the start-up code is stored here on the pack)
DRV     screen driver: geometry, LCD address mapping
SLOTA   region R: one overlay, the data it reads in right after its code (a blob, tables),
        and the playing tune in its top 80 bytes (TUNEAT)
KR, KS  (above the array) SANTA's code before its call of SANTAG, and its NEEDS message:
        Santa's pose and halo, the script stack; the wins and the 32-bit work
```
KH, KR and KS are code that never runs again once the game has started; `tools/build.py` finds
them in the launchers' translated code, the start-up code checks SANTA's and SANTAG's code that
does run again is where the build says (else SPINS ERROR 3) and clears the holes.

## The screen model
- `under[]` (whole screen, W x H chars: 20x4 or 16x2; 80 bytes each for both, `shown[]` at +80) is what every cell should show, ignoring the sprite window.
- `shown[]` is what the LCD shows. A frame's flush writes every cell where (under, or the window's stage char) differs from shown: direct DDRAM writes (address via the driver's map). After switching on, shown[] is filled with $FF and every glyph marked dirty: everything is redrawn.
- 8 glyph shadows (64 bytes) with a dirty mask; dirty ones go to CGRAM at the frame start.
- Slots 0-3 pictures (Mrs Claus, reindeer, bell, house/present), 4-7 the stage, as the spec.

## Frames and sound
- A tick is 1/120 s = 7,680 cycles. A frame: compose the window, flush glyphs and cells (time measured with the FRC), then sound for the rest of the frame tick by tick; then KB$TEST (a key sets the skip flag).
- The tune runs in ticks (its tempo does not change with Glass speed); the Glass setting scales animation frame lengths.
- Tunes have two parts, melody and bass (`data/tunes.txt`: `bass` lines; the compiler checks they are the same length). The engine keeps a record for each voice; while both sound the melody has two ticks in three and the bass one (VOVH cycles are charged for the choosing and the new tone's set-up). A note's last tick is silent, its last 3 if it is 12 ticks or more, and the bass keeps quiet in the melody's gap, so repeated notes sound apart. The tune buffer (TUNEAT) is as long as the longest tune: HARK, 121 bytes.
- Interrupts stay enabled during notes (deviation from the spec, which masks them): the emulator drops a timer interrupt that comes due while masked, so keys and the clock would stop there; on hardware the keyboard interrupt's ~0.5 ms is a small gap every 50 ms. `MASK_NOTES` in the kernel switches to the spec's way for the real-hardware listening test.

## Switching off
- The Organiser counts down its switch-off time (TMW_TOUT); `frame_t` and the key waits set it back, so it never switches off in the middle of play. It switches off only in the game's own unlimited key wait (`kw_sleep`, after the Organiser's time), which redraws everything when it is on again. At rest with idle scenes on, OV_REST waits in 10-second steps (the snow at 20 s on four lines, a scene at 80 s and every 40 s on) and after 5 minutes waits for good; the count is kept in `kv_idlen` while the snow or a scene is in region R.

## Results before animation
- A spin is drawn, counted and saved before anything moves. A feature is computed in full when it is triggered (its random state kept), credited and saved; its spins are then replayed from that state for the show.
