// The save file: credits, bet, random state and statistics survive leaving and coming back;
// a short balance lowers the bet; an empty one is topped up by 500.
const { Game } = require('./lib');
const model = process.argv[2] || 'lz64';
const g = new Game(model);
g.start();
let bad = 0;
const ok = (c, m) => { if (!c) { bad++; console.log('FAIL', m); } else console.log('ok  ', m); };
g.spin(g.seedFor((b) => b.total > 0 && !b.santa && !b.freeSpins, 50), 1);
const bal = g.peek32('kv_bal');
const rng = g.peek32('kv_rng');
ok(g.peek32('st_spins') === 1 && g.peek32('st_staked') === 20, 'statistics: 1 spin, 20 staked (' + g.peek32('st_spins') + ', ' + g.peek32('st_staked') + ')');
g.m.press('UP', 3, 6); g.m.press('UP', 3, 6);           // bet 5 a line
g.run(0.5);
// leave (ON) and run SANTA again
g.m.press('ON', 3, 10); g.run(0.5); g.m.press('EXE', 3, 10); g.run(6);
ok(!/CR/.test(g.text()), 'left: ' + g.text().split(String.fromCharCode(10)).join(' | '));
const g2 = g; g2.start();
ok(g2.peek32('kv_bal') === bal, 'credits kept: ' + g2.peek32('kv_bal') + ' v ' + bal);
g2.setRng(0x12345678); g2.call(g2.ids().OV_BANK, 3);          // saved
g2.setRng(1); g2.call(g2.ids().OV_BANK, 0);                    // loaded
ok(g2.peek32('kv_rng') === 0x12345678, 'random state saved and loaded: ' + g2.peek32('kv_rng').toString(16));
ok(g2.peek32('st_spins') === 1, 'statistics kept');
// a balance too small for the bet: lowered
g2.poke('kv_bal', 0, 0); g2.poke('kv_bal', 0, 1); g2.poke('kv_bal', 0, 2); g2.poke('kv_bal', 50, 3);
g2.poke('kv_bet', 3);
g2.spin(null, 1);
ok(g2.peek('kv_bet') === 1 && g2.peek32('kv_bal') === 50, 'bet lowered to 2 a line (bet ' + g2.peek('kv_bet') + ', credits ' + g2.peek32('kv_bal') + ')');
g2.poke('kv_bal', 10, 3); g2.poke('kv_bet', 0);
g2.spin(null, 1);
ok(g2.peek32('kv_bal') === 510 && g2.peek('st_topups', 1) === 1, 'topped up: ' + g2.peek32('kv_bal'));
console.log(g2.scr().join('\n'));
process.exit(bad ? 1 : 0);
