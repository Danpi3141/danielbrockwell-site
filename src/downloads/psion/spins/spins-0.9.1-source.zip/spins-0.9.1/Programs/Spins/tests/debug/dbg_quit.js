const { Game } = require('../lib');
const g = new Game(process.argv[2] || 'lz64');
g.start();
const names = Object.fromEntries(Object.entries(g.ids()).map(([k, v]) => [v, k]));
g.m.press('ON', 3, 10); g.run(0.5);
console.log(g.scr().join('|'));
g.m.press('EXE', 3, 10);
for (let i = 0; i < 16; i++) { g.run(0.5); console.log((i/2+0.5).toFixed(1), names[g.peek('kv_res')], (g.m.dbg.pc()-g.base).toString(16), g.text().split('\n').join('|')); }
