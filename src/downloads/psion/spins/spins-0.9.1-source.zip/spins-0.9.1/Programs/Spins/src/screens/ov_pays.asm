; =====================================================================
; OV_PAYS: the pay table (a page for each paying symbol, drawn with it,
; then the rules) and the line viewer. Pages of four lines; two lines
; show a page in two halves. Each entry returns A = 0.
; =====================================================================
        include "../defs.inc"

        jmp  oi_pays            ; C_PAYS
        jmp  oi_lines           ; C_LINES

; ---------------------------------------------------------------------
; the pay table: a page for each paying symbol, then the rules
; ---------------------------------------------------------------------
oi_pays:
        clr  kv_tnt             ; (its data covers the tune buffer)
        bsr  oi_tabs
        ldaa #8+OI_RULES
        bsr  oi_pages
        ldx  #oi_ppage
        stx  oi_fn
        jmp  oi_view
oi_ppage:
        cmpa #8
        blo  .s
        suba #8                 ; the rules' pages
        ldx  #oi_rules
        jmp  oi_nth
.s:     staa oi_s               ; a symbol's page: its shape, name, pays
        ldx  #oi_buf
        stx  oi_p
        ldx  #oi_chr            ; line 1: the symbol, its name
        ldab oi_s
        abx
        ldaa 0,x
        ldab #1
        jsr  oi_lstart
        jsr  oi_ch
        ldaa #' '
        jsr  oi_ch
        ldx  #oi_names
        ldab oi_s
        jsr  oi_skipb
        jsr  oi_str
        jsr  oi_lend
        ldaa #3                 ; lines 2-4: 3, 4 and 5 in a row
.c:     staa oi_c
        jsr  oi_lstart
        ldaa oi_c
        adda #'0'
        jsr  oi_ch
        ldx  #oi_row
        jsr  oi_str
        ldaa oi_s               ; the pay
        ldab #3
        mul
        addb oi_c
        subb #3
        aslb
        ldx  #OI_PAYS
        abx
        ldd  0,x
        jsr  oi_num
        jsr  oi_lend
        inc  oi_c
        ldaa oi_c
        cmpa #6
        bne  .c
        ldx  #oi_buf
        rts
OI_RULES = 5
oi_rules:
        fcl  "SANTA: WILD"
        fcl  "On reel 1 he"
        fcl  "fills the reel,"
        fcl  "then delivers."
        fcl  "HOUSES"
        fcl  "Wild after his"
        fcl  "visit; else they"
        fcl  "block a line."
        fcl  "STARS: ANYWHERE"
        fcl  "3 = 10 Xmas Spins"
        fcl  "4 = 12, 5 = 15"
        fcl  "(reels 3,5: +1)"
        fcl  "XMAS SPINS"
        fcl  "Santa stays on"
        fcl  "reel 1: houses"
        fcl  "are all wild."
        fcl  "20 LINES"
        fcl  "Pays: line bet x"
        fcl  "the table, from"
        fcl  "reel 1 rightward"
oi_names:
        fcl  "Mrs Claus"
        fcl  "Reindeer"
        fcl  "Bell"
        fcl  "Wreath"
        fcl  "A"
        fcl  "K"
        fcl  "Q"
        fcl  "J"
oi_row: fcl  " in a row "
oi_chr: fcb  0,1,2,'@','A','K','Q','J'

; the lines and pays (from the tables) into oi_data: TB_LINES on
oi_tabs:
        ldaa #IT_TAB2
        tst  kv_four
        beq  .t
        ldaa #IT_TAB4
.t:     jsr  pk_item
        os   PK$RWRD
        ldd  #TB_LINES
        os   PK$SKIP
        ldd  #148
        ldx  #oi_data
        os   PK$READ
        rts
OI_LINES = oi_data
OI_PAYS = oi_data+100

; ---------------------------------------------------------------------
; the lines: each drawn across the reels with a block; LINE n of 20
; ---------------------------------------------------------------------
oi_lines:
        clr  kv_tnt
        bsr  oi_tabs
        clr  oi_k
.d:     jsr  cls
        clr  oi_c               ; every reel cell a dot
.r:     clr  oi_ln
.y:     ldaa #'.'
        bsr  oi_cell
        inc  oi_ln
        ldaa oi_ln
        cmpa kv_rows
        bne  .y
        inc  oi_c
        ldaa oi_c
        cmpa #5
        bne  .r
        ldab oi_k               ; this line's cells: a block each
        ldaa #5
        mul
        addd #OI_LINES
        std  oi_x
        clr  oi_c
.l:     ldx  oi_x
        ldab oi_c
        abx
        ldaa 0,x
        staa oi_ln
        ldaa #255
        bsr  oi_cell
        inc  oi_c
        ldaa oi_c
        cmpa #5
        bne  .l
        ldx  #oi_buf            ; the panel: LINE n
        stx  oi_p
        jsr  oi_lstart
        ldx  #oi_sline
        jsr  oi_str
        clra
        ldab oi_k
        incb
        jsr  oi_num
        jsr  oi_lend
        clra
        ldx  #oi_buf
        jsr  pn_text
        ldaa #1
        ldx  #oi_s20
        jsr  pn_text
        clra
        jsr  key_wait
        cmpb #K_DOWN
        beq  .dn
        cmpb #K_RIGHT
        beq  .dn
        cmpb #K_UP
        beq  .up
        cmpb #K_LEFT
        beq  .up
        clra
        rts
.dn:    inc  oi_k
        ldaa oi_k
        cmpa #20
        bne  .d
        clr  oi_k
        bra  .d
.up:    dec  oi_k
        bpl  .d
        ldaa #19
        staa oi_k
        bra  .d
; A = a character: into reel oi_c, row oi_ln
oi_cell:
        psha
        ldx  #kv_reelx
        ldab oi_c
        abx
        ldaa oi_ln
        ldab kv_w
        mul
        addb 0,x
        pula
        jmp  put
oi_sline: fcl "LINE "
oi_s20: fcl  "OF 20"

        include "pages.inc"
