// One scene frame, large: node tests/shot1.js model scene ms out.png
const fs = require('fs');
const { Game } = require('../lib');
const { lcdBitmap, sheet } = require('../png');
const [model, sc, ms, out] = [process.argv[2] || 'lz64', +(process.argv[3] || 1), +(process.argv[4] || 150), process.argv[5] || 'build/shots/one.png'];
const g = new Game(model);
g.start();
g.poke('kv_arg', sc); g.poke('kv_fn', 12);
let done = false;
const bms = [];
g.callSteps(g.ids().OV_SCENE, 0, ms / 1000, () => { if (!done) { bms.push(lcdBitmap(g, 8)); done = bms.length >= 2; } }, 60);
fs.writeFileSync(out, sheet(bms, 1));
