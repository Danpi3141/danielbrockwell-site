const { Game } = require('../lib');
const g = new Game(process.argv[2] || 'lz64');
g.start();
const ids = g.ids();
g.setRng(g.seedFor((b) => b.santa && b.houses >= 2));
g.call(ids.OV_GAME, 0);
g.call(ids.OV_SPINFX, 0);
const fa = g.addr('frame_t'), done = g.addr('t_done'), idle = g.addr('kw_idle');
g.m.runTo([idle]);
g.m.dbg.setA(ids.OV_WALK); g.m.dbg.setB(0); g.m.dbg.setPC(g.addr('t_call'));
let last = g.m.cycles(), n = 0;
for (;;) {
  const r = g.m.runTo([fa, done], 921600 * 5);
  if (r === done) break;
  const c = g.m.cycles();
  if (n++ < 40) console.log('frame_t A=', g.m.dbg.a(), 'since last', c - last, 'glass', g.peek('kv_glass'), 'SB', g.m.peekw(0x41));
  last = c;
  g.m.run(5);
}
