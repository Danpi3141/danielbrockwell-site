; =====================================================================
; OV_WINFX: the wins shown. Each winning line in turn (or the total
; only: setting kv_showw): its symbols flash, Mrs Claus, the reindeer
; or the bell animate in place, the panel names the line and its pay.
; Then, after a base spin, the credits count up to the lines' pay and a
; jingle sounds by the size of the win; a big one asks for a scene.
; Entries: 0 a base spin, 1 a free spin (its pay added to the feature's
; running total, shown as WIN).
; =====================================================================
        include "../defs.inc"

LN      = wf_data               ; the lines (20 x 5) and pays (8 x 3 words),
PAYS    = LN+100                ; then the blob
A_ANIM  = 0                     ; art: two frames for each of the 3 pictures,
A_PICS  = 6                     ; then the pictures themselves
E_JSMALL = 0                    ; effects
E_COIN  = 3
SC_BIG  = 1                     ; scene requests (kv_screq)
SC_HUGE = 2
SC_TREE = 3                     ; five wreaths: O Christmas Tree

        jmp  wf_base
        jmp  wf_free
        jmp  wf_count           ; WF_COUNT: the credits shown count up to kv_bal

wf_count:
        ldx  #kv_bal
        jsr  count_up
        clra
        rts

wf_base:
        clr  wf_fr
        clra                    ; the win shown starts at 0
        clrb
        std  kv_dwin
        std  kv_dwin+2
        bra  wf_go
wf_free:
        ldaa #1
        staa wf_fr
wf_go:  ldd  kv_dwin             ; the win shown before this spin's lines
        std  wf_d0
        ldd  kv_dwin+2
        std  wf_d0+2
        tst  kv_nwin
        bne  .w
        tst  wf_fr
        bne  .x
        jmp  pn_win             ; (WIN 0)
.x:     rts
.w:     ldaa #IT_WINS
        ldx  #wf_data+148
        stx  kv_scene
        jsr  pk_load
        ldaa #IT_TAB2           ; the lines and the pays, from the tables
        tst  kv_four
        beq  .t
        ldaa #IT_TAB4
.t:     jsr  pk_item
        os   PK$RWRD
        ldd  #TB_LINES
        os   PK$SKIP
        ldd  #148
        ldx  #LN
        os   PK$READ
        tst  kv_showw
        bne  .tot
        clr  wf_i
.l:     ldx  #kv_wins           ; each winning line in turn
        ldab wf_i
        abx
        tst  0,x
        beq  .nl
        jsr  wf_line
        bcs  .tot               ; (a key: the rest at once)
.nl:    inc  wf_i
        ldaa wf_i
        cmpa #20
        bne  .l
; the total: WIN shows it; the pictures as they were
.tot:   ldd  kv_lwin            ; the spin's pay in credits
        jsr  set32
        ldab kv_bet
        ldx  #bets
        abx
        ldab 0,x
        jsr  mul32
        tst  wf_fr
        bne  .fr
        ldd  kv_n32             ; WIN = the lines' pay
        std  kv_dwin
        ldd  kv_n32+2
        std  kv_dwin+2
        bra  .sh
.fr:    ldd  wf_d0              ; free: added to the running total
        std  kv_dwin
        ldd  wf_d0+2
        std  kv_dwin+2
        ldx  #kv_dwin
        jsr  add32
.sh:    jsr  pn_win
        ldx  #wf_none
        jsr  pn_msg
        clra                    ; the three pictures back
.p:     psha
        adda #A_PICS
        ldab #2
        jsr  sc_tab
        pula
        psha
        jsr  glyph_ld
        pula
        inca
        cmpa #3
        bne  .p
        tst  wf_fr
        bne  .done
; a base spin: the credits count up, a jingle by the size of it
        ldx  #kv_dbal
        ldd  kv_dwin
        std  kv_n32
        ldd  kv_dwin+2
        std  kv_n32+2
        ldd  kv_dbal
        std  wf_tg
        ldd  kv_dbal+2
        std  wf_tg+2
        ldx  #wf_tg
        jsr  add32
        ldx  #kv_wins           ; five wreaths on a line: O Christmas Tree
        ldab #20
.tr:    ldaa 0,x
        cmpa #$35               ; (wreath 3 << 4 | 5)
        beq  .tree
        inx
        decb
        bne  .tr
        bra  .sz
.tree:  ldaa #IT_T_TREE
        jsr  tune_go
.sz:    jsr  wf_size            ; A = 0 small, 1 medium (5x the stake), 2 large (20x)
        psha
        adda #E_JSMALL
        ldab #6
        jsr  sc_tab
        jsr  snd_fx
        pula
        cmpa #2
        bne  .c
        ldaa #SC_BIG            ; 20x and more: the big-win scene; 100x: huge
        staa kv_screq
        tst  wf_huge
        beq  .c
        inc  kv_screq
.c:     ldx  #wf_tg
        jsr  count_up
.done:  rts

; wf_size: A = 0, 1 or 2 for a win (kv_dwin) under 5x the stake, under
; 20x, or more; wf_huge set at 100x
wf_size:
        clr  wf_huge
        jsr  stake              ; kv_n32 = the stake
        ldd  kv_n32+2           ; (stakes fit 16 bits: 20-200)
        std  wf_st
        ldab #100
        bsr  .cmp
        bcs  .h
        inc  wf_huge
.h:     ldab #20
        bsr  .cmp
        ldaa #2
        bcc  .x
        ldab #5
        bsr  .cmp
        ldaa #1
        bcc  .x
        clra
.x:     rts
; carry clear if kv_dwin >= B * the stake
.cmp:   ldaa wf_st+1
        mul                     ; (the stake's low byte * B: stakes under 256)
        std  wf_t
        ldd  kv_dwin
        bne  .big               ; (over 65535: more than any multiple here)
        ldd  kv_dwin+2
        subd wf_t
        rts
.big:   clc
        rts

; wf_line: line wf_i (it pays: kv_wins) shown: its cells flash, its
; picture animates, the panel says "LINE n +pay". Carry set: a key
wf_line:
        ldab wf_i
        stab wf_li
        ldx  #kv_wins
        abx
        ldaa 0,x
        tab
        andb #15
        stab wf_n
        lsra
        lsra
        lsra
        lsra
        staa wf_sym
        ldab wf_li              ; its cells, and what they show now
        ldaa #5
        mul
        addd #LN
        std  wf_lp
        clr  wf_r
.c:     ldx  wf_lp
        ldab wf_r
        abx
        ldaa 0,x                ; the row
        ldab kv_w
        mul
        ldx  #kv_reelx
        pshb
        ldab wf_r
        abx
        pulb
        addb 0,x
        ldx  #wf_cells
        pshb
        ldab wf_r
        abx
        pulb
        stab 0,x
        ldx  #kv_under
        abx
        ldaa 0,x
        ldx  #wf_chars
        ldab wf_r
        abx
        staa 0,x
        inc  wf_r
        ldaa wf_r
        cmpa wf_n
        bne  .c
        ldaa wf_sym             ; its pay in credits
        ldab wf_n
        subb #3
        stab wf_t
        ldab #3
        mul
        addb wf_t
        aslb
        ldx  #PAYS
        abx
        ldd  0,x
        jsr  wf_mulbet
        ldd  wf_pay             ; WIN goes up by it
        jsr  set32
        ldx  #kv_dwin
        jsr  add32
        jsr  pn_win
        jsr  wf_text            ; "LINE n +pay"
        ldx  #wf_buf
        jsr  pn_msg
        ldaa #E_COIN
        ldab #6
        jsr  sc_tab
        jsr  snd_fx
        clr  wf_k               ; six frames: on, off; the picture moves
.f:     ldaa wf_k
        anda #1
        bne  .off
        clr  wf_r               ; on: the symbols
.on:    ldx  #wf_chars
        ldab wf_r
        abx
        ldaa 0,x
        bsr  wf_put
        inc  wf_r
        ldaa wf_r
        cmpa wf_n
        bne  .on
        bra  .anim
.off:   clr  wf_r               ; off: spaces
.of:    ldaa #' '
        bsr  wf_put
        inc  wf_r
        ldaa wf_r
        cmpa wf_n
        bne  .of
.anim:  ldaa wf_sym             ; Mrs Claus, the reindeer, the bell: in place
        cmpa #3
        bhs  .fr
        asla
        ldab wf_k
        lsrb
        andb #1
        aba                     ; their frame: 2 * symbol + (k / 2) & 1
        ldab #2
        jsr  sc_tab
        ldaa wf_sym
        jsr  glyph_ld
.fr:    ldaa #10
        jsr  frame
        tst  kv_key
        bne  .key
        inc  wf_k
        ldaa wf_k
        cmpa #6
        bne  .f
        clr  wf_r               ; the symbols back
.bk:    ldx  #wf_chars
        ldab wf_r
        abx
        ldaa 0,x
        bsr  wf_put
        inc  wf_r
        ldaa wf_r
        cmpa wf_n
        bne  .bk
        clc
        rts
.key:   os   KB$GETK
        clr  wf_r
.kb:    ldx  #wf_chars
        ldab wf_r
        abx
        ldaa 0,x
        bsr  wf_put
        inc  wf_r
        ldaa wf_r
        cmpa wf_n
        bne  .kb
        sec
        rts
; A = a character for cell wf_r of the line
wf_put: ldx  #wf_cells
        ldab wf_r
        abx
        ldab 0,x
        jmp  put

; wf_mulbet: D = a pay in line bets: wf_pay = D times the bet
wf_mulbet:
        std  wf_t2
        clr  wf_pay
        clr  wf_pay+1
        ldab kv_bet
        ldx  #bets
        abx
        ldab 0,x
.l:     pshb
        ldd  wf_pay
        addd wf_t2
        std  wf_pay
        pulb
        decb
        bne  .l
        rts

; wf_text: wf_buf = the line and its pay in the panel's 10 characters,
; as the other panel lines: "L15    +40" (at most "L20  +8000": the
; biggest line pay is 800 line bets at 10)
wf_text:
        ldd  wf_pay             ; the pay, right-aligned, with its +
        jsr  set32
        jsr  num_dec
        ldx  #kv_nb
.sp:    ldaa 0,x
        cmpa #' '
        bne  .pl
        inx
        bra  .sp
.pl:    dex
        ldaa #'+'
        staa 0,x
        clrb                    ; into the buffer
.cp:    ldx  #kv_nb
        abx
        ldaa 0,x
        ldx  #wf_buf+1
        abx
        staa 0,x
        incb
        cmpb #10
        bne  .cp
        stab wf_buf             ; (10 characters)
        ldx  #wf_buf+1          ; the line on the left
        stx  wf_p
        ldaa #'L'
        bsr  .ch
        ldab wf_li
        incb
        clra
        bra  .num
.num:   jsr  set32              ; D in decimal, no spaces
        jsr  num_dec
        ldx  #kv_nb
.ns:    ldaa 0,x
        cmpa #' '
        bne  .nd
        inx
        bra  .ns
.nd:    ldaa 0,x
        pshx
        bsr  .ch
        pulx
        inx
        cpx  #kv_nb+10
        bne  .nd
        rts
.ch:    ldx  wf_p
        cpx  #wf_buf+11
        beq  .cx
        staa 0,x
        inx
        stx  wf_p
.cx:    rts
wf_none: fcb 0

wf_fr:  fcb  0
wf_i:   fcb  0
wf_li:  fcb  0
wf_n:   fcb  0
wf_sym: fcb  0
wf_r:   fcb  0
wf_k:   fcb  0
wf_huge: fcb 0
wf_lp:  fdb  0
wf_pay: fdb  0
wf_st:  fdb  0
wf_t:   fdb  0
wf_t2:  fdb  0
wf_p:   fdb  0
wf_tg:  rmb  4
wf_d0:  rmb  4
wf_cells: rmb 5                 ; (before wf_data: the lines are read in there)
wf_chars: rmb 5
wf_buf: rmb  11
        include "cu.inc"
wf_data:                        ; the lines and pays, then the blob
