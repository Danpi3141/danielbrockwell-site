const { Game } = require('../lib');
const g = new Game('lz64'); g.start(); const ids = g.ids();
g.poke('kv_arg', 3); g.poke('kv_arg', 1, 1); g.poke('kv_spx', 0);
g.call(ids.OV_TEST, 3);
for (const x of [0, 5, 6]) {
  g.poke('kv_spx', x);
  g.call(ids.OV_TEST, 4);
  console.log('x', x, 'wc', g.peek('kv_wc'), 'wo', g.peek('kv_wo'), 'wsave', [0, 1, 2, 3].map((i) => g.peek('kv_wsave', i)));
  console.log(' under r1', [0, 1, 2].map((i) => g.peek('kv_under', 20 + i)), 'r2', [0, 1, 2].map((i) => g.peek('kv_under', 40 + i)));
  for (let k = 4; k < 8; k++) console.log(' g' + k, [...Array(8)].map((_, i) => g.peek('kv_glyph', k * 8 + i)).join(','), ' lcd', g.m.udg(k).join(','));
  console.log(g.lcd(3));
}
