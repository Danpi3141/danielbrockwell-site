// lineWinFast (the 6303's rule) equals the brute-force lineWin on every 5-cell line over the
// alphabet the game uses (paying symbols, house, star, wild): 11^5 = 161,051 lines.
const G = require('../ref/game.js');
const A = [...'MRBWAKQJH*X'];
let n = 0, bad = 0;
const c = [0, 0, 0, 0, 0];
for (let i = 0; i < 11 ** 5; i++) {
  let v = i;
  for (let r = 0; r < 5; r++) { c[r] = A[v % 11]; v = Math.floor(v / 11); }
  const a = G.lineWin(c), b = G.lineWinFast(c);
  n++;
  if (JSON.stringify(a) !== JSON.stringify(b)) { if (bad++ < 5) console.log(c.join(''), a, b); }
}
console.log(`lineWinFast: ${n} lines, ${bad} differ`);
process.exit(bad ? 1 : 0);
