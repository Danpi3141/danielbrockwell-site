; ---------------------------------------------------------------------
; Kernel variables: cleared by the start-up code (they are not on the
; pack: the start-up code is stored where they go).
;
; Some live outside the array, in the launchers' code that never runs
; again once the game has started (tools/build.py santag_hole and
; santa_hole; tests/t_hidden.js):
; KH: SANTAG's code before its USR call (its copy of the bootstrap string
; among it), just below the array: the screen model and the number's digits
; KR: SANTA's code before its call of SANTAG, just above the array: Santa's
; pose and halo, the script reader's stack
; KS: SANTA's code after it (the message that never shows once the game
; has run): the wins, the 32-bit work
; ---------------------------------------------------------------------
kh_first = KH
kv_under = KH+0                 ; (80) the screen model (SHOWN = 80 on)
kv_shown = KH+80                ; (80) what the LCD shows
kv_n     = KH+160               ; (4) num_dec's work
kv_nbl   = KH+164               ; (1) (num_at: a length byte before the digits)
kv_nb    = KH+165               ; (10) a number in decimal
kv_sdep  = KH+175               ; (1) the script reader's stack's depth in bytes
kv_sct   = KH+176               ; (1)
kv_sci   = KH+177               ; (1)
kv_nokey = KH+178               ; (1) keys do not end the script
kv_hook  = KH+179               ; (2) the director's HOOK handler
kv_stage = KH+181               ; (2) and its stage-command handler
kh_end   = KH+183
kr_first = KR
kv_pose  = KR+0                 ; (16) the pose
kv_halo  = KR+16                ; (16) and its halo (right after it)
kv_sstk  = KR+32                ; (12) the script reader's stack: four entries, count and address
kr_end   = KR+44
; KS: SANTA's code after the call (its "NEEDS" message), above KR
ks_first = KS
kv_wins  = KS+0                 ; (20) each line: 0, or symbol << 4 | count
kv_n32   = KS+20                ; (4) a 32-bit argument
kv_m32   = KS+24                ; (4)
kv_tgt   = KS+28                ; (4) count_up's target
kv_win   = KS+32                ; (4) the whole play's pay in credits
kv_cnt   = KS+36                ; (1)
kv_day   = KS+37                ; (2) the month and day the date was last looked at
ks_end   = KS+39

kv_first:
; ---- the saved part, as the save file's record (OV_BANK): its length,
; a tag and version, the bytes, a checksum
sv_rec:     rmb  1
sv_tag:     rmb  2
sv_first:
kv_bal:     rmb  4              ; the credits
kv_bet:     rmb  1              ; 0-3: 1, 2, 5, 10 a line
kv_rng:     rmb  4              ; the random state (xorshift32): saved, so switching
                                ; off and on cannot replay a spin
kv_anim:    rmb  1              ; settings: Animation 0 Off, 1 Quick, 2 Full
kv_styles:  rmb  1              ; Santa's styles: 0 all six, 1 standard only
kv_sound:   rmb  1              ; Sound 0 on, 1 soft, 2 off
kv_music:   rmb  1              ; Music 0 on, 1 off
kv_glass:   rmb  1              ; Glass 0-3: 8 10 12 15 frames a second
kv_showw:   rmb  1              ; Show wins 0 line by line, 1 total only
kv_astop:   rmb  1              ; Autoplay stops 0 on a feature, 1 on a big win, 2 never
kv_idle:    rmb  1              ; Idle scenes 0 on, 1 off
st_spins:   rmb  4              ; statistics
st_staked:  rmb  4
st_paid:    rmb  4
st_big:     rmb  4              ; the biggest win
st_santa:   rmb  2              ; Santa's visits
st_feats:   rmb  2              ; features
st_topups:  rmb  2
st_seen:    rmb  2              ; the scenes seen (bits: for the replay menu)
st_gift:    rmb  1              ; the year of the last Christmas Day gift
st_door:    rmb  3              ; the advent doors opened (bits: 1-24 December)
st_dyear:   rmb  1              ; the year they were opened in
st_bestb:   rmb  4              ; the session record: the best balance,
st_run:     rmb  1              ; the longest run of paying spins,
st_mosth:   rmb  1              ; the most houses in one delivery
sv_end:
sv_chk:     rmb  1
kv_frng:    rmb  4              ; the feature's random state, for its show
kv_sp:      rmb  2              ; the stack at entry (quit returns from there)
kv_base:    rmb  2              ; the array's address
kv_dev:     rmb  1              ; the game's device: A: 0, B: 1, C: 2
kv_bpa:     rmb  3              ; area B's pack address
kv_pa:      rmb  3              ; the pack address being sought
kv_pkok:    rmb  1              ; the device is selected
kv_res:     rmb  1              ; the overlay in slot A (0 none)
kv_rx:      rmb  2
kv_fo:      rmb  2
kv_t0:      rmb  2              ; scratch
kv_t1:      rmb  2
kv_t2:      rmb  2
kv_t3:      rmb  2
kv_arg:     rmb  2              ; an argument for an overlay's entry
kv_left:    rmb  1              ; key_wait
kv_aidle:   rmb  2
kv_afr:     rmb  1
kv_four:    rmb  1              ; four-line display
kv_omode:   rmb  1              ; the LZ's display mode at entry
kv_oclk:    rmb  1              ; and its clock
kv_next:    rmb  1              ; the display's next DDRAM address ($FF unknown)
kv_gdirty:  rmb  1              ; glyphs to send
kv_cdirty:  rmb  1              ; cells changed
kv_cend:    rmb  2              ; kv_under + kv_ncell
kv_w:       rmb  1              ; the screen: width, height, cells
kv_h:       rmb  1
kv_ncell:   rmb  1
kv_px:      rmb  1              ; the panel's first column
kv_rows:    rmb  1              ; reel rows: 4 or 2
kv_reelx:   rmb  5              ; each reel's column
kv_grid:    rmb  20             ; the reels' windows (these two together:
kv_santa:   rmb  1              ; OV_GAME keeps them across a feature); reel 1 and the houses are wild
kv_nwin:    rmb  1              ; the lines that pay
kv_lwin:    rmb  2              ; their pay in line bets
kv_fn:      rmb  1              ; a feature's spins at the start (0 none)
kv_fseed:   rmb  4              ; its random state
kv_dbal:    rmb  4              ; the credits shown (counting up to kv_bal)
kv_dwin:    rmb  4              ; the win shown
kv_fleft:   rmb  1              ; spins left to show
kv_fsofar:  rmb  1              ; spins known so far
kv_fidx:    rmb  1              ; the spin being shown
kv_screq:   rmb  1
kv_auto:    rmb  1              ; autoplay: spins to go (255: until a feature)
kv_short:   rmb  1
kv_gok:     rmb  1              ; the last win may be gambled
kv_runn:    rmb  1              ; paying spins in a row now
kv_idlen:   rmb  1              ; OV_REST's idle count, kept over an idle scene
kv_snow:    rmb  1              ; snow settled in the lanes (four lines)              ; the last spin's stake was short              ; a scene asked for (big win ...)
kv_fl:      rmb  1              ; the frame player: ticks left
kv_f0:      rmb  2              ; the counter at the frame's start
kv_key:     rmb  1              ; a key waiting after the last frame
kv_s:       rmb  2              ; the sound engine
kv_ss:      rmb  2
kv_sh:      rmb  1
kv_ls:      rmb  2              ; the last tone's S and shift (its counts kept)
kv_lsh:     rmb  1
kv_fxp:     rmb  2
kv_fxt:     rmb  1
kv_fxi:     rmb  1
kv_tune:    rmb  10             ; the tune's two voices (ksound.asm: VP ...)
kv_bass:    rmb  10             ; (its VBASE stays 0: note E4)
kv_tnt      = kv_tune+4         ; the melody's ticks left: 0 no tune
kv_tloop:   rmb  1
kv_tunit:   rmb  1
kv_alt:     rmb  1              ; whose tick it is when both sound (0-2)
kv_comp:    rmb  2              ; the compositor in slot A (0: none)
kv_wc:      rmb  1              ; its left column ($FF: no cells taken)
kv_wo:      rmb  1              ; the sprite's dot within it, 0-5
kv_wcnt:    rmb  1
kv_spx:     rmb  1              ; the sprite: left edge in steps
kv_spy:     rmb  1              ; the window's top row
kv_wsave:   rmb  4              ; the window cells' own characters
kv_wsp:     rmb  2
kv_whl:     rmb  2
kv_fontp:   rmb  2              ; the shapes of the font's characters (or 0)
kv_scene:   rmb  2              ; the blob in use (just after its director)
kv_ip:      rmb  2              ; the script reader: the next command
kv_cos:     rmb  1              ; the cosmetic random byte
kv_glyph:   rmb  64             ; the 8 defined characters
kv_end:
