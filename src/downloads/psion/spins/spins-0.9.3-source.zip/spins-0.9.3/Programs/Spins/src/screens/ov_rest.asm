; =====================================================================
; OV_REST: the screen at rest: the reels, the panel, the keys. Returns
; A = a command for the kernel (kv_arg its argument).
;   EXE spin   UP, DOWN the line bet   A autoplay   P pay table
;   L lines    S statistics            MODE menu    ON leave (asks)
; Autoplay: while kv_auto counts, every return is a spin, unless a key
; was pressed or its stop rule is met. Idle: snow in the lanes after 20
; s (four lines), a scene after 80 s and every 40 s on, then after 5
; minutes a wait in which the Organiser may switch off (the count is kept
; in kv_idlen while another overlay shows the snow or a scene). A new day
; (the game left running overnight, the Organiser switched off in it):
; C_DATE, as at the start (advent, Christmas Day, New Year); a key
; pressed then only wakes it.
; =====================================================================
        include "../defs.inc"

        jmp  or_go

or_go:  tst  kv_auto            ; autoplay?
        beq  .rest
        os   KB$TEST            ; a key stops it
        tstb
        bne  .stop
        tst  kv_short           ; the credits ran short
        bne  .stop
        ldaa kv_astop           ; its stop rule: 0 a feature, 1 a big win
        bne  .r1
        tst  kv_fn
        bne  .stop
        bra  .on
.r1:    cmpa #1
        bne  .on
        tst  kv_screq
        bne  .stop
.on:    ldaa kv_auto            ; (255: until the Xmas Spins)
        cmpa #255
        beq  .go
        dec  kv_auto
        beq  .stop
.go:    jsr  or_draw
        ldaa #C_SPIN
        rts
.stop:  os   KB$FLSH
        clr  kv_auto
        ldx  #or_aoff
        jsr  snd_fx
        ldaa #6
        jsr  frame_t
.rest:  clr  kv_short
        jsr  or_draw
        ldaa kv_idlen           ; back from the snow or a scene: still idle
        staa or_idle
        clr  kv_idlen
.k:     bsr  or_day             ; a new day?
        bne  .dt
        ldaa kv_idle            ; idle scenes off: wait (and switch off)
        bne  .w0
        ldaa or_idle            ; after 5 minutes: wait (and switch off)
        cmpa #30
        bhs  .w0
        ldaa #200               ; 10 seconds
        jsr  key_wait
        tstb
        bne  .key
        inc  or_idle
        ldaa or_idle
        cmpa #2                 ; 20 s: snow in the lanes (four lines)
        bne  .i6
        tst  kv_four
        beq  .k
        ldab #C_SNOW
        bra  .idl
.i6:    cmpa #6                 ; 80 s, and every 40 s on: an idle scene
        blo  .k
        anda #3
        bne  .k
        ldab #C_IDLE
.idl:   ldaa or_idle            ; (the count, for when we are back)
        staa kv_idlen
        tba
        rts
.w0:    clra
        jsr  key_wait
.key:   clr  or_idle            ; (a key: no longer idle)
        bsr  or_day             ; switched on on a new day: its date first
        bne  .dt
        cmpb #K_EXE
        bne  .b
        ldaa #C_SPIN
        rts
.b:     cmpb #K_UP              ; the line bet
        bne  .d
        ldaa kv_bet
        cmpa #3
        beq  .k
        inc  kv_bet
        ldx  #or_bup
        bra  .bet
.d:     cmpb #K_DOWN
        bne  .o
        tst  kv_bet
        beq  .k
        dec  kv_bet
        ldx  #or_bdn
.bet:   jsr  snd_fx
        jsr  pn_bet
        ldaa #6
        jsr  frame_t
        jmp  .k
.o:     ldx  #or_keys           ; the other keys: their commands
.t:     ldaa 0,x
        beq  .k
        cba
        beq  .c
        inx
        inx
        bra  .t
.c:     ldaa 1,x
        rts
.dt:    ldaa #C_DATE
        rts

; or_day: Z clear if the month or day is not what B_DATE last saw (B, a
; key, kept: a pull leaves the flags)
or_day: pshb
        ldd  TMB_MON
        subd kv_day
        pulb
        rts

or_keys: fcb 'A',C_AUTO, 'P',C_PAYS, 'L',C_LINES, 'S',C_STATS, 'G',C_GAMBLE
        fcb  K_MODE,C_MENU, K_ON,C_LEAVE, 0

; the reels and the panel
or_draw:
        bsr  or_reels
        tst  kv_four            ; (stretch goal) the snow at the foot of the lanes:
        beq  or_panel           ; a level every 16 spins; a big win sweeps it off
        tst  kv_screq
        beq  .s
        clr  kv_snow
.s:     ldab kv_snow
        lsrb
        lsrb
        lsrb
        lsrb
        cmpb #3
        bls  .l
        ldab #3
.l:     ldx  #or_snow
        abx
        ldaa 0,x
        ldab #61                ; row 4, columns 2, 4, 6, 8, 10
.c:     pshb
        jsr  put
        pulb
        addb #2
        cmpb #71
        blo  .c
; the panel: CR, BET, WIN (on two lines: WIN if there was one, else
; BET); EXE=SPIN, or the autoplay count
or_panel:
        jsr  pn_cr
        jsr  pn_bet
        ldd  kv_dwin
        bne  .w
        ldd  kv_dwin+2
        beq  .m
.w:     jsr  pn_win
.m:     tst  kv_auto
        bne  .a
        tst  kv_four
        beq  .x
        ldx  #or_exe
        tst  kv_gok             ; (after a win: G gambles it)
        beq  .e
        ldx  #or_gam
.e:     jmp  pn_msg
.a:     ldx  #or_auto           ; "AUTO n" (or AUTO XMAS)
        ldaa kv_auto
        cmpa #255
        beq  .ax
        clra
        ldab kv_auto
        jsr  set32
        jsr  num_dec
        ldx  #or_abuf+5
        ldd  kv_nb+8
        std  0,x
        ldx  #or_abuf
.ax:    jmp  pn_msg
.x:     rts
or_exe: fcl  "EXE=SPIN"
or_snow: fcb ' ','.','_','='
or_gam: fcl  "G=GAMBLE"
or_auto: fcl "AUTO XMAS"
or_abuf: fcb 7
        fcc  "AUTO   "

; the reels from kv_grid; Santa on reel 1 standing (glyphs 4 and 5;
; on four lines a + above and below)
or_reels:
        jsr  cls
        clr  or_r
        ldx  #kv_grid           ; Santa?
        ldab kv_rows
.sa:    ldaa 0,x
        cmpa #9
        beq  .santa
        inx
        decb
        bne  .sa
        bra  .r
.santa: ldaa #IT_SANTA          ; him standing
        ldx  #kv_glyph+32
        jsr  pk_load
        ldaa kv_gdirty
        oraa #$30
        staa kv_gdirty
        clrb
        tst  kv_four
        beq  .t
        ldaa #'+'
        jsr  put
        ldaa #'+'
        ldab #60
        jsr  put
        ldab #20
.t:     ldaa #4
        pshb
        jsr  put
        pulb
        addb kv_w
        ldaa #5
        jsr  put
        inc  or_r               ; (reel 1 done)
.r:     clr  or_y
.y:     ldaa or_r
        asla
        asla
        adda or_y
        tab
        ldx  #kv_grid
        abx
        ldab 0,x
        ldx  #or_chr
        abx
        ldaa 0,x
        psha
        ldx  #kv_reelx
        ldab or_r
        abx
        ldaa or_y
        ldab kv_w
        mul
        addb 0,x
        pula
        jsr  put
        inc  or_y
        ldaa or_y
        cmpa kv_rows
        bne  .y
        inc  or_r
        ldaa or_r
        cmpa #5
        bne  .r
        rts
or_chr: fcb  0,1,2,'@','A','K','Q','J',3,4,'*'

or_bup:  fcb 1,4,32,1, 1,6,39,1, $FF     ; bet up: C7 then G7
or_bdn:  fcb 1,4,39,1, 1,6,32,1, $FF
or_aoff: fcb 1,3,39,1, 1,3,36,1, 1,6,32,1, $FF
or_r:   fcb  0
or_y:   fcb  0
or_idle: fcb 0
