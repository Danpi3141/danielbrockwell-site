; =====================================================================
; Psion Spins - shared definitions
; (system variables from the Technical Reference Manual: the same on
; the CM, XP, LA and LZ)
; =====================================================================

; ---- zero-page scratch (UTW_S0..S5). Clobbered by many OS calls.
T0      = $41
T1      = $42
T2      = $43
T3      = $44
T4      = $45
T5      = $46
T6      = $47
T7      = $48
T8      = $49
T9      = $4A
T10     = $4B
T11     = $4C

; ---- system variables and hardware
KBB_DLAY = $77                  ; key repeat delay (ticks)
KBB_REPT = $78                  ; key repeat rate (ticks)
KBB_STAT = $7B
TMB_YEAR = $20C5                ; the clock: year, month (0-11), day (0-30), hour, minute, second
TMB_MON  = $20C6
TMB_DAY  = $20C7
TMB_HOUR = $20C8
TMB_MIN  = $20C9
TMB_SEC  = $20CA
TMW_FRAM = $20CB                ; frame counter, +1 every 50 ms
TMW_TOUT = $007D                ; seconds left to auto switch-off
TMW_TCNT = $20CD                ; auto switch-off time in seconds
LCD_CTRL = $0180
LCD_DATA = $0181
BZ_ON    = $0280                ; touching it raises the buzzer's line
BZ_OFF   = $02C0                ; touching it lowers it
FRC      = $0009                ; the processor's free-running counter (2 bytes)
MODEL    = $FFE8                ; model byte: 0 CM, 1 XP, 2 LA, 13/14/29/30 four-line
ALA_FREE = $2040                ; the first byte above the allocated cells

; ---- key codes
K_ON    = 1
K_MODE  = 2
K_UP    = 3
K_DOWN  = 4
K_LEFT  = 5
K_RIGHT = 6
K_DEL   = 8
K_EXE   = 13
K_SPACE = 32

; ---- error codes returned to the launcher in X
E_OK     = 0
E_NOPACK = 1                    ; game files not found
E_RUN    = 3                    ; SANTAG run by itself (run SANTA): no SANTA above the array
E_FILES  = 2                    ; a block is missing or damaged

; ---- timing
TICK_CYC = 7680                 ; cycles in a tick, 1/120 s at 921,600 Hz

; ---- screen driver entries (a jump table at DRV)
DV_INIT = 0                     ; geometry into the kernel's variables
DV_ADDR = 3                     ; A = cell index: A = DDRAM address

; ---- OV_GAME entries
G_SPIN  = 0
G_FREE  = 1
G_TABS  = 2
G_PAY   = 3
G_GIFT  = 4
G_XINIT = 5

; ---- commands returned by OV_REST and the menu (A)
C_NONE  = 0
C_SPIN  = 1
C_QUIT  = 2                     ; (after asking): the goodbye, saved, out
C_MENU  = 3                     ; 3 on: a table on the pack (tools/build.py CMDS)
C_PAYS  = 4
C_LINES = 5
C_STATS = 6
C_SET   = 7
C_JUKE  = 8
C_SCENES = 9
C_HELP  = 10
C_NEW   = 11
C_AUTO  = 12
C_LEAVE = 13
C_SNOW  = 14
C_IDLE  = 15
C_SCENE = 16                    ; kv_arg = the scene
C_BANKNEW = 17
C_SAVE  = 18
C_GIFT  = 19                    ; the advent gift: three free spins (OV_GAME)
C_GSETTLE = 20                  ; paid and saved (OV_BANK), then C_XMAS
C_GAMBLE = 21
C_DATE  = 22                    ; the day has changed: advent, Christmas Day, New Year
C_LAST  = 22
C_XMAS  = 30                    ; (the kernel: the Xmas Spins shown)
; ---- overlay entries
B_LOAD  = 0                     ; OV_BANK: the save file, or a new player
B_STAKE = 1                     ; the stake taken (carry: not enough)
B_SETTLE = 2                    ; the win paid, the statistics, saved
B_SAVE  = 3
B_NEW   = 4                     ; a new player
B_DATE  = 5                     ; Christmas Day, advent, New Year
B_GSETTLE = 6                   ; the gift paid
SF_BASE = 0                     ; OV_SPINFX
SF_FREE = 1
WF_BASE = 0                     ; OV_WINFX
WF_FREE = 1
WF_COUNT = 2
X_THROW = 0                     ; OV_XFX
X_PANEL = 1
; ---- the scenes (OV_SCENE, kv_arg)
S_TITLE = 0
S_XSTART = 1
S_XEND  = 2
S_BIG   = 3
S_HUGE  = 4
S_FULL  = 5
S_BROKE = 6
S_VILLAGE = 7
S_CHIMNEY = 8
S_PEEK  = 9
S_BYE   = 10
S_XMASDAY = 11
S_ADVENT = 12
S_NEWYEAR = 13
