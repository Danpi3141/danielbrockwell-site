; =====================================================================
; OV_BANK: the credits and the save file. A:SANSAV is one record: the
; bytes sv_first..sv_end (credits, bet, random state, settings and the
; statistics), with its length, a tag and version first and a checksum
; last; it is read and written in place, and rewritten after every spin.
; =====================================================================
        include "../defs.inc"

SV_LEN  = sv_end-sv_first
SV_VER  = 2                     ; (2: st_dyear)

        jmp  ob_load            ; B_LOAD: the save file, or a new player
        jmp  ob_stake           ; B_STAKE: the stake taken (carry: no spin)
        jmp  ob_settle          ; B_SETTLE: the win paid, counted, saved
        jmp  ob_save            ; B_SAVE
        jmp  ob_new             ; B_NEW: a new player
        jmp  ob_date            ; B_DATE: Christmas Day, advent, New Year
        jmp  ob_gsettle         ; B_GSETTLE: the advent gift paid, then shown

ob_gsettle:
        jsr  ob_settle
        ldaa #C_XMAS
        rts

; B_DATE: at the start, and when OV_REST sees the day change (C_DATE):
; 1-24 December today's advent door; 25 December, once a year, 250
; credits and the greeting; 31 December and 1 January, New Year
; (A = C_SCENE, kv_arg = the scene); else A = 0
ob_date:
        ldd  TMB_MON            ; A the month (0-11), B the day (0-30):
        std  kv_day             ; remembered, for OV_REST
        tstb
        bne  .ny
        tsta                    ; 1 January: New Year
        beq  .nyr
.ny:    cmpa #11
        bne  .no
        cmpb #30                ; 31 December: New Year
        bne  .ad
.nyr:   ldaa #S_NEWYEAR
        bra  .sc
.ad:    cmpb #24                ; 1-24 December: the advent calendar
        bhs  .xd
        ldaa TMB_YEAR           ; a new year's calendar: every door shut
        cmpa st_dyear
        beq  .dy
        staa st_dyear
        clr  st_door
        clr  st_door+1
        clr  st_door+2
.dy:
        stab kv_arg+1           ; (the day, 0-23)
        lsrb                    ; its door: bit d mod 8 of st_door[d / 8]
        lsrb
        lsrb
        ldx  #st_door
        abx
        ldab kv_arg+1
        andb #7
        jsr  ob_bit
        bita 0,x
        bne  .no                ; opened already
        oraa 0,x
        staa 0,x
        jsr  ob_save
        ldaa #S_ADVENT
.sc:    staa kv_arg
        ldaa #C_SCENE
        rts
.xd:    cmpb #24                ; 25 December
        bne  .no
        ldaa TMB_YEAR
        cmpa st_gift
        beq  .no
        staa st_gift
        ldd  #250
        jsr  set32
        ldx  #kv_bal
        jsr  add32
        jsr  ob_save
        ldaa #S_XMASDAY
        staa kv_arg
        ldaa #C_SCENE
        rts
.no:    clra
        rts

; ---------------------------------------------------------------------
; B_LOAD: the record read straight into place, then checked; else a
; new player
; ---------------------------------------------------------------------
ob_load:
        bsr  sv_open
        bcs  ob_new
        ldx  #sv_rec
        os   FL$READ
        bcs  ob_new
        ldaa sv_rec
        cmpa #SV_LEN+3
        bne  ob_new
        ldd  sv_tag
        subd #'S'*256+SV_VER
        bne  ob_new
        jsr  sv_sum
        cmpb sv_chk
        bne  ob_new
        ldaa kv_bet             ; a setting out of range (a damaged file whose
        cmpa #4                 ; sum still agrees): its first choice
        blo  .b
        clr  kv_bet
.b:     clrb
.s:     ldx  #ob_lim
        abx
        ldaa 0,x
        ldx  #kv_anim
        abx
        cmpa 0,x
        bhi  .in
        clr  0,x
.in:    incb
        cmpb #8
        bne  .s
        clr  kv_pkok
        bra  ob_start
ob_lim: fcb  3,2,3,2,4,2,3,2     ; kv_anim .. kv_idle: how many choices

; B_NEW: a new player: 1,000 credits, line bet 1, the default settings,
; the statistics cleared (the random state is kept)
ob_new: clr  kv_pkok
        ldd  kv_rng             ; (kept: from the clock at start-up)
        std  ob_t
        ldd  kv_rng+2
        std  ob_t+2
        ldx  #sv_first
.z:     clr  0,x
        inx
        cpx  #sv_end
        bne  .z
        ldd  ob_t
        std  kv_rng
        ldd  ob_t+2
        std  kv_rng+2
        ldd  #1000
        jsr  set32
        ldd  kv_n32+2
        std  kv_bal+2
        ldaa #2
        staa kv_anim            ; Full
        staa kv_glass           ; 12 frames a second
        bsr  ob_save
; the screen to start from: credits shown, a grid of symbols
ob_start:
        ldd  kv_bal
        std  kv_dbal
        ldd  kv_bal+2
        std  kv_dbal+2
        clra
        clrb
        std  kv_dwin
        std  kv_dwin+2
        ldx  #20
        stx  T0
        ldx  #ob_grid
        ldd  #kv_grid
        os   UT$CPYB
        clr  kv_santa
        clra                    ; (as a command entry: back to the reels)
        rts
ob_grid: fcb 0,5,1,7, 4,2,6,3, 1,7,0,5, 6,3,4,2, 2,0,5,6

; open A:SANSAV at its first record: carry set if there is none
sv_open:
        clr  kv_pkok            ; (the file services select A:)
        ldx  #fn_sav
        os   FL$OPEN
        bcs  .x
        tab
        os   FL$RECT
        clra
        clrb
        os   FL$SETP
        ldd  #1
        os   FL$RSET
.x:     rts
fn_sav: fcl  "A:SANSAV"

; B = the checksum of the saved bytes
sv_sum: ldx  #sv_first
        clrb
.l:     addb 0,x
        inx
        cpx  #sv_end
        bne  .l
        rts

; B_SAVE: the record written over the old one
ob_save:
        ldaa #SV_LEN+3
        staa sv_rec
        ldd  #'S'*256+SV_VER
        std  sv_tag
        bsr  sv_sum
        stab sv_chk
        bsr  sv_open
        bcc  .old
        ldx  #fn_sav            ; no file yet
        os   FL$CRET
        bcs  .x
        tab
        os   FL$RECT
        bra  .w
.old:   os   FL$ERAS
.w:     ldx  #sv_rec
        os   FL$WRIT
.x:     clr  kv_pkok
        clra                    ; (as a command entry: back to the reels)
        rts

; ---------------------------------------------------------------------
; B_STAKE: 20 line bets taken. Carry set if not: then A = 1 the bet was
; lowered to one the credits cover (said on the panel), or 2 the credits
; were topped up by 500 (too few for any bet).
; ---------------------------------------------------------------------
ob_stake:
        jsr  stake
        ldx  #kv_bal
        jsr  sub32
        bcc  .ok
        jsr  add32              ; short: put it back
.low:   tst  kv_bet             ; a smaller bet?
        beq  .top
        dec  kv_bet
        jsr  stake
        ldx  #kv_bal
        jsr  sub32
        bcs  .sh
        jsr  add32              ; (it fits: only looked)
        jsr  pn_bet
        ldx  #ob_low
        jsr  pn_msg
        bsr  ob_save
        ldaa #1
        sec
        rts
.sh:    jsr  add32
        bra  .low
.top:   ldd  #500               ; Santa's top-up
        jsr  set32
        ldx  #kv_bal
        jsr  add32
        ldx  #st_topups
        bsr  inc16
        bsr  ob_save
        ldaa #2
        sec
        rts
.ok:    clr  kv_gok
        ldx  #st_staked         ; counted (kv_n32 is the stake)
        jsr  add32
        ldx  #st_spins
        bsr  inc32
        ldd  kv_bal             ; the credits shown go down by it too
        std  kv_dbal
        ldd  kv_bal+2
        std  kv_dbal+2
        clra
        clrb
        std  kv_dwin
        std  kv_dwin+2
        clr  kv_screq
        jsr  pn_cr
        jsr  pn_bet
        ldx  #ob_none
        jsr  pn_msg
        clc
        rts
ob_low: fcl  "BET LOWER"
ob_none: fcb 0

; X += 1 (32 bits) / X += 1 (16 bits)
inc32:  pshx
        ldd  #1
        jsr  set32              ; (it sets X to kv_n32)
        pulx
        jmp  add32
inc16:  ldd  0,x
        addd #1
        std  0,x
        rts

; ---------------------------------------------------------------------
; B_SETTLE: the win paid; the statistics; saved
; ---------------------------------------------------------------------
ob_settle:
        ldd  kv_win
        std  kv_n32
        ldd  kv_win+2
        std  kv_n32+2
        ldx  #kv_bal
        jsr  add32
        ldx  #st_paid
        jsr  add32
        ldx  #st_big            ; the biggest: big - win borrows?
        ldd  2,x
        subd kv_win+2
        ldd  0,x
        sbcb kv_win+1
        sbca kv_win
        bcc  .b
        ldd  kv_win
        std  0,x
        ldd  kv_win+2
        std  2,x
.b:     clr  kv_gok             ; a base win (no feature) may be gambled
        tst  kv_fn
        bne  .g
        ldd  kv_win
        bne  .gk
        ldd  kv_win+2
        beq  .g
.gk:    inc  kv_gok
.g:     ldaa kv_runn            ; the session record: the run of paying spins
        ldab kv_win+3
        orab kv_win+2
        orab kv_win+1
        orab kv_win
        bne  .rn
        clra
        bra  .rs
.rn:    inca
        beq  .rs                ; (255 at most)
        cmpa st_run
        bls  .rs
        staa st_run
.rs:    staa kv_runn
        ldx  #st_bestb          ; the best balance: best - bal borrows?
        ldd  2,x
        subd kv_bal+2
        ldd  0,x
        sbcb kv_bal+1
        sbca kv_bal
        bcc  .hb
        ldd  kv_bal
        std  0,x
        ldd  kv_bal+2
        std  2,x
.hb:    inc  kv_snow            ; snow settles a little each spin
        bne  .h
        dec  kv_snow
.h:     tst  kv_santa           ; the most houses in one delivery
        beq  .f
        clrb
        ldx  #kv_grid+4
.hc:    ldaa 0,x
        cmpa #8
        bne  .hn
        incb
.hn:    inx
        cpx  #kv_grid+20
        bne  .hc
        cmpb st_mosth
        bls  .g2
        stab st_mosth
.g2:    tst  kv_santa
        beq  .f
        ldx  #st_santa
        bsr  inc16
.f:     tst  kv_fn
        beq  .s
        ldx  #st_feats
        bsr  inc16
.s:     jmp  ob_save

; B = 0-7: A = 1 << B
ob_bit: ldaa #1
        tstb
        beq  .x
.l:     asla
        decb
        bne  .l
.x:     rts
ob_t:   rmb  4
