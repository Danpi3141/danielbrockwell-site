; =====================================================================
; OV_SPINFX: the spin, played to the result already drawn (kv_grid).
; Three drums (glyphs 4, 5, 6: reels 1 and 4 share A, 2 and 5 B, 3 has
; C) turn a few dots out of step; each reel stops from its top row down,
; the lander (glyph 7) sliding each row's symbol in; a thunk rising from
; reel 1 to reel 5. Santa drops into reel 1 whole. With two stars down
; the remaining reels turn a second longer each, inverted, to a
; heartbeat. Quick: the reels stop 0.1 s apart; Off: the symbols appear.
; EXE stops every reel at once, in a fast cascade.
; Entries: 0 a base spin, 1 a free spin (Santa already on reel 1).
; =====================================================================
        include "../defs.inc"

FT      = 4                     ; a frame: 4 ticks (30 a second)
A_RIB   = 0                     ; art in the SPIN blob: the ribbon,
A_RIBI  = 3                     ; the inverted ribbon, the font's symbols
A_FONT  = 6
E_HANDLE = 0                    ; effects in the blob
E_TICK  = 2
E_HEART = 4
E_STAR  = 5
E_SLEIGH = 6
E_GOTIT = 7

        jmp  sf_base
        jmp  sf_free

sf_base:
        clr  sf_fr
        bra  sf_go
sf_free:
        ldaa #1
        staa sf_fr
sf_go:  ldaa #IT_PICS           ; the pictures as they were (a delivery made
        ldx  #kv_glyph          ; the house a present)
        jsr  pk_load
        ldaa kv_gdirty
        oraa #$0F
        staa kv_gdirty
        ldaa #IT_SPIN           ; the blob
        clr  kv_tnt             ; (no tune: its data may cover the tune buffer)
        ldx  #sf_data
        stx  kv_scene
        jsr  pk_load
        ldx  #sf_t              ; sf_t, sf_one, sf_inv, sf_fast, sf_stars
        ldab #5
.z:     clr  0,x
        inx
        decb
        bne  .z
        ldaa #$FF
        staa sf_cur
        clr  sf_next
        ldaa kv_anim            ; the pace: the setting (autoplay too)
        staa sf_pace
        clrb                    ; every reel turning; their stop times:
.s:     ldx  #sf_st             ; Full frame 21 + 10 r, Quick 6 + 3 r
        abx
        clr  0,x
        pshb
        ldaa sf_pace
        cmpa #2
        beq  .full
        ldaa #3
        mul
        addb #6
        bra  .at
.full:  ldaa #10
        mul
        addb #21
.at:    tba
        pulb
        ldx  #sf_at
        abx
        staa 0,x
        incb
        cmpb #5
        bne  .s
.sd:    ldd  #$0008             ; the drums out of step
        std  sf_d
        ldaa #16
        staa sf_d+2
        tst  kv_anim
        bne  .anim
        jmp  sf_show            ; Off: the symbols at once
.anim:  tst  sf_fr
        beq  .b
        jsr  sf_santa           ; a free spin: Santa stands on reel 1 already
        ldaa #2
        staa sf_st
        inc  sf_next
.b:     ldab #4                 ; every turning reel's cells to its drum
.dr:    pshb
        jsr  sf_rdrum
        pulb
        decb
        bpl  .dr
        ldaa #E_HANDLE
        jsr  sf_fx

; ---- the frames ----
sf_loop:
        jsr  sf_drums
        ldaa sf_cur             ; a reel landing?
        cmpa #$FF
        bne  .land
        ldab sf_next            ; the next one's time?
        cmpb #5
        beq  .tw
        ldx  #sf_at
        abx
        ldaa sf_t
        cmpa 0,x
        blo  .tw
        stab sf_cur
        clr  sf_row
        clr  sf_ph
        tstb
        bne  .land
        tst  sf_fr
        bne  .land
        tst  kv_santa
        beq  .land
        jsr  sf_drop            ; Santa drops in (four frames of his own)
        bra  .done
.land:  jsr  sf_step
.done:  ldaa sf_cur             ; all down?
        cmpa #$FF
        bne  .tw
        ldaa sf_next
        cmpa #5
        beq  sf_end
.tw:    tst  sf_inv             ; stars down twinkle
        beq  .fr
        jsr  sf_twinkle
        tst  kv_fxt             ; the heartbeat goes on
        bne  .fr
        ldaa #E_HEART
        jsr  sf_fx
.fr:    ldaa #FT
        tst  sf_fast
        beq  .ft
        ldaa #2
.ft:    jsr  frame
        inc  sf_t
        ldab kv_key             ; EXE: every reel stops now
        cmpb #K_EXE
        bne  sf_loop
        os   KB$GETK
        ldaa #1
        staa sf_fast
        clr  sf_inv
        ldx  #sf_at
        ldaa sf_t
.q:     staa 0,x
        inx
        cpx  #sf_at+5
        bne  .q
        bra  sf_loop
sf_end: tst  sf_fr              ; a base spin that starts the Xmas Spins:
        bne  .f                 ; its stars flash to a chime (0.8 s)
        tst  kv_fn
        beq  .f
        ldaa #E_GOTIT
        jsr  sf_fx
        ldab #8
.l:     pshb
        ldaa #'*'               ; off, on, ... on
        bitb #1
        bne  .c
        ldaa #' '
.c:     staa sf_c
        jsr  sf_stc
        ldaa #12
        jsr  frame
        pulb
        decb
        bne  .l
.f:     jmp  flush             ; the last reel's last symbol shown now (not when
                                ; the next overlay draws, a fifth of a second on)

; sf_show: every reel's symbols at once (and Santa)
sf_show:
        clr  sf_r
.r:     tst  sf_r
        bne  .n
        tst  kv_santa
        beq  .n
        jsr  sf_santa
        bra  .x
.n:     clr  sf_row
.y:     jsr  sf_place
        inc  sf_row
        ldaa sf_row
        cmpa kv_rows
        bne  .y
.x:     inc  sf_r
        ldaa sf_r
        cmpa #5
        bne  .r
        jmp  flush              ; (shown now, as sf_end)

; ---- the drums: turned by the speed, their glyphs built ----
sf_drums:
        ldaa #1                 ; speed: 1, 2, then 4 dots a frame
        ldab sf_t
        cmpb #3
        blo  .v
        inca
        cmpb #8
        blo  .v
        ldaa #4
.v:     staa sf_v
        clr  sf_k
.k:     ldx  #sf_d
        ldab sf_k
        abx
        ldaa 0,x                ; offset - speed, mod 24
        suba sf_v
        bpl  .p
        adda #24
.p:     staa 0,x
        ldab sf_k               ; glyph 4 + k, unless Santa holds it
        cmpb #2
        beq  .g
        tst  sf_one
        bne  .nx
.g:     staa sf_o
        ldaa #A_RIB             ; the ribbon's 24 rows (inverted in anticipation)
        tst  sf_inv
        beq  .rb
        ldaa #A_RIBI
.rb:    ldab #2
        jsr  sc_tab             ; X = the ribbon
        stx  sf_rib
        ldab sf_k
        addb #4
        aslb
        aslb
        aslb
        ldx  #kv_glyph
        abx
        stx  sf_dst
        ldab #8
.row:   pshb
        ldx  sf_rib
        ldab sf_o
        abx
        ldaa 0,x
        ldx  sf_dst
        staa 0,x
        inx
        stx  sf_dst
        inc  sf_o
        ldaa sf_o
        cmpa #24
        bne  .w
        clr  sf_o
.w:     pulb
        decb
        bne  .row
        ldab sf_k
        addb #4
        jsr  gbit
        oraa kv_gdirty
        staa kv_gdirty
.nx:    inc  sf_k
        ldaa sf_k
        cmpa #3
        bne  .k
        rts

; B = reel: its cells to its drum, if it is turning
sf_rdrum:
        ldx  #sf_st
        abx
        tst  0,x
        bne  .x
        stab sf_r
        ldx  #sf_drum
        abx
        ldaa 0,x
        tst  sf_one             ; (with Santa down, or in free spins, drum C only)
        bne  .c
        tst  sf_fr
        beq  .d
.c:     ldaa #6
.d:     staa sf_c
        clr  sf_row
.y:     jsr  sf_cell
        ldaa sf_c
        jsr  put
        inc  sf_row
        ldaa sf_row
        cmpa kv_rows
        bne  .y
.x:     rts
sf_drum: fcb 4,5,6,4,5

; ---- a reel landing: one step a frame ----
sf_step:
        ldaa sf_cur
        staa sf_r
        ldaa sf_ph
        bne  .p
        jsr  sf_cell            ; phase 0: the row's cell becomes the lander,
        ldaa #7                 ; 4 rows of its symbol in
        jsr  put
        ldab #4
        bra  .lg
.p:     cmpa #1
        bne  .r
        ldab #7                 ; phase 1: 7 rows
.lg:    jsr  sf_lander
        tst  sf_fast            ; (fast: straight to the symbol)
        bne  .r
        inc  sf_ph
        rts
.r:     jsr  sf_place           ; the symbol at rest, a tick
        clr  sf_ph
        ldaa #E_TICK
        jsr  sf_fx
        inc  sf_row
        ldaa sf_row
        cmpa kv_rows
        bne  .x
        ldab sf_cur             ; the reel is down: its thunk
        ldx  #sf_st
        abx
        ldaa #2
        staa 0,x
        jsr  sf_thunk
        ldaa #$FF
        staa sf_cur
        inc  sf_next
        jsr  sf_count           ; stars
.x:     rts

; sf_cell: B = the cell of reel sf_r, row sf_row
sf_cell:
        ldaa sf_r
        ldx  #kv_reelx
        tab
        abx
        ldaa sf_row
        ldab kv_w
        mul
        addb 0,x
        rts

; sf_sym: A = the symbol at reel sf_r, row sf_row
sf_sym: ldaa sf_r
        asla
        asla
        adda sf_row
        tab
        ldx  #kv_grid
        abx
        ldaa 0,x
        rts

; sf_place: the symbol shown at rest in its cell
sf_place:
        bsr  sf_sym
        tab
        ldx  #sf_chr
        abx
        ldaa 0,x
        psha
        bsr  sf_cell
        pula
        jmp  put
sf_chr: fcb  0,1,2,'@','A','K','Q','J',3,' ','*'

; sf_lander: B = rows: glyph 7 = the bottom B rows of the symbol, from
; the top
sf_lander:
        stab sf_v2
        bsr  sf_sym
        cmpa #4                 ; a picture: from kv_glyph; else the font art
        bhs  .f
        cmpa #3
        beq  .f
        ldab #8
        mul
        addd #kv_glyph
        xgdx
        bra  .g
.f:     cmpa #8
        bne  .nh
        ldx  #kv_glyph+24       ; the house: glyph 3
        bra  .g
.nh:    ldab #A_FONT+5          ; star
        cmpa #10
        beq  .fa
        tab                     ; wreath 3 .. J 7: A_FONT + 0 .. 4
        subb #3
        addb #A_FONT
.fa:    tba
        ldab #2
        jsr  sc_tab
.g:     ldab #8                 ; the source's last B rows
        subb sf_v2
        abx
        stx  sf_rib
        ldab #8
        bsr  sf_clr
        ldab sf_v2
        bsr  sf_copy
        ldaa #7
        ldx  #sf_buf
        jmp  glyph_ld

; sf_clr: B bytes of sf_buf cleared; sf_dst = sf_buf
sf_clr: ldx  #sf_buf
        stx  sf_dst
.c:     clr  0,x
        inx
        decb
        bne  .c
        rts
; sf_copy: B bytes from sf_rib on to sf_dst on
sf_copy:
.l:     pshb
        ldx  sf_rib
        ldaa 0,x
        inx
        stx  sf_rib
        ldx  sf_dst
        staa 0,x
        inx
        stx  sf_dst
        pulb
        decb
        bne  .l
        rts

; ---- Santa ----
; sf_santa: Santa standing in reel 1 (glyphs 4 and 5)
sf_santa:
        clra
        bsr  sf_spose
        jmp  sf_scells
; sf_drop: Santa drops in from the top over four frames, sleigh bells
sf_drop:
        ldaa #E_SLEIGH
        jsr  sf_fx
        inc  sf_one             ; the other reels to drum C
        ldab #4
.r:     pshb
        jsr  sf_rdrum
        pulb
        decb
        bne  .r
        jsr  sf_scells
        ldaa #12
.f:     psha
        bsr  sf_spose
        ldaa #FT
        jsr  frame
        inc  sf_t
        jsr  sf_drums
        pula
        suba #4
        bpl  .f
        ldaa #2
        staa sf_st
        inc  sf_next
        ldaa #$FF
        staa sf_cur
        rts
; A = rows down (0-12): glyphs 4, 5 = the standing pose that far down
sf_spose:
        staa sf_v2
        ldab #16
        bsr  sf_clr
        clra                    ; pose 0 (STAND), unpacked
        clrb
        jsr  sc_tab
        jsr  pose_unpack
        ldx  #kv_pose
        stx  sf_rib
        ldab sf_v2
        ldx  sf_dst
        abx
        stx  sf_dst
        ldab #16
        subb sf_v2
        bsr  sf_copy
        ldaa #4
        ldx  #sf_buf
        jsr  glyph_ld
        ldaa #5
        ldx  #sf_buf+8
        jmp  glyph_ld
; reel 1's cells: Santa (4 over 5); on four lines on rows 2-3, a + above
; and below
sf_scells:
        clrb
        tst  kv_four
        beq  .t
        ldaa #'+'
        jsr  put
        ldaa #'+'
        ldab #60
        jsr  put
        ldab #20
.t:     ldaa #4
        pshb
        jsr  put
        pulb
        addb kv_w
        ldaa #5
        jmp  put

; ---- stars, anticipation, sounds ----
; sf_count: the stars on the reels down; two, with reels still to come
; (a base spin, Full): anticipation
sf_count:
        ldab sf_next            ; the reel just down: sf_next - 1
        decb
        stab sf_r
        clr  sf_row
.y:     jsr  sf_sym
        cmpa #10
        bne  .n
        inc  sf_stars
        ldaa #E_STAR
        jsr  sf_fx
.n:     inc  sf_row
        ldaa sf_row
        cmpa kv_rows
        bne  .y
        ldaa sf_stars
        cmpa #2
        bne  .x
        tst  sf_inv
        bne  .x
        tst  sf_fr
        bne  .x
        ldaa sf_pace
        cmpa #2
        bne  .x
        ldaa sf_next
        cmpa #5
        beq  .x
        inc  sf_inv             ; each reel to come: a second (30 frames) more
        ldab sf_next
        ldx  #sf_at
        abx
        ldaa #30
.l:     psha
        adda 0,x
        staa 0,x
        pula
        adda #30
        inx
        cpx  #sf_at+5
        bne  .l
.x:     rts

; the stars down twinkle: *, +, x in turn (the landing reel's row kept)
sf_twinkle:
        ldaa sf_row
        psha
        bsr  .go
        pula
        staa sf_row
        rts
.go:    ldaa sf_t
        lsra
        lsra
.m:     cmpa #3
        blo  .k
        suba #3
        bra  .m
.k:     tab
        ldx  #sf_tw
        abx
        ldaa 0,x
        staa sf_c
; sf_stc: sf_c in every star cell of the reels down
sf_stc: clr  sf_r
.r:     ldx  #sf_st
        ldab sf_r
        abx
        ldaa 0,x
        cmpa #2
        bne  .nr
        clr  sf_row
.y:     jsr  sf_sym
        cmpa #10
        bne  .ny
        jsr  sf_cell
        ldaa sf_c
        jsr  put
.ny:    inc  sf_row
        ldaa sf_row
        cmpa kv_rows
        bne  .y
.nr:    inc  sf_r
        ldaa sf_r
        cmpa #5
        bne  .r
        rts
sf_tw:  fcb  '*','+','x'

; the reel's thunk: a low note rising from reel 1 to 5, then a dull noise
sf_thunk:
        ldaa sf_cur
        ldab #3
        mul
        addb #5                 ; A5 .. D6
        stab sf_th+2
        ldx  #sf_th
        jmp  snd_fx
sf_th:  fcb  1,3,0,2, 4,3,50, $FF

; A = an effect of the blob: started
sf_fx:  ldab #6
        jsr  sc_tab
        jmp  snd_fx

; the overlay's variables
sf_fr:  fcb  0                  ; a free spin
sf_pace: fcb 0                  ; 2 Full, 1 Quick
sf_t:   fcb  0                  ; the frame (these five in a row: sf_go clears them)
sf_one: fcb  0                  ; Santa is down: one drum
sf_inv: fcb  0                  ; anticipation
sf_fast: fcb 0                  ; EXE: every reel now
sf_stars: fcb 0
sf_cur: fcb  0                  ; the reel landing ($FF none)
sf_next: fcb 0                  ; the next reel to land
sf_row: fcb  0
sf_ph:  fcb  0
sf_r:   fcb  0
sf_c:   fcb  0
sf_k:   fcb  0
sf_v:   fcb  0
sf_v2:  fcb  0
sf_o:   fcb  0
sf_rib: fdb  0
sf_dst: fdb  0
sf_d:   rmb  3                  ; the drums' offsets
sf_st:  rmb  5                  ; each reel: 0 turning, 2 down
sf_at:  rmb  5                  ; the frame each starts to land
sf_buf: rmb  16
sf_data:                        ; the blob, read in here
