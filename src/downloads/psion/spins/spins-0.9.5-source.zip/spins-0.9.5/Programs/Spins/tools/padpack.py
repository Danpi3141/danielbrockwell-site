#!/usr/bin/env python3
"""A test pack: the game, plus PAD (a padding array of N words, then SANTA) - for tests/m_mem.js.
    python tools/padpack.py N out.opk
With PADSANTA=nocheck, SANTA's memory check always passes (its numbers 300 and 300: the same code
shape, so the variables kept in its code stay where they are) - for tests/m_mem2.js."""
import re
import os
import sys
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import pack  # noqa: E402

n, out = int(sys.argv[1]), sys.argv[2]
g = os.path.join(ROOT, 'build', 'game')
src_dir = os.path.splitext(os.path.abspath(out))[0] + '_src'     # (one each: trials may run at once)
os.makedirs(src_dir, exist_ok=True)
pad = os.path.join(src_dir, 'PAD.opl')
with open(pad, 'w', encoding='latin-1', newline='\n') as f:
    f.write('PAD:\nLOCAL p%%(%d)\n%s:\n' % (max(1, n), os.environ.get('PADCALL', 'SANTA')))
img = pack.PackImage('datapak', 32, target='cm')
santa = os.path.join(g, 'SANTA.opl')
if os.environ.get('PADSANTA') == 'nocheck':
    src = open(santa, encoding='latin-1').read()
    src, n = re.subn(r'n%=\d+\+\d+\*EXIST', 'n%=300+300*EXIST', src)
    assert n == 1
    santa = os.path.join(src_dir, 'SANTA.opl')
    with open(santa, 'w', encoding='latin-1', newline='\n') as f:
        f.write(src)
img.add_opl(santa)
img.add_opl(os.path.join(g, 'SANTAG.opl'))
img.add_data('SANM', open(os.path.join(g, 'sank.bin'), 'rb').read())
img.add_opl(pad)
img.write(out)
