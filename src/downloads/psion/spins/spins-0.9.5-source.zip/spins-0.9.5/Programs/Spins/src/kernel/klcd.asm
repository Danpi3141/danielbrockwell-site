; ---------------------------------------------------------------------
; The screen model. kv_under[] holds the character every cell should
; show (kv_ncell cells, kv_w a line); kv_shown[] (right after it, at
; +SHOWN) what the LCD shows. kv_glyph holds the 8 defined characters
; (8 rows each, the dots in bits 4-0), kv_gdirty the ones not yet sent.
; flush sends what changed straight to the display controller.
; ---------------------------------------------------------------------
SHOWN   = 80                    ; kv_shown - kv_under

; B = a command to the display controller
lcd_cmd: ldaa LCD_CTRL
        bmi  lcd_cmd
        stab LCD_CTRL
        rts
; B = a byte of data
lcd_dat: ldaa LCD_CTRL
        bmi  lcd_dat
        stab LCD_DATA
        rts

; flush: the dirty glyphs, then every cell that differs from the LCD
flush:  jsr  almchk
        ldaa kv_gdirty
        beq  .cells
        clr  kv_gdirty
        staa kv_t0
        ldab #$40               ; CGRAM address 0
        ldx  #kv_glyph
.g:     lsr  kv_t0
        bcc  .gn
        pshb
        jsr  lcd_cmd            ; this glyph's address
        ldaa #8
        staa kv_t1
.gl:    ldab 0,x
        inx
        jsr  lcd_dat
        dec  kv_t1
        bne  .gl
        pulb
        bra  .gx
.gn:    pshb                    ; (skipped: on 8)
        ldab #8
        abx
        pulb
.gx:    addb #8
        tst  kv_t0
        bne  .g
        ldab #$80               ; back to the display memory (the emulator, and
        jsr  lcd_cmd            ; maybe the controller, takes no address with it)
        ldaa #$FF               ; the DDRAM address is unknown now
        staa kv_next
.cells: tst  kv_cdirty
        beq  .x
        clr  kv_cdirty
        ldx  #kv_under
.c:     ldaa 0,x
        cmpa SHOWN,x
        bne  .ch
.cn:    inx
        cpx  kv_cend
        bne  .c
.x:     rts
.ch:    staa SHOWN,x
        stx  kv_t2
        xgdx
        subd #kv_under          ; B = the cell's index
        tba
        jsr  DRV+DV_ADDR        ; A = its DDRAM address
        cmpa kv_next
        beq  .same
        staa kv_next
        tab
        orab #$80
        jsr  lcd_cmd
.same:  inc  kv_next
        ldx  kv_t2
        ldab 0,x
        jsr  lcd_dat
        bra  .cn

; almchk: once a minute, a second or more into it, as redraw. An alarm that
; rings puts back the OS's copy of the screen, which is not the game's; they
; ring on the minute, at the first tick, for up to 59 seconds (inside the
; OS's interrupt, so nothing here runs meanwhile).
almchk: ldd  TMB_MIN            ; A the minute, B the second
        cmpa kv_min
        beq  rd_x
        tstb
        beq  rd_x
        staa kv_min
; redraw: everything sent again at the next flush (after switching on)
redraw: ldx  #kv_under
.l:     ldaa 0,x
        coma
        staa SHOWN,x
        inx
        cpx  #kv_under+SHOWN
        bne  .l
        ldaa #$FF
        staa kv_gdirty
        staa kv_cdirty
rd_x:   rts

; cls: every cell a space
cls:    ldx  #kv_under
        ldaa #' '
.l:     staa 0,x
        inx
        cpx  kv_cend
        bne  .l
        inc  kv_cdirty
        rts

; put: A = character, B = cell index
put:    ldx  #kv_under
        abx
        staa 0,x
        inc  kv_cdirty
        rts

; glyph_ld: A = glyph (0-7), X = 8 rows: copied in, marked dirty
glyph_ld:
        pshx
        tab
        bsr  gbit
        oraa kv_gdirty
        staa kv_gdirty
        ldaa #8
        mul
        addd #kv_glyph          ; D = where, X = from, T0 = 8 bytes
        ldx  #8
        stx  T0
        pulx
        os   UT$CPYB
        rts

; gbit: B = glyph number: A = its bit (1 << B); B kept
gbit:   ldaa #1
        pshb
        tstb
        beq  .x
.l:     asla
        decb
        bne  .l
.x:     pulb
        rts
