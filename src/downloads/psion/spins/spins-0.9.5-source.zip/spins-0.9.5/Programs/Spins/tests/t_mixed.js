'use strict';
// Two versions on two packs (24 Nov): the launcher looks for its kernel block on C:, then B:, then A:, so another version
// on another pack could be loaded (in Chess that stopped a real Organiser with TRAP 0007 7E80). Each block now starts with
// the build's number, which the bootstrap checks, and the kernel block has a new name. Every start must load its own kernel
// or say that its files are not there.
//   node tests/t_mixed.js [rom...]
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');
const { Machine } = require(path.join(ROOT, 'tools', 'emu'));
const RUN = 'SANTA', OPK = path.join(ROOT, 'build', 'game', 'SPINS.opk'), BLOCK = 'SANM', TAG = 'SPK1', DATA = [];
const OLDDIR = path.join(__dirname, 'old');
const ROMS = { '33-cm.rom': 8, '24-cm.rom': 8, '31-xp.rom': 16, '36-la.rom': 32, '46-lz.rom': 32, '46a-lz64.rom': 64 };
const TMP = path.join(require('os').tmpdir(), 'mixed_Spins_' + process.pid);
fs.mkdirSync(TMP, { recursive: true });
let fails = 0;
const ok = (c, m) => { if (!c) fails++; console.log((c ? 'ok   ' : 'FAIL ') + m); };
const bytes = (s) => [...Buffer.from(s, 'latin1')];

// the pack with the kernel's tag changed (so it can be told from the real one once it is in RAM) and, for id, the build's
// number of the blocks named: the file's name (8 and a 0), the long record's header (4), the object length (2), the stub (14)
const XTAG = TAG.slice(0, 3) + 'X';
function variant(name, tag, blocks) {
  const d = fs.readFileSync(OPK);
  for (const b of blocks) {
    const at = d.indexOf(Buffer.from(b.padEnd(8) + '\0', 'latin1'));
    if (at < 0) throw new Error('no block ' + b);
    d[at + 29] ^= 0x15;
  }
  if (tag) {
    const at = d.indexOf(Buffer.from(TAG, 'latin1'), d.indexOf(Buffer.from(BLOCK.padEnd(8), 'latin1')));
    if (at < 0) throw new Error('no tag');
    d.write(XTAG, at, 'latin1');
  }
  const p = path.join(TMP, 'mixed_' + name + '.opk');
  fs.writeFileSync(p, d);
  return p;
}
const OTHER = variant('other', true, [BLOCK]);          // another build
const SAME = variant('same', true, []);                 // this build's number, its tag changed: what a start from it looks like
const olds = fs.existsSync(OLDDIR) ? fs.readdirSync(OLDDIR).filter((f) => f.endsWith('.opk')) : [];

// what is in RAM after starting RUN from dev with packs b and c
function start(rom, b, c, dev) {
  const m = new Machine({ rom, ram: ROMS[rom] });
  m.boot();
  if (b) m.insertPack(b, 0);
  if (c) m.insertPack(c, 1);
  let low = false;
  m.dbg.setTrace((pc) => { if (pc < 0x40) low = true; });
  m.runProc(RUN, dev);
  m.runSeconds(8);
  m.dbg.setTrace(null);
  const hi = m.lines === 4 ? 0x8000 : 0x2000 + (ROMS[rom] << 10);
  const has = (t) => m.find(bytes(t), 0x2000, Math.min(hi, 0xFFFF)) >= 0;
  const msg = m.screenText().replace(/\s+/g, ' ').trim();
  return { own: has(TAG), other: has(XTAG), low, msg };
}
const say = (r) => `${r.low ? 'CRASHED ' : ''}${r.own ? 'its own kernel' : r.other ? 'the OTHER kernel' : 'no kernel'} "${r.msg.slice(0, 24)}"`;
for (const rom of process.argv.slice(2).length ? process.argv.slice(2) : Object.keys(ROMS)) {
  try {
    let r = start(rom, OPK, null, 'B');
    ok(r.own && !r.low, `${rom} alone in B: ${say(r)}`);
    r = start(rom, null, OPK, 'C');
    ok(r.own && !r.low, `${rom} alone in C: ${say(r)}`);
    r = start(rom, OPK, OTHER, 'B');
    ok(r.own && !r.other && !r.low, `${rom} run from B:, another build in C: ${say(r)}`);
    r = start(rom, OTHER, OPK, 'C');
    ok(r.own && !r.other && !r.low, `${rom} run from C:, another build in B: ${say(r)}`);
    r = start(rom, OPK, OPK, 'B');
    ok(r.own && !r.low, `${rom} the same build in both: ${say(r)}`);
    r = start(rom, OPK, SAME, 'B');
    ok(r.other && !r.low, `${rom} (control) the same build's number in C: is taken first: ${say(r)}`);
    r = start(rom, OTHER, null, 'B');
    ok(!r.own && !r.other && !r.low, `${rom} only another build's data: ${say(r)}`);
    for (const d of DATA) {
      r = start(rom, variant('d' + d, false, [d]), null, 'B');
      ok(!r.low && (d === DATA[0] ? !/^.{0,3}$/.test(r.msg) : r.own), `${rom} another build's ${d}: ${say(r)}`);
    }
    for (const f of olds) {                              // the released versions, whose launchers have no such check
      const O = path.join(OLDDIR, f);
      r = start(rom, OPK, O, 'B');
      ok(r.own && !r.low, `${rom} run from B:, ${f} in C: ${say(r)}`);
      r = start(rom, O, OPK, 'C');
      ok(r.own && !r.low, `${rom} run from C:, ${f} in B: ${say(r)}`);
      const a = start(rom, O, null, 'B'), b = start(rom, O, OPK, 'B');
      ok(b.own === a.own && !b.low && a.msg === b.msg, `${rom} ${f} run from B:, the new one in C: as it is alone: ${say(b)}`);
    }
  } catch (e) { ok(false, rom + ' ' + e.message.split('\n')[0]); }
}
console.log(fails ? fails + ' failures' : 'all mixed-version tests passed');
process.exit(fails ? 1 : 0);
