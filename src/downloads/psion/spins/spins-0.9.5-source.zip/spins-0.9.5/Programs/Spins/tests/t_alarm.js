// An alarm rings while the game runs (25 Nov 2026, version 0.9.5). The OS rings it inside its 50 ms interrupt, for as long
// as 59 seconds, and puts back its own copy of the screen: the game, which sends its screen straight to the display
// controller, stayed blank or garbled until 0.9.4. Now (almchk) what is on the LCD is the game's again within a second and
// a half, at the reels, in the menus and in the middle of a spin, a feature or a scene.
//   node tests/t_alarm.js [model ...]     (OLD=<another build's build/game>: that build)
'use strict';
const { Game } = require('./lib');
const ALARM = { four: [89, 0, 0, 0, 0, 5], two: [87, 0, 0, 0, 0, 1] };     // amt_tab: 00:00, once
let fails = 0;
const ok = (c, s) => { if (!c) fails++; console.log((c ? 'ok   ' : 'FAIL ') + s); };
const ringing = (m) => /ALARM/.test(m.screenText());

for (const model of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'xp', 'lz', 'lz64']) {
  const g = new Game(model, process.env.OLD ? { build: process.env.OLD } : {}), m = g.m, four = m.lines === 4;
  let s = 4711; const rnd = (n) => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s % n; };
  // the OS's alarm set up by hand: amt_tab, and the clock a moment before midnight
  const soon = () => { m.write(0x22F9, four ? ALARM.four : ALARM.two); m.write(0x20C5, [126, 10, 27, 23, 59, 58]); };
  const calm = () => { m.write(0x22F9, [0, 0, 0, 0, 0, 0]); };
  m.press('A', 3, 12); m.runSeconds(1); for (let i = 0; i < 3; i++) { m.press('EXE', 3, 12); m.runSeconds(0.5); }
  for (let i = 0; i < 6; i++) m.press('ON', 3, 10);
  m.runSeconds(1); calm();
  g.start();
  // what the LCD shows against what the game says it shows (kv_shown, the 8 characters), and nothing left to send
  const n = four ? 80 : 32;
  const whole = () => {
    const shown = m.read(g.addr('kv_shown'), n).join(), cells = m.cells().slice(0, n).join();
    const glyphs = m.read(g.addr('kv_glyph'), 64).map((v) => v & 31).join(), udg = [].concat(...m.udgs()).map((v) => v & 31).join();
    return shown === cells && glyphs === udg ? '' : (shown !== cells ? 'cells ' : '') + (glyphs !== udg ? 'characters' : '');
  };
  // at a moment when the game has just sent all it had to (a frame ends, or it waits)
  const settle = () => { m.runTo([g.addr('kw_idle'), g.addr('kw_tidle'), g.addr('fs_k') - 1, g.addr('snd_tick')], 921600 * 3); };
  let done = 0, bad = 0, before = 0; const kinds = {};
  const KEYS = ['EXE', 'EXE', 'EXE', 'EXE', 'A', 'P', 'L', 'S', 'G', 'MODE', 'UP', 'DOWN', 'EXE'];
  for (let i = 0; i < 40; i++) {
    calm(); m.write(0x20C5, [126, 10, 27, 12, 0, 5]);
    if (/FIND|Find/.test(m.screenText())) { m.runProc('SANTA', 'B'); m.runSeconds(6); g.sync(); }
    for (let k = 1 + rnd(3); k > 0; k--) { m.press(KEYS[rnd(KEYS.length)], 2, 2 + rnd(10)); }
    const waiting = rnd(2) === 0;
    if (waiting) m.runSeconds(6 + rnd(6));
    if (/FIND|Find|Leave/i.test(m.screenText())) { m.press('ON', 3, 6); continue; }
    m.pokew(0x7D, 0x200); m.poke(0x20C9, 30); m.runSeconds(1.5);
    settle(); if (whole()) before++;
    soon();
    for (let k = 0; k < 120 && !ringing(m); k++) m.runTicks(1);
    if (!ringing(m)) continue;
    const how = ['left to ring', 'dismissed', 'dismissed at once'][rnd(3)];
    if (how === 'left to ring') for (let k = 0; k < 80 && ringing(m); k++) m.runSeconds(1);
    else { if (how === 'dismissed') m.runSeconds(2 + rnd(3)); for (let k = 0; k < 10 && ringing(m); k++) { m.keyDown('ON'); for (let j = 0; j < 20 && ringing(m); j++) m.runTicks(1); m.keyUp('ON'); m.runTicks(2); } }
    if (ringing(m)) { ok(false, `${model}: the alarm would not stop`); break; }
    m.runSeconds(1.6); settle();
    let w = whole();
    for (let k = 0; k < 6 && w; k++) { m.runTicks(1); settle(); w = whole(); }        // (caught in the middle of a frame)
    done++; kinds[how + (waiting ? ', waiting' : ', in play')] = (kinds[how + (waiting ? ', waiting' : ', in play')] || 0) + 1;
    if (w) { bad++; if (bad < 4) console.log(`     ${how}, ${waiting ? 'waiting' : 'in play'}: ${w} differ: ${m.screenText().replace(/\n/g, '|')}`); }
  }
  ok(done > 15 && !bad, `${model}: ${done} alarms, the LCD the game's own again after ${done - bad} (${Object.entries(kinds).map(([k, v]) => v + ' ' + k).join('; ')}); already different before ${before}`);
}
console.log(fails ? fails + ' FAILED' : 't_alarm ok');
process.exit(fails ? 1 : 0);
