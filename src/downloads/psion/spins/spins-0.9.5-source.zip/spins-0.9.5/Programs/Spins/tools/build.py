#!/usr/bin/env python3
"""Builds Psion Spins: the kernel, the screen drivers and overlays, the data (art, scripts,
tunes, tables), the launchers and the pack image (a Datapak that runs on every model).

    python tools/build.py [--out build/game] [--psion]

The array m%() holds: kernel (code, variables) | screen driver (DRV) | slot A (one overlay)
| scene buffer (SCENE). See docs/design.md.
"""
import argparse
import json
import os
import sys
import zlib

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import asm   # noqa: E402
import pack  # noqa: E402
import art   # noqa: E402
import script  # noqa: E402

BAD_OPL = (0, 9, 10, 13)
LAUNCH_OVERHEAD = 257          # SANTAG beyond its array (tests/m_mem.js, m_mem2.js: the game ran with 516 bytes of padding called straight, 20 Nov)
SAVE_ROOM = 120                # A:SANSAV
SANTAG_FRAME_GAP = 22          # SANTAG's variables between the end of its object code and m%() (i%, a%,
                               # v%(), m%()'s count), as Connect 4's C4G and Reversi's REVG
SANTA_FRAME = 12               # SANTA's frame between the end of m%() and its QCode (as Reversi's REV)
                               # (tests/t_hidden.js checks both on every ROM)
TUNE_BUF = 121                 # the top of region R: the tune playing (the longest, HARK, is 121)
BLOB_MAX = 600                 # the largest blob allowed
# what each overlay reads in just after its own code (region R holds both): the items, room
# before them, and whether the tune buffer must stay clear above them (a tune plays meanwhile)
DATA_OF = {'OV_GAME': (['IT_TAB4', 'IT_TAB2'], 0, False), 'OV_SPINFX': (['IT_SPIN'], 0, False),
           'OV_WALK': (['IT_WALK%d' % i for i in range(10)], 0, True), 'OV_WINFX': (['IT_WINS'], 148, True),
           'OV_XFX': (['IT_XFX'], 0, True), 'OV_HOME': (['IT_HOME'], 0, True),
           'OV_SCENE': (['IT_S%02d' % i for i in range(14)], 0, True),
           'OV_PAYS': ([], 148, False), 'OV_TEST': (['IT_POSES'], 80, True)}
PACK_K = 32

# code units, in id order: the drivers first (ids 1 and 2: kpack.asm relies on it)
UNITS = [('DRV2', 'drv2.asm'), ('DRV4', 'drv4.asm'), ('OV_GAME', 'ov_game.asm'), ('OV_TEST', 'ov_test.asm'), ('OV_BANK', 'ov_bank.asm'),
         ('OV_REST', 'ov_rest.asm'), ('OV_SPINFX', 'ov_spinfx.asm'), ('OV_WALK', 'ov_walk.asm'), ('OV_HOME', 'ov_home.asm'),
         ('OV_WINFX', 'ov_winfx.asm'), ('OV_XFX', 'ov_xfx.asm'),
         ('OV_MENU', 'ov_menu.asm'), ('OV_SET', 'ov_set.asm'), ('OV_PAYS', 'ov_pays.asm'), ('OV_INFO', 'ov_info.asm'),
         ('OV_EXTRA', 'ov_extra.asm'), ('OV_IDLE', 'ov_idle.asm'), ('OV_SCENE', 'ov_scene.asm'),
         ('OV_GAMBLE', 'ov_gamble.asm')]
DRIVERS = ('DRV2', 'DRV4')


BLOBS = {}                     # blob -> its scripts' numbers (for ids.inc)


class BuildError(Exception):
    pass


def build_number(data):
    """The build's number, at the head of the data block and in the bootstrap, which passes over any other build's block
    (another version's on another pack: in Chess that stopped a real Organiser, 24 Nov). No byte an OPL string cannot hold."""
    k = 0
    while True:
        n = zlib.crc32(bytes(data) + bytes([k])) & 0xFFFF
        if not {n >> 8, n & 255} & {0, 9, 10, 13, 34}:
            return n
        k += 1


def encode_fixups(fix, kernel=False):
    """A fix-up list: its length in bytes (one byte), then steps, two a byte (the high nibble
    first): 1-15 on that far and fix the word there, 0 on 15 without a fix-up (also the pad)."""
    nib = []
    prev = 0
    for f in sorted(fix):
        d = f - prev
        if d < 1:
            raise BuildError('a fix-up at %d: steps start at 1' % f)
        while d > 15:
            nib.append(0)
            d -= 15
        nib.append(d)
        prev = f
    if len(nib) % 2:
        nib.append(0)
    out = bytes(nib[i] << 4 | nib[i + 1] for i in range(0, len(nib), 2))
    if len(out) > 255 and not kernel:
        raise BuildError('a fix-up list of %d bytes (its length is one byte)' % len(out))
    return bytes([len(out) & 255]) + out


def launcher_lines(boot, total):
    """SANTAG: makes the array, pokes the bootstrap into its top from one string, calls it."""
    lit = '"' + bytes(boot).decode('latin-1').replace('"', '""') + '"'
    if len('POKEB a%%+i%%,ASC(MID$(%s,i%%+1,1))' % lit) > 250:
        raise BuildError('the bootstrap no longer fits one string')
    words = (total + 1) // 2
    return ['SANTAG:', 'LOCAL m%%(%d),v%%(6),i%%,a%%' % words,
            'a%%=ADDR(m%%())+%d' % (total - len(boot)),
            'i%=0', 'DO', 'POKEB a%%+i%%,ASC(MID$(%s,i%%+1,1))' % lit, 'i%=i%+1', 'UNTIL i%%=%d' % len(boot),
            'v%%(1)=ADDR(m%%()) :v%%(2)=%d' % total,
            'i%=USR(a%,ADDR(v%()))',
            'IF i% :PRINT "SPINS ERROR ";i% :GET :ENDIF']


def santa_lines(needs):
    return ['SANTA:', 'LOCAL n%',
            'n%%=%d+%d*EXIST("A:SANSAV")-FREE' % (needs + SAVE_ROOM, SAVE_ROOM),
            'IF n%<=0 :SANTAG: :RETURN :ENDIF',
            'PRINT "SANTA NEEDS ";n% :PRINT "BYTES MORE RAM" :GET']


def opl_object(path):
    """A launcher's translated object code."""
    class A:
        no_translate = False
        target = 'cm'
        strip_indent = True
        encoding = 'latin-1'
    _, rec, _ = pack.opl2opk.opl_procedure(path, A, quiet=True)
    rec = bytes(rec)
    olen = rec[15] << 8 | rec[16]
    return rec[17:17 + olen]


def santag_hole(path, boot):
    """KH: SANTAG's QCode before its USR call, in RAM just below the array (offset, length).
    SANTAG stays loaded all game and its code before USR never runs again, so the kernel keeps
    variables there (src/kernel/kvars.inc); that includes its copy of the bootstrap string,
    which has run by then. Its code from USR on runs when the game ends: it stays."""
    obj = opl_object(path)
    qlen = obj[2] << 8 | obj[3]
    q = obj[len(obj) - qlen:]
    at = q.find(boot)
    if at < 0 or q.find(boot, at + 1) >= 0:
        raise BuildError('SANTAG: the bootstrap string is not once in its code')
    u = q.rfind(bytes([0x9F, 0x7F]))             # USR, then the assignment to i%
    if u < at + len(boot) or q.find(bytes([0x9F]), at + len(boot)) != u:
        raise BuildError('SANTAG: its USR call is not where it should be')
    return -(qlen + SANTAG_FRAME_GAP), u


def santa_hole(path):
    """KR: SANTA's QCode before its call of SANTAG, in RAM just above the array (offset from its
    end, length); KS: its code after that (the "NEEDS" message), which never runs once SANTAG
    has (its offset from KR, length). Only 84 7B (drop SANTAG's result, RETURN) run again, when
    the game ends: they stay."""
    obj = opl_object(path)
    qlen = obj[2] << 8 | obj[3]
    q = obj[len(obj) - qlen:]
    c = q.find(bytes([0x7D, 6]) + b'SANTAG' + bytes([0x84, 0x7B]))
    if c < 0 or q.find(b'SANTAG', c + 3) >= 0:
        raise BuildError('SANTA: its call of SANTAG is not where it should be')
    return SANTA_FRAME, c + 8, c + 10, qlen - c - 10


def array_bytes(total):
    """m%() is whole words: SANTA's frame starts after its last byte."""
    return (total + 1) // 2 * 2


class Items:
    """Area B's items: code units first (their ids), then data."""
    def __init__(self):
        self.names = [n for n, _ in UNITS]
        self.data = {}

    def add(self, name, data):
        if name in self.names:
            raise BuildError('item %s twice' % name)
        self.names.append(name)
        self.data[name] = bytes(data)

    def ids(self):
        return {n: i + 1 for i, n in enumerate(self.names)}


SYMS = 'MRBWAKQJHS*'
TB_BASE, TB_FREE, TB_LINES, TB_PAYS = 0, 175, 315, 415


NOTE0 = 'E4'                   # note 0; C5 is note 8, C8 note 44
NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']


def note_number(name):
    """'C5' -> the game's note number (E4 = 0)."""
    def semis(n):
        return NOTE_NAMES.index(n[:-1]) + 12 * int(n[-1])
    return semis(name) - semis(NOTE0)


def note_freq(n):
    return 440.0 * 2 ** ((n + note_number('E4') - note_number('A4')) / 12)


def notes_table():
    """S for each note: the tone loop's period is 32 + 4 S cycles (src/kernel/ksound.asm)."""
    out = []
    for n in range(note_number('C8') + 1):
        s = round((921600 / note_freq(n) - 32) / 4)
        if not 3 <= s <= 765:
            raise BuildError('note %d: S %d out of range' % (n, s))
        out.append(s)
    return out


def make_tables(kind):
    """The game tables for one grid (OV_GAME's layout)."""
    t = json.load(open(os.path.join(ROOT, 'data', 'tables.json'), encoding='utf-8'))
    g = t[kind]
    out = bytearray()
    for s in g['base'] + g['free'][1:]:
        if len(s) != 32:
            raise BuildError('a strip of %d' % len(s))
        out += bytes(SYMS.index(c) for c in s + s[:3])
    for l in g['lines']:
        out += bytes(int(c) - 1 for c in l)
    for sym in 'MRBWAKQJ':
        for p in t['pays'][sym]:
            out += p.to_bytes(2, 'big')
    assert len(out) == TB_PAYS + 48
    return bytes(out)


FONT_CHARS = '@AKQJ*+x'
FONT = {'@': [14, 17, 1, 13, 21, 21, 14, 0], 'A': [14, 17, 17, 17, 31, 17, 17, 0], 'K': [17, 18, 20, 24, 20, 18, 17, 0],
        'Q': [14, 17, 17, 17, 21, 18, 13, 0], 'J': [7, 2, 2, 2, 2, 18, 12, 0], '*': [0, 4, 21, 14, 21, 4, 0, 0],
        '+': [0, 4, 4, 31, 4, 4, 0, 0], 'x': [0, 0, 17, 10, 4, 10, 17, 0]}   # the LCD font (CM and LZ alike)


# the commands from C_MENU (3) on: the overlay and entry each runs (kmain.asm reads the
# table, IT_CMDS, from the pack)
CMDS = ['OV_MENU', 'OV_PAYS', 'OV_PAYS+1', 'OV_INFO', 'OV_SET', 'OV_EXTRA', 'OV_EXTRA+1', 'OV_INFO+1',
        'OV_MENU+3', 'OV_MENU+1', 'OV_MENU+2', 'OV_IDLE', 'OV_IDLE+1', 'OV_SCENE', 'OV_BANK+B_NEW',
        'OV_BANK+B_SAVE', 'OV_GAME+G_GIFT', 'OV_BANK+B_GSETTLE', 'OV_GAMBLE', 'OV_BANK+B_DATE']


def defs_values():
    """The plain NAME = number lines of src/defs.inc."""
    out = {}
    for line in open(os.path.join(ROOT, 'src', 'defs.inc'), encoding='latin-1'):
        w = line.split(';')[0].split('=')
        if len(w) == 2 and w[0].strip().isidentifier():
            v = w[1].strip()
            try:
                out[w[0].strip()] = int(v[1:], 16) if v.startswith('$') else int(v)
            except ValueError:
                pass
    return out


def make_cmds(ids):
    d = defs_values()
    out = bytearray()
    for c in CMDS:
        ov, _, e = c.partition('+')
        entry = (int(e) if e.isdigit() else d[e]) if e else 0
        out += bytes([ids[ov], entry])
    if len(CMDS) != d['C_LAST'] - d['C_MENU'] + 1:
        raise BuildError('CMDS has %d commands, defs.inc C_MENU..C_LAST %d' % (len(CMDS), d['C_LAST'] - d['C_MENU'] + 1))
    return out


def make_data(items):
    items.add('IT_CMDS', make_cmds(items.ids()))
    items.add('IT_TAB4', make_tables('four'))
    items.add('IT_TAB2', make_tables('two'))
    pics, _ = art.parse(os.path.join(ROOT, 'art', 'pictures.txt'))
    items.add('IT_FONT', bytes([len(FONT_CHARS)]) + b''.join(bytes([ord(c)] + FONT[c]) for c in FONT_CHARS))
    poses, porder = art.parse(os.path.join(ROOT, 'art', 'santa.txt'))
    items.add('IT_POSES', b''.join(art.encode(poses[n]) for n in porder))
    items.add('IT_SANTA', bytes(art.rowbits(r) for r in poses['STAND']['rows']))   # 16 rows: glyphs 4 and 5
    for name, t in script.parse_tunes(os.path.join(ROOT, 'data', 'tunes.txt')).items():
        items.add('IT_T_' + name, script.tune_bytes(t))
        script.TUNE_ITEMS[name] = items.ids()['IT_T_' + name]
        if len(script.tune_bytes(t)) > TUNE_BUF:
            raise BuildError('tune %s is over the tune buffer' % name)
    script.DATA['FONT'] = bytes([len(FONT_CHARS)]) + b''.join(bytes([ord(c)] + FONT[c]) for c in FONT_CHARS)
    src = script.load_sources()
    with open(os.path.join(ROOT, 'build', 'sounds.json'), 'w') as f:    # for tools/sounds.js
        json.dump({k: {n: list(v) for n, v in src[k].items()} for k in ('tunes', 'effects')}, f)
    for fn in sorted(os.listdir(os.path.join(ROOT, 'scripts'))):
        if fn.endswith('.scr'):
            for blob in script.parse_scripts(os.path.join(ROOT, 'scripts', fn)):
                data, names = script.build_blob(blob, src, fn, BLOB_MAX)
                items.add('IT_' + blob.name, data)
                BLOBS[blob.name] = names
    items.add('IT_GAMBLE', art.encode(pics['FIST']) + art.encode(pics['PRESENT']))
    items.add('IT_PICS', b''.join(art.encode(pics[n]) for n in ('MRS', 'DEER', 'BELL', 'HOUSE')))


def build(out):
    gen = os.path.join(out, 'gen')
    os.makedirs(gen, exist_ok=True)
    items = Items()
    make_data(items)
    ids = items.ids()
    lines = ['; generated by tools/build.py', 'N_ITEMS = %d' % len(ids)]
    lines += ['%s = %d' % (n, i) for n, i in ids.items()]
    for b, names in BLOBS.items():
        lines += ['SC_%s_%s = %d' % (b, n.upper(), i) for n, i in names.items()]
    lines += ['TB_BASE = %d' % TB_BASE, 'TB_FREE = %d' % TB_FREE, 'TB_LINES = %d' % TB_LINES, 'TB_PAYS = %d' % TB_PAYS]
    with open(os.path.join(gen, 'ids.inc'), 'w') as f:
        f.write('\n'.join(lines) + '\n')
    with open(os.path.join(gen, 'notes.inc'), 'w') as f:
        nt = notes_table()
        hi2 = sum(1 for v in nt if v >= 512)          # (S falls as the note rises)
        hi1 = sum(1 for v in nt if v >= 256)
        if any((v >> 8) != (2 if i < hi2 else 1 if i < hi1 else 0) for i, v in enumerate(nt)):
            raise BuildError('the notes table: S out of order')
        f.write('NOTE_HI2 = %d\nNOTE_HI1 = %d\n' % (hi2, hi1))
        f.write('notes:  fcb  %s\n' % ','.join(str(v & 255) for v in nt))
    if ids['DRV2'] != 1 or ids['DRV4'] != 2:
        raise BuildError('the drivers must be units 1 and 2')
    incdirs = [gen, os.path.join(ROOT, 'src'), os.path.join(ROOT, 'src', 'kernel'), os.path.join(ROOT, 'src', 'screens')]

    def assemble(path, origin, imports, what):
        try:
            return asm.assemble(path, origin=origin, imports=imports, incdirs=incdirs)
        except asm.AsmError as e:
            raise BuildError('%s: %s' % (what, e))

    init_len = [0]

    hole = {}

    def imports(kmax, drv, slot):
        top = array_bytes(kmax + drv + slot)
        return {'DRV': (kmax, 'rel'), 'SLOTA': (kmax + drv, 'rel'), 'TUNEAT': (kmax + drv + slot - TUNE_BUF, 'rel'),
                'INIT_LEN': (init_len[0], 'abs'), 'SLOTA_SIZE': (slot, 'abs'), 'DRV_SIZE': (drv, 'abs'),
                'TUNE_BUF': (TUNE_BUF, 'abs'),
                'KH': (hole['kh'], 'rel'), 'KH_LEN': (hole['kh_len'], 'abs'),
                'KH_KEEP': (hole['kh'] + hole['kh_len'], 'rel'),
                'KR': (top + hole['kr'], 'rel'), 'KR_LEN': (hole['kr_len'], 'abs'),
                'KR_KEEP': (top + hole['kr'] + hole['kr_len'], 'rel'),
                'KS': (top + hole['kr'] + hole['ks'], 'rel'), 'KS_LEN': (hole['ks_len'], 'abs')}

    def need(n):
        its, before, tune = DATA_OF.get(n, ([], 0, True))
        return before + max([len(items.data[i]) + 2 for i in its] or [0]) + (TUNE_BUF if tune else 0)

    kpath = os.path.join(ROOT, 'src', 'kernel', 'kernel.asm')
    b = assemble(os.path.join(ROOT, 'src', 'launch', 'boot.asm'), 0, {'BUILD': (0x4242, 'abs')}, 'boot')    # (its build: below)
    if b.fix:
        raise BuildError('the bootstrap must be position independent')
    boot = bytes(b.out)
    bad = [i for i, v in enumerate(boot) if v in BAD_OPL]
    if bad:
        raise BuildError('the bootstrap has bytes an OPL string cannot hold at %s' % bad)

    # the launchers' code that never runs again: drafts, for where the holes are
    draft = os.path.join(out, 'draft.opl')
    with open(draft, 'w', encoding='latin-1', newline='\n') as f:
        f.write('\n'.join(launcher_lines(boot, 5000)) + '\n')
    hole['kh'], hole['kh_len'] = santag_hole(draft, boot)
    with open(draft, 'w', encoding='latin-1', newline='\n') as f:
        f.write('\n'.join(santa_lines(5000)) + '\n')
    hole['kr'], hole['kr_len'], hole['ks'], hole['ks_len'] = santa_hole(draft)
    os.remove(draft)

    # sizes: the drivers and overlays, assembled against a first kernel
    k = assemble(kpath, 0, imports(0x3000, 512, 1024), 'kernel')
    ksym = dict(k.sym)
    ksym.update(imports(0x3000, 512, 1024))
    drv = slot = 16
    for n, fn in UNITS:
        u = assemble(os.path.join(ROOT, 'src', 'screens', fn), 0x3000, ksym, n)
        if n in DRIVERS:
            drv = max(drv, len(u.out))
        else:
            slot = max(slot, len(u.out) + need(n))
    kmax = 0
    for _ in range(8):
        k = assemble(kpath, 0, imports(kmax, drv, slot), 'kernel')
        if len(k.out) == kmax:
            break
        kmax = len(k.out)
    else:
        raise BuildError('kernel size did not settle')
    if bytes(k.out[3:7]) != b'SPK1':
        raise BuildError('kernel does not start with its tag')
    ksym = dict(k.sym)
    ksym.update(imports(kmax, drv, slot))
    kin = assemble(os.path.join(ROOT, 'src', 'kernel', 'kinit.asm'), kmax + drv, ksym, 'kinit')
    init_len[0] = len(kin.out)
    k2 = assemble(kpath, 0, imports(kmax, drv, slot), 'kernel')
    if len(k2.out) != len(k.out) or any(k2.sym[n] != v for n, v in k.sym.items() if n != 'INIT_LEN'):
        raise BuildError('the kernel moved when given the length of the start-up code')
    k = k2
    ksym = dict(k.sym)
    ksym.update(imports(kmax, drv, slot))
    kin = assemble(os.path.join(ROOT, 'src', 'kernel', 'kinit.asm'), kmax + drv, ksym, 'kinit')
    if len(kin.out) != init_len[0]:
        raise BuildError('the start-up code changed length when given its length')
    if len(kin.out) > slot:
        raise BuildError('the start-up code (%d) is bigger than region R' % len(kin.out))
    with open(os.path.join(out, 'kinit.lst'), 'w') as f:
        f.write(kin.listing_text())
    vstart = k.sym['kv_first'][0]
    if vstart + len(kin.out) > kmax + drv:
        raise BuildError('the start-up code would overlap slot A while it is copied')
    image = bytearray(k.out)
    if any(image[vstart:]):
        raise BuildError('kernel variables are not all zero')
    if any(f >= vstart for f in k.fix):
        raise BuildError('a fix-up in the kernel variables')

    # area B: the index, then the units, then the data
    body = {}
    report = []
    for n, fn in UNITS:
        origin = kmax if n in DRIVERS else kmax + drv
        u = assemble(os.path.join(ROOT, 'src', 'screens', fn), origin, ksym, n)
        limit = drv if n in DRIVERS else slot
        if len(u.out) + (0 if n in DRIVERS else need(n)) > limit:
            raise BuildError('%s is %d bytes and needs %d after it: over its room (%d)' % (n, len(u.out), need(n), limit))
        body[n] = len(u.out).to_bytes(2, 'big') + bytes(u.out) + encode_fixups(u.fix)
        report.append((n, len(u.out), len(u.fix), 0 if n in DRIVERS else need(n)))
        with open(os.path.join(out, n.lower() + '.lst'), 'w') as f:
            f.write(u.listing_text())
        with open(os.path.join(out, n.lower() + '.sym.json'), 'w') as f:
            json.dump({s: v for s, v in u.sym.items() if s not in ksym}, f, indent=0)
    for n, d in items.data.items():
        body[n] = len(d).to_bytes(2, 'big') + d
    nitems = len(items.names)
    blk = bytearray(2 * nitems)
    for i, n in enumerate(items.names):
        off = len(blk)
        blk[2 * i:2 * i + 2] = off.to_bytes(2, 'big')
        blk += body[n]
    if len(blk) > 65000:
        raise BuildError('area B is %d bytes' % len(blk))

    kimg = image[:vstart] + bytes(kin.out)
    fx = assemble(os.path.join(ROOT, 'src', 'launch', 'fixer.asm'), 0, {}, 'fixer')
    if fx.fix:
        raise BuildError('the fixer must be position independent')
    enc = encode_fixups(list(k.fix) + [vstart + f for f in kin.fix], kernel=True)
    allk = bytes(kimg) + bytes(fx.out) + enc[1:]            # read in one go by the bootstrap
    total = kmax + drv + slot
    if len(allk) > total - len(boot) - 16:
        raise BuildError('kernel and its fix-ups do not fit the array while loading')
    build_id = build_number(allk + bytes(blk))
    boot = bytes(assemble(os.path.join(ROOT, 'src', 'launch', 'boot.asm'), 0, {'BUILD': (build_id, 'abs')}, 'boot').out)
    sank = build_id.to_bytes(2, 'big') + len(kimg).to_bytes(2, 'big') + len(allk).to_bytes(2, 'big') + allk + bytes(blk)
    with open(os.path.join(out, 'kernel.lst'), 'w') as f:
        f.write(k.listing_text())
    with open(os.path.join(out, 'kernel.sym.json'), 'w') as f:
        json.dump({n: v for n, v in ksym.items()}, f, indent=0)

    kh_used = k.sym['kh_end'][0] - k.sym['kh_first'][0]
    if k.sym['kh_first'][0] != hole['kh'] or kh_used > hole['kh_len']:
        raise BuildError("the variables in SANTAG's code (%d bytes) must fit it (%d)" % (kh_used, hole['kh_len']))
    kr_used = k.sym['kr_end'][0] - k.sym['kr_first'][0]
    if k.sym['kr_first'][0] != array_bytes(total) + hole['kr'] or kr_used > hole['kr_len']:
        raise BuildError("the variables in SANTA's code (%d bytes) must fit it (%d)" % (kr_used, hole['kr_len']))
    ks_used = k.sym['ks_end'][0] - k.sym['ks_first'][0]
    if k.sym['ks_first'][0] != array_bytes(total) + hole['kr'] + hole['ks'] or ks_used > hole['ks_len']:
        raise BuildError("the variables in SANTA's message (%d bytes) must fit it (%d)" % (ks_used, hole['ks_len']))
    needs = total + LAUNCH_OVERHEAD
    lp = os.path.join(out, 'SANTAG.opl')
    with open(lp, 'w', encoding='latin-1', newline='\n') as f:
        f.write('\n'.join(launcher_lines(boot, total)) + '\n')
    sp = os.path.join(out, 'SANTA.opl')
    with open(sp, 'w', encoding='latin-1', newline='\n') as f:
        f.write('\n'.join(santa_lines(needs)) + '\n')
    if santag_hole(lp, boot) != (hole['kh'], hole['kh_len']) or santa_hole(sp) != (hole['kr'], hole['kr_len'], hole['ks'], hole['ks_len']):
        raise BuildError('the launchers changed shape between the draft and the build')

    img = pack.PackImage('datapak', PACK_K, target='cm')
    img.add_opl(sp)
    img.add_opl(lp)
    img.add_data('SANM', sank)
    with open(os.path.join(out, 'sank.bin'), 'wb') as f:      # (for tests/m_mem.js's packs)
        f.write(sank)
    opk = os.path.join(out, 'SPINS.opk')
    size_k, used = img.write(opk)

    e = {n: v[0] for n, v in k.sym.items()}
    text = ['Pack (%dK Datapak): %d bytes used of %d' % (size_k, used, size_k * 1024),
            '  SANM %d (kernel %d, area B %d)' % (len(sank), len(allk), len(blk)),
            'RAM (array m%%()): %d, SANTA needs %d free' % (total, needs),
            '  kernel code %d, variables %d, start-up code %d (run once)' % (vstart, kmax - vstart, len(kin.out)),
            '  and in the launchers\' code that has run: %d of %d below the array (SANTAG), %d of %d and %d of %d above (SANTA)'
            % (kh_used, hole['kh_len'], kr_used, hole['kr_len'], ks_used, hole['ks_len']),
            '  driver %d, region R %d (an overlay, then its data; the tune at the top: %d)' % (drv, slot, TUNE_BUF),
            'Units']
    for n, ln, nf, nd in report:
        text.append('  %-10s %5d bytes, %3d fix-ups, %4d of data: %5d' % (n, ln, nf, nd, ln + nd))
    text = '\n'.join(text)
    with open(os.path.join(out, 'budget.txt'), 'w') as f:
        f.write(text + '\n')
    meta = {'kmax': kmax, 'drv': drv, 'slot': slot, 'total': total, 'needs': needs,
            'opk': os.path.relpath(opk, ROOT).replace(os.sep, '/'),   # relative: no home folder in the repo
            'ids': ids, 'vstart': vstart, 'kh': hole['kh'], 'kh_len': hole['kh_len'], 'kh_used': kh_used,
            'kr': array_bytes(total) + hole['kr'], 'kr_len': hole['kr_len'], 'kr_used': kr_used,
            'ks': array_bytes(total) + hole['kr'] + hole['ks'], 'ks_len': hole['ks_len'], 'ks_used': ks_used}
    with open(os.path.join(out, 'build.json'), 'w') as f:
        json.dump(meta, f, indent=1)
    return text, meta


def psion_folder(opk, folder):
    """The pack's files as .OB3 procedures for RPLOAD (a real Organiser through a Comms Link).
    Made in a scratch folder, then copied over: other files in psion/ are left alone."""
    import shutil
    import subprocess
    tools = os.path.join(ROOT, '..', '..', 'Tools')
    tmp = folder + '_tmp'
    if os.path.isdir(tmp):
        shutil.rmtree(tmp)
    subprocess.run([sys.executable, os.path.join(tools, 'opk2files.py'), '-o', tmp, opk], check=True, capture_output=True)
    for f in os.listdir(tmp):
        if f.lower().endswith('.opl'):
            os.remove(os.path.join(tmp, f))          # (the .ob3 files hold the source too)
    subprocess.run([sys.executable, os.path.join(tools, 'mkrpdata.py'), tmp, '--title', 'PSION SPINS', '--run', 'SANTA'],
                   check=True, capture_output=True)
    os.makedirs(folder, exist_ok=True)
    for f in os.listdir(tmp):
        shutil.copyfile(os.path.join(tmp, f), os.path.join(folder, f))
    shutil.rmtree(tmp)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=None)
    ap.add_argument('--psion', action='store_true', help='also write psion/: the files for RPLOAD')
    a = ap.parse_args()
    out = os.path.abspath(a.out) if a.out else os.path.join(ROOT, 'build', 'game')
    os.makedirs(out, exist_ok=True)
    try:
        text, _ = build(out)
    except (BuildError, pack.opl2opk.PackError, art.ArtError, script.ScriptError) as e:
        sys.exit('build failed: %s' % e)
    print(text)
    if a.psion:
        psion_folder(os.path.join(out, 'SPINS.opk'), os.path.join(ROOT, 'psion'))
        print('psion/: the files for RPLOAD')


if __name__ == '__main__':
    main()
