; ---------------------------------------------------------------------
; Keys (from Connect 4 and Reversi). Every key stirs the free-running
; timer into the random state.
; ---------------------------------------------------------------------

; key_test: B = a waiting key (taken), or 0
key_test:
        os   KB$TEST
        tstb
        beq  kw_x
        os   KB$GETK
        bra  kw_key

; key_wait: A = frames (50 ms) to wait, 0 = until a key. Out: B = key, or 0
; if the time ran out. The pack is switched off first. Switching off after
; the Organiser's idle time, and on again, redraws the screen.
key_wait:
        staa kv_left
        tst  kv_pkok
        beq  .on
        os   PK$PKOF
        clr  kv_pkok
.on:    jsr  flush
        ldaa kv_left
        bne  .tm
        bsr  kw_sleep
        bra  kw_key
.tm:    bsr  kw_timed
kw_key: tstb
        beq  kw_x
        ldaa FRC+1              ; the random state: the timer stirred in
        eora kv_rng+3
        staa kv_rng+3
        ldaa FRC
        adda kv_rng+2
        staa kv_rng+2
        oraa kv_rng+3           ; (never all zero)
        oraa kv_rng
        oraa kv_rng+1
        bne  .nz
        inc  kv_rng+3
.nz:    cmpb #'a'               ; a to z become A to Z
        blo  kw_x
        cmpb #'z'
        bhi  kw_x
        subb #32
kw_x:   rts

; wait up to kv_left frames for a key: B = key or 0
kw_timed:
        ldaa TMW_FRAM+1
        staa kv_afr             ; (flush uses kv_t0)
kw_tidle: ldx TMW_TCNT           ; no switching off in a timed wait
        stx  TMW_TOUT           ; (tests call overlays from here too)
        os   KB$TEST
        tstb
        bne  .got
        ldaa TMW_FRAM+1
        suba kv_afr
        cmpa kv_left
        bhs  .out
        slp
        jsr  flush              ; (after an alarm: almchk)
        bra  kw_tidle
.got:   os   KB$GETK
        rts
.out:   clrb
        rts

; Wait for a key with no time limit, switching off after the Organiser's
; idle time (TMW_TCNT seconds, 0 = never) with BT$SWOF; on again,
; everything is drawn again.
kw_sleep:
        clr  kv_aidle
        clr  kv_aidle+1
        ldaa TMW_FRAM+1
        staa kv_afr
kw_idle: ldx  TMW_TCNT          ; (tests call overlays from here: t_call)
        stx  TMW_TOUT
        os   KB$TEST
        tstb
        bne  .key
        slp
        jsr  flush              ; (after an alarm: almchk)
        ldaa TMW_FRAM+1
        cmpa kv_afr
        beq  kw_idle
        staa kv_afr
        ldd  kv_aidle
        addd #1
        std  kv_aidle
        ldx  TMW_TCNT
        beq  kw_idle
        xgdx                    ; seconds -> frames: * 20
        asld
        asld
        std  kv_t0
        asld
        asld
        addd kv_t0
        subd kv_aidle
        bhi  kw_idle
        jsr  sw_off
        bra  kw_sleep
.key:   os   KB$GETK
        rts

; switch off now; on again, everything drawn again
sw_off: os   BT$SWOF            ; back here when ON is pressed
        jsr  redraw
        jsr  flush
        os   KB$FLSH
        rts
