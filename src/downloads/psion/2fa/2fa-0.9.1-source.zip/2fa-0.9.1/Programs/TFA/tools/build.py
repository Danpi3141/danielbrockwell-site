#!/usr/bin/env python3
"""Builds Psion 2FA (TFA): the machine code (one array, no overlays), the launchers and the pack.

    python tools/build.py [--out build/game] [--kernel src/kernel/kernel.asm] [--psion]

Pack (16K Datapak, runs on every model): TFA and CLOCK (OPL: check the free memory, call TFAG),
TFAG (OPL: makes the array m%(), pokes the bootstrap into its top, calls it) and TFAM (data
block: the kernel's length, the length of all that follows, the kernel's code, the fixer and
the encoded fix-ups). The bootstrap finds TFAM, reads it into m%(), the fixer adds m%()'s
address to every word in the fix-up list and jumps to the kernel with D = ADDR(v%()).
The kernel's variables come after its code; they are not on the pack (the kernel clears them).
"""
import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import asm   # noqa: E402
import pack  # noqa: E402

BAD_OPL = (0, 9, 10, 13)
LAUNCH_OVERHEAD = 300          # TFAG and its caller beyond the array (tests/m_mem.js: the program works with
                               # about 960 bytes of padding through TFA on a blank CM 3.3; at 300 TFA refuses from 958)
SET_ROOM = 60                  # A:TFASET, made on the first run
PACK_K = 16


class BuildError(Exception):
    pass


def encode_fixups(fix):
    """Steps, two a byte (the high nibble first): 1-15 on that far and fix the word there,
    0 on 15 without a fix-up (also the pad). (As Spins/Connect 4; src/launch/fixer.asm.)"""
    nib = []
    prev = 0
    for f in sorted(fix):
        d = f - prev
        if d < 1:
            raise BuildError('a fix-up at %d: steps start at 1' % f)
        while d > 15:
            nib.append(0)
            d -= 15
        nib.append(d)
        prev = f
    if len(nib) % 2:
        nib.append(0)
    return bytes(nib[i] << 4 | nib[i + 1] for i in range(0, len(nib), 2))


def tfag_lines(boot, total):
    lit = '"' + bytes(boot).decode('latin-1').replace('"', '""') + '"'
    if len('POKEB a%%+i%%,ASC(MID$(%s,i%%+1,1))' % lit) > 250:
        raise BuildError('the bootstrap no longer fits one string')
    words = (total + 1) // 2
    return ['TFAG:(c%)', 'LOCAL m%%(%d),v%%(6),i%%,a%%' % words,
            'a%%=ADDR(m%%())+%d' % (total - len(boot)),
            'i%=0', 'DO', 'POKEB a%%+i%%,ASC(MID$(%s,i%%+1,1))' % lit, 'i%=i%+1', 'UNTIL i%%=%d' % len(boot),
            'v%%(1)=ADDR(m%%()) :v%%(2)=%d :v%%(5)=c%%' % total,
            'i%=USR(a%,ADDR(v%()))',
            'IF i% :PRINT "TFA ERROR ";i% :GET :ENDIF']


def caller_lines(name, flag, needs):
    return ['%s:' % name, 'LOCAL n%',
            'n%%=%d+%d*EXIST("A:TFASET")-FREE' % (needs + SET_ROOM, SET_ROOM),
            'IF n%%<=0 :TFAG:(%d) :RETURN :ENDIF' % flag,
            'PRINT "TFA NEEDS ";n% :PRINT "BYTES MORE RAM" :GET']


TFAG_FRAME_GAP = 22            # TFAG's QCode ends this far below m%() (its variables in between)
CALLER_FRAME = 17              # TFA's / CLOCK's QCode starts this far above m%()'s last word
                               # (both measured on all 29 ROMs, 21 Nov; checked by tests/t_hidden.js)


def opl_object(path):
    """A launcher's translated object code (as the CM translator makes it)."""
    class A:
        no_translate = False
        target = 'cm'
        strip_indent = True
        encoding = 'latin-1'
    _, rec, _ = pack.opl2opk.opl_procedure(path, A, quiet=True)
    rec = bytes(rec)
    olen = rec[15] << 8 | rec[16]
    return rec[17:17 + olen]


def qcode(path):
    obj = opl_object(path)
    qlen = obj[2] << 8 | obj[3]
    return obj[len(obj) - qlen:]


def launcher_holes(tfag, caller, boot):
    """Where the launchers' code that never runs again lies, relative to m%() (kvars.inc):
    KH: TFAG's QCode before its USR call, just below the array; KR: TFA's (or CLOCK's, the same
    code) QCode up to and including its call of TFAG, just above the array; KS: its code after
    the 84 7B (drop TFAG's result, RETURN) that run again, the NEEDS message."""
    q = qcode(tfag)
    at = q.find(boot)
    if at < 0 or q.find(boot, at + 1) >= 0:
        raise BuildError('TFAG: the bootstrap string is not once in its code')
    u = q.rfind(bytes([0x9F, 0x7F]))             # USR, then the assignment to i%
    if u < at + len(boot) or q.find(bytes([0x9F]), at + len(boot)) != u:
        raise BuildError('TFAG: its USR call is not where it should be')
    r = qcode(caller)
    c = r.find(bytes([0x7D, 4]) + b'TFAG' + bytes([0x84, 0x7B]))
    if c < 0 or r.find(b'TFAG', c + 3) >= 0:
        raise BuildError('the caller: its call of TFAG is not where it should be')
    # (not the parameter's push and count before the call: the OPL runtime reads them again when
    # TFAG returns - variables there crashed an LA on leaving, 21 Nov)
    if r[c - 7] != 0x22 or r[c - 5:c] != bytes([0x20, 0, 0x20, 1, 0x7D])[:5] and r[c - 4:c] != bytes([0x20, 0, 0x20, 1]):
        raise BuildError("the caller: TFAG's parameter is not pushed where it should be")
    return {'kh': -(len(q) + TFAG_FRAME_GAP), 'kh_len': u, 'kr_len': c - 7, 'kr_keep': c + 6, 'ks': c + 8, 'ks_len': len(r) - c - 8}


def hole_imports(h, total):
    top = (total + 1) // 2 * 2 + CALLER_FRAME
    return {'KH': (h['kh'], 'rel'), 'KH_LEN': (h['kh_len'], 'abs'), 'KH_KEEP': (h['kh'] + h['kh_len'], 'rel'),
            'KR': (top, 'rel'), 'KR_LEN': (h['kr_len'], 'abs'), 'KR_KEEP': (top + h['kr_keep'], 'rel'),
            'KS': (top + h['ks'], 'rel'), 'KS_LEN': (h['ks_len'], 'abs')}


def build(out, kpath):
    incdirs = [os.path.join(ROOT, 'src'), os.path.join(ROOT, 'src', 'kernel'), os.path.join(ROOT, 'src', 'ovl')]

    def assemble(path, origin=0, imports=None, what='', defines=None):
        try:
            return asm.assemble(path, origin=origin, imports=imports or {}, defines=defines or {}, incdirs=incdirs)
        except asm.AsmError as e:
            raise BuildError('%s: %s' % (what or path, e))

    b = assemble(os.path.join(ROOT, 'src', 'launch', 'boot.asm'), what='boot')
    if b.fix:
        raise BuildError('the bootstrap must be position independent')
    boot = bytes(b.out)
    bad = [i for i, v in enumerate(boot) if v in BAD_OPL]
    if bad:
        raise BuildError('the bootstrap has bytes an OPL string cannot hold at %s' % bad)
    fx = assemble(os.path.join(ROOT, 'src', 'launch', 'fixer.asm'), what='fixer')
    if fx.fix:
        raise BuildError('the fixer must be position independent')

    ovl = os.path.join(ROOT, 'src', 'ovl')
    units = [None] + ['ov_date', 'ov_clk', 'ov_cset', 'ov_add', 'ov_key', 'ov_chk', 'ov_edit', 'ov_del', 'ov_set', 'ov_zone',
                     'ov_pset', 'ov_pin', 'ov_help', 'ov_tools', 'ov_init', 'ov_name', 'ov_strm']
    # the launchers' holes, from drafts (their shape does not depend on the numbers in them)
    drafts = {}
    for name, lines in (('TFAG', tfag_lines(boot, 5000)), ('TFA', caller_lines('TFA', 0, 5300)), ('CLOCK', caller_lines('CLOCK', 1, 5300))):
        drafts[name] = os.path.join(out, 'draft_%s.opl' % name)
        with open(drafts[name], 'w', encoding='latin-1', newline='\n') as f:
            f.write('\n'.join(lines) + '\n')
    holes = launcher_holes(drafts['TFAG'], drafts['TFA'], boot)
    if launcher_holes(drafts['TFAG'], drafts['CLOCK'], boot) != holes:
        raise BuildError("CLOCK's code is not shaped as TFA's")
    size, total = 16, 0
    for _ in range(20):
        hi = hole_imports(holes, total)
        k = assemble(kpath, what='kernel', defines={'OV_SIZE': size}, imports=hi)
        ksym = {n: v for n, v in k.sym.items() if not n.startswith('.') and '.' not in n}
        ksym.update(hi)
        if 'ov_slot' not in k.sym:              # (a probe kernel: no overlays)
            units, ovs, origin = [None], {}, k.sym['kv_first'][0]
            break
        origin = k.sym['ov_slot'][0]
        ovs = {}
        for i, u in enumerate(units):
            if u:
                ovs[i] = assemble(os.path.join(ovl, u + '.asm'), origin=origin, imports=ksym, what=u)
        need = max(len(o.out) for o in ovs.values())
        # the top of the slot holds the name menu's list under OV_NAME, and slots 1-2 above OV_STRM
        need = max(need, len(ovs[units.index('ov_name')].out) + k.sym['MENU_BUF'][0],
                   len(ovs[units.index('ov_strm')].out) + 2 * k.sym['SL_SIZE'][0])
        if need == size and k.sym['kv_end'][0] == total:
            break
        size, total = need, k.sym['kv_end'][0]
    else:
        raise BuildError('the overlay slot did not settle')
    for r, n in (('kh', 'KH'), ('kr', 'KR'), ('ks', 'KS')):
        used = k.sym[r + '_end'][0] - ksym[n][0]
        if used > ksym[n + '_LEN'][0]:
            raise BuildError('the variables in %s (%d bytes) must fit it (%d)' % (n, used, ksym[n + '_LEN'][0]))
    for f in drafts.values():
        os.remove(f)
    if bytes(k.out[3:7]) != b'TFA1':
        raise BuildError('the kernel does not start with jmp + its tag TFA1')
    vstart = k.sym['kv_first'][0]
    if vstart != origin:
        raise BuildError('the overlay slot must start the variables')
    total = k.sym['kv_end'][0]
    image = bytearray(k.out)
    if any(image[vstart:]):
        raise BuildError('kernel variables are not all zero')
    if any(f >= vstart for f in k.fix):
        raise BuildError('a fix-up in the kernel variables')
    kimg = bytes(image[:vstart])
    allk = kimg + bytes(fx.out) + encode_fixups(k.fix)
    if len(allk) > total - len(boot):
        raise BuildError('the kernel, fixer and fix-ups (%d) do not fit below the bootstrap (array %d)' % (len(allk), total))
    index = bytearray()
    body = bytearray()
    nunits = len(units) - 1
    report = []
    for i in range(1, nunits + 1):
        o = ovs[i]
        enc = encode_fixups(o.fix)
        if len(enc) > 255:
            raise BuildError('%s: %d bytes of fix-ups' % (units[i], len(enc)))
        index += (2 * nunits + len(body)).to_bytes(2, 'big')
        body += len(o.out).to_bytes(2, 'big') + bytes(o.out) + bytes([len(enc)]) + enc
        report.append('  %-9s %5d bytes, %3d fix-ups' % (units[i].upper(), len(o.out), len(o.fix)))
        with open(os.path.join(out, units[i] + '.lst'), 'w') as f:
            f.write(o.listing_text())
    tfam = len(kimg).to_bytes(2, 'big') + len(allk).to_bytes(2, 'big') + allk + bytes(index) + bytes(body)

    needs = total + LAUNCH_OVERHEAD
    paths = {}
    for name, lines in (('TFA', caller_lines('TFA', 0, needs)), ('CLOCK', caller_lines('CLOCK', 1, needs)),
                        ('TFAG', tfag_lines(boot, total))):
        p = os.path.join(out, name + '.opl')
        with open(p, 'w', encoding='latin-1', newline='\n') as f:
            f.write('\n'.join(lines) + '\n')
        paths[name] = p
    if launcher_holes(paths['TFAG'], paths['TFA'], boot) != holes or launcher_holes(paths['TFAG'], paths['CLOCK'], boot) != holes:
        raise BuildError('the launchers changed shape between the drafts and the build')
    img = pack.PackImage('datapak', PACK_K, target='cm')
    for name in ('TFA', 'CLOCK', 'TFAG'):
        img.add_opl(paths[name])
    img.add_data('TFAM', tfam)
    with open(os.path.join(out, 'tfam.bin'), 'wb') as f:      # (tests/m_mem.js makes padded packs)
        f.write(tfam)
    opk = os.path.join(out, 'TFA.opk')
    size_k, used = img.write(opk)
    with open(os.path.join(out, 'kernel.lst'), 'w') as f:
        f.write(k.listing_text())
    with open(os.path.join(out, 'kernel.sym.json'), 'w') as f:
        json.dump({n: v for n, v in k.sym.items() if not n.startswith('.')}, f, indent=0)
    text = ['Pack (%dK Datapak): %d bytes used of %d' % (size_k, used, size_k * 1024),
            '  TFAM %d (kernel %d, fixer %d, fix-ups %d: %d; overlays %d)' % (len(tfam), len(kimg), len(fx.out), len(k.fix), len(allk) - len(kimg) - len(fx.out), len(index) + len(body)),
            'RAM: array %d (resident code %d, overlay slot %d, variables %d); TFA needs %d free (+%d before A:TFASET exists)'
            % (total, vstart, size, total - vstart - size, needs, SET_ROOM),
            "  and in the launchers' code that has run: %d of %d below the array (TFAG), %d of %d and %d of %d above (TFA or CLOCK)"
            % (k.sym['kh_end'][0] - ksym['KH'][0], holes['kh_len'], k.sym['kr_end'][0] - ksym['KR'][0], holes['kr_len'],
               k.sym['ks_end'][0] - ksym['KS'][0], holes['ks_len']),
            'Overlays'] + report
    text = '\n'.join(text)
    with open(os.path.join(out, 'budget.txt'), 'w') as f:
        f.write(text + '\n')
    meta = {'total': total, 'vstart': vstart, 'slot': size, 'holes': holes, 'needs': needs, 'opk': os.path.relpath(opk, ROOT).replace(os.sep, '/'), 'code': vstart, 'fixups': len(k.fix)}
    with open(os.path.join(out, 'build.json'), 'w') as f:
        json.dump(meta, f, indent=1)
    return text, meta


def psion_folder(opk, folder):
    """The pack's files as .OB3 procedures for RPLOAD (a real Organiser through a Comms Link)."""
    import shutil
    import subprocess
    tools = os.path.join(ROOT, '..', '..', 'Tools')
    tmp = folder + '_tmp'
    if os.path.isdir(tmp):
        shutil.rmtree(tmp)
    subprocess.run([sys.executable, os.path.join(tools, 'opk2files.py'), '-o', tmp, opk], check=True, capture_output=True)
    for f in os.listdir(tmp):
        if f.lower().endswith('.opl'):
            os.remove(os.path.join(tmp, f))
    subprocess.run([sys.executable, os.path.join(tools, 'mkrpdata.py'), tmp, '--title', 'PSION 2FA', '--run', 'TFA'],
                   check=True, capture_output=True)
    os.makedirs(folder, exist_ok=True)
    for f in os.listdir(tmp):
        shutil.copyfile(os.path.join(tmp, f), os.path.join(folder, f))
    shutil.rmtree(tmp)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=None)
    ap.add_argument('--kernel', default=None)
    ap.add_argument('--psion', action='store_true')
    a = ap.parse_args()
    out = os.path.abspath(a.out) if a.out else os.path.join(ROOT, 'build', 'game')
    kpath = os.path.abspath(a.kernel) if a.kernel else os.path.join(ROOT, 'src', 'kernel', 'kernel.asm')
    os.makedirs(out, exist_ok=True)
    try:
        text, _ = build(out, kpath)
    except (BuildError, pack.opl2opk.PackError) as e:
        sys.exit('build failed: %s' % e)
    print(text)
    if a.psion:
        psion_folder(os.path.join(out, 'TFA.opk'), os.path.join(ROOT, 'psion'))
        print('psion/: the files for RPLOAD')


if __name__ == '__main__':
    main()
