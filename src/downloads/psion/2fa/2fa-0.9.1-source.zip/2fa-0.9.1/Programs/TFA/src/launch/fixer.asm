; =====================================================================
; The kernel's fixer: read in from block TFAM just after the kernel (where
; the variables go, cleared later) and run once by the bootstrap with
; X = v%()-1. Adds the array's address to every word in the kernel's
; fix-up list (encoded right after this code: steps two a byte, as
; tools/build.py encode_fixups) and jumps to the kernel's first byte with D = ADDR(v%()).
; Position independent: relative branches and zero-page scratch only.
; =====================================================================
        include "../defs.inc"

V_BASE  = 1                     ; (offsets from v%()-1, as in boot.asm)
V_KLEN  = 7                     ; the kernel's length
V_ALL   = 11                    ; the kernel, this code and the list

fix:    stx  T6                 ; v%()-1
        ldd  V_BASE,x
        std  T0                 ; the array
        addd #$FFFF
        std  T8                 ; the last word fixed, less one: the array - 1
        addd V_KLEN,x           ; this code, less one
        addd #FIXLEN
        std  T2                 ; one before the next encoded byte
        ldd  T8
        addd V_ALL,x
        std  T4                 ; one before the end
.fx:    ldx  T2
        cpx  T4
        beq  .go
        ldab 1,x                ; two steps: 1-15 on and fix, 0 on 15
        inx
        stx  T2
        pshb
        lsrb
        lsrb
        lsrb
        lsrb
        bsr  .st
        pulb
        andb #15
        bsr  .st
        bra  .fx
.st:    clra
        tstb
        beq  .z
        bsr  .on
        xgdx                    ; X = the word to fix, less one
        ldd  1,x
        addd T0
        std  1,x
        rts
.z:     ldab #15
.on:    addd T8
        std  T8
        rts
.go:    ldx  T0                 ; the kernel's entry is its first byte
        pshx
        ldx  T6
        inx
        xgdx                    ; D = v%()
        rts
fix_end:
FIXLEN  = fix_end-fix
