# Psion 2FA (TFA)

Time-based two-factor codes (TOTP: six digits, 30 seconds, HMAC-SHA-1, RFC 6238) on every Organiser II from the 8K CM to the LZ64, in 6303 machine code, built from *Psion 2FA: time-based codes on the Organiser II* (the spec, `docs/spec.docx`, 20 Nov 2026). One 16K Datapak serves every model. The first version only, as asked: no stretch goals.

## Status (21 Nov 2026)

- **The whole first version is built** and tested in the emulator: six-digit codes for up to 50 accounts; the two-line and four-line code screens; the name menu; adding (the key editor and the check against a phone), renaming, deleting; Setup (the device for keys with moving the file, the zone, summer time on two lines, the PIN); the date check and the clock-went-back check; the built-in year 2000 fix (the clock screen and CLOCK); switching off after two minutes; Help and the self-test.
- **Codes are right**: against Node's own HMAC-SHA-1 on the RFC 4226/6238 values, the spec's sample key and 40 random keys; on screen, across changeovers, midnight, month and year ends, every row of the spec's clock table (to 2084), 50 accounts and a 64-character key.
- **Every ROM**: all 29 Organiser ROMs in the emulator (CM, XP, LA, LZ, LZ64; English, French, German, multilingual) start, add an account, show the right code, pass the self-test, and (two-line) run CLOCK.
- **The real Y2000FIX**: installed in the emulator from the supplied listing, its TIME and TFA's clock screen show the same date, and a clock set through it gives TFA the right codes.
- **Not yet checked**: anything only real hardware shows (below), and a site accepting a code typed from the Psion.

## Run

In Jape (https://www.jaapsch.net/psion/jape/jape.htm): **Select OPK file** → `build/game/TFA.opk` → **Create** → **Slot B**, then **Prog → Run → B:TFA**. CLOCK (two-line models) opens straight on the clock screen; INSERT it in the main menu to use it in place of TIME.

On a real Organiser: `python tools/build.py --psion` writes `psion/` (TFA, CLOCK, TFAG, TFAM as .OB3 and RPLOAD's list) for a Datapak through a Comms Link, as for the other games.

Test keys and their codes at fixed times: `docs/test_keys.md` (made by `node tools/testkeys.js --md docs/test_keys.md`; `node tools/testkeys.js --now` prints today's codes for comparing with the Psion and a phone).

## Using it

| Key on the code screen | Two lines | Four lines |
|---|---|---|
| MODE, EXE | the name menu | the name menu |
| UP, DOWN | the previous / next account | the three shown move by one |
| RIGHT | | the next codes, with `>` (any key back) |
| ON/CLEAR | leave (the account is remembered) | leave |

The name menu holds the accounts in the order added and **Tools** (Add, Rename, Delete, Setup, Help) last; Setup has Device, PIN, Zone, Summer and Clock (two lines) or Device, PIN, Zone (four). With many accounts the menu comes in pages: **More** goes to the next (the OS's menu holds about 252 characters).

Adding: the name (1-8 characters, not More or Tools, not one in use), then the key in the program's own editor (A-Z and 2-7, 16-64 characters, shown in groups of four with a count; anything else beeps; DEL removes one), then the first code with the seconds left: **Y** saves, **N** goes back to the key with everything still there.

## Build and test

```bash
python tools/build.py [--psion]
```

```bash
node tests/run_all.js
```

| Test | What it shows |
|---|---|
| `node ref/totp.js` | The reference against the spec's numbers: SHA-1, the RFC codes, base 32, the whole clock table |
| `t_engine.js` | The 6303's SHA-1, HMAC, cut and base 32 against the reference (RFC values, the sample key, 40 random keys) |
| `t_ui.js` | First run, adding, the code screens against the reference across a changeover, UP/DOWN, RIGHT, the menu, leaving and starting again, rename, delete (CM, XP, LA, LZ, LZ64) |
| `t_clock.js` | The spec's clock table read off the code screen (1942 and 1998, the zone, leap days, 2054, 2083, 2084), the remembered year, the year-00 fault |
| `t_clkscr.js` | The clock screen: 2083 stored as 1999, 2084 as 1972, 2026 as 1942 within a second of EXE; CLOCK; clock went back; four lines |
| `t_settings.js` | Moving the keys A: → C: → B:, summer time, the PIN (set, three wrong and the doubling wait, a wrong PIN that passes the check, change, off), the self-test |
| `t_menu.js` | Fifty accounts: the pages, every account's codes, a 64-character key, a kind not known (`------`) |
| `t_off.js` | Switching off after two minutes on the code screen, in a menu and at the PIN; the secrets zero while off; the PIN asked after; the OS's settings put back on leaving |
| `t_break.js` | Across midnight, a month end, the year end; year 00; the program pack and the keys' pack pulled out; A: full on a CM |
| `t_y2k.js` | Against the real Y2000FIX (`build/y2k`, from `ref/y2000fix`) |
| `t_leave.js` | Leaving TFA and CLOCK with ON/CLEAR held from 0.1 to 4 seconds: straight back to the menu (24 Nov: before, a press of over about a quarter of a second left a blank screen, or the LZ's pause pattern, until a key: OPL pauses when it sees ON down; the program now waits for it to come up) |
| `t_roms.js` | All 29 ROMs |
| `t_hidden.js` | The variables in the launchers' code, on all 29 ROMs: what runs again stays intact; TFA, CLOCK, TFA, CLOCK, TFA started and left cleanly |
| `t_stress.js` | Random keys: CM 1,585, XP 1,554, LZ64 2,764 keys; no crash, hang, stack error or change to the resident code |
| `m_mem.js` | The memory margin on the smallest machines (below) |
| `t_timing.js` | The spec's timing table (below) |
| `tests/probe/p1-p7.js` | The OS checks the spec asked for before relying on them: `docs/probes.md` |

## Measured

| | Spec's estimate | Measured |
|---|---|---|
| One SHA-1 block | 60 ms | 66 ms |
| First code for an account | 240 ms | 282 ms |
| Later codes | 120 ms | 144 ms |
| Start to the first code (from EXE on Run) | under 1 s | 1.2 s (0.5 s of it the launcher reading the program) |
| Three accounts cold (four lines) | about 1 s | 1.0 s ("Working..." until the codes now show) |
| The changeover | instant | 8-14 ms after the clock's tick |
| Array | 5,060 | 4,051 (and 258 bytes of variables in the launchers' code that has run) |
| Spare on a blank CM | about 1,040 | about 1,980 (CM 3.3), 2,020 (CM 2.4): `m_mem.js`, the largest other use of memory with which TFA still starts (the program itself runs out at 2,010) |
| Pack | 5,500 | 11,621 of 16,384 (the overlays and their fix-ups) |

## How it is built

- **Files on the pack**: TFA and CLOCK (OPL: check the free memory, "TFA NEEDS n BYTES MORE RAM"), TFAG (OPL: makes the array, pokes the bootstrap into its top, calls it), TFAM (the machine code: the resident part, its fixer and fix-ups, then twelve overlays). TFASET (settings, always A:) and TFAKEY (accounts, A:, B: or C:) are made by the program; both are ordinary Organiser files.
- **The array** (4,051 bytes): the resident code (3,282: start, the code screens, SHA-1/HMAC/base 32, the clock, the key file, the screen and key routines, the overlay loader) | the overlay slot (541) | the variables (228: account slot 0, the typed key, the record). The rest of the variables (258 bytes: the hashing buffers, the decoded key, the PIN, the small ones) live in the launchers' code that has run, as Spins and Connect 4 do: TFAG's code before its USR call (just below the array) and TFA's or CLOCK's before its call of TFAG and after it (just above); the start-up code checks that what runs again is where the build put it, and refuses with TFA ERROR 3 if TFAG was run some other way (`tests/t_hidden.js`, all 29 ROMs).
- **Overlays** (the spec planned none: the code came out at 7.4K, not 4.4K): seventeen, from 149 to 528 bytes, read from the pack into the slot when wanted: the date check, the clock screen and its editing, adding (with the key editor and the check as two more), rename, delete, Setup (device; zone and summer; the PIN's setting), the PIN's asking, Help, the Tools menu, reading and writing the settings, the name menu, and the PIN's scrambling. One overlay can call another and get back (the caller is read in again). While the codes show, the top of the slot holds account slots 1 and 2 (four lines); while the name menu shows, its list.
- **SHA-1**: the f functions folded into the round's add (the logic instructions leave the carry alone), the 5- and 30-bit rotations done with MUL; the first block of each hash kept per account, so a code costs two blocks.
- **The clock**: TM$TGET; days since 1970 × 2,880 + half-minutes, less the zone (and summer time on two lines). The year: 1900 + the byte, plus 28 until it reaches the last year seen (two lines). The clock is written right after the once-a-second tick (btb_nmfl), plus a second if the tick took half a second to come.
- **Switching off**: the program counts two idle minutes itself where it waits (and sets the OS's switch-off time to two minutes for the OS's own menus and editor); the OS's switch-off vector ($2058) is pointed at a few bytes that wipe the PIN and note it, so a PIN is asked after any switch-off, even inside an OS menu. The time and vector are put back on leaving.

## Where this build differs from the spec

- **Overlays** (above), so **the menus need the program pack** (with it pulled out the codes go on showing; MODE gives the system's NO PACK and leaves), and a **paged name menu** (the OS's menu takes about 252 characters: 28 names of 8 characters, not 51 items).
- **Renaming** writes the new record and then erases the old one, as the spec says, so the renamed account moves to the end of the list.
- **Changing the PIN** (on, change, off) rewrites every record, one at a time; a power cut part-way would leave some under the old PIN. A wrong PIN that passes the check shows wrong codes and writes nothing, except that an account added after it is scrambled under that PIN.
- **The wrong-PIN wait** doubles from 15 seconds to 4 minutes, then stays there.
- **Device**: moving refuses if the new device already holds TFAKEY (FILE EXISTS).
- **A: on a CM**: adding to A: is refused (OUT OF MEMORY) unless 400 bytes stay free, or TFA could not start again (`t_break.js`: a restart failed at 304 free).
- **The clock screen's years** run 1985-2099: 1984 would be stored as year byte 0, which the program refuses.
- **CLOCK on four lines** shows the date and time and says to set them with TIME.
- **Day names** come from the OS (FRI, VEN, FR), month names are English in the same case.
- **Help** is two pages of keys and Test (the self-test).
- **Summer time** is on two lines only, as planned: the LZ's daylight-saving switch does not move the stored time (`docs/probes.md`).

## Real hardware (what only it can show)

The clock against a phone over days and weeks; the keyboard feel (digits need SHIFT, except in the PIN); the time a pack read takes (overlays come from the pack); switching off and on; a code accepted by a real site. The spec's milestone 12: a week beside a phone on a CM and an LZ64.

## About this repository

One of the Psion Organiser II projects on Forgejo (`Daniel/Psion-*`). The build and test scripts expect the PsionII workspace layout:

```
PsionII/
  Emulator/          Jape, Jaap Scherphuis's emulator, with its ROM images (not in any repo:
                     https://www.jaapsch.net/psion/jape/jape.htm)
  Tools/             Daniel/Psion-Tools (opltran, opl2opk, RPBOOT/RPLOAD, ...)
  Programs/NAME/     this repository
```

`build/` is committed (except `build/probe/`), so the test harness has the exact images it was checked against.
