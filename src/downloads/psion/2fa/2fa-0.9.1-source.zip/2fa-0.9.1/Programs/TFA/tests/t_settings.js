'use strict';
// Setup: moving the key file between devices, summer time, the PIN (set, wrong, change, off),
// Help's self-test
const { UI, R } = require('./ui');
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
const A1 = ['GitHub', 'JBSW Y3DP EHPK 3PXP'], A2 = ['Google', 'GEZD GNBV GY3T QOJQ GEZD GNBV GY3T QOJQ'];

function codeOk(g, acct, label) {
  for (let i = 0; i < 300; i++) { const s = g.shown(); if (s && (g.four ? s.rows.length && s.cells >= 0 : true)) break; g.run(0.1); }
  g.run(0.8);
  let r = g.stable(() => ({ s: g.shown(), t: g.clock(), text: g.text() }));
  if (g.expect(acct[1], r.t).left >= 29) { g.run(1); }    // (just changed over: the new codes may still be being made)
  r = g.stable(() => ({ s: g.shown(), t: g.clock(), text: g.text() }));
  const e = g.expect(acct[1], r.t);
  const shownNow = g.four ? r.s.rows[0] && r.s.rows[0].code : r.s && r.s[0].now;
  const nm = g.four ? r.s.rows[0] && r.s.rows[0].name : r.s && r.s[0].name;
  ok(shownNow === e.now && nm === acct[0].toUpperCase(), `${label}: ${nm} ${shownNow} (want ${e.now})`);
}
const setup = (g, item) => { g.key('MODE', 0.6); g.toolsItem('Setup'); g.waitFor(/Zone/); g.key(item, 0.6); };
// the records of a file on a device, from the emulator's own file services: via the kernel
function count(g, dev) { g.poke('st_dev', dev); return g.call('kf_open') && g.peekw('kf_n'); }

for (const model of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'lz64']) {
  console.log('==', model);
  const four = /lz/.test(model);
  const g = new UI(model, { clock: four ? [126, 10, 19, 14, 31, 40] : [42, 10, 19, 14, 31, 40], packC: { type: 0, size: 16 } });
  g.start().confirmDate().add(...A1).add(...A2);
  g.key('UP', 1.2);
  codeOk(g, A1, 'two accounts on A:');
  // Device: A -> C (a blank Datapak in C:)
  setup(g, 'D');
  ok(g.has(/Keys on: A/), 'device screen: ' + g.lines()[0]);
  g.key('RIGHT', 0.3).key('RIGHT', 0.3);
  ok(g.has(/Keys on: C/), 'RIGHT RIGHT: C');
  g.key('EXE', 3);
  codeOk(g, A1, 'moved to C:, the codes the same');
  ok(g.peek('st_dev') === 2, 'the setting says C: (' + g.peek('st_dev') + ')');
  g.key('MODE', 0.6);
  ok(g.has(/GITHUB|Github/) && g.has(/GOOGLE|Google/), 'both names from C: ' + g.lines()[0]);
  g.key('ON', 0.6);
  // and back to B: (the program pack, a Datapak)
  setup(g, 'D'); g.key('LEFT', 0.3); g.key('EXE', 3);
  codeOk(g, A1, 'from B:');
  ok(g.peek('st_dev') === 1, 'moved to B:');
  // leave and start again: the keys are found on B:
  g.key('ON', 1); g.start(); g.run(1.5);
  codeOk(g, A1, 'started again: keys on B:');
  // summer time (two lines): the codes an hour back
  if (!four) {
    setup(g, 'S');
    ok(g.has(/Summer time: Off/), 'summer screen');
    g.key('RIGHT', 0.3);
    ok(g.has(/Summer time: On/), 'summer on');
    g.key('EXE', 1.5);
    g.summer = true;
    codeOk(g, A1, 'summer time: an hour back');
    setup(g, 'S'); g.key('RIGHT', 0.3); g.key('EXE', 1.5);
    g.summer = false;
    codeOk(g, A1, 'summer time off again');
  }
  // the PIN: set 2468
  setup(g, 'P');
  ok(g.has(/New PIN/), 'PIN: new');
  g.type('2468').key('EXE', 0.3);
  ok(g.has(/Again/), 'PIN: again');
  g.type('2468').key('EXE', 3);
  codeOk(g, A1, 'PIN set: the codes the same');
  // renaming a scrambled key (unscrambled by the old name, scrambled by the new): codes the same
  g.key('MODE', 0.6); g.toolsItem('Rename'); g.key('EXE', 0.6); g.waitFor(/Name:/);
  g.key('ON', 0.3).type('Hub').key('EXE', 2);
  codeOk(g, ['Hub', A1[1]], 'renamed with a PIN: the codes the same');
  g.key('MODE', 0.6); g.toolsItem('Rename'); g.key('H', 0.6); g.waitFor(/Name:/);
  g.key('ON', 0.3).type(A1[0]).key('EXE', 2);
  codeOk(g, A1, 'and back');
  // the records are kind B now, the key text scrambled
  g.key('ON', 1);
  g.start();
  ok(g.has(/PIN:/), 'PIN asked at start');
  // three wrong (choose ones whose check differs), then a wait
  const salt = g.read('st_salt', 4), check = g.peek('st_check');
  const chk = (pin) => { const h = R.sha1(Buffer.concat([Buffer.from(pin), Buffer.from(salt)])); return 48 + (h[0] >> 4); };
  const wrong = ['1111', '2222', '3333', '4444', '5555', '6666', '7777', '8888', '9999', '1234'].filter((p) => chk(p) !== check);
  ok(chk('2468') === check, 'the check digit matches the reference (' + String.fromCharCode(check) + ')');
  for (let i = 0; i < 3; i++) g.type(wrong[i]).key('EXE', 0.4);
  ok(g.has(/Wrong PIN/) && g.has(/Wait 1[45]s/), 'three wrong: ' + g.lines().join(' | '));
  g.run(16);
  ok(g.has(/PIN:/), 'after the wait the PIN is asked again');
  g.type(wrong[3]).key('EXE', 0.4);
  ok(g.has(/Wait (29|30)s/), 'the next wait doubles: ' + g.lines()[1]);
  g.run(31);
  g.type('2468').key('EXE', 2);
  codeOk(g, A1, 'the right PIN');
  // a wrong PIN that passes the check: codes wrong, nothing written
  const pass = ['0000', '0001', '0002', '0003', '0004', '0005', '0006', '0007', '0008', '0009', '0010', '0011', '0012', '0013', '0014', '0015', '0016', '0017', '0018', '0019', '0020', '0021', '0022', '0023', '0024', '0025', '0026', '0027', '0028', '0029', '0030', '0031', '0032', '0033', '0034', '0035', '0036', '0037', '0038', '0039', '0040'].find((p) => p !== '2468' && chk(p) === check);
  g.key('ON', 1); g.start();
  g.type(pass).key('EXE', 2);
  const r = g.stable(() => ({ s: g.shown(), t: g.clock() }));
  const e = g.expect(A1[1], r.t);
  ok((four ? r.s.rows[0].code : r.s[0].now) !== e.now, 'a wrong PIN that passes the check (' + pass + ') shows other codes');
  g.key('ON', 1);
  // change the PIN to 13579, then off
  g.start(); g.type('2468').key('EXE', 1.5);
  setup(g, 'P');
  g.key('C', 0.5);
  g.type('13579').key('EXE', 0.3).type('13579').key('EXE', 3);
  codeOk(g, A1, 'PIN changed: the codes the same');
  g.key('ON', 1); g.start(); g.type('13579').key('EXE', 1.5);
  codeOk(g, A1, 'the new PIN');
  setup(g, 'P'); g.key('O', 3);
  codeOk(g, A1, 'PIN off');
  g.key('ON', 1); g.start(); g.run(1.5);
  ok(!g.has(/PIN:/), 'no PIN asked');
  codeOk(g, A1, 'no PIN: the codes');
  // Help: the self-test
  g.key('MODE', 0.6); g.toolsItem('Help'); g.key('T', 3);
  ok(g.has(/Self-test OK/), 'self-test: ' + g.lines()[0]);
  g.key('EXE', 1.5);
  g.key('ON', 1);
}
console.log(fails ? fails + ' FAILED' : 'all ok');
process.exit(fails ? 1 : 0);
