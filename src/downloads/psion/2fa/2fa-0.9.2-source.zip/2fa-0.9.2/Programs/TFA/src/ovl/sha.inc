; SHA-1 of a short message (OV_STRM, OV_PIN, OV_HELP)

; sha_msg: SHA-1 of the B bytes at X (B < 56) -> sh_h
sha_msg:
        pshb
        pshx
        bsr  clrw
        ldd  #sh_w
        std  kv_to
        pulx
        pulb
        pshb
        bsr  copy
        pulb
; sha_msgw: SHA-1 of the B bytes already at sh_w (the rest of it zero) -> sh_h
sha_msgw:
        ldx  #sh_w
        abx
        ldaa #$80
        staa 0,x
        clra
        asld
        asld
        asld
        std  sh_w+62
        bsr  sha_init
        bra  sha_blk
