'use strict';
// node tests/walk2.js <model> "<keys>" ["<keys after re-running TFA>" ...]: like walk.js, but each
// further argument runs TFA again on the same machine first (R:<proc> picks another procedure)
const { TFA } = require('./lib');
const model = process.argv[2] || 'lz64';
const four = /lz/.test(model);
const g = new TFA(model, { clock: four ? [126, 10, 19, 14, 32, 7] : [42, 10, 19, 14, 32, 7] });
const show = (w) => console.log('--', w, '\n' + g.text());
let first = true;
for (const seq of process.argv.slice(3)) {
  let proc = 'TFA';
  const ks = seq.split(' ').filter(Boolean);
  if (ks[0] && ks[0].startsWith('R:')) proc = ks.shift().slice(2);
  if (!first) { g.run(1); }
  g.start(proc);
  first = false;
  show('start ' + proc);
  for (const k of ks) {
    if (k.startsWith('t:')) g.m.type(k.slice(2), 3, 4);
    else if (k.startsWith('w:')) g.run(+k.slice(2));
    else if (k === 's') { show('now'); continue; } else g.press(k, 3, 6);
    g.run(0.6);
    if (process.env.ALL) show(k);
  }
  show('end of sequence');
}
