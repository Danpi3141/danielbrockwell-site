'use strict';
// The clock screen (two lines: the built-in year 2000 fix), CLOCK, the date check and the
// clock-went-back check
const { UI, R } = require('./ui');
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };

// set the field values with the keys: from the clock screen's set mode (cursor on the day)
function setFields(g, want) {      // want: {day, mon, year, hour, min, sec} (real; mon 1-12, day 1-31)
  const cur = () => {
    const L = g.lines();
    const m = L[0].match(/^\S{3} ([ \d]\d) (\w{3}) (\d{4})/), t = L[1].match(/^(\d\d):(\d\d):(\d\d)/);
    const mons = 'JANFEBMARAPRMAYJUNJULAUGSEPOCTNOVDEC';
    return [+m[1], mons.indexOf(m[2].toUpperCase()) / 3 + 1, +m[3], +t[1], +t[2], +t[3]];
  };
  const target = [want.day, want.mon, want.year, want.hour, want.min, want.sec];
  const order = [1, 2, 0, 3, 4, 5];               // month and year first (the day's range depends on them)
  let field = 0;
  for (const f of order) {
    while (field !== f) { g.key(field < f ? 'RIGHT' : 'LEFT', 0.15); field += field < f ? 1 : -1; }
    for (let n = 0; n < 200 && cur()[f] !== target[f]; n++) g.key(cur()[f] < target[f] ? 'UP' : 'DOWN', 0.08);
  }
  return cur();
}

for (const model of ['cm', 'xp', 'la']) {
  console.log('==', model);
  const g = new UI(model, { clock: [42, 10, 19, 14, 32, 7] });
  g.start('CLOCK');
  ok(/^FRI 20 NOV 2026/.test(g.lines()[0]) && /^14:32:\d\d/.test(g.lines()[1]), 'CLOCK shows the real date: ' + g.lines().join(' | '));
  // set 31 Dec 2083 23:59:50: stored 1999
  g.key('EXE', 0.3);
  const got = setFields(g, { day: 31, mon: 12, year: 2083, hour: 23, min: 59, sec: 50 });
  ok(got.join() === '31,12,2083,23,59,50', 'fields set: ' + got);
  g.key('EXE', 1.5);
  let t = g.clock();
  ok(t[0] === 99 && t[1] === 11 && t[2] === 30 && t[3] === 23 && t[4] === 59 && t[5] >= 50 && t[5] <= 53, '2083 stored as 1999 (84 behind): ' + t);
  ok(g.peekw('st_year') === 2083, 'the year remembered: ' + g.peekw('st_year'));
  // 2084: stored 112 behind (1972)
  g.key('EXE', 0.3);
  setFields(g, { day: 1, mon: 1, year: 2084, hour: 0, min: 0, sec: 5 });
  g.key('EXE', 1.5);
  t = g.clock();
  ok(t[0] === 72 && t[1] === 0 && t[2] === 0, '2084 stored as 1972 (112 behind): ' + t);
  ok(/^SAT  1 JAN 2084/.test(g.lines()[0]), 'shown as 2084: ' + g.lines()[0]);
  // back to 20 Nov 2026 14:32:10 set "on the beat": stored 1942
  g.key('EXE', 0.3);
  setFields(g, { day: 20, mon: 11, year: 2026, hour: 14, min: 32, sec: 10 });
  g.key('EXE', 1.05);
  t = g.clock();
  ok(t.slice(0, 5).join() === '42,10,19,14,32' && t[5] >= 10 && t[5] <= 12, '2026 stored as 1942, within a second of EXE: ' + t);
  g.key('ON', 1);
  ok(!g.m.screenText().includes('2026'), 'ON leaves CLOCK');
  // TFA now: no date check (CLOCK set it), no accounts
  g.start();
  ok(g.has(/No accounts yet/), 'TFA after CLOCK: no date check: ' + g.lines()[0]);
  g.key('ON', 1);
  // the clock goes back a day: "Clock went back", then the date check; N opens the clock screen
  g.setClock([42, 10, 18, 14, 32, 7]);
  g.start();
  ok(g.has(/Clock went back/), 'clock went back: ' + g.lines()[0]);
  g.key('EXE', 0.5);
  ok(/^THU 19 NOV 2026/.test(g.lines()[0]) && /Is this right/.test(g.lines()[1]), 'then the date asked: ' + g.lines().join(' | '));
  g.key('N', 0.6);
  ok(/^THU 19 NOV 2026/.test(g.lines()[0]) && /^14:32/.test(g.lines()[1]), 'N: the clock screen (setting): ' + g.lines().join(' | '));
  setFields(g, { day: 20, mon: 11, year: 2026, hour: 14, min: 32, sec: 30 });
  g.key('EXE', 1);
  ok(g.has(/No accounts yet/), 'set: on to the program: ' + g.lines()[0]);
  t = g.clock();
  ok(t[0] === 42 && t[2] === 19, 'stored ' + t);
  g.key('ON', 1);
  // a clock set by hand to 1998 (56 behind) reads as 2026 as well
  g.setClock([98, 10, 19, 14, 32, 7]);
  g.start();
  ok(g.has(/No accounts yet/), '1998 reads as 2026: no date check');
  g.key('ON', 1);
}

// four lines: CLOCK shows the date and says to set it with TIME; the date check's N says the same
{
  console.log('== lz64');
  const g = new UI('lz64', { clock: [126, 10, 19, 14, 32, 7] });
  g.start('CLOCK');
  ok(/^FRI 20 NOV 2026/.test(g.lines()[0]) && /with TIME/.test(g.lines()[3]), 'CLOCK on four lines: ' + g.lines().join(' | '));
  g.key('EXE', 0.5);
  ok(/with TIME/.test(g.lines()[3]), 'EXE does not set it');
  g.key('ON', 1);
  g.start();
  g.key('N', 0.6);
  ok(g.has(/Set the clock/) && g.has(/with TIME/), 'date check N: ' + g.lines().join(' | '));
  g.key('EXE', 1);
}
console.log(fails ? fails + ' FAILED' : 'all ok');
process.exit(fails ? 1 : 0);
