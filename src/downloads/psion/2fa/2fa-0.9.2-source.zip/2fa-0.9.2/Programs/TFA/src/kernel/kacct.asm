; =====================================================================
; Accounts: a record's key decoded (and unscrambled), the slots on
; screen (one on two lines, three on four), their codes
; =====================================================================

SL_ACC  = 0                     ; the account number, 0 = empty
SL_OK   = 1                     ; 1: a kind this version makes codes for
SL_NAME = 2                     ; lbc, up to 8
SL_HALF = 11                    ; the kept half-results (hm_prep)
SL_NOW  = 51                    ; the code now (6 digits)
SL_NEXT = 57                    ; the next code
SL_SIZE = 63

; ac_secret: the key in kv_rec (kv_kp, kv_kl; and ac_kind, ac_name) -> kb_key. Carry set if the kind
; is not one this version knows (A or B).
ac_secret:
        ldx  kv_kp
        ldab kv_kl
        bsr  b32dec
        ldaa ac_kind+1
        cmpa #'A'
        beq  .ok
        cmpa #'B'
        bne  .no
        ovsub OV_STRM,0         ; B: scrambled by the PIN (from the kernel or an overlay)
.ok:    clc
        rts
.no:    sec
        rts

; ---- slots -----------------------------------------------------------
; sl_x: X = slot A (0-2)
sl_x:   adda #2                 ; (slots 1 and 2 are the top of the overlay slot, slot 0 just
        cmpa #3                 ; after it: in memory 1, 2, 0)
        blo  .s
        suba #3
.s:     ldab #SL_SIZE
        mul
        ldx  #kv_slots
        abx
        rts

; sl_fill: the slots from account kv_cur on (empty past the last), with
; their half-results. Carry set if a record could not be read.
sl_fill:
        clr  kv_res             ; (the slots overwrite the overlay slot's top)
        clra
.s:     staa kv_i
        bsr  sl_x
        stx  kv_sl
        ldab #SL_HALF
        bsr  zero               ; empty, no name, no codes
        ldab kv_i
        addb kv_cur             ; the account
        cmpb kf_n+1
        bhi  .nx                ; past the last
        stab kv_j
        clra
        bsr  kf_read
        bcs  .x
        ldx  kv_sl
        ldab kv_j
        stab SL_ACC,x
        ldd  kv_sl              ; the name
        addd #SL_NAME
        std  kv_to
        ldx  #ac_name
        ldab ac_name
        incb
        bsr  copy
        bsr  ac_secret
        bcs  .nx
        ldx  kv_sl
        inc  SL_OK,x
        ldab #SL_HALF
        abx
        bsr  hm_prep
.nx:    ldaa kv_i
        inca
        cmpa kv_nsl
        bne  .s
        clc
.x:     rts

; sl_codes: the codes now (step kv_cs) and next, for every slot that makes codes
; (sl_codesn: for the first A slots)
sl_codes:
        ldaa kv_nsl
sl_codesn:
        staa kv_n
        bsr  sl_nows
        bra  sl_nexts

; sl_nows: the codes now (step kv_cs) for the first kv_n slots
sl_nows:
        clra
.s:     staa kv_i
        bsr  sl_x
        tst  SL_OK,x
        beq  .nx
        stx  kv_sl
        ldd  kv_cs
        std  kv_step
        ldd  kv_cs+2
        std  kv_step+2
        ldab #SL_NOW
        bsr  sl_one
.nx:    ldaa kv_i
        inca
        cmpa kv_n
        bne  .s
        rts

; the code for kv_step into slot kv_sl + B
sl_one: ldx  kv_sl
        abx
        stx  kv_dst
        ldx  kv_sl
        ldab #SL_HALF
        abx
        bra  hm_code

; kv_step += 1
step1:  ldd  kv_step+2
        addd #1
        std  kv_step+2
        bcc  .x
        ldx  kv_step
        inx
        stx  kv_step
.x:     rts

; sl_shift: at a changeover: each next code becomes the code now (sl_nexts then
; makes the new next codes)
sl_shift:
        clra
.s:     staa kv_i
        bsr  sl_x
        stx  kv_sl
        ldab #SL_NOW
        abx
        stx  kv_to
        ldx  kv_sl
        ldab #SL_NEXT
        abx
        ldab #6
        bsr  copy
        ldaa kv_i
        inca
        cmpa kv_nsl
        bne  .s
        rts

; sl_nexts: the next codes (for kv_cs + 1) for the first kv_n slots
sl_nexts:
        clra
.s:     staa kv_i
        bsr  sl_x
        stx  kv_sl
        tst  SL_OK,x
        beq  .nx
        ldd  kv_cs
        std  kv_step
        ldd  kv_cs+2
        std  kv_step+2
        bsr  step1
        ldab #SL_NEXT
        bsr  sl_one
.nx:    ldaa kv_i
        inca
        cmpa kv_n
        bne  .s
        rts
