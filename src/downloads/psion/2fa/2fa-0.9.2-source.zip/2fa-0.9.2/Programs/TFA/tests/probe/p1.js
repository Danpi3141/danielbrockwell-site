'use strict';
// Probe 1: ED$EPOS buffer format and ON/CLEAR; MN$DISP with 51 items.
const { Probe } = require('./plib');
for (const model of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'lz64']) {
  const p = new Probe(model);
  const m = p.m;
  console.log('==', model, 'base', p.base.toString(16));
  const buf = p.buf();
  p.lbc(buf, 'Name:');
  m.poke(0x2187, 2); m.write(0x2188, [0x41, 0x42]);
  p.call('DP$EMIT', { a: 12 });
  p.call('DP$PRNT', { x: buf + 1, b: 5 });
  let r = p.call('ED$EPOS', { a: 0, b: 8, s0: 99 }, () => { m.runSeconds(0.3); m.type('CD'); m.press('EXE'); });
  console.log('epos EXE ->', r, 'len', m.peek(0x2187), JSON.stringify(Buffer.from(m.read(0x2188, 6)).toString('latin1')));
  r = p.call('ED$EPOS', { a: 0, b: 8, s0: 99 }, () => {
    m.runSeconds(0.2); m.press('ON'); m.runSeconds(0.2);
    console.log('after one ON:\n' + p.scr() + '\nlen ' + m.peek(0x2187));
    m.press('ON');
  });
  console.log('epos ON ON ->', r, 'len', m.peek(0x2187));
  // MODE with bit 7 clear: exits?
  m.poke(0x2187, 2); m.write(0x2188, [0x41, 0x42]);
  r = p.call('ED$EPOS', { a: 0, b: 8, s0: 99 }, () => { m.runSeconds(0.2); m.press('MODE'); });
  console.log('epos MODE ->', r, 'len', m.peek(0x2187));

  // MN$DISP: 50 names + Tools
  let a = buf;
  const names = [];
  for (let i = 1; i <= 50; i++) names.push((i % 3 === 0 ? 'Longname' : 'Acct') + String(i).padStart(2, '0').slice(0, 2));
  names.push('Tools');
  names.forEach((n, i) => { a = p.lbc(a, n.slice(0, 8)); m.pokew(a, i + 1); a += 2; });
  m.poke(a, 0);
  console.log('menu string bytes', a + 1 - buf);
  p.call('DP$EMIT', { a: 12 });
  r = p.call('MN$DISP', { x: buf, d: 0x1003 }, () => {
    m.runSeconds(0.5); console.log('menu:\n' + p.scr());
    m.press('DOWN'); m.press('DOWN'); m.runSeconds(0.2); console.log('down2:\n' + p.scr());
    m.press('T'); m.runSeconds(0.3); console.log('after T:\n' + p.scr());
    if (!m.screenText().includes('Tools') || m.dbg.pc() < 0x8000) m.press('EXE');
  });
  console.log('menu T ->', r, 'S0 item', r.s0);
  r = p.call('MN$DISP', { x: buf, d: 0x1003 }, () => { m.runSeconds(0.3); m.press('MODE'); });
  console.log('menu MODE ->', r);
  r = p.call('MN$DISP', { x: buf, d: 0x1003 }, () => { m.runSeconds(0.3); m.press('UP'); m.runSeconds(0.2); console.log('UP:\n' + p.scr()); m.press('EXE'); });
  console.log('menu UP EXE ->', r);
  r = p.call('MN$DISP', { x: buf, d: 0x1003 }, () => { m.runSeconds(0.3); m.press('L'); m.runSeconds(0.2); console.log('L:\n' + p.scr()); m.press('L'); m.runSeconds(0.2); console.log('L L:\n' + p.scr()); m.press('ON'); });
  console.log('menu L L ON ->', r);
}
