'use strict';
// Probe 3: records of up to 75 characters written, read, found and erased on A:, B: and C:
const { Probe } = require('./plib');
const models = process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'lz64'];
for (const model of models) {
  const p = new Probe(model, { packC: { type: 0, size: 16 } });   // a blank 16K Datapak in C:
  const m = p.m;
  const buf = p.buf();
  const nameAt = buf + 400, rec = buf + 200;
  const show = (what, r) => console.log(model, what, r.c ? 'ERR ' + r.b : 'ok', 'A=' + r.a.toString(16), 'X=' + r.x);
  for (const dev of ['A', 'B', 'C']) {
    p.lbc(nameAt, dev + ':TFAKEY');
    let r = p.call('FL$OPEN', { x: nameAt });
    show(dev + ' open (absent)', r);
    r = p.call('FL$CRET', { x: nameAt });
    show(dev + ' create', r);
    const type = r.a;
    for (let i = 1; i <= 3; i++) {
      const text = 'Name' + i + '\tA\t' + 'JBSWY3DPEHPK3PXP'.repeat(4).slice(0, 64 - i);
      p.lbc(rec, text.slice(0, 75));
      r = p.call('FL$WRIT', { x: rec });
      if (r.c) show(dev + ' write ' + i, r);
    }
    r = p.call('FL$SIZE');
    show(dev + ' size (records in X)', r);
    // reopen fresh, read record 2
    r = p.call('FL$OPEN', { x: nameAt });
    show(dev + ' reopen type ' + type.toString(16), r);
    r = p.call('FL$RSET', { d: 2 });
    r = p.call('FL$READ', { x: rec });
    console.log(model, dev, 'read 2:', r.c ? 'ERR ' + r.b : JSON.stringify(p.str(rec)));
    // erase record 2, then read 2 again
    r = p.call('FL$RSET', { d: 2 });
    r = p.call('FL$ERAS');
    show(dev + ' erase 2', r);
    r = p.call('FL$SIZE');
    show(dev + ' size after erase', r);
    r = p.call('FL$RSET', { d: 2 });
    r = p.call('FL$READ', { x: rec });
    console.log(model, dev, 'read 2 after erase:', r.c ? 'ERR ' + r.b : JSON.stringify(p.str(rec).slice(0, 12)));
    r = p.call('FL$RSET', { d: 3 });
    r = p.call('FL$READ', { x: rec });
    console.log(model, dev, 'read 3 after erase:', r.c ? 'ERR ' + r.b : JSON.stringify(p.str(rec).slice(0, 12)));
    // switch device between: open A then read this one again by its type
    r = p.call('FL$RSET', { d: 1 });
    r = p.call('FL$READ', { x: rec });
    console.log(model, dev, 'read 1:', r.c ? 'ERR ' + r.b : JSON.stringify(p.str(rec).slice(0, 12)));
  }
  // two files open alternately: A:TFASET and C:TFAKEY by FL$SETP+FL$RECT
  p.lbc(nameAt, 'A:TFASET');
  let r = p.call('FL$CRET', { x: nameAt });
  const tset = r.a;
  p.lbc(rec, 'settings'); p.call('FL$WRIT', { x: rec });
  p.lbc(nameAt, 'C:TFAKEY');
  r = p.call('FL$OPEN', { x: nameAt });
  const tkey = r.a;
  console.log(model, 'types: TFASET', tset.toString(16), 'C:TFAKEY', tkey.toString(16));
  p.call('FL$SETP', { b: 0 }); p.call('FL$RECT', { b: tset }); p.call('FL$RSET', { d: 1 });
  r = p.call('FL$READ', { x: rec });
  console.log(model, 'A by setp/rect:', r.c ? 'ERR ' + r.b : JSON.stringify(p.str(rec)));
  p.call('FL$SETP', { b: 2 }); p.call('FL$RECT', { b: tkey }); p.call('FL$RSET', { d: 2 });
  r = p.call('FL$READ', { x: rec });
  console.log(model, 'C by setp/rect:', r.c ? 'ERR ' + r.b : JSON.stringify(p.str(rec).slice(0, 12)));
  // FL$FREC: record length
  p.call('FL$SETP', { b: 2 }); p.call('FL$RECT', { b: tkey });
  r = p.call('FL$FREC', { d: 1 });
  console.log(model, 'frec 1:', r.c ? 'ERR ' + r.b : 'len ' + r.a);
  // pack pulled out
  m.removePack(1);
  p.call('FL$SETP', { b: 2 }); p.call('FL$RECT', { b: tkey }); p.call('FL$RSET', { d: 1 });
  r = p.call('FL$READ', { x: rec });
  console.log(model, 'C pulled read:', r.c ? 'ERR ' + r.b : 'ok?');
}
