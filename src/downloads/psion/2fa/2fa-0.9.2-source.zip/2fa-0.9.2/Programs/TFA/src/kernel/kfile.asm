; =====================================================================
; Files: A:TFASET (one record of settings) and TFAKEY on A:, B: or C:
; (one record an account: name TAB kind TAB key). Every call that can
; fail is checked: carry set and the OS's message shown (fl_err).
; =====================================================================

; ---- the settings ---------------------------------------------------
; The record: "T" then the 13 bytes st_dev..st_day in hex.


; fopen: X = a file's name: FL$OPEN, then its record type made current (FL$OPEN
; returns it in A but leaves the old one current: docs/probes.md)
fopen:  os   FL$OPEN
        bcs  frx
frect:  tab
        os   FL$RECT
        clc
frx:    rts
; fcret: the same for a new file
fcret:  os   FL$CRET
        bcc  frect
        rts

; a_room: B = the device: on A: the record in kv_rec must leave A_KEEP bytes free,
; or TFA could not start again (A: and the program share a CM's memory). Carry
; set and B = 254 (OUT OF MEMORY) if not.
a_room: tstb
        bne  .ok
        ldd  RTA_SP
        subd ALA_FREE
        subd #A_KEEP
        bcs  .no
        subb kv_rec
        sbca #0
        bcc  .ok
.no:    ldab #254
        sec
        rts
.ok:    clc
        rts

; ---- errors --------------------------------------------------------
; the OS's message for error B, a key, carry set
fl_err: pshb
        bsr  cls
        pulb
        os   ER$MESS            ; (it waits for SPACE itself)
        sec
        rts

; ---- the key file ---------------------------------------------------
kf_name: fcl "A:TFAKEY"

; kf_nm: the name with device A = 0, B = 1, C = 2 put in
kf_nm:  ldx  #kf_name
        addb #'A'
        stab 1,x
        rts

; kf_open: open TFAKEY on st_dev: kf_n = the number of accounts; carry set
; if it is not there (no message)
kf_open:
        ldab st_dev
kf_opb: bsr  kf_nm
        bsr  fopen
        bcs  .x
        os   FL$SIZE
        stx  kf_n
        clc
.x:     rts

; kf_find: the key file on st_dev, else on A:, B:, C: (st_dev then names it);
; carry set if on none (kf_n = 0)
kf_find:
        bsr  kf_open
        bcc  .x
        clrb
.d:     pshb
        bsr  kf_opb
        pulb
        bcc  .f
        incb
        cmpb #3
        bne  .d
        ldx  #0
        stx  kf_n
        sec
.x:     rts
.f:     stab st_dev
        rts

; kf_read: account D (1..kf_n) -> kv_rec, parsed into ac_name, ac_kind,
; the key's place (kv_kp, kv_kl); carry set (message shown) on a failure
kf_read:
        std  kv_tmp
        bsr  kf_open
        bcs  fl_err             ; (the OS's error: no pack, file not found...)
        ldd  kv_tmp
        os   FL$RSET
        ldx  #kv_rec
        os   FL$READ
        bcs  fl_err
; ac_parse: kv_rec -> ac_name, ac_kind (lbc), the key's place in kv_rec (kv_kp, kv_kl)
ac_parse:
        ldx  #kv_rec+1
        stx  kv_src
        ldab kv_rec
        stab kv_cnt
        ldx  #ac_name
        ldaa #8
        bsr  .fld
        ldx  #ac_kind
        ldaa #1
        bsr  .fld
        ldx  kv_src             ; the key: left where it is (kv_kp, kv_kl)
        stx  kv_kp
        ldab kv_cnt
        cmpb #KEY_MAX
        bls  .k
        ldab #KEY_MAX
.k:     stab kv_kl
        clc
        rts
; the next field (to a TAB or the end), at most A characters, into the lbc at X
.fld:   staa T2
        clr  0,x
        stx  kv_dst
.c:     tst  kv_cnt
        beq  .x
        dec  kv_cnt
        ldx  kv_src
        ldab 0,x
        inx
        stx  kv_src
        cmpb #9
        beq  .x
        ldx  kv_dst
        ldaa 0,x
        cmpa T2
        bhs  .c
        inca
        staa 0,x
        pshb
        tab
        abx
        pulb
        stab 0,x
        bra  .c
.x:     clc
        rts

; kf_add: kv_rec appended to the key file (made if it is not there)
kf_add: ldab st_dev
        bsr  a_room
        bcs  fl_err
        bsr  kf_open
        bcc  .w
        ldab st_dev
        bsr  kf_nm
        bsr  fcret
        bcs  fl_err
.w:     ldx  #kv_rec
        os   FL$WRIT
        bcs  fl_err
        os   FL$SIZE
        stx  kf_n
        clc
        rts
