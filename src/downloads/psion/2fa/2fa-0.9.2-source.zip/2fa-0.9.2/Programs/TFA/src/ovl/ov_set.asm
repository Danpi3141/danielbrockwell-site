; =====================================================================
; OV_SET: Setup > Device: the device for keys (moving the file)
; =====================================================================
        include "ovhead.inc"
        jmp  set_dev

set_dev:
        ldaa st_dev
        staa kv_d
.d:     bsr  cls
        bsr  pri
        fcl  "Keys on: "
        ldaa kv_d
        adda #'A'
        bsr  emit
        ldaa #1
        clrb
        bsr  at
        bsr  pri
        fcl  "LEFT RIGHT EXE"
.k:     bsr  getk
        cmpb #K_ON
        beq  .x
        cmpb #K_EXE
        beq  .go
        ldaa kv_d
        cmpb #K_LEFT
        beq  .l
        cmpb #K_RIGHT
        bne  .k
        inca                    ; A, B, C round
        cmpa #3
        bne  .s
        clra
        bra  .s
.l:     deca
        bpl  .s
        ldaa #2
.s:     staa kv_d
        bra  .d
.go:    ldaa kv_d
        cmpa st_dev
        beq  .x
        bsr  kf_open            ; keys to move?
        bcs  .new               ; none: only the setting changes
        bsr  mv_file
        bcs  .x
.new:   ldaa kv_d
        staa st_dev
        ovjump OV_INIT,1
.x:     rts

; mv_file: TFAKEY copied from st_dev to kv_d, checked, then erased from st_dev.
; Carry set (message shown) if anything fails; then the copy is removed.
mv_file:
        bsr  cls
        bsr  pri
        fcl  "Working..."
        ldab kv_d               ; the new device must have none
        bsr  kf_opb
        bcs  .mk
        ldab #235               ; FILE EXISTS
        bra  fl_err
.mk:    ldab kv_d
        bsr  kf_nm
        bsr  fcret
        bcs  .err
        bsr  kf_open            ; the count, from the old file
        ldaa kf_n+1
        staa kv_n
        ldaa #1
.cp:    staa kv_j               ; each record read from the old and written to the new
        cmpa kv_n
        bhi  .chk
        tab
        clra
        bsr  kf_read
        bcs  .undo
        bsr  .tonew
        ldab kv_d               ; (room on A:?)
        bsr  a_room
        bcs  .err2
        ldx  #kv_rec
        os   FL$WRIT
        bcs  .err2
        ldaa kv_j
        inca
        bra  .cp
.chk:   ldaa #1                 ; each record read back and compared
.ck:    staa kv_j
        cmpa kv_n
        bhi  .del
        tab
        clra
        bsr  kf_read            ; the old one, copied aside
        bcs  .undo
        ldx  #kv_rec
        ldd  #sh_v              ; (84 bytes free then: sh_v and sh_w)
        std  kv_to
        ldab #KREC
        bsr  copy
        bsr  .tonew
        ldab kv_j
        clra
        os   FL$RSET
        ldx  #kv_rec
        os   FL$READ
        bcs  .err2
        ldx  #sh_v              ; the same, byte for byte?
        stx  kv_src
        ldx  #kv_rec
        ldab kv_rec
        incb
.cmp:   ldaa 0,x
        inx
        pshx
        ldx  kv_src
        cmpa 0,x
        bne  .bad1
        inx
        stx  kv_src
        pulx
        decb
        bne  .cmp
        ldaa kv_j
        inca
        bra  .ck
.del:   ldab st_dev             ; all there: the old file goes
        bsr  kf_nm
        os   FL$DELN
        bcs  .err
        clc
        rts
.bad1:  pulx
        ldab #245               ; WRITE PACK ERR
.err2:  pshb
        bsr  .rmnew
        pulb
.err:   bra  fl_err
.undo:  bsr  .rmnew
        sec
        rts
.tonew: ldab kv_d               ; the new file current
        bsr  kf_nm
        bsr  fopen
        rts
.rmnew: ldab kv_d               ; the copy removed
        bsr  kf_nm
        os   FL$DELN
        rts
