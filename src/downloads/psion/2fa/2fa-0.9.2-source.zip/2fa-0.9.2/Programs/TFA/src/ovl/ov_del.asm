; =====================================================================
; OV_DEL: deleting an account
; =====================================================================
        include "ovhead.inc"
        jmp  del_acc


del_acc:
        clr  kv_tools
        ovsub OV_NAME,0
        bcs  .x
        stab kv_self
        clra
        bsr  kf_read
        bcs  .x
        bsr  cls
        bsr  pri
        fcl  "Delete "
        ldx  #ac_name
        bsr  prs
        ldaa #'?'
        bsr  emit
        ldaa #1
        clrb
        bsr  at
        bsr  pri
        fcl  "Y/N"
        bsr  ysno
        bcc  .x
        ldaa kv_self
        tab
        clra
        bsr  kf_del
        ldaa #1
        staa kv_cur
.x:     rts
        include "recs.inc"
