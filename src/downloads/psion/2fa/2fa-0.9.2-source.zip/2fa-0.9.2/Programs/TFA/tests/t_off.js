'use strict';
// Switching off: two minutes idle on the code screen and inside an OS menu; the secrets wiped
// while off; ON gives fresh codes (after the PIN if set); leaving puts the OS's settings back
const { UI } = require('./ui');
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
const A1 = ['GitHub', 'JBSW Y3DP EHPK 3PXP'];

function secretsZero(g) {
  const a = g.addr('kv_sec0'), b = g.addr('kv_sec1');
  for (let x = a; x < b; x++) if (g.m.peek(x)) return false;
  return true;
}
function codeOk(g, label) {
  for (let i = 0; i < 50 && !g.shown(); i++) g.run(0.1);
  g.run(0.8);
  const r = g.stable(() => ({ s: g.shown(), t: g.clock() }));
  const e = g.expect(A1[1], r.t);
  const c = g.four ? r.s && r.s.rows[0] && r.s.rows[0].code : r.s && r.s[0].now;
  ok(c === e.now, `${label}: ${c} (want ${e.now})`);
}

for (const model of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'xp', 'lz64']) {
  console.log('==', model);
  const four = /lz/.test(model);
  const g = new UI(model, { clock: four ? [126, 10, 19, 14, 31, 40] : [42, 10, 19, 14, 31, 40] });
  const tcnt0 = g.m.peekw(0x20CD), sof0 = g.m.peekw(0x2058);
  g.start().confirmDate().add(...A1);
  ok(g.m.peekw(0x20CD) === 120, 'switch-off time two minutes while running');
  // idle on the code screen: still on at 115 s, off by 125 s
  g.run(115);
  ok(g.m.isOn(), 'on after 115 s idle');
  g.run(10);
  ok(!g.m.isOn(), 'off after two minutes idle');
  ok(secretsZero(g), 'the secrets are zero while off');
  g.run(600);                   // ten minutes off
  g.press('ON', 3, 10); g.run(1.5);
  ok(g.m.isOn(), 'on again');
  codeOk(g, 'fresh codes after ten minutes off');
  // idle inside the name menu: the OS switches off; ON gives the menu back, then a key: codes
  g.key('MODE', 0.6);
  g.run(125);
  ok(!g.m.isOn(), 'off from inside the name menu');
  ok(g.peek('kv_woke') === 1, 'the switch-off seen through the vector');
  g.run(60);
  g.press('ON', 3, 10); g.run(1);
  g.key('EXE', 1.5);
  codeOk(g, 'after switching on inside the menu');
  // with a PIN: asked after switching on
  g.key('MODE', 0.6); g.toolsItem('Setup'); g.waitFor(/Zone/); g.key('P', 0.6);
  g.type('8642').key('EXE', 0.3).type('8642').key('EXE', 3);
  codeOk(g, 'PIN set');
  g.run(125);
  ok(!g.m.isOn() && secretsZero(g), 'off, and the PIN wiped with the rest');
  g.press('ON', 3, 10); g.run(1);
  ok(g.has(/PIN:/), 'switched on: the PIN asked');
  g.type('8642').key('EXE', 1.5);
  codeOk(g, 'codes after the PIN');
  // a menu left idle with a PIN set: on again, a key: the PIN first
  g.key('MODE', 0.6);
  g.run(125);
  g.press('ON', 3, 10); g.run(0.8);
  g.key('EXE', 0.8);
  ok(g.has(/PIN:/), 'switched on inside a menu: the PIN before anything else (' + g.lines()[0] + ')');
  g.type('8642').key('EXE', 1.5);
  codeOk(g, 'codes after that PIN');
  // the key wait of the PIN itself switches off too
  g.key('ON', 1);
  g.start();
  ok(g.has(/PIN:/), 'PIN at start');
  g.run(125);
  ok(!g.m.isOn(), 'off from the PIN screen');
  g.press('ON', 3, 10); g.run(1);
  ok(g.has(/PIN:/), 'PIN again');
  g.type('8642').key('EXE', 1.5);
  // leaving restores the OS's switch-off time and vector
  g.key('ON', 1.5);
  ok(g.m.peekw(0x20CD) === tcnt0 && g.m.peekw(0x2058) === sof0, `left: switch-off time ${g.m.peekw(0x20CD)} (was ${tcnt0}), vector ${g.m.peekw(0x2058).toString(16)} (was ${sof0.toString(16)})`);
  ok(secretsZero(g), 'left: the secrets zero');
}
console.log(fails ? fails + ' FAILED' : 'all ok');
process.exit(fails ? 1 : 0);
