'use strict';
// Against the real Y2000FIX (Jaap Scherphuis, 1998; ref/y2000fix, translated by Tools/opl2opk.py
// into build/y2k/Y2K.opk): installed on a two-line Organiser, its TIME and TFA's clock screen show
// the same date and time, and a clock set through either gives the same codes.
const path = require('path');
const { execFileSync } = require('child_process');
const { UI, R } = require('./ui');
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
const opk = path.join(__dirname, '..', 'build', 'y2k', 'Y2K.opk');
for (const model of ['cm', 'xp', 'la']) {
  console.log('==', model);
  const g = new UI(model, { clock: [42, 10, 19, 14, 31, 40] });
  g.m.insertPack(opk, 1);                       // Y2000FIX's installer in C:
  g.m.runProc('TIMEINST', 'C');
  for (let i = 0; i < 100 && !/loaded/i.test(g.text()); i++) g.run(0.2);
  ok(/Time TSR loaded/i.test(g.text()), 'Y2000FIX installed: ' + g.lines()[0]);
  g.key('EXE', 1);
  // the TIME item of the main menu (T: TIME is the only T item on an English two-line menu)
  for (let i = 0; i < 3; i++) g.press('ON', 3, 6);
  g.key('T', 1);
  const fix = g.lines();
  // TFA's clock screen
  for (let i = 0; i < 3; i++) g.press('ON', 3, 6);
  g.start('CLOCK');
  const ours = g.lines();
  ok(/2026/.test(fix.join(' ')) && /NOV/i.test(fix.join(' ')), 'Y2000FIX TIME: ' + fix.join(' | '));
  ok(/^FRI 20 NOV 2026/.test(ours[0]), 'TFA CLOCK:      ' + ours.join(' | '));
  const day = (s) => (s.match(/(\d+)\s+NOV\s+2026/i) || [])[1];
  ok(day(fix.join(' ')) === day(ours.join(' ')), 'the same date');
  g.key('ON', 1);
  // set the clock through Y2000FIX's TIME (MODE, RIGHT RIGHT to the year, UP: 2027, EXE stores):
  // TFA's clock screen and its codes read it the same way
  for (let i = 0; i < 3; i++) g.press('ON', 3, 6);
  g.key('T', 1); g.key('MODE', 0.4); g.key('RIGHT', 0.3); g.key('RIGHT', 0.3); g.key('UP', 0.4); g.key('EXE', 1);
  const t = g.clock();
  ok(t[0] === 43, 'Y2000FIX stored 2027 as 1943: ' + t.join(','));
  for (let i = 0; i < 3; i++) g.press('ON', 3, 6);
  g.start('CLOCK');
  ok(/^SAT 20 NOV 2027/.test(g.lines()[0]), 'TFA CLOCK reads it as 2027: ' + g.lines()[0]);
  g.key('ON', 1);
  g.start();
  g.confirmDate();
  g.add('GitHub', 'JBSW Y3DP EHPK 3PXP');
  g.run(1);
  const r = g.stable(() => ({ s: g.shown(), t: g.clock() }));
  const e = g.expect('JBSW Y3DP EHPK 3PXP', r.t);
  ok(r.s[0].now === e.now && R.clockStep(r.t, { lines: 2 }).year === 2027, 'codes for 2027 from the clock Y2000FIX set: ' + r.s[0].now + ' (want ' + e.now + ')');
  g.key('ON', 1);
}
console.log(fails ? fails + ' FAILED' : 'all ok');
process.exit(fails ? 1 : 0);
