; =====================================================================
; HMAC-SHA-1 TOTP (RFC 2104, 4226, 6238) and base 32 (RFC 4648)
; =====================================================================

; hm_prep: the key in kb_key (kb_len bytes, at most 40) -> the 40 bytes at X:
; the state after the first block of the inner hash, then of the outer hash.
; These depend only on the key: every code from then on costs two blocks.
hm_prep:
        stx  kv_slot
        ldaa #$36
        bsr  .one
        ldaa #$5C
.one:   staa kv_pad
        ldx  #sh_w              ; the key padded to 64 bytes, xor the pad
        clrb
.fill:  ldaa kv_pad
        cmpb kb_len
        bhs  .put
        pshx
        ldx  #kb_key
        abx
        eora 0,x
        pulx
.put:   staa 0,x
        inx
        incb
        cmpb #64
        bne  .fill
        bsr  sha_init
        bsr  sha_blk
        ldx  #sh_h
        ldd  kv_slot
        bsr  cpy20
        ldd  kv_slot
        addd #20
        std  kv_slot
        rts

; hm_code: X = the 40 bytes made by hm_prep, kv_step = the step (4 bytes;
; the top four of the eight are zero) -> six digits (ASCII) at kv_dst.
hm_code:
        stx  kv_slot
        bsr  sha_set            ; the inner hash goes on from its first block
        bsr  clrw
        ldd  kv_step
        std  sh_w+4
        ldd  kv_step+2
        std  sh_w+6
        ldaa #$80
        staa sh_w+8
        ldd  #(64+8)*8
        std  sh_w+62
        bsr  sha_blk
        bsr  clrw               ; the outer hash: its first block's state, then the inner result
        ldx  #sh_h
        ldd  #sh_w
        bsr  cpy20
        ldaa #$80
        staa sh_w+20
        ldd  #(64+20)*8
        std  sh_w+62
        ldx  kv_slot
        ldab #20
        abx
        bsr  sha_set
        bsr  sha_blk
        ldab sh_h+19            ; the cut: four bytes from the offset in the last nibble
        andb #15
        ldx  #sh_h
        abx
        ldd  0,x
        anda #$7F
        std  T0
        ldd  2,x
        std  T2
        ldab #6                 ; six digits, the last first
.dg:    pshb
        bsr  div10
        adda #'0'
        pulb
        pshb
        ldx  kv_dst
        decb
        abx
        staa 0,x
        pulb
        decb
        bne  .dg
        rts

clrw:   ldx  #sh_w
        ldab #64
.c:     clr  0,x
        inx
        decb
        bne  .c
        rts

; T0-T3 (32 bits) / 10: the quotient in T0-T3, the remainder in A
div10:  clra
        ldab #32
        stab T4
.l:     asl  T3
        rol  T2
        rol  T1
        rol  T0
        rola
        cmpa #10
        blo  .n
        suba #10
        inc  T3
.n:     dec  T4
        bne  .l
        rts

; b32dec: X = base-32 text (A-Z, 2-7), B = its length -> kb_key, kb_len.
; Five bits a character; the bits left over at the end are dropped.
b32dec: stx  kv_src
        stab kv_cnt
        clr  kb_len
        clra
        clrb
        std  T0                 ; the bits so far
        clr  T2                 ; how many
.c:     tst  kv_cnt
        beq  .x
        ldx  kv_src
        ldab 0,x
        inx
        stx  kv_src
        dec  kv_cnt
        subb #'A'
        bcc  .v                 ; A-Z: 0-25
        addb #'A'-'2'+26        ; 2-7: 26-31
.v:     andb #31
        ldaa #5
.sh:    asl  T1
        rol  T0
        deca
        bne  .sh
        orab T1
        stab T1
        ldab T2
        addb #5
        stab T2
        cmpb #8
        blo  .c
        subb #8
        stab T2
        stab T3                 ; the byte: (bits >> count) & 255
        ldd  T0
        tst  T3
        beq  .o
.r:     lsrd
        dec  T3
        bne  .r
.o:     ldx  #kb_key
        pshb
        ldab kb_len
        abx
        pulb
        stab 0,x
        inc  kb_len
        bra  .c
.x:     rts
