; =====================================================================
; OV_CLK: the clock screen (two lines: setting it is OV_CSET)
; =====================================================================
        include "ovhead.inc"
        jmp  clk_screen
        jmp  clk_setnow

clk_screen:
        bsr  ck_read
        bcs  .set               ; no date to show: straight to setting it
        bsr  ck_tod
        bsr  cls
        bsr  pr_date
        ldaa #1
        clrb
        bsr  at
        bsr  pr_time
        tst  kv_four
        beq  .k
        ldaa #3
        clrb
        bsr  at
        bsr  pri
        fcl  "Set it with TIME"
.k:     bsr  pollk
        tstb
        beq  .t
        cmpb #K_ON
        beq  .x
        cmpb #K_EXE
        bne  .t
        tst  kv_four
        bne  .t
.set:   bsr  clk_setnow         ; then the clock shown again
        tst  kv_four
        beq  clk_screen
        rts
.t:     ldaa ck_t+5             ; redrawn when the second changes
        psha
        bsr  ck_read
        pula
        bcs  .x
        cmpa ck_t+5
        beq  .k
        bra  clk_screen
.x:     rts
; clk_setnow: the fields edited (OV_CSET), then (EXE) the clock set
clk_setnow:
        ovsub OV_CSET,0
        bcs  .x
        bra  ck_set
.x:     rts


; ck_set: the clock set to the edit fields, right after its once-a-second
; tick (the NMI clears btb_nmfl), so no update falls in the middle. If the
; tick took half a second or more to come, the time set is a second on.
ck_set: ldaa TMW_FRAM+1
        staa kv_fr
        ldaa #1
        staa BTB_NMFL
.w:     tst  BTB_NMFL
        bne  .w
        ldaa TMW_FRAM+1
        suba kv_fr
        cmpa #10
        blo  .now
        bsr  ed_sec1
.now:   bsr  ed_store
        ldx  #kv_tset           ; (straight away: the next tick is a second off)
        ldd  0,x
        std  TMB_YEAR
        ldd  2,x
        std  TMB_YEAR+2
        ldd  4,x
        std  TMB_YEAR+4
        ldd  ed_year            ; the year it means, and today, remembered
        std  st_year
        bsr  ck_read
        bcs  .x
        ldd  ck_days
        std  st_day
        clr  kv_new
        ovsub OV_INIT,1
.x:     rts

; the edit fields a second on
ed_sec1:
        ldx  #ed_sec
        ldab #60
        bsr  .inc
        bne  .x
        dex
        bsr  .inc               ; minute
        bne  .x
        dex
        ldab #24
        bsr  .inc               ; hour
        bne  .x
        bsr  mdays
        ldx  #ed_day
        bsr  .inc
        bne  .x
        ldx  #ed_mon
        ldab #12
        bsr  .inc
        bne  .x
        ldd  ed_year
        addd #1
        std  ed_year
.x:     rts
.inc:   inc  0,x                ; Z set if it went round to 0
        cmpb 0,x
        bne  .r
        clr  0,x
.r:     rts

        include "clkcom.inc"
