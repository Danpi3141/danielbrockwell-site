// Reference for Psion 2FA (TFA): base 32, HMAC-SHA-1 TOTP, and the Organiser clock -> step rule
// of the spec (docs/spec.txt, "Time"). Node's crypto does the hashing; sha1Block() is a plain
// one-block SHA-1 compression for checking the 6303's intermediate states.
'use strict';
const crypto = require('crypto');

const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

// base-32 text (spaces ignored, any case) -> bytes; left-over bits dropped
function b32decode(text) {
  const out = [];
  let acc = 0, bits = 0;
  for (const ch of text.toUpperCase().replace(/[\s=]/g, '')) {
    const v = B32.indexOf(ch);
    if (v < 0) throw new Error('not base 32: ' + ch);
    acc = (acc << 5) | v; bits += 5;
    if (bits >= 8) { bits -= 8; out.push((acc >> bits) & 255); }
    acc &= (1 << bits) - 1;
  }
  return Buffer.from(out);
}

function b32encode(buf) {
  let s = '', acc = 0, bits = 0;
  for (const b of buf) {
    acc = (acc << 8) | b; bits += 8;
    while (bits >= 5) { bits -= 5; s += B32[(acc >> bits) & 31]; }
    acc &= (1 << bits) - 1;
  }
  if (bits) s += B32[(acc << (5 - bits)) & 31];
  return s;
}

function stepBytes(step) {
  const b = Buffer.alloc(8);
  b.writeUInt32BE(Math.floor(step / 4294967296), 0);
  b.writeUInt32BE(step >>> 0, 4);
  return b;
}

// HOTP/TOTP: the six-digit code for a key (bytes) at a step
function code(key, step, digits = 6) {
  const h = crypto.createHmac('sha1', key).update(stepBytes(step)).digest();
  const o = h[19] & 15;
  const n = ((h[o] & 0x7f) << 24) | (h[o + 1] << 16) | (h[o + 2] << 8) | h[o + 3];
  return String(n % 10 ** digits).padStart(digits, '0');
}

function hmac(key, msg) { return crypto.createHmac('sha1', key).update(msg).digest(); }
function sha1(msg) { return crypto.createHash('sha1').update(msg).digest(); }

// one SHA-1 compression: state (5 words) and a 64-byte block -> new state
function sha1Block(state, block) {
  const w = new Array(80);
  for (let i = 0; i < 16; i++) w[i] = block.readUInt32BE(i * 4);
  for (let i = 16; i < 80; i++) { const x = w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16]; w[i] = ((x << 1) | (x >>> 31)) >>> 0; }
  let [a, b, c, d, e] = state;
  for (let i = 0; i < 80; i++) {
    let f, k;
    if (i < 20) { f = (b & c) | (~b & d); k = 0x5A827999; } else if (i < 40) { f = b ^ c ^ d; k = 0x6ED9EBA1; } else if (i < 60) { f = (b & c) | (b & d) | (c & d); k = 0x8F1BBCDC; } else { f = b ^ c ^ d; k = 0xCA62C1D6; }
    const t = (((a << 5) | (a >>> 27)) + f + e + k + w[i]) >>> 0;
    e = d; d = c; c = ((b << 30) | (b >>> 2)) >>> 0; b = a; a = t;
  }
  return [state[0] + a, state[1] + b, state[2] + c, state[3] + d, state[4] + e].map((v) => v >>> 0);
}
const SHA1_IV = [0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0];

// ---- the clock (spec, "Time") ----
const DAYS_BEFORE = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
const leap = (y) => y % 4 === 0;            // 1970-2099

function daysSince1970(y, mon, day) {       // mon 0-11, day 0-30
  let d = 365 * (y - 1970) + Math.floor((y - 1969) / 4);
  d += DAYS_BEFORE[mon] + (mon > 1 && leap(y) ? 1 : 0) + day;
  return d;
}

// The real year from the year byte. lines 4: 1900 + byte. lines 2: 1900 + byte, plus 28 until
// it reaches the remembered year. A byte of 0 is refused (null).
function realYear(byte, lines, remembered = 2026) {
  if (byte === 0) return null;
  let y = 1900 + byte;
  if (lines === 2) while (y < remembered) y += 28;
  return y;
}

// clock bytes [Y,M,D,h,m,s] -> {step, left, year} ; zone in quarter hours ahead of UTC; summer: +1 h
function clockStep(t, { lines = 4, remembered = 2026, zone = 0, summer = false } = {}) {
  const y = realYear(t[0], lines, remembered);
  if (y === null) return null;
  const days = daysSince1970(y, t[1], t[2]);
  const half = t[3] * 120 + t[4] * 2 + (t[5] >= 30 ? 1 : 0);
  const step = days * 2880 + half - zone * 30 - (summer ? 120 : 0);
  const left = t[5] >= 30 ? 60 - t[5] : 30 - t[5];
  return { step, left, year: y };
}

// a Date (UTC) -> the step
function stepOf(date) { return Math.floor(date.getTime() / 30000); }

module.exports = { B32, b32decode, b32encode, code, hmac, sha1, sha1Block, SHA1_IV, stepBytes, daysSince1970, realYear, clockStep, stepOf, DAYS_BEFORE };

if (require.main === module) {
  // the spec's own checks
  const ok = (c, m) => { if (!c) { console.log('FAIL', m); process.exitCode = 1; } else console.log('ok  ', m); };
  ok(sha1('abc').toString('hex') === 'a9993e364706816aba3e25717850c26c9cd0d89d', 'sha1 abc');
  ok(sha1('').toString('hex') === 'da39a3ee5e6b4b0d3255bfef95601890afd80709', 'sha1 empty');
  const rk = Buffer.from('12345678901234567890');
  const hc = ['755224', '287082', '359152', '969429', '338314', '254676', '287922', '162583', '399871', '520489'];
  hc.forEach((c, i) => ok(code(rk, i) === c, 'hotp ' + i + ' ' + c));
  [[59, '287082'], [1111111109, '081804'], [1111111111, '050471'], [1234567890, '005924'], [2000000000, '279037']]
    .forEach(([t, c]) => ok(code(rk, Math.floor(t / 30)) === c, 'totp ' + t + ' ' + c));
  ok(b32decode('JBSW Y3DP EHPK 3PXP').toString('hex') === '48656c6c6f21deadbeef', 'b32 JBSW');
  ok(b32decode('GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ').equals(rk), 'b32 rfc');
  const st = clockStep([126, 10, 19, 14, 32, 7]);
  ok(st.step === 59839504 && st.left === 23, 'step 20 Nov 2026 14:32:07 = ' + st.step);
  ok(stepOf(new Date(Date.UTC(2026, 10, 20, 14, 32, 7))) === 59839504, 'step via Date');
  const jk = b32decode('JBSWY3DPEHPK3PXP');
  ok(code(jk, 59839504) === '787941' && code(jk, 59839505) === '187523', 'JBSW sample ' + code(jk, 59839504) + ' ' + code(jk, 59839505));
  // spec clock table (two-line clock bytes)
  const rows = [
    [[42, 10, 19, 14, 32, 7], {}, 59839504, 23], [[98, 10, 19, 14, 32, 7], {}, 59839504, 23],
    [[42, 10, 19, 14, 32, 7], { zone: 4 }, 59839384, 23],
    [[42, 11, 30, 23, 59, 59], {}, 59958719, 1], [[43, 0, 0, 0, 0, 0], {}, 59958720, 30],
    [[44, 1, 27, 23, 59, 59], {}, 61179839, 1], [[44, 1, 28, 12, 0, 0], {}, 61181280, 30],
    [[44, 2, 0, 0, 0, 0], {}, 61182720, 30],
    [[70, 0, 0, 0, 0, 0], { remembered: 2053 }, 88361280, 30],
    [[99, 11, 30, 23, 59, 59], { remembered: 2083 }, 119917439, 1],
    [[72, 0, 0, 0, 0, 0], { remembered: 2083 }, 119917440, 30],
  ];
  rows.forEach(([t, o, s, l]) => { const r = clockStep(t, Object.assign({ lines: 2 }, o)); ok(r.step === s && r.left === l, 'clock ' + t + ' ' + JSON.stringify(o) + ' -> ' + r.step + '/' + r.left); });
}
