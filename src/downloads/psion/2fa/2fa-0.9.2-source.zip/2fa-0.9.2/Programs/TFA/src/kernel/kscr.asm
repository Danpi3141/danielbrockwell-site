; =====================================================================
; Screen, keys, menus, messages; switching off
; =====================================================================

; ---- display -------------------------------------------------------
cls:    ldaa #12
emit:   os   DP$EMIT
        rts
; at: A = line, B = column -> the cursor there (not shown)
at:     pshb
        ldab kv_w
        mul
        pula
        aba
        clrb
        os   DP$STAT
        rts
; clear line A, the cursor at its start
clrl:   pshb
        ldx  #cl_code
        tab
        abx
        ldaa 0,x
        bsr  emit
        pulb
        rts
cl_code: fcb 14,15,22,23
; print the text after the call (a length byte, then the text)
pri:    pulx
        ldab 0,x
        inx
        os   DP$PRNT
        jmp  0,x
; print the lbc at X
prs:    ldab 0,x
        inx
; print B characters at X
prb:    tstb
        beq  .x
        os   DP$PRNT
.x:     rts
; B spaces
spaces: tstb
        beq  .x
        ldaa #' '
        bsr  emit
        decb
        bra  spaces
.x:     rts
; print the lbc at X in a field of B characters (padded with spaces on the right)
prf:    pshb
        ldab 0,x
        pshb
        bsr  prs
        pulb                    ; the length
        pula                    ; the width
        sba
        bls  .x
        tab
        bra  spaces
.x:     rts
; A = 0-99 as two digits
pr2:    clrb
.t:     cmpa #10
        blo  .d
        suba #10
        incb
        bra  .t
.d:     psha
        tba
        adda #'0'
        bsr  emit
        pula
        adda #'0'
        bra  emit
; the seconds left (ck_left) in two characters
secs2:  ldaa ck_left
; A = 0-99 in two characters, a space before one digit
pr2s:   cmpa #10
        bhs  pr2
        psha
        ldaa #' '
        bsr  emit
        pula
        adda #'0'
        bra  emit
; D as a number (no padding)
prnum:  ldx  #kv_nbuf
        os   UT$UTOB
        ldx  #kv_nbuf
        bra  prb
; a six-digit code at X as two groups of three: "787 941"
prcode: ldab #3
        os   DP$PRNT
        ldaa #' '
        bsr  emit
        ldab #3
        os   DP$PRNT
        rts

; ---- keys ----------------------------------------------------------
; pollk: B = a key (letters in upper case) if there is one; else B = 0 after
; the next 50 ms frame. After two minutes with no key the Organiser is
; switched off, and the program starts again (woke) when it is switched on.
pollk:  ldx  TMW_TCNT           ; the OS's own count never runs out here
        stx  TMW_TOUT
t_idle: os   KB$TEST            ; (tests stop here)
        tstb
        bne  .key
        slp
        ldaa TMW_FRAM+1
        cmpa kv_fr
        beq  .x
        staa kv_fr
        ldx  kv_idle
        inx
        stx  kv_idle
        cpx  #20*IDLE_SECS
        blo  .x
        bsr  swoff
        bra  woke
.x:     clrb
        rts
.key:   os   KB$GETK
        ldx  #0
        stx  kv_idle
upper:  cmpb #'a'
        blo  .x
        cmpb #'z'
        bhi  .x
        subb #32
.x:     rts
; getk: wait for a key (as pollk)
getk:   bsr  pollk
        tstb
        beq  getk
        rts

; yes or no: carry set for Y; N and ON/CLEAR clear it; anything else beeps
ysno:   bsr  getk
        cmpb #'Y'
        beq  .y
        cmpb #'N'
        beq  .n
        cmpb #K_ON
        beq  .n
        bsr  beep
        bra  ysno
.y:     sec
        rts
.n:     clc
        rts
beep:   ldaa #16
        bra  emit

; ---- menus ---------------------------------------------------------
; menu: X = a menu (items: lbc name + word; a 0 byte ends it), drawn by
; the OS from the top of the screen. Out: B = the item number, carry set if
; ON/CLEAR (or MODE) left it.
menu:   pshx
        bsr  cls
        pulx
        ldd  #$1003             ; ON, MODE and EXE end it
        os   MN$DISP
        bsr  chkwoke
        cmpb #K_EXE
        bne  .no
        ldab T0+1               ; the item
        clc
        rts
.no:    sec
        rts

; after any wait in the OS: if the Organiser was switched off meanwhile,
; start again from the PIN and the code screen
chkwoke:
        tst  kv_woke
        bne  woke
        rts

; ---- switching off -------------------------------------------------
; the OS calls this through its switch-off vector ($2058) whenever the
; Organiser switches off (by itself in an OS wait, or swoff): the secrets
; are wiped first. Flags and registers are kept.
sof_hook:
        psha
        pshb
        pshx
        tpa
        psha
        ldx  T0                 ; (the OS's scratch kept)
        pshx
        ldx  #kv_slot0          ; everything but the overlay slot's top (a menu's list may be there)
        ldd  #kv_sec1
        bsr  zr
        ldx  #kh_sec0
        ldd  #kh_sec1
        bsr  zr
        pulx
        stx  T0
        inc  kv_woke
        pula
        tap
        pulx
        pulb
        pula
        fcb  $7E                ; jmp to the OS's own routine (set at start)
sof_go: fdb  0

swoff:  bsr  wipe
        os   BT$SWOF
        ldx  #0                 ; (on again: the idle count starts afresh)
        stx  kv_idle
        rts

; wipe the secrets: the decoded key, the kept half-results and codes, the
; typed key, the PIN, the hash's working values, the record
wipe:   clr  kv_res             ; (two of the slots are the overlay slot's top)
        ldx  #kv_sec0
        ldd  #kv_sec1
        bsr  zr
        ldx  #kh_sec0
        ldd  #kh_sec1
        bra  zr
; wipe the key material only, not the PIN (before the name menu is built over two slots)
wipe_k: ldx  #kv_sec0
        ldd  #kv_sec1
        bsr  zr
        ldx  #kh_sec0
        ldd  #kh_pin
; zero the bytes from X up to D
zr:     std  T0
.l:     cpx  T0
        beq  .x
        clr  0,x
        inx
        bra  .l
.x:     rts

; ---- messages ------------------------------------------------------
; the OS's message for error B, then a key
errmsg: os   ER$MESS
        rts
