; =====================================================================
; OV_DATE: the date check at start, the clock fault
; =====================================================================
        include "ovhead.inc"
        jmp  ck_check
        jmp  ck_fault

ck_check:
        bsr  ck_read
        bcs  ck_fault
        tst  kv_new
        bne  .ask
        ldd  ck_days
        subd st_day
        bcc  .x
        bsr  cls
        bsr  pri
        fcl  "Clock went back"
        bsr  getk
.ask:   bsr  cls                ; "FRI 20 Nov 2026" / "Is this right? Y"
        bsr  ck_tod
        bsr  pr_date
        ldaa #1
        clrb
        bsr  at
        bsr  pri
        fcl  "Is this right? Y"
        bsr  ysno
        bcc  .no
        clr  kv_new
        ldd  ck_days
        std  st_day
        ovjump OV_INIT,1
.no:    tst  kv_four
        bne  ck_time
        ovjump OV_CLK,1         ; two lines: the clock screen, setting
.x:     rts

; the clock cannot be read: "Clock year is 00" / "Set the clock"
ck_fault:
        bsr  cls
        bsr  pri
        fcl  "Clock year is 00"
        ldaa #1
        clrb
        bsr  at
        bsr  pri
        fcl  "Set the clock"
        bsr  getk
        tst  kv_four
        bne  ck_time
        ovjump OV_CLK,1
; four lines: the clock is set with the Organiser's TIME
ck_time:
        bsr  cls
        bsr  pri
        fcl  "Set the clock"
        ldaa #1
        clrb
        bsr  at
        bsr  pri
        fcl  "with TIME"
        bsr  getk
        bra  leave
        include "clkcom.inc"
