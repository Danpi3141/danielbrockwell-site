; =====================================================================
; OV_NAME: the name menu (in pages; its list at the top of the overlay slot)
; =====================================================================
        include "ovhead.inc"
        jmp  nm_pick

MENU_ROOM = 252                 ; the names' text plus a space each, More and Tools included

nm_pick:
        bsr  wipe_k             ; (the key material: the list goes where two of the slots are)
        ldaa #1
.page:  staa kv_pg              ; the first account on this page
        staa kv_j
        ldx  #kv_menu
        stx  kv_to
        clr  kv_pn              ; names on this page
        ldaa #MENU_ROOM-5       ; room: 5 kept for More
        tst  kv_tools
        beq  .r
        suba #6                 ; and 6 for Tools
.r:     staa kv_room
        bsr  kf_open
        bcs  .end
.n:     ldaa kv_j
        cmpa kf_n+1
        bhi  .end
        tab
        clra
        os   FL$RSET
        ldx  #kv_rec
        os   FL$READ
        bcs  .end
        bsr  ac_parse
        ldaa ac_name            ; room for it?
        inca
        cmpa kv_room
        bhi  .more
        nega
        adda kv_room
        staa kv_room
        ldx  #ac_name
        bsr  m_add
        inc  kv_pn
        inc  kv_j
        bra  .n
.more:  ldx  #m_more
        bsr  m_add
.end:   tst  kv_tools
        beq  .z
        ldx  #m_tools
        bsr  m_add
.z:     ldx  kv_to              ; the end of the list
        clr  0,x
        ldx  #kv_menu
        bsr  menu
        bcs  .x
        cmpb kv_pn
        bhs  .other
        addb kv_pg              ; an account
        clc
.x:     rts
.other: ldaa kv_j               ; More (if accounts remain), else Tools
        cmpa kf_n+1
        bhi  .tl
        cmpb kv_pn
        bne  .tl
        bra  .page
.tl:    clrb
        clc
        rts

; m_add: the lbc at X added to the menu at kv_to (with a word 0)
m_add:  ldab 0,x
        incb
        pshb
        bsr  copy
        pulb
        ldx  kv_to
        abx
        clr  0,x
        clr  1,x
        inx
        inx
        stx  kv_to
        rts

m_more: fcl  "More"
m_tools: fcl "Tools"
