'use strict';
// Leaving with ON/CLEAR: however long it is held down, straight back to the Organiser's menu (the OPL
// that called the program would pause, a blank screen until a key, if it saw ON still down).
//   node tests/t_leave.js [model or ROM...]
const { UI } = require('./ui');
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
for (const model of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'cm24', 'xp', 'la', 'lz', 'lz64']) {
  const four = /lz/.test(model);
  const g = new UI(model, { clock: four ? [126, 10, 19, 14, 31, 40] : [42, 10, 19, 14, 31, 40] });
  g.start().confirmDate();
  let first = true;
  for (const [proc, hold] of [['TFA', 2], ['TFA', 3], ['TFA', 6], ['TFA', 15], ['TFA', 40], ['TFA', 80]].concat(four ? [] : [['CLOCK', 3], ['CLOCK', 30]])) {
    if (!first) { g.start(proc); if (/Is this right/.test(g.text())) g.key('Y', 1); }
    first = false;
    let paused = false, seen = 0;
    g.m.keyDown('ON'); g.m.runTicks(hold); g.m.keyUp('ON');
    for (let i = 0; i < 60; i++) { g.run(0.1); if (/EDIT|RUN|EXEC|START|NEU/i.test(g.text())) { seen = i + 1; break; } }
    paused = !seen;
    ok(!paused && g.m.isOn() && !/ERR/.test(g.text()), `${model} ${proc}, ON held ${hold * 50} ms: ${seen ? 'at the menu' : 'screen ' + JSON.stringify(g.text())}`);
    if (paused) { g.key('EXE', 1.5); }
    for (let i = 0; i < 3; i++) g.press('ON', 3, 8);
    g.run(0.5);
  }
}
console.log(fails ? fails + ' FAILED' : 'all ok');
process.exit(fails ? 1 : 0);
