; =====================================================================
; The clock -> the step (spec "Time"): days since 1970 * 2880 + the
; half-minutes today, less the zone (and summer time on two lines).
; =====================================================================

; ck_read: the clock now -> ck_t, ck_year, ck_days, kv_step, ck_left.
; Carry set: the clock cannot be read as a date (year byte 0, or before 1970).
ck_read:
        ldx  #ck_t
        os   TM$TGET
; ck_calc: the same from the six bytes in ck_t
ck_calc:
        ldab ck_t               ; the year byte
        beq  .bad               ; 0: rolled over, or 1900 (no use)
        clra
        addd #1900
        tst  kv_four
        bne  .y
.y28:   std  T0                 ; two lines: add 28 until it reaches the year last seen
        subd st_year
        bcc  .y1
        ldd  T0
        addd #28
        bra  .y28
.y1:    ldd  T0
.y:     std  ck_year
        andb #3
        stab T3                 ; 0 in a leap year
        ldd  ck_year
        subd #1970
        bcs  .bad
        stab T2                 ; n = whole years since 1970 (0-129)
        ldaa #109               ; 365 n = 256 n + 109 n
        mul
        adda T2
        std  T4
        ldab T2                 ; + the leap days before this year: (n + 1) / 4
        incb
        lsrb
        lsrb
        clra
        addd T4
        std  T4
        ldx  #ck_db             ; + the days before this month
        ldab ck_t+1
        cmpb #12
        bhs  .bad
        aslb
        abx
        ldd  T4
        addd 0,x
        ldx  ck_t+1             ; (month, day)
        cpx  #$0200             ; March on in a leap year: one more
        blo  .nl
        tst  T3
        bne  .nl
        addd #1
.nl:    addb ck_t+2             ; + the day of the month (0-30)
        adca #0
        std  ck_days
        ldx  #2880              ; the step: days * 2880 ...
        os   UT$UMUL
        std  kv_step
        stx  kv_step+2
        ldaa ck_t+5             ; the seconds left: 30 - s, or 60 - s from 30 on
        ldab #30
        cmpa #30
        blo  .s
        ldab #60
.s:     sba
        nega
        staa ck_left
        ldaa ck_t+3             ; + the half-minutes today
        ldab #120
        mul
        std  T0
        ldab ck_t+4
        clra
        asld
        addd T0
        pshb                    ; (seconds 30 on: one more)
        ldab ck_t+5
        cmpb #30
        pulb
        blo  .h
        addd #1
.h:     bsr  st_add
        ldab st_zone            ; - 30 for each quarter hour ahead of UTC
        ldaa #30
        tstb
        bpl  .zp
        negb
        mul
        bsr  st_add
        bra  .zs
.zp:    mul
        bsr  st_sub
.zs:    tst  kv_four            ; - an hour for summer time (two lines)
        bne  .ok
        ldaa st_flags
        anda #FL_SUM
        beq  .ok
        ldd  #120
        bsr  st_sub
.ok:    ldd  ck_year            ; the year last seen moves on
        subd st_year
        bcs  .x
        ldd  ck_year
        std  st_year
.x:     clc
        rts
.bad:   sec
        rts

; kv_step += D
st_add: addd kv_step+2
        std  kv_step+2
        bcc  .x
        ldx  kv_step
        inx
        stx  kv_step
.x:     rts
; kv_step -= D
st_sub: std  T0
        ldd  kv_step+2
        subd T0
        std  kv_step+2
        bcc  .x
        ldx  kv_step
        dex
        stx  kv_step
.x:     rts

; days before each month (not a leap year)
ck_db:  fdb  0,31,59,90,120,151,181,212,243,273,304,334
