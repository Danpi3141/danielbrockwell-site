; =====================================================================
; OV_HELP: Help: the keys, and the self-test (the published values)
; =====================================================================
        include "ovhead.inc"
        jmp  help

help_m: fcl  "Keys"
        fdb  0
        fcl  "Test"
        fdb  0
        fcb  0
help:   ldx  #help_m
        bsr  menu
        bcs  .x
        tstb
        bne  selftest
        ldx  #help_t            ; pages of two lines, a key between
.p:     ldab 0,x
        beq  .x
        pshx
        bsr  cls
        pulx
        bsr  prs
        pshx
        ldaa #1
        clrb
        bsr  at
        pulx
        bsr  prs
        pshx
        bsr  getk
        pulx
        cmpb #K_ON
        bne  .p
.x:     rts

help_t: fcl  "MODE: accounts"
        fcl  "UP DOWN: others"
        fcl  "EXE: the menu"
        fcl  "ON: leave"
        fcl  "Tools Add: type"
        fcl  "key from site"
        fcl  "Key: A-Z, 2-7"
        fcl  "SHIFT for digits"
        fcl  "Compare the code"
        fcl  "with a phone"
        fcl  "Keep backup"
        fcl  "codes elsewhere"
        fcb  0

; selftest: SHA-1 of "abc", and the RFC 4226 key's codes at steps 0 and
; 37,037,036; "Self-test OK" or which failed
selftest:
        bsr  cls
        bsr  pri
        fcl  "Testing..."
        ldx  #st_abc
        ldab #3
        bsr  sha_msg
        ldx  #sh_h
        ldd  #$A999
        subd 0,x
        bne  .f1
        ldd  #$3E36
        subd 2,x
        bne  .f1
        ldx  #st_key            ; the key: "12345678901234567890"
        ldd  #kb_key
        std  kv_to
        ldab #20
        stab kb_len
        bsr  copy
        clra
        bsr  sl_x
        stx  kv_sl
        ldab #SL_HALF
        abx
        bsr  hm_prep
        ldx  #0
        stx  kv_step
        stx  kv_step+2
        ldx  #st_c0
        bsr  .code
        bne  .f2
        ldx  #37037036/65536
        stx  kv_step
        ldx  #37037036&65535
        stx  kv_step+2
        ldx  #st_c1
        bsr  .code
        bne  .f3
        bsr  cls
        bsr  pri
        fcl  "Self-test OK"
        bra  .k
.f1:    ldaa #'1'
        bra  .f
.f2:    ldaa #'2'
        bra  .f
.f3:    ldaa #'3'
.f:     psha
        bsr  cls
        bsr  pri
        fcl  "Test failed: "
        pula
        bsr  emit
.k:     bra  getk
.code:  stx  kv_src             ; the code made, against the 6 digits at X: Z if the same
        ldx  #kv_nbuf
        stx  kv_dst
        ldx  kv_sl
        ldab #SL_HALF
        abx
        bsr  hm_code
        ldx  #kv_nbuf
        ldab #6
.c:     ldaa 0,x
        pshx
        ldx  kv_src
        cmpa 0,x
        bne  .ne
        inx
        stx  kv_src
        pulx
        inx
        decb
        bne  .c
        rts
.ne:    pulx
        rts

st_abc: fcc  "abc"
st_key: fcc  "12345678901234567890"
st_c0:  fcc  "755224"
st_c1:  fcc  "081804"
        include "sha.inc"
