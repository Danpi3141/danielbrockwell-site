; =====================================================================
; OV_CSET: the clock's fields edited (two lines: the built-in year 2000 fix)
; =====================================================================
        include "ovhead.inc"
        jmp  clk_set

clk_set:
        bsr  ck_read            ; start from the clock, or 1 Jan 2026 if it cannot be read
        bcc  .r
        ldx  #2026
        stx  ck_year
        ldx  #ck_t
        ldab #6
        bsr  zero
.r:     bsr  ck_tod
        clr  kv_f
.d:     bsr  cls
        bsr  pr_date
        ldaa #1
        clrb
        bsr  at
        bsr  pr_time
        ldx  #ed_cur            ; the cursor under the field's last character
        ldab kv_f
        abx
        ldaa 0,x
        ldab #$81
        os   DP$STAT
.k:     bsr  getk
        cmpb #K_ON
        beq  .x
        cmpb #K_EXE
        beq  .set
        ldaa kv_f
        cmpb #K_LEFT
        bne  .rt
        deca
        bpl  .f
        ldaa #5
        bra  .f
.rt:    cmpb #K_RIGHT
        bne  .ud
        inca
        cmpa #6
        bne  .f
        clra
.f:     staa kv_f
        bra  .d
.ud:    cmpb #K_UP
        beq  .up
        cmpb #K_DOWN
        bne  .k
        bsr  ed_down
        bra  .cl
.up:    bsr  ed_up
.cl:    bsr  ed_clamp
        bra  .d
.x:     sec                     ; ON/CLEAR: carry set, nothing set
        rts
.set:   clc                     ; EXE: OV_CLK sets the clock
        rts

; the cursor's position for each field: day, month, year, hour, minute, second
ed_cur: fcb  5,9,14,16+1,16+4,16+7

; the field kv_f up by one (round within its range)
ed_up:  bsr  ed_fld
        cmpa #2
        beq  .y
        inc  0,x
        ldab 0,x
        cmpb T2
        blo  .x
        clr  0,x
.x:     rts
.y:     ldd  ed_year            ; the year: 1985 to 2099
        addd #1
        subd #2100
        bcs  .y1
        ldd  #1985-2100
.y1:    addd #2100
        std  ed_year
        rts
ed_down:
        bsr  ed_fld
        cmpa #2
        beq  .y
        tst  0,x
        bne  .d
        ldab T2
        stab 0,x
.d:     dec  0,x
        rts
.y:     ldd  ed_year
        subd #1
        subd #1985
        bcc  .y1
        ldd  #2099-1985
.y1:    addd #1985
        std  ed_year
        rts
; X = the field's byte, T2 = its range, A = kv_f
ed_fld: ldx  #ed_rng
        ldab kv_f
        abx
        ldab 0,x
        tst  kv_f               ; the day: the month's length
        bne  .r
        bsr  mdays
.r:     stab T2
        ldx  #ed_ptr
        ldab kv_f
        abx
        ldab 0,x                ; (the field's offset from ed_mon)
        ldx  #ed_mon
        abx
        ldaa kv_f
        rts
ed_rng: fcb  31,12,0,24,60,60
ed_ptr: fcb  1,0,0,2,3,4         ; day, month, (year), hour, minute, second

; ed_clamp: the day within the month
ed_clamp:
        bsr  mdays
        cmpb ed_day
        bhi  .x
        decb
        stab ed_day
.x:     rts
        include "clkcom.inc"
