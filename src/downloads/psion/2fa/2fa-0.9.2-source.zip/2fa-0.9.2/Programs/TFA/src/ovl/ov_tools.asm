; =====================================================================
; OV_TOOLS: the Tools and Setup menus
; =====================================================================
        include "ovhead.inc"
        jmp  tools
        jmp  setup
        jmp  noacc


; ---- Tools ------------------------------------------------------------
tools_m:
        fcl  "Add"
        fdb  0
        fcl  "Rename"
        fdb  0
        fcl  "Delete"
        fdb  0
        fcl  "Setup"
        fdb  0
        fcl  "Help"
        fdb  0
        fcb  0
tools:  ldx  #tools_m
        bsr  menu
        bcs  .x
        tstb
        bne  .r
        ovjump OV_ADD,0
.r:     decb
        bne  .d
        ovjump OV_EDIT,0
.d:     decb
        bne  .s
        ovjump OV_DEL,0
.s:     decb
        bne  .h
        bra  setup
.h:     ovjump OV_HELP,0
.x:     rts

; ---- Setup ------------------------------------------------------------
setup_m:
        fcl  "Device"
        fdb  0
        fcl  "PIN"
        fdb  0
        fcl  "Zone"
        fdb  0
setup_m2:
        fcl  "Summer"           ; (two-line models only)
        fdb  0
        fcl  "Clock"
        fdb  0
        fcb  0
setup:  tst  kv_four            ; four lines: the list ends after Zone
        beq  .m
        clr  setup_m2
.m:     ldx  #setup_m
        bsr  menu
        bcs  .x
        tstb
        bne  .p
        ovjump OV_SET,0
.p:     decb
        bne  .z
        ovjump OV_PSET,0
.z:     decb
        bne  .s
        ovjump OV_ZONE,0
.s:     decb
        bne  .c
        ovjump OV_ZONE,1
.c:     ovjump OV_CLK,0
.x:     rts

; ---- no accounts (from the code screen): EXE adds one, MODE the Tools menu

; ---- no accounts -----------------------------------------------------
noacc:  bsr  cls
        bsr  pri
        fcl  "No accounts yet"
        ldaa #1
        clrb
        bsr  at
        bsr  pri
        fcl  "EXE to add one"
.k:     bsr  getk
        cmpb #K_EXE
        beq  .add
        cmpb #K_MODE
        beq  .tools
        cmpb #K_ON
        bne  .k
        bra  leave
.add:   ovsub OV_ADD,0
        bra  again
.tools: ovsub OV_TOOLS,0        ; (not bsr: Tools' choices jump to other overlays, so come
        bra  again              ; back through ovback, which reads OV_TOOLS in again)

