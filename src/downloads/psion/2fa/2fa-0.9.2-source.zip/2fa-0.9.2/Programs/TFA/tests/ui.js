// UI helpers on top of lib.js: drive TFA's screens and check codes against ref/totp.js
'use strict';
const { TFA } = require('./lib');
const R = require('../ref/totp');

class UI extends TFA {
  constructor(model, opts = {}) {
    super(model, opts);
    this.four = this.m.lines === 4;
    this.zone = 0; this.summer = false; this.remembered = 2026;
  }
  lines() { return this.m.screen(); }
  has(re) { return re.test(this.text()); }
  key(k, s = 0.4) { this.press(k, 3, 6); this.run(s); return this; }
  type(t, s = 0.3) { this.m.type(t, 3, 4); this.run(s); return this; }
  waitFor(re, sec = 10) {
    for (let i = 0; i < sec * 10; i++) { if (re.test(this.text())) return true; this.run(0.1); }
    throw new Error('waited for ' + re + ' but the screen is\n' + this.text());
  }
  // the expected codes for a key at the emulator's clock now (and the next step)
  expect(keyText, at) {
    const t = at || this.clock();
    const s = R.clockStep(t, { lines: this.four ? 4 : 2, remembered: this.remembered, zone: this.zone, summer: this.summer });
    const k = R.b32decode(keyText);
    const fmt = (c) => c.slice(0, 3) + ' ' + c.slice(3);
    return { now: fmt(R.code(k, s.step)), next: fmt(R.code(k, s.step + 1)), left: s.left, step: s.step };
  }
  // read the codes and the time together, retrying across a second boundary
  stable(fn) {
    for (let i = 0; i < 5; i++) {
      const t0 = this.clock().join(); const v = fn(); const t1 = this.clock().join();
      if (t0 === t1) return v;
      this.run(0.2);
    }
    throw new Error('the clock would not hold still');
  }
  // from the first-run date check: confirm
  confirmDate() { this.waitFor(/Is this right/); this.key('Y', 0.6); return this; }
  // add an account from the no-accounts screen or the code screen
  add(name, key) {
    if (this.has(/No accounts/)) this.key('EXE');
    else { this.key('MODE'); this.toolsItem('Add'); }
    this.waitFor(/Name:/);
    this.type(name).key('EXE');
    this.waitFor(/typed/);
    this.type(key.replace(/ /g, ''), 0.2).key('EXE', 0.8);
    this.waitFor(/Same as phone/);
    const r = this.stable(() => ({ s: this.text(), e: this.expect(key) }));
    if (!r.s.includes(r.e.now)) throw new Error('check screen shows a wrong code for ' + key + ': want ' + r.e.now + '\n' + r.s);
    this.key('Y', 0.8);
    return this;
  }
  // from the name menu: choose Tools (the last item: RIGHT/DOWN until Tools is chosen)
  toolsItem(item) {
    this.waitFor(/Tools/);
    for (let i = 0; i < 60 && !/Add/.test(this.text()); i++) { this.key('T', 0.5); if (/More/.test(this.text()) && !/Add/.test(this.text())) {} }
    if (!/Add/.test(this.text())) throw new Error('no Tools menu\n' + this.text());
    if (item) this.key(item[0], 0.6);
    return this;
  }
  // the code screen's codes for the account names shown
  shown() {
    const L = this.lines();
    if (!this.four) {
      const a = L[0].match(/^(.{8}) (\d{3} \d{3}|------)/), b = L[1].match(/^next ([ \d]\d)s (\d{3} \d{3}|------)/);
      return a && b ? [{ name: a[1].trim(), now: a[2], next: b[2], left: +b[1] }] : null;
    }
    const out = [];
    for (let i = 0; i < 3; i++) { const a = L[i].match(/^(.{12})([ >])(\d{3} \d{3}|------)/); if (a) out.push({ name: a[1].trim(), code: a[3], next: a[2] === '>' }); }
    const bar = L[3].match(/^\[([= ]{18})\]$/);
    return { rows: out, cells: bar ? bar[1].split('').filter((c) => c === '=').length : -1 };
  }
}
module.exports = { UI, R };
