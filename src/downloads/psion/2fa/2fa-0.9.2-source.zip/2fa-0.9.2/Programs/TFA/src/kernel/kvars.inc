; =====================================================================
; Variables: after the code, cleared at start, not on the pack. Most of
; the small ones, the hashing buffers, the decoded key and the PIN live
; outside the array, in the launchers' code that never runs again once
; the program has started (tools/build.py launcher_holes; the kernel's
; start checks they are where the build put them, else TFA ERROR 3):
; KH: TFAG's code before its USR call, just below the array (the bootstrap
;     string among it); KR: TFA's (or CLOCK's) code up to its call of TFAG,
;     just above the array; KS: its code after that (the NEEDS message).
; =====================================================================
kv_first:
ov_slot: rmb OV_SIZE            ; an overlay (kov.asm); at its top, while the codes show,
                                ; slots 1 and 2 (four lines), or the name menu's list
; ---- the secrets in the array (from kv_sec0, the top of ov_slot): wiped on leaving and
; whenever the Organiser switches off (with kh_sec0..kh_sec1)
kv_slot0: rmb SL_SIZE           ; account slot 0 (just after slots 1 and 2: sl_x)
kt_len: rmb  1                  ; the key typed (lbc: kt_txt follows)
kt_txt: rmb  KEY_MAX
kv_rec: rmb  KREC               ; a record as read or written (lbc)
kv_sec1:
ck_t:    rmb  6   ; the six bytes read
ck_year: rmb  2   
ck_days: rmb  2   
ck_left: rmb  1   
kv_base: rmb  2   ; the array's address
kv_dev:  rmb  1   ; the device TFAC is on
kv_end:

; ---- in KH (TFAG's code, below the array): the secrets first
kh_sec0 = KH
sh_h    = KH+0                  ; (20) SHA-1 (sh_v must follow sh_h)
sh_v    = KH+20                 ; (20)
sh_w    = KH+40                 ; (64)
kb_len  = KH+104                ; (1) a decoded key
kb_key  = KH+105                ; (40)
kh_pin  = KH+145
pin_buf = KH+145                ; (9) the PIN (lbc)
kh_sec1 = KH+154
kv_v    = KH+154 ; (2) ADDR(v%())
kv_sp   = KH+156 ; (2) the stack pointer to leave (and start again) with
kv_flag = KH+158 ; (1) 1: started by CLOCK
kv_four = KH+159 ; (1) 1: four lines (LZ, LZ64)
kv_w    = KH+160 ; (1) the display's width: 16 or 20
kv_nsl  = KH+161 ; (1) slots on the code screen: 1 or 3
kv_oldm = KH+162 ; (1) the display mode to go back to (LZ)
kv_tcnt = KH+163 ; (2) the switch-off time to go back to
kv_new  = KH+165 ; (1) 1: no settings were found (a first run)
kv_woke = KH+166 ; (1) set by sof_hook: the Organiser was switched off
kv_cur  = KH+167 ; (1) the account on screen (the top one on four lines)
kv_idle = KH+168 ; (2) frames with no key
kv_fr   = KH+170 ; (1)
kv_slot = KH+171 ; (2)
kv_pad  = KH+173 ; (1)
kv_dst  = KH+174 ; (2)
kv_src  = KH+176 ; (2)
kv_to   = KH+178 ; (2)
kv_cnt  = KH+180 ; (1)
kv_step = KH+181 ; (4) a step (the low four of its eight bytes)
kv_pmt  = KH+185 ; (1)
kv_pdst = KH+186 ; (2)
kv_kbst = KH+188 ; (1)
kv_tries= KH+189 ; (1)
kv_wait = KH+190 ; (1)
kv_pon  = KH+191 ; (1)
kf_n    = KH+192 ; (2) accounts in the key file
kh_end  = KH+194

; ---- in KR
kv_cs   = KR+0   ; (4) the step of the codes on screen
kv_left = KR+4   ; (1) the seconds left shown
kv_rmode= KR+5   ; (1) 1: the next codes shown (four lines, RIGHT)
kv_i    = KR+6   ; (1)
kv_j    = KR+7   ; (1)
kv_n    = KR+8   ; (1)
kv_sl   = KR+9   ; (2)
kv_nbuf = KR+11  ; (8) a number's digits, a code
kv_ctr  = KR+19  ; (1)
kv_tools= KR+20  ; (1)
kv_pg   = KR+21  ; (1)
kv_pn   = KR+22  ; (1)
kv_room = KR+23  ; (1)
kv_self = KR+24  ; (1) the account being renamed (0: none)
kv_npos = KR+25  ; (1)
kv_nname= KR+26  ; (9) a new name (lbc)
kr_end  = KR+35

; ---- in KS
kv_bpa  = KS+0   ; (3) the overlay area's pack address
kv_res  = KS+3   ; (1) the overlay in the slot
kv_fo   = KS+4   ; (2)
kv_tmp  = KS+6   ; (2)
kv_lv   = KS+8   ; (1) 1: leaving
kv_kp   = KS+9   ; (2) a record's key text: where in kv_rec, its length
kv_kl   = KS+11  ; (1)
kv_pln  = KS+12  ; (1) pin_in: the line
kv_chk  = KS+13  ; (1) pin_chk: the check digit
ac_name = KS+14  ; (9) a record's fields (lbc each)
ac_kind = KS+23  ; (2)
st_dev  = KS+25  ; (1) keys on A: 0, B: 1, C: 2
st_zone = KS+26  ; (1) quarter hours ahead of UTC (-48 to 56)
st_flags= KS+27  ; (1) FL_SUM, FL_PIN
st_salt = KS+28  ; (4)
st_check= KS+32  ; (1)
st_last = KS+33  ; (1) the account shown last
st_year = KS+34  ; (2) the last real year seen
st_day  = KS+36  ; (2) the last day seen (days since 1970)
st_end  = KS+38  
ks_end  = KS+38

t_buf   = kv_rec                ; (tests)
t_slot  = kv_slot0+SL_HALF


; ---- scratch shared by parts that never run together (kt: the key typed, only while adding)
ed_year = kt_txt                ; the clock screens' fields (in this order)
ed_mon  = kt_txt+2
ed_day  = kt_txt+3
ed_hour = kt_txt+4
ed_min  = kt_txt+5
ed_sec  = kt_txt+6
kv_tset = kt_txt+7              ; the six bytes the clock is to hold
kv_f    = kt_txt+13             ; the clock screen's field
kv_d    = kt_txt+14             ; Setup: the device, the zone or summer time being chosen
pin_nw  = kv_slot0              ; Setup > PIN: a new PIN (lbc) and the same again (the slots
kv_pin2 = kv_slot0+PIN_MAX+1    ; are free then; the key text in kt is not: the keys are rewritten)

; ---- in the overlay slot
MENU_BUF = 360                  ; the name menu's list (50 names of 1 character, More, Tools)
kv_menu  = ov_slot+OV_SIZE-MENU_BUF
kv_slots = ov_slot+OV_SIZE-2*SL_SIZE    ; slots 1 and 2, then kv_slot0 just after (sl_x)
kv_sec0  = kv_slots
