'use strict';
// Probe 7: two files on A:: does FL$OPEN make the second file's records current?
const { Probe } = require('./plib');
for (const model of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'lz64']) {
  const p = new Probe(model);
  const m = p.m;
  const buf = p.buf(), nm = buf + 400, rec = buf + 200;
  const mk = (name, recs) => { p.lbc(nm, name); let r = p.call('FL$CRET', { x: nm }); console.log(model, 'create', name, r.c ? 'ERR ' + r.b : 'type ' + r.a.toString(16)); recs.forEach((t) => { p.lbc(rec, t); p.call('FL$WRIT', { x: rec }); }); };
  mk('A:TFASET', ['settings1']);
  mk('A:TFAKEY', ['key1', 'key2']);
  for (const name of ['A:TFAKEY', 'A:TFASET', 'A:TFAKEY']) {
    p.lbc(nm, name);
    const r = p.call('FL$OPEN', { x: nm });
    const sz = p.call('FL$SIZE');
    p.call('FL$RSET', { d: 1 });
    const rr = p.call('FL$READ', { x: rec });
    console.log(model, 'open', name, '-> type', r.a.toString(16), 'rect', m.peek(0x96).toString(16), 'size', sz.x, 'rec1', rr.c ? 'ERR ' + rr.b : JSON.stringify(p.str(rec)));
  }
  // write to SET (new record then erase 1), then open KEY again
  p.lbc(nm, 'A:TFASET'); p.call('FL$OPEN', { x: nm });
  p.lbc(rec, 'settings2'); p.call('FL$WRIT', { x: rec });
  p.call('FL$RSET', { d: 1 }); p.call('FL$ERAS');
  p.lbc(nm, 'A:TFAKEY');
  const r = p.call('FL$OPEN', { x: nm });
  const sz = p.call('FL$SIZE');
  p.call('FL$RSET', { d: 1 });
  const rr = p.call('FL$READ', { x: rec });
  console.log(model, 'after SET rewrite: open KEY type', r.a.toString(16), 'size', sz.x, 'rec1', JSON.stringify(p.str(rec)));
}
