#!/usr/bin/env python3
"""A test pack: the program's files plus PAD (an array of N words, then TFA or, with
--nocheck: a TFA whose memory check always passes: the program's own limit).
    python tools/padpack.py N out.opk [--nocheck]"""
import os
import sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import pack  # noqa: E402
b = os.path.join(os.path.dirname(HERE), 'build', 'game')
n, out = int(sys.argv[1]), sys.argv[2]
call = 'TFA:'
pad = os.path.join(os.path.dirname(out), 'PAD.opl')
with open(pad, 'w', encoding='latin-1', newline='\n') as f:
    f.write('PAD:\nLOCAL p%%(%d)\n%s\n' % (max(n, 1), call))
img = pack.PackImage('datapak', 16, target='cm')
import re
tfa = os.path.join(b, 'TFA.opl')
if '--nocheck' in sys.argv:          # TFA whose memory check always passes (the same shape of code)
    t = open(tfa, encoding='latin-1').read()
    t = re.sub(r'n%=\d+', 'n%=0', t, count=1)
    tfa = os.path.join(os.path.dirname(out), 'TFA.opl')
    with open(tfa, 'w', encoding='latin-1', newline='\n') as f:
        f.write(t)
for name in ('PAD', 'TFA', 'CLOCK', 'TFAG'):
    img.add_opl(pad if name == 'PAD' else tfa if name == 'TFA' else os.path.join(b, name + '.opl'))
img.add_data('TFAC', open(os.path.join(b, 'tfam.bin'), 'rb').read())
img.write(out)
