; every overlay: assembled at ov_slot with the kernel's symbols imported
        include "macros.inc"
