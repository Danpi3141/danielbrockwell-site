'use strict';
// The variables in the launchers' code that has run (kvars.inc KH, KR, KS), on all 29 ROMs: the
// code that runs again stays intact while TFA runs (TFAG's USR on, TFA's parameter, call and
// RETURN), leaving gets back to the Organiser's menu cleanly, and TFA and CLOCK start again.
const fs = require('fs');
const path = require('path');
const { UI } = require('./ui');
const { ROMS } = require('./lib');
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
const meta = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'build', 'game', 'build.json'), 'utf8'));
const h = meta.holes;
const only = process.argv.slice(2);
for (const rom of Object.keys(ROMS)) {
  if (only.length && !only.includes(rom)) continue;
  const four = /lz/.test(rom);
  try {
    const g = new UI(rom, { clock: four ? [126, 10, 19, 14, 31, 40] : [42, 10, 19, 14, 31, 40] });
    let good = true, why = '';
    for (const proc of ['TFA', 'CLOCK', 'TFA', 'CLOCK', 'TFA']) {
      g.start(proc);
      if (/Is this right/.test(g.text())) g.key('Y', 1);
      const base = g.peekw('kv_base');
      const top = base + ((meta.total + 1) >> 1) * 2 + 17;
      const kh = g.m.peekw(base + h.kh + h.kh_len), kr = g.m.peekw(top + h.kr_keep), par = g.m.read(top + h.kr_len, 7);
      if (kh !== 0x9F7F || kr !== 0x847B || par[0] !== 0x22 || par[3] !== 0x20 || par[6] !== 0x01) { good = false; why = `${proc}: kept code changed ${kh.toString(16)} ${kr.toString(16)} ${par}`; }
      const nlog = g.m.logs.length;
      g.key('ON', 1.5);
      if (!g.m.isOn() || !/[A-Za-z]/.test(g.text()) || g.m.logs.slice(nlog).some((l) => /resetting|Stack error/.test(l))) { good = false; why = `${proc}: not back at the menu: ${JSON.stringify(g.text())} ${g.m.logs.slice(-1)}`; break; }
    }
    ok(good, `${rom.padEnd(13)} TFA, CLOCK, TFA, CLOCK, TFA started and left ${why}`);
  } catch (e) {
    fails++; console.log('FAIL', rom, e.message.split('\n').slice(0, 3).join(' | '));
  }
}
console.log(fails ? fails + ' FAILED' : 'all ok');
process.exit(fails ? 1 : 0);
