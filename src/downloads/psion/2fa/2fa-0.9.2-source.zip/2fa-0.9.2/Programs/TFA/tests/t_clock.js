'use strict';
// The spec's clock table (Building and checking > The clock), read off the code screen: the
// clock set, the remembered year and the zone poked, then the codes and seconds against
// ref/totp.js at the clock read back; plus the step the kernel worked out (kv_cs).
const { UI, R } = require('./ui');
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
const KEY = 'JBSW Y3DP EHPK 3PXP';

// [two-line clock bytes, options, step, seconds left] (the spec's rows)
const ROWS = [
  [[42, 10, 19, 14, 32, 7], {}, 59839504, 23],
  [[98, 10, 19, 14, 32, 7], {}, 59839504, 23],
  [[42, 10, 19, 14, 32, 7], { zone: 4 }, 59839384, 23],
  [[42, 11, 30, 23, 59, 59], {}, 59958719, 1],
  [[43, 0, 0, 0, 0, 0], {}, 59958720, 30],
  [[44, 1, 27, 23, 59, 59], {}, 61179839, 1],
  [[44, 1, 28, 12, 0, 0], {}, 61181280, 30],
  [[44, 2, 0, 0, 0, 0], {}, 61182720, 30],
  [[70, 0, 0, 0, 0, 0], { remembered: 2053 }, 88361280, 30],
  [[99, 11, 30, 23, 59, 59], { remembered: 2083 }, 119917439, 1],
  [[72, 0, 0, 0, 0, 0], { remembered: 2083 }, 119917440, 30],
];

for (const model of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'lz64']) {
  console.log('==', model);
  const g = new UI(model, { clock: [42, 10, 19, 14, 32, 7] });
  const four = g.four;
  if (four) g.setClock([126, 10, 19, 14, 32, 7]);
  g.start().confirmDate().add('GitHub', KEY);
  for (const [bytes, o, step, left] of ROWS) {
    const t = bytes.slice();
    if (four) t[0] = R.realYear(bytes[0], 2, o.remembered || 2026) - 1900;   // four lines: the real year
    if (t[5] === 59) t[5] = 57;   // (the same step, and time to read it before the minute rolls on)
    g.setClock(t);                // (then, before any instruction runs: the year remembered)
    g.pokew('st_year', o.remembered || 2026);
    g.poke('st_zone', o.zone || 0);
    g.zone = o.zone || 0; g.remembered = o.remembered || 2026;
    g.run(0.75);
    const r = g.stable(() => ({ cs: g.read('kv_cs', 4), s: g.shown(), t: g.clock(), ck: g.peek('ck_left') }));
    const cs = ((r.cs[0] << 24) | (r.cs[1] << 16) | (r.cs[2] << 8) | r.cs[3]) >>> 0;
    const e = R.clockStep(r.t, { lines: four ? 4 : 2, remembered: g.remembered, zone: g.zone });
    const code = R.code(R.b32decode(KEY), e.step);
    const shownCode = four ? r.s.rows[0].code : r.s[0].now;
    ok(cs === e.step && Math.abs(e.step - step) <= 1 && shownCode === code.slice(0, 3) + ' ' + code.slice(3),
      `${t.join(',')} ${JSON.stringify(o)}: step ${cs} (table ${step}, left ${left}) code ${shownCode}`);
  }
  // the remembered year moves on: after 2054 it is 2054
  g.m.write(0x20C5, four ? [154, 0, 0, 0, 0, 5] : [70, 0, 0, 0, 0, 5]); g.pokew('st_year', 2053); g.run(0.5);
  ok(g.peekw('st_year') === 2054, 'the year last seen moves on to ' + g.peekw('st_year'));
  if (!four) {
    // a year byte of 0: the clock fault
    g.setClock([0, 0, 0, 0, 0, 5]); g.run(1);
    ok(/Clock year is 00/.test(g.text()), 'year byte 0: ' + g.lines()[0]);
  }
}
console.log(fails ? fails + ' FAILED' : 'all ok');
process.exit(fails ? 1 : 0);
