# Organiser II OS notes for TFA

From Jaap Scherphuis's pages (mcosintr.htm, mcosxp1.htm, mcosxp2.htm, mcoslz.htm, sysvars.htm), paraphrased; items marked *check* are verified in the emulator before use (see docs/probes.md).

## Calling convention
`swi` + service byte. Inputs in A, B, X, D and UTW_S0..S5 ($41-$4C). A, B, X, S0-S5 trashed unless stated. Errors: carry set, B = code (only for services that can fail). Strings are lbc (length byte then text).

## Menus
- **MN$DISP** ($50): X = menu string; D = exit-key mask (bit n = key code n+1 exits: bit 0 ON, bit 12 EXE). Out: B = exit key (EXE if a letter picked the only item with it), UTW_S0 = item number (0 first). A non-zero: chosen item had word 0 and X = its entry; A zero: X = the item's word. String: items each lbc name + 2-byte word, ended by a 0 byte. dpb_vlin $64 = current item, dpb_vsiz $65 = count (undocumented). Max items / length: not stated (*check*). Error 202 MENU TOO BIG exists.
- MN$1DSP ($87, LZ), MN$XDSP ($86, LZ): on the cursor line / lines below.

## Line editor
- **ED$EPOS** ($1D): A flags (bit 0 multi-line, bit 1 up/down exit (LZ), bit 7 set = MODE ignored); B = max length; RTT_BF ($2188) = string to edit (*check* lbc in $2187?); UTW_S0 = cursor position. Text left of the cursor is a prompt; right is cleared. Out: B = exit key.
- ED$EDIT ($1C): cursor at the first character.
- TL$XXMD ($68): prompt + edit, carry set on ON/CLEAR.

## Clock
- TMB_YEAR $20C5, MONS $20C6 (0-11), DAYS $20C7 (0-30), HOUR $20C8, MINS $20C9, SECS $20CA. Year 0-99 on CM/XP/LA, 0-255 on LZ.
- **TM$TGET** ($6A): X = 6-byte buffer; copied with no NMI update in the middle; X preserved.
- **TM$TSET** ($B3, LZ only): X = 6 bytes; sets.
- TM$DAYV ($69): X = 3-byte date; B = weekday (0 Monday), X = 3-byte day name.
- btb_nmfl $5B: cleared when an NMI (the 1 s tick) occurs. Set non-zero, wait until zero, then write the clock (Y2000FIX: `oim #1,$5B / tst $5B / bne` then UT$CPYB 6 bytes from RTT_BF to $20C5).
- LZ tmb_24f $20A6: bit 7 = daylight saving on (*check*: does the clock move?).
- btb_wnmi $20AF (LZ): +1 every NMI.

## Keys and power
- KB$TEST ($4B): B = key or 0; does the auto switch-off if TMB_SWOF ($7C) and TMW_TOUT ($7D) = 0.
- KB$GETK ($48): waits; resets TMW_TOUT to TMW_TCNT ($20CD).
- KB$FLSH ($47), KB$UGET ($4C), KB$STAT ($4A): B = new KBB_STAT ($7B) (bit 6 num lock).
- BT$SWOF ($0C): switch off; resumes after the SWI on switch-on. D, X trashed.
- UT$YSNO ($7D): B = key, carry set if Y.

## Display
- DP$EMIT ($10) A = char, registers kept. DP$PRNT ($11) X = text, B = length. DP$STAT ($14) A = cursor pos (0-31 / 0-79 on LZ 4-line), B bit 7 cursor on, bit 0 underline. DP$MSET ($82, LZ) A = 0/1 two/four lines, returns old mode in A.
- Control codes: 8 left, 9 tab, 10 down, 11 home, 12 clear, 13 to line start, 14/15 clear line 1/2, 16 beep; LZ 22/23 clear lines 3/4, 26 clear to end of line.
- UT$DISP ($6F) inline format string (values from the stack, last pushed shown first): %a char, %u word, %v byte, %s lbc, %b buffer, widths, `-0` right justify, `}` = 2 digits.

## Arithmetic and copies
- UT$UDIV ($78): X / D -> X (no remainder). UT$UMUL ($79): D * X -> D high, X low.
- UT$UTOB ($7A): D -> decimal at X, B = length. UT$CPYB ($6D): D = to, X = from, S0 = count. UT$FILL ($71): A value, B count, X address. UT$ICPB ($72): compare A/B lengths, X and S0 strings, case-insensitive.

## Files
- Names lbc 'D:NAME'. Record type flb_rect $96, current record flw_crec $9B (from 1), device flb_cpak $97.
- FL$OPEN ($2F) X = name, A = record type; 234 FILE NOT FOUND. FL$CRET ($28) creates. FL$DELN ($29) deletes.
- FL$FIND ($2C): D = lbc search, X = buffer for the found record (lbc); next matching record; 238 at end.
- FL$READ ($31): X = buffer (lbc), B = type. FL$WRIT ($37): X = lbc record, appended, becomes current. FL$ERAS ($2A): erases the current record.
- FL$SETP ($35) B = pack. FL$RECT ($32) B = type. FL$RSET ($34) D = record number. FL$NEXT ($2E). FL$SIZE ($36): X = record count; D = free low word, UTW_S1h free high byte. FL$FREC ($2D): D = record number -> A = length.
- FL$BOPN ($24): X = name, B = block type; then PK$READ.
- Errors: 194 battery, 200 read pack, 233 dir full, 234 not found, 235 exists, 236 bad name, 238 end of file, 239 pack full, 240 unknown pack, 244 read only, 245 write pack err, 246 no pack.
