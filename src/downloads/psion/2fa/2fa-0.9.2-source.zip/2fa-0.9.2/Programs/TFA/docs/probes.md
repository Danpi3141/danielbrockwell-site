# What the emulator showed (20 Nov 2026)

The spec's "to check on the emulator before relying on it" list, run with `tests/probe/p1.js`..`p5.js` (a probe kernel that calls any OS service, built with `python tools/build.py --kernel tests/probe/probe.asm --out build/probe`).

| Question | Answer |
|---|---|
| LZ daylight saving moves the six clock bytes? | **No.** TIME > MODE > Set > Daylight-saving On sets bit 7 of $20A6; the stored time stays (0:00:07 stored while the screen shows "1:00:06 am (D)"). The LZ needs no Summer setting (`p4.js`). |
| ED$EPOS buffer | An lbc at $2187 (length) + $2188 (text). Text left of the cursor stays as a prompt. EXE: B = 13. ON/CLEAR clears the line first; a second ON exits with B = 1 and length 0. MODE exits with B = 2 unless A bit 7 is set. (`p1.js`) |
| MN$DISP with 50 names + Tools | **Refused: error 202 MENU TOO BIG.** The limit is the text: every item's name plus one space must fit about 252 characters (28 names of 8, 42 of 5, 60+ of 3), the same on CM, XP, LZ, LZ64, two-line and four-line. **The name menu pages** (`p2.js`). |
| Records of up to 75 characters on A:, B:, C: | Same calls everywhere: FL$CRET/FL$OPEN return the record type ($91 for the first file on a device), FL$WRIT appends, FL$RSET n + FL$READ reads record n, FL$ERAS erases and later records move down one, FL$SIZE gives the count in X, FL$FREC the length. Two files on two devices are switched with FL$SETP + FL$RECT. A pulled pack: error 246 NO PACK (`p3.js`). |
| Switching off inside the program | BT$SWOF returns after ON on CM, XP, LA, LZ64 (`p5.js`). |
| Clock writes | btb_nmfl ($5B) set to 1 is cleared by the next one-second NMI (all models); a write of the six bytes right after it holds (`p5.js`). Cold-boot clock: CM/XP 1987, LA 1988, LZ 1989. |
| Day names | TM$DAYV: B = weekday (0 Monday), X = three letters, upper case on every ROM tried ("FRI"). |
