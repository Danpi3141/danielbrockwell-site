; the name editor and its check (OV_ADD, OV_EDIT)

; ac_name = the new name (kv_nname)
ac_newname:
        ldx  #kv_nname
        ldd  #ac_name
        std  kv_to
        ldab #9
        bra  copy

; ---- the name ------------------------------------------------------------
; ed_name: "Name:" and the line editor at the cursor, starting from the text
; in RTB_BL. Out: carry set if abandoned; else kv_nname and ac_name = the
; name: 1-8 characters, not More or Tools, not another account's (kv_self
; is the account being renamed).
ed_name:
        bsr  pri
        fcl  "Name:"
        ldaa DPB_CPOS
        staa kv_npos
.ed:    ldaa kv_npos
        clrb
        os   DP$STAT
        ldx  #99
        stx  T0
        ldaa #$80               ; one line, MODE ignored
        ldab #8
        os   ED$EPOS
        bsr  chkwoke
        cmpb #K_EXE
        bne  .no
        ldab RTB_BL
        beq  .ed
        stab kv_nname
        ldx  #RTT_BF
        ldd  #kv_nname+1
        std  kv_to
        ldab kv_nname
        bsr  copy
        bsr  nm_check
        bcs  .ed
        bsr  ac_newname
        clc
        rts
.no:    sec
        rts

; nm_check: kv_nname against More, Tools and every account but kv_self:
; carry set (a beep) if it is taken
nm_check:
        ldx  #m_more
        bsr  .cmp
        beq  .used
        ldx  #m_tools
        bsr  .cmp
        beq  .used
        bsr  kf_open
        bcs  .ok
        ldaa #1
.n:     staa kv_j
        cmpa kf_n+1
        bhi  .ok
        cmpa kv_self
        beq  .nx
        tab
        clra
        os   FL$RSET
        ldx  #kv_rec
        os   FL$READ
        bcs  .ok
        bsr  ac_parse
        ldx  #ac_name
        bsr  .cmp
        beq  .used
.nx:    ldaa kv_j
        inca
        bra  .n
.ok:    clc
        rts
.used:  bsr  beep
        sec
        rts
.cmp:   ldaa 0,x                ; the lbc at X against kv_nname, any case: Z if the same
        inx
        pshx
        ldx  #kv_nname+1
        stx  T0                 ; (UT$ICPB: A, B the lengths, X one text, UTW_S0 the other)
        pulx
        ldab kv_nname
        os   UT$ICPB
        tstb
        rts

m_more: fcl  "More"
m_tools: fcl "Tools"
