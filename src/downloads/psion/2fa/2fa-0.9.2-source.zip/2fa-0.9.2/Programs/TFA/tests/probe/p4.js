'use strict';
// Probe 4: the LZ's TIME application and daylight saving: do the clock bytes move?
const { Machine } = require('../../tools/emu');
const m = new Machine({ rom: '46a-lz64.rom', ram: 64 });
m.boot();
const clock = () => m.read(0x20C5, 6).join(',') + ' 24f=' + m.peek(0x20A6).toString(16);
const show = (w) => console.log('--', w, clock() + '\n' + m.screenText());
show('menu');
const seq = (process.argv[2] || 'T').split(' ');
for (const k of seq) { if (k === 'W') { m.runSeconds(1); continue; } m.press(k, 3, 8); m.runSeconds(0.3); show(k); }
