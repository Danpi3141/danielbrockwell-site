; =====================================================================
; OV_KEY: the key editor (in groups of four, A-Z and 2-7 only)
; =====================================================================
        include "ovhead.inc"
        jmp  ed_key


; ---- the key editor ---------------------------------------------------------
; ed_key: the key typed into kt_txt (kt_len kept from before): A-Z and 2-7, DEL
; removes one, EXE accepts 16 to 64, ON/CLEAR abandons (carry set)
ed_key: bsr  cls
        tst  kv_four
        beq  .d
        bsr  pri                ; four lines: the name stays in view
        fcl  "New account"
        ldaa #1
        clrb
        bsr  at
        bsr  pri
        fcl  "Name: "
        ldx  #kv_nname
        bsr  prs
.d:     bsr  key_show
.k:     bsr  getk
        cmpb #K_ON
        beq  .no
        cmpb #K_EXE
        beq  .exe
        cmpb #K_DEL
        beq  .del
        cmpb #'A'
        blo  .dig
        cmpb #'Z'
        bls  .add
.bad:   bsr  beep
        bra  .k
.dig:   cmpb #'2'
        blo  .bad
        cmpb #'7'
        bhi  .bad
.add:   ldaa kt_len
        cmpa #KEY_MAX
        bhs  .bad
        ldx  #kt_txt
        pshb
        tab
        abx
        pulb
        stab 0,x
        inc  kt_len
        bra  .d
.del:   tst  kt_len
        beq  .bad
        dec  kt_len
        bra  .d
.exe:   ldaa kt_len
        cmpa #KEY_MIN
        blo  .bad
        clc
        rts
.no:    sec
        rts

; key_show: "Key:", the count typed, and the end of the key in groups of four
; with the cursor after it (two lines: lines 0 and 1; four lines: 2 and 3)
key_show:
        ldaa #0
        tst  kv_four
        beq  .l
        ldaa #2
.l:     staa kv_i               ; the line of "Key:"
        bsr  clrl
        bsr  pri
        fcl  "Key:"
        ldab kt_len             ; "13 typed" at the right
        clra
        pshb
        ldx  #kv_nbuf
        os   UT$UTOB
        addb #6
        negb
        addb kv_w
        ldaa kv_i
        bsr  at
        pulb
        clra
        bsr  prnum
        bsr  pri
        fcl  " typed"
        ldaa kv_i               ; the key's line
        inca
        bsr  clrl
        clrb                    ; the first group shown: from the end, as many as fit
.s:     stab T2
        ldaa kt_len
        sba
        beq  .p                 ; (nothing typed)
        deca                    ; columns: n + (n - 1) / 4
        lsra
        lsra
        ldab kt_len
        subb T2
        aba
        cmpa kv_w
        blo  .p                 ; fits with the cursor after it
        ldab T2
        addb #4
        bra  .s
.p:     ldx  #kt_txt
        ldab T2
        abx
.c:     cmpb kt_len
        bhs  .e
        cmpb T2
        beq  .ch
        bitb #3
        bne  .ch
        ldaa #' '
        bsr  emit
.ch:    ldaa 0,x
        bsr  emit
        inx
        incb
        bra  .c
.e:     ldaa DPB_CPOS           ; the cursor shown after the key
        ldab #$80
        os   DP$STAT
        rts
