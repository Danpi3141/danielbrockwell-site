; =====================================================================
; Shared small routines
; =====================================================================

; copy 20 bytes from X to D
cpy20:  std  kv_to
        ldab #20
; copy B bytes from X to kv_to (B may be 0)
copy:   stab T1
        clr  T0
        ldd  kv_to
        os   UT$CPYB
        rts

; fill B bytes at X with zero (B may be 0)
zero:   tstb
        beq  .x
.l:     clr  0,x
        inx
        decb
        bne  .l
.x:     rts
