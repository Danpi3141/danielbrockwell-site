; =====================================================================
; OV_EDIT: renaming an account
; =====================================================================
        include "ovhead.inc"
        jmp  ren_acc

ren_acc:
        clr  kv_tools           ; the account, from the name menu
        ovsub OV_NAME,0
        bcs  .x
        stab kv_self
        clra
        bsr  kf_read
        bcs  .x
        ldab ac_name            ; the name as it is, to edit
        stab RTB_BL
        ldx  #ac_name+1
        ldd  #RTT_BF
        std  kv_to
        ldab ac_name
        bsr  copy
        bsr  cls
        bsr  ed_name            ; (ac_name is the new name from here)
        bcs  .x
        ldaa kv_self            ; the record again (ed_name read others)
        tab
        clra
        bsr  kf_read
        bcs  .x
        bsr  ac_keykt           ; the key as it is ...
        ldaa ac_kind+1
        cmpa #'B'
        bne  .w
        bsr  ac_secret          ; ... unless scrambled by the old name: unscrambled
        bsr  ac_newname
        ovsub OV_STRM,0         ; and scrambled by the new
        bsr  b32enc
.w:     bsr  ac_newname
        bsr  ac_make            ; the new record first, then the old one erased
        bsr  kf_add
        bcs  .x
        ldaa kv_self
        tab
        clra
        bsr  kf_del
        ldaa kf_n+1
        staa kv_cur
.x:     rts
        include "names.inc"
        include "recs.inc"
