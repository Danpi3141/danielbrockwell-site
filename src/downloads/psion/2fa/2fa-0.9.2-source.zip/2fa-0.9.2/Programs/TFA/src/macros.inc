; ---- overlays (src/kernel/kov.asm): their numbers and entries
OV_DATE = 1                     ; 0 ck_check, 1 ck_fault
OV_CLK  = 2                     ; 0 clk_screen, 1 clk_setnow
OV_CSET = 3                     ; 0 clk_set (the fields edited; carry: abandoned)
OV_ADD  = 4                     ; 0 add_acc
OV_KEY  = 5                     ; 0 ed_key
OV_CHK  = 6                     ; 0 chk_key
OV_EDIT = 7                     ; 0 ren_acc
OV_DEL  = 8                     ; 0 del_acc
OV_SET  = 9                     ; 0 set_dev
OV_ZONE = 10                    ; 0 set_zone, 1 set_sum
OV_PSET = 11                    ; 0 set_pin
OV_PIN  = 12                    ; 0 pin_gate, 1 pin_in, 2 pin_chk, 3 pin_new
OV_HELP = 13                    ; 0 help
OV_TOOLS = 14                   ; 0 tools, 1 setup, 2 noacc
OV_INIT = 15                    ; 0 set_load, 1 set_save
OV_NAME = 16                    ; 0 nm_pick (kv_tools: Tools at the end)
OV_STRM = 17                    ; 0 ac_stream
OV_LAST = 17

; call an overlay's entry (back after the call); from the kernel
ovcall  macro id,e
        jsr  ovc
        fcb  \id,\e
        endm
; go to an overlay's entry (it returns to whoever called this code)
ovjump  macro id,e
        jsr  ovj
        fcb  \id,\e
        endm
; call an overlay's entry from an overlay: this overlay is read in again before
; coming back (B and the flags are kept; A and X are not)
ovsub   macro id,e
        jsr  ovs
        fcb  \id,\e
        endm
