; =====================================================================
; OV_STRM: a key scrambled or unscrambled by the PIN
; =====================================================================
        include "ovhead.inc"
        jmp  ac_stream


; kb_key ^= the stream for ac_name: SHA-1(PIN, salt, name, n) for n = 0, 1
; (40 bytes: the longest key). The same call scrambles and unscrambles.
ac_stream:
        clr  kv_ctr
.blk:   bsr  clrw               ; the message, straight into the hash's block: PIN digits, salt, name, n
        ldx  #sh_w
        stx  kv_to
        ldx  #pin_buf
        bsr  .cat
        ldx  #st_salt-1         ; (st_salt follows a byte: 4 bytes copied from st_salt)
        ldab #4
        bsr  .catb
        ldx  #ac_name
        bsr  .cat
        ldx  #kv_ctr-1
        ldab #1
        bsr  .catb
        ldd  kv_to
        subd #sh_w
        bsr  sha_msgw
        ldab kv_ctr             ; xor 20 bytes from 20 * n
        ldaa #20
        mul
        ldx  #kb_key
        abx
        stx  T6
        ldx  #sh_h
.x:     ldaa 0,x
        inx
        stx  T8
        ldx  T6
        eora 0,x
        staa 0,x
        inx
        stx  T6
        ldx  T8
        cpx  #sh_h+20
        bne  .x
        inc  kv_ctr
        ldaa kv_ctr
        cmpa #2
        bne  .blk
        rts
.cat:   ldab 0,x                ; append the lbc at X (B bytes from X+1) to the message
.catb:  inx
        pshb
        bsr  copy
        pulb
        ldx  kv_to
        abx
        stx  kv_to
        rts
        include "sha.inc"
