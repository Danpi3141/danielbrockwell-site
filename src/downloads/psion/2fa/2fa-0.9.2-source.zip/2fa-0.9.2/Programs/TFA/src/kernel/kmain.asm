; =====================================================================
; Start, leave, the code screens
; =====================================================================

start:  ldx  KR_KEEP            ; TFA's (or CLOCK's) code must be just above the array and
        cpx  #$847B             ; TFAG's just below it, as when TFA or CLOCK runs TFAG: some
        bne  .bad               ; variables live in their code that has run (kvars.inc)
        ldx  KH_KEEP
        cpx  #$9F7F
        beq  .run
.bad:   ldx  #E_RUN             ; (TFAG run some other way)
        rts
.run:   pshb
        psha
        ldx  #kv_first          ; the variables (and the fixer, the fix-ups and the bootstrap under them),
        ldd  #kv_end            ; and the launchers' code that has run, cleared
        bsr  zr
        ldx  #KH
        ldd  #KH+KH_LEN
        bsr  zr
        ldx  #KR
        ldd  #KR+KR_LEN
        bsr  zr
        ldx  #KS
        ldd  #KS+KS_LEN
        bsr  zr
        pula
        pulb
        std  kv_v
        xgdx
        ldaa 9,x                ; the launcher's flag: 1 = CLOCK
        staa kv_flag
        ldx  0,x                ; v%(1): the array
        stx  kv_base
        ldx  #MODEL&$FF00
        ldd  #$1001             ; two lines: 16 wide, one slot
        tim  #8,MODEL&255,x     ; four-line (LZ, LZ64): bit 3 of the model byte
        beq  .two
        ldaa #1
        os   DP$MSET            ; four lines (the old mode kept for leaving)
        staa kv_oldm
        inc  kv_four
        ldd  #$1403             ; 20 wide, three slots
.two:   staa kv_w
        stab kv_nsl
        ldx  TMW_TCNT           ; the switch-off time: two minutes while running
        stx  kv_tcnt
        ldx  #IDLE_SECS
        stx  TMW_TCNT
        ldx  $2058              ; the switch-off vector: through sof_hook
        stx  sof_go
        ldx  #sof_hook
        stx  $2058
        sts  kv_sp
        bsr  ov_find            ; where the overlays are
        ovcall OV_INIT,0        ; the settings (carry: none yet, a first run)
        rol  kv_new
        ldaa st_last
        staa kv_cur

; main: also where the program starts again after being switched off
woke:
main:   lds  kv_sp
        clr  kv_woke
        bsr  wipe
        tst  kv_flag
        beq  .tfa
        ovcall OV_CLK,0         ; CLOCK: the clock screen, then out
        bra  leave
.tfa:   ovcall OV_DATE,0        ; the date confirmed if need be (may leave)
        ovcall OV_PIN,0         ; the PIN if one is set (may leave)
; again: the key file found afresh and the code screen (after Tools)
again:  lds  kv_sp
        bsr  kf_find
        bra  cs_main

; leave: back to the launcher (from any depth)
leave:  lds  kv_sp
        bsr  wipe
        tst  kv_lv              ; (once only: a pack gone while saving comes back here)
        bne  .ns
        inc  kv_lv
        tst  kv_new             ; (nothing saved until the date is confirmed)
        bne  .ns
        ldaa kv_cur
        staa st_last
        bsr  ck_read
        bcs  .sv
        ldd  ck_days
        std  st_day
.sv:    ovcall OV_INIT,1
.ns:    ldx  kv_tcnt
        stx  TMW_TCNT
        ldx  sof_go
        stx  $2058
        tst  kv_four
        beq  .x
        ldaa kv_oldm
        os   DP$MSET
.x:     bsr  wipe               ; (again: the settings record was made in the secrets' area)
        bsr  cls
        os   KB$BREK            ; (ON/CLEAR still down would pause the OPL that called: wait until it is up)
        os   KB$FLSH
        ldx  #0
        rts

; ---- the code screen ------------------------------------------------
cs_main:
        ldd  kf_n
        bne  .some
        ovcall OV_TOOLS,2       ; no accounts (never comes back)
.some:  ldaa kv_cur             ; the account in range
        beq  .one
        cmpa kf_n+1
        bls  cs_go
.one:   ldaa #1
        staa kv_cur
cs_go:  tst  kv_four
        beq  .w
        bsr  cls
        ldaa #3
        ldab #5
        bsr  at
        bsr  pri
        fcl  "Working..."
.w:     bsr  sl_fill
        bcs  cs_bad
        bsr  ck_read
        bcs  cs_fault
        ldd  kv_step
        std  kv_cs
        ldd  kv_step+2
        std  kv_cs+2
        ldaa kv_nsl
        staa kv_n
        bsr  sl_nows            ; the codes now shown first, then the next ones made
        clr  kv_rmode
        bsr  cs_draw
        bsr  sl_nexts
        bsr  cs_codes
cs_loop:
        bsr  ck_read
        bcs  cs_fault
        ldd  kv_step+2          ; the step now against the codes' step
        subd kv_cs+2
        std  T8
        ldd  kv_step
        sbcb kv_cs+1
        sbca kv_cs
        bne  .far
        tstb
        bne  .far
        ldd  T8
        beq  .same
        subd #1
        bne  .far
        bsr  cs_take            ; one step on: the next codes move up, shown at once,
        bsr  sl_shift           ; then the new next codes made
        clr  kv_rmode
        bsr  cs_codes
        bsr  sl_nexts
        bra  .new
.far:   bsr  cs_take            ; further (after being off): all afresh, now first
        bsr  sl_nows
        clr  kv_rmode
        bsr  cs_codes
        bsr  sl_nexts
.new:   clr  kv_rmode
        bsr  cs_codes
.same:  ldaa ck_left
        cmpa kv_left
        beq  .key
        staa kv_left
        bsr  cs_secs
.key:   bsr  pollk
        tstb
        bne  cs_key
        bra  cs_loop
cs_bad: bra  main
cs_fault:
        ovcall OV_DATE,1
        bra  main

; the step now becomes the codes' step
cs_take:
        ldd  kv_step
        std  kv_cs
        ldd  kv_step+2
        std  kv_cs+2
        rts

cs_key: tst  kv_rmode           ; any key ends the next codes being shown
        beq  .k
        clr  kv_rmode
        bsr  cs_codes
        bra  cs_loop
.k:     cmpb #K_ON
        bne  .m
        bra  leave
.m:     cmpb #K_MODE
        beq  .menu
        cmpb #K_EXE
        beq  .menu
        cmpb #K_UP
        beq  .up
        cmpb #K_DOWN
        beq  .dn
        cmpb #K_RIGHT
        bne  cs_loop
        tst  kv_four
        beq  cs_loop
        inc  kv_rmode           ; RIGHT (four lines): the next codes
        bsr  cs_codes
        bra  cs_loop
.up:    dec  kv_cur
        bne  .go
        ldaa kf_n+1
        staa kv_cur
        bra  .go
.dn:    ldaa kv_cur
        cmpa kf_n+1
        blo  .d1
        clra
.d1:    inca
        staa kv_cur
.go:    bra  cs_go
.menu:  ldaa #1                 ; the name menu, Tools last
        staa kv_tools
        ovcall OV_NAME,0
        bcs  .go
        tstb
        beq  .tools
        stab kv_cur
        bra  .go
.tools: ovcall OV_TOOLS,0
        bra  again

; ---- drawing the code screen ---------------------------------------
cs_draw:
        bsr  cls
        tst  kv_four
        bne  cs_codes
        ldaa #1                 ; two lines: "next 23s 187 523"
        clrb
        bsr  at
        bsr  pri
        fcl  "next"
; the names and codes (and the seconds or the bar)
cs_codes:
        clra
.s:     staa kv_i
        bsr  sl_x
        stx  kv_sl
        ldaa kv_i               ; the line
        clrb
        bsr  at
        ldx  kv_sl
        ldab #SL_NAME
        abx
        ldab #8
        tst  kv_four
        beq  .nw
        ldab #12
.nw:    bsr  prf                ; the name, padded
        ldx  kv_sl
        tst  SL_ACC,x
        beq  .blank
        ldaa #' '
        tst  kv_rmode
        beq  .nr
        ldaa #'>'
.nr:    bsr  emit
        tst  kv_four
        bne  .c4
        ldaa #1                 ; two lines: the next code below
        ldab #9
        bsr  at
        ldab #SL_NEXT
        bsr  .code
        clra
        ldab #9
        bsr  at
.c4:    ldab #SL_NOW
        tst  kv_rmode
        beq  .cn
        ldab #SL_NEXT
.cn:    bsr  .code
        bra  .nx
.blank: ldab #8
        bsr  spaces
.nx:    ldaa kv_i
        inca
        cmpa kv_nsl
        bne  .s
        clr  kv_left            ; the seconds or the bar redrawn
        bra  cs_secs
.code:  ldx  kv_sl              ; the code at slot + B, or ------ for a kind not known
        tst  SL_OK,x
        beq  .dash
        abx
        bra  prcode
.dash:  bsr  pri
        fcl  "------ "
        rts

; the seconds left (two lines) or the bar (four lines)
cs_secs:
        ldaa ck_left
        staa kv_left
        tst  kv_four
        bne  .bar
        ldaa #1
        ldab #5
        bsr  at
        bsr  secs2
        ldaa #'s'
        bra  emit
.bar:   ldaa #3                 ; [=============     ]: seconds left * 3 / 5 cells
        clrb
        bsr  at
        ldaa #'['
        bsr  emit
        ldaa ck_left
        ldab #3
        mul
        ldaa #-1
.div:   inca
        subb #5
        bcc  .div
        staa T2                 ; cells filled
        ldab #18
.c:     ldaa #'='
        tst  T2
        bne  .f
        ldaa #' '
        inc  T2
.f:     dec  T2
        bsr  emit
        decb
        bne  .c
        ldaa #']'
        bra  emit
