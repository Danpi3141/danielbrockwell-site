// Test helpers: Psion 2FA on an emulated Organiser (tools/emu.js). The kernel is found in RAM by
// its "TFA1" tag (base = tag - 3); its variables through build/game/kernel.sym.json.
'use strict';
const fs = require('fs');
const path = require('path');
const { Machine } = require('../tools/emu');

const ROOT = path.join(__dirname, '..');
const TAG = [0x54, 0x46, 0x41, 0x31];
const MODELS = {
  cm: { rom: '33-cm.rom', ram: 8 }, cm24: { rom: '24-cm.rom', ram: 8 }, cm26: { rom: '26-cm.rom', ram: 8 },
  xp: { rom: '31-xp.rom', ram: 16 }, xp24: { rom: '24-xp.rom', ram: 16 }, xp26: { rom: '26-xp.rom', ram: 16 },
  la: { rom: '36-la.rom', ram: 32 }, lz: { rom: '46-lz.rom', ram: 32 }, lz64: { rom: '46a-lz64.rom', ram: 64 },
};
const ROMS = {
  '24-cm.rom': 8, '26-cm.rom': 8, '33-cm.rom': 8, '33-cmf.rom': 8, '36-cmf.rom': 8,
  '24-xp.rom': 16, '26-xp.rom': 16, '31-xp.rom': 16,
  '30-lahp.rom': 32, '33-la.rom': 32, '34-lag.rom': 32, '36-la.rom': 32, '36-laf.rom': 32, '36-lag.rom': 32, '37-lam.rom': 32,
  '42-lz.rom': 32, '44-lz.rom': 32, '45-lz.rom': 32, '45-lzi.rom': 32, '45-lzs.rom': 32, '46-lz.rom': 32, '46-lzi.rom': 32,
  '43-lz64.rom': 64, '44-lz64.rom': 64, '45-lz64.rom': 64, '46a-lz64.rom': 64, '46b-lz64.rom': 64, '46-lz64i.rom': 64, '46-lz64s.rom': 64,
};

class TFA {
  constructor(model, opts = {}) {
    this.model = model;
    const mm = MODELS[model] || (ROMS[model] ? { rom: model, ram: ROMS[model] } : null);
    if (!mm) throw new Error('no model ' + model);
    this.m = new Machine({ rom: mm.rom, ram: mm.ram });
    this.bdir = opts.build || path.join(ROOT, 'build', 'game');
    this.sym = JSON.parse(fs.readFileSync(path.join(this.bdir, 'kernel.sym.json'), 'utf8'));
    this.meta = JSON.parse(fs.readFileSync(path.join(this.bdir, 'build.json'), 'utf8'));
    this.m.boot();
    if (opts.clock) this.setClock(opts.clock);
    if (opts.packC) this.m.emptyPack(opts.packC.type, opts.packC.size, 1);
    this.m.insertPack(opts.pack || path.join(this.bdir, 'TFA.opk'), 0);
    this.base = -1;
  }
  setClock(t) {   // six bytes, written just after a tick
    const m = this.m;
    m.poke(0x5B, 1);
    for (let i = 0; i < 40 && m.peek(0x5B); i++) m.runSeconds(0.02);
    m.write(0x20C5, t);
  }
  clock() { return this.m.read(0x20C5, 6); }
  text() { return this.m.screenText(); }
  sync() {
    const a = this.m.find(TAG, 0x2000, 0xFFF0);
    this.base = a >= 0 ? a - 3 : -1;
    return this.base;
  }
  // run TFA (or CLOCK) from B: and wait until the kernel is in RAM and at a key wait
  start(proc = 'TFA', maxSec = 20) {
    for (let a; (a = this.m.find(TAG, 0x2000, 0xFFF0)) >= 0;) this.m.poke(a, 0);   // stale tags in freed RAM
    this.m.runProc(proc, 'B');
    for (let i = 0; i < maxSec * 10; i++) {
      this.m.runSeconds(0.1);
      if (this.sync() >= 0) return this.toIdle(maxSec);
    }
    throw new Error(proc + ' did not start\n' + this.text());
  }
  toIdle(maxSec = 20) {
    const idle = this.addr('t_idle');
    if (this.m.runTo([idle], 921600 * maxSec) !== idle) throw new Error('no key wait\n' + this.text());
    return this;
  }
  addr(name) {
    const s = this.sym[name];
    if (!s) throw new Error('no symbol ' + name);
    return s[1] === 'abs' ? s[0] : this.base + s[0];
  }
  peek(n, o = 0) { return this.m.peek(this.addr(n) + o); }
  peekw(n, o = 0) { return this.m.peekw(this.addr(n) + o); }
  poke(n, v, o = 0) { this.m.poke(this.addr(n) + o, v); }
  pokew(n, v, o = 0) { this.m.pokew(this.addr(n) + o, v); }
  read(n, len, o = 0) { return this.m.read(this.addr(n) + o, len); }
  write(n, bytes, o = 0) { this.m.write(this.addr(n) + o, bytes); }
  // call a kernel routine from the key wait (t_idle): returns registers and cycles
  call(routine, regs = {}, maxSec = 30) {
    const m = this.m, d = m.dbg;
    if (d.pc() !== this.addr('t_idle')) this.toIdle();
    const back = d.pc();
    const done = this.addr('t_done');
    d.setX(typeof routine === 'string' ? this.addr(routine) : routine);
    if (regs.a !== undefined) d.setA(regs.a);
    if (regs.b !== undefined) d.setB(regs.b);
    d.setPC(this.addr('t_call'));
    const c0 = m.cycles();
    let ok = false;
    for (let i = 0; i < maxSec * 20 && !ok; i++) {
      m.runSeconds(0.05);
      ok = d.pc() === done;
    }
    if (!ok) throw new Error('call ' + routine + ' did not finish (pc ' + d.pc().toString(16) + ')\n' + this.text());
    const out = { a: d.a(), b: d.b(), x: d.x(), p: d.p(), cycles: m.cycles() - c0 };
    d.setPC(back);
    return out;
  }
  // call a routine with registers {a, b, x} straight from the key wait: its return goes to t_done
  callDirect(routine, regs = {}, maxSec = 30) {
    const m = this.m, d = m.dbg;
    if (d.pc() !== this.addr('t_idle')) this.toIdle();
    const back = d.pc(), sp = d.sp(), done = this.addr('t_done');
    m.pokew(sp - 2, done); d.setSP(sp - 2);       // (Jape's SP points at the last byte pushed)
    if (regs.a !== undefined) d.setA(regs.a);
    if (regs.b !== undefined) d.setB(regs.b);
    if (regs.x !== undefined) d.setX(regs.x);
    d.setPC(typeof routine === 'string' ? this.addr(routine) : routine);
    const c0 = m.cycles();
    let cyc = -1;
    d.setTrace((pc) => { if (pc === done && cyc < 0) cyc = m.cycles() - c0; });
    for (let i = 0; i < maxSec * 50 && cyc < 0; i++) m.run(18432);
    d.setTrace(null);
    if (cyc < 0) throw new Error('call ' + routine + ' did not finish');
    d.setPC(back); d.setSP(sp);
    return cyc;
  }
  // exact cycles of a routine (breakpoint at t_done)
  timed(routine, regs = {}) {
    const m = this.m, d = m.dbg;
    if (d.pc() !== this.addr('t_idle')) this.toIdle();
    const back = d.pc();
    d.setX(this.addr(routine));
    if (regs.a !== undefined) d.setA(regs.a);
    if (regs.b !== undefined) d.setB(regs.b);
    d.setPC(this.addr('t_call'));
    const c0 = m.cycles();
    const done = this.addr('t_done');
    if (m.runTo([done], 921600 * 30) !== done) throw new Error('timed call did not finish');
    const cyc = m.cycles() - c0;
    m.run(4);
    d.setPC(back);
    return cyc;
  }
  press(k, hold = 3, gap = 6) { this.m.press(k, hold, gap); }
  run(s) { this.m.runSeconds(s); }
}

module.exports = { TFA, MODELS, ROMS, ROOT };
