'use strict';
// Probe 2: MN$DISP limits: largest item count for short and long names; does 4-line mode differ?
const { Probe } = require('./plib');
for (const model of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'lz64']) {
  const p = new Probe(model);
  const m = p.m;
  const buf = p.buf();
  const tryMenu = (n, len) => {
    let a = buf;
    for (let i = 0; i < n; i++) { a = p.lbc(a, ('N' + i + 'XXXXXXXX').slice(0, len)); m.pokew(a, i + 1); a += 2; }
    m.poke(a, 0);
    p.call('DP$EMIT', { a: 12 });
    const r = p.call('MN$DISP', { x: buf, d: 0x1003 }, () => { m.runSeconds(0.3); m.press('EXE'); });
    return { ok: !r.c, bytes: a + 1 - buf, b: r.b };
  };
  for (const four of model.startsWith('lz') ? [false, true] : [false]) {
    if (four) p.call('DP$MSET', { a: 1 });
    for (const len of [3, 5, 8]) {
      let lo = 1, hi = 60;
      while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (tryMenu(mid, len).ok) lo = mid; else hi = mid - 1; }
      const r = tryMenu(lo, len);
      console.log(model, four ? '4-line' : '2-line', 'name len', len, 'max items', lo, 'bytes', r.bytes, 'next fails:', JSON.stringify(tryMenu(lo + 1, len)));
    }
  }
}
