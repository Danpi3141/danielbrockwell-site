; =====================================================================
; Overlays: the parts used now and then (the date check, the clock
; screen, adding, renaming and deleting, Setup, Help, the Tools menu)
; are read from TFAC into one slot (ov_slot) when they are wanted.
; TFAC's data: the kernel's part (read by the bootstrap), then the
; overlay area: an index of 2-byte offsets (one an overlay, from 1),
; then each overlay: its length (2), its code (assembled at ov_slot,
; a jump table first), the length of its fix-up list (1), the list.
; =====================================================================

tfam_n: fcl  "A:TFAC"

; ov_find: at start: the pack address of the overlay area (kv_bpa)
ov_find:
        ldx  kv_v
        ldab 4,x                ; the device TFAC came from
        stab kv_dev
        ldx  #tfam_n
        addb #'A'
        stab 1,x
        ldab #$83
        os   FL$BOPN
        bcs  .x
        ldx  kv_v               ; past the stub, the build, the two lengths and the kernel's part
        ldd  10,x
        addd #16+6
        os   PK$SKIP
        os   PK$QADD
        stab kv_bpa
        stx  kv_bpa+1
.x:     rts

; ovc: call overlay entry: jsr ovc / fcb id,entry (back after the two bytes)
ovc:    pulx
        ldd  0,x
        inx
        inx
        pshx
        bra  ov_call
; ovj: the same as a jump (from one overlay to another: the entry returns
; to the caller of the overlay that jumped)
ovj:    pulx
        ldd  0,x
        bra  ov_call
; ovs: an overlay calling another (the ovsub macro): jsr ovs / fcb id,entry.
; The caller's number goes on the stack under the return to ovback.
ovs:    pulx
        ldd  0,x
        inx
        inx
        pshx                    ; the return into the calling overlay
        std  kv_tmp             ; (id, entry)
        ldaa kv_res
        psha                    ; the caller's number
        ldx  #ovback
        pshx                    ; the callee returns to ovback
        ldd  kv_tmp
        bra  ov_call
; the callee is back: its caller read in again, B and the flags kept
ovback: stab kv_tmp
        tpa
        staa kv_tmp+1
        pula                    ; the caller's number
        bsr  ov_load
        ldab kv_tmp
        ldaa kv_tmp+1
        tap
        rts

; ov_call: A = overlay, B = entry
ov_call:
        pshb
        bsr  ov_load
        pulb
        ldaa #3
        mul
        addd #ov_slot
        pshb
        psha
        rts                     ; into the entry's jump

; ov_load: overlay A into the slot (unless it is there), its fix-ups added
ov_load:
        tsta                    ; (0: none: from ovback when the kernel called)
        beq  .x
        cmpa kv_res
        beq  .x
        clr  kv_res
        psha
        clra                    ; the device
        ldab kv_dev
        os   PK$SETP
        pula
        psha
        tab                     ; the index entry: (A - 1) * 2
        clra
        asld
        subd #2
        bsr  .seek
        os   PK$RWRD            ; the overlay's offset
        bsr  .seek
        os   PK$RWRD            ; its length
        subd #OV_SIZE+1
        bcc  .gone              ; (a pack that is not there reads as 0 or $FF)
        addd #OV_SIZE+1
        beq  .gone
        ldx  #ov_slot
        os   PK$READ
        os   PK$RBYT            ; the fix-ups: their length in bytes
        stab kv_cnt
        ldx  #ov_slot
        stx  kv_fo
.f:     tst  kv_cnt
        beq  .done
        os   PK$RBYT
        dec  kv_cnt
        pshb
        lsrb
        lsrb
        lsrb
        lsrb
        bsr  .step
        pulb
        andb #15
        bsr  .step
        bra  .f
.done:  pula
        staa kv_res
.x:     rts
.gone:  ldab #246               ; NO PACK
        jsr  fl_err
        bra  leave
; seek to the overlay area + D
.seek:  addd kv_bpa+1
        xgdx
        ldab kv_bpa
        adcb #0
        os   PK$SADD
        rts
; a step: 1-15 on that far and add the array's address to the word there; 0 on 15
.step:  ldx  kv_fo
        tstb
        bne  .on
        ldab #15
        abx
        stx  kv_fo
        rts
.on:    abx
        stx  kv_fo
        ldd  0,x
        addd kv_base            ; the array's address
        std  0,x
        rts
