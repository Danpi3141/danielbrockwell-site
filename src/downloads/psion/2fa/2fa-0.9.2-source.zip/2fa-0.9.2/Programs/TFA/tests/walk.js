'use strict';
// Interactive-ish walk: node tests/walk.js <model> "<keys>"  - keys separated by spaces;
// words: EXE ON MODE UP DOWN LEFT RIGHT DEL, t:<text> types text, w:<secs> waits, s shows the screen.
const { TFA } = require('./lib');
const model = process.argv[2] || 'lz64';
const four = /lz/.test(model);
const clock = four ? [126, 10, 19, 14, 32, 7] : [42, 10, 19, 14, 32, 7];
const g = new TFA(model, { clock });
g.start(process.env.PROC || 'TFA');
const show = (w) => console.log('--', w, '\n' + g.text());
show('start');
for (const k of (process.argv[3] || '').split(' ').filter(Boolean)) {
  if (k.startsWith('t:')) g.m.type(k.slice(2), 3, 4);
  else if (k.startsWith('w:')) g.run(+k.slice(2));
  else if (k === 's') { show('now'); continue; } else g.press(k, 3, 6);
  g.run(0.6);
  show(k);
}
