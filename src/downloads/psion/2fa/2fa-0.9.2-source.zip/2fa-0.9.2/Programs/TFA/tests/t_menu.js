'use strict';
// Fifty accounts: the name menu in pages (More), every account reachable and showing its own
// codes; eight-letter names; a 64-character key; the device full
const { UI, R } = require('./ui');
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };

// accounts written straight into the key file through the kernel's kf_add
function addRecords(g, list) {
  for (const [name, kind, key] of list) {
    const rec = Buffer.from(name + '\t' + kind + '\t' + key, 'latin1');
    g.write('kv_rec', [rec.length, ...rec]);
    g.call('kf_add');
  }
}
const keyFor = (i) => R.b32encode(Buffer.from(Array.from({ length: 10 + (i % 31) }, (_, j) => (i * 53 + j * 7 + 1) & 255)));
const names = Array.from({ length: 50 }, (_, i) => (i % 2 ? 'Longnm' : 'N') + String(i + 1).padStart(2, '0'));

for (const model of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'lz64']) {
  console.log('==', model);
  const four = /lz/.test(model);
  const g = new UI(model, { clock: four ? [126, 10, 19, 14, 31, 40] : [42, 10, 19, 14, 31, 40], packC: four ? { type: 1, size: 32 } : { type: 0, size: 16 } });
  g.start().confirmDate();
  g.poke('st_dev', 2);          // keys on C: (a Rampak)
  const list = names.map((n, i) => [n, 'A', keyFor(i)]);
  list[49] = [names[49], 'A', 'JBSWY3DPEHPK3PXP'.repeat(4)];          // a 64-character key
  list[48] = [names[48], 'Z', 'ABCDEFGHIJKLMNOP'];                    // a kind not known
  addRecords(g, list);
  ok(g.peekw('kf_n') === 50, 'fifty records: ' + g.peekw('kf_n'));
  g.key('ON', 0.5); g.key('EXE', 0.5);   // (no accounts screen -> add: back out to it, then restart)
  g.key('ON', 1); g.key('ON', 1);
  g.start(); g.run(2);
  // the name menu: page through with More, collecting names
  const seen = new Set();
  g.key('MODE', 1);
  let pages = 0;
  for (; pages < 10; pages++) {
    const before = g.text();
    names.forEach((n) => { if (new RegExp('\b' + n + '\b', 'i').test(before)) seen.add(n); });
    g.key('M', 1.5);             // More (the only item starting with M) - on the last page: a beep
    if (g.text() === before) break;
  }
  g.key('T', 0.8);
  ok(/Add/.test(g.text()), 'Tools on the last page: ' + JSON.stringify(g.lines()[0]));
  ok(pages >= 1 && pages <= 4, 'pages: ' + (pages + 1));
  g.key('ON', 0.6);
  if (process.env.DBG) {
    const m = g.m, sym = Object.entries(g.sym).filter(([n, v]) => v[1] === 'rel').map(([n, v]) => [g.base + v[0], n]).sort((a, b) => a[0] - b[0]);
    const name = (pc) => { let r = '?'; for (const [a, n] of sym) { if (a <= pc) r = n + '+' + (pc - a); else break; } return r; };
    let last = []; m.dbg.setTrace((pc) => { if (pc >= g.base && pc < g.base + 6000) { last.push(pc); if (last.length > 40) last.shift(); } if (pc === g.addr('leave') || pc === g.addr('fl_err')) console.log('  ->', name(pc), 'after', last.slice(-25).map(name).join(' > ')); });
  }
  // every account chosen by its place: from the code screen with DOWN, checking the code
  let bad = 0, unknownOk = false;
  g.run(1);
  for (let i = 0; i < 50; i++) {
    // the account on screen: kv_cur
    const cur = g.peek('kv_cur');
    for (let w = 0; w < 50 && !(g.shown() && (four ? g.shown().rows.length : true)); w++) g.run(0.1);
    const r = g.stable(() => ({ s: g.shown(), t: g.clock() }));
    if (!r.s) { console.log('  not a code screen:', JSON.stringify(g.text())); bad++; g.key('ON', 1); continue; }
    const nm = four ? r.s.rows[0].name : r.s[0].name, code = four ? r.s.rows[0].code : r.s[0].now;
    const [n, kind, key] = list[cur - 1];
    if (kind === 'Z') unknownOk = code === '------';
    else {
      const e = g.expect(key, r.t);
      if (nm.toUpperCase() !== n.toUpperCase() || code !== e.now) { bad++; if (bad < 4) console.log('  mismatch', cur, nm, code, e.now); }
    }
    g.key('DOWN', four ? 1.6 : 0.8);
  }
  ok(bad === 0, 'all fifty accounts show their own codes (64-char key included)');
  ok(unknownOk, 'a kind not known shows ------');
  g.key('ON', 1);
}
console.log(fails ? fails + ' FAILED' : 'all ok');
process.exit(fails ? 1 : 0);
