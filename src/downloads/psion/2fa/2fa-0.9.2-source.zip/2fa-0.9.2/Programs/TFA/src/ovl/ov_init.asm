; =====================================================================
; OV_INIT: the settings read at start and written (A:TFASET)
; =====================================================================
        include "ovhead.inc"
        jmp  set_load
        jmp  set_save

ST_LEN  = st_end-st_dev

set_name: fcl "A:TFASET"

; set_load: the settings from A:TFASET; carry set (and the defaults) if
; there are none or they are damaged
set_load:
        ldx  #set_name
        bsr  fopen
        bcs  .def
        ldd  #1
        os   FL$RSET
        ldx  #kv_rec
        os   FL$READ
        bcs  .def
        ldx  #kv_rec
        ldaa 0,x
        cmpa #1+2*ST_LEN
        bne  .def
        ldaa 1,x
        cmpa #'T'
        bne  .def
        inx
        inx
        stx  kv_src
        ldx  #st_dev
.h:     stx  kv_dst
        ldx  kv_src
        bsr  hexin
        stx  kv_src
        ldx  kv_dst
        staa 0,x
        inx
        cpx  #st_end
        bne  .h
        ldaa st_dev             ; in range, or the defaults
        cmpa #3
        bhs  .def
        ldaa st_zone
        adda #48
        cmpa #48+56+1
        bhs  .def
        clc
        rts
.def:   ldx  #st_dev            ; A:, zone 0, summer off, no PIN, last 1, 2026
        ldab #ST_LEN
.c:     clr  0,x
        inx
        decb
        bne  .c
        ldaa #1
        staa st_last
        ldd  #2026
        std  st_year
        sec
        rts

; two hex digits at X -> A; X moves on
hexin:  bsr  .dig
        asla
        asla
        asla
        asla
        staa T0
        bsr  .dig
        oraa T0
        rts
.dig:   ldaa 0,x
        inx
        suba #'0'
        cmpa #10
        blo  .x
        suba #7
.x:     anda #15
        rts

; set_save: the settings written (the new record first, then the old one
; erased: a power cut leaves one or the other whole)
set_save:
        ldx  #kv_rec+1
        ldaa #'T'
        staa 0,x
        inx
        stx  kv_dst
        ldx  #st_dev
.h:     ldaa 0,x
        inx
        stx  kv_src
        ldx  kv_dst
        bsr  hexout
        stx  kv_dst
        ldx  kv_src
        cpx  #st_end
        bne  .h
        ldaa #1+2*ST_LEN
        staa kv_rec
        ldx  #set_name
        bsr  fopen
        bcc  .w
        ldx  #set_name
        bsr  fcret
        bcs  fl_err
.w:     ldx  #kv_rec
        os   FL$WRIT
        bcs  fl_err
        os   FL$SIZE
        cpx  #1
        beq  .x
        ldd  #1
        os   FL$RSET
        os   FL$ERAS
        bcs  fl_err
.x:     clc
        rts

; A -> two hex digits at X; X moves on
hexout: psha
        lsra
        lsra
        lsra
        lsra
        bsr  .dig
        pula
.dig:   anda #15
        adda #'0'
        cmpa #'9'
        bls  .s
        adda #7
.s:     staa 0,x
        inx
        rts
