'use strict';
// The spec's "Things to try to break": the code screen across midnight, a month end and the year
// end (and a two-line clock rolling over to year 00); the program pack pulled out while codes show;
// the keys' pack pulled out; A: full on a CM (adding refused with a message, nothing half written).
const { UI } = require('./ui');
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
const KEY = 'JBSW Y3DP EHPK 3PXP';
function codeNow(g) {
  for (let i = 0; i < 60 && !g.shown(); i++) g.run(0.1);
  const r = g.stable(() => ({ s: g.shown(), t: g.clock() }));
  const e = g.expect(KEY, r.t);
  const c = g.four ? r.s && r.s.rows[0] && r.s.rows[0].code : r.s && r.s[0].now;
  return { c, want: e.now, t: r.t };
}

// ---- across midnight, a month end, the year end
for (const model of ['cm', 'lz64']) {
  const four = /lz/.test(model);
  const g = new UI(model, { clock: four ? [126, 10, 19, 14, 31, 40] : [42, 10, 19, 14, 31, 40] });
  g.start().confirmDate().add('GitHub', KEY);
  for (const [label, t] of [['midnight', [19, 23, 59, 20]], ['the month end', [29, 23, 59, 20]], ['the year end', [30, 23, 59, 20]]]) {
    const y = four ? 126 : 42;
    const mon = label === 'midnight' ? 10 : 10 + (label === 'the year end' ? 1 : 0);
    g.setClock([y, mon, t[0], t[1], t[2], t[3]]);
    let bad = 0, n = 0;
    for (let s = 0; s < 70; s += 3) {
      g.run(3); n++;
      if (n % 10 === 0) g.press('LEFT', 1, 1);   // (a key now and then: no switching off)
      const r = codeNow(g);
      if (r.c !== r.want) { bad++; console.log('   ', label, r.t.join(','), r.c, 'want', r.want); }
    }
    ok(bad === 0, `${model}: codes right across ${label} (${n} looks)`);
  }
  if (!four) {
    // a two-line clock rolling over from 1999 (2083) to 00: the fault screen, not wrong codes
    g.pokew('st_year', 2083);
    g.setClock([99, 11, 30, 23, 59, 55]);
    g.run(7);
    ok(/Clock year is 00/.test(g.text()), 'two lines: the year rolls over to 00: ' + g.lines()[0]);
    g.key('EXE', 1);
    ok(/\s[ \d]\d \w{3} \d{4}/.test(g.lines()[0]), 'then the clock screen to set it: ' + g.lines()[0]);
  }
}

// ---- the program pack pulled out while codes show (keys on A:)
for (const model of ['cm', 'lz64']) {
  const four = /lz/.test(model);
  const g = new UI(model, { clock: four ? [126, 10, 19, 14, 31, 40] : [42, 10, 19, 14, 31, 40] });
  g.start().confirmDate().add('GitHub', KEY);
  g.m.removePack(0);
  g.run(35);
  let r = codeNow(g);
  ok(r.c === r.want, `${model}: program pack out: the codes go on (${r.c})`);
  g.key('MODE', 1.5);
  ok(/NO PACK|ERROR/i.test(g.text()), 'the menus need the pack: the system\'s message: ' + g.text().replace(/\n/g, '|'));
  g.key('SPACE', 1.5);
  ok(!g.text().includes('?') && g.m.isOn(), 'then out cleanly: ' + g.text().replace(/\n/g, '|'));
  // back in: starts again
  g.m.insertPack(require('path').join(__dirname, '..', 'build', 'game', 'TFA.opk'), 0);
  for (let i = 0; i < 4; i++) g.press('ON', 3, 6);
  g.start(); g.run(2);
  r = codeNow(g);
  ok(r.c === r.want, 'pack back: TFA starts and shows the codes');
}

// ---- the keys' pack (C:) pulled out
{
  const g = new UI('cm', { clock: [42, 10, 19, 14, 31, 40], packC: { type: 0, size: 16 } });
  g.start().confirmDate();
  g.poke('st_dev', 2);
  g.add('GitHub', KEY);
  g.add('Google', 'GEZD GNBV GY3T QOJQ GEZD GNBV GY3T QOJQ');
  g.m.removePack(1);
  g.key('UP', 1.5);
  ok(/NO PACK|ERROR/i.test(g.text()), 'keys\' pack out, another account: the system\'s message: ' + g.text().replace(/\n/g, '|'));
  g.key('SPACE', 2);
  ok(/No accounts yet/.test(g.text()), 'then: no accounts (the keys cannot be found): ' + g.lines()[0]);
  g.key('ON', 1);
}

// ---- A: full on a CM: adding refused with the system's message, nothing half written
{
  const g = new UI('cm', { clock: [42, 10, 19, 14, 31, 40] });
  g.start().confirmDate();
  let n = 0, err = '';
  for (; n < 60; n++) {               // fill A: with records through the kernel
    const rec = Buffer.from('Fill' + n + '\tA\t' + 'JBSWY3DPEHPK3PXP'.repeat(4), 'latin1');
    g.write('kv_rec', [rec.length, ...rec]);
    try { g.call('kf_add', {}, 3); } catch (e) {
      err = g.text();
      g.press('SPACE', 3, 6);                  // the message gone: the call finishes, back to the key wait
      g.m.runTo([g.addr('t_done')], 921600 * 5); g.m.run(4); g.m.dbg.setPC(g.addr('t_idle'));
      break;
    }
  }
  ok(/MEMORY|FULL/i.test(err), `A: full after ${n} records of 70 characters: ${err.replace(/\n/g, '|')}`);
  const count = g.peekw('kf_n');
  g.key('ON', 1); g.run(1);
  g.start(); g.run(2);
  ok(g.peekw('kf_n') === count && g.m.isOn(), `TFA still starts, the file holds ${g.peekw('kf_n')} whole records`);
}
console.log(fails ? fails + ' FAILED' : 'all ok');
process.exit(fails ? 1 : 0);
