'use strict';
// Probe 6: is the switch-off vector bta_sof ($2058) called when the OS switches off by itself
// inside MN$DISP? And what do TMW_TOUT / the frame counter look like afterwards?
const { Probe } = require('./plib');
for (const model of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'xp', 'lz64']) {
  const p = new Probe(model);
  const m = p.m;
  const vecs = {};
  for (let a = 0x2042; a <= 0x2058; a += 2) vecs[a.toString(16)] = m.peekw(a).toString(16);
  console.log(model, 'vectors', JSON.stringify(vecs));
  const sof = m.peekw(0x2058);
  // a menu of two items; TCNT 10 s so the OS switches off soon
  const buf = p.buf();
  let a = p.lbc(buf, 'One'); m.pokew(a, 1); a += 2; a = p.lbc(a, 'Two'); m.pokew(a, 2); a += 2; m.poke(a, 0);
  m.pokew(0x20CD, 10); m.pokew(0x7D, 10);
  let hit = 0;
  m.dbg.setBp(sof);
  const r = p.call('MN$DISP', { x: buf, d: 0x1001 }, () => {
    for (let i = 0; i < 300; i++) {
      const h = m.run(921600 / 10);
      if (h === sof) { hit++; console.log(model, 'bta_sof hit, frames', m.peekw(0x20CB), 'secs', m.peek(0x20CA)); m.dbg.setBp(sof, false); m.run(10); }
      if (!m.isOn()) break;
    }
    console.log(model, 'on?', m.isOn(), 'after', 'frames', m.peekw(0x20CB), 'clock', m.read(0x20C8, 3).join(':'));
    m.runSeconds(20);
    m.press('ON', 3, 10);
    m.runSeconds(0.5);
    console.log(model, 'switched on: TOUT', m.peekw(0x7D), 'frames', m.peekw(0x20CB), 'clock', m.read(0x20C8, 3).join(':'), 'screen\n' + p.scr());
    m.press('EXE');
  });
  console.log(model, 'menu returned', r, 'sof hits', hit);
}
