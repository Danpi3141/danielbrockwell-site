'use strict';
// Random keys for a while (node tests/t_stress.js <model> <seconds> [seed]): TFA must never crash,
// hang, or write over its own resident code; whenever it leaves (ON), it is started again. At the
// end it must still leave and start again.
const { UI } = require('./ui');
const model = process.argv[2] || 'cm', secs = +(process.argv[3] || 300);
let seed = +(process.argv[4] || 12345);
const rnd = () => { seed = (seed * 1103515245 + 12345) >>> 0; return (seed >>> 8) / 16777216; };
const KEYS = ['EXE', 'EXE', 'MODE', 'UP', 'DOWN', 'LEFT', 'RIGHT', 'DEL', 'Y', 'N', 'A', 'G', 'T', 'S', 'P', 'D', 'Z', 'R', 'H', 'C', 'O', 'M', 'K', 'B', 'Q'];
const four = /lz/.test(model);
const g = new UI(model, { clock: four ? [126, 10, 19, 14, 31, 40] : [42, 10, 19, 14, 31, 40], packC: four ? { type: 1, size: 32 } : { type: 0, size: 16 } });
g.start().confirmDate().add('GitHub', 'JBSW Y3DP EHPK 3PXP').add('Google', 'GEZD GNBV GY3T QOJQ GEZD GNBV GY3T QOJQ');
const code0 = g.addr('entry'), codeLen = g.meta.vstart;
const dev = g.addr('kf_name') + 1 - code0;   // the device letter in "A:TFAKEY" (after its length): kf_nm writes it
const sum = () => g.m.read(code0, codeLen).reduce((a, b, i) => (i === dev ? a : (a + b * (i + 1)) % 1000000007), 0);
// TFA is running while the OPL stack (RTA_SP, $A5) is below its array. Its tag stays in the freed memory after
// it leaves, so finding that proves nothing: the keys would go on into the Organiser's own menus and editor.
const running = () => g.sync() >= 0 && g.m.peekw(0xA5) <= g.base && /TFA1/.test(Buffer.from(g.m.read(g.base + 3, 4)).toString());
let ref = sum();
const errs = [];
let restarts = 0, presses = 0, t = 0, lastScreen = '', same = 0;
g.m.logs.length = 0;
while (t < secs) {
  // the program still there?
  if (!running()) {
    if (!g.m.isOn()) { g.press('ON', 3, 10); g.run(1); }
    const scr = g.text();
    if (/ERROR|ERR\b|MEMORY|STACK/i.test(scr) && !/press SPACE|press space/i.test(scr)) errs.push('error screen: ' + scr.replace(/\n/g, '|'));
    for (let i = 0; i < 3; i++) g.press('ON', 3, 6);
    try { g.start(); restarts++; ref = sum(); if (/Is this right/.test(g.text())) g.key('Y'); if (/PIN:/.test(g.text())) { g.type('1357').key('EXE'); } } catch (e) { errs.push('restart failed: ' + e.message.split('\n')[0]); break; }
    continue;
  }
  for (let i = 0; i < 20 && sum() !== ref; i++) g.run(0.02);   // (the LZ64's OS banks memory for a moment in file calls)
  if (sum() !== ref) { errs.push('resident code changed after ' + presses + ' keys'); ref = sum(); }
  let k = KEYS[Math.floor(rnd() * KEYS.length)];
  if (rnd() < 0.02) k = 'ON';
  if (/PIN:|New PIN|Again/.test(g.text()) && rnd() < 0.7) { g.type('1357'); k = 'EXE'; }
  if (/typed/.test(g.text()) && rnd() < 0.5) { g.type('JBSWY3DPEHPK3PXP'.slice(0, 1 + Math.floor(rnd() * 16))); }
  g.press(k, 2, 3);
  presses++;
  const dt = 0.1 + rnd() * 0.6;
  g.run(dt); t += dt + 0.03;
  if (rnd() < 0.003) { g.run(130); t += 130; }       // now and then left idle: switched off, then on
  if (!g.m.isOn()) { g.press('ON', 3, 10); g.run(1); }
  const scr = g.text();
  if (scr === lastScreen) same++; else same = 0;
  lastScreen = scr;
  if (g.m.logs.some((l) => /Stack error/.test(l))) { errs.push('stack error after ' + presses + ' keys'); g.m.logs.length = 0; }
}
// at the end: back to the code screen and the first account right
for (let i = 0; i < 4; i++) g.press('ON', 3, 6);
g.run(1);
try {
  g.start(); if (/Is this right/.test(g.text())) g.key('Y'); if (/PIN:/.test(g.text())) g.type('1357').key('EXE'); g.run(2);
  g.key('MODE', 0.8); g.key('G', 0.6); if (/GOOGLE|Google/.test(g.lines()[0].slice(0, 9)) || /Tools/.test(g.text())) { /* menu */ }
  g.key('EXE', 2);
} catch (e) { errs.push('final start: ' + e.message.split('\n')[0]); }
if (secs >= 600 && !restarts) errs.push('TFA never left: the test did not see it go');
console.log(`${model}: ${presses} keys, ${restarts} restarts, ${Math.round(t)} s; screen now ${JSON.stringify(g.text())}`);
if (errs.length) { console.log('FAIL\n  ' + errs.slice(0, 20).join('\n  ')); process.exit(1); }
console.log('ok');
