; =====================================================================
; OV_PSET: Setup > PIN: setting, changing or removing it (every key rewritten)
; =====================================================================
        include "ovhead.inc"
        jmp  set_pin




; ---- Setup > PIN ------------------------------------------------------
pin_m:  fcl  "Change"
        fdb  0
        fcl  "Off"
        fdb  0
        fcb  0
set_pin:
        ldaa st_flags
        anda #FL_PIN
        bne  .on
        ovsub OV_PIN,3            ; off: a new PIN and a new salt
        bcs  .x
        ldaa FRC+1              ; the salt: four letters from the timer and the clock
        ldab TMB_YEAR+5
        aba
        ldx  #st_salt
        ldab #4
.sa:    pshb
        ldab FRC+1
        aba
        anda #15
        adda #'A'
        staa 0,x
        rola
        eora TMW_FRAM+1
        inx
        pulb
        decb
        bne  .sa
        ldaa #1                 ; scrambled from now on
        bra  .conv
.on:    ldx  #pin_m             ; on: change it, or off
        bsr  menu
        bcs  .x
        tstb
        bne  .off
        ovsub OV_PIN,3
        bcs  .x
        ldaa #1
        bra  .conv
.off:   clra
; every key rewritten: unscrambled by the PIN in pin_buf (if it was
; scrambled), then scrambled by pin_new if A = 1, else kept plain (kind A)
.conv:  staa kv_pon
        ldx  #pin_buf           ; the old PIN kept in kv_pin2
        ldd  #kv_pin2
        std  kv_to
        ldab #PIN_MAX+1
        bsr  copy
        bsr  cls
        bsr  pri
        fcl  "Working..."
        bsr  kf_open
        bcs  .set               ; no keys yet
        ldd  kf_n
        stab kv_j
        beq  .set
.r:     ldx  #kv_pin2           ; the old PIN to unscramble
        ldd  #pin_buf
        std  kv_to
        ldab #PIN_MAX+1
        bsr  copy
        ldd  #1                 ; record 1 each time: rewritten at the end, then erased
        bsr  kf_read
        bcs  .x
        bsr  ac_secret
        bcs  .keep              ; a kind not known: copied as it is
        ldx  #pin_nw           ; the new PIN from here on
        ldd  #pin_buf
        std  kv_to
        ldab #PIN_MAX+1
        bsr  copy
        ldaa #'A'
        tst  kv_pon
        beq  .pl
        ovsub OV_STRM,0
        ldaa #'B'
.pl:    staa ac_kind+1
        bsr  b32enc
        bsr  ac_make
.keep:  bsr  kf_add
        bcs  .x
        ldd  #1
        bsr  kf_del
        bcs  .x
        dec  kv_j
        bne  .r
.set:   ldaa st_flags           ; the settings
        anda #255-FL_PIN
        tst  kv_pon
        beq  .f
        oraa #FL_PIN
.f:     staa st_flags
        ldx  #pin_nw
        ldd  #pin_buf
        std  kv_to
        ldab #PIN_MAX+1
        bsr  copy
        ovsub OV_PIN,2
        ldaa kv_chk
        staa st_check
        ovjump OV_INIT,1
.x:     rts


        include "recs.inc"
