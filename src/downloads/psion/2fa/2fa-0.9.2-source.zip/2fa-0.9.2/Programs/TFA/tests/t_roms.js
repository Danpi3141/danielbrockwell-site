'use strict';
// Every Organiser ROM the emulator has (29): start, the date check, add an account, its codes
// against ref/totp.js, Help's self-test, leave; on two-line ROMs CLOCK shows the real date.
const { UI } = require('./ui');
const { ROMS } = require('./lib');
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
const only = process.argv.slice(2);
for (const rom of Object.keys(ROMS)) {
  if (only.length && !only.includes(rom)) continue;
  const four = /lz/.test(rom);
  try {
    const g = new UI(rom, { clock: four ? [126, 10, 19, 14, 31, 40] : [42, 10, 19, 14, 31, 40] });
    g.start();
    const date = g.lines()[0].trim();
    g.confirmDate();
    g.add('GitHub', 'JBSW Y3DP EHPK 3PXP');
    g.run(1);
    const r = g.stable(() => ({ s: g.shown(), t: g.clock() }));
    const e = g.expect('JBSW Y3DP EHPK 3PXP', r.t);
    const code = four ? r.s && r.s.rows[0] && r.s.rows[0].code : r.s && r.s[0].now;
    g.key('MODE', 0.6); g.toolsItem('Help'); g.key('T', 3);
    const st = /Self-test OK/.test(g.text());
    g.key('EXE', 1.5); g.key('ON', 1.5);
    let clk = '';
    if (!four) { g.start('CLOCK'); clk = g.lines()[0].trim(); g.key('ON', 1); }
    ok(code === e.now && st && (four || /20 NOV 2026/i.test(clk)), `${rom.padEnd(13)} date "${date}" code ${code} (want ${e.now}) self-test ${st ? 'OK' : 'FAILED'}${four ? '' : ' CLOCK "' + clk + '"'}`);
  } catch (err) {
    fails++;
    console.log('FAIL', rom, err.message.split('\n').slice(0, 3).join(' | '));
  }
}
console.log(fails ? fails + ' FAILED' : 'all ok');
process.exit(fails ? 1 : 0);
