; =====================================================================
; OV_PIN: the PIN asked for (at start and after switching on), its entry and check
; =====================================================================
        include "ovhead.inc"
        jmp  pin_gate
        jmp  pin_in
        jmp  pin_chk
        jmp  pin_new

; The PIN: 4-8 digits, kept nowhere. The settings hold a salt (4
; characters) and a check (one hex digit from SHA-1 of the PIN and the
; salt: 1 wrong PIN in 16 passes it, by design). Keys are scrambled with
; SHA-1(PIN, salt, name, n) (kacct.asm ac_stream).
; =====================================================================


; pin_in: "<prompt>" at line A then the digits as stars, into the lbc at X.
; X points to the prompt (lbc) on entry: kv_pmt. Out: carry set if ON/CLEAR.
pin_in: ldaa kv_pln
        bsr  clrl
        ldx  #m_pin             ; the prompt: kv_pmt 0 PIN, 1 New PIN, 2 Again (at most 8 characters)
        ldab kv_pmt
        beq  .pm
        ldx  #m_new
        decb
        beq  .pm
        ldx  #m_again
.pm:
        bsr  prs
        ldaa #' '
        bsr  emit
        ldaa DPB_CPOS
        staa kv_npos
        ldx  kv_pdst
        clr  0,x
        ldab KBB_STAT           ; numbers without SHIFT while it is typed
        stab kv_kbst
        orab #$40
        os   KB$STAT
.s:     ldaa kv_npos            ; the stars
        clrb
        os   DP$STAT
        ldx  kv_pdst
        ldab 0,x
        pshb
.st:    tstb
        beq  .cl
        ldaa #'*'
        bsr  emit
        decb
        bra  .st
.cl:    pula                    ; spaces after the stars: PIN_MAX - length
        nega
        adda #PIN_MAX
        tab
        bsr  spaces
        ldx  kv_pdst
        ldaa kv_npos
        adda 0,x
        ldab #$80
        os   DP$STAT
.k:     bsr  getk
        cmpb #K_ON
        beq  .no
        cmpb #K_DEL
        beq  .del
        cmpb #K_EXE
        beq  .exe
        cmpb #'0'
        blo  .bad
        cmpb #'9'
        bhi  .bad
        ldx  kv_pdst
        ldaa 0,x
        cmpa #PIN_MAX
        bhs  .bad
        inca
        staa 0,x
        pshb
        tab
        abx
        pulb
        stab 0,x
        bra  .s
.del:   ldx  kv_pdst
        tst  0,x
        beq  .bad
        dec  0,x
        bra  .s
.exe:   ldx  kv_pdst
        ldaa 0,x
        cmpa #PIN_MIN
        bhs  .ok
.bad:   bsr  beep
        bra  .k
.ok:    bsr  .kb
        clc
        rts
.no:    bsr  .kb
        sec
        rts
.kb:    ldab kv_kbst            ; the keyboard as it was (KB$STAT changes the carry on an LZ)
        os   KB$STAT
        rts

; pin_chk: A = the check digit for pin_buf and st_salt
pin_chk:
        bsr  clrw               ; PIN digits and salt, straight into the hash's block
        ldx  #sh_w
        stx  kv_to
        ldx  #pin_buf
        ldab 0,x
        inx
        pshb
        bsr  copy
        pulb
        ldx  #sh_w
        abx
        stx  kv_to
        ldx  #st_salt
        ldab #4
        bsr  copy
        ldab pin_buf
        addb #4
        bsr  sha_msgw
        ldaa sh_h
        lsra
        lsra
        lsra
        lsra
        adda #'0'
        staa kv_chk
        rts

m_pin:  fcl  "PIN:"
m_new:  fcl  "New PIN"
m_again: fcl "Again: "

; pin_gate: if a PIN is set, it is asked for: three tries, then a wait that
; doubles each time. ON/CLEAR leaves the program.
pin_gate:
        ldaa st_flags
        anda #FL_PIN
        beq  .x
        clr  kv_tries
        ldaa #15
        staa kv_wait
.ask:   bsr  cls
        clr  kv_pmt
        clr  kv_pln
        ldx  #pin_buf
        stx  kv_pdst
        bsr  pin_in
        bcs  .out
        bsr  pin_chk
        cmpa st_check
        beq  .x
        inc  kv_tries
        ldaa kv_tries
        cmpa #3
        blo  .ask
        bsr  cls                ; a wait: "Wrong PIN" / "Wait 15s"
        bsr  pri
        fcl  "Wrong PIN"
        ldaa kv_wait
        staa kv_left
.w:     ldaa #1
        clrb
        bsr  at
        bsr  pri
        fcl  "Wait "
        clra
        ldab kv_left
        bsr  prnum
        bsr  pri
        fcl  "s  "
        ldab #20                ; a second
.f:     pshb
        bsr  pollk
        cmpb #K_ON
        pulb
        beq  .out
        ldaa TMW_FRAM+1         ; (pollk returns at each frame)
        decb
        bne  .f
        dec  kv_left
        bne  .w
        ldaa kv_wait            ; next time twice as long (to about 16 minutes)
        bmi  .ask
        asl  kv_wait
        bra  .ask
.out:   bra  leave
.x:     rts
; pin_new: a new PIN typed twice into pin_nw (carry set if abandoned)
pin_new:
        bsr  cls
        ldaa #1
        staa kv_pmt
        clr  kv_pln
        ldx  #pin_nw
        stx  kv_pdst
        bsr  pin_in
        bcs  .x
        ldaa #2
        staa kv_pmt
        ldaa #1
        staa kv_pln
        ldx  #kv_pin2
        stx  kv_pdst
        bsr  pin_in
        bcs  .x
        ldx  #pin_nw           ; the same twice?
        ldaa 0,x
        cmpa kv_pin2
        bne  .no
        ldab 0,x
.c:     inx
        ldaa 0,x
        cmpa PIN_MAX+1,x        ; (kv_pin2 follows pin_nw: 9 bytes on)
        bne  .no
        decb
        bne  .c
        clc
.x:     rts
.no:    bsr  beep
        bra  pin_new

        include "sha.inc"
