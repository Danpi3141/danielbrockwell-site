'use strict';
// Where a SHA-1 block's cycles go: cycles counted between instruction starts, by kernel label.
const { TFA } = require('./lib');
const g = new TFA(process.argv[2] || 'cm').start();
const labels = Object.entries(g.sym).filter(([n, v]) => v[1] === 'rel' && !n.includes('.')).map(([n, v]) => [g.base + v[0], n]).sort((a, b) => a[0] - b[0]);
const loc = Object.entries(g.sym).filter(([n, v]) => v[1] === 'rel').map(([n, v]) => [g.base + v[0], n]).sort((a, b) => a[0] - b[0]);
const name = (pc, tab) => { let r = '?'; for (const [a, n] of tab) { if (a <= pc) r = n; else break; } return r; };
const by = {};
let lastPc = -1, lastCyc = 0;
const m = g.m;
g.call('sha_init');
m.dbg.setTrace((pc) => {
  const c = m.cycles();
  if (lastPc >= 0) { const k = name(lastPc, loc); by[k] = (by[k] || 0) + (c - lastCyc); }
  lastPc = pc; lastCyc = c;
});
const total = g.timed('sha_blk');
m.dbg.setTrace(null);
console.log('total', total);
Object.entries(by).sort((a, b) => b[1] - a[1]).slice(0, 25).forEach(([k, v]) => console.log(k.padEnd(20), v, (100 * v / total).toFixed(1) + '%'));
