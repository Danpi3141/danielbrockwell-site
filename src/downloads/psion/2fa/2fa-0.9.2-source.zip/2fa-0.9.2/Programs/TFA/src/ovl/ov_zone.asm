; =====================================================================
; OV_ZONE: Setup > Zone, Setup > Summer
; =====================================================================
        include "ovhead.inc"
        jmp  set_zone
        jmp  set_sum


; ---- Zone ----------------------------------------------------------------
; quarter hours from UTC, -48 (-12:00) to +56 (+14:00); LEFT/RIGHT a quarter,
; UP/DOWN an hour
set_zone:
        ldaa st_zone
        staa kv_d
.d:     bsr  cls
        bsr  pri
        fcl  "Zone: "
        ldab #'+'
        ldaa kv_d
        bpl  .p
        ldab #'-'
        nega
.p:     psha
        tba
        bsr  emit
        pula
        tab
        lsra                    ; hours
        lsra
        bsr  prnum1
        ldaa #':'
        bsr  emit
        andb #3                 ; minutes
        ldaa #15
        mul
        tba
        bsr  pr2
        ldaa #1
        clrb
        bsr  at
        bsr  pri
        fcl  "from UTC"
.k:     bsr  getk
        cmpb #K_ON
        beq  .x
        cmpb #K_EXE
        beq  .set
        ldaa #1
        cmpb #K_RIGHT
        beq  .add
        ldaa #-1
        cmpb #K_LEFT
        beq  .add
        ldaa #4
        cmpb #K_UP
        beq  .add
        ldaa #-4
        cmpb #K_DOWN
        bne  .k
.add:   adda kv_d
        cmpa #-48
        blt  .k
        cmpa #56
        bgt  .k
        staa kv_d
        bra  .d
.set:   ldaa kv_d
        staa st_zone
        ovjump OV_INIT,1
.x:     rts

; A (0-99) as a number
prnum1: pshb                    ; (B kept)
        tab
        clra
        bsr  prnum
        pulb
        rts

; ---- Summer time (two lines) ------------------------------------------------
set_sum:
        ldaa st_flags
        staa kv_d
.d:     bsr  cls
        bsr  pri
        fcl  "Summer time: "
        ldaa kv_d
        anda #FL_SUM
        beq  .off
        bsr  pri
        fcl  "On "
        bra  .k
.off:   bsr  pri
        fcl  "Off"
.k:     bsr  getk
        cmpb #K_ON
        beq  .x
        cmpb #K_EXE
        beq  .set
        ldaa kv_d
        eora #FL_SUM
        staa kv_d
        bra  .d
.set:   ldaa kv_d
        staa st_flags
        ovjump OV_INIT,1
.x:     rts
