// The main suite: node tests/run_all.js [--quick]   (t_roms, t_stress and m_mem run on their own)
'use strict';
const { execFileSync } = require('child_process');
const path = require('path');
const quick = process.argv.includes('--quick');
const tests = ['t_engine', 't_ui', 't_clock', 't_clkscr', 't_settings', 't_menu', 't_off', 't_break', 't_leave', 't_mixed'];
let bad = 0;
for (const t of tests) {
  if (quick && ['t_break', 't_off', 't_menu'].includes(t)) continue;
  const t0 = Date.now();
  let out = '', ok = true;
  try { out = execFileSync('node', [path.join(__dirname, t + '.js')], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }); } catch (e) { ok = false; out = (e.stdout || '') + (e.stderr || ''); }
  const fails = out.split('\n').filter((l) => l.startsWith('FAIL'));
  console.log(`${ok ? 'ok  ' : 'FAIL'} ${t.padEnd(12)} ${((Date.now() - t0) / 1000).toFixed(0)} s${fails.length ? '  ' + fails.slice(0, 3).join(' / ') : ''}${!ok && !fails.length ? '  ' + out.trim().split('\n').slice(-3).join(' | ') : ''}`);
  if (!ok) bad++;
}
console.log(bad ? bad + ' FAILED' : 'all ok');
process.exit(bad ? 1 : 0);
