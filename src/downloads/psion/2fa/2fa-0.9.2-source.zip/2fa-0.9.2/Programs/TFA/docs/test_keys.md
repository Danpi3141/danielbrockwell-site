# Test keys for Psion 2FA

Made by `node tools/testkeys.js --md docs/test_keys.md` from `ref/totp.js` (Node's own HMAC-SHA-1; its RFC values are checked by `node ref/totp.js`). Type a key on the Psion (Tools > Add) and on a phone app; set the clock (two-line Organisers: Setup > Clock, or CLOCK) to a time below and compare.

Codes are six digits on a 30-second step (the standard). "Next" is the code for the step after.

## The keys

| Name | Key (typed in groups of four) | Bytes (hex) | Notes |
|---|---|---|---|
| GitHub | `JBSW Y3DP EHPK 3PXP` | `48656c6c6f21deadbeef` | the spec's sample key ("Hello!" and DEADBEEF), 16 characters |
| RFC | `GEZD GNBV GY3T QOJQ GEZD GNBV GY3T QOJQ` | `3132333435363738393031323334353637383930` | RFC 4226 / 6238 test key: the ASCII "12345678901234567890", 32 characters |
| Amazon | `MFRG GZDF MZTW Q2LK` | `6162636465666768696a` | 10 bytes, 16 characters (used in the tests) |
| Google | `JBSW Y3DP EHPK 3PXP JBSW Y3DP EH` | `48656c6c6f21deadbeef48656c6c6f21` | 16 bytes, 26 characters: the length many sites give (2 bits left over) |
| Long | `JBSW Y3DP EHPK 3PXP JBSW Y3DP EHPK 3PXP JBSW Y3DP EHPK 3PXP JBSW Y3DP EHPK 3PXP` | `48656c6c6f21deadbeef48656c6c6f21deadbeef48656c6c6f21deadbeef48656c6c6f21deadbeef` | 40 bytes, 64 characters: the longest the program takes |
| Letters | `ABCD EFGH IJKL MNOP QRST UVWX YZ23 4567` | `00443214c74254b635cf84653a56d7c675be77df` | every character of the alphabet once, 32 characters |
| Psion | `KBZW S33O EBHX EZ3B NZUX GZLS EE` | `5073696f6e204f7267616e6973657221` | the bytes of "Psion Organiser!" (16), 26 characters |

## Codes at fixed times (zone +0:00, UTC)

| Time (UTC) | Two-line clock year | Step | GitHub | RFC | Amazon | Google | Long | Letters | Psion |
|---|---|---|---|---|---|---|---|---|---|
| 2026-11-20 14:32:07 (spec sample) | 1942 | 59839504 | 787 941 / 187 523 | 362 714 / 037 264 | 618 571 / 606 468 | 614 294 / 756 868 | 118 195 / 975 596 | 725 381 / 834 627 | 176 287 / 874 480 |
| 1970-01-01 00:00:59 (RFC 59 s) | - | 1 | 996 554 / 602 287 | 287 082 / 359 152 | 765 705 / 816 065 | 744 635 / 644 925 | 092 609 / 430 123 | 408 553 / 375 962 | 748 065 / 721 786 |
| 2005-03-18 01:58:29 (RFC 1111111109) | 1921 | 37037036 | 071 271 / 358 462 | 081 804 / 050 471 | 319 116 / 100 631 | 582 920 / 691 746 | 813 582 / 101 405 | 594 936 / 966 206 | 277 541 / 837 038 |
| 2005-03-18 01:58:31 (RFC 1111111111) | 1921 | 37037037 | 358 462 / 490 635 | 050 471 / 266 759 | 100 631 / 666 096 | 691 746 / 119 611 | 101 405 / 792 776 | 966 206 / 322 051 | 837 038 / 751 298 |
| 2009-02-13 23:31:30 (RFC 1234567890) | 1925 | 41152263 | 742 275 / 835 227 | 005 924 / 590 587 | 434 900 / 608 602 | 635 050 / 449 235 | 398 980 / 270 467 | 111 313 / 019 660 | 822 665 / 342 684 |
| 2033-05-18 03:33:20 (RFC 2000000000) | 1949 | 66666666 | 890 699 / 620 710 | 279 037 / 637 009 | 443 123 / 485 245 | 313 117 / 515 136 | 507 497 / 640 513 | 660 985 / 859 457 | 307 003 / 304 141 |
| 2027-01-01 00:00:00 (2027 new year) | 1943 | 59958720 | 386 398 / 281 742 | 081 419 / 190 863 | 722 786 / 641 205 | 439 223 / 341 271 | 068 710 / 221 000 | 987 406 / 549 381 | 245 650 / 392 302 |
| 2028-02-29 12:00:00 (leap day 2028) | 1944 | 61181280 | 685 695 / 778 580 | 615 451 / 135 253 | 929 009 / 253 721 | 715 566 / 590 308 | 925 940 / 579 694 | 820 321 / 468 635 | 111 019 / 358 920 |
| 2038-01-19 03:14:08 (past 2038 (32-bit seconds)) | 1954 | 71582788 | 583 145 / 831 111 | 703 886 / 302 373 | 070 564 / 445 311 | 197 727 / 187 994 | 647 865 / 715 893 | 093 787 / 295 542 | 862 923 / 388 081 |
| 2054-01-01 00:00:00 (2054 (past 2053)) | 1970 | 88361280 | 030 392 / 418 564 | 133 187 / 139 571 | 873 868 / 716 159 | 221 373 / 687 387 | 717 624 / 119 826 | 148 258 / 113 596 | 473 474 / 143 883 |
| 2083-12-31 23:59:59 (last of 2083) | 1999 | 119917439 | 366 069 / 242 481 | 157 021 / 667 930 | 426 516 / 365 882 | 508 550 / 728 735 | 717 723 / 103 612 | 238 880 / 725 277 | 925 410 / 254 758 |
| 2084-01-01 00:00:00 (2084 (112 behind)) | 1972 | 119917440 | 242 481 / 629 847 | 667 930 / 306 212 | 365 882 / 256 649 | 728 735 / 289 073 | 103 612 / 198 728 | 725 277 / 830 099 | 254 758 / 927 138 |

Each cell is the code now / the next code. The RFC rows agree with RFC 6238's table (its eight-digit codes end in these six digits) for the RFC key.

## Codes against a counter (RFC 4226, the RFC key)

| Step | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 |
|---|---|---|---|---|---|---|---|---|---|---|
| Code | 755224 | 287082 | 359152 | 969429 | 338314 | 254676 | 287922 | 162583 | 399871 | 520489 |

## The self-test (Tools > Help > Test)

SHA-1 of "abc" = `a9993e364706816aba3e25717850c26c9cd0d89d`; the RFC key at step 0 = 755224, at step 37,037,036 = 081804.
