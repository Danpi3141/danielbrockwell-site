; =====================================================================
; OV_ADD: adding an account (the key editor is OV_KEY, the check OV_CHK)
; =====================================================================
        include "ovhead.inc"
        jmp  add_acc

add_acc:
        clr  kv_self
        clr  RTB_BL             ; the name: empty to start
.name:  bsr  cls
        tst  kv_four
        beq  .n2
        bsr  pri
        fcl  "New account"
        ldaa #1
        clrb
        bsr  at
.n2:    bsr  ed_name
        bcs  .x
        clr  kt_len
.key:   ovsub OV_KEY,0             ; the key, in our own editor
        bcs  .x
        ovsub OV_CHK,0            ; the check against a phone
        bcs  .key               ; N: back to the key, everything still there
        ldab st_flags           ; Y: saved (scrambled if there is a PIN)
        andb #FL_PIN
        bne  .scr
        ldaa #'A'               ; kind A: the key as typed (kt)
        bra  .kind
.scr:   ovsub OV_STRM,0          ; kind B: kb_key (decoded by chk_key) scrambled
        bsr  b32enc
        ldaa #'B'
.kind:  staa ac_kind+1
        ldaa #1
        staa ac_kind
        bsr  ac_make
        bsr  kf_add
        bcs  .x
        ldaa kf_n+1
        staa kv_cur
.x:     rts

        include "names.inc"
        include "recs.inc"
