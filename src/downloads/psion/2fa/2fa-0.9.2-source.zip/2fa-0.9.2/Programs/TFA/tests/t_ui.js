'use strict';
// The main flows on each model: first run, adding, the code screens against ref/totp.js across
// changeovers, moving between accounts, leaving and starting again, rename, delete.
const { UI } = require('./ui');
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };

const KEYS = [['GitHub', 'JBSW Y3DP EHPK 3PXP'], ['Google', 'GEZD GNBV GY3T QOJQ GEZD GNBV GY3T QOJQ'], ['Amazon', 'MFRG GZDF MZTW Q2LK']];

function checkScreen(g, accts, label) {
  // every shown code against the reference, read while the clock holds still
  const r = g.stable(() => ({ s: g.shown(), t: g.clock(), text: g.text() }));
  if (!g.four) {
    const a = accts[0];
    const e = g.expect(a[1], r.t);
    ok(r.s && r.s[0].name === a[0].toUpperCase() && r.s[0].now === e.now && r.s[0].next === e.next && r.s[0].left === e.left,
      `${label}: ${a[0]} ${e.now} next ${e.next} ${e.left}s  [${r.text.replace(/\n/g, ' | ')}]`);
  } else {
    let good = r.s && r.s.rows.length === accts.length;
    accts.forEach((a, i) => {
      const e = g.expect(a[1], r.t);
      const row = r.s && r.s.rows[i];
      good = good && row && row.name === a[0].toUpperCase() && row.code === (row.next ? e.next : e.now);
    });
    const e0 = g.expect(accts[0][1], r.t);
    good = good && (r.s.cells === Math.floor(e0.left * 3 / 5) || r.s.cells === Math.floor((e0.left % 30 + 1) * 3 / 5));   // (drawn within 50 ms of the tick)
    ok(good, `${label}: ${accts.map((a) => a[0]).join(',')} bar ${r.s && r.s.cells}  [${r.text.replace(/\n/g, ' | ')}]`);
  }
}

for (const model of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'xp', 'la', 'lz', 'lz64']) {
  console.log('==', model);
  const four = /lz/.test(model);
  const g = new UI(model, { clock: four ? [126, 10, 19, 14, 31, 40] : [42, 10, 19, 14, 31, 40] });
  g.start();
  ok(/20 NOV 2026/i.test(g.text()) && /Is this right/.test(g.text()), 'first run: the date check ' + JSON.stringify(g.lines()[0]));
  g.confirmDate();
  ok(g.has(/No accounts yet/), 'no accounts screen');
  // MODE there: the Tools menu; Help > Test and back to the no-accounts screen
  g.key('MODE', 0.8); g.key('H', 0.8); g.key('T', 3);
  ok(g.has(/Self-test OK/), 'from no accounts: Tools > Help > Test: ' + g.lines()[0]);
  g.key('EXE', 1.5);
  ok(g.has(/No accounts yet/), 'and back to no accounts: ' + g.lines()[0]);
  g.add(...KEYS[0]);
  checkScreen(g, [KEYS[0]], 'one account');
  // across a changeover
  const left = g.expect(KEYS[0][1]).left;
  g.run(left + 1.5);
  checkScreen(g, [KEYS[0]], 'after the changeover');
  g.add(...KEYS[1]);
  g.add(...KEYS[2]);
  g.run(0.5);
  // the last added is shown (on four lines: from it on)
  if (four) checkScreen(g, [KEYS[2]], 'after adding three (the third at the top)');
  else checkScreen(g, [KEYS[2]], 'after adding three');
  g.key('DOWN', four ? 2.5 : 1.2);          // round to the first
  checkScreen(g, four ? KEYS : [KEYS[0]], 'DOWN wraps to the first');
  g.key('DOWN', four ? 2.5 : 1.2);
  checkScreen(g, four ? [KEYS[1], KEYS[2]] : [KEYS[1]], 'DOWN');
  g.key('UP', four ? 2.5 : 1.2);
  if (four) {
    g.key('RIGHT', 0.3);
    const s = g.stable(() => g.shown());
    ok(s.rows.length === 3 && s.rows.every((r) => r.next), 'RIGHT shows the next codes with >');
    checkScreen(g, KEYS, 'RIGHT');
    g.key('LEFT', 0.3);
    ok(g.stable(() => g.shown()).rows.every((r) => !r.next), 'a key goes back to the codes now');
  }
  // the name menu chooses an account
  g.key('MODE', 0.6);
  ok(g.has(/GOOGLE|Google/) && g.has(/Tools/), 'name menu: ' + JSON.stringify(g.lines()[0]));
  g.key('A', 1.2);              // Amazon (the only A)
  checkScreen(g, four ? [KEYS[2]] : [KEYS[2]], 'chosen from the menu');
  // leave and start again: no date check, the same account
  g.key('ON', 1);
  ok(!g.sync() || true, 'left');
  g.run(1);
  g.start();
  g.run(1.2);
  checkScreen(g, [KEYS[2]], 'started again on the account shown last');
  // rename Google to Mail
  g.key('MODE', 0.6); g.toolsItem('Rename');
  g.waitFor(/GITHUB|Github/);
  g.key('G', 0.4);              // GitHub is first: G moves to the next G, Google
  g.key('EXE', 0.6);
  g.waitFor(/Name:/);
  g.key('ON', 0.3);
  g.type('Mail').key('EXE', 1.5);
  const renamed = [['Mail', KEYS[1][1]]];
  checkScreen(g, renamed, 'renamed (now the last)');
  // a name already used is refused
  g.key('MODE', 0.6); g.toolsItem('Rename');
  g.key('EXE', 0.6);            // the first: GitHub
  g.waitFor(/Name:/);
  g.key('ON', 0.3).type('MAIL').key('EXE', 0.6);
  ok(g.has(/Name:/), 'a name in use is refused');
  g.key('ON', 0.3).key('ON', 1);
  // delete Amazon
  g.key('MODE', 0.6); g.toolsItem('Delete');
  g.key('A', 0.6);
  ok(g.has(/Delete AMAZON\?/i), 'delete asks ' + JSON.stringify(g.lines()[0]));
  g.key('N', 1);
  g.key('MODE', 0.6); g.toolsItem('Delete'); g.key('A', 0.6); g.key('Y', 1.5);
  g.key('MODE', 0.6);
  ok(!g.has(/AMAZON|Amazon/) && g.has(/GITHUB|Github/) && g.has(/MAIL|Mail/), 'deleted: ' + JSON.stringify(g.lines().join('|')));
  g.key('ON', 1);
}
console.log(fails ? fails + ' FAILED' : 'all ok');
process.exit(fails ? 1 : 0);
