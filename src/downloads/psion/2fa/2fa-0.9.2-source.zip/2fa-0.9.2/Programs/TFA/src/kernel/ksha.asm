; =====================================================================
; SHA-1 on one 64-byte block (RFC 3174), big-endian like the 6303.
; sha_blk: sh_h (5 words) is updated with the block in sh_w (16 words,
; used as the ring of message words: each new word is made in place).
; Zero page during a block: T0-T3 the round's sum, T4-T7 a scratch word,
; T8 the word's offset in the ring, T9 the round number, T10 its group.
; No OS calls inside, so the scratch is safe.
; =====================================================================

sha_blk:
        ldx  #sh_h              ; working values a..e = h
        ldab #20
.cp:    ldaa 0,x
        staa 20,x               ; sh_v follows sh_h
        inx
        decb
        bne  .cp
        clr  T9
.rnd:   ldab T9
        andb #15
        aslb
        aslb
        stab T8                 ; the word's offset s = (t & 15) * 4
        ldx  #sh_w
        abx
        ldd  0,x                ; T = W[s]
        std  T0
        ldd  2,x
        std  T2
        ldaa T9
        cmpa #16
        blo  .wok
        ldab T8                 ; W[t] = rol1(W[t-3] ^ W[t-8] ^ W[t-14] ^ W[t-16])
        addb #8
        bsr  sh_wx
        ldab T8
        addb #32
        bsr  sh_wx
        ldab T8
        addb #52
        bsr  sh_wx
        ldaa T0
        rola                    ; carry = bit 31
        ldd  T2
        rolb
        rola
        std  T2
        ldd  T0
        rolb
        rola
        std  T0
        ldx  #sh_w
        ldab T8
        abx
        ldd  T0
        std  0,x
        ldd  T2
        std  2,x
.wok:   ldaa T9                 ; the group: 0-19, 20-39, 40-59, 60-79
        clrb
.grp:   suba #20
        bcs  .gk
        addb #4
        bra  .grp
.gk:    stab T10                ; group * 4
        ldaa T10                ; T += f, a byte at a time from the lowest: the logic
        beq  .ch                ; instructions and the stores leave the carry alone
        cmpa #8
        beq  .maj
        ldaa sh_v+7
        eora sh_v+11
        eora sh_v+15
        adda T3
        staa T3
        ldaa sh_v+6
        eora sh_v+10
        eora sh_v+14
        adca T2
        staa T2
        ldaa sh_v+5
        eora sh_v+9
        eora sh_v+13
        adca T1
        staa T1
        ldaa sh_v+4
        eora sh_v+8
        eora sh_v+12
        adca T0
        staa T0
        bra  .fs
.ch:
        ldaa sh_v+11
        eora sh_v+15
        anda sh_v+7
        eora sh_v+15
        adda T3
        staa T3
        ldaa sh_v+10
        eora sh_v+14
        anda sh_v+6
        eora sh_v+14
        adca T2
        staa T2
        ldaa sh_v+9
        eora sh_v+13
        anda sh_v+5
        eora sh_v+13
        adca T1
        staa T1
        ldaa sh_v+8
        eora sh_v+12
        anda sh_v+4
        eora sh_v+12
        adca T0
        staa T0
        bra  .fs
.maj:
        ldaa sh_v+7
        oraa sh_v+11
        anda sh_v+15
        staa T11
        ldaa sh_v+7
        anda sh_v+11
        oraa T11
        adda T3
        staa T3
        ldaa sh_v+6
        oraa sh_v+10
        anda sh_v+14
        staa T11
        ldaa sh_v+6
        anda sh_v+10
        oraa T11
        adca T2
        staa T2
        ldaa sh_v+5
        oraa sh_v+9
        anda sh_v+13
        staa T11
        ldaa sh_v+5
        anda sh_v+9
        oraa T11
        adca T1
        staa T1
        ldaa sh_v+4
        oraa sh_v+8
        anda sh_v+12
        staa T11
        ldaa sh_v+4
        anda sh_v+8
        oraa T11
        adca T0
        staa T0
.fs:
        ldx  #sh_v+16           ; T += e
        bsr  sh_addx
        ldx  #sh_k              ; T += K
        ldab T10
        abx
        bsr  sh_addx
        ldaa sh_v               ; rol5(a) into T4-T7 with MUL: a byte times 32 is its top
        ldab #32                ; three bits (A) and the rest moved up five (B); byte k of
        mul                     ; the result is B of a[k] or A of a[k+1] (round)
        stab T4
        staa T7
        ldaa sh_v+1
        ldab #32
        mul
        oraa T4
        staa T4
        stab T5
        ldaa sh_v+2
        ldab #32
        mul
        oraa T5
        staa T5
        stab T6
        ldaa sh_v+3
        ldab #32
        mul
        oraa T6
        staa T6
        orab T7
        stab T7
        bsr  sh_add4            ; T += rol5(a)
        ldd  sh_v+12            ; e = d
        std  sh_v+16
        ldd  sh_v+14
        std  sh_v+18
        ldd  sh_v+8             ; d = c
        std  sh_v+12
        ldd  sh_v+10
        std  sh_v+14
        ldaa sh_v+7             ; c = rol30(b) = b rotated right twice, with MUL by 64:
        ldab #64                ; byte k is A of b[k] or B of b[k-1] (round)
        mul
        staa sh_v+11
        stab sh_v+8
        ldaa sh_v+4
        ldab #64
        mul
        oraa sh_v+8
        staa sh_v+8
        stab T4
        ldaa sh_v+5
        ldab #64
        mul
        oraa T4
        staa sh_v+9
        stab T4
        ldaa sh_v+6
        ldab #64
        mul
        oraa T4
        staa sh_v+10
        orab sh_v+11
        stab sh_v+11
        ldd  sh_v               ; b = a
        std  sh_v+4
        ldd  sh_v+2
        std  sh_v+6
        ldd  T0                 ; a = T
        std  sh_v
        ldd  T2
        std  sh_v+2
        inc  T9
        ldaa T9
        cmpa #80
        beq  .end
        jmp  .rnd
.end:   ldx  #sh_h              ; h += a..e
        ldab #5
.add:   pshb
        ldd  0,x
        std  T0
        ldd  2,x
        std  T2
        pshx
        ldab #20
        abx
        bsr  sh_addx
        pulx
        ldd  T0
        std  0,x
        ldd  T2
        std  2,x
        inx
        inx
        inx
        inx
        pulb
        decb
        bne  .add
        rts

; T ^= the word at sh_w + (B & 63)
sh_wx:  andb #63
        ldx  #sh_w
        abx
        ldd  0,x
        eora T0
        eorb T1
        std  T0
        ldd  2,x
        eora T2
        eorb T3
        std  T2
        rts

; T += T4-T7
sh_add4:
        ldx  #T4
; T += the word at X
sh_addx:
        ldd  T2
        addd 2,x
        std  T2
        ldd  T0
        adcb 1,x
        adca 0,x
        std  T0
        rts

sh_k:   fdb  $5A82,$7999,$6ED9,$EBA1,$8F1B,$BCDC,$CA62,$C1D6
sh_iv:  fdb  $6745,$2301,$EFCD,$AB89,$98BA,$DCFE,$1032,$5476,$C3D2,$E1F0

; sh_h = the starting values
sha_init:
        ldx  #sh_iv
; sh_h = the 20 bytes at X
sha_set:
        ldd  #sh_h
        bra  cpy20
