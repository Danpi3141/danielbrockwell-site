// Probe harness: boots a model, runs the probe kernel (build/probe) and calls OS services.
'use strict';
const fs = require('fs');
const path = require('path');
const { Machine } = require('../../tools/emu');
const ROOT = path.join(__dirname, '..', '..');
const MODELS = {
  cm: { rom: '33-cm.rom', ram: 8 }, cm24: { rom: '24-cm.rom', ram: 8 }, xp: { rom: '31-xp.rom', ram: 16 },
  la: { rom: '36-la.rom', ram: 32 }, lz: { rom: '46-lz.rom', ram: 32 }, lz64: { rom: '46a-lz64.rom', ram: 64 },
};
const SVC = { 'MN$DISP': 0x50, 'ED$EPOS': 0x1D, 'ED$EDIT': 0x1C, 'FL$OPEN': 0x2F, 'FL$CRET': 0x28, 'FL$DELN': 0x29,
  'FL$FIND': 0x2C, 'FL$READ': 0x31, 'FL$WRIT': 0x37, 'FL$ERAS': 0x2A, 'FL$SETP': 0x35, 'FL$RECT': 0x32,
  'FL$RSET': 0x34, 'FL$NEXT': 0x2E, 'FL$SIZE': 0x36, 'FL$FREC': 0x2D, 'BT$SWOF': 0x0C, 'TM$TGET': 0x6A,
  'TM$TSET': 0xB3, 'TM$DAYV': 0x69, 'DP$MSET': 0x82, 'DP$PRNT': 0x11, 'DP$EMIT': 0x10, 'DP$STAT': 0x14,
  'KB$GETK': 0x48, 'KB$TEST': 0x4B, 'UT$YSNO': 0x7D, 'FL$BOPN': 0x24, 'TM$NDYS': 0x95 };

class Probe {
  constructor(model, opts = {}) {
    const mm = MODELS[model] || { rom: model, ram: opts.ram };
    this.m = new Machine({ rom: mm.rom, ram: mm.ram });
    const b = path.join(ROOT, 'build', 'probe');
    this.sym = JSON.parse(fs.readFileSync(path.join(b, 'kernel.sym.json'), 'utf8'));
    this.m.boot();
    this.m.insertPack(path.join(b, 'TFA.opk'), 0);
    if (opts.packC) this.m.emptyPack(opts.packC.type, opts.packC.size, 1);
    this.m.runProc('TFA', 'B');
    for (let i = 0; i < 100; i++) {
      this.m.runSeconds(0.1);
      const a = this.m.find([0x54, 0x46, 0x41, 0x31], 0x2000, 0xFFF0);
      if (a >= 0) { this.base = a - 3; break; }
    }
    if (this.base === undefined) throw new Error('probe did not start\n' + this.m.screenText());
    if (this.m.runTo([this.a('p_idle')], 921600 * 5) < 0) throw new Error('no idle');
  }
  a(n) { const s = this.sym[n]; if (!s) throw new Error('no sym ' + n); return s[1] === 'abs' ? s[0] : this.base + s[0]; }
  buf() { return this.a('pr_buf'); }
  // call service svc with regs {a,b,x,d,s0}; keys: function run while the call is waiting
  call(svc, r = {}, keys) {
    const m = this.m, d = m.dbg;
    if (r.d !== undefined) { r.a = r.d >> 8; r.b = r.d & 255; }
    m.poke(this.a('pr_a'), r.a || 0); m.poke(this.a('pr_b'), r.b || 0);
    m.pokew(this.a('pr_x'), r.x || 0); m.pokew(this.a('pr_s0'), r.s0 || 0);
    m.poke(this.a('p_svc'), typeof svc === 'string' ? SVC[svc] : svc);
    d.setPC(this.a('p_call'));
    const done = this.a('p_done');
    const at = () => { const pc = d.pc(); return pc >= done && pc <= done + 2; };
    if (keys) keys(this);
    for (let i = 0; i < 200 && !at(); i++) m.runSeconds(0.1);
    if (!at()) throw new Error('call did not finish (pc ' + d.pc().toString(16) + ')\n' + m.screenText());
    const cc = m.peek(this.a('pr_cc'));
    const out = { a: m.peek(this.a('pr_a')), b: m.peek(this.a('pr_b')), x: m.peekw(this.a('pr_x')), s0: m.peekw(this.a('pr_s0')), c: cc & 1 };
    d.setPC(this.a('p_idle'));
    return out;
  }
  lbc(addr, s) { const b = Buffer.from(s, 'latin1'); this.m.poke(addr, b.length); this.m.write(addr + 1, [...b]); return addr + 1 + b.length; }
  str(addr) { const n = this.m.peek(addr); return Buffer.from(this.m.read(addr + 1, n)).toString('latin1'); }
  scr() { return this.m.screenText(); }
}
module.exports = { Probe, SVC, MODELS };
