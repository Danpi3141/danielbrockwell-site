'use strict';
// Probe 5: BT$SWOF returns after ON; btb_nmfl ($5B) clears each second; TM$TGET; TM$DAYV.
const { Probe } = require('./plib');
for (const model of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'xp', 'la', 'lz64']) {
  const p = new Probe(model);
  const m = p.m;
  const buf = p.buf();
  let r = p.call('BT$SWOF', {}, () => {
    m.runSeconds(1);
    console.log(model, 'after BT$SWOF: on?', m.isOn(), 'pc', m.dbg.pc().toString(16));
    m.runSeconds(3);
    m.press('ON', 3, 10);
    m.runSeconds(0.5);
    console.log(model, 'after ON: on?', m.isOn(), 'screen\n' + p.scr());
  });
  console.log(model, 'BT$SWOF returned', r);
  // the NMI flag
  m.poke(0x5B, 1);
  let t = 0;
  for (; t < 30 && m.peek(0x5B); t++) m.runSeconds(0.05);
  console.log(model, '$5B cleared after', t * 50, 'ms; secs', m.peek(0x20CA));
  r = p.call('TM$TGET', { x: buf });
  console.log(model, 'TM$TGET', m.read(buf, 6).join(','));
  m.write(buf, [42, 10, 19]);
  r = p.call('TM$DAYV', { x: buf });
  console.log(model, 'TM$DAYV 42/10/19 -> B', r.b, 'name', JSON.stringify(Buffer.from(m.read(r.x, 3)).toString('latin1')));
  m.write(buf, [126, 10, 19]);
  r = p.call('TM$DAYV', { x: buf });
  console.log(model, 'TM$DAYV 126/10/19 -> B', r.b, 'name', JSON.stringify(Buffer.from(m.read(r.x, 3)).toString('latin1')));
  // write the clock directly right after a tick, then read it back a little later
  m.poke(0x5B, 1);
  for (t = 0; t < 30 && m.peek(0x5B); t++) m.runSeconds(0.01);
  m.write(0x20C5, [42, 10, 19, 14, 32, 5]);
  m.runSeconds(2.0);
  console.log(model, 'clock 2 s after write 14:32:05 ->', m.read(0x20C5, 6).join(','));
}
