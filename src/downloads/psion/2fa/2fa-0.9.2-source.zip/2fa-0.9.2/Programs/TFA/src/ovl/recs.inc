; writing records: the record made from its fields, an account erased, a key encoded

; kf_del: account D erased
kf_del: std  kv_tmp
        bsr  kf_open
        bcs  fl_err
        ldd  kv_tmp
        os   FL$RSET
        os   FL$ERAS
        bcs  fl_err
        os   FL$SIZE
        stx  kf_n
        clc
        rts

; ac_make: kv_rec = ac_name TAB ac_kind TAB the key text in kt
ac_make:
        ldx  #kv_rec
        stx  kv_dst
        clr  kv_rec
        ldx  #ac_name
        bsr  .cat
        bsr  .tab
        ldx  #ac_kind
        bsr  .cat
        bsr  .tab
        ldx  #kt_len
.cat:   ldab 0,x                ; append the lbc at X
        beq  .x
        inx
.c:     ldaa 0,x
        inx
        bsr  .put
        decb
        bne  .c
.x:     rts
.tab:   ldaa #9
.put:   pshx
        pshb
        ldx  #kv_rec
        inc  0,x
        ldab 0,x
        abx
        staa 0,x
        pulb
        pulx
        rts


; b32enc: kb_key (kb_len bytes) -> kt as base-32 text (the last
; character's spare bits zero), as the key is stored when scrambled
b32enc: clr  kt_len
        ldx  #kb_key
        stx  kv_src
        ldab kb_len
        stab kv_cnt
        clr  T0                 ; the bits so far (T0-T1) and how many (T2)
        clr  T2
.b:     tst  kv_cnt
        beq  .end
        ldaa T1                 ; eight more
        staa T0
        ldx  kv_src
        ldab 0,x
        inx
        stx  kv_src
        stab T1
        dec  kv_cnt
        ldab T2
        addb #8
        stab T2
.o:     ldab T2                 ; out five at a time
        cmpb #5
        blo  .b
        subb #5
        stab T2
        stab T3
        ldd  T0
.r:     tst  T3
        beq  .p
        lsrd
        dec  T3
        bra  .r
.p:     bsr  .put
        bra  .o
.end:   ldab T2                 ; the bits left, shifted up to five
        beq  .x
        ldaa #5
        sba
        staa T3
        ldab T1
.l:     aslb
        dec  T3
        bne  .l
.put:   andb #31
        addb #'A'
        cmpb #'Z'
        bls  .s
        subb #'Z'+1-'2'
.s:     ldx  #kt_len
        inc  0,x
        ldaa 0,x
        pshb
        tab
        abx
        pulb
        stab 0,x
.x:     rts


; ac_keykt: kt = the record's key text as it is (kv_kp, kv_kl)
ac_keykt:
        ldd  #kt_txt
        std  kv_to
        ldab kv_kl
        stab kt_len
        ldx  kv_kp
        bra  copy
