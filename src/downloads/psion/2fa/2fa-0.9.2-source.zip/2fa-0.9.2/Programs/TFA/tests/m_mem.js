// The memory margin on the smallest machines: PAD (an array) then TFA, at sizes found by binary
// search. TFA must refuse cleanly ("NEEDS") when short, never fail; reports the largest padding at
// which TFA starts and adds an account (the spare RAM on a blank machine).
//   node tests/m_mem.js [model] [--nocheck]   (--nocheck: TFAG straight, the program's true limit)
'use strict';
const { execFileSync } = require('child_process');
const path = require('path'), fs = require('fs');
const { UI } = require('./ui');
const model = process.argv[2] || 'cm';
const nocheck = process.argv.includes('--nocheck');
const tmp = path.join(__dirname, '..', 'build', 'mem');
fs.mkdirSync(tmp, { recursive: true });
function trial(words) {
  const opk = path.join(tmp, `pad${words}.opk`);
  execFileSync('python', [path.join(__dirname, '..', 'tools', 'padpack.py'), String(words), opk].concat(nocheck ? ['--nocheck'] : []));
  const g = new UI(model, { pack: opk, clock: [42, 10, 19, 14, 31, 40] });
  g.m.runProc('PAD', 'B');
  for (let i = 0; i < 100; i++) {
    g.run(0.2);
    const t = g.text();
    if (/NEEDS/.test(t)) return { r: 'needs', t };
    if (/MEMORY|ERROR|ERR /i.test(t)) return { r: 'error', t };
    if (g.sync() >= 0) {
      try {
        g.toIdle(); g.confirmDate();
        g.key('MODE', 0.8); g.key('H', 0.8); g.key('T', 3);      // (no accounts: MODE is the Tools menu)
        if (!/Self-test OK/.test(g.text())) return { r: 'error', t: g.text() };
        g.key('EXE', 1.5);
        // adding to A: either works, or is refused with the system's message (TFA keeps room to start again)
        g.key('EXE', 0.6); g.type('GitHub').key('EXE', 0.6); g.type('JBSWY3DPEHPK3PXP').key('EXE', 1.5);
        g.key('Y', 1.5);
        const t = g.text();
        if (/OUT OF MEMORY/.test(t)) { g.key('SPACE', 1); return { r: 'ok', t: '(adding to A: refused: OUT OF MEMORY)' }; }
        if (!g.shown()) return { r: 'error', t };
        return { r: 'ok' };
      } catch (e) { return { r: 'error', t: e.message.split('\n').slice(0, 3).join(' ') }; }
    }
  }
  return { r: 'timeout', t: g.text() };
}
let lo = 0, hi = 1200;
while (hi - lo > 1) {
  const mid = (lo + hi) >> 1;
  const r = trial(mid);
  console.log(`pad ${2 * mid} bytes: ${r.r}${r.t ? ' ' + r.t.replace(/\n/g, '|') : ''}`);
  if (!nocheck && (r.r === 'error' || r.r === 'timeout')) { console.log('FAIL: not refused cleanly'); process.exit(1); }
  if (r.r === 'ok') lo = mid; else hi = mid;
}
console.log(`${model}: ${nocheck ? 'the program works' : 'TFA starts and works'} with up to about ${2 * lo} bytes of padding${nocheck ? '' : ' (TFA refuses beyond)'}`);
