; =====================================================================
; Psion 2FA - shared definitions (system variables from the technical
; manual: the same on the CM, XP, LA and LZ; docs/os_notes.md)
; =====================================================================

; ---- zero-page scratch (UTW_S0..S5): clobbered by most OS calls
T0      = $41
T1      = $42
T2      = $43
T3      = $44
T4      = $45
T5      = $46
T6      = $47
T7      = $48
T8      = $49
T9      = $4A
T10     = $4B
T11     = $4C

; ---- system variables and hardware
BTB_NMFL = $5B                  ; cleared by the once-a-second NMI
DPB_CPOS = $62
KBB_WAIT = $76
KBB_DLAY = $77
KBB_REPT = $78
KBB_STAT = $7B
TMB_SWOF = $7C
TMW_TOUT = $7D                  ; seconds left to auto switch-off
FLB_RECT = $96
FLB_CPAK = $97
FLW_CREC = $9B
TMB_YEAR = $20C5                ; the clock: year, month (0-11), day (0-30), hour, minute, second
TMW_FRAM = $20CB                ; +1 every 50 ms
TMW_TCNT = $20CD                ; auto switch-off time in seconds
TMB_24F  = $20A6                ; LZ: bit 7 daylight saving
DPB_MODE = $2184                ; LZ: 0 two lines, 1 four
RTB_BL   = $2187                ; the run-time buffer: length, then text
RTT_BF   = $2188
ALA_FREE = $2040                ; the first byte above the allocated cells
RTA_SP   = $00A5                ; the language stack (free RAM lies between)
FRC      = $0009                ; free-running counter
MODEL    = $FFE8                ; bit 3 set: four-line (LZ, LZ64)

; ---- key codes
K_ON    = 1
K_MODE  = 2
K_UP    = 3
K_DOWN  = 4
K_LEFT  = 5
K_RIGHT = 6
K_DEL   = 8
K_EXE   = 13
K_SPACE = 32

; ---- error codes returned to the launcher in X
E_OK     = 0
E_NOPACK = 1                    ; TFAC not found
E_RUN    = 3                    ; TFAG not run by TFA or CLOCK
