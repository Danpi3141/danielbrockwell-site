'use strict';
// Milestones 1-3: SHA-1 on one block, HMAC and the cut, base 32 - the 6303 against ref/totp.js
const { TFA } = require('./lib');
const R = require('../ref/totp');

let fails = 0;
const ok = (c, msg) => { if (!c) { fails++; console.log('FAIL', msg); } else console.log('ok  ', msg); };
const hex = (a) => Buffer.from(a).toString('hex');

for (const model of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'lz64']) {
  const g = new TFA(model).start();
  console.log('==', model, 'kernel at', g.base.toString(16));
  // SHA-1 of one padded block
  const block = (msg) => { const b = Buffer.alloc(64); Buffer.from(msg).copy(b); b[msg.length] = 0x80; b.writeUInt16BE(msg.length * 8, 62); return b; };
  for (const msg of ['abc', '']) {
    g.call('sha_init');
    g.write('sh_w', [...block(msg)]);
    const cyc = g.timed('sha_blk');
    ok(hex(g.read('sh_h', 20)) === R.sha1(msg).toString('hex'), `sha1(${JSON.stringify(msg)}) = ${hex(g.read('sh_h', 20))}  ${cyc} cycles = ${(cyc / 921.6).toFixed(1)} ms`);
  }
  // base 32
  const dec = (text) => { g.write('t_buf', [...Buffer.from(text)]); g.m.dbg.setB(text.length); const x = g.addr('t_buf'); g.m.dbg.setX(x); return text; };
  const b32 = (text) => {
    g.write('t_buf', [...Buffer.from(text)]);
    // b32dec takes X and B: go through a tiny trampoline via t_call (X = routine) - so set regs by poking kv_src/kv_cnt path:
    g.pokew('kv_src', g.addr('t_buf'));
    return text;
  };
  void dec; void b32;
  const decode = (text) => {
    g.write('t_buf', [...Buffer.from(text)]);
    g.callDirect('b32dec', { x: g.addr('t_buf'), b: text.length });
    return Buffer.from(g.read('kb_key', g.peek('kb_len')));
  };
  for (const [t, want] of [['JBSWY3DPEHPK3PXP', '48656c6c6f21deadbeef'], ['GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ', Buffer.from('12345678901234567890').toString('hex')],
    ['JBSWY3DPEHPK3PXPJBSWY3DPEHPK3PXPJBSWY3DPEHPK3PXPJBSWY3DPEHPK3PXP', R.b32decode('JBSWY3DPEHPK3PXP'.repeat(4)).toString('hex')],
    ['MZXW6YTBOI', R.b32decode('MZXW6YTBOI').toString('hex')], ['ABCDEFGHIJKLMNOPQRSTUVWXYZ234567', R.b32decode('ABCDEFGHIJKLMNOPQRSTUVWXYZ234567').toString('hex')]]) {
    ok(decode(t).toString('hex') === want, `b32 ${t} -> ${decode(t).toString('hex')}`);
  }
  // HOTP codes from a counter, and TOTP times
  const codeAt = (keyText, step) => {
    decode(keyText);
    g.pokew('kv_dst', g.addr('t_buf') + 60);
    const c1 = g.callDirect('hm_prep', { x: g.addr('t_slot') });
    g.write('kv_step', [step >>> 24 & 255, step >>> 16 & 255, step >>> 8 & 255, step & 255]);
    const c2 = g.callDirect('hm_code', { x: g.addr('t_slot') });
    return { code: Buffer.from(g.read('t_buf', 6, 60)).toString(), prep: c1, code2: c2 };
  };
  const rfc = 'GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ';
  const hc = ['755224', '287082', '359152', '969429', '338314', '254676', '287922', '162583', '399871', '520489'];
  let timing;
  hc.forEach((c, i) => { const r = codeAt(rfc, i); timing = r; ok(r.code === c, `hotp ${i} ${r.code}`); });
  console.log(`   prep (2 blocks) ${timing.prep} cycles = ${(timing.prep / 921.6).toFixed(0)} ms, code (2 blocks + cut) ${timing.code2} = ${(timing.code2 / 921.6).toFixed(0)} ms`);
  for (const [t, c] of [[59, '287082'], [1111111109, '081804'], [1111111111, '050471'], [1234567890, '005924'], [2000000000, '279037']]) {
    const r = codeAt(rfc, Math.floor(t / 30));
    ok(r.code === c, `totp ${t} ${r.code}`);
  }
  for (const s of [59839504, 59839505]) {
    const r = codeAt('JBSWY3DPEHPK3PXP', s);
    ok(r.code === R.code(R.b32decode('JBSWY3DPEHPK3PXP'), s), `JBSW step ${s} ${r.code}`);
  }
  // random keys and steps against the reference
  let bad = 0;
  for (let i = 0; i < 40; i++) {
    const len = 10 + (i * 7) % 31;
    const key = Buffer.from(Array.from({ length: len }, (_, j) => (i * 37 + j * 101 + 13) & 255));
    const txt = R.b32encode(key);
    const step = (i * 2654435761) >>> 1;
    const r = codeAt(txt, step);
    if (r.code !== R.code(key, step)) { bad++; console.log('  mismatch', txt, step, r.code, R.code(key, step)); }
  }
  ok(bad === 0, '40 random keys (10-40 bytes) and steps');
}
if (fails) { console.log(fails, 'FAILED'); process.exit(1); }
console.log('all ok');
