// The test keys and their codes (the reference table): node tools/testkeys.js [--now] [--md out.md]
//   --now      also the codes for the PC's clock now (to compare with the Psion or a phone)
//   --md file  write the table as Markdown (docs/test_keys.md)
'use strict';
const fs = require('fs');
const R = require('../ref/totp');

const KEYS = [
  ['GitHub', 'JBSW Y3DP EHPK 3PXP', 'the spec\'s sample key ("Hello!" and DEADBEEF), 16 characters'],
  ['RFC', 'GEZD GNBV GY3T QOJQ GEZD GNBV GY3T QOJQ', 'RFC 4226 / 6238 test key: the ASCII "12345678901234567890", 32 characters'],
  ['Amazon', 'MFRG GZDF MZTW Q2LK', '10 bytes, 16 characters (used in the tests)'],
  ['Google', 'JBSW Y3DP EHPK 3PXP JBSW Y3DP EH', '16 bytes, 26 characters: the length many sites give (2 bits left over)'],
  ['Long', 'JBSW Y3DP EHPK 3PXP JBSW Y3DP EHPK 3PXP JBSW Y3DP EHPK 3PXP JBSW Y3DP EHPK 3PXP', '40 bytes, 64 characters: the longest the program takes'],
  ['Letters', 'ABCD EFGH IJKL MNOP QRST UVWX YZ23 4567', 'every character of the alphabet once, 32 characters'],
  ['Psion', R.b32encode(Buffer.from('Psion Organiser!')).replace(/(.{4})/g, '$1 ').trim(), 'the bytes of "Psion Organiser!" (16), 26 characters'],
];

// [label, Date (UTC)]
const TIMES = [
  ['spec sample', new Date(Date.UTC(2026, 10, 20, 14, 32, 7))],
  ['RFC 59 s', new Date(59 * 1000)],
  ['RFC 1111111109', new Date(1111111109 * 1000)],
  ['RFC 1111111111', new Date(1111111111 * 1000)],
  ['RFC 1234567890', new Date(1234567890 * 1000)],
  ['RFC 2000000000', new Date(2000000000 * 1000)],
  ['2027 new year', new Date(Date.UTC(2027, 0, 1, 0, 0, 0))],
  ['leap day 2028', new Date(Date.UTC(2028, 1, 29, 12, 0, 0))],
  ['past 2038 (32-bit seconds)', new Date(Date.UTC(2038, 0, 19, 3, 14, 8))],
  ['2054 (past 2053)', new Date(Date.UTC(2054, 0, 1, 0, 0, 0))],
  ['last of 2083', new Date(Date.UTC(2083, 11, 31, 23, 59, 59))],
  ['2084 (112 behind)', new Date(Date.UTC(2084, 0, 1, 0, 0, 0))],
];

const fmt = (c) => c.slice(0, 3) + ' ' + c.slice(3);
const two = (d) => {     // what a two-line Organiser's clock holds (84 behind to 2083, 112 behind from 2084)
  const y = d.getUTCFullYear(), s = y <= 2083 ? y - 84 : y - 112;
  return s >= 1901 && s <= 1999 ? String(s) : '-';
};
const pad = (d) => d.toISOString().replace('T', ' ').replace('.000Z', '');

const lines = [];
lines.push('# Test keys for Psion 2FA');
lines.push('');
lines.push('Made by `node tools/testkeys.js --md docs/test_keys.md` from `ref/totp.js` (Node\'s own HMAC-SHA-1; its RFC values are checked by `node ref/totp.js`). Type a key on the Psion (Tools > Add) and on a phone app; set the clock (two-line Organisers: Setup > Clock, or CLOCK) to a time below and compare.');
lines.push('');
lines.push('Codes are six digits on a 30-second step (the standard). "Next" is the code for the step after.');
lines.push('');
lines.push('## The keys');
lines.push('');
lines.push('| Name | Key (typed in groups of four) | Bytes (hex) | Notes |');
lines.push('|---|---|---|---|');
for (const [n, k, note] of KEYS) lines.push(`| ${n} | \`${k}\` | \`${R.b32decode(k).toString('hex')}\` | ${note} |`);
lines.push('');
lines.push('## Codes at fixed times (zone +0:00, UTC)');
lines.push('');
lines.push('| Time (UTC) | Two-line clock year | Step | ' + KEYS.map((k) => k[0]).join(' | ') + ' |');
lines.push('|---|---|---|' + KEYS.map(() => '---|').join(''));
for (const [label, d] of TIMES) {
  const st = R.stepOf(d);
  const cs = KEYS.map(([, k]) => { const kb = R.b32decode(k); return fmt(R.code(kb, st)) + ' / ' + fmt(R.code(kb, st + 1)); });
  lines.push(`| ${pad(d)} (${label}) | ${two(d)} | ${st} | ${cs.join(' | ')} |`);
}
lines.push('');
lines.push('Each cell is the code now / the next code. The RFC rows agree with RFC 6238\'s table (its eight-digit codes end in these six digits) for the RFC key.');
lines.push('');
lines.push('## Codes against a counter (RFC 4226, the RFC key)');
lines.push('');
lines.push('| Step | ' + [0, 1, 2, 3, 4, 5, 6, 7, 8, 9].join(' | ') + ' |');
lines.push('|---|' + '---|'.repeat(10));
lines.push('| Code | ' + [0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => R.code(R.b32decode(KEYS[1][1]), i)).join(' | ') + ' |');
lines.push('');
lines.push('## The self-test (Tools > Help > Test)');
lines.push('');
lines.push('SHA-1 of "abc" = `' + R.sha1('abc').toString('hex') + '`; the RFC key at step 0 = ' + R.code(R.b32decode(KEYS[1][1]), 0) + ', at step 37,037,036 = ' + R.code(R.b32decode(KEYS[1][1]), 37037036) + '.');
lines.push('');

if (process.argv.includes('--now')) {
  const d = new Date(), st = R.stepOf(d), left = 30 - (Math.floor(d.getTime() / 1000) % 30);
  console.log(`Now ${pad(d)} UTC, step ${st}, ${left} s left`);
  for (const [n, k] of KEYS) { const kb = R.b32decode(k); console.log(`  ${n.padEnd(8)} ${fmt(R.code(kb, st))}  next ${fmt(R.code(kb, st + 1))}`); }
}
const mi = process.argv.indexOf('--md');
if (mi > 0) { fs.writeFileSync(process.argv[mi + 1], lines.join('\n')); console.log('wrote', process.argv[mi + 1]); } else if (!process.argv.includes('--now')) console.log(lines.join('\n'));
