; Probe kernel: a generic OS caller driven by tests/probe/*.js through the emulator.
; The harness stops at p_idle, pokes registers and a service number, sets PC to p_call,
; and runs to p_done; results are read from pr_* (A, B, X, S0, carry).
        include "defs.inc"
entry:  jmp  start
        fcc  "TFA1"
start:  std  pv_v
        sts  pv_sp
p_idle: nop
        bra  p_idle
p_call: ldx  pr_s0
        stx  T0
        ldaa pr_a
        ldab pr_b
        ldx  pr_x
        swi
p_svc:  fcb  0
        staa pr_a
        stab pr_b
        stx  pr_x
        ldx  T0
        stx  pr_s0
        tpa
        staa pr_cc
p_done: nop
        bra  p_done
p_quit: lds  pv_sp
        ldx  #0
        rts
kv_first:
pv_v:   rmb  2
pv_sp:  rmb  2
pr_a:   rmb  1
pr_b:   rmb  1
pr_x:   rmb  2
pr_s0:  rmb  2
pr_cc:  rmb  1
pr_buf: rmb  700
kv_end:
