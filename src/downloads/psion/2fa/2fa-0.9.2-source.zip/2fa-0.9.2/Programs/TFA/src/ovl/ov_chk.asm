; =====================================================================
; OV_CHK: the first code shown, kept in time, for checking against a phone
; =====================================================================
        include "ovhead.inc"
        jmp  chk_key


; ---- the check against a phone --------------------------------------------
; chk_key: the code for the key typed, shown with the seconds left, kept in
; time; carry clear for Y, set for N (and ON/CLEAR)
chk_key:
        ldx  #kt_txt
        ldab kt_len
        bsr  b32dec
        clra
        bsr  sl_x               ; slot 0 holds it (the code screen makes its own afresh)
        stx  kv_sl
        ldaa #1
        staa SL_OK,x
        ldab #SL_HALF
        abx
        bsr  hm_prep
        bsr  cls
        ldx  #0
        stx  kv_cs
        stx  kv_cs+2
.loop:  bsr  ck_read
        bcs  .no
        ldd  kv_step+2          ; a new step: the codes afresh
        subd kv_cs+2
        bne  .new
        ldd  kv_step
        subd kv_cs
        beq  .same
.new:   bsr  cs_take
        ldaa #1
        bsr  sl_codesn
        bsr  chk_draw
.same:  ldaa ck_left
        cmpa kv_left
        beq  .k
        bsr  chk_secs
.k:     bsr  pollk
        tstb
        beq  .loop
        cmpb #'Y'
        beq  .yes
        cmpb #'N'
        beq  .no
        cmpb #K_ON
        beq  .no
        bsr  beep
        bra  .loop
.yes:   clc
        rts
.no:    sec
        rts

chk_draw:
        bsr  cls
        tst  kv_four
        beq  .two
        ldx  #kv_nname          ; four lines: the name, Now, Next, the question
        bsr  prs
        ldaa #1
        clrb
        bsr  at
        bsr  pri
        fcl  "Now:  "
        ldx  #kv_slot0+SL_NOW
        bsr  prcode
        ldaa #2
        clrb
        bsr  at
        bsr  pri
        fcl  "Next: "
        ldx  #kv_slot0+SL_NEXT
        bsr  prcode
        ldaa #3
        clrb
        bsr  at
        bsr  pri
        fcl  "Same as phone? Y/N"
        bra  chk_secs
.two:   bsr  pri                ; two lines: "Now: 787 941 23s" / "Same as phone? Y"
        fcl  "Now: "
        ldx  #kv_slot0+SL_NOW
        bsr  prcode
        ldaa #1
        clrb
        bsr  at
        bsr  pri
        fcl  "Same as phone? Y"
; the seconds left: at the end of line 0 (two lines) or line 1 (four)
chk_secs:
        ldaa ck_left
        staa kv_left
        clra
        ldab #13
        tst  kv_four
        beq  .p
        ldd  #$0111
.p:     bsr  at
        bsr  secs2
        ldaa #'s'
        bra  emit

