; the date and time printed from the edit fields (OV_DATE, OV_CLK)

; ck_tod: the edit fields from the clock read (ck_t, ck_year)
ck_tod: ldd  ck_year
        std  ed_year
        ldx  #ck_t+1
        ldd  #ed_mon
        std  kv_to
        ldab #5
        bra  copy

; ---- printing the date and time (from ed_year, ed_mon .. ed_sec) ----------
; "FRI 20 Nov 2026": the day name from the OS (its language), English months
pr_date:
        bsr  ed_store           ; the stored form, for the OS's day name
        ldx  #kv_tset
        os   TM$DAYV
        ldaa 1,x                ; capital month names if the day name is in capitals
        anda #$20
        staa T5
        ldab #3
        os   DP$PRNT
        ldaa #' '
        bsr  emit
        ldaa ed_day
        inca
        bsr  pr2s
        ldaa #' '
        bsr  emit
        ldab ed_mon
        ldaa #3
        mul
        ldx  #months
        abx
        ldab #3
.m:     ldaa 0,x
        tst  T5                 ; (T5 = 0: the day name is in capitals: so is the month)
        bne  .c
        anda #$DF
.c:     bsr  emit
        inx
        decb
        bne  .m
        ldaa #' '
        bsr  emit
        ldd  ed_year
        bra  prnum
; "14:32:07"
pr_time:
        ldaa ed_hour
        bsr  pr2
        ldaa #':'
        bsr  emit
        ldaa ed_min
        bsr  pr2
        ldaa #':'
        bsr  emit
        ldaa ed_sec
        bra  pr2

months: fcc  "JanFebMarAprMayJunJulAugSepOctNovDec"

; ed_store: kv_tset = the six bytes the clock should hold for the edit fields:
; the year 84 behind to 2083, 112 behind from 2084 (two lines); as it is (four)
ed_store:
        ldd  ed_year
        tst  kv_four
        bne  .s
        subd #2084
        bcc  .late
        addd #2084-84           ; to 2083: 84 behind
        bra  .s
.late:  addd #2084-112          ; from 2084: 112 behind
.s:     subd #1900
        stab kv_tset
        ldx  #ed_mon
        ldd  #kv_tset+1
        std  kv_to
        ldab #5
        bra  copy


; B = the days in month ed_mon of ed_year
mdays:  ldx  #md_tab
        ldab ed_mon
        abx
        ldab 0,x
        cmpb #28
        bne  .x
        ldaa ed_year+1          ; February: 29 in a leap year (1985-2099: every fourth)
        anda #3
        bne  .x
        incb
.x:     rts
md_tab: fcb  31,28,31,30,31,30,31,31,30,31,30,31
