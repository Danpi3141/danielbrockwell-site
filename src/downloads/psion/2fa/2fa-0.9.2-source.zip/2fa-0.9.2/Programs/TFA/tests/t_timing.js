'use strict';
// The spec's "Timing to measure": one SHA-1 block, the first code for an account, later codes,
// start to the first code; plus the changeover (the new code on screen) and three accounts cold.
const { UI } = require('./ui');
const MS = (c) => (c / 921.6).toFixed(0) + ' ms';
const out = [];
for (const model of ['cm', 'lz64']) {
  const four = /lz/.test(model);
  const g = new UI(model, { clock: four ? [126, 10, 19, 14, 31, 40] : [42, 10, 19, 14, 31, 40] });
  g.start().confirmDate().add('GitHub', 'JBSW Y3DP EHPK 3PXP').add('Google', 'GEZD GNBV GY3T QOJQ GEZD GNBV GY3T QOJQ').add('Amazon', 'MFRG GZDF MZTW Q2LK');
  // one block, a key's half-results (2 blocks), a code (2 blocks and the cut)
  g.call('sha_init');
  const blk = g.timed('sha_blk');
  g.write('t_buf', [...Buffer.from('JBSWY3DPEHPK3PXP')]);
  g.callDirect('b32dec', { x: g.addr('t_buf'), b: 16 });
  const prep = g.callDirect('hm_prep', { x: g.addr('t_slot') });
  g.pokew('kv_dst', g.addr('t_buf') + 40);
  const code = g.callDirect('hm_code', { x: g.addr('t_slot') });
  // start to the first code: leave, run TFA again, time until the code screen shows codes
  g.key('ON', 1);
  const c0 = g.m.cycles();
  g.m.runProc('TFA', 'B');
  const c1 = g.m.cycles();
  let t = 0;
  while (t < 200 && !(g.shown() && (four ? g.shown().rows.length >= 1 && !/Working/.test(g.text()) : true))) { g.run(0.02); t++; }
  const start = g.m.cycles() - c1;
  // the changeover: from the clock's tick into a new half-minute to the new code on screen
  g.run(0.5);
  const nowCode = () => { const s = g.shown(); return s && (four ? s.rows[0] && s.rows[0].code : s[0].now); };
  g.run(Math.max(0, g.peek('ck_left') - 1.5));
  let tick = -1, ch = -1, prevSec = g.clock()[5], codeBefore = nowCode();
  for (let i = 0; i < 8000 && ch < 0; i++) {
    g.m.run(461);                                    // 0.5 ms steps
    const sec = g.clock()[5];
    if (tick < 0 && sec !== prevSec && sec % 30 === 0) tick = g.m.cycles();
    if (tick < 0) codeBefore = nowCode();
    else if (nowCode() !== codeBefore) ch = g.m.cycles() - tick;
    prevSec = sec;
  }
  // the "Working..." time on four lines: DOWN moves the three (all three cold)
  let cold = 0;
  if (four) {
    g.run(1);
    const k0 = g.m.cycles();
    g.press('DOWN', 1, 1);
    while (!/Working/.test(g.text()) && g.m.cycles() - k0 < 921600) g.m.run(921);
    while (/Working/.test(g.text()) && g.m.cycles() - k0 < 921600 * 5) g.m.run(921);
    cold = g.m.cycles() - k0;
  }
  out.push([model, MS(blk), MS(prep + code), MS(code), MS(start), ch >= 0 ? MS(ch) : '?', four ? MS(cold) : '-']);
}
console.log('model | one SHA-1 block | first code (key + code) | later code | start to codes (after Run) | changeover | three accounts cold');
for (const r of out) console.log(r.join(' | '));
