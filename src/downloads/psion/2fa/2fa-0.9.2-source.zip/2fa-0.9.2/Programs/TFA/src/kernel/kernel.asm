; =====================================================================
; Psion 2FA (TFA): the machine code, assembled as if at 0 and moved to
; the array by the fixer. Entered with D = ADDR(v%()):
;   v%() bytes 0-1 the array, 2-3 its size, 4 the device TFAC came from,
;   8-9 the launcher's flag (0 TFA, 1 CLOCK).
; Returns to TFAG with X = 0.
; =====================================================================
        include "defs.inc"
        include "macros.inc"

IDLE_SECS = 120                 ; switched off after two minutes with no key
FL_SUM  = 1                     ; st_flags: summer time (two lines)
FL_PIN  = 2                     ; st_flags: a PIN is set
A_KEEP  = 400                   ; free bytes left on A: when adding there: TFA must start again (tests/t_break.js:
                                ; on a CM a restart failed with 304 free while running, worked with 379)
KREC    = 77                    ; a record: its length byte and up to 76 characters
KEY_MIN = 16                    ; a key: 16 to 64 characters
KEY_MAX = 64
PIN_MIN = 4                     ; a PIN: 4 to 8 digits
PIN_MAX = 8

entry:  jmp  start
        fcc  "TFA1"             ; the tag tests find the kernel by

; ---- test hooks: tests stop at t_idle (in pollk), set X and PC = t_call, run to t_done
t_call: jsr  0,x
t_done: bra  t_done

        include "kmain.asm"
        include "kov.asm"
        include "kacct.asm"
        include "kfile.asm"
        include "kclock.asm"
        include "kscr.asm"
        include "kutil.asm"
        include "kotp.asm"
        include "ksha.asm"

        include "kvars.inc"
