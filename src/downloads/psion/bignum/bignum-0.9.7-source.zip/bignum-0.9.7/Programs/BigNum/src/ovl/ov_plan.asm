; =====================================================================
; OV_PLAN: the methods for the composite number of the record fa_rec, one after another: rho, P-1, P+1, ECM,
; the sieve: fx_found = 1 and the factor on top of the stack of numbers, or 0 (no method left). The work done
; is noted in the record. If the sieve can take the number, the methods before it get a fifth of its time.
; Entry 0: from the start. Entry 1: the method fa_st was skipped: from the next. 2: RESUME: the method fa_st goes on.
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        include "fa.inc"
        entry plan
        entry skip
        lastent resume

FR_W    = 3                     ; a record's work: rho, P-1, P+1, ECM levels 1 to 4
FR_N    = 20
plan:   clr  fa_st
        ldx  fa_rec
        ldab #FR_N
        abx
        stx  fx_n
        ldx  fx_n
        bsr  hcopy
        ovsub OV_DIGS,0
        bsr  hdrop
        ldd  kv_digs
        std  fx_dg
        ldaa #2                 ; no end to it, unless the sieve can take it
        staa fx_job
        clr  fa_lim
        bsr  qcan
        bcs  next
        inc  fa_lim
        dec  fx_job
        ovsub OV_QEST,0         ; kv_n = the sieve's time
        ldd  kv_n
        std  fx_js
        ldd  kv_n+2
        std  fx_js+2
        ldab #5                 ; a fifth
        bsr  ndiv
        ldd  kv_n
        std  fa_bud
        ldd  kv_n+2
        std  fa_bud+2
        addd fx_js+2            ; the job: the two
        std  fx_js+2
        ldd  kv_n
        adcb fx_js+1
        adca fx_js
        std  fx_js
        bra  next
resume: ldaa fa_st
        beq  go_rho
        deca
        beq  go_pm1
        deca
        beq  go_pp1
        deca
        beq  go_ecm
        bra  go_qs
; a method was skipped, or is done
skip:   bsr  note
again:  inc  fa_st
next:   ldaa fa_st
        beq  rho
        deca
        beq  pm1
        deca
        beq  pp1
        deca
        beq  ecm
        deca
        beq  qs
        clr  fx_found
        bra  plout
; done: a method has come to its end: what it did is noted; a factor, or the next method
done:   bsr  note
        tst  fx_found
        beq  again
plout:  clr  kv_skp
        rts

; ---- rho: 8,000 steps, or what the time allows
rho:    ldd  st_rho
        bne  .s
        ldd  #8000
        tst  fa_lim             ; (no sieve and a small number: to the end)
        bne  .s
        ldx  fx_dg
        cpx  #20
        bhi  .s
        ldd  #60000
.s:     ldx  fa_rec
        subd FR_W,x
        bls  again
        std  fx_lim
        ldd  #1000              ; a thousand steps' time
        std  kv_tot
        bsr  ctx
        ovsub OV_EST,5
        bsr  fits               ; kv_n = how many thousands fit, in 1/1000
        bcc  go_rho
        ldd  kv_n+2
        subd fx_lim
        bhs  go_rho
        ldd  kv_n+2
        std  fx_lim
        subd #200
        bcs  again
go_rho: bsr  start
        ovsub OV_RHO,0
        bra  done
; ---- P-1, P+1: B1 = 2,000 if there is time for it
pm1:    ldd  st_pm1
        bsr  b1
        ldx  fa_rec
        subd FR_W+2,x
        bls  again
        bsr  pmfit
        bcs  again
go_pm1: bsr  start
        ovsub OV_PM1,0
        bra  done
pp1:    ldd  st_pp1
        bsr  b1
        ldx  fa_rec
        subd FR_W+4,x
        bls  again
        bsr  pmfit
        bcs  again
go_pp1: bsr  start
        ovsub OV_PM1,1
        bra  done
b1:     bne  .x
        ldd  #2000
.x:     std  fx_lim
        rts
; pmfit: carry set if there is no time for both stages
pmfit:  bsr  ctx
        ldd  fx_lim
        std  kv_tot
        ovsub OV_EST,6
        ldd  kv_est
        std  kv_fs
        ldd  kv_est+2
        std  kv_fs+2
        ldd  fx_lim             ; (the second stage: 25 B1 / 256 units)
        ldx  #25
        os   UT$UMUL
        stx  kv_al
        tba
        ldab kv_al
        std  kv_tot
        ovsub OV_EST,7
        ldd  kv_est+2
        addd kv_fs+2
        std  kv_est+2
        ldd  kv_est
        adcb kv_fs+1
        adca kv_fs
        std  kv_est
        tst  fa_lim
        beq  .ok
        ldd  fa_bud+2
        subd kv_est+2
        ldd  fa_bud
        sbcb kv_est+1
        sbca kv_est
        rts
.ok:    clc
        rts
; ---- ECM, level after level
ecm:    ldd  st_ecm             ; a bound of your own: one level, CURVES curves
        beq  .lv
        std  fx_lim
        clr  fx_lvl
        ldd  st_cur
        bne  .c
        ldd  #25
.c:     ldx  fa_rec
        tst  FR_W+6,x
        bra  .try
.lv:    ldaa #1                 ; the first level with curves left
.l:     staa fx_lvl
        bsr  lev                ; D = its curves, fx_lim its bound, X = where the done ones are
        subd 0,x
        bhi  .some
        ldaa fx_lvl
        inca
        ldab fa_m               ; (PROVE: two levels)
        cmpb #2
        bne  .l4
        cmpa #3
        beq  again
.l4:    cmpa #5
        bne  .l
        tst  fa_lim             ; all done: the sieve, or more of level 4
        bne  again
        ldaa #4
        staa fx_lvl
        bsr  lev
        ldd  0,x
        addd #900
        bra  .set
.some:  addd 0,x
        bra  .set
.try:   std  fx_crv
        subd FR_W+6,x
        bls  again
        ldd  fx_crv
        bra  .set2
.set:   std  fx_crv
.set2:  bsr  wcur
        ldd  0,x
        std  fx_cur
        tst  fa_lim             ; as many curves as there is time for
        beq  go_ecm
        bsr  ctx
        ldd  #64
        std  kv_tot
        ovsub OV_EST,8
        ldx  kv_est
        bne  again
        ldx  kv_est+2
        bne  .d
        inx
.d:     stx  kv_nb
        ldd  #1
        std  kv_na
        ldd  fa_bud
        std  kv_n
        ldd  fa_bud+2
        std  kv_n+2
        bsr  muldiv
        ldx  kv_n
        bne  go_ecm
        ldd  kv_n+2
        beq  again
        addd fx_cur
        subd fx_crv
        bhs  go_ecm
        addd fx_crv
        std  fx_crv
go_ecm: bsr  start
        ovsub OV_ECM,0
        bsr  note
        tst  fx_found
        bne  plout
        ldx  st_ecm             ; (a bound of your own: once)
        bne  again
        bra  ecm                ; the next level, or no more time
; ---- the sieve
qs:     tst  fa_lim
        beq  again
go_qs:  bsr  start
        ovsub OV_QS,0
        bra  done

; lev: the level fx_lvl: D = its curves, fx_lim its bound, X = the place of the count in the record
lev:    ldab fx_lvl
        decb
        aslb
        aslb
        ldx  #levels
        abx
        ldd  0,x
        std  fx_lim
        ldd  2,x
        pshb
        psha
        bsr  wcur
        pula
        pulb
        rts
wcur:   ldab fx_lvl
        bne  .l
        incb
.l:     decb
        aslb
        addb #FR_W+6
        ldx  fa_rec
        abx
        rts
levels: fdb  500,5,2000,30,11000,70,50000,900   ; (as measured: ref/ecmcount.js)
; fits: kv_n = fa_bud x 1000 / kv_est; carry clear: no limit
fits:   tst  fa_lim
        bne  .l
        clc
        rts
.l:     ldd  fa_bud
        std  kv_n
        ldd  fa_bud+2
        std  kv_n+2
        ldd  #1000
        std  kv_na
        ldd  kv_est+2
        bne  .d
        incb
.d:     std  kv_nb
        bsr  muldiv
        ldx  kv_n
        beq  .s
        clc
        rts
.s:     sec
        rts
; ctx: mn for the estimates
ctx:    ldx  fx_n
        bsr  ilen
        std  mn
        rts
; start: a method starts: S skips it; the time noted
start:  ldaa #1
        staa kv_skp
        ldd  kv_el+2
        std  fa_t0
        clra
        clrb
        std  kv_done
        tst  kv_four
        bne  .x
        ovsub OV_HEAD,1         ; (two lines: the job, for two seconds)
.x:     rts
; note: what the method did, into the record; the time it took off the limit
note:   ldx  fa_rec
        ldaa fa_st
        bne  .n1
        ldd  kv_done            ; rho: the steps
        addd FR_W,x
        bcc  .r
        ldd  #$FFFF
.r:     std  FR_W,x
        bra  .t
.n1:    deca
        bne  .n2
        ldd  fx_lim
        std  FR_W+2,x
        bra  .t
.n2:    deca
        bne  .n3
        ldd  fx_lim
        std  FR_W+4,x
        bra  .t
.n3:    deca
        bne  .t
        bsr  wcur               ; ECM: the curves
        ldd  fx_cur
        std  0,x
.t:     ldd  kv_el+2            ; the time
        subd fa_t0
        std  kv_al
        ldd  fa_bud+2
        subd kv_al
        std  fa_bud+2
        ldd  fa_bud
        sbcb #0
        sbca #0
        std  fa_bud
        bcc  .x
        ldd  #0                 ; (used up)
        std  fa_bud
        std  fa_bud+2
.x:     rts
        include "qcan.inc"
