; the quadratic sieve's variables (kernel: q_...). N's item is fx_n; kN = the multiplier q_k times N.
; Byte strings are highest byte first. ub = bytes of u, a, b and the B's; kN takes 2 ub.
Q_SMALL = 20                    ; primes below this are not sieved by
Q_SMAX  = 10                    ; the most primes in an a
Q_ALOW  = 40                    ; they are no smaller than this, and
Q_POOL  = 48                    ; from so many of the base at most (all below 1,024)
; a record for each sieved prime (index q_i0 on): p, the two roots (from the block's start; $FFFF: not
; sieved), log2, then the changes of the roots for each b (q_s - 1 of them)
QR_P    = 0
QR_R1   = 2
QR_R2   = 4
QR_L    = 6
QR_D    = 7
QW_LEN  = 160                   ; room kept below the sieve for numbers being worked with
