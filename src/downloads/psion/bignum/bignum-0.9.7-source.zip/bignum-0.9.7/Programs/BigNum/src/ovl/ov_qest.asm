; =====================================================================
; OV_QEST: kv_n = the seconds the sieve should take for the number at fx_n. Entry 0: with as many primes as there is
; room for; entry 1: with q_f of them
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        entry size
        lastent qest

; 8 log2(seconds), every 8 bits from 40 to 200, with 3 bits - 186 primes (measured on the emulator to 48 digits, then
; from the PC twin); and 13 (n - F) / F more with only F of those n (the same: some numbers take half that, or twice)
size:   bsr  bits
        ovsub OV_QS0,1
qest:   bsr  bits
        ldx  #t1
        subd #40
        bcc  .a
        clra
        clrb
.a:     tsta
        bne  .max
        cmpb #160
        blo  .b
.max:   ldab #159
.b:     pshb                    ; between two entries
        lsrb
        lsrb
        lsrb
        abx
        pulb
        andb #7
        stab kv_al
        ldaa 1,x
        suba 0,x
        mul
        lsrd
        lsrd
        lsrd
        addb 0,x                ; 8 log2
        pshb
        ldd  kv_bits            ; the primes there should be
        subd #73
        bcs  .all
        addd #73
        std  zt
        asld
        addd zt
        subd #186
        tsta
        bne  .m2
        cmpb #240
        bls  .fi
.m2:    ldab #240
.fi:    subb q_f
        bls  .all
        ldaa #13
        mul
        std  kv_n+2
        ldx  #0
        stx  kv_n
        ldab q_f
        bsr  ndiv
        pulb
        addb kv_n+3
        bcs  .m3
        cmpb #199               ; (a year)
        bls  .go
.m3:    ldab #199
.go:    pshb
.all:   pulb
        tba
        lsra
        lsra
        lsra
        psha                    ; the whole part
        andb #7
        ldx  #frac
        abx
        ldab 0,x                ; 2 to the rest, x 128
        clra
        std  kv_n+2
        ldd  #0
        std  kv_n
        pulb
.s:     decb
        bmi  .d
        asl  kv_n+3
        rol  kv_n+2
        rol  kv_n+1
        rol  kv_n
        bra  .s
.d:     ldab #128
        bsr  ndiv
        rts
frac:   fcb  128,140,152,166,181,197,215,235
bits:   ldx  fx_n
        bsr  ibits
        std  kv_bits
        rts
t1:     fcb  31,32,34,37,42,48,50,56,64,69,76,85,96,103,113,121,133,147,161,177,193
        include "ibits.inc"
