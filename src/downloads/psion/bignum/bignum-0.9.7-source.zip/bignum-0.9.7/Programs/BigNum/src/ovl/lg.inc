; the log's records being made up (OV_LOG, OV_LOGC)
lg_sp   = kv_fs+14              ; (2) the stack
lg_b    = kv_fs+16              ; (2) the record being made up
lg_w    = kv_fs+18              ; (2) the stack of numbers
lg_i    = kv_fs+20              ; (2) a digit
lg_r    = kv_fs+22              ; (2) a record of the list
; digs: the top number's digits into the record (used up); digs0: converted only; digs1: put in
digs:   bsr  digs0
        bsr  digs1
        ldx  lg_b
        stx  kv_wp
        rts
digs0:  bra  decimal
digs1:  clra
        clrb
        std  lg_i
        tst  dg_neg
        beq  .l
        ldaa #'-'
        bsr  lch
.l:     ldd  lg_i
        bsr  dgch
        bsr  lch
        ldx  lg_i
        inx
        stx  lg_i
        cpx  dg_n
        bne  .l
        rts
; lch: A into the record (B, X kept); a full one is written first
lch:    pshx
        pshb
        ldx  lg_b
        ldab 0,x
        cmpb #250
        bne  .p
        psha
        bsr  flush
        pula
        ldx  lg_b
.p:     inc  0,x
        ldab 0,x
        abx
        staa 0,x
        pulb
        pulx
        rts
; flush: the record written
flush:  ldx  lg_b
        tst  0,x
        beq  .x
        os   FL$WRIT
        bcs  lg_err
        ldx  lg_b
        clr  0,x
.x:     rts
; an error: said (and no more: the result is shown next), back to OV_LOG's caller
lg_err: lds  lg_sp
        pshb
        bsr  cls
        pulb
        os   ER$MESS
lg_x:   ldx  lg_w
        stx  kv_wp
        rts
; ltx: the lbc at X into the record
ltx:    ldab 0,x
.l:     inx
        ldaa 0,x
        bsr  lch
        decb
        bne  .l
        rts
; lnew: an empty line buffer; llb: what is in it into the record
lnew:   bra  ln0
llb:    ldx  #kv_lbuf
.l:     cpx  kv_p
        beq  .x
        ldaa 0,x
        bsr  lch
        inx
        bra  .l
.x:     rts
