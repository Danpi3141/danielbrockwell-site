; =====================================================================
; OV_LOGV: LOG: the records of the log, the newest first: UP and DOWN go through them, RIGHT and LEFT through one
; too long for the screen.
; =====================================================================
        include "macros.inc"
        lastent logv

lo_n    = kv_fs+16              ; (2) the records
lo_i    = kv_fs+18              ; (2) the one shown
lo_o    = kv_fs+20              ; its first character shown, from 0
lo_b    = kv_fs+21              ; (2)
logv:   ldaa kv_tier
        cmpa #4
        bne  .ok
        ldab #E_AVL
        clr  kv_epos
        bra  err
.ok:    ldx  #off
        ldaa st_log
        beq  .msg
        adda #'A'-1
        staa name+1
        ldx  #name
        os   FL$OPEN
        ldx  #none
        bcs  .msg
        tab
        os   FL$RECT
        os   FL$SIZE            ; X = the records
        stx  lo_n
        stx  lo_i
        ldx  #none
        ldd  lo_n
        beq  .msg
        ldd  #256
        bsr  walloc
        stx  lo_b
        bra  rec
.msg:   pshx
        bsr  cls
        bsr  ln0
        pulx
        bsr  prs
        bsr  out
        clr  RTB_BL
        bra  getk
rec:    clr  lo_o
        ldd  lo_i
        os   FL$RSET
        ldx  lo_b
        os   FL$READ
        bcc  clean
        pshb
        bsr  cls
        pulb
        os   ER$MESS
        rts
clean:  ldx  lo_b               ; (a file of something else: no control codes)
        ldab 0,x
        beq  draw
.c:     ldaa 1,x
        cmpa #32
        bhs  .o
        ldaa #32
        staa 1,x
.o:     inx
        decb
        bne  .c
draw:   clra
.r:     psha
        bsr  ln
        pula
        psha
        ldab kv_w
        mul
        addb lo_o
        ldx  lo_b
        ldaa 0,x                ; the characters left
        sba
        bls  .e
        abx
        inx
        cmpa kv_w
        bls  .n
        ldaa kv_w
.n:     tab
        bsr  prb
.e:     bsr  out
        pula
        inca
        cmpa kv_h
        bne  .r
.k:     bsr  getk
        cmpb #K_UP
        beq  .up
        cmpb #K_DOWN
        beq  .down
        cmpb #K_RIGHT
        beq  .right
        cmpb #K_LEFT
        beq  .left
        cmpb #K_EXE
        beq  .up
        cmpb #K_ON
        beq  .x
        cmpb #K_MODE
        bne  .k
.x:     clr  RTB_BL
        ldx  kv_vb
        stx  kv_wp
        rts
.up:    ldx  lo_i
        dex
        beq  .k
        stx  lo_i
        bra  rec
.down:  ldx  lo_i
        cpx  lo_n
        beq  .k
        inx
        stx  lo_i
        bra  rec
.right: ldaa kv_w
        ldab kv_h
        mul
        addb lo_o
        bcs  .k
        ldx  lo_b
        cmpb 0,x
        bhs  .k
        stab lo_o
        bra  draw
.left:  ldaa kv_w
        ldab kv_h
        mul
        ldaa lo_o
        sba
        bcs  .k
        staa lo_o
        bra  draw
name:   fcl  "A:BIGLOG"
off:    fcl  "LOG is OFF"
none:   fcl  "No log"
