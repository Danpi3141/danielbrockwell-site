; =====================================================================
; OV_HELP: HELP: what there is, a line each
; =====================================================================
        include "macros.inc"
        lastent help

he_i    = kv_fs+16
help:   clr  he_i
draw:   clra
.r:     psha
        bsr  ln
        pula
        psha
        tab
        addb he_i
        ldx  #text
.f:     decb
        bmi  .p
        pshb
        ldab 0,x
        incb
        abx
        pulb
        bra  .f
.p:     bsr  prs
        bsr  out
        pula
        inca
        cmpa kv_h
        bne  .r
.k:     bsr  getk
        cmpb #K_DOWN
        beq  .down
        cmpb #K_UP
        beq  .up
        cmpb #K_EXE
        beq  .down2
        cmpb #K_ON
        beq  .x
        cmpb #K_MODE
        bne  .k
.x:     rts
.up:    tst  he_i
        beq  .k
        dec  he_i
        bra  draw
.down2: ldaa he_i               ; EXE: a page on, and at the end back
        adda kv_h
        cmpa #LINES
        bhs  .x
        ldab #LINES             ; (no further than the last page)
        subb kv_h
        cba
        bls  .set
        tba
.set:   staa he_i
        bra  draw
.down:  ldaa he_i
        adda kv_h
        cmpa #LINES
        bhs  .k
        inc  he_i
        bra  draw
text:
        fcl  "BigNum 0.9.7"
        fcl  "Daniel+Claude"
        fcl  "UP DOWN: scroll"
        fcl  "MODE: menu"
        fcl  "+ - * / % **"
        fcl  "GCD LCM MOD ABS"
        fcl  "SQRT(a) SIZE(a)"
        fcl  "NROOT(a,n)"
        fcl  "MODEXP(a,e,m)"
        fcl  "MODINV(a,m)"
        fcl  "MODSQRT(a,p)"
        fcl  "CRT(a,m,b,n)"
        fcl  "JACOBI(a,n)"
        fcl  "ISPRIME(n)"
        fcl  "PROVE(n)"
        fcl  "NEXTPRIME(n)"
        fcl  "PREVPRIME(n)"
        fcl  "LLT(p): 2**p-1"
        fcl  "FACTOR(n)"
        fcl  "TRIAL(n,limit)"
        fcl  "RHO PM1 PP1 QS"
        fcl  "ECM(n,curves)"
        fcl  "PHI TAU SIGMA"
        fcl  "FACT(n)"
        fcl  "PRIMORIAL(n)"
        fcl  "FIB(n) LUC(n)"
        fcl  "BINOM(n,k)"
        fcl  "A=... stores"
        fcl  "V+letter stores"
        fcl  "ANS: last result"
        fcl  "SET VARS CLR"
        fcb  13
        fcc  "SAVE A,"
        fcb  34
        fcc  "name"
        fcb  34
        fcb  13
        fcc  "LOAD A,"
        fcb  34
        fcc  "name"
        fcb  34
        fcl  "RESUME BENCH LOG"
        fcl  "ON: stop, clear"
LINES   = 35
