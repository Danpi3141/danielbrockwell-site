fs_i    = kv_fs+16              ; the factor at the top (or shown), from 0
fs_n    = kv_fs+17              ; how many
fs_c    = kv_fs+18              ; one cut short (255 none)
fs_j    = kv_fs+19              ; the one being shown
fs_l    = kv_fs+20              ; its line
fs_p    = kv_fs+21              ; 1: there is a probable prime
fs_w    = kv_fs+22              ; the columns for the digits
