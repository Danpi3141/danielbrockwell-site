; =====================================================================
; OV_CMD: CLR (all the variables) and CLR A (one). Entry 1: TIER: the memory tier (1 to 4) as a result,
; kept in ANS
; =====================================================================
        include "macros.inc"
        entry clr_
        lastent tier

tier:   bsr  nextc
        tstb
        bne  syn
        ldab kv_tier
        clra
        bsr  hpush
        ovjump OV_SHOW,0

clr_:   bsr  nextc
        tstb
        beq  all
        bsr  upc
        cmpb #'A'
        blo  syn
        cmpb #'Z'
        bhi  syn
        stab kv_dst
        bsr  nextc
        tstb
        bne  syn
        ldx  kv_vb              ; that one
.f:     cpx  kv_hi
        beq  .none
        ldab 0,x
        cmpb kv_dst
        beq  .got
        inx
        bsr  inext
        bra  .f
.none:  ldab #E_SET
        ldaa kv_tp
        suba #3
        staa kv_epos
        bra  err
.got:   stx  zx                 ; the ones below it up over it
        pshx
        inx
        bsr  inext
        stx  zp
        pula
        pulb
        std  zt
        ldd  zp
        subd zt
        std  kv_se              ; its bytes
        ldd  zt
        std  zx
        subd kv_vb
        pshb
        psha
        ldd  kv_vb
        addd kv_se
        std  kv_vb
        std  kv_wp
        pula
        pulb
        bsr  cpd
        bra  done
syn:    ldab #E_SYN
        ldaa kv_tp
        deca
        deca
        staa kv_epos
        bra  err
all:    ldx  kv_hi
        stx  kv_vb
        stx  kv_wp
done:   ldx  #txt
        bsr  msg
        rts
txt:    fcl  "Cleared"
        include "msg.inc"
        include "nextc.inc"
