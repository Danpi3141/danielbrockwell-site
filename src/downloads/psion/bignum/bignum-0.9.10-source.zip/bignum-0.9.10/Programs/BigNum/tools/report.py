#!/usr/bin/env python3
"""Puts this build's figures into docs/report.html (its line "const D = ...").

    node tools/report_probe.js ...      (build/report/*.json: see PROBES below)
    python tools/report.py

Sizes come from the build (build/game), memory, times and screens from build/report, the sieve's whole jobs from
data/sieve_times.csv.
"""
import json
import os
import re
import struct

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
G = os.path.join(ROOT, 'build', 'game')
R = os.path.join(ROOT, 'build', 'report')
# PROBES: maps > maps.json; screens lz64|xp > scr_*.json; sieve lz64 48 400 > q48.json; sieve xp <40 digits> 300 > q40.json;
# profile lz64 "QS(<48 digits>)" -60 600 > p48.json; "QS(<40>)" -30 400 > p40.json;
# profile lz64|cm "ISPRIME(2**2047+1919)" 60 120 > pprp.json|pcm.json; profile lz64 "ECM((2**61-1)*(10**20+39),2)" 25 60 > pecm.json


def js(p):
    return json.load(open(p, encoding='utf8'))


GROUPS = [
    ('shell', 'Line, screens, menus', 'init edit eval pre show page names menu cmd ins vars set setl setf help digs bench pause prog est'),
    ('arith', 'Arithmetic functions', 'div pow fn root seq binom mexp meven minv msqr mset'),
    ('prime', 'Primality', 'prp pshow base2 luc lucp next llt ksq'),
    ('proof', 'Proofs', 'prove prvm pchk wit witt sqt lv cert vshow cshow'),
    ('factor', 'FACTOR and its methods', 'fact trial trf ppow plan fshow fline fspl phi head meth rho pm1 pm1a ps ps2 ps2a ecm ecma ecs ec2 ec2a'),
    ('sieve', 'The sieve', 'qs qs0 qs1 qsv qsp qsl qsx qest'),
    ('files', 'Files, KEEP, the log', 'keep ckl res file fsav log logc logv'),
]
NOTES = {
    'init': 'the start: the tier, the multiply rows made, the settings read', 'edit': 'the entry line: typing, recall, the header or an error',
    'eval': 'a line checked, then worked out: operators on a stack of their own', 'pre': 'a command, or the variable of A=...',
    'show': 'a result shown and kept in ANS', 'page': 'the pager for long numbers', 'names': 'the 32 functions and 10 commands looked up',
    'menu': 'the menu (drawn by the OS)', 'cmd': 'CLR, TIER', 'ins': 'Insert: the functions listed', 'vars': 'the variables listed', 'set': 'SET name value',
    'setl': 'the settings listed', 'setf': 'the settings file A:BIGNUM', 'help': 'HELP, 37 lines', 'digs': 'how many digits a number has',
    'bench': 'BENCH: products timed', 'pause': 'a run paused: C S K A', 'prog': 'times and progress (kept in RAM on tiers 1 to 3)', 'est': 'how long a run should take',
    'div': 'division and remainders', 'pow': '**', 'fn': 'GCD LCM JACOBI ABS SIZE', 'root': 'SQRT, NROOT (Newton)', 'seq': 'FACT PRIMORIAL FIB LUC', 'binom': 'BINOM (by primes)',
    'mexp': 'MODEXP, an odd modulus', 'meven': 'MODEXP, an even modulus', 'minv': 'MODINV, CRT', 'msqr': 'MODSQRT (Tonelli and Shanks)', 'mset': 'Montgomery work set up',
    'prp': 'ISPRIME: small factors, base 2, Lucas', 'pshow': "ISPRIME's result", 'base2': 'the strong test to base 2', 'luc': 'the extra strong Lucas test', 'lucp': 'its P chosen',
    'next': 'NEXTPRIME, PREVPRIME: a window sieved', 'llt': 'LLT(p): Lucas and Lehmer', 'ksq': 'long squares the Karatsuba way (tiers 1 to 3)',
    'prove': 'PROVE, and P on the screens', 'prvm': 'a proof and those it rests on', 'pchk': 'is enough of N-1 or N+1 factored?', 'wit': 'a witness for each prime', 'witt': 'the Lucas parameter t',
    'sqt': 'the last test when a third is factored', 'lv': 'a Lucas sequence modulo N', 'cert': 'the certificate made', 'vshow': "PROVE's result", 'cshow': 'the certificate shown',
    'fact': 'FACTOR: the list of factors', 'trial': 'trial division', 'trf': 'a small factor into the list', 'ppow': 'is it a perfect power?', 'plan': 'which method next, and for how long',
    'fshow': 'the factors shown', 'fline': 'one line of them', 'fspl': 'the list changed: split, power, prime', 'phi': 'PHI TAU SIGMA', 'head': "a method's fixed lines", 'meth': 'RHO PM1 PP1 ECM QS by themselves',
    'rho': "Pollard's rho (Brent)", 'pm1': 'P-1 and P+1, first stage', 'pm1a': 'their set-up', 'ps': 'a window of primes', 'ps2': 'P-1 and P+1, second stage', 'ps2a': 'its set-up',
    'ecm': 'ECM, first stage', 'ecma': 'its set-up', 'ecs': 'a curve from sigma', 'ec2': 'ECM, second stage', 'ec2a': 'its set-up',
    'qs': 'the sieve, all of it; a new a and its roots', 'qs0': 'multiplier, sizes, room', 'qs1': 'the factor base', 'qsv': 'its polynomials sieved, cells divided out',
    'qsp': 'a relation kept or paired', 'qsl': 'the relations combined', 'qsx': 'the square root and the factor', 'qest': 'how long it should take',
    'keep': 'K and KEEP: the run written to BIGKEEP', 'ckl': 'and read back', 'res': 'RESUME', 'file': 'SAVE and LOAD', 'fsav': 'a number written to a file', 'log': 'the log BIGLOG', 'logc': 'a certificate into it', 'logv': 'LOG: the log shown',
}


def main():
    D = {}
    bud = open(os.path.join(G, 'budget.txt')).read()
    D['ver'] = re.search(r'BigNum (\S+)', bud).group(1)
    D['id'] = re.search(r'build (\w+)', bud).group(1)
    D['pack'] = int(re.search(r'(\d+) bytes used', bud).group(1))
    bnk, code, fixer, fixups, bnl = [int(x) for x in re.search(r'BNK (\d+) \(resident code (\d+), fixer (\d+), fix-ups (\d+)\), BNL (\d+)', bud).groups()]
    sym = js(os.path.join(G, 'kernel.sym.json'))
    s = {n: v[0] for n, v in sym.items()}
    meta = js(os.path.join(G, 'build.json'))
    ovl = {m.group(1).lower()[3:]: (int(m.group(2)), int(m.group(3))) for m in re.finditer(r'^\s+(OV_\w+)\s+(\d+)\s+(\d+)$', bud, re.M)}
    order = [u[3:] for u in meta['ovl']]
    first2 = order.index('qs0')
    big = {u for u in order if u.startswith('qs') or u in ('ksq', 'qest', 'keep', 'file', 'res', 'logv', 'fsav', 'log', 'logc', 'ckl')}
    groups = []
    seen = set()
    for key, name, us in GROUPS:
        us = us.split()
        seen |= set(us)
        groups.append({'k': key, 'n': name, 'u': [[u, ovl[u][0], ovl[u][1], int(u in big), NOTES[u]] for u in us]})
    assert seen == set(order), seen ^ set(order)
    D['groups'] = groups
    D['nov'] = len(order)
    kinit = len(open(os.path.join(G, 'kinit.lst')).read())  # (only to notice it is there)
    assert kinit
    last = open(os.path.join(G, 'kinit.lst')).read().rstrip().split('\n')[-1]
    kin = int(last[:4], 16) + len(last[6:].split(' ')[0]) // 2 - s['ov_slot']
    boot = int(re.search(r'bootstrap (\d+)', bud).group(1))
    D['res'] = {'code': code, 'vars': s['ov_slot'] - s['kv_vars'], 'small': meta['small'], 'slot': meta['slot'], 'prg': s['kv_fy'] - s['kv_prg'], 'qv': s['kv_big'] - s['kv_fy'], 'rsmall': meta['res'], 'rbig': meta['big'], 'kinit': kin, 'boot': boot, 'fixer': fixer, 'fixups': fixups}
    # kernel by file
    f = [('header', 0), ('kmain', s['kgo']), ('kov', s['ovc']), ('kscr', s['clsf']), ('kheap', s['walloc']), ('rows', s['ycl']), ('core', s['mulp']), ('', s['kv_vars'])]
    D['kfiles'] = [[a[0], b[1] - a[1]] for a, b in zip(f, f[1:])]
    # the pack
    areas = [sum(ovl[u][1] for u in us) + 2 * len(us) for us in (order[:first2], order[first2:])]
    klen = s['ov_slot'] + kin
    ptab = 2185                 # the primes for trial division, in BNK after its index (tools/build.py PTABLE)
    assert 8 + klen + fixer + fixups + areas[0] + ptab == bnk and 2 + areas[1] == bnl, (8 + klen + fixer + fixups + areas[0], bnk, 2 + areas[1], bnl)
    D['packs'] = {'bnk': bnk, 'bnl': bnl, 'k0': 8, 'kimg': code, 'kzero': s['ov_slot'] - code, 'kin': kin, 'fixer': fixer, 'fixups': fixups, 'a0': areas[0], 'ptab': ptab, 'a1': areas[1], 'n0': first2, 'n1': len(order) - first2,
                  'ovcode': sum(v[0] for v in ovl.values()), 'ovpack': sum(v[1] for v in ovl.values()), 'rest': D['pack'] - bnk - bnl}
    # machines at the entry line
    maps = js(os.path.join(R, 'maps.json'))
    D['mach'] = {}
    for mo, m in maps.items():
        a = m['start']
        top = {'cm': 0x4000, 'xp': 0x6000}.get(mo, 0x8000)
        seg = [['os', 'Organiser: system RAM, files on A:', a['alafree'] - 0x2000], ['gap', 'left for files and the OS', a['lo'] - a['alafree']], ['num', 'numbers, variables', a['hi'] - a['lo']]]
        if a['tier'] < 4:
            seg += [['line', 'lines for recall, the line', a['et'] - a['rec']], ['rows', 'multiply rows', a['base'] - a['et']]]
        seg += [['code', 'kernel code', s['kv_vars']], ['vars', 'variables', s['ov_slot'] - s['kv_vars']], ['slot', 'overlay slot', meta['small'] if a['tier'] == 4 else meta['slot']]]
        if a['tier'] < 4:
            seg += [['prg', 'progress code', s['kv_fy'] - s['kv_prg']], ['qv', 'sieve variables', s['kv_big'] - s['kv_fy']]]
        seg += [['lau', 'launcher', m['menu'][0] - a['end']], ['stk', 'OS, stack', top - m['menu'][0]]]
        assert sum(x[2] for x in seg) == top - 0x2000, (mo, sum(x[2] for x in seg), top - 0x2000)
        D['mach'][mo] = {'free': m['free'], 'tier': a['tier'], 'seg': seg, 'tot': top - 0x2000}
    # a 2,048-bit test on the CM
    c = maps['cm']
    p = c['prime']
    var = p['hi'] - p['vb']
    D['cm2048'] = [['free', 'free', p['wp'] - p['lo']], ['prod', 'the product (2 x 256) and a byte', c['ms'] - p['wp']], ['slots', 'two slots of 256', 512], ['mod', "the modulus, the line's argument", p['vb'] - c['ms'] - 512], ['vars', 'A and ANS, 2,048 bits each', var]]
    assert sum(x[2] for x in D['cm2048']) == p['hi'] - p['lo']
    # the sieve's block
    D['qmap'] = {}
    for k in ('48', '40'):
        d = js(os.path.join(R, 'q%s.json' % k))
        q, m = d['q'], d['map']
        seg = [['work', 'room for numbers', q['q_sv'] - m['lo']], ['sv', 'the sieve', q['q_rec'] - q['q_sv']], ['rec', 'records of the primes', q['q_rel'] - q['q_rec']], ['rel', 'relations and partial ones', q['q_pe'] - q['q_rel']],
               ['ab', "a, b, the B's, work", q['q_lg'] - q['q_a']], ['lg', 'logs of the primes for a', q['q_t'] - q['q_lg']], ['pt', 'primes and square roots', q['q_kn'] - q['q_t']], ['kn', 'kN and the numbers', m['vb'] - q['q_kn']]]
        assert sum(x[2] for x in seg) == m['vb'] - m['lo']
        n = q['q_f'] + 10
        D['qmap'][k] = {'mo': d['mo'], 'seg': seg, 'tot': m['vb'] - m['lo'], 'q': {a[2:]: q[a] for a in ('q_f', 'q_s', 'q_k', 'q_ub', 'q_rs', 'q_svz', 'q_i0', 'q_plo', 'q_phi', 'q_bits', 'q_lp', 'q_np')},
                        'mat': n * ((q['q_f'] + 8) // 8), 'need': n}
    # profiles
    KIND = {'fill': r'poly\.f$|poly\.fill|^qsv', 'scan': r'poly\.(s|sn|scan|hit)$', 'prime': r'poly\.(pr|np|small)$', 'log': r'poly\.(m1|l1|e1|m2|c2|l2|e2|m3|c3|l3|a3|e3|x3|large)$', 'switch': r'^switch', 'cand': r''}

    def prof(fn):
        d = js(os.path.join(R, fn))
        out = {}
        for k, v in d['r']:
            if k.startswith('ov_qsv '):
                lab = k.split()[1]
                for kk, rx in KIND.items():
                    if re.search(rx, lab):
                        break
            elif k.split()[0] == 'ov_qs':
                kk = 'newa'
            elif k == 'OS':
                kk = 'os'
            elif k == 'rows':
                kk = 'rows'
            elif k.startswith('kernel'):
                lab = k.split()[1]
                kk = 'core' if lab in ('mr', 'rr', 'mulr', 'mulrx', 'redr', 'redc', 'sqrp', 'mulp', 'ycl', 'entryw', 'chunkw', 'chunky', 'chunkp', 'chunkq', 'chunkd', 'clrx', 'clrxn', 'cpb', 'sub3', 'add3', 'as', 'as_o', 'as_p', 'as_n', 'as_l', 'as_b', 'as_a', 'as_x', 'ycl_j', 'mrun', 'mop', 'mslot', 'cmpn', 'mfin') else 'disp'
            else:
                kk = 'disp'
            out[kk] = out.get(kk, 0) + v
        return {'text': d['text'], 'r': {k: round(v, 1) for k, v in out.items()}}
    D['prof'] = {k: prof(k + '.json') for k in ('p48', 'p40', 'pprp', 'pcm', 'pecm')}
    # screens
    D['scr'] = {}
    for mo in ('lz64', 'xp'):
        o = js(os.path.join(R, 'scr_%s.json' % mo))['out']
        named = {x['name']: x['t'] for x in o if x['name'] != 'fac'}
        fac = [[x['s'], x['t']] for x in o if x['name'] == 'fac']
        D['scr'][mo] = {'n': named, 'fac': fac}
    # whole jobs
    D['jobs'] = []
    for l in open(os.path.join(ROOT, 'data', 'sieve_times.csv')):
        v = l.strip().split(',')
        if v[0].isdigit():
            D['jobs'].append([int(v[0]), int(v[2]), int(v[5])])
    p = os.path.join(ROOT, 'docs', 'report.html')
    h = open(p, encoding='utf8').read()
    out, n = re.subn(r'(?m)^const D = .*$', lambda m: 'const D = ' + json.dumps(D, separators=(',', ':')) + ';', h)
    assert n == 1
    open(p, 'w', encoding='utf8', newline='\n').write(out)
    print('docs/report.html: %d bytes; D %d' % (len(out), len(json.dumps(D))))
    for k in ('ver', 'id', 'pack', 'res', 'kfiles', 'packs', 'cm2048', 'prof'):
        print(k, D[k])
    for mo, m in D['mach'].items():
        print(mo, m['free'], m['tier'], m['seg'])
    print(D['qmap'])
    print([(g['n'], len(g['u']), sum(x[1] for x in g['u']), sum(x[2] for x in g['u'])) for g in groups])


if __name__ == '__main__':
    main()
