; gcd: the top two numbers (not negative) replaced by their greatest common divisor.
; gd_go: the loop by itself, with Jacobi's sign (the second number over the top one) in gd_s.
; Binary and in place: the numbers' first bytes at gd_a, gd_b, their lengths gd_la, gd_lb.
; With GD_ODD defined (OV_RHO's): the second number is odd, and there is no Jacobi's sign.
gd_a    = ma
gd_la   = mal
gd_b    = mb
gd_lb   = mbl
gd_z    = mq                    ; the twos in both
gd_za   = mpc
gd_s    = mwq
gcd:    bsr  i2                 ; nothing to do if either is 0
        bsr  ilen
        subd #0
        beq  hnip
        bsr  ilenw
        subd #0
        beq  hdrop
        bsr  gd_set
        bsr  gd_odd             ; A's twos
        ifdef GD_ODD
        bsr  gd_go
        bra  gd_res
        else
        std  gd_za
        bsr  gd_swap
        bsr  gd_odd             ; B's
        std  gd_z
        subd gd_za
        bls  .c
        ldd  gd_za              ; the fewer
        std  gd_z
.c:     bsr  gd_go
        ldd  gd_z               ; A x 2 to the gd_z
        pshb
        psha
        bsr  gd_res
.s:     clra
        clrb
        std  kv_na
        pula
        pulb
        subd #8
        bcs  .l
        pshb
        psha
        ldd  #256
        bsr  hmuladd
        bra  .s
.l:     addb #8
        beq  .x
        ldaa #1
.b:     asla
        decb
        bne  .b
        tab
        clra
        bra  hmuladd
.x:     rts
        endif
; gd_res: the answer (A) in place of the two numbers
gd_res: ldx  gd_a
        dex
        dex
        stx  kv_wp
        ldd  gd_la
        std  0,x
        bra  hslide
; gd_set: the two numbers' places; kv_se their end
gd_set: bsr  ilenw
        std  gd_lb
        inx
        inx
        stx  gd_b
        bsr  i2
        bsr  ilen
        std  gd_la
        inx
        inx
        stx  gd_a
        dex
        dex
        bsr  inext
        stx  kv_se
        clr  gd_s
        rts
; gd_go: both odd: until they are the same (the answer)
gd_go:  bsr  poll
        ldd  gd_la              ; A against B
        subd gd_lb
        bne  .ne
        ldx  gd_a
        stx  zx
        ldx  gd_b
        stx  zp
        ldx  gd_la
.cl:    stx  zt
        ldx  zx
        ldaa 0,x
        inx
        stx  zx
        ldx  zp
        cmpa 0,x
        bne  .ne
        inx
        stx  zp
        ldx  zt
        dex
        bne  .cl
        rts                     ; the same
.ne:    bcc  .sub
        bsr  gd_swap            ; the larger is A (Jacobi: if both are 3 modulo 4 the sign changes)
        ifndef GD_ODD
        bsr  gd_low
        psha
        bsr  gd_lowb
        pulb
        stab zm
        anda zm
        anda #2
        beq  .sub
        bsr  gd_neg
        endif
.sub:   ldd  gd_a               ; A - B
        addd gd_la
        std  zx
        ldd  gd_b
        addd gd_lb
        std  zp
        ldx  gd_lb
        clr  zw                 ; the borrow
.sl:    stx  zt
        ldx  zp
        dex
        stx  zp
        ldab 0,x
        ldx  zx
        dex
        stx  zx
        ldaa 0,x
        stab zm
        lsr  zw
        sbca zm
        rol  zw
        staa 0,x
        ldx  zt
        dex
        bne  .sl
        tst  zw
        beq  .tr
        ldx  zx
.bw:    dex
        ldaa 0,x
        dec  0,x
        tsta
        beq  .bw
.tr:    ldx  gd_a               ; its zeros at the front gone
        ldd  gd_la
.z:     tst  0,x
        bne  .nz
        inx
        subd #1
        bra  .z
.nz:    stx  gd_a
        std  gd_la
        bsr  gd_odd
        ifdef GD_ODD
        bra  gd_go
        else
        lsrb                    ; Jacobi: an odd number of twos, and B 3 or 5 modulo 8
        bcc  gd_go
        bsr  gd_lowb
        inca
        anda #4
        beq  .k
        bsr  gd_neg
.k:     bra  gd_go
gd_neg: ldaa gd_s
        eora #$80
        staa gd_s
        rts
; gd_low: A = the number A's lowest byte; gd_lowb: B's
gd_lowb: ldx gd_b
        ldd  gd_lb
        bra  gd_l
        endif
gd_low: ldx  gd_a
        ldd  gd_la
gd_l:   stx  zt
        addd zt
        xgdx
        dex
        ldaa 0,x
        rts
; gd_swap: A and B change places
gd_swap: ldx gd_a
        ldd  gd_b
        std  gd_a
        stx  gd_b
        ldx  gd_la
        ldd  gd_lb
        std  gd_la
        stx  gd_lb
        rts
; gd_odd: A (not 0) shifted down until it is odd: D = how far
gd_odd: ldx  #0
        stx  zw
.by:    bsr  gd_low             ; whole bytes
        tsta
        bne  .bits
        ldx  gd_la
        dex
        stx  gd_la
        ldd  zw
        addd #8
        std  zw
        bra  .by
.bits:  lsra
        bcs  .x
        psha
        ldd  gd_la
        tstb
        beq  .e
        inca
.e:     staa zt
        ldx  gd_a
        clc
.sh:    ror  0,x
        inx
        decb
        bne  .sh
        dec  zt
        bne  .sh
        ldx  gd_a               ; a zero at the front gone
        tst  0,x
        bne  .s2
        inx
        stx  gd_a
        ldx  gd_la
        dex
        stx  gd_la
.s2:    ldx  zw
        inx
        stx  zw
        pula
        bra  .bits
.x:     ldd  zw
        rts
