// The sieve from inside: the multiplier and factor base, every a's B's and records, the roots of every
// polynomial, every relation kept.   node tests/t_qs1.js [model] [digits] [seed]
'use strict';
const { BN, rng, fromBytes, HZ } = require('./lib');
const model = process.argv[2] || 'lz64';
const digits = +process.argv[3] || 24;
const R = rng(+process.argv[4] || 1);
const g = new BN(model).start(), m = g.m;
let fails = 0;
const fail = (s) => { console.log('FAIL', s); if (++fails > 10) process.exit(1); };
const powm = (b, e, p) => { let r = 1n; b %= p; while (e) { if (e & 1n) r = r * b % p; b = b * b % p; e >>= 1n; } return r; };
const prime = (v) => { for (const p of [2n, 3n, 5n, 7n, 11n, 13n, 17n, 19n, 23n, 29n, 31n, 37n]) if (v % p === 0n) return v === p; let d = v - 1n, s = 0; while (!(d & 1n)) { d >>= 1n; s++; }
  next: for (const a of [2n, 3n, 5n, 7n, 11n, 13n, 17n]) { let x = powm(a, d, v); if (x === 1n || x === v - 1n) continue; for (let i = 1; i < s; i++) { x = x * x % v; if (x === v - 1n) continue next; } return false; } return true; };
const rp = (lo, hi) => { for (;;) { const v = lo + R.bits(Number((hi - lo).toString(2).length) + 8) % (hi - lo) | 1n; if (v < hi && prime(v)) return v; } };
const root = (v) => { let x = 1n << BigInt(Math.ceil(v.toString(2).length / 2)); for (;;) { const y = (x + v / x) / 2n; if (y >= x) return x; x = y; } };
const lo = root(10n ** BigInt(digits - 1)), hi = root(10n ** BigInt(digits));
const P = rp(lo, hi), Q = rp(lo, hi), N = P * Q;
console.log('N =', String(N), '=', String(P), 'x', String(Q));
const t = `QS(${N})`;
g.wait(); m.write(g.peekw('kv_line'), [t.length, ...[...t].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', t.length);
m.poke(0x76, 13);
const OV = (o) => g.meta.ovl.indexOf(o) + 1;
// run to an address inside an overlay
const to = (ov, name, sec = 3000) => { const a = g.oaddr(ov, name); for (;;) { if (m.runTo([a], HZ * sec) !== a) throw new Error('never came to ' + name + '\n' + g.text()); if (g.peek('kv_res') === OV(ov)) return; m.run(1); } };
const signed = (b) => { let v = fromBytes(b); if (b[0] & 0x80) v -= 1n << BigInt(8 * b.length); return v; };
const c0 = m.cycles();
to('ov_qs', 'qsa');
const w = (n) => g.peekw(n), b1 = (n) => g.peek(n);
const ub = b1('q_ub'), F = b1('q_f'), s = b1('q_s'), rs = b1('q_rs'), i0 = b1('q_i0'), k = BigInt(b1('q_k')), M = w('q_m');
const kN = fromBytes(m.read(w('q_kn'), 2 * ub));
if (kN !== k * N) fail('kN');
console.log(`k ${k} bits ${w('q_bits')} (${kN.toString(2).length}) ub ${ub} F ${F} s ${s} rs ${rs} i0 ${i0} M ${M} lgt ${w('q_lgt') / 256} fill ${b1('q_fill')} lp ${w('q_lp')} pool ${b1('q_plo')}-${b1('q_phi')} need ${w('q_need')} set-up ${((m.cycles() - c0) / HZ).toFixed(1)} s`);
console.log(`room: relations ${w('q_pe') - w('q_rel')} records ${w('q_rece') - w('q_rec')} sieve ${w('q_rec') - w('q_sv')} work ${w('q_sv') - w('kv_lim')}`);
const fb = [], ts = [];
for (let i = 0; i < F; i++) { fb.push(w('q_p') && m.peekw(w('q_p') + 2 * i)); ts.push(m.peekw(w('q_t') + 2 * i)); }
{ const want = [2]; for (let p = 3; want.length < F; p += 2) { if (!prime(BigInt(p))) continue; const r = kN % BigInt(p); if (r === 0n || powm(r, BigInt((p - 1) / 2), BigInt(p)) === 1n) want.push(p); }
  if (want.join() !== fb.join()) fail('the factor base ' + fb + ' want ' + want);
  fb.forEach((p, i) => { if (i && (ts[i] * ts[i] - Number(kN % BigInt(p))) % p !== 0) fail('root of ' + p); }); }
if (b1('q_plo') < b1('q_phi')) for (let i = b1('q_plo'); i < b1('q_phi'); i++) { const l = m.peekw(w('q_lg') + 2 * (i - b1('q_plo'))) / 256; if (Math.abs(l - Math.log2(fb[i])) > 0.02) fail('log2 of ' + fb[i] + ' is ' + l); }
// ---- the a's and their polynomials
let as = 0, polys = 0, tA = 0, tP = 0, offs = [];
const t0 = m.cycles();
const seen = new Set();
const limitA = +process.argv[5] || 3;
while (as < limitA) {
  let c = m.cycles();
  to('ov_qsv', 'qsv'); tA += m.cycles() - c; as++;
  const a = fromBytes(m.read(w('q_a'), ub));
  const qs = []; for (let i = 0; i < s; i++) qs.push(fb[m.peek(g.addr('q_qi') + i)]);
  if (qs.reduce((x, q) => x * BigInt(q), 1n) !== a) fail('a = ' + a + ' but its primes are ' + qs);
  if (new Set(qs).size !== s) fail('a prime twice: ' + qs);
  offs.push((Math.log2(Number(a)) - w('q_lgt') / 256).toFixed(2));
  const np = w('q_np'); if (np !== 1 << (s - 1)) fail('np ' + np);
  const Bs = []; for (let l = 0; l < s; l++) Bs.push(fromBytes(m.read(w('q_bl') + l * ub, ub)));
  for (let poly = 0; poly < np; poly++) {
    c = m.cycles();
    if (poly < 20) {
      // after the switch: at the filling. Stop at the sieve's scan instead: labels are local, so look when the next poly starts
    }
    to('ov_qsv', 'poly'); tP += m.cycles() - c;
    if (w('q_pi') !== poly) { if (w('q_nr') >= w('q_need')) break; fail(`poly ${w('q_pi')} want ${poly}`); }
    polys++;
    if (poly === 0 || poly % 7 === 3) {
      // (the state is that of the polynomial before, for poly > 0)
      const b = signed(m.read(w('q_b'), ub));
      if ((b * b - kN) % a !== 0n) fail(`b of poly ${poly - 1}`);
      const ab = b < 0n ? -b : b;
      for (let i = i0; i < F; i++) {
        const r = w('q_rec') + (i - i0) * rs, p = m.peekw(r), r1 = m.peekw(r + 2), r2 = m.peekw(r + 4);
        if (p !== fb[i]) fail('record p');
        if (qs.includes(p) || ts[i] === 0) { if (r1 !== 0xffff) fail('a prime of a has roots'); continue; }
        for (const x0 of [r1, r2]) { const x = BigInt(x0 - M); if (((a * x + b) ** 2n - kN) % BigInt(p) !== 0n || x0 >= p) fail(`root ${x0} of ${p} at poly ${poly - 1}`); }
        if (r1 === r2) fail('equal roots of ' + p);
      }
    }
  }
  // the relations
  const rn = w('q_rn');
  for (let e = 0; e < rn; e++) {
    const bytes = m.read(w('q_rel') + e * ub, ub); const pair = bytes[0] & 0x80; bytes[0] &= 0x7f;
    const u = fromBytes(bytes); let v = u * u - kN; if (v < 0n) v = -v;
    for (const p of fb) while (v % BigInt(p) === 0n) v /= BigInt(p);
    if (pair) { const b2 = m.read(w('q_rel') + (e + 1) * ub, ub); const u2 = fromBytes(b2); let v2 = u2 * u2 - kN; if (v2 < 0n) v2 = -v2; for (const p of fb) while (v2 % BigInt(p) === 0n) v2 /= BigInt(p); if (v !== v2 || v === 1n || v > BigInt(w('q_lp'))) fail(`pair ${v} ${v2}`); e++; } else if (v !== 1n) fail(`relation ${u}: ${v} is left`);
  }
  console.log(`a ${as}: ${qs} ${offs[as - 1]}; relations ${w('q_nr')} (${rn} entries), partial ${w('q_pn')}; a ${(tA / as / HZ).toFixed(2)} s, polynomial ${(tP / polys / HZ * 1000).toFixed(0)} ms`);
}
console.log(fails ? `${fails} FAILED` : `t_qs1 ${model} ${digits} digits ok`);
process.exit(fails ? 1 : 0);
