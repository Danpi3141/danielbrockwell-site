// Karatsuba's squares (OV_KSQ: from KS_TOP bytes, not on the smallest tier) where they are used: LLT's numbers
// against BigInt step by step, with a pause between; MODEXP of long and odd lengths; the same with too little
// room for its work (sqrp then), and the least room that takes it.
//   node tests/t_ksq.js [model]
'use strict';
const { BN, HZ, rng, fromBytes } = require('./lib');
const model = process.argv[2] || 'lz64'; const R = rng(9);
let bad = 0, n = 0; const fail = (s) => { console.log('FAIL', s); bad++; };
const pw = (a, e, q) => { let r = 1n; a %= q; for (; e; e >>= 1n) { if (e & 1n) r = r * a % q; a = a * a % q; } return r; };
const g = new BN(model).start(), m = g.m; g.wait();
if (g.peek('kv_tier') === 4) { console.log(`t_ksq ${model}: the smallest tier (no OV_KSQ)`); process.exit(0); }
const home = () => { for (let i = 0; i < 8 && !g.atLine(); i++) { g.inject('ON'); g.wait(); } };
const KSQ = g.meta.ovl.indexOf('ov_ksq') + 1, LLT = g.meta.ovl.indexOf('ov_llt') + 1;
let used = 0; const ld = g.addr('ov_load');
// run to a place in an overlay, counting OV_KSQ's loads on the way
const to = (ov, name, sec = 4000) => { const a = g.oaddr(ov, name); for (;;) { const r = m.runTo([a, ld], HZ * sec); if (r === ld) { if (m.dbg.a() === KSQ) used++; m.run(4); continue; } if (r !== a) throw new Error('never came to ' + name + '\n' + g.text()); if (g.peek('kv_res') === LLT) return; m.run(1); } };
// LLT(2281): 286 bytes; s(i) modulo 2**p - 1 at the start of steps 1, 2, 5, 12 (a pause and Continue before that one)
{
  const p = 2281n, M = (1n << p) - 1n, l = `LLT(${p})`; home(); g.wait();
  m.write(g.peekw('kv_line'), [l.length, ...[...l].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', l.length); m.poke(0x76, 13); m.run(3000);
  const sk = (k) => { let v = 4n; for (let i = 0; i < k; i++) v = (v * v - 2n) % M; return v; };
  for (const want of [1, 2, 5, 12]) {
    for (;;) {
      to('ov_llt', 'llt.loop'); const k = Number(p) - 2 - g.peekw('kv_fs', 4);
      if (k === 8) { m.run(HZ / 2); m.poke(0x76, 1); g.wait(30); if (!/Paused/.test(g.text())) fail('no pause: ' + g.text()); m.poke(0x76, 67); m.run(2000); continue; }
      if (k < want) { m.run(1); continue; }
      const got = fromBytes(m.read(g.peekw('kv_fs', 8), g.peekw('mn'))) % M; n++;
      if (got !== sk(want)) fail(`LLT(${p}) after ${want} steps (${k}): ${got.toString(16).slice(0, 30)}...`);
      m.run(1); break;
    }
  }
  m.poke(0x76, 1); g.wait(30); m.poke(0x76, 65); m.run(2000); g.wait(600); home();      // (stopped: A)
  if (!used) fail('LLT: OV_KSQ never used');
}
// MODEXP against BigInt: moduli 2**b - c of every kind of length about KS_TOP and past it (lines stay short)
const modexp = (b, c, e) => { const N = (1n << BigInt(b)) - BigInt(c), a = 3n ** BigInt(b >> 1) % N; home(); const r = g.line(`MODEXP(3**${b >> 1},${e},2**${b}-${c})`, 1e5); n++; if (r.err || r.val !== pw(a, BigInt(e), N)) fail(`MODEXP mod 2**${b}-${c}: ${r.err} ${r.val}`); };
const room = g.peekw('kv_hi') - g.peekw('kv_lo');           // (4,096 bits: an XP has room only just, and none with a variable)
for (const [b, c] of [[1529, 3], [1536, 5], [1537, 1], [1601, 7], [2048, 159], [2055, 9], [3001, 11], [4096, 3]]) if (b * 2 < room) modexp(b, c, 1000003);
// the block made smaller and smaller (the OS's free memory moved up, as t_tight does): the job always right; OV_KSQ
// while there is room for its work, sqrp after; then NO MEMORY for the job itself
{
  const ala = m.peekw(0x2040), heap = () => g.peekw('kv_hi') - g.peekw('kv_lo');
  const block = (h) => { home(); m.pokew(0x2040, ala); g.line('1'); home(); m.pokew(0x2040, ala + heap() - h); g.line('1'); home(); };
  const N = (1n << 2048n) - 159n, want = pw(3n ** 1000n % N, 1029n, N); let on = 0, off = 0, last = -1;
  for (let h = 3600; h >= 1900; h -= 50) {
    block(h); const l = 'MODEXP(3**1000,1029,2**2048-159)'; g.wait(); m.write(g.peekw('kv_line'), [l.length, ...[...l].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', l.length); m.poke(0x76, 13); m.run(3000);
    let k = 0; const idle = g.addr('t_idle'); for (;;) { const r = m.runTo([ld, idle], HZ * 1e5); if (r === idle) break; if (m.dbg.a() === KSQ) k++; m.run(4); }
    const err = g.atLine() ? g.peek('kv_err') : 0; n++;
    if (err === 7) { if (last < 0) last = h; continue; }
    if (err || g.vars()['@'] !== want) fail(`MODEXP in a block of ${h}: ${err} ${g.vars()['@']}`);
    if (k) on++; else off++; if (k && off) fail(`OV_KSQ again in ${h} after sqrp in a larger block`);
  }
  console.log(`  block 3,600 to 1,900: OV_KSQ in ${on}, sqrp in ${off}, NO MEMORY from ${last}`);
  if (!on || !off) fail('both ways not seen');
  home(); m.pokew(0x2040, ala); g.line('1'); home();
}
console.log(bad ? `${bad} FAILED` : `t_ksq ${model} ok (${n} checks, OV_KSQ read ${used} times in LLT)`);
process.exit(bad ? 1 : 0);
