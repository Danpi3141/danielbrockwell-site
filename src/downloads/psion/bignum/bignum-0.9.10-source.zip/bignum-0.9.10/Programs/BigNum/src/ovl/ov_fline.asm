; =====================================================================
; OV_FLINE: the factor fs_j on the line fs_l of the factors' screen. Entry 1: the page's factors (from fs_i:
; two on four lines, on lines 1 and 2; one on two lines), and UP and DOWN through them here, with no overlay
; read; back with any other key OV_FSHOW acts on in B (lines 0 and 3 are OV_FSHOW's and stay as they are)
; =====================================================================
        include "macros.inc"
        include "fa.inc"
        include "fs.inc"
        entry factor
        lastent page

page:   ldaa #255
        staa fs_c
        ldaa fs_i
        staa fs_j
        clr  fs_l
        tst  kv_four
        beq  .last
        inc  fs_l
        bsr  factor
        inc  fs_l
        inc  fs_j
        ldaa fs_j
        cmpa fs_n
        bne  .last
        ldaa #2                 ; (none under it: the line blank)
        bsr  ln
        bsr  out
        bra  .flsh
.last:  bsr  factor
.flsh:  tst  fs_f               ; (an S meant to skip, pressed as the job ended, is not for here: none before it can be seen)
        beq  .key
        clr  fs_f
        os   KB$FLSH
.key:   bsr  getk
        ldaa fs_i
        cmpb #K_DOWN
        bne  .up
        inca
        cmpa fs_n
        beq  .key
        bra  .go
.up:    cmpb #K_UP
        bne  .oth
        deca
        bmi  .key
.go:    staa fs_i
        bra  page
.oth:   ldx  #.ks               ; one for OV_FSHOW?
.k:     cmpb 0,x
        beq  .x
        inx
        cpx  #.ks+8
        bne  .k
        bra  .key
.x:     rts
.ks:    fcb  K_EXE,'V','P','M','C','S',K_ON,K_MODE
; factor: the factor fs_j on the line fs_l: its label, its digits and its power
factor: ldab fs_j               ; its digits first: how many there are comes from them (no OV_DIGS)
        bsr  copyf
        bsr  decimal
        ldd  dg_n
        std  kv_digs
        ldaa fs_l
        bsr  ln
        ldab fs_j
        bsr  nth
        stx  kv_ia
        ldab 0,x
        ldx  #lbl
        abx
        abx
        abx
        ldab #3
.lb:    ldaa 0,x
        cmpa #32
        beq  .ld
        bsr  putc
        inx
        decb
        bne  .lb
.ld:    ldd  kv_digs
        bsr  putw
        tst  kv_four
        bne  .four
        bsr  ecm                ; two lines: how far ECM got; which of how many, at the right
        ldab #4
        ldaa fs_n
        cmpa #10
        blo  .r5
        incb
        incb
.r5:    bsr  rcol
        ldab fs_j
        incb
        clra
        bsr  putw
        bsr  putsl
        ldab fs_n
        clra
        bsr  putwo
        bsr  ln1
        ldab kv_w
        bra  .num
.four:  bsr  putsp
        ldd  kv_p               ; the number after the label, at column 4 or later
        subd #kv_lbuf
        cmpb #4
        bhs  .fc
        ldab #4
        pshb
        bsr  col
        pulb
.fc:    negb
        addb kv_w
.num:   stab fs_w
        clr  fs_x               ; room for the power
        bsr  expo
        subd #1
        beq  .px
        ldab #2
        stab fs_x
        bsr  expo
        ldx  #tens
.pl:    subd 0,x
        bcs  .pd
        addd 0,x
        inc  fs_x
        inx
        inx
        bra  .pl
.pd:    ldab fs_w
        subb fs_x
        stab fs_w
.px:    ldab fs_w
        clra
        subd dg_n
        bcs  .cut
        ldab dg_n+1
        bsr  digs
        bra  .pw
.cut:   ldaa fs_c               ; (the first one cut)
        inca
        bne  .c2
        ldaa fs_j
        staa fs_c
.c2:    ldab fs_w
        subb #3
        bsr  digs
        ldab #3
        ldaa #'.'
.dt:    bsr  putc
        decb
        bne  .dt
.pw:    tst  fs_x
        beq  .x
        ldaa #'^'
        bsr  putc
        bsr  expo
        bsr  putw
.x:     bra  out
; expo: D = the power
expo:   ldab fs_j
        bsr  nth
        ldd  FR_E,x
        rts
tens:   fdb  10,100,1000,10000,65535
; digs: the first B digits at the pen
digs:   stab fs_w
        clra
        clrb
.l:     pshb
        bsr  dgch
        bsr  putc
        pulb
        clra
        incb
        cmpb fs_w
        bne  .l
        rts
lbl:    fcc  "U  P  PRPC  C  C  "
        include "fcopy.inc"
        include "fecm.inc"
        include "flnext.inc"
        include "dec.inc"
