; =====================================================================
; OV_TRF: trial division has found that the prime kv_pf divides the top number: divided out and into the list
; (td_x and td_e are set again after it)
; =====================================================================
        include "macros.inc"
        include "fa.inc"
        lastent found

found:  clra
        clrb
        std  kv_n               ; how many times
        bsr  tdset
.l:     ldd  kv_n
        addd #1
        std  kv_n
        ldd  kv_pf              ; divided out here, in place (OV_DIV would be two more overlays each time)
        cmpb #2                 ; (2 is the only prime with an even low byte)
        bne  .q
        bsr  half
        ldx  td_e
        dex
        ldab 0,x
        andb #1
        bra  .t
.q:     bsr  tdq
        ldd  kv_pf
        std  td_p
        bsr  tdiv
.t:     beq  .l
        bsr  fl_new
        ldd  kv_n
        std  FL_E
        ldd  kv_pf
        bsr  hpush
        ldaa #FT_P
        bra  fl_add
        include "flist.inc"
        include "tdiv.inc"
