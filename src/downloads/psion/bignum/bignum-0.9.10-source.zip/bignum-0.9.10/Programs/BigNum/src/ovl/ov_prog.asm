; =====================================================================
; OV_PROG: times and progress: an overlay on the smallest tier; on the others kept in memory, at kv_prg
; =====================================================================
        include "macros.inc"
        entry prx_pct
        entry prx_left
        entry prx_num
        entry ptt
        entry tmd
        entry prx_two
        entry prx_ln
        lastent ksq

; ksq: sqrp on the larger tiers (OV_INIT puts a jump to it at sqrp): a long number squared by OV_KSQ, if there is
; room for its work; the display brought up to date first (none is shown while OV_KSQ is in)
ksq:    ldd  mal
        subd #KS_TOP
        bcs  .s
        ldd  mal
        asld
        addd mal
        addd #KS_W
        addd kv_lim
        bcs  .s
        subd kv_wp
        bcc  .s
        bsr  poll
        ovsub OV_KSQ,0
        rts
.s:     ldx  mp
        jmp  sqrp2
; (no reference to itself but relative ones: it runs in the slot or at kv_prg, the same bytes: tools/build.py checks)
; prx_two: the rest of two lines' progress: the percentage at the pen, the line out, the time left under it
prx_two: bsr prx_num
        bsr  out
        bsr  ln1
        bsr  prx_left
        bra  out
; prx_num: the percentage at the pen
prx_num: clra
        clrb
        std  kv_n
        bsr  togo               ; (never over 100)
        ldd  kv_tot
        subd kv_na
        std  kv_n+2
        ldd  #100
        std  kv_na
        ldd  kv_tot
        std  kv_nb
        bsr  tmd
        bsr  putn
        ldaa #'%'
        bra  putc
ptt:    bra  prx_ln.pt        ; (by steps within reach)
tmd:    bra  prx_ln.tm
; togo: kv_na = the units to go (0 if there have been more than was thought)
togo:   ldd  kv_tot
        subd kv_done
        bcc  .k
        clra
        clrb
.k:     std  kv_na
        rts
; ---- progress of a run ----------------------------------------------------
; kv_done of kv_tot units are done; kv_est = the seconds the whole should take (4
; bytes; from the cost model, until some time has passed).
; prx_left: "left 5:28:00" at the pen; prx_pct: "25%  left 5:28:00" (a line of its own); pr_2: two lines,
; "Lucas 25%" having been begun at the pen of the first
prx_pct: bsr  prx_num
        bsr  putsp2
prx_left: bsr pri
        fcl  "left "
        bsr  prx_ln
        bra  prx_ln.pt
; prx_ln: kv_n = the seconds left
prx_ln: ldd  kv_el+2            ; the time this part has taken
        subd kv_e0+2
        std  kv_n+2
        ldd  kv_el
        sbcb kv_e0+1
        sbca kv_e0
        std  kv_n
        ldd  kv_done            ; (worked out when a unit is done; counted down from there until the next one)
        subd kv_ld
        beq  .same
        addd kv_ld
        std  kv_ld
        ldd  kv_el+2
        std  kv_le
.same:  ldd  kv_el+2
        subd kv_le
        pshb
        psha
        bsr  less
        ldx  kv_done            ; some done, and some time gone by: from the time it took
        cpx  #4
        blo  .est
        ldx  kv_n
        bne  .real
        ldd  kv_n+2
        subd #15
        blo  .est
.real:  ldd  kv_done
        bra  .sc
.pt:    bra  putt_
.tm:    bra  tm2
.est:   ldd  kv_est
        std  kv_n
        ldd  kv_est+2
        std  kv_n+2
        ldd  kv_tot
.sc:    std  kv_nb
        bsr  togo
        bsr  tm2
        ldd  kv_n+2             ; and the parts to come
        addd kv_ext+2
        std  kv_n+2
        ldd  kv_n
        adcb kv_ext+1
        adca kv_ext
        std  kv_n
        pula
        pulb
; less: D seconds off kv_n (not below 0)
less:   std  kv_na
        ldd  kv_n+2
        subd kv_na
        std  kv_n+2
        ldd  kv_n
        sbcb #0
        sbca #0
        bcc  .s
        clra
        clrb
        std  kv_n+2
.s:     std  kv_n
        rts
tm2:    bra  muldv_
; putt: kv_n seconds as a time: 0:09:40, 12:00:00, or 28d 2h from 100 hours
putt_:  ldaa #60
        tab
        bsr  ndiv
        staa kv_ts              ; seconds
        ldab #60
        bsr  ndiv
        staa kv_ts+1            ; minutes
        ldd  kv_n               ; hours: 100 or more: days
        bne  .days
        ldd  kv_n+2
        subd #100
        bcc  .days
        bsr  putn
        ldaa #':'
        bsr  putc
        ldaa kv_ts+1
        bsr  put2
        ldaa #':'
        bsr  putc
        ldaa kv_ts
        bra  put2
.days:  ldab #24
        bsr  ndiv
        staa kv_ts              ; hours
        bsr  putn
        ldaa #'d'
        bsr  putc
        bsr  putsp
        clra
        ldab kv_ts
        bsr  putw
        ldaa #'h'
        bra  putc
; put2: A as two digits
put2:   tab
        clra
.t:     subb #10
        bcs  .u
        inca
        bra  .t
.u:     addb #10
        adda #'0'
        bsr  putc
        tba
        adda #'0'
        bra  putc
        include "mdiv.inc"
