; =====================================================================
; OV_TRIAL: trial division. Entry 0: the top number (positive) divided by every prime up to the setting
; TDIV, each added to the list of factors; what is left stays on top (1, or a number with no small factor;
; kv_pk = 1 if it is sure to be a prime). Entry 1: TRIAL(n, limit): the smallest prime factor up to the
; limit, or 1. The primes from 7 are in a table on the pack (pt_rd); what is found is divided out here (tdq).
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        include "fa.inc"
        entry trial
        lastent f_trial
tr_l    = kv_fs+20              ; (2) the limit
tr_f    = kv_fs+22              ; 1: TRIAL(): the first one will do
f_trial: bsr  ilenw             ; the limit: 65535 at most
        bmi  tr_arg
        subd #1
        bcs  tr_arg
        beq  .b
        subd #1
        bne  .max
        ldd  2,x
        bra  .l
.b:     ldab 2,x
        clra
        bra  .l
.max:   ldd  #65535
.l:     std  tr_l
        bsr  hdrop
        ldx  kv_wp
        ldd  0,x
        beq  tr_arg
        bmi  tr_arg
        ldaa #1
        staa tr_f
        bsr  run
        bsr  hdrop
        ldd  kv_pf              ; (0: none)
        bne  .v
        incb
.v:     bra  hpush
tr_arg: bra  errarg
trial:  clr  tr_f
        ldd  st_tdiv
        std  tr_l
        ldx  #shook
        bsr  hookx
        bsr  shook
run:    clr  kv_pk
        clra
        clrb
        std  kv_pf
        ldx  kv_wp              ; the window, and the number below it
        pshx
        ldd  #PS_LEN
        bsr  walloc
        stx  ps_buf
        pulx
        bsr  hcopy
        bsr  tdset
        ldd  #2
        bsr  divs
        bne  .odd
        ldd  #2
        bsr  found
        bcs  .out
.odd:   bsr  pt_go
.l:     bsr  poll
        bsr  pt_next
        tst  ps_p
        bne  .out
        ldd  ps_p+1
        subd tr_l
        bhi  .out
        bsr  sq                 ; p squared past what is left: it is a prime (or 1)
        bcs  .prime
        ldd  ps_p+1
        std  td_p
        bsr  tdiv
        bne  .l
        ldd  ps_p+1
        bsr  found
        bcc  .l
        bra  .out
.prime: inc  kv_pk
        tst  tr_f               ; TRIAL: it may be within the limit itself
        beq  .out
        bsr  ilenw
        subd #2
        bhi  .out
        beq  .w
        ldab 2,x
        clra
        bra  .c
.w:     ldd  2,x
.c:     subd #2
        bcs  .out
        addd #2
        std  kv_al
        subd tr_l
        bhi  .out
        ldd  kv_al
        std  kv_pf
.out:   bsr  i2                 ; over the window and the number it was made from
        ldab #PS_LEN
        abx
        bsr  inext
        bra  hslx
; found: the prime D divides the number: counted, divided out, into the list. Carry set: that is all
found:  std  kv_pf
        tst  tr_f
        beq  .go
        sec
        rts
.go:    ovsub OV_TRF,0
        bsr  tdset
        clc
        rts
; divs: Z if the prime D divides the number
divs:   cmpb #2
        bne  .o
        tsta
        bne  .o
        ldx  td_e
        dex
        ldab 0,x
        andb #1
        rts
.o:     std  td_p
        bra  tdiv
; sq: carry set if ps_p+1 squared is more than the number on top
sq:     bsr  ilenw
        subd #4
        bhi  .no
        ldx  #0                 ; the number as 4 bytes, kv_n
        stx  kv_n
        stx  kv_n+2
        ldx  td_x
        stx  zx
        ldd  td_e
        subd td_x
        beq  .z
        stab zm
        ldab #4
        subb zm
        ldx  #kv_n
        abx
        stx  zp
        ldab zm
        clra
        bsr  cpb
.z:     ldd  ps_p+1
        ldx  ps_p+1
        os   UT$UMUL            ; D:X
        stx  kv_al
        std  kv_se
        ldd  kv_n+2
        subd kv_al
        ldd  kv_n
        sbcb kv_se+1
        sbca kv_se
        rts
.no:    clc
        rts
; the primes from 3 up to 65535: 3 and 5, then those in the table (a byte for each 30: a bit for each of 30 k +
; 1, 7, 11, 13, 17, 19, 23, 29 that is a prime), read a window at a time into ps_buf. ps_p: the next (ps_p
; not 0: none left); ps_lo: bytes left in the window, ps_lo+1: 30 k; ps_d: bits left, ps_d+1: which; ps_i: the
; next byte; pt_c: the next window
pt_c    = kv_fs+23             ; (TRF's records: kv_fs to +19)
pt_go:  ldab #2
        stab ps_wi
        clr  ps_d
        clr  ps_lo
        clr  pt_c
        clr  ps_p
        ldd  #-30
        std  ps_lo+1
        rts
pt_next: ldab ps_wi
        beq  .s
        dec  ps_wi
        aslb
        negb
        addb #7
        clra
        bra  .p
.s:     ldaa ps_d
        beq  .n
        inc  ps_d+1
        lsra
        staa ps_d
        bcc  .s
        ldab ps_d+1
        ldx  #pt_o-1
        abx
        ldab 0,x
        clra
        addd ps_lo+1
.p:     std  ps_p+1
        rts
.n:     ldd  ps_lo+1
        addd #30
        std  ps_lo+1
        bcc  .k
        bne  .e                 ; past 65535 (0: from -30, the first)
.k:     tst  ps_lo
        bne  .in
        bsr  pt_rd
.in:    dec  ps_lo
        ldx  ps_i
        ldaa 0,x
        inx
        stx  ps_i
        staa ps_d
        clr  ps_d+1
        bra  .s
.e:     inc  ps_p
        rts
pt_o:   fcb  1,7,11,13,17,19,23,29
; pt_rd: the next window of the table (in BNK, after its index)
pt_rd:  ldaa pt_c
        inc  pt_c
        ldab #PS_LEN
        mul
        addd #PTAB
        addd kv_bpa+1
        pshb
        psha
        ldab kv_bpa
        adcb #0
        pshb
.p:     clra
        ldab kv_dev
        os   PK$SETP
        bcc  .ok
        cmpb #194               ; the battery too low to power the pack: as ov_load (the OS has said so)
        bne  .ok                ; (another error: the pack has gone; the next overlay read says so)
        os   KB$TEST
        bra  .p
.ok:    pulb
        pulx
        os   PK$SADD
        ldx  ps_buf
        stx  ps_i
        ldd  #PS_LEN
        os   PK$READ
        ldaa #PS_LEN
        staa ps_lo
        rts
sh_t:   fcl  "Trial division.."
        include "shook.inc"
        include "tdiv.inc"
        include "pslen.inc"
