; =====================================================================
; Overlays: most of the program is read from BNK and BNL into one slot (ov_slot) when it is wanted. BNK's
; data: the kernel's part (read by the bootstrap), then the overlay area; BNL's is the same for the overlays from
; OV_2 on (two files, as none may be over 32K to be sent to an Organiser): an index of 2-byte offsets
; (one a unit, from 1), then each unit: its length, its code (assembled at ov_slot, a jump table
; first), the length of its fix-up list (1), the list; before and after each the build's number.
; =====================================================================

; ovc: call overlay entry: jsr ovc / fcb id,entry (back after the two bytes)
ovc:    pulx
        ldd  0,x
        inx
        inx
        pshx
        bra  ov_call
; ovj: the same as a jump (from one overlay to another: the entry returns to the caller of the
; overlay that jumped)
ovj:    pulx
        ldd  0,x
        bra  ov_call
; ovs: an overlay calling another (the ovsub macro): jsr ovs / fcb id,entry. The caller's number goes
; on the stack under the return to ovback.
ovs:    pulx
        ldd  0,x
        inx
        inx
        pshx                    ; the return into the calling overlay
ovs2:   std  kv_tmp             ; (id, entry)
        ldaa kv_res
        psha                    ; the caller's number
        ldx  #ovback
        pshx                    ; the callee returns to ovback
        ldd  kv_tmp
        bra  ov_call
; the callee is back: its caller read in again, B and the flags kept
ovback: stab kv_tmp
        tpa
        staa kv_tmp+1
        pula                    ; the caller's number
        bsr  ov_load
        ldab kv_tmp
        ldaa kv_tmp+1
        tap
        rts
; ovd: an overlay calling the overlay and entry in D
ovd:    bra  ovs2

; ov_call: A = overlay, B = entry
ov_call:
        pshb
        bsr  ov_load
        pulb
        ldaa #3
        mul
        addd #ov_slot
        pshb
        psha
        rts                     ; into the entry's jump

; ov_load: overlay A into the slot (unless it is there), its fix-ups added
ov_load:
        tsta                    ; (0: none: from ovback when the kernel called)
        beq  .x
        cmpa kv_res
        beq  .x
        clr  kv_res
        psha
        ldx  kv_slt
        stx  kv_fo
        psha
        clra                    ; the device
        ldab kv_dev
        os   PK$SETP
        bcs  .bad
        pula
        ldx  #kv_bpa            ; in BNK, or in BNL
        cmpa #OV_2
        blo  .one
        suba #OV_2-1
        inx
        inx
        inx
.one:   stx  kv_bs
        tab                     ; the index entry
        clra
        asld
        subd #2
        bsr  .seek
        os   PK$RWRD            ; the unit's offset
        bsr  .seek
        os   PK$RWRD            ; the build's number (another version's pack put in while this runs would do harm)
        subd #BUILD
        bne  .gone
        os   PK$RWRD            ; its length
        subd kv_slz
        bhi  .gone              ; (a pack that is not there reads as 0 or $FF)
        addd kv_slz
        beq  .gone
        ldx  kv_slt
        os   PK$READ
        os   PK$RBYT            ; the fix-ups: their length in bytes
        stab kv_cnt
; read 16 at a time (one call for them, not one a byte) onto the stack, and pulled off it (the steps' calls go
; below them); the first piece is what is over a multiple of 16
.f:     ldab kv_cnt
        beq  .done
        andb #15
        bne  .r
        ldab #16
.r:     tba
.d:     des
        decb
        bne  .d
        tsx                     ; (the top: TSX is right in Jape too, STS is not)
        tab
        clra
        os   PK$READ
.g:     pulb
        pshb
        lsrb
        lsrb
        lsrb
        lsrb
        bsr  .step
        pulb
        andb #15
        bsr  .step
        dec  kv_cnt
        ldab kv_cnt
        bitb #15
        bne  .g
        bra  .f
.done:  os   PK$RWRD            ; the number again: the pack was there to the end
        subd #BUILD
        bne  .gone
        pula
        staa kv_res
.x:     rts
.bad:   cmpb #194               ; the battery is too low to power the pack: the OS says so and switches off; and again
        bne  .gone              ; when it is on (2.4's ROMs do not look)
        os   KB$TEST
        pula
        pula
        bra  ov_load
.gone:  bsr  cls
        ldab #242               ; PACK CHANGED
        os   ER$MESS            ; (it waits for SPACE itself)
        bra  leave
; seek to the overlays (kv_bs) + D
.seek:  ldx  kv_bs
        addd 1,x
        pshb
        psha
        ldab 0,x
        adcb #0
        pulx
        os   PK$SADD
        rts
; a step: 1-15 on that far and add the base to the word there; 0 on 15
.step:  ldx  kv_fo
        tstb
        bne  .on
        ldab #15
        abx
        stx  kv_fo
        rts
.on:    abx
        stx  kv_fo
        cpx  kv_osk             ; (nothing past the block, if the pack has gone)
        bhs  .s
        ldd  0,x
        addd #entry             ; the base
        std  0,x
.s:     rts
