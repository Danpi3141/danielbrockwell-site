; =====================================================================
; OV_QS: the quadratic sieve on the number at fx_n (odd, composite, not a power, no small factors): fx_found
; = 1 and a factor on top of the stack of numbers, or 0 (it did not work out).
; Entry 0: all of it. (OV_QSA and OV_QSR are part of it: qsa, qsr.)
; =====================================================================
        include "macros.inc"
        include "ckn.inc"
        include "fx.inc"
        include "qs.inc"
        lastent qs

qs:     ldaa #3                 ; (if none of the sets gives a factor, one time in a thousand: all over again)
        staa fx_rec
        ldd  kv_wp
        std  fx_wp
.again: ldx  fx_wp
        stx  kv_wp
        clr  fx_found
        ldaa #4
        staa fx_m
        ovsub OV_QS0,0          ; the multiplier, the sizes
        bcs  .none              ; (no room)
        ldab q_f                ; (the factor base takes about q_f / 16 seconds)
        lsrb
        lsrb
        lsrb
        lsrb
        clra
        bsr  setest
        ovsub OV_QS1,0          ; the factor base, the room
        bcs  .out               ; (a factor came up: pushed)
        ovsub OV_QEST,1
        ldd  kv_n+2
        ldx  kv_n
        bsr  setest2
        ldd  q_need
        bsr  part
        clra
        clrb
        std  q_svn
        std  q_svp
        ldaa #CK_QS
        bsr  ckset
.a:     ldaa fx_job             ; FACTOR's: how long the whole will take, as it looks now
        deca
        bne  .nj
        bsr  pr_ln
        ldd  kv_n+2
        addd kv_el+2
        std  fx_js+2
        ldd  kv_n
        adcb kv_el+1
        adca kv_el
        std  fx_js
        inc  kv_full
.nj:    bsr  safe
        bsr  qsa                ; an a
        ovsub OV_QSV,0          ; all its polynomials
        ldd  q_nr
        subd q_need
        blo  .a
        ldaa q_f                ; (the combining, and a square root: about q_f squared / 512 seconds)
        tab
        mul
        tab
        lsrb
        clra
        bsr  setest
        ovsub OV_QSL,0          ; the combining
        ldd  kv_est+2           ; (a root takes half as long)
        lsrd
        std  kv_est+2
        ovsub OV_QSX,0          ; the factor
        tst  fx_found
        bne  .fin
        dec  fx_rec
        bne  .again
        bra  .none
.out:   inc  fx_found
.fin:   ldx  fx_wp
        bsr  hslx
        bra  hook0
.none:  ldx  fx_wp
        stx  kv_wp
        bra  hook0
setest: ldx  #0
setest2: stx kv_est
        std  kv_est+2
        rts
; ---- qsa: a new a for the sieve: the product of q_s primes of the base, near 2 to the q_lgt/256; the B's
; with b = the sum of +-B, b squared = kN modulo a. Goes on to OV_QSR for the records.
qa_n    = kv_fs                 ; primes chosen
qa_sum  = kv_fs+1               ; (2) their 256 log2
qa_bd   = kv_fs+3               ; (2) how near the target the last one comes
qa_bi   = kv_fs+5               ; which it is
qa_try  = kv_fs+6
qa_best = kv_fs+7               ; (2) the best of the tries
qa_c    = kv_fs+9               ; the window the primes are taken from: its first place
qa_w    = kv_fs+10              ; and its width
qa_l    = kv_fs+11
qa_x    = kv_fs+12              ; (2)
qa_m    = kv_fs+14              ; (2) a modulus
qa_y    = kv_fs+16              ; (2) a number modulo it
; ---- the primes: s-1 at random from a window, the last the one that comes nearest the target; the best of 4
qsa:    ldd  q_np               ; under a cell in four polynomials looked at: more of them are worth it (a cell takes about
        lsrd                    ; as long as a polynomial; measured on the emulator, 36 to 48 digits)
        lsrd
        subd q_cn
        bls  .enough
        ldaa q_fill
        cmpa q_fmax
        bhs  .enough
        adda #2
        staa q_fill
.enough: ldx #0
        stx  q_cn
        bsr  window
        ldd  #$FFFF
        std  qa_best
        ldaa #12
        staa qa_try
.try:   bsr  pick
        ldd  qa_bd              ; (near enough will do: only the nearest would be the same few again and again, and a long
        subd #160               ; job runs out of new ones)
        blo  .got
        ldd  qa_bd
        subd qa_best
        bhs  .nt
        ldd  qa_bd
        std  qa_best
        ldab q_s                ; kept (in the place of the g's)
        ldx  #q_qi
.kp:    ldaa 0,x
        staa 10,x
        inx
        decb
        bne  .kp
.nt:    dec  qa_try
        bne  .try
        ldab q_s
        ldx  #q_qi
.kb:    ldaa 10,x
        staa 0,x
        inx
        decb
        bne  .kb
.got:
; ---- a, and the B's: B = (a/q) g, g = t (a/q)^-1 modulo q (or q - g, if that is smaller)
        ldaa #$FF
        bsr  prod
        ldx  q_a
        bsr  tofix
        clr  qa_l
.bl:    ldab qa_l               ; (a/q) modulo q
        bsr  qval
        std  qa_m
        ldd  #1
        std  qa_y
        clrb
.pm:    cmpb qa_l
        beq  .ps
        pshb
        bsr  qval
        bsr  mulm
        pulb
.ps:    incb
        cmpb q_s
        bne  .pm
        ldx  #0                 ; its inverse: how many times it makes 1
        clra
        clrb
.iv:    inx
        addd qa_y
        subd qa_m
        bcc  .ic
        addd qa_m
.ic:    tsta
        bne  .iv
        cmpb #1
        bne  .iv
        stx  qa_y               ; times t
        ldx  #q_qi
        ldab qa_l
        abx
        ldab 0,x
        ldx  q_t
        abx
        abx
        ldd  0,x
        bsr  mulm
        ldd  qa_m               ; the smaller of g and q - g
        subd qa_y
        std  zt
        subd qa_y
        bcc  .g
        ldd  zt
        std  qa_y
.g:     ldx  #q_ga
        ldab qa_l
        aslb
        abx
        ldd  qa_y
        std  0,x
        ldaa qa_l
        bsr  prod
        ldx  #0
        stx  kv_na
        ldd  qa_y
        bsr  hmuladd
        ldab qa_l
        ldaa q_ub
        mul
        addd q_bl
        xgdx
        bsr  tofix
        inc  qa_l
        ldaa qa_l
        cmpa q_s
        bne  .bl
        ldx  q_b                ; b = the sum of the B's
        ldab q_ub
        clra
        std  mn
        bsr  clrx
        ldd  q_bl
        std  qa_x
        ldab q_s
.sb:    pshb
        ldd  q_b
        addd mn
        std  zx
        std  ze
        ldd  qa_x
        addd mn
        std  qa_x
        std  zp
        bsr  add3
        pulb
        decb
        bne  .sb
        ldx  #0                 ; the polynomials: 2 to the s-1
        stx  q_pi
        ldab q_s
        stab zt
        ldd  #1
        bra  .ne
.np:    asld
.ne:    dec  zt
        bne  .np
        std  q_np
        bra  qsr                ; the records

; window: where the primes are taken from: around the one nearest 2 to the target/s
window: ldx  q_lgt
        ldab q_s
        clra
        os   UT$UDIV            ; (X / D)
        stx  kv_al
        ldx  q_lg
        ldab q_plo
.c:     cmpb q_phi
        beq  .cd
        pshb
        ldd  0,x
        inx
        inx
        subd kv_al
        pulb
        bcc  .cd
        incb
        bra  .c
.cd:    ldaa q_s                ; its half width: s + 5, at least 8
        adda #5
        cmpa #8
        bhs  .w
        ldaa #8
.w:     staa qa_w
        subb qa_w               ; from that far below ...
        bcs  .lo
        cmpb q_plo
        bhs  .l1
.lo:    ldab q_plo
.l1:    stab qa_c
        ldaa q_phi              ; ... twice as wide, within the primes there are
        sba
        asl  qa_w
        cmpa qa_w
        bhs  .x
        staa qa_w
.x:     rts
; pick: q_qi: different primes at random from the window (with fewer than 6, the last is the nearest); qa_bd = how
; far off the target
pick:   clr  qa_n
        clra
        clrb
        std  qa_sum
.r:     bsr  rand               ; a place in the window
        ldab qa_w
        mul
        adda qa_c
        bsr  free
        beq  .r
        bsr  put
        bsr  lgof
        addd qa_sum
        std  qa_sum
        inc  qa_n
        ldaa q_s                ; all of them at random, or (few: short jobs) the last one the nearest
        cmpa #6
        bhs  .all
        deca
.all:   cmpa qa_n
        bne  .r
        ldaa q_s
        cmpa qa_n
        bne  .last
        ldd  qa_sum
        subd q_lgt
        bcc  .d
        coma
        comb
        addd #1
.d:     std  qa_bd
        rts
.last:  ldd  #$FFFF             ; the last: the nearest
        std  qa_bd
        ldaa q_plo
.n:     bsr  free
        beq  .nn
        psha
        bsr  lgof
        addd qa_sum
        subd q_lgt
        bcc  .ps
        coma
        comb
        addd #1
.ps:    std  kv_al
        subd qa_bd
        pula
        bhs  .nn
        ldx  kv_al
        stx  qa_bd
        staa qa_bi
.nn:    inca
        cmpa q_phi
        bne  .n
        ldaa qa_bi
put:    ldx  #q_qi              ; A put in (kept)
        ldab qa_n
        abx
        staa 0,x
        rts
; free: Z if the place A is taken, or its prime divides k (A kept)
free:   ldx  #q_qi
        ldab qa_n
        beq  .no
.l:     cmpa 0,x
        beq  .x
        inx
        decb
        bne  .l
.no:    ldx  q_t
        tab
        abx
        abx
        ldx  0,x
.x:     rts
; lgof: D = 256 log2 of the prime at A
lgof:   suba q_plo
        ldx  q_lg
        tab
        abx
        abx
        ldd  0,x
        rts
; rand: A = a random byte
rand:   ldx  #3                 ; (a shift register and a counter: 4 thousand million before it comes round)
.s:     ldd  q_rng
        asld
        bcc  .n
        eorb #$2D
.n:     std  q_rng
        dex
        bne  .s
        ldd  q_rng2
        addd #$9E37
        std  q_rng2
        eora q_rng+1
        rts
; qval: D = the prime numbered B of a
qval:   ldx  #q_qi
        abx
        ldab 0,x
        ldx  q_p
        abx
        abx
        ldd  0,x
        rts
; prod: the product of a's primes but for the one numbered A ($FF: all), pushed
prod:   staa qa_x
        bsr  hpush1
        clrb
.l:     cmpb qa_x
        beq  .n
        pshb
        bsr  qval
        ldx  #0
        stx  kv_na
        bsr  hmuladd
        pulb
.n:     incb
        cmpb q_s
        bne  .l
        rts
; mulm: qa_y = qa_y D modulo qa_m (D below 1,024)
mulm:   asld
        asld
        asld
        asld
        asld
        asld
        std  zp
        ldaa #10
        staa zw
        clra
        clrb
.l:     asld
        subd qa_m
        bcc  .a
        addd qa_m
.a:     asl  zp+1
        rol  zp
        bcc  .b
        addd qa_y
        subd qa_m
        bcc  .b
        addd qa_m
.b:     dec  zw
        bne  .l
        std  qa_y
        rts
; tofix: the top number (not negative) into the ub bytes at X, and dropped
tofix:  ldab q_ub
        clra
        bsr  clrx
        stx  zp
        bsr  ilenw
        pshb
        psha
        bsr  inext
        stx  zx
        pula
        pulb
        bsr  cpd
        bra  hdrop
; ---- qsr: the records of the sieve for a new a: for every sieved prime p its roots for the first b and the
; changes for the others. With h = g q^-1 modulo p for each prime q of a (so that B a^-1 = h), the changes
; are 2 h, and the roots (+-t) a^-1 less the sum of the h's, and M (the block starts at -M).
qa_p    = kv_fs                 ; (2) the prime
qa_r    = kv_fs+2               ; (2) its record
qa_i    = kv_fs+4               ; its place
qr_l    = kv_fs+5
qa_s    = kv_fs+6               ; (2) the sum of the h's
qr_x    = kv_fs+8               ; (2)
qa_v    = kv_fs+10              ; (2) the inverse of the product of the first l primes
qsr:    ldx  q_rec
        stx  qa_r
        ldab q_i0
        stab qa_i
.rec:   bsr  poll
        ldab qa_i               ; p
        ldx  q_p
        abx
        abx
        ldd  0,x
        std  qa_p
        ldx  qa_r
        std  QR_P,x
        ldx  #15                ; its log2, to the nearest
.n:     tsta
        bmi  .f
        asld
        dex
        bra  .n
.f:     asla
        cmpa #$6A               ; (the square root of 2: $B504)
        blo  .lo
        inx
.lo:    xgdx
        ldx  qa_r
        stab QR_L,x
        ldd  #$FFFF             ; not sieved by: in a, or a divisor of k
        std  QR_R1,x
        std  QR_R2,x
        ldab qa_i
        ldx  q_t
        abx
        abx
        ldd  0,x
        beq  .next
        ldx  #q_qi
        ldab q_s
        ldaa qa_i
.in:    cmpa 0,x
        beq  .next
        inx
        decb
        bne  .in
        bsr  roots
.next:  ldx  qa_r
        ldab q_rs
        abx
        stx  qa_r
        inc  qa_i
        ldaa qa_i
        cmpa q_f
        bne  .rec
        rts

; ---- one prime: with P(l) = q(0) ... q(l-1): all of them, one inverse, and back: q(l)^-1 = P(l+1)^-1 P(l).
; The P(l) are pushed on the way up.
roots:  ldd  #1
        std  qr_x
        clr  qr_l
.up:    ldx  qr_x
        pshx
        ldab qr_l
        bsr  qval
        bsr  mulq               ; qr_x = qr_x times q modulo p
        inc  qr_l
        ldaa qr_l
        cmpa q_s
        bne  .up
        bsr  inv16              ; D = the inverse of qr_x
        std  qa_v
        std  kv_al              ; (a^-1)
        clra
        clrb
        std  qa_s
.dn:    dec  qr_l
        pulx                    ; q^-1 = the inverse of P(l+1) times P(l)
        stx  qr_x
        ldd  qa_v
        bsr  mulw
        ldx  #q_ga              ; h
        ldab qr_l
        aslb
        abx
        ldd  0,x
        bsr  mulq
        ldd  qa_s
        addd qr_x
        bsr  red1
        std  qa_s
        ldab qr_l               ; the change: 2 h (none for the last B, which never changes)
        incb
        cmpb q_s
        beq  .last
        ldd  qr_x
        asld
        bsr  red1
        std  zt
        ldx  qa_r
        ldab qr_l
        aslb
        abx
        ldd  zt
        std  QR_D,x
.last:  ldx  qa_v               ; the inverse of P(l) = that of P(l+1) times q
        stx  qr_x
        ldab qr_l
        bsr  qval
        bsr  mulq
        ldx  qr_x
        stx  qa_v
        tst  qr_l
        bne  .dn
        ldab qa_i               ; t a^-1
        ldx  q_t
        abx
        abx
        ldd  0,x
        std  qr_x
        ldd  kv_al
        bsr  mulw
        ldd  q_m                ; M - the sum, modulo p
.m:     subd qa_p
        bcc  .m
        addd qa_p
        subd qa_s
        bcc  .ms
        addd qa_p
.ms:    std  qa_s
        addd qr_x
        bsr  red1
        ldx  qa_r
        std  QR_R1,x
        ldd  qa_s
        subd qr_x
        bcc  .r2
        addd qa_p
.r2:    std  QR_R2,x
        rts
; red1: D (below 2 p) modulo p
red1:   subd qa_p
        bcc  .x
        addd qa_p
.x:     rts
; mulq: qr_x = qr_x D modulo p (D below 1,024); mulw: D below 4,096
mulq:   asld
        asld
        asld
        asld
        asld
        asld
        std  zp
        ldaa #10
        bra  mulg
mulw:   asld
        asld
        asld
        asld
        std  zp
        ldaa #12
mulg:   staa zw
        clra
        clrb
.l:     asld
        subd qa_p
        bcc  .ma
        addd qa_p
.ma:    asl  zp+1
        rol  zp
        bcc  .mb
        addd qr_x
        subd qa_p
        bcc  .mb
        addd qa_p
.mb:    dec  zw
        bne  .l
        std  qr_x
        rts
; inv16: D = the inverse of qr_x modulo p
inv16:  ldd  qa_p               ; r0 = p, r1 = x, t0 = 0, t1 = 1
        std  zx
        ldd  qr_x
        std  zp
        clra
        clrb
        std  ze
        ldd  #1
        std  zt
.l:     ldd  zx                 ; r0 -= r1, t0 -= t1 (modulo p), while it goes
        subd zp
        bcs  .sw
        std  zx
        ldd  ze
        subd zt
        bcc  .p
        addd qa_p
.p:     std  ze
        bra  .l
.sw:    ldx  zx                 ; the two pairs changed over
        ldd  zp
        std  zx
        stx  zp
        ldx  ze
        ldd  zt
        std  ze
        stx  zt
        ldd  zp
        bne  .l
        ldd  ze
        rts
        include "ckset.inc"
        include "cksafe.inc"
