; =====================================================================
; BigNum - shared definitions (system variables from the technical manual: the same on the CM, XP,
; LA and LZ)
; =====================================================================
; ---- zero-page scratch (UTW_S0..S5): clobbered by most OS calls
T0      = $41
T1      = $42
T2      = $43
T3      = $44
T4      = $45
T5      = $46
T6      = $47
T7      = $48
T8      = $49
T9      = $4A
T10     = $4B
T11     = $4C
; ---- the multiply rows' own names for it (core.asm)
zm      = $41                   ; the multiplier byte
zk      = $42                   ; Montgomery's constant
zx      = $43                   ; the multiplier's bytes
zp      = $45                   ; the product
ze      = $47                   ; where the multiplier ends
zw      = $49                   ; the chunk's width
zt      = $4B
YZ      = $E2                   ; the multiplicand's chunk (the transient application area, but for $E0 and $E1: an alarm that rings on an LZ64 writes $E1, inside the tick interrupt)
WMAX    = 24
; ---- system variables and hardware
BTB_NMFL = $5B
DPB_CPOS = $62
KBB_NKYS = $74
KBB_WAIT = $76
KBB_STAT = $7B
TMB_SWOF = $7C
TMW_TOUT = $7D
FLB_RECT = $96
FLB_CPAK = $97
FLW_CREC = $9B
RTA_SP  = $A5                   ; the language stack (free RAM lies between it and ALA_FREE)
ALA_FREE = $2040
TMB_SECS = $20CA
TMW_FRAM = $20CB
TMW_TCNT = $20CD
DPB_MODE = $2184
RTB_BL   = $2187
RTT_BF   = $2188
FRC      = $0009
MODEL    = $FFE8                ; bit 3 set: four lines (LZ, LZ64)
; ---- key codes
K_ON    = 1
K_MODE  = 2
K_UP    = 3
K_DOWN  = 4
K_LEFT  = 5
K_RIGHT = 6
K_DELR  = 7
K_DEL   = 8
K_EXE   = 13
K_SPACE = 32
RESERVE = 56                   ; left to the OS for files on A: (the settings)
KS_TOP  = 192                   ; squares from so many bytes by Karatsuba's way (OV_KSQ: not on the smallest tier)
KS_W    = 64                    ; its work: 3 n + this
BIGRAM  = 11409                 ; from this much memory (with the 256 bytes OPL keeps): tiers 1 to 3
