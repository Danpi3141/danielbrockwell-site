; =====================================================================
; OV_KSQ: sqrp by Karatsuba's way, for long numbers on the larger tiers (OV_PROG's ksq comes here when there
; is room). A = H 256**k + L (L the last k bytes, H the h = n - k before them):
; A squared = H squared 256**2k + 2 H L 256**k + L squared, and 2 H L = (H + L) squared - H squared - L squared:
; three squares of half the length, each done the same way while it is long, then by sqrp. Everything it keeps
; is on the stack or in its work below the stack of numbers (a pause may read it in again).
; =====================================================================
        include "macros.inc"
        lastent ksqr

KS_CUT  = 96                    ; shorter than this: sqrp (Karatsuba's adding and taking away costs more)
ksqr:   ldx  mn                 ; (put back at the end, with the stack of numbers)
        pshx
        ldx  mb
        pshx
        ldx  ma
        pshx
        ldx  mal
        pshx
        ldx  mp
        pshx
        ldx  kv_wp
        pshx
        ldd  mal                ; the work: 3 n + KS_W bytes (OV_PROG's ksq has seen there is room)
        asld
        addd mal
        addd #KS_W
        bsr  walloc
        stx  mb
        bsr  ks
        pulx
        stx  kv_wp
        pulx
        stx  mp
        pulx
        stx  mal
        pulx
        stx  ma
        pulx
        stx  mb
        pulx
        stx  mn
        ldd  mal                ; P's end, as sqrp leaves it
        asld
        addd mp
        std  mpe
        std  mq
        rts
; ks: P (mp, 2 n bytes, a spare byte before it) = A (ma, mal = n bytes) squared; mb: free memory
ks:     ldd  mal
        subd #KS_CUT
        bcc  .k
        ldx  mp
        jmp  sqrp2
.k:     ldx  mb                 ; on the stack: h 0, k 2, A 4, n 6, P 8, F 10
        pshx
        ldx  mp
        pshx
        ldx  mal
        pshx
        ldx  ma
        pshx
        ldd  mal
        lsrd
        pshb
        psha
        ldd  mal
        tsx
        subd 0,x
        pshb
        psha
; L squared at P + 2 h (L at A + h)
        tsx
        ldd  0,x
        addd 4,x
        std  ma
        ldd  0,x
        asld
        addd 8,x
        std  mp
        ldd  2,x
        std  mal
        ldd  10,x
        std  mb
        bsr  ks
; H squared at P
        tsx
        ldd  4,x
        std  ma
        ldd  0,x
        std  mal
        ldd  8,x
        std  mp
        ldd  10,x
        std  mb
        bsr  ks
; S = H + L (h + 1 bytes) at F: a 0, H, and L added
        tsx
        ldd  4,x
        std  zx
        ldd  10,x
        addd #1
        std  zp
        ldd  0,x
        bsr  cpb
        tsx
        ldx  10,x
        clr  0,x
        tsx
        ldd  10,x
        std  zw                 ; (the carry stops at F)
        addd 0,x
        addd #1
        std  zx                 ; S's end
        ldd  4,x
        addd 6,x
        std  zp                 ; L's (A's) end
        ldd  2,x
        std  zt
        bsr  addn
; S squared at T = F + h + 2 (2 h + 2 bytes, a spare byte before it), its own work after it
        tsx
        ldd  0,x
        addd #1
        std  mal
        ldd  10,x
        std  ma
        addd mal
        addd #1
        std  mp
        addd mal
        addd mal
        std  mb
        bsr  ks
; less H squared, and L squared: 2 H L
        bsr  tend
        ldd  0,x
        asld
        std  zt
        addd 8,x
        std  zp                 ; H squared's end
        bsr  subn
        bsr  tend
        ldd  2,x
        asld
        std  zt
        ldd  6,x
        asld
        addd 8,x
        std  zp                 ; L squared's end
        bsr  subn
; added to P, k bytes up
        bsr  tend
        std  zp
        ldd  0,x
        asld
        addd #2
        std  zt
        ldd  6,x
        asld
        addd 8,x
        subd 2,x
        std  zx                 ; P + 2 n - k
        ldd  8,x
        std  zw
        bsr  addn
        ldab #12
.p:     ins
        decb
        bne  .p
        rts
; tend: zx = D = T's end (F + 3 h + 4), zw = T (F + h + 2); X the frame (as in ks, a call deeper)
tend:   tsx
        inx
        inx
        ldd  0,x
        addd #2
        addd 10,x
        std  zw
        addd 0,x
        addd 0,x
        addd #2
        std  zx
        rts
; addn: the zt bytes ending at zp added to those ending at zx (add3, with mn = zt), and the carry on up to (not
; past) zw
addn:   bsr  ready
        bsr  add3
        bcc  sx
        ldx  ze
.c:     cpx  zw
        beq  sx
        dex
        inc  0,x
        beq  .c
        rts
; subn: the same taken away (what is there is never the less)
subn:   bsr  ready
        bsr  sub3
        bcc  sx
        ldx  ze
.c:     cpx  zw
        beq  sx
        dex
        ldaa 0,x
        dec  0,x
        tsta
        beq  .c
sx:     rts
ready:  ldd  zt
        std  mn
        ldx  zx
        stx  ze
        rts
