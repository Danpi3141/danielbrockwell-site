// psion/ (the files RPLOAD sends to a real Organiser) made from build/game's pack, byte for byte: they must never
// lag a build.   node tests/t_psion.js
'use strict';
const path = require('path'), { spawnSync } = require('child_process');
const ROOT = path.join(__dirname, '..');
const r = spawnSync('python', [path.join(ROOT, 'tools', 'build.py'), '--check-psion'], { encoding: 'utf8' });
if (r.status !== 0) { console.log('FAIL', (r.stderr || r.stdout).trim()); process.exit(1); }
console.log('t_psion ok (psion/ is the pack\'s)');
