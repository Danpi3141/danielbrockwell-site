; =====================================================================
; OV_EDIT: the entry line. Entry 0: the header (or the error kv_err) and a line to type; comes back
; with the line at kv_line when EXE is pressed. Entry 1: the line goes to the lines kept for recall.
; =====================================================================
        include "macros.inc"
        lastent edit

edit:   ldd  ALA_FREE           ; what is left to A: as it should be (a file may have come or gone)
        addd #256+RESERVE
        std  RTA_SP
        std  kv_lo
        std  kv_lim
        std  kv_osp
        bsr  cls
        clr  kv_ri
        ldaa kv_err
        beq  .new
        cmpa #E_MSG
        bhs  .new
        ldaa kv_epos            ; an error: the line again, the cursor at the fault
        staa kv_cur
        bra  .go
.new:   ldx  kv_line            ; an empty line (kv_recn: what was there, for UP on the smallest tier)
        ldab 0,x
        beq  .n0
        bsr  small
        bne  .n0
        clra
        std  kv_recn
.n0:    clr  0,x
        clr  kv_cur
.go:    clr  kv_ws
        bsr  head
        ldaa kv_err             ; (text for the line, from SET)
        cmpa #E_LINE
        beq  .text
.k:     bsr  show
        bsr  getk
        cmpb #K_EXE
        beq  .exe
        cmpb #K_ON
        beq  .on
        cmpb #K_MODE
        beq  .mode
        cmpb #K_LEFT
        beq  .left
        cmpb #K_RIGHT
        beq  .right
        cmpb #K_UP
        beq  .up
        cmpb #K_DOWN
        beq  .down
        cmpb #K_DEL
        beq  .del
        cmpb #K_DELR
        beq  .delr
        cmpb #32
        blo  .k
        cmpb #126
        bhi  .k
        bsr  insch
        bra  .k
.left:  ldab kv_cur
        beq  .k
        dec  kv_cur
        bra  .k
.right: ldx  kv_line
        ldab kv_cur
        cmpb 0,x
        bhs  .k
        inc  kv_cur
        bra  .k
.del:   tst  kv_cur
        beq  .k
        dec  kv_cur
.delr:  ldx  kv_line            ; the character at the cursor goes
        ldaa 0,x
        suba kv_cur
        bls  .k
        dec  0,x
        ldab kv_cur
        abx
.dl:    ldab 2,x
        stab 1,x
        inx
        deca
        bne  .dl
        bra  .k
.up:    bsr  small
        beq  .ups
        ldaa kv_ri
        inca
        bsr  recall
        bcs  .k
        inc  kv_ri
        bra  .k
.ups:   ldx  kv_line            ; (the smallest tier: the line before, if nothing has been typed over it)
        ldaa 0,x
        bne  .k
        ldaa kv_recn+1
        staa 0,x
        staa kv_cur
        bra  .k
.down:  ldaa kv_ri
        beq  .k
        dec  kv_ri
        beq  .empty
        ldaa kv_ri
        bsr  recall
        bra  .k
.empty: ldx  kv_line
        clr  0,x
        clr  kv_cur
        bra  .k
.mode:  ovsub OV_MENU,0         ; (text to type in left in RTB_BL)
        bsr  cls
        bsr  head
.text:  ldx  #RTB_BL
        ldaa 0,x
        beq  .k
.mi:    inx
        pshx
        psha
        ldab 0,x
        bsr  insch
        pula
        pulx
        deca
        bne  .mi
        bra  .k
.on:    ldx  kv_line
        tst  0,x
        beq  .q
        clr  kv_err             ; (the header again, if there was an error)
        bra  edit
.q:
        bsr  quit
        bcs  leave
        bsr  cls
        bsr  head
        bra  .k
.exe:   ldx  kv_line
        ldab 0,x
        beq  .k
.sp:    inx                     ; (only spaces: not a line)
        ldaa 0,x
        cmpa #32
        bne  .run
        decb
        bne  .sp
        bra  .k
.run:   clr  kv_err
        bsr  small
        bne  keep
        rts
small:  ldaa kv_tier            ; Z: the smallest tier
        cmpa #4
        rts

; quit: carry set if you say so
quit:   ldaa kv_h
        suba #1
        bsr  lnpri
        fcl  "Quit? Y/N"
        bsr  out
.k:     bsr  getk
        cmpb #'Y'
        beq  .y
        cmpb #'N'
        beq  .n
        cmpb #K_ON
        bne  .k
.n:     clc
        rts
.y:     sec
        rts

; insch: B put in at the cursor, if there is room (lower case as capitals)
insch:  ldx  kv_line
        ldaa 0,x
        cmpa kv_lmax
        blo  .ok
        bra  bell
.ok:    inc  0,x
        tsta
        bne  .o2
        bsr  small
        bne  .o1
        clr  kv_recn+1          ; (typed over)
.o1:    clra
.o2:
        suba kv_cur             ; the characters after it move along
        pshb
        ldab 0,x
        abx
        tsta
        beq  .put
.mv:    dex
        ldab 0,x
        stab 1,x
        deca
        bne  .mv
.put:   pulb
        stab 0,x
        inc  kv_cur
        rts

; recall: line A (1 the newest) of those kept into the line (carry set: there is none)
recall: ldx  kv_rec
.f:     ldab 0,x
        beq  .no
        deca
        beq  .got
        inx
        abx
        bra  .f
.no:    sec
        rts
.got:   stab kv_cur             ; the cursor at its end
        pshx
        stx  zx
        ldx  kv_line
        stx  zp
        clra
        addd #1
        bsr  cpb
        pulx
        clr  kv_ws
        clc
        rts
; keep: the line into the lines kept (first; the oldest ones that no longer fit are lost)
keep:   ldx  kv_line
        ldab 0,x
        clra
        addd #1
        std  kv_al              ; its bytes
        ldx  kv_rec             ; the same as the last one? (not kept twice)
        stx  zp
        ldx  kv_line
        stx  zx
        ldaa kv_al+1
        beq  .move
.eq:    ldx  zx
        ldab 0,x
        inx
        stx  zx
        ldx  zp
        cmpb 0,x
        bne  .move
        inx
        stx  zp
        deca
        bne  .eq
        rts
.move:  ldd  kv_rec             ; the others along
        addd kv_recn
        std  zp
        subd kv_al
        std  zx
        subd kv_rec
        bsr  cpd
        ldx  kv_line
        stx  zx
        ldx  kv_rec
        stx  zp
        ldd  kv_al
        bsr  cpb
        ldx  kv_rec             ; a 0 after the last that is whole
        ldd  kv_rec
        addd kv_recn
        std  zp
.w:     ldab 0,x
        beq  .x
        stx  zx
        inx
        abx
        cpx  zp
        blo  .w
        ldx  zx
        clr  0,x
.x:     rts

; head: the header, or the error, above the line; kv_rw = the line's row
head:   bsr  ln0
        ldab kv_err
        beq  .head
        cmpb #E_MSG
        blo  .err
.head:  ldaa #1
        staa kv_rw
        cmpb #E_MSG
        bne  .big
        clr  kv_err             ; (shown once)
        ldx  #RTB_BL
        bsr  prs
        bra  .o
.big:   bsr  pri
        fcl  "BigNum "
        bsr  bits
        ldaa #'b'
        bsr  putc
        tst  kv_four
        beq  .o
        bsr  putsp2
        ldd  kv_wp              ; the free memory, in K
        subd kv_lo
        tab
        lsrb
        lsrb
        clra
        bsr  putw
        ldaa #'K'
        bsr  putc
.o:     bra  out
.err:   ldx  #msgs
.f:     decb
        beq  .m
        pshb
        ldab 0,x
        inx
        abx
        pulb
        bra  .f
.m:     bsr  prs
        bsr  out
        ldaa #1
        tst  kv_four
        beq  .r
        bsr  ln                 ; (four lines: a second line for it)
        ldab kv_err
        cmpb #E_BIG
        bne  .n
        bsr  pri
        fcl  "Limit is "
        bsr  bits
        bsr  pri
        fcl  " bits"
.n:     bsr  out
        ldaa #2
.r:     staa kv_rw
        bra  bell
bits:   ldd  kv_cap
        asld
        asld
        asld
        bra  putw

; show: the line, scrolled so that the cursor can be seen, and the cursor
show:   ldab kv_w               ; the characters shown
        decb
        stab zt
        ldab kv_cur
        cmpb kv_ws
        bhs  .r
        stab kv_ws
.r:     subb kv_ws              ; the cursor must be in the window (one past the end is)
        cmpb zt
        blo  .d
        incb
        subb zt
        addb kv_ws
        stab kv_ws
.d:     ldaa kv_rw
        bsr  ln
        ldaa #'>'
        bsr  putc
        ldx  kv_line
        ldab 0,x
        subb kv_ws
        pshb
        ldab kv_ws
        incb
        abx
        pulb
        bsr  prb
        bsr  out
        ldaa kv_rw
        ldab kv_w
        mul
        addb kv_cur
        subb kv_ws
        incb
        tba
        ldab #$81               ; the cursor on, as a line
        os   DP$STAT
        rts

msgs:   fcl  "SYNTAX"
        fcl  "TOO BIG"
        fcl  "DIV BY 0"
        fcl  "NO INVERSE"
        fcl  "BAD ARG"
        fcl  "NOT AVAILABLE"
        fcl  "NO MEMORY"
        fcl  "NOT SET"
