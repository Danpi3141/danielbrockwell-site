; =====================================================================
; OV_QS1: the sieve set up, second part: the factor base (q_f primes p and square roots of kN modulo p), the
; primes to make a's from, the sieve's threshold, the rest of the room. Carry set: a prime of the base
; divides N (pushed).
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        include "qs.inc"
        lastent qs1

qs1:    ldx  #hook
        bsr  hookx
        ldab q_f
        clra
        bsr  part
        ldx  q_p                ; 2
        ldd  #2
        std  0,x
        ldx  q_t
        ldd  #1
        std  0,x
        ldd  #PS_LEN            ; (the room of the relations to come)
        ldx  kv_wp
        stx  kv_fs
        bsr  walloc
        stx  ps_buf
        clr  kv_fs+2            ; the index
        inc  kv_fs+2
        clrb
        ldx  #3
        bsr  ps_go
.p:     bsr  poll
        bsr  ps_next
        bsr  rem                ; kN modulo p
        std  kv_fs+4
        bne  .sq
        ldd  ps_p+1             ; p divides kN: k, or N?
        tsta
        bne  .fac
        ldaa q_k
.mk:    sba                     ; k modulo p
        bcs  .fac
        bne  .mk
        ldd  #0
        bra  .add
.fac:   ldd  ps_p+1             ; a factor
        bsr  hpush
        sec
        rts
; a square root: x squared, for x = 1, 2, ... up to (p-1)/2
.sq:    clra
        clrb
        std  zp                 ; x
        std  zt                 ; its square modulo p
.x:     ldd  zp                 ; + 2 x + 1
        asld
        addd #1
        addd zt
.m:     subd ps_p+1
        bcc  .m
        addd ps_p+1
        std  zt
        ldx  zp
        inx
        stx  zp
        subd kv_fs+4
        beq  .got
        ldd  zp
        asld
        subd ps_p+1
        bcs  .x
        bra  .p                 ; none
.got:   ldd  zp
.add:   std  zt
        ldab kv_fs+2
        ldx  q_t
        abx
        abx
        ldd  zt
        std  0,x
        ldab kv_fs+2
        ldx  q_p
        abx
        abx
        ldd  ps_p+1
        std  0,x
        ldx  kv_done
        inx
        stx  kv_done
        inc  kv_fs+2
        ldab kv_fs+2
        cmpb q_f
        bne  .p
        ldx  kv_fs
        stx  kv_wp
; the first prime sieved by; the primes for a's: from Q_ALOW, Q_POOL of them at most
        ldx  q_p
        clrb
.i0:    tst  0,x
        bne  .i1
        ldaa 1,x
        cmpa #Q_SMALL
        bhs  .i1
        inx
        inx
        incb
        bra  .i0
.i1:    stab q_i0
        ldaa q_f
        cmpa #Q_FEW
        blo  .i3
.i2:    tst  0,x
        bne  .i3
        ldaa 1,x
        cmpa #Q_ALOW
        bhs  .i3
        inx
        inx
        incb
        bra  .i2
.i3:    stab q_plo
        stab q_phi
        stx  kv_fs+6
        ldx  q_lg
        stx  kv_fs+8
.lg:    ldab q_phi              ; q_lg: 256 log2(p) for each
        cmpb q_f
        beq  .hi
        subb q_plo
        cmpb #Q_POOL
        beq  .hi
        ldx  kv_fs+6
        ldd  0,x
        inx
        inx
        stx  kv_fs+6
        bsr  log2
        ldx  kv_fs+8
        std  0,x
        inx
        inx
        stx  kv_fs+8
        inc  q_phi
        bra  .lg
.hi:
; ---- the threshold: log2(M sqrt(kN/2)) less the slack, less the large prime's bits
        ldd  q_bits
        lsrd
        addb q_lm
        subb #18                ; the slack without a large prime
        ldx  q_lp
        beq  .nolp
        ldab q_f                ; with one: up to 15 times the largest prime
        decb
        ldx  q_p
        abx
        abx
        ldd  0,x
        ldx  #15
        os   UT$UMUL
        stx  q_lp
        xgdx
        bsr  log2
        tab                     ; its bits
        inca
        staa zm
        ldx  q_bits             ; the slack: 13, or 11 from 80 to 109 bits
        ldab #13
        cpx  #80
        blo  .sl
        cpx  #110
        bhs  .sl
        ldab #11
.sl:    addb zm
        stab zm
        ldd  q_bits
        lsrd
        addb q_lm
        subb zm
.nolp:  negb                    ; a cell starts at 128 less it
        addb #128
        stab q_fill
        addb #16                ; (OV_QSA raises it so far, with a large prime, if few cells come to 128)
        cmpb #120
        bls  .fm
        ldab #120
.fm:    ldx  q_lp
        bne  .fm2
        clrb
.fm2:   stab q_fmax
        ldx  #0
        stx  q_np
        ldab q_f                ; relations wanted: 10 more than the primes
        clra
        addd #10
        std  q_need
; ---- the room, downwards: the relations (what is left over), the records, the sieve; QW_LEN below them
; for the numbers worked with
        ldd  kv_wp
        std  q_pe               ; the relations' room ends here
        std  q_pa
        ldab q_f
        subb q_i0
        ldaa q_rs
        mul
        addd q_svz
        addd #QW_LEN
        addd kv_lim
        std  q_rel
        ldd  kv_lim
        addd #QW_LEN
        std  q_sv
        std  kv_wp
        addd q_svz
        std  q_rec
        ldd  q_rel
        std  q_rece
        clra
        clrb
        std  q_rn
        std  q_pn
        std  q_nr
        ldd  TMW_FRAM           ; the random state
        std  q_rng2
        orab #1
        std  q_rng
        clc
        rts

; rem: D = kN modulo ps_p+1
rem:    ldx  q_kn
        stx  zx
        ldab q_ub
        aslb
        stab zt
        clra
        clrb
.l:     ldx  zx
        pshb
        ldab 0,x
        stab zm
        pulb
        inx
        stx  zx
        ldx  #8
.b:     asl  zm
        rolb
        rola
        subd ps_p+1
        bcc  .n
        addd ps_p+1
.n:     dex
        bne  .b
        dec  zt
        bne  .l
        rts
; log2: D = 256 log2(D) (D not 0)
log2:   ldx  #15                ; the top bit up to bit 15
.n:     tsta
        bmi  .f
        asld
        dex
        bra  .n
.f:     std  kv_al
        stx  kv_se              ; the whole part
        ldaa #8
        staa kv_cnt
        clr  kv_cy
.b:     ldd  kv_al              ; squared: 2 or more: a 1
        ldx  kv_al
        os   UT$UMUL            ; (D the high word)
        tsta
        bmi  .one
        asld
        stx  kv_ia
        asl  kv_ia
        adcb #0
        clc
        bra  .r
.one:   sec
.r:     rol  kv_cy
        std  kv_al
        dec  kv_cnt
        bne  .b
        ldaa kv_se+1
        ldab kv_cy
        rts
hk_l:   bsr  pri
        fcl  "Primes "
        ldd  kv_done
        bsr  putw
        bsr  putsl
        ldd  kv_tot
        bra  putw
hk_q:   bsr  pri
        fcl  "QS primes"
        rts
        include "mhook.inc"
hk_3    = pr_pct
        include "psn.inc"
