; =====================================================================
; OV_SHOW: the result of a line: entry 0 keeps the top number in ANS (and the variable of P=...) and
; shows it. Entry 1: the top number in the pager (it is used up). Entry 2: a variable is asked for and
; the top number kept in it (V on a result screen).
; =====================================================================
        include "macros.inc"
        entry show
        entry pager
        entry askvar
        entry vagain
        entry num
        lastent vst

vst:    ldab kv_dst
        bra  vstore
show:   ldab kv_dst
        beq  .ans
        bsr  vstore
.ans:   ldab #'@'
        bsr  vstore
        bsr  beepend
        ldaa kv_tier
        cmpa #4
        beq  .nl
        ldaa kv_ckw             ; (what was kept of it is not wanted any more)
        beq  .ck
        ovsub OV_KEEP,2
.ck:    ldaa st_log             ; the log
        beq  .nl
        ovsub OV_LOG,0
.nl:
        ldab kv_rk              ; a screen of its own?
        beq  num
        decb
        beq  num
        ldaa kv_rk              ; (kv_rk is the overlay that shows it)
        clrb
        bra  ov_call
num:    bsr  runon              ; (a long one takes a while)
        bsr  decimal
        clr  kv_run
        ldaa #1
        staa pg_v
        ldaa kv_h               ; will it fit under the line?
        deca
        ldab kv_w
        stab pg_w
        mul
        std  zt
        bsr  chars
        subd zt
        bhi  pages
; the line, and the number under it
        bsr  cls
        bsr  echo
        ldx  #0
        stx  pg_i
        ldaa #1
.r:     bsr  row
        cmpa kv_h
        bne  .r
        ldab kv_rk
        beq  .k
        ldaa kv_h               ; SIZE: the bits as well
        deca
        bsr  ln
        ldab #9                 ; (four digits' room)
        bsr  rcol
        ldd  kv_bits
        bsr  putwp
        fcl  " bits"
        bsr  out
.k:     bsr  getk
        bsr  vkey
        bcs  num
        cmpb #K_EXE
        beq  .x
        cmpb #K_ON
        beq  .x
        cmpb #K_MODE
        bne  .k
.x:     rts
pager:  bsr  runon
        bsr  decimal
        clr  kv_run
        ldaa #2
        staa pg_v
pages:  ovjump OV_PAGE,0
        include "row.inc"

        include "echo.inc"

; the pager's V key: the number asked for and kept, then shown again
vagain: ldab #'V'
        bsr  vkey
        bra  num
; ---- variables ------------------------------------------------------------
; vkey: V and then a letter: the result kept in that variable: carry set (the screen to be drawn again)
vkey:   cmpb #'V'
        beq  .v
        clc
        rts
.v:     bsr  toans
askvar: ldaa kv_h
        deca
        bsr  lnpri
        fcl  "Store in A-Z?"
        bsr  out
.k:     bsr  getk
        cmpb #K_ON
        beq  .x
        cmpb #'A'
        blo  .k
        cmpb #'Z'
        bhi  .k
        bsr  vstore
.x:     sec
        rts
; toans: the stack of numbers holds ANS again and nothing else
toans:  ldx  kv_vb
        stx  kv_wp
        ldx  kv_lo
        stx  kv_lim
        ldx  kv_vb              ; (ANS is the variable kept last, but look for it)
.f:     cpx  kv_hi
        beq  .x
        ldab 0,x
        inx
        cmpb #'@'
        beq  hcopy
        bsr  inext
        bra  .f
.x:     rts
; vstore: the top number kept as the variable B
vstore: stab zm
        pshb
        ldx  kv_vb              ; the old one taken out
.f:     cpx  kv_hi
        beq  .new
        ldab 0,x
        cmpb zm
        beq  .old
        inx
        bsr  inext
        bra  .f
.old:   stx  zx
        pshx
        inx
        bsr  inext
        stx  zp
        pula
        pulb
        pshb
        psha
        std  zt
        ldd  zp
        subd zt                 ; its bytes
        std  kv_se
        ldd  zt
        subd kv_wp              ; those below it
        std  kv_al
        pulx
        stx  zx
        ldd  kv_wp
        addd kv_se
        std  kv_wp
        ldd  kv_vb
        addd kv_se
        std  kv_vb
        ldd  kv_al
        bsr  cpd
.new:   bsr  ilenw              ; room for the new one: the numbers on the stack move down
        addd #3
        std  kv_se
        ldd  kv_vb
        subd kv_wp
        std  kv_al
        ldd  kv_wp
        std  zx
        subd kv_se
        bcs  nomem
        std  zp
        subd kv_lim
        bcs  nomem
        ldd  zp
        std  kv_wp
        ldd  kv_vb
        subd kv_se
        std  kv_vb
        ldd  kv_al
        bsr  cpb
        ldx  kv_vb
        pulb
        stab 0,x
        inx
        stx  zp
        ldx  kv_wp
        stx  zx
        ldd  kv_se
        subd #1
        bra  cpb

; beepend: a beep when a run of over a minute ends
beepend: tst  st_beep
        beq  .x
        ldx  kv_el
        bne  .b
        ldd  kv_el+2
        subd #60
        blo  .x
.b:     bra  bell
.x:     rts
        include "dec.inc"
