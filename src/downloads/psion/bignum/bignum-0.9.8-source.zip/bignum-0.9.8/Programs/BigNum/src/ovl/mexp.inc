; mexp: slot 0 = slot 1 to the power of the item at mx_e (positive), by windows of mx_w bits (4, with
; slots 1 to 8 for the odd powers and 9 spare; or 1, with slot 1 only). kv_done, kv_tot count its bits.
mx_e    = kv_fs                 ; the exponent
mx_i    = kv_fs+2               ; the bit to do next (the lowest is 0), plus 1
mx_w    = kv_fs+4
mx_v    = kv_fs+5               ; a window's value
mx_n    = kv_fs+6               ; its bits
mx_s    = kv_fs+7               ; slot 0 has nothing in it yet
mexp:   ldx  mx_e               ; its bits
        bsr  ilen
        subd #1
        asld
        asld
        asld
        std  mx_i
        ldab 2,x
        clra
.b:     inca
        lsrb
        bne  .b
        tab
        clra
        addd mx_i
        std  mx_i
        std  kv_tot
        ldd  #0
        std  kv_done
        ldaa #1
        staa mx_s
        ldaa mx_w
        deca
        beq  .l
        bsr  mrun               ; the odd powers
        mo    M_SQR,9,1,1
        mo    M_MUL,2,1,9
        mo    M_MUL,3,2,9
        mo    M_MUL,4,3,9
        mo    M_MUL,5,4,9
        mo    M_MUL,6,5,9
        mo    M_MUL,7,6,9
        mol   M_MUL,8,7,9
        bsr  mx_set
.l:     bsr  mx_safe
        ldd  mx_i
        beq  .x
        subd #1
        bsr  ebit
        bne  .win
        ldd  mx_i               ; a 0: a square
        subd #1
        std  mx_i
        bsr  msq1
        bra  .l
.x:     rts
.win:   clr  mx_v               ; a window: from a 1 down to a 1, at most mx_w bits
        clr  mx_n
.w:     ldab mx_n               ; the bit mx_n on
        clra
        addd #1
        std  zt
        ldd  mx_i
        subd zt
        bcs  .wd
        bsr  ebit
        asl  mx_v
        tstb
        beq  .w0
        inc  mx_v
.w0:    inc  mx_n
        ldaa mx_n
        cmpa mx_w
        bne  .w
.wd:    ldab mx_v               ; the zeros at its end taken off
        lsrb
        bcs  .ok
        stab mx_v
        dec  mx_n
        bra  .wd
.ok:    ldab mx_n
        clra
        std  zt
        ldd  mx_i
        subd zt
        std  mx_i
.sq:    bsr  msq1
        dec  mx_n
        bne  .sq
        ldab mx_v               ; times the odd power
        lsrb
        incb
        stab mi+1
        clr  mi
        clr  mi+2
        ldab #M_MUL
        tst  mx_s
        beq  .m
        clr  mx_s
        ldab #M_CPY
.m:     bsr  mop
        bra  .l
; slot 0 squared (nothing yet: left)
msq1:   ldx  kv_done
        inx
        stx  kv_done
        tst  mx_s
        bne  .x
        ldx  #0
        stx  mi
        clr  mi+2
        ldab #M_SQR
        bra  mop
.x:     rts
        include "ebit.inc"
