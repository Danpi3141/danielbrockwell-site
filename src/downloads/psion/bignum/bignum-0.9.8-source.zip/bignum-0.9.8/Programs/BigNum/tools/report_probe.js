// Measures what docs/report.html shows: the memory of a running BigNum, where the time goes, the screens.
//   node tools/report_probe.js <part>     (maps | sieve <digits> | profile <model> <line> <from s> <for s> | screens <model>)
// Each prints JSON (tools/report.js runs them all into build/report/).
'use strict';
const { BN, HZ } = require('../tests/lib');
const typed = (g, t) => { g.wait(); g.m.write(g.peekw('kv_line'), [t.length, ...[...t].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', t.length); g.inject('EXE'); };
const part = process.argv[2], A = process.argv.slice(3);
const N48 = '495679895743617608625155398465450525066555623863';
// where everything is, now
function map(g) {
  const w = (n) => g.peekw(n), m = g.m;
  const o = { tier: g.peek('kv_tier'), base: g.base, slot: g.addr('ov_slot'), vars: g.addr('kv_vars'), end: w('kv_osk'), lo: w('kv_lo'), lim: w('kv_lim'), wp: w('kv_wp'), vb: w('kv_vb'), hi: w('kv_hi'),
    et: w('kv_et'), line: w('kv_line'), lmax: g.peek('kv_lmax'), rec: w('kv_rec'), recn: w('kv_recn'), slz: w('kv_slz'), boot: w('kv_boot'), alafree: m.peekw(0x2040), rtasp: m.peekw(0xA5), sp: m.dbg.sp(),
    ksp: w('kv_sp'), res: g.meta.ovl[g.peek('kv_res') - 1], cells: [] };
  // (the allocator's cells: a table of addresses from $2000; $2040 is the free space's)
  for (let a = 0x2000; a <= 0x2040; a += 2) o.cells.push(m.peekw(a));
  return o;
}
if (part === 'maps') {
  const out = {};
  for (const mo of ['cm', 'xp', 'la', 'lz', 'lz64']) {
    const g = new BN(mo); const free = g.free(); const fp = [g.m.peekw(0xA5), g.m.peekw(0x2040)];
    g.start(); g.wait(); const a = map(g);
    g.line('A=2**2047+1919'); for (let i = 0; i < 4 && !g.atLine(); i++) { g.inject('ON'); g.wait(); }
    const b = map(g);
    typed(g, 'ISPRIME(A)'); g.run(60); g.m.runTo([g.addr('poll')], HZ * 5);
    out[mo] = { free, menu: fp, start: a, var: b, prime: map(g), mn: g.peekw('mn'), ms: g.peekw('ms'), mp: g.peekw('mp'), text: g.lines() };
  }
  console.log(JSON.stringify(out));
} else if (part === 'sieve') {
  const [mo, n, secs] = [A[0], A[1] === '48' ? N48 : A[1], +A[2]];
  const g = new BN(mo).start(); typed(g, `QS(${n})`); g.run(secs); g.m.runTo([g.addr('poll')], HZ * 5);
  const q = {}; for (const k of Object.keys(g.sym)) if (/^q_/.test(k)) { const b = /^q_(k|s|f|ub|i0|rs|lm|fill|fmax|plo|phi)$/.test(k); q[k] = b ? g.peek(k) : g.peekw(k); }
  console.log(JSON.stringify({ mo, n, map: map(g), q, text: g.lines() }));
} else if (part === 'profile') {
  const [mo, line, from, len] = [A[0], A[1], +A[2], +A[3]];
  const g = new BN(mo).start(), m = g.m, d = m.dbg; typed(g, line);
  for (let i = 0; i < 100000 && from < 0 && !/Relations|QS \d/.test(g.text()); i++) g.run(1);
  g.run(Math.abs(from));
  const ks = Object.entries(g.sym).filter(([n, v]) => v[1] === 'rel' && v[0] < g.sym.kv_vars[0] && !/^t_|^mr_|^rr_/.test(n)).map(([n, v]) => [v[0], n]).sort((a, b) => a[0] - b[0]);
  const os = {}; for (const [u, s] of Object.entries(g.osym)) os[u] = Object.entries(s).filter(([, v]) => v[1] === 'rel').map(([n, v]) => [v[0], n]).sort((a, b) => a[0] - b[0]);
  const find = (t, off) => { let r = '?'; for (const [a, n] of t) { if (a > off) break; r = n; } return r; };
  const cnt = {}, slot = g.sym.ov_slot[0], vars = g.sym.kv_vars[0], prg = g.sym.kv_prg[0]; let tot = 0; const c0 = m.cycles(), end = c0 + len * HZ;
  let seed = 12345; const et = g.peekw('kv_et'), hi2 = g.peekw('kv_rec') || 0xFFFF;
  while (m.cycles() < end) {
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    m.run(400 + seed % 700); tot++;
    const pc = d.pc(), off = pc - g.base; let k;
    if (pc >= 0x8000) k = 'OS'; else if (off >= 0 && off < vars) k = 'kernel ' + find(ks, off);
    else if (off >= slot && off < prg) { const r = g.meta.ovl[g.peek('kv_res') - 1]; k = r ? r + ' ' + find(os[r] || [], off) : 'loading'; }
    else if (pc >= et && pc < et + 700 && pc < hi2 + 2000) k = 'rows'; else k = 'other';
    cnt[k] = (cnt[k] || 0) + 1;
  }
  const r = Object.entries(cnt).sort((a, b) => b[1] - a[1]).map(([k, v]) => [k, +(100 * v / tot).toFixed(2)]);
  console.log(JSON.stringify({ mo, line, text: g.lines(), tot, r }));
} else if (part === 'screens') {
  const mo = A[0], out = [];
  const g = new BN(mo).start(); const snap = (name, note) => out.push({ name, note, t: g.lines() });
  const home = () => { for (let i = 0; i < 8 && !g.atLine(); i++) { g.inject('ON'); g.wait(); } };
  const put = (t) => { g.wait(); g.m.write(g.peekw('kv_line'), [t.length, ...[...t].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', t.length); g.inject('LEFT'); g.wait(); };
  const run = (t, ...steps) => {            // steps: [seconds, name, note]
    home(); typed(g, t); for (const [s, name, note] of steps) { if (s === 0) g.wait(1e6); else g.run(s); snap(name, note); }
  };
  const stopit = () => { g.m.poke(0x76, 1); for (let i = 0; i < 60 && !/Paused/.test(g.text()); i++) g.run(0.25); };
  const abandon = () => { g.run(0.5); g.m.poke(0x76, 65); g.run(1); g.wait(60); home(); };
  const until = (re, sec) => { for (let i = 0; i < sec * 2 && !re.test(g.text()); i++) g.run(0.5); };
  g.wait(); snap('start', 'Ready');
  put('FACTOR(2**64+1)'); snap('typed', 'A line typed'); g.inject('ON'); g.wait();
  run('2**127-1', [0, 'value', 'A value']);
  run('FACT(60)', [0, 'long', 'A longer one']);
  run('2**521-1', [0, 'longer', 'Too long for the screen: EXE for the pager']); g.inject('EXE'); g.wait(); snap('pager', 'The pager');
  home(); g.inject('MODE'); g.run(1); snap('menu', 'The menu (MODE)'); g.m.poke(0x76, 1); g.run(1); g.wait();
  home(); typed(g, 'SET'); g.wait(); snap('set', 'SET'); home();
  run('ISPRIME(2**521-1)', [30, 'prp', 'A primality test under way']); g.wait(1e6); snap('isprime', 'ISPRIME(2**521-1)');
  run('PROVE(2**127-1)', [4, 'proving', 'A proof under way']); g.wait(1e6); snap('proved', 'PROVE(2**127-1)'); g.inject('C'); g.wait(); snap('cert', 'C: the certificate');
  run('FACTOR(2**101-1)', [0.5, 'f0', '']); let last = '';
  for (let i = 0; i < 2000; i++) { if (g.m.runTo([g.addr('t_idle')], HZ / 2) === g.addr('t_idle')) break; const t = g.lines(); const h = t.join('|').replace(/[\d:%]+/g, '#'); if (h !== last) { last = h; out.push({ name: 'fac', note: '', t, s: g.peekw('kv_el', 2) }); } }
  snap('factors', 'FACTOR(2**101-1)'); if (g.four) { g.inject('M'); g.wait(); snap('how', 'M: how it was found'); }
  home(); typed(g, 'QS(353890612479965357292787308697)'); until(/Relations +[2-9]\d|QS +[2-9]\d\//, 300); snap('qs', 'The sieve');
  stopit(); snap('pause', 'ON/CLEAR: paused'); abandon();
  typed(g, 'ECM((2**61-1)*(10**20+39),2)'); until(/urve|ECM L/, 100); g.run(20); snap('ecm', 'ECM'); stopit(); abandon();
  typed(g, 'BENCH'); g.wait(1e4); snap('bench', 'BENCH'); home();
  typed(g, 'VARS'); g.wait(); snap('vars', 'VARS'); home();
  typed(g, 'MODINV(6,9)'); g.wait(); snap('error', 'An error: the cursor is at it');
  console.log(JSON.stringify({ mo, out }));
}
