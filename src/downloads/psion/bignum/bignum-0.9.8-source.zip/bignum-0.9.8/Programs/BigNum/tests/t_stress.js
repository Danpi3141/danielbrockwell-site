// Random lines and keys: after each, the kernel's code must be as it was, the block's pointers in order and the
// variables whole.   node tests/t_stress.js [model] [seed] [minutes of Organiser time]
'use strict';
const { BN, HZ, rng } = require('./lib');
const model = process.argv[2] || 'lz64', seed = +process.argv[3] || 1, mins = +process.argv[4] || 60;
const R = rng(seed); const pick = (a) => a[R.int(a.length)];
const g = new BN(model, /^cm/.test(model) ? {} : { packC: { type: 1, size: 32 } }).start(), m = g.m;
let small = g.peek('kv_tier') === 4;
let idle = g.addr('t_idle');
let code = null; const ex = new Set(); const hist = [];
const kcode = () => m.read(g.base, g.sym.kv_vars[0]);
const learn = () => { const c = kcode(); if (code) { for (let i = 0; i < c.length; i++) if (c[i] !== code[i]) ex.add(i); } code = c; };
// the bytes that change by themselves (patched instructions) are learnt from quiet work first
const learnAll = () => { g.poke('st_log', 0); learn();     // (a full log has an error after each result)
  for (const l of ['FACT(60)*FACT(50)', 'FACTOR(2**64+1)', 'ISPRIME(2**127-1)', '10**60/7', small ? '1' : 'QS(10007*1000003)']) { g.line(l, 1e5); g.wait(); learn(); } };
learnAll();
const fail = (s) => { console.log(`FAIL ${model} seed ${seed}: ${s}\n${g.text()}\nlast: ${hist.slice(-25).join(' ~ ')}`); process.exit(1); };
const check = () => {
  const c = kcode(); for (let i = 0; i < c.length; i++) if (c[i] !== code[i] && !ex.has(i)) fail(`code changed at ${i.toString(16)}`);
  const [lo, lim, wp, vb, hi] = ['kv_lo', 'kv_lim', 'kv_wp', 'kv_vb', 'kv_hi'].map((n) => g.peekw(n));
  if (!(lo <= lim && lim <= wp && wp <= vb && vb <= hi)) fail(`pointers ${[lo, lim, wp, vb, hi].map((x) => x.toString(16))}`);
  if (m.peekw(0xA5) > lo || m.peekw(0x2040) > m.peekw(0xA5)) fail(`memory ${m.peekw(0x2040).toString(16)} ${m.peekw(0xA5).toString(16)} ${lo.toString(16)}`);
  let a = vb, n = 0;
  while (a < hi) { const l = m.peek(a); if (!(l === 64 || (l >= 65 && l <= 90))) fail('a variable ' + l); a += 3 + (m.peekw(a + 1) & 0x7fff); if (++n > 40) fail('variables'); }
  if (a !== hi) fail('variables run over');
  const odd = m.cells().find((v) => (v >= 8 && v < 32) || v > 126); if (odd !== undefined) fail('a strange character: ' + odd);
};
const num = () => pick([() => String(R.int(10)), () => String(R.int(100000)), () => String(R.bits(64)), () => String(R.bits(120)), () => pick(['A', 'B', 'C', 'P', 'ANS', 'Q']), () => `2**${R.int(300)}`, () => `10**${R.int(60)}`, () => `(${expr(1)})`, () => '-' + R.int(50)])();
const fns = [['GCD', 2], ['LCM', 2], ['MOD', 2], ['SQRT', 1], ['NROOT', 2], ['ABS', 1], ['SIZE', 1], ['MODEXP', 3], ['MODINV', 2], ['MODSQRT', 2], ['CRT', 4], ['JACOBI', 2], ['ISPRIME', 1], ['NEXTPRIME', 1], ['PREVPRIME', 1], ['LLT', 1], ['FACTOR', 1], ['TRIAL', 2], ['RHO', 1], ['PM1', 1], ['PP1', 1], ['ECM', 2], ['QS', 1], ['PHI', 1], ['TAU', 1], ['SIGMA', 1], ['FACT', 1], ['PRIMORIAL', 1], ['FIB', 1], ['LUC', 1], ['BINOM', 2], ['PROVE', 1]];
const call = () => { const [f, n] = pick(fns); const k = R.int(20) ? n : R.int(5); return `${f}(${Array.from({ length: k }, num).join(',')})`; };
const expr = (d = 0) => { let s = R.int(3) ? num() : d > 1 ? num() : call(); for (let i = R.int(3); i > 0; i--) s += pick(['+', '-', '*', '/', '%', '**', '*']) + (R.int(4) ? num() : call()); return s; };
const cmds = ['VARS', 'CLR', 'CLR A', 'SET', 'SET TDIV 500', 'SET TDIV 10000', 'SET PROOF ON', 'SET PROOF OFF', 'SET BEEP OFF', 'SET ECMB1 100', 'SET ECMB1 AUTO', 'SET RHOIT 500', 'SET RHOIT AUTO', 'SET LOG C:', 'SET LOG A', 'SET LOG OFF', 'SET KEEP C:', 'SET KEEP OFF', 'SET EVERY 1', 'HELP', 'LOG', 'RESUME', 'SAVE A,"NUM"', 'SAVE ANS,"C:XY"', 'LOAD B,"NUM"', 'LOAD C,"C:XY"', 'BENCH', 'SET FOO', 'SAVE', 'LOAD Z,"ZZ"', 'HELLO'];
const keys = ['EXE', 'ON', 'UP', 'DOWN', 'LEFT', 'RIGHT', 'DEL', 'DELR', 'V', 'P', 'C', 'A', 'M', 'S', 'N', 'EXE', 'ON', '1', '(', 'K', 'E'];
const CODE = { EXE: 13, ON: 1, MODE: 2, UP: 3, DOWN: 4, LEFT: 5, RIGHT: 6, DELR: 7, DEL: 8 };
let lines = 0, presses = 0, pauses = 0, quits = 0;
const put = (k) => { hist.push(k); m.poke(0x76, CODE[k] || k.charCodeAt(0)); m.run(3000); presses++; };
const space = () => /space/i.test(g.text());
// wait for a key wait; long work is paused and given up, or skipped
const settle = (sec) => {
  for (let i = 0; i < 400; i++) {
    const r = m.runTo([idle], HZ * sec); if (r === idle) return;
    if (/TRAP/.test(g.text())) fail('TRAP');
    if (space()) { g.press('SPACE'); g.run(0.5); continue; }
    if (/Insert/.test(g.text())) { g.press('ON'); g.run(0.5); continue; }
    if (!g.peek('kv_run')) { g.run(1); if (!g.text().trim()) { hist.push('WOKE'); g.press('ON'); g.run(1); } continue; }   // (switched off by itself)
    const k = R.int(6) ? 'ON' : 'S'; put(k);
    if (m.runTo([idle], HZ * 20) === idle) { if (/Paused/.test(g.text())) { pauses++; put(pick(['A', 'C', 'S', 'A', 'A', 'K'])); } } else if (k === 'ON' && g.peek('kv_run') && !space()) fail('no pause');
  }
  fail('never waits for a key');
};
const home = () => { for (let i = 0; i < 14 && !g.atLine(); i++) { put(/Paused/.test(g.text()) ? 'A' : 'ON'); settle(20); } if (!g.atLine()) fail('not back at the line'); if (/Quit/.test(g.text())) { put('N'); settle(5); } };
const t0 = m.cycles();
while ((m.cycles() - t0) / HZ < mins * 60) {
  const w = R.int(10);
  if (w < 6) {
    const l = (R.int(8) ? (R.int(5) ? expr() : `${pick('ABCPQ')}=${expr()}`) : pick(cmds)).slice(0, small ? 127 : 250);
    home();
    m.write(g.peekw('kv_line'), [l.length, ...[...l].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', l.length); put('EXE'); hist.push(l); lines++; settle(pick([3, 20, 90]));
  } else if (w < 9) { if (/Quit/.test(g.text())) put('N'); else put(pick(keys)); settle(30); }
  else if (R.int(3) === 0) {
    home(); put('ON'); settle(5); if (!/Quit/.test(g.text())) { put('ON'); settle(5); }
    if (/Quit/.test(g.text())) {
      hist.push('QUIT'); m.poke(0x76, 89); m.run(HZ * 2); quits++;
      if (m.peekw(0xA5) < g.base) fail('did not leave');
      g.start(); g.wait(); idle = g.addr('t_idle'); small = g.peek('kv_tier') === 4; code = null; ex.clear(); learnAll();
    }
  } else { home(); hist.push('MODE'); m.poke(0x76, 2); g.run(1); const p = pick(['I', 'V', 'S', 'B', 'L', 'R', 'ON']); hist.push(p); g.press(p); g.run(1); settle(40); }
  check();
}
console.log(`t_stress ${model} seed ${seed}: ${lines} lines, ${presses} keys, ${pauses} pauses, ${quits} times left: ok`);
