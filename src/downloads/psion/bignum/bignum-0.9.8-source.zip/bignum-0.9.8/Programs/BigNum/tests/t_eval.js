// Lines worked out, against BigInt: random expressions, precedence, errors and where they point.
//   node tests/t_eval.js [model] [seed] [count]
'use strict';
const { BN, rng } = require('./lib');
const model = process.argv[2] || 'lz64';
const R = rng(+process.argv[3] || 1);
const g = new BN(model).start();
let fails = 0;
const fail = (s) => { console.log('FAIL', s); if (++fails > 12) process.exit(1); };
const cap = g.peekw('kv_cap') * 8;
const fdivE = (a, b) => { let r = a % b; if (r < 0n) r += b < 0n ? -b : b; return [(a - r) / b, r]; };
const chk = (t, want) => { const r = g.line(t); if (r.err || r.val !== want) fail(`${t}: got ${r.err ? 'error ' + r.err + ' at ' + r.pos : r.val} want ${want}`); return r; };
const bad = (t, e, pos) => { const r = g.line(t); if (r.err !== e || (pos !== undefined && r.pos !== pos)) fail(`${t}: got error ${r.err} at ${r.pos} value ${r.val}, want error ${e} at ${pos}`); };
// fixed
chk('1+2*3', 7n); chk('2**3**2', 512n); chk('-2**2', -4n); chk('(-2)**3', -8n); chk('(-2)**4', 16n); chk('7/2', 3n); chk('-7/2', -4n); chk('-7%2', 1n); chk('7/-2', -3n); chk('7%-2', 1n); chk('-7/-2', 4n); chk('-7%-2', 1n);
chk('2-3-4', -5n); chk('100/7/2', 7n); chk('100/(7/2)', 33n); chk('2*-3', -6n); chk('--5', 5n); chk('+5', 5n); chk('((((1))))', 1n); chk(' 1 + 2 ', 3n); chk('0**0', 1n); chk('0**5', 0n); chk('1**99999999999', 1n); chk('(-1)**99999999999', -1n); chk('(-1)**99999999998', 1n);
chk('2**127-1', 2n ** 127n - 1n); chk('10**50', 10n ** 50n); chk('3**100', 3n ** 100n); chk('(2**64)**3', 2n ** 192n); chk('(-8)**5', -(8n ** 5n)); chk('(-16)**6', 16n ** 6n); chk('000123', 123n); chk('123456789012345678901234567890', 123456789012345678901234567890n);
chk('A=5', 5n); chk('B=A*A+1', 26n); chk('A*B', 130n); chk('ANS+1', 131n); chk('A=A+1', 6n); chk('a+b', 32n); chk('Z=ANS', 32n); chk('A=2**200', 2n ** 200n); chk('A/B', 2n ** 200n / 26n); chk('MOD(-7,3)', 2n); chk('MOD(2**100,97)+1', 2n ** 100n % 97n + 1n); chk('mod(9,4)', 1n);
// errors
bad('1+', 1, 2); bad('1+*2', 1, 2); bad('(1+2', 1, 4); bad('1+2)', 1, 3); bad('FOO(1)', 1, 0); bad('1 2', 1, 2); bad('MOD(1)', 1); bad('MOD(1,2,3)', 1); bad('1,2', 1, 1); bad('()', 1, 1); bad('MOD 3', 1, 0); bad('1/0', 3, 1); bad('1%(5-5)', 3, 1); bad('X+1', 8, 0); bad('2**-1', 5, 1); bad('A=', 1); bad('=5', 1, 0); bad('1#2', 1, 1); bad('2+AB', 1, 2); bad('A B', 1); bad('1..2', 1, 1);
bad(`2**${cap}`, 2, 1); chk(`2**${cap - 1}`, 2n ** BigInt(cap - 1)); bad('3**99999', 2, 1); bad('3**999999999999', 2, 1); bad(`(2**${cap / 2})*(2**${cap / 2})`, 2); chk(`(2**${cap / 2}-1)*(2**${cap / 2}-1)`, (2n ** BigInt(cap / 2) - 1n) ** 2n); chk(`2**${cap - 1}-1+2**${cap - 1}`, 2n ** BigInt(cap) - 1n); bad(`2**${cap - 1}+2**${cap - 1}`, 2);
// random expressions
const N = +process.argv[4] || 250;
const gen = (d) => {
  if (d === 0 || R.int(5) === 0) { const v = R.bits([1, 8, 16, 17, 40, 100, 200][R.int(7)]); return [String(v), v, 9]; }
  const k = R.int(9);
  if (k === 7) { const [t, v, p] = gen(d - 1); return [p < 8 ? '-(' + t + ')' : '-' + t, -v, 3]; }
  if (k === 8) { const b = R.bits(12), e = BigInt(R.int(20)); return [`${b}**${e}`, b ** e, 4]; }
  const a = gen(d - 1), b = gen(d - 1);
  const sh = (x, min) => (x[2] < min ? '(' + x[0] + ')' : x[0]);
  if (k < 2) return [sh(a, 1) + '+' + sh(b, 2), a[1] + b[1], 1];
  if (k < 4) return [sh(a, 1) + '-' + sh(b, 2), a[1] - b[1], 1];
  if (k < 5) return [sh(a, 2) + '*' + sh(b, 3), a[1] * b[1], 2];
  if (b[1] === 0n) return [sh(a, 1) + '+' + sh(b, 2), a[1] + b[1], 1];
  const [q, r] = fdivE(a[1], b[1]);
  return k === 5 ? [sh(a, 2) + '/' + sh(b, 3), q, 2] : [sh(a, 2) + '%' + sh(b, 3), r, 2];
};
let done = 0;
for (let i = 0; i < N; i++) {
  const [t, v] = gen(3);
  if (t.length > 120 || v.toString(2).length > cap) continue;
  const r = g.line(t);
  if (r.err === 2) continue;                     // an intermediate past the cap
  if (r.err || r.val !== v) fail(`${t}: got ${r.err ? 'error ' + r.err + ' at ' + r.pos : r.val} want ${v}`);
  done++;
}
// division at all sizes, (A/B)*B+A%B = A
for (let i = 0; i < 120; i++) {
  const na = 1 + R.int(i < 60 ? 12 : 70), nb = 1 + R.int(i < 60 ? 6 : 60);
  let a = R.bits(8 * na), b = R.bits(8 * nb) >> BigInt(R.int(8));
  if (R.int(4) === 0) a = (1n << BigInt(8 * na)) - 1n - R.bits(8); if (R.int(4) === 0) b = (1n << BigInt(8 * nb - 1)) + R.bits(8); if (R.int(6) === 0) b = (1n << BigInt(8 * nb)) - 1n;
  if (R.int(4) === 0 && b) a = b * (a / b) - BigInt(R.int(2)); if (a < 0n) a = -a;
  if (R.int(2)) a = -a; if (R.int(2)) b = -b; if (b === 0n) b = 3n;
  g.clear(); g.push(a); g.push(b);
  const [q, r] = fdivE(a, b);
  g.call('ov_call', { a: g.meta.ovl.indexOf('ov_div') + 1, b: 2 });
  const s = g.stack();
  if (s[0] !== q || s[1] !== r || s.length !== 2) fail(`${a} / ${b}: got ${s} want ${q},${r}`);
}
g.clear();
console.log(fails ? `${fails} FAILED` : `t_eval ${model} ok (${done} random lines)`);
process.exit(fails ? 1 : 0);
