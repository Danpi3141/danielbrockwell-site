// How many curves a factor of so many digits needs: node ecmcount.js digits B1 pairs seed
'use strict';
const { curveFinds, powm } = require('./ecm');
const { rng } = require('../tests/lib');
const [d, b1, n, seed] = process.argv.slice(2).map(Number);
const R = rng(seed * 7919 + d * 31 + b1);
const prime = (v) => { for (const p of [2n, 3n, 5n, 7n, 11n, 13n, 17n, 19n, 23n, 29n, 31n, 37n]) if (v % p === 0n) return v === p; let e = v - 1n, s = 0; while (!(e & 1n)) { e >>= 1n; s++; } next: for (const a of [2n, 3n, 5n, 7n, 11n, 13n, 17n]) { let x = powm(a, e, v); if (x === 1n || x === v - 1n) continue; for (let i = 1; i < s; i++) { x = x * x % v; if (x === v - 1n) continue next; } return false; } return true; };
const lo = 10n ** BigInt(d - 1), hi = 10n ** BigInt(d);
let s1 = 0, s2 = 0;
for (let i = 0; i < n; i++) { let p; do { p = lo + R.bits(96) % (hi - lo) | 1n; } while (!prime(p)); const r = curveFinds(p, 1000 * (1 + i % 4) + 5 + R.int(300) + 1, b1); if (r === 1) s1++; else if (r === 2) s2++; }
console.log(d, b1, n, s1, s2);
