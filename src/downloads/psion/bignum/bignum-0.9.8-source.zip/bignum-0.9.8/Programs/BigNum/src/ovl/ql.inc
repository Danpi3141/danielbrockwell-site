; the combining's variables
ql_n    = kv_fy                 ; rows
ql_rb   = kv_fy+1               ; a row's bytes
ql_m    = kv_fy+2               ; (2) the rows
ql_piv  = kv_fy+4               ; (2) each column's pivot row (255 none)
ql_use  = kv_fy+6               ; (2) each row: 0 free, 1 a pivot, 2 no good, 3 tried
ql_cb   = kv_fy+8               ; a column's byte
ql_cm   = kv_fy+9               ; and bit
