import re,sys
rows=[]
for fn in ('sweep1.txt','sweep2.txt','sweep3.txt'):
    for l in open('twin/'+fn):
        m=re.match(r'(\d+)d F=(\d+) M=(\d+) slack=(\S+) lp=(\d+) .*?avg ([\d.]+)(s|m|h|d).*?ok (\d+)/(\d+)',l)
        if not m: continue
        rows.append((int(m[1]),int(m[2]),int(m[3]),m[4],int(m[5]),float(m[6])*{'s':1,'m':60,'h':3600,'d':86400}[m[7]],int(m[8])/int(m[9])))
def t(v): return '%.0fs'%v if v<120 else '%.1fm'%(v/60) if v<7200 else '%.1fh'%(v/3600) if v<172800 else '%.1fd'%(v/86400)
for lo,hi,name in ((1,32,'F<=32'),(33,48,'F 48'),(49,64,'F 64'),(65,96,'F 80-96'),(97,152,'F 128-152'),(153,176,'F 160-176'),(177,240,'F 192-240')):
    print(name)
    for d in sorted({r[0] for r in rows}):
        c=sorted((r for r in rows if r[0]==d and lo<=r[1]<=hi and r[6]>=0.99),key=lambda r:r[5])[:2]
        if c: print('  %dd '%d+' | '.join('F%d M%d s%s lp%d %s'%(r[1],r[2],r[3],r[4],t(r[5])) for r in c))
