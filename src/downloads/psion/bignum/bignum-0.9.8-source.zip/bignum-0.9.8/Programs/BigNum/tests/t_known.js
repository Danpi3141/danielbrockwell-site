// The spec's known answers on a model, then random numbers factored (checked by their product and primality).
//   node tests/t_known.js [model] [random numbers] [seed] [most digits]
'use strict';
const { BN, HZ, rng } = require('./lib');
const model = process.argv[2] || 'lz64', nr = +(process.argv[3] || 10), seed = +(process.argv[4] || 1), md = +(process.argv[5] || 30);
const g = new BN(model).start(), m = g.m, small = g.peek('kv_tier') === 4;
let bad = 0; const fail = (s) => { console.log(`${model} FAIL ${s}`); bad++; };
const powm = (b, e, p) => { let r = 1n; b %= p; while (e) { if (e & 1n) r = r * b % p; b = b * b % p; e >>= 1n; } return r; };
const prime = (v) => { if (v < 2n) return false; for (const p of [2n, 3n, 5n, 7n, 11n, 13n, 17n, 19n, 23n, 29n, 31n, 37n]) if (v % p === 0n) return v === p; let d = v - 1n, s = 0; while (!(d & 1n)) { d >>= 1n; s++; } next: for (const a of [2n, 3n, 5n, 7n, 11n, 13n, 17n, 19n]) { let x = powm(a, d, v); if (x === 1n || x === v - 1n) continue; for (let i = 1; i < s; i++) { x = x * x % v; if (x === v - 1n) continue next; } return false; } return true; };
const list = () => { const r = []; let a = g.peekw('kv_rl'); const e = g.peekw('kv_lim'); while (a < e) { r.push([m.peek(a), m.peekw(a + 1), g.item(a + 20)]); a += 22 + (m.peekw(a + 20) & 0x7fff); } return r; };
const T = (r) => (r.cycles / HZ).toFixed(0) + ' s';
const val = (l, v) => { const r = g.line(l, 1e7); if (r.err || r.val !== v) fail(`${l}: ${r.err} ${r.val}`); else console.log(`${model} ${l} ${T(r)}`); };
const fac = (l, f) => { const r = g.line(l, 1e7); const s = list().map(([, e, v]) => e > 1 ? `${v}^${e}` : `${v}`).join(' '); if (r.err || s !== f) fail(`${l}: ${r.err} ${s}`); else console.log(`${model} ${l} ${T(r)} ${r.screen[0].trim()} ${r.screen[1].trim()}`); };
if (seed < 100) {
  val('2**127-1', 170141183460469231731687303715884105727n);
  fac('FACTOR(2**64+1)', '274177 67280421310721'); fac('FACTOR(2**67-1)', '193707721 761838257287'); fac('FACTOR(10**30+1)', '61 101 3541 9901 27961 4188901 39526741');
  fac('FACTOR(FACT(25)+1)', '401 38681321803817920159601'); fac('FACTOR(FACT(30))', '2^26 3^14 5^7 7^4 11^2 13^2 17 19 23 29');
  if (!small) { fac('FACTOR(2**101-1)', '7432339208719 341117531003194129'); fac('FACTOR(2**128+1)', '59649589127497217 5704689200685129054721'); }
  fac('FACTOR((10**15+37)**2)', '1000000000000037^2'); fac('FACTOR(7**40)', '7^40');
  val('ISPRIME(10**50+151)', 1n); val('NEXTPRIME(10**20)', 100000000000000000039n); val('NEXTPRIME(10**30)', 1000000000000000000000000000057n); val('PROVE(2**127-1)', 1n); val('PROVE(10**30+57)', 1n); val('LLT(127)', 1n); val('LLT(521)', 1n); val('LLT(131)', 0n);
  const c = small ? 1023n : 4095n; val(`(2**${c}-1)*(2**${c}-1)`, ((1n << c) - 1n) ** 2n);
  const R = rng(99); for (let i = 0; i < 4; i++) { let a = R.bits(300) * (i & 1 ? -1n : 1n), b = R.bits(90) * (i & 2 ? -1n : 1n); g.line(`A=${a}`); g.line(`B=${b}`); val('(A/B)*B+A%B-A', 0n); }
}
const R = rng(seed * 31 + 7);
for (let i = 0; i < nr; i++) {
  const d = 10 + R.int((small ? Math.min(md, 20) : md) - 9); const N = 10n ** BigInt(d - 1) + R.bits(d * 4) % (9n * 10n ** BigInt(d - 1));
  const r = g.line(`FACTOR(${N})`, 1e7); const f = list();
  let p = 1n; for (const [t, e, v] of f) { p *= v ** BigInt(e); if (t !== 1 && t !== 2) fail(`${N}: type ${t}`); if (!prime(v)) fail(`${N}: ${v} not prime`); }
  if (r.err || p !== N) fail(`${N}: ${r.err} product ${p}`); else console.log(`${model} ${d} digits ${N} = ${f.map(([, e, v]) => e > 1 ? `${v}^${e}` : v).join(' ')} ${T(r)}`);
}
console.log(bad ? `${bad} FAILED` : `t_known ${model} ok`);
process.exit(bad ? 1 : 0);
