; share: D = how much of the time has gone, of q_need. With a large prime the relations come slowly at first, then
; faster as the partial ones pair off: r of n of them take r + (n - r) / 9, or 1.6 r while that is less (as measured,
; 50 whole jobs: within 8% on average from a fifth of the way on)
share:  ldd  q_nr
        ldx  q_lp
        beq  .x
        ldaa #154
        mul
        staa zt
        ldd  q_need
        subd q_nr
        bls  .all
        ldaa #28
        mul
        cmpa zt
        bls  .s
        ldaa zt
.s:     tab
        clra
        addd q_nr
.x:     rts
.all:   ldd  q_need
        rts
