; =====================================================================
; OV_FSHOW: the factors (the list at kv_rl, smallest first). Four lines: the line typed, two factors a page
; and how many; two lines: one a page. UP and DOWN go through them, EXE opens one too long for its line in the
; pager, V keeps the first one shown in a variable, P proves a probable prime, S adds the result to the log on a device that
; is asked for (not on the smallest tier).
; =====================================================================
        include "macros.inc"
        include "fa.inc"
        include "fs.inc"
        include "pv.inc"
        entry fshow
        lastent again

fshow:  clr  fs_i
        ldaa #1
        staa fs_f
again:  clr  fs_n
        clr  fs_p
        ldx  kv_rl
.n:     cpx  kv_lim
        beq  .d
        inc  fs_n
        ldaa 0,x
        cmpa #FT_TRIED
        bne  .nt
        ldaa #FT_PRP
        staa 0,x
.nt:    cmpa #FT_PRP
        bne  .np
        inc  fs_p
.np:    bsr  fl_next
        bra  .n
.d:     tst  fs_n
        bne  draw
        ovjump OV_SHOW,4        ; (1 has none: the plain number)
draw:   bsr  cls
        ldaa #255
        staa fs_c
        ldaa fs_i
        staa fs_j
        clr  fs_l
        tst  kv_four
        beq  .two
        bsr  strip              ; what was factored
        bsr  echot
        inc  fs_l
        bsr  fline
        inc  fs_l
        inc  fs_j
        ldaa fs_j
        cmpa fs_n
        beq  .last
        bsr  fline
.last:  bsr  foot
        bra  .keys
.two:   bsr  fline
.keys:  tst  fs_f               ; (an S meant to skip, pressed as the job ended, is not for here: none before it can be seen)
        beq  .key
        clr  fs_f
        os   KB$FLSH
.key:   bsr  getk
        cmpb #K_DOWN
        beq  .down
        cmpb #K_UP
        beq  .up
        cmpb #K_EXE
        beq  .exe
        cmpb #'V'
        beq  .v
        cmpb #'P'
        beq  .p
        cmpb #'M'
        beq  .m
        cmpb #'C'
        beq  .c
        cmpb #'S'
        beq  .s
        cmpb #K_ON
        beq  .x
        cmpb #K_MODE
        bne  .keys
.x:     rts
.down:  ldaa fs_i
        inca
        cmpa fs_n
        beq  .keys
        staa fs_i
        bra  draw
.up:    tst  fs_i
        beq  .keys
        dec  fs_i
        bra  draw
.exe:   ldab fs_c               ; one too long for its line: the pager; else back to the line
        cmpb #255
        beq  .x
        bsr  copyf
        ovsub OV_SHOW,1
        bra  draw
.v:     ldab fs_i
        bsr  copyf
        ovsub OV_SHOW,2
        bra  draw
.p:     tst  fs_p
        beq  .keys
        ovjump OV_PROVE,1
.c:     ldab fs_i               ; the certificate of the first one shown, if it is a prime past 2**64 and proved: the
        bsr  nth                ; proof is made again
        ldaa 0,x
        deca
        bne  .keys2
        stx  pv_rec
        ldab #FR_N
        abx
        bsr  ilen
        subd #8
        bls  .keys2
        ovjump OV_PROVE,5
.keys2: bra  .keys
.s:     ldaa kv_tier
        cmpa #4
        beq  .keys2
        ldd  kv_lim             ; memory for it? (a factor, its digits and a record; with none the result would be lost)
        subd kv_rl
        std  zt
        asld
        addd zt
        addd #300
        addd kv_lim
        bcs  .nm
        subd kv_vb
        bls  .dev
.nm:    ldaa kv_h
        deca
        bsr  lnpri
        fcl  "NO MEMORY"
        bsr  out
        bsr  getk
        bra  draw
.dev:
        ldaa kv_h               ; which device?
        deca
        bsr  lnpri
        fcl  "Save on A, B, C?"
        bsr  out
        bsr  getk
        subb #'A'-1
        bls  draw
        cmpb #3
        bhi  draw
        pshb
        ldx  kv_vb              ; (a number on top: OV_LOG looks at its length)
        stx  kv_wp
        bsr  hpush1
        pulb
        ldaa fs_i               ; (OV_LOG's variables are in the same place)
        psha
        ldaa st_log             ; its device for now
        psha
        stab st_log
        ovsub OV_LOG,0
        ldab st_log
        pula
        staa st_log
        pula
        staa fs_i
        ldaa #0
        staa fs_f
        bcs  again              ; (an error: the OS has said it)
        pshb
        ldaa kv_h
        deca
        bsr  lnpri
        fcl  "Saved: "
        pula
        adda #'A'-1
        bsr  putc
        bsr  pri
        fcl  ":BIGLOG"
        bsr  out
        bsr  getk
        bra  again
.m:     ldab fs_i               ; how the first one shown was found, until a key
        bsr  nth
        stx  kv_ia
        ldaa kv_h
        deca
        bsr  ln
        ldx  kv_ia
        ldab FR_M,x
        bsr  method
        ldx  kv_ia
        ldd  FR_S,x
        beq  .m2
        pshb
        psha
        bsr  pri
        fcl  " s="
        pula
        pulb
        bsr  putw
.m2:    bsr  out
        bsr  getk
        bra  draw
        include "fcopy.inc"
fline:  ovsub OV_FLINE,0
        rts
; foot: how many factors, and the time (or how far ECM got, or that one is only probably prime)
foot:   ldaa #3
        bsr  ln
        ldab fs_n
        clra
        bsr  putwp
        fcl  " factor"
        ldaa fs_n
        deca
        beq  .s1
        ldaa #'s'
        bsr  putc
.s1:    ldx  kv_rl
.g:     cpx  kv_lim
        beq  .t
        ldaa 0,x
        cmpa #FT_GAVE
        beq  .ecm
        bsr  fl_next
        bra  .g
.ecm:   stx  kv_ia
        bsr  ecm
        bra  out
.t:     tst  fs_p               ; "1 factor   PRP  10s" or "2 factors  0:00:20"
        beq  .t2
        ldab #11
        bsr  col
        bsr  pri
        fcl  "PRP  "
        ldd  kv_el
        std  kv_n
        bne  .t3
        ldd  kv_el+2
        std  kv_n+2
        subd #1000
        bcc  .t3
        bsr  putn
        ldaa #'s'
        bsr  putc
        bra  out
.t2:    bsr  putsp2
.t3:    ldd  kv_el
        std  kv_n
        ldd  kv_el+2
        std  kv_n+2
        bsr  putt
        bra  out
        include "fecm.inc"
        include "flnext.inc"
        include "method.inc"
        include "strip.inc"
        include "echo.inc"
