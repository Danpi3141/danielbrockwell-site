; FACTOR's own variables (kv_fz)
fa_rec  = kv_fz                 ; (2) the record being worked on
fa_st   = kv_fz+2               ; the method: 0 rho 1 P-1 2 P+1 3 ECM 4 the sieve 5 none left
fa_wp   = kv_fz+3               ; (2) the stack of numbers
fa_bud  = kv_fz+5               ; (4) seconds left to the methods before the sieve
fa_lim  = kv_fz+9               ; 1: that limit counts (the sieve comes after)
fa_dg   = kv_fz+10              ; (2) the whole number's digits
fa_t0   = kv_fz+12              ; (2) the time a method began (low word)
fa_m    = kv_fz+14              ; 1: called by FACTOR itself: its screen is to be shown
