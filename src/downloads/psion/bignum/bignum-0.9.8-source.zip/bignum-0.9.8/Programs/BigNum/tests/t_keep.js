// KEEP and RESUME: each line stopped part way with K (more than once), resumed in a fresh start of the program, and its
// result compared with the line's own value.   node tests/t_keep.js [model] [which regex] [device]
'use strict';
const { BN, HZ } = require('./lib');
const model = process.argv[2] || 'lz64', re = new RegExp(process.argv[3] || '.'), dev = process.argv[4] || 'C';
let bad = 0; const fail = (s) => { console.log('FAIL', s); bad++; };
// line, value, seconds before each K
const J = [
  ['ISPRIME(2**521-1)', 1n, [40, 60, 40]],                                  // base 2, then Lucas
  ['MODEXP(3,2**521-2,2**521-1)', 1n, [20, 25]],
  ['LLT(521)', 1n, [10, 12]],
  ['MODEXP(3,2**521-2,2**521-1)+4*MODEXP(5,2**521-3,2**521-1)', null, [40, 130]],        // (the second one's state must not go into the first)
  ['LLT(521)+LLT(607)', 2n, [20, 60]],
  ['RHO(10000019*(10**24+7))', null, [15, 20]],
  ['PM1((2**89-1)*(10**20+39))', null, [15, 40, 60]],
  ['PP1((2**89-1)*(10**20+39))', null, [15, 40, 60]],
  ['ECM((2**61-1)*(10**20+39),2)', 1n, [25, 120, 200]],
  ['QS(353890612479965357292787308697)', null, [60, 40]],
  ['FACTOR(2**101-1)', 7432339208719n, [30, 60, 100]],
  ['1+FACTOR(10**25+7)*A', null, [10, 20]],
  ['PHI(2**101-1)', null, [60]],
];
const typed = (g, t) => { g.wait(); g.m.write(g.peekw('kv_line'), [t.length, ...[...t].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', t.length); g.inject('EXE'); };
const key = (g, k) => { g.m.poke(0x76, k === 'ON' ? 1 : k.charCodeAt(0)); g.m.run(HZ * 2); };
for (const [line, want, secs] of J) {
  if (!re.test(line)) continue;
  const g = new BN(model, { packC: { type: 1, size: 32 } }).start();
  g.line('A=10**30+57');
  let ref = want;
  if (ref === null) { const r = g.line(line, 1e6); ref = r.val; }
  g.line('SET KEEP ' + dev + ':');
  typed(g, line);
  let ok = true, log = [];
  for (const s of secs) {
    g.run(s);
    key(g, 'ON');
    for (let i = 0; i < 4 && /Paused/.test(g.text()) && !/K/.test(g.text().replace(/BREAK|OK/g, '')); i++) { key(g, 'C'); g.run(12); key(g, 'ON'); }   // (a short step: nothing to keep)
    if (!/Paused/.test(g.text())) { log.push('finished before ' + s); break; }
    if (!/K/.test(g.text())) { fail(`${line}: no K: ${g.text()}`); ok = false; break; }
    log.push(g.lines()[g.four ? 0 : 1].replace('Paused: ', '').trim());
    key(g, 'K');
    g.wait(600);
    if (!g.atLine() && !/factor|C\d/.test(g.text())) { log.push('finished first'); break; }
    if (false) { fail(`${line}: after K: ${g.text()}`); ok = false; break; }
    for (let i = 0; i < 5 && !g.atLine(); i++) { g.inject('ON'); g.wait(); }
    g.line('A=5');                                          // (its variables come out of the file)
    for (let i = 0; i < 5 && !g.atLine(); i++) { g.inject('ON'); g.wait(); }
    typed(g, 'RESUME'); g.wait();
    if (!/Resume\? Y\/N/.test(g.text())) { fail(`${line}: RESUME: ${g.text()}`); ok = false; break; }
    g.inject('Y');
  }
  if (!ok) continue;
  g.wait(1e6);
  const v = g.vars()['@'];
  if (v !== ref && !(/QS|RHO/.test(line) && ref > 1n && v > 1n && BigInt(line.match(/\d{20,}/) ? line.match(/\d{20,}/)[0] : 0) % v === 0n)) fail(`${line}: ${v} want ${ref}\n${g.text()}`);
  console.log(`${line}: [${log.join(' | ')}] ${String(v).slice(0, 30)}`);
}
console.log(bad ? `${bad} FAILED` : 't_keep ok');
process.exit(bad ? 1 : 0);
