; =====================================================================
; Text: every line is made up in kv_lbuf (so nothing ever runs past the edge) and printed whole by
; the OS, which keeps its own copy for when the Organiser is switched off and on.
; =====================================================================

clsf:   clr  kv_full            ; (everything has been drawn)
cls:    ldaa #12
emit:   os   DP$EMIT
        rts

; ln: A = a line: the line's buffer blank, the pen at its start
ln2:    ldaa #2                 ; (lines 2, 1 and 0: cpx and cmpa swallow the next one's load)
        fcb  $8C
ln1:    ldaa #1
        fcb  $81
ln0:    clra
ln:     staa kv_ln
        ldx  #kv_lbuf
        stx  kv_p
        ldaa #32
        ldab #20
        os   UT$FILL
        rts
; col: the pen to column B
col:    ldx  #kv_lbuf
        abx
        stx  kv_p
        rts
; rcol: the pen to where B characters end at the right edge
rcol:   negb
        addb kv_w
        bra  col
; putwo: putw's; putsp2: two spaces
putsp2: bsr  putsp
        bra  putsp
putwo:  bsr  putw
        bra  out
; putc: A at the pen (dropped past the edge); A, B, X kept
putsl:  ldaa #'/'               ; (a stroke; a space)
        fcb  $8C
putsp:  ldaa #32
putc:   pshx
        ldx  kv_p
        cpx  kv_pe
        beq  .x
        staa 0,x
        inx
        stx  kv_p
.x:     pulx
        rts
; pdig: D and the word digits; putwp: D, then the text after the call
pdig:   bsr  putwp
        fcl  " digits"
        rts
putwp:  bsr  putw
        bra  pri
; pri: the text after the call (a length byte, then the text)
lnpri:  bsr  ln                 ; (on line A)
pri:    pulx
        bsr  prs
        jmp  0,x
; prs: the lbc at X (X left after it)
prs:    ldab 0,x
        inx
prb:    tstb                    ; B characters at X
        beq  .x
.l:     ldaa 0,x
        inx
        bsr  putc
        decb
        bne  .l
.x:     rts
; out: the line printed (the cursor off)
out:    ldaa kv_ln
        ldab kv_w
        mul
        tba
        clrb
        os   DP$STAT
        ldx  #kv_lbuf
        ldab kv_w
        os   DP$PRNT
        rts

; ---- 32-bit numbers (kv_n: 4 bytes, highest first) ----------------------
; putw: D as a number at the pen; putn: kv_n
putw:   std  kv_n+2
        ldd  #0
        std  kv_n
putn:   clrb                    ; the digits, the last one first, onto the stack: B of them
.d:     pshb
        ldab #10
        bsr  ndiv               ; A = the remainder
        pulb
        adda #'0'
        psha
        incb
        ldx  kv_n
        bne  .d
        ldx  kv_n+2
        bne  .d
.p:     pula
        bsr  putc
        decb
        bne  .p
        rts
; ndiv: kv_n / B (1-255): A = the remainder
ndiv:   stab kv_nd
        ldab #32
        clra
.b:     asl  kv_n+3
        rol  kv_n+2
        rol  kv_n+1
        rol  kv_n
        rola
        bcs  .s
        cmpa kv_nd
        blo  .n
.s:     suba kv_nd
        inc  kv_n+3
.n:     decb
        bne  .b
        rts
; ---- times and progress: OV_PROG's routines; on all but the smallest tier it is kept in memory as well, past the
; slot (the same code, at kv_prg)
pr_pct: clrb
        bra  prd
pr_left: ldab #1
        bra  prd
pr_num: ldab #2
        bra  prd
putt:   ldab #3
        bra  prd
pr_two: ldab #5
        bra  prd
pr_ln:  ldab #6
        bra  prd
muldiv: ldab #4
prd:    ldaa kv_tier
        cmpa #4
        beq  .o
        ldaa #3
        mul
        addd #kv_prg
        pshb
        psha
        rts
.o:     ldaa #OV_PROG
        bra  ovd
