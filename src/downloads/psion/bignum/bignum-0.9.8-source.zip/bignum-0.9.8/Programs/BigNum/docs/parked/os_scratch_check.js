// After BigNum, with the OS's scratch areas full of rubbish, does the OS behave as it would have? (docs/parked-ram-savings.md)
//   node docs/parked/os_scratch_check.js [rom ...]      (none: all 29; it takes a few minutes)
'use strict';
const { BN, HZ, ROMS, rng } = require('../../tests/lib');
const K = ['EXE', 'ON', 'UP', 'DOWN', 'LEFT', 'RIGHT', 'DEL', 'MODE', 'SPACE', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'L', 'M', 'N', 'O', 'P', 'R', 'S', 'T', '1', '2', '+', '=', '(', ')'];
const one = (rom, seed, fill) => {
  const g = new BN(rom), m = g.m; g.start(); g.wait(); m.pokew(0x7D, 0xFFFF);
  if (fill) for (const [a, b] of [[0x234D, 0x23AC], [0x23B5, 0x23D3]]) for (let i = a; i <= b; i++) m.poke(i, fill === 1 ? 0xFF : (i * 37 + 11) & 255);
  g.inject('ON'); g.wait(); m.poke(0x76, 89); m.run(HZ * 4);
  const R = rng(seed), out = [], keys = [];
  for (let i = 0; i < 220; i++) { const k = K[R.int(K.length)]; keys.push(k); try { m.press(k, 3, 5); } catch (e) { continue; } m.run(HZ * 0.3); out.push(m.screenText()); if (!m.isOn()) { m.press('ON', 3, 5); m.run(HZ); } }
  return { out, keys };
};
let bad = 0, n = 0; const roms = process.argv.slice(2).length ? process.argv.slice(2) : Object.keys(ROMS);
for (const r of roms) for (const seed of [1, 2]) {
  const a = one(r, seed, 0), clk = (s) => s.replace(/\d+:\d+(:\d+)?/g, 't');
  for (const f of [1, 2]) { const b = one(r, seed, f); n++; const i = a.out.findIndex((t, k) => clk(t) !== clk(b.out[k])); if (i >= 0) { bad++; console.log('DIFF', r, seed, f, 'at key', i, a.keys.slice(Math.max(0, i - 6), i + 1).join(' '), '\n', JSON.stringify(a.out[i]), '\n', JSON.stringify(b.out[i])); } }
}
console.log(n, 'runs', bad, 'differ');
