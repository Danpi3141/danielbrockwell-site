; =====================================================================
; OV_INS: the functions listed: the one picked goes into the line with its opening bracket (in RTB_BL).
; =====================================================================
        include "macros.inc"
        lastent ins

ins:    ldx  #fns               ; how many
        clra
.n:     tst  0,x
        beq  .l
        inca
        bsr  past
        bra  .n
.l:     bsr  list
        ldx  #RTB_BL
        clr  0,x
        cmpb #K_EXE
        bne  .x
        ldab li_i
        bsr  nth
        stx  zx
        ldx  #RTB_BL+1
        stx  zp
        clrb
.c:     ldx  zx
        ldaa 0,x
        inx
        stx  zx
        ldx  zp
        incb
        tsta
        bmi  .last
        staa 0,x
        inx
        stx  zp
        bra  .c
.last:  anda #$7F
        staa 0,x
        ldaa #'('
        staa 1,x
        incb
        stab RTB_BL
.x:     rts
; nth: X = entry B; past: X past the entry at X
nth:    ldx  #fns
.l:     decb
        bmi  .x
        bsr  past
        bra  .l
.x:     rts
past:   tst  0,x
        bmi  .e
        inx
        bra  past
.e:     inx
        inx
        inx
        inx
        rts
li_row: bsr  nth
.l:     ldaa 0,x
        bmi  .e
        bsr  putc
        inx
        bra  .l
.e:     anda #$7F
        bsr  putc
        ldaa #'('
        bra  putc
        include "list.inc"
fns:
        include "fns.inc"
        fcb  0
