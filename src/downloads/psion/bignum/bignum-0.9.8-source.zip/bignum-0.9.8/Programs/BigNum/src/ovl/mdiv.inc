; muldv_: kv_n = kv_n x kv_na / kv_nb (the product in 6 bytes; a result past 4 bytes is all ones)
muldv_: ldx  #0
        stx  md_h
        stx  md_h+2             ; the product: md_h (2), kv_n (4): from the top bit of kv_na
        ldd  kv_n
        std  md_a
        ldd  kv_n+2
        std  md_a+2
        stx  kv_n
        stx  kv_n+2
        ldab #16
.m:     asl  kv_n+3
        rol  kv_n+2
        rol  kv_n+1
        rol  kv_n
        rol  md_h+1
        rol  md_h
        asl  kv_na+1
        rol  kv_na
        bcc  .n
        pshb
        ldd  kv_n+2
        addd md_a+2
        std  kv_n+2
        ldd  kv_n
        adcb md_a+1
        adca md_a
        std  kv_n
        bcc  .c
        ldx  md_h
        inx
        stx  md_h
.c:     pulb
.n:     decb
        bne  .m
        ldaa #48                ; and divided
        staa md_a
        ldx  kv_nb
        beq  .x
        clra
        clrb
.d:     asl  kv_n+3
        rol  kv_n+2
        rol  kv_n+1
        rol  kv_n
        rol  md_h+1
        rol  md_h
        rolb
        rola
        bcs  .s
        subd kv_nb
        bcc  .i
        addd kv_nb
        bra  .e
.s:     subd kv_nb
.i:     inc  kv_n+3
.e:     dec  md_a
        bne  .d
        ldx  md_h
        beq  .x
        ldx  #$FFFF
        stx  kv_n
        stx  kv_n+2
.x:     rts
