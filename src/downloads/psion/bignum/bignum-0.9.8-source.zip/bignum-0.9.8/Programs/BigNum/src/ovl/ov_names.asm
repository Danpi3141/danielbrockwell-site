; =====================================================================
; OV_NAMES: the functions' and commands' names. Entry 0: the name at kv_id, kv_il letters, looked up among
; the functions: kv_fn = its arguments, overlay and entry (carry set: not there); 1: among the commands.
; =====================================================================
        include "macros.inc"
        entry lookf
        lastent lookc

lookc:  ldx  #cmds
        bra  look
lookf:  ldx  #fns
look:   bsr  find
        bcs  .x
        ldd  0,x
        std  kv_fn
        ldaa 2,x
        staa kv_fn+2
        clc
.x:     rts
; same: Z if the name is the one at X (its last letter has bit 7 set); X and B past it
same:   stx  zp
        ldx  kv_line
        ldab kv_id
        abx
        stx  zx
        ldaa kv_il
        clr  zw
.l:     ldx  zp
        ldab 0,x
        inx
        stx  zp
        pshb
        andb #$7F
        psha
        ldx  zx
        pshb
        ldab 0,x
        bsr  upc
        stab zm
        inx
        stx  zx
        pulb
        pula
        tsta                    ; (no letters left: not it)
        beq  .n
        cmpb zm
        beq  .s
.n:     inc  zw
.s:     deca
        pulb
        tstb
        bpl  .l
        ldx  zp
        tsta
        bne  .x
        tst  zw
.x:     rts
; find: the name in the table at X: X = its three bytes, A its number; carry set: not there
find:   clra
.f:     tst  0,x
        beq  .no
        psha
        bsr  same
        beq  .y
        pula
        inca
        inx
        inx
        inx
        bra  .f
.y:     pula
        clc
        rts
.no:    sec
        rts
; functions: the name (bit 7 on its last letter), its arguments, the overlay and entry that do it
fns:
        include "fns.inc"
        fcb  0
cmds:
        include "cmds.inc"
        fcb  0
