; hsqr: the top number squared
hsqr:   bsr  ilenw
        std  mal
        subd #0
        beq  .x                 ; (0)
        inx
        inx
        stx  ma
        addd ma
        std  kv_se
        ldd  mal
        asld
        pshb
        psha
        addd #2
        bsr  walloc
        pula
        pulb
        std  0,x
        inx
        inx
        stx  mp
        bsr  sqrp
        bra  hslide
.x:     rts
