; sgcd: the GCD of slot B and the number (fx_n) pushed
sgcd:   bsr  fromslot
        ldx  fx_n
        bsr  hcopy
        ovsub OV_FN,0
        rts
; kind: the top number: Z: it is 1; carry: it is less than the number at fx_n (a factor); neither: it is
; the number
kind:   ldx  kv_wp
        ldd  0,x
        subd #1
        bne  .c
        ldaa 2,x
        deca
        beq  .x
.c:     ldd  fx_n
        bsr  hcmp
        bne  .y                 ; (not Z: carry if less)
        clc                     ; the number itself: no Z, no carry
        ldaa #1
.y:
.x:     rts
