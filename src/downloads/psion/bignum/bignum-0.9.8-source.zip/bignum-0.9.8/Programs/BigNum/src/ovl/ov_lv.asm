; =====================================================================
; OV_LV: the Lucas sequence V(k) modulo N with P = t, Q = 1: the top three numbers t, k, N (N odd, t below it, k
; positive) replaced by it.
; =====================================================================
        include "macros.inc"
        include "pv.inc"
        lastent lv

mx_e    = kv_fs                 ; k, for ebit
lv_i    = kv_fs+2               ; the bit to do, plus 1
lv_e    = kv_fs+4               ; the arguments' end
lv_t    = kv_fs+6
lv:     bsr  i2
        stx  mx_e
        bsr  inext
        stx  lv_t
        bsr  inext
        stx  lv_e
        ldx  mx_e
        bsr  ibits
        std  lv_i
        bsr  ilenw
        std  mn
        ldx  kv_wp
        stx  ms_x
        ldab #5                 ; 0 and 1: V, V; 2: t; 3: 2; 4: R squared
        stab ms_b
        ldd  #$0304
        std  ms_o
        ovsub OV_MSET,0
        ldd  lv_i
        bsr  part
        ovsub OV_EST,2
        ldx  #hook
        bsr  hookx
        ldx  lv_t
        ldab #2
        bsr  toslot
        bsr  mrun
        mo    M_MUL,2,2,4
        mo    M_ADD,3,3,3
        mo    M_CPY,0,3,3        ; V0 = 2, V1 = t
        mol   M_CPY,1,2,2
.l:     ldd  lv_i
        beq  .e
        subd #1
        std  lv_i
        ldx  kv_done
        inx
        stx  kv_done
        bsr  ebit
        bne  .one
        bsr  mrun
        mo    M_MUL,1,0,1
        mo    M_SUB,1,1,2
        mo    M_SQR,0,0,0
        mol   M_SUB,0,0,3
        bra  .l
.one:   bsr  mrun
        mo    M_MUL,0,0,1
        mo    M_SUB,0,0,2
        mo    M_SQR,1,1,1
        mol   M_SUB,1,1,3
        bra  .l
.e:     ldab #1
        bsr  sone
        bsr  mrun
        mol   M_MUL,0,0,1
        clrb
        bsr  fromslot
        ldx  lv_e
        bra  hslx
hk_t:   fcl  "PROVE  "
hk_p:   fcl  "N+1 bit "
hk_q:   fcl  "N+1 "
        include "ibits.inc"
        include "ebit.inc"
        include "mslot.inc"
        include "bhook.inc"
