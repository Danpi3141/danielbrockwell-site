// An alarm rings (the OS's alarm screen) while the program works and while it waits for a key: it is
// dismissed, and the work goes on to the right result, the screen as it was.   node tests/t_alarm.js [rom ...]
'use strict';
const { BN, ROMS, HZ } = require('./lib');
let bad = 0;
for (const rom of process.argv.slice(2).length ? process.argv.slice(2) : ['24-cm.rom', '33-cm.rom', '31-xp.rom', '36-la.rom', '42-lz.rom', '46-lz.rom', '43-lz64.rom', '46a-lz64.rom']) {
  for (const phase of ['running', 'waiting']) for (const trial of phase === 'running' ? [0, 1, 2] : [0]) {
    const g = new BN(rom), m = g.m;
    m.press('A', 3, 12); m.runSeconds(1);
    for (let i = 0; i < 3; i++) { m.press('EXE', 3, 12); m.runSeconds(0.3); }
    for (let i = 0; i < 5; i++) m.press('ON', 3, 10);
    g.start();
    m.poke(0x5B, 1); for (let i = 0; i < 40 && m.peek(0x5B); i++) m.runSeconds(0.02);
    if (g.four) m.write(0x20C5, [126, 10, 27, 23, 59, 30 + trial * 3]); else m.write(0x20C8, [23, 59, 30 + trial * 3]);                       // Saturday 28 November 2026; it rings at midnight
    const line = 'MODEXP(3,2**521-2,2**521-1)+PROVE(2**107-1)'; const at = g.addr('t_idle');
    if (phase === 'running') { g.wait(); m.write(g.peekw('kv_line'), [line.length, ...[...line].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', line.length); g.inject('EXE'); } else { g.line('2**100'); g.wait(); }
    const scr = g.text();
    let rang = false; for (let i = 0; i < 400 && !rang; i++) { m.runSeconds(0.25); rang = /ALARM/i.test(g.text()); }
    if (!rang) { console.log(`FAIL ${rom} ${phase}: it did not ring: ${g.text()}`); bad++; continue; }
    m.runSeconds(2); for (let k = 0; k < 10 && /ALARM|ON\/CLEAR/i.test(g.text()); k++) { m.press('ON', 20, 4); m.runSeconds(0.4); }
    m.runSeconds(1);
    if (phase === 'running') {
      for (let k = 0; k < 5; k++) { if (/Paused/.test(g.text())) { m.poke(0x76, 67); m.run(HZ); } }
      for (let k = 0; k < 4000 && m.runTo([at], HZ) !== at; k++) ; for (let k = 0; k < 3 && /Paused/.test(g.text()); k++) { m.poke(0x76, 67); m.run(HZ); for (let j = 0; j < 4000 && m.runTo([at], HZ) !== at; j++) ; }
      const v = g.vars()['@']; if (v !== 2n) { console.log(`FAIL ${rom} running: ${v} ${g.text()}`); bad++; } else console.log(`${rom} running: rang, the result right`);
    } else { const ok = g.text() === scr; if (!ok) { console.log(`${rom} waiting: the screen after it: ${g.text().replace(/\n/g, '|')}`); } for (let i = 0; i < 4 && !g.atLine(); i++) { g.inject('ON'); g.wait(); } const r = g.line('6*7'); if (r.val !== 42n) { bad++; console.log('FAIL', rom, r); } else console.log(`${rom} waiting: ${ok ? 'the screen as it was' : 'the screen changed'}, goes on`); }
  }
}
console.log(bad ? `${bad} FAILED` : 't_alarm ok');
process.exit(bad ? 1 : 0);
