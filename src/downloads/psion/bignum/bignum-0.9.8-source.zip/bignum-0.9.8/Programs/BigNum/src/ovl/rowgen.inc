; rowgen: the multiply rows (src/core/rows.asm) made for kv_wm (8 or 24) bytes, at the top of the block:
; the entries (kv_et), then groups of 8 steps, each with its N run (no carry in, 11 bytes a step) and
; its C run (12 bytes a step), in the order C N, N C, C N ... so that each run goes on into the next
; group's; the last group is C N.  Every group is 96 + 3 + 88 = 187 bytes. Then the exits (15), and, for more than 8 bytes, the
; rest of ycl's copying (33).
rowgen: ldab kv_wm
        lsrb
        lsrb
        lsrb
        stab rg_g               ; the groups
        ldaa #187
        mul
        addd #2+15              ; entry 0, the exits
        std  zt
        ldab kv_wm
        clra
        asld
        addd zt
        std  zt
        ldab kv_wm
        cmpb #8
        beq  .n8
        ldd  zt
        addd #33
        std  zt
.n8:    ldd  kv_hi
        subd zt
        std  kv_hi
        std  kv_et
        std  zt
        ldab kv_wm
        decb
        stab rg_t               ; the chunk byte of the first step
        incb
        clra
        asld
        addd #2
        addd zt
.grp:   std  rg_b
        addd #187
        std  rg_nn              ; (C N: the next group's N run)
        ldab rg_g
        lsrb
        bcc  .nc
        ldd  rg_b               ; C N
        std  rg_c
        addd #99
        std  rg_n
        addd #179               ; the next one's C run
        std  rg_cc
        ldab rg_g
        decb
        bne  .m
        ldd  rg_nn              ; the last: the exits
        addd #3
        std  rg_cc
.m:     ldx  rg_cc
        ldd  #96
        bra  .jmp
.nc:    ldd  rg_nn              ; N C
        std  rg_cc
        addd #99
        std  rg_nn
        ldd  rg_b
        std  rg_n
        addd #91
        std  rg_c
        ldx  rg_nn
        ldd  #88
.jmp:   addd rg_b               ; jmp X there
        stx  zx
        xgdx
        ldaa #$7E
        staa 0,x
        ldd  zx
        std  1,x
        clr  rg_k               ; the N run
        ldd  rg_cc
        std  rg_l
        ldx  rg_n
        ldd  rg_c
        addd #12
        bsr  rg_run
        inc  rg_k               ; the C run
        ldd  rg_nn
        std  rg_l
        ldx  rg_c
        ldd  rg_n
        addd #11
        bsr  rg_run
        ldab rg_t
        subb #8
        stab rg_t
        ldd  rg_b
        addd #187
        dec  rg_g
        bne  .grp
; the exits: N: jmp (to where the rows were called from); C: the carry put on, then the same
        std  rg_b
        ldx  kv_et
        std  0,x
        ldx  rg_b
        ldaa #$7E
        staa 0,x
        inx
        stx  kv_rx
        inx
        inx
        ldd  #$6C00             ; inc 0,x
        std  0,x
        ldd  #$26F9             ; bne the jmp
        std  2,x
        ldd  #$096C             ; dex / inc 0,x
        std  4,x
        ldd  #$0027             ; beq back to the dex
        std  6,x
        ldd  #$FB20             ; bra the jmp
        std  8,x
        ldaa #$F2
        staa 10,x
        ldab kv_wm              ; the rest of the chunk's copying: ldd n,x / std YZ+n
        cmpb #8
        beq  .yx
        ldd  rg_b
        addd #15
        std  ycl_j+1
        std  zx
        ldx  zx
        ldab #8
.y:     ldaa #$EC
        std  0,x
        ldaa #$DD
        pshb
        addb #YZ
        std  2,x
        pulb
        inx
        inx
        inx
        inx
        incb
        incb
        cmpb kv_wm
        bne  .y
        ldaa #$39
        staa 0,x
.yx:    rts
; 8 steps at X: rg_k 0 N, 1 C; D = where the first one's branch goes (the others 12 or 11 on, the
; last to rg_l)
rg_run: std  rg_tg
        ldaa rg_t
        staa rg_u
        ldaa #8
        staa rg_i
.s:     tst  rg_k
        bne  .c
        stx  zx                 ; its entry
        ldx  kv_et
        ldab rg_u
        incb
        aslb
        abx
        ldd  zx
        std  0,x
        ldx  zx
.c:     ldab rg_u
        ldaa #$D6               ; ldab YZ+t
        addb #YZ
        std  0,x
        ldd  #$9600+zm          ; ldaa zm
        std  2,x
        ldaa #$3D               ; mul
        staa 4,x
        inx
        inx
        inx
        inx
        inx
        ldaa #$4C               ; inca
        tst  rg_k
        beq  .n
        staa 0,x
        inx
.n:     ldaa #$E3               ; addd t+1,x
        ldab rg_u
        incb
        std  0,x
        ldaa #$ED               ; std t+1,x
        std  2,x
        ldaa #$25               ; bcs (C: bcc)
        suba rg_k
        staa 4,x
        ldab #6
        abx
        stx  zx
        dec  rg_i
        bne  .t
        ldd  rg_l
        std  rg_tg
.t:     ldd  rg_tg
        subd zx
        dex
        stab 0,x
        inx
        ldd  rg_tg
        addd #12
        subb rg_k
        sbca #0
        std  rg_tg
        dec  rg_u
        tst  rg_i
        bne  .s
        rts
rg_g:   rmb 1
rg_t:   rmb 1
rg_u:   rmb 1
rg_i:   rmb 1
rg_k:   rmb 1
rg_b:   rmb 2
rg_n:   rmb 2
rg_c:   rmb 2
rg_nn:  rmb 2
rg_cc:  rmb 2
rg_l:   rmb 2
rg_tg:  rmb 2
