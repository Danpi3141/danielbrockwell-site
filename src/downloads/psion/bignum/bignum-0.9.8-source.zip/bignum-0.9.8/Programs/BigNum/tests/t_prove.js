// PROVE: every certificate is read out of memory and checked here from scratch.
//   node tests/t_prove.js [model] [line ...]
'use strict';
const { BN, HZ } = require('./lib');
const model = process.argv[2] || 'lz64';
const g = new BN(model).start(), m = g.m;
let bad = 0;
const fail = (s) => { console.log('FAIL', s); bad++; };
const powm = (b, e, n) => { let r = 1n; b = ((b % n) + n) % n; while (e) { if (e & 1n) r = r * b % n; b = b * b % n; e >>= 1n; } return r; };
const gcd = (a, b) => { a = a < 0n ? -a : a; while (b) [a, b] = [b, a % b]; return a; };
const root = (v) => { if (v < 2n) return v; let x = 1n << BigInt(Math.ceil(v.toString(2).length / 2)); for (;;) { const y = (x + v / x) / 2n; if (y >= x) return x; x = y; } };
const mr = (n) => { if (n < 2n) return false; for (const p of [2n, 3n, 5n, 7n, 11n, 13n, 17n, 19n, 23n, 29n, 31n, 37n]) if (n % p === 0n) return n === p; let d = n - 1n, s = 0; while (!(d & 1n)) { d >>= 1n; s++; }
  next: for (const a of [2n, 3n, 5n, 7n, 11n, 13n, 17n, 19n, 23n, 29n, 31n, 37n]) { let x = powm(a, d, n); if (x === 1n || x === n - 1n) continue; for (let i = 1; i < s; i++) { x = x * x % n; if (x === n - 1n) continue next; } return false; } return true; };
const jac = (a, n) => { a = ((a % n) + n) % n; let t = 1; while (a) { while (!(a & 1n)) { a >>= 1n; const r = n & 7n; if (r === 3n || r === 5n) t = -t; } [a, n] = [n, a]; if ((a & 3n) === 3n && (n & 3n) === 3n) t = -t; a %= n; } return n === 1n ? t : 0; };
const inv = (a, n) => { let [r, s] = [((a % n) + n) % n, n], [x, y] = [1n, 0n]; while (s) { const q = r / s; [r, s] = [s, r - q * s]; [x, y] = [y, x - q * y]; } return ((x % n) + n) % n; };
const luc = (t, k, n) => { let a = 2n, b = t; for (const c of k.toString(2)) { if (c === '1') { a = (a * b - t) % n; b = (b * b - 2n) % n; } else { b = (a * b - t) % n; a = (a * a - 2n) % n; } } return ((a % n) + n) % n; };
function cert() {
  const r = []; let a = g.peekw('kv_rl'); const e = g.peekw('kv_lim');
  while (a < e) { const v = g.item(a + 3); r.push({ t: m.peek(a), w: m.peekw(a + 1), v }); a += 5 + (m.peekw(a + 3) & 0x7fff); }
  return r;
}
function check(N, c) {
  const secs = []; for (const r of c) { if (r.t !== 1) secs.push({ ...r, q: [] }); else secs[secs.length - 1].q.push(r); }
  const kind = ['', '', 'N-1 half', 'N-1 third', 'N+1'];
  if (!secs.length || secs[0].v !== N) return fail('not a certificate of ' + N);
  for (const s of secs) {
    const n = s.v, plus = s.t === 4, M = plus ? n + 1n : n - 1n; let F = 1n;
    for (const { w, v: q } of s.q) {
      if (M % q) fail(`${q} does not divide`);
      if (q >= 1n << 64n) { if (!secs.some((x) => x.v === q)) fail(`${q} unproved`); } else if (!mr(q)) fail(`${q} not prime`);
      let x = M; while (x % q === 0n) { x /= q; F *= q; }
      const a = BigInt(w);
      if (plus) { const D = BigInt(s.w); const t = 2n * (a * a + D) * inv(a * a - D, n) % n; if (gcd(a * a - D, n) !== 1n) fail('a a - D'); const v = luc(t, M / q, n); if (gcd(v - 2n, n) !== 1n) fail(`gcd at ${q}`); if (luc(t, M, n) !== 2n) fail('V(N+1)'); } else { const r = powm(a, M / q, n); if (powm(r, q, n) !== 1n) fail('a^(n-1)'); if (gcd(r - 1n, n) !== 1n) fail(`gcd at ${q}`); }
    }
    if (plus) { if (jac(BigInt(s.w), n) !== -1) fail('D'); if ((F - 1n) * (F - 1n) <= n) fail('F too small'); } else if (s.t === 2) { if ((F + 1n) * (F + 1n) <= n) fail('F too small'); } else { if (F * F * F <= n) fail('F too small'); const R = M / F, c2 = R / F, c1 = R % F, d = c1 * c1 - 4n * c2; if (d >= 0n && root(d) ** 2n === d) fail('square test'); }
    if (!mr(n)) fail('really not a prime ' + n);
  }
  return secs.map((s) => `P${String(s.v).length} ${kind[s.t]}`).join(', ');
}
const lines = process.argv.length > 3 ? process.argv.slice(3) : ['2**127-1', '10**30+57', '2**89-1', '2**107-1', '10**20+39', '10**25+13', '18446744073709551629',
  '2*(10**24+7)*3+1', '10**40+121', '2**130-5', '4*10**30+519', '(2**107-1)*210+1'];
for (const l of lines) {
  const r = g.line(`PROVE(${l})`, 1e6);
  const vs = g.meta.ovl[g.peek('kv_res') - 1] === 'ov_vshow';
  const N = eval(l.replace(/\d+/g, '$&n'));
  let s = '';
  if (r.err) fail(`${l} err ${r.err}`);
  else if (vs && g.peek('kv_pv', 4)) { s = check(N, cert()); if (r.val !== 1n) fail('value ' + r.val); } else { s = r.screen.join('|'); if (vs && r.val !== 0n) fail('value'); if (!vs && (r.val === 1n) !== mr(N)) fail('prime?'); }
  console.log(`${l} = ${r.val} ${(r.cycles / HZ).toFixed(0)} s: ${s}`);
}
console.log(bad ? `${bad} FAILED` : 'ok');
process.exit(bad ? 1 : 0);
