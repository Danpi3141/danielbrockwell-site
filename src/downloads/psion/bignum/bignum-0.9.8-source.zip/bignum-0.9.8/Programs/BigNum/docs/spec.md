# Psion big-number calculator: design spec
Nov 24, 2026 · @Daniel
## Summary
A big-number calculator for all five Organiser II models that evaluates typed expressions, tests numbers for primality and factors them through a chain of methods modelled on YAFU, ending in a small quadratic sieve.
| Decision | Choice | Decided by |
| Name | BigNum | You |
| Models | CM, XP, LA, LZ and LZ64 | You |
| Largest number | 8,192 bits (2,467 digits); 2,048 bits (617 digits) on the CM or any machine short of memory | You |
| Factoring | Trial division, Pollard rho, P-1, P+1, elliptic curves, then a small quadratic sieve | You |
| Effort | One plan. The cheaper methods get a fifth of the sieve's time, then the sieve runs | You |
| Sieve | 192 primes and a 160-bit cap with 21,000 bytes free; smaller on machines with less | You |
| Primality | A strong probable-prime test for any number, plus a proof when enough of N-1 or N+1 can be factored | You |
| Small primes | Below 2 to the power 64, a pass of the test alone counts as proven | You |
| Interface | An expression line, as in YAFU | You |
| Remainder | Both % and MOD(a,b) | You |
| Long runs | Start at once with the estimate on screen, and never ask first. Checkpoints are optional and off by default | You |
| Engine | Its own, not shared with the prime finder | You |
| Functions | Modular arithmetic, number theory and sequences | You |
| Machine code | Loaded the same way as in your other Organiser programs | You |
| Memory | Four tiers set by free memory at start-up, not by model | This spec |
| Arithmetic | Whole numbers only, held as bytes, multiplied with the processor's 8 by 8 multiply | This spec |

### What to expect
- Arithmetic is quick at every size. Two 8,192-bit numbers multiply in about a minute.
- Primality is practical to about 600 digits. A 155-digit test takes 10 minutes and a 617-digit test runs overnight. A full 2,467-digit test takes about four weeks.
- The sieve sets the factoring range. With 21,000 bytes free, the LA, LZ and LZ64 factor any 28-digit number in minutes, any 36-digit number in about two hours and any 40-digit number overnight. The sieve's hard cap there is 160 bits, or 49 digits, which takes about four weeks.
- Free memory decides the limits, not the model. There are four tiers. A machine short of memory gets a smaller sieve and a lower cap.
- The CM is the main risk. It fits with about 800 bytes to spare on paper, and it has no sieve and no saving.
- Every time here is an estimate. The figures come from a cost model and a Python prototype, not a real machine. The BENCH command replaces them.
## Scope
The program borrows YAFU's shape: an interactive line where you type an expression, and a FACTOR function that runs a chain of methods on its own. It leaves out everything that needs a modern machine.
### Taken from YAFU
| YAFU feature | Here |
| Interactive expression evaluator with functions and variables | Yes, on one line of the Organiser's screen |
| factor(n): one call that picks and chains methods | Yes |
| Separate calls for each method: trial, rho, pm1, pp1, ecm, mpqs | Yes, in capitals, with QS for the sieve |
| isprime, nextprime, gcd, jacobi, modinv, modexp, sqrt, nroot, fib, luc | Yes |
| Factors printed with a size label, such as P12 for a 12-digit prime | Yes, with PRP for probable primes and C for composites |
| Settings for each method's bounds | Yes, as named settings |
| A log of results | Yes, optional, as a file on a pack. Not in tier 4 |
| Save files so long runs can resume | Yes, optional. Not in tier 4 |

The function list and settings follow YAFU's documentation.
### Left out
| YAFU feature | Why not |
| Self-initialising quadratic sieve with large primes | Large primes need too much memory. A simpler multiple-polynomial sieve takes its place, with self-initialising as the first stretch goal |
| Number field sieve | Far beyond the machine |
| Effort levels, as in the -plan option | One plan is enough here: a fifth of the sieve's time, then the sieve |
| Batch files and command-line flags | No command line. Settings do the same job |
| Logarithms and floating point | Whole numbers only |
| Hex and binary input and output | Not requested |
| Random numbers and RSA test numbers | Small extras, listed as stretch goals |

### Changes forced by the keyboard
The Organiser has no ^, ! or # key, so:
- Power is **, as in the Organiser's own calculator and in OPL.
- Factorial and primorial are the functions FACT(n) and PRIMORIAL(n).
- Names are in capitals, which is how the keyboard types by default.
## Limits by machine
The program measures free memory when it starts and picks one of four tiers. The model does not matter: a machine short of memory behaves like a smaller one. One build runs on all five machines.
|  | CM | XP | LA | LZ | LZ64 |
| Screen | 16 x 2 | 16 x 2 | 16 x 2 | 20 x 4 | 20 x 4 |
| Memory | 8K | 16K | 32K | 32K | 64K |
| Typically free, bytes | 6,400 | 14,000 | 21,000 | 21,000 | 21,000 |
| Usual tier | 4 | 2 | 1 | 1 | 1 |
| Program's peak need, bytes | 5,600 | 12,500 | 16,700 | 16,700 | 16,700 |
| Largest number | 2,048 bits | 8,192 bits | 8,192 bits | 8,192 bits | 8,192 bits |
| In decimal digits | 617 | 2,467 | 2,467 | 2,467 | 2,467 |
| Quadratic sieve | None | 128 primes | 192 primes | 192 primes | 192 primes |
| Sieve hard cap | n/a | 150 bits, 46 digits | 160 bits, 49 digits | 160 bits, 49 digits | 160 bits, 49 digits |
| Longest line that can be typed | 128 characters | 255 | 255 | 255 | 255 |
| Earlier lines kept for recall | 1 | 2 | 4 | 4 | 4 |

### Memory tiers
| Tier | Free at start, bytes | Largest number | Sieve | Sieve hard cap | ECM only above | Saving | Entry line |
| 1 | 16,700 or more | 8,192 bits | 192 primes | 160 bits, 49 digits | The cap | Optional | 255 characters |
| 2 | 12,500 to 16,699 | 8,192 bits | 128 primes | 150 bits, 46 digits | The cap | Optional | 255 characters |
| 3 | 9,100 to 12,499 | 2,048 bits | 64 primes | 120 bits, 37 digits | The cap | Optional | 255 characters |
| 4 | 5,600 to 9,099 | 2,048 bits | None | n/a | 20 digits | None | 128 characters |
| None | Under 5,600 | Will not start |  |  |  |  |  |

- The tier is set once, at start-up. It does not change during a session, so a long run cannot be caught out.
- A full machine drops tiers. An LZ with 10,000 bytes free runs in tier 3: 617-digit numbers and the small sieve. It keeps its four-line screens.
- Freeing memory restores the tier. Move files from A: to a pack and start the program again.
- Tier 4 has no saving at all. Checkpoints, the log, SAVE and LOAD are left out there, because writing a checkpoint needs about 1,000 bytes a CM does not have.
- Tier 4 has a shorter entry line. It takes 128 characters, not 255. Longer expressions are built up with variables.
- Tier 4 has no P+1. The PP1 function reports that it is not available there, and FACTOR goes from P-1 straight to ECM.
- Under 5,600 bytes the program stops with a message saying how much it needs.
A result that would pass the size cap stops with TOO BIG. Nothing wraps round or loses digits silently.
### Largest inputs for the sequence functions
| Function | 2,048-bit cap | 8,192-bit cap |
| FACT(n) | n up to 300 | n up to 966 |
| PRIMORIAL(n) | n up to 1,480 | n up to 5,782 |
| FIB(n) | n up to 2,951 | n up to 11,801 |
| BINOM(2k,k) | k up to 1,026 | k up to 4,099 |
| 2**n | n up to 2,047 | n up to 8,191 |

### What the size cap does not promise
Arithmetic works across the whole range, but heavy number theory does not. Multiplying two 8,192-bit numbers takes about a minute. Testing one for primality takes about four weeks. The time estimates section gives the full picture.
## The expression line
You type one line, press EXE, and get one result. A line is an expression, an assignment or a command.
2**127-1
FACTOR(2**64+1)
P=NEXTPRIME(10**30)
MODEXP(3,P-1,P)
ISPRIME(10**50+151)
FACTOR(FACT(25)+1)
### Rules
| Item | Rule |
| Numbers | Whole numbers in decimal, positive or negative |
| Line length | Up to 255 characters, the editor's limit. 128 in tier 4, the CM |
| Operators, strongest first | **, then unary -, then * / %, then + - |
| ** | Power. Groups from the right, so 2**3**2 is 2**9 |
| / and % | Whole-number quotient and remainder. The remainder is never negative |
| MOD(a,b) | The same remainder as a%b, written as a function |
| Brackets | ( and ), nested as deep as memory allows |
| Variables | Single letters A to Z. P=expression stores a value |
| ANS | The last result |
| Functions | A name of two or more letters, then arguments in brackets |
| Commands | A name with no brackets, such as SET or VARS |

A number too long to type is built from an expression or loaded from a file with LOAD.
### Functions
| Group | Function | Result |
| Arithmetic | GCD(a,b), LCM(a,b) | Greatest common divisor, least common multiple |
|  | MOD(a,b) | Remainder, the same as a%b |
|  | SQRT(a), NROOT(a,n) | Whole-number root, rounded down |
|  | ABS(a), SIZE(a) | Absolute value; count of decimal digits (bits shown beside it) |
| Modular | MODEXP(a,e,m) | a to the power e, modulo m |
|  | MODINV(a,m) | Inverse of a modulo m |
|  | MODSQRT(a,p) | A square root of a modulo a prime p |
|  | CRT(a,m,b,n) | The number that is a modulo m and b modulo n |
|  | JACOBI(a,n) | Jacobi symbol: -1, 0 or 1 |
| Primes | ISPRIME(n) | 1 or 0. The screen says whether 1 means proven or probable |
|  | PROVE(n) | 1 if a proof was found, with a certificate |
|  | NEXTPRIME(n), PREVPRIME(n) | Nearest prime above or below n |
|  | LLT(p) | Lucas-Lehmer test of 2**p-1 |
| Factoring | FACTOR(n) | Runs the whole chain. The value is the smallest prime factor |
|  | TRIAL(n,limit), RHO(n), PM1(n), PP1(n), ECM(n,curves), QS(n) | One method only. The value is a factor, or 1 if none was found |
| Built on factoring | PHI(n), TAU(n), SIGMA(n) | Euler's totient, number of divisors, sum of divisors |
| Sequences | FACT(n), PRIMORIAL(n) | n factorial; product of the primes up to n |
|  | FIB(n), LUC(n) | Fibonacci and Lucas numbers |
|  | BINOM(n,k) | Binomial coefficient |

### Commands
| Command | What it does |
| SET name value | Changes a setting. SET alone lists them |
| VARS | Lists the variables in use and their sizes |
| CLR or CLR A | Clears all variables, or one |
| SAVE A,"name" | Writes a number to a file as decimal text |
| LOAD A,"name" | Reads it back |
| RESUME | Continues a saved long run |
| BENCH | Times this machine, to sharpen later estimates |
| LOG | Shows the last results kept in the log |
| HELP | Lists the functions |

SAVE, LOAD, RESUME and LOG are not available in tier 4, which has no saving.
### Errors
An error shows a short message, then returns to the line with the cursor at the fault.
| Message | Cause |
| SYNTAX | The line cannot be read |
| TOO BIG | A result would pass the size cap |
| DIV BY 0 | Division or remainder by zero |
| NO INVERSE | MODINV of a number that shares a factor with the modulus |
| BAD ARG | An argument a function cannot take, such as FACT(-1) |
| NOT AVAILABLE | Something this memory tier leaves out, or a number over the sieve cap given to QS |
| NO MEMORY | No room left for variables. CLR frees some |

## Screens
Every screen has a four-line form for the LZ and LZ64 and a two-line form for the CM, XP and LA. All sketches below are exact to the character.
### Entry
The top line shows the size cap and free memory. The entry line scrolls sideways when it passes the screen width.
BigNum 8192b  21K   
>FACTOR(2**64+1)_   
                    
                    

BigNum 2048b    
>FACTOR(A)_     
### Factor results
Each factor has a label in YAFU's style. P14 is a proven 14-digit prime, PRP39 a probable prime and C40 a composite left unfactored. A repeated factor shows its power, as in P1^10.
2**64+1 =           
P6  274177          
P14 67280421310721  
2 factors  0:00:20  
The two-line machines show one factor per page. The up and down keys move between pages.
P6          1/2 
274177          

P14         2/2 
67280421310721  
A factor too long for its line is cut with dots. EXE opens it in the number pager.
2**127-1 =          
P39 1701411834604...
                    
1 factor   PRP  10s 
### Number pager
Long numbers page through the screen. The four-line pager shows 60 digits a page under a position line.
Digits 1-60 of 617  
32317006071311007300
71487668866995196044
41026697154840321303
The two-line pager shows 30 digits a page. The last column is kept for a v or ^ mark that says more pages follow or come before.
323170060713110 
073007148766886v
Pressing S in the two-line pager shows the position for a moment.
Digits 1-30     
of 617          
### The first seconds
The program never asks before a long run. It starts at once, shows the estimate on the progress screen, and leaves stopping to you. So that it never looks stuck, the screen changes the moment EXE is pressed and names each quick step as it runs.
FACTOR  60 digits   
Trial division...   
                    
ON=stop             

Trial division..
ON=stop         
A long single job shows its full estimate from the first bit.
BPSW  2467 digits   
Base 2 bit 1/8192   
0%  left 28d 2h     
ON=stop             
### Progress
Every long run shows what it is doing, how far it has got and the time left.
During FACTOR, the bottom line shows the estimate for the whole job in place of the key hint. The factoring chain section has those screens.
BPSW  617 digits    
Lucas bit 512/2048  
25%  left 5:28:00   
ON=stop             

ECM  C40  B1=2000   
Curve 3/25  stage 1 
62%  left 0:09:40   
ON=stop  S=skip     

QS  C36  base 128   
Relations 61/137    
45%  left 1:46:00   
ON=stop             
The two-line form keeps the method, the percentage and the time left.
ECM 3/25  62%   
left 0:09:40    

Lucas 25%       
left 5:28:00    
### Primality results
ISPRIME(2**127-1)   
PRP  39 digits      
BPSW passed  10s    
P=prove             

2**127-1            
P39  PROVED  by N+1 
100% of N+1 factored
C=certificate       

PRP  39 digits  
P=prove         

P39 PROVED N+1  
C=certificate   
### Paused
ON/CLEAR pauses a run and offers four choices. Tier 4 has no saving, so it leaves out the K choice.
Paused: ECM curve 3 
C=continue  S=skip  
K=keep and stop     
A=abandon           

Paused  C S K A 
ECM curve 3     
### Errors
TOO BIG             
Limit is 8192 bits  
>2**9000_           
                    

TOO BIG         
>2**3000_       
## Keys, menu and settings
The keys keep to the Organiser's own habits, and a menu saves typing on the alphabetical keyboard.
### Keys
| Where | Key | Action |
| Entry line | EXE | Run the line |
|  | Left, right | Move the cursor |
|  | Up, down | Recall earlier lines |
|  | DEL | Delete a character |
|  | ON/CLEAR | Clear the line. On an empty line, offer to quit |
|  | MODE | Open the menu |
| Results | Up, down | Next or previous page or factor |
|  | EXE | Open the shown factor in the pager, or return to the entry line |
|  | P | Prove the shown probable prime |
|  | C | Show the certificate of a proven prime |
|  | ON/CLEAR | Back to the entry line |
| Running | ON/CLEAR | Pause and show the choices |
|  | S | Skip to the next method in the chain |

On a result screen, V followed by a letter stores the shown number or factor in that variable.
### Menu
MODE opens a menu in the Organiser's usual style.
| Item | What it does |
| Insert | Lists the functions. Picking one types its name and an opening bracket at the cursor |
| Vars | Lists variables. Picking one types its letter |
| Set | Shows and changes settings |
| Resume | Continues a saved run |
| Bench | Times this machine |
| Log | Shows logged results |
| Quit | Leaves the program |

### Settings
Settings do the job of YAFU's command-line options. SET TDIV 50000 changes one from the entry line. There are no effort levels: FACTOR has one plan, described in the factoring chain section.
| Setting | Default | Meaning |
| TDIV | 10000 | Trial division limit, up to 65535 |
| RHOIT | Auto | Cap on Pollard rho steps. Auto follows the one-fifth rule |
| PM1B1, PP1B1 | Auto | First-stage bounds for P-1 and P+1 |
| ECMB1, CURVES | Auto | Bound and curve count for ECM |
| PROOF | OFF | When on, FACTOR proves every prime factor it reports |
| KEEP | OFF | Checkpoint device: OFF, A:, B: or C: |
| EVERY | 30 | Minutes between checkpoints |
| LOG | OFF | Device for the results log |
| BEEP | ON | Beep when a run over a minute ends |

Settings are saved in a small file on A: so they survive between sessions.
KEEP, EVERY and LOG do nothing in tier 4.
## Arithmetic engine
Numbers are held as bytes, because the processor's one fast multiply works on two bytes at a time. Everything else in the program is built on a small set of machine-code routines.
### Number format
- A two-byte header holds the length in bytes and the sign.
- The value follows as bytes, lowest first. Zero has length 0.
- The largest number is 1,024 bytes plus its header.
Numbers live in one block of memory claimed at start-up. A to Z and ANS are 27 pointers into it. A number takes only the space it needs, so 26 small variables cost little. When a request fails the block is tidied once, and only then does NO MEMORY appear.
### Core routines
| Routine | Method | Assumed cost |
| Add, subtract, compare | Byte loop with carry | 14 cycles a byte |
| Multiply | Schoolbook rows using MUL | 50 cycles per pair of bytes |
| Square | Each cross product once, doubled, plus the diagonal | 60% of a multiply |
| Divide by a 16-bit number | Byte-by-byte long division | 45 cycles a byte |
| Divide | Knuth's Algorithm D on bytes | About one multiply |
| Montgomery reduction | Byte by byte, with a one-byte constant | About one multiply |
| Shift left or right | Byte loop | 10 cycles a byte |

The processor runs 921,600 cycles a second. That comes from the 3.6864 MHz crystal divided by four, as given in the Organiser technical manual. The cycle costs are my assumptions until BENCH measures them.
### Working round one index register
The 6303 has a single index register, and a multiply loop wants two pointers. Two layouts cover this.
- Short form. Both operands and the product sit within 255 bytes of the register. This covers numbers up to about 60 bytes, or 150 digits. All factoring work uses it.
- Long form. Two pointers are kept in memory and swapped into the register. It is slower per step but has no size limit.
The stack pointer must not be borrowed as a second pointer. Interrupts push onto the stack and would corrupt the number.
### Modular arithmetic
| Job | Method |
| Repeated work modulo an odd number | Montgomery form. Convert in once, loop, convert out once |
| Modulo an even number | Reduce by division. Only user-typed MODEXP and % need it |
| MODEXP | Four-bit window when eight table entries fit, plain binary otherwise |
| Powers of 2 | No table. Each step is a squaring and a doubling |
| MODINV, GCD, JACOBI | Binary methods: shifts and subtractions, no division |
| SQRT, NROOT | Newton's method on whole numbers |
| MODSQRT | Tonelli-Shanks |

### Decimal in and out
- Input takes four digits at a time: multiply by 10,000, then add.
- Output divides by 10,000 repeatedly and stores two digits to a byte.
- The pager reads from that packed copy, so paging back and forth costs nothing.
Converting a full 8,192-bit number for display takes about 31 seconds. A 2,048-bit number takes about 2 seconds.
## Factoring chain
FACTOR works up from cheap methods to expensive ones. It leaves each method as soon as the next one is the better bet.
[IMAGE media/image1.png]
FACTOR chain · 6 methods, 2 decisions, 1 loop back
Every factor found is tested at once. A prime part is labelled and set aside. A composite part carries on from where its parent stopped, without repeating work already done.
### The steps
| Step | What it does | Default | Typically finds |
| Trial division | Divides by every number below TDIV with no factor of 2, 3 or 5 | 10,000, as in YAFU | Factors up to 4 digits |
| Perfect power | Tests for squares, cubes and higher powers | Always | Powers such as 7**40 |
| Prime check | Runs the probable-prime test on what is left | Shows its estimate when long | n/a |
| Pollard rho | Brent's version, one GCD every 32 steps | Up to 8,000 steps | Factors up to about 8 digits |
| P-1 | Stage 1 to B1, stage 2 to 25 x B1 | B1 = 2,000 | A factor p where p-1 has only small prime factors |
| P+1 | Williams's method, same bounds | B1 = 2,000, one start. Left out in tier 4 | The same for p+1 |
| ECM | Montgomery curves, stage 2 to 100 x B1 | Levels below | Factors up to about 15 digits in a day, about 20 in weeks |
| Quadratic sieve | Multiple polynomials, described in the next section | Any leftover up to the sieve cap | Any number in range, whatever its factors |

One shortcut saves many tests. After trial division to 10,000, anything left below 100,000,000 must be prime.
### One plan: a fifth, then the sieve
FACTOR has one plan and no effort levels. The sieve's running time depends only on the size of the number. ECM's depends on the size of the factor. So the cheaper methods get a fixed share of the sieve's time, and then the sieve finishes the job.
- Leftover within the sieve cap. The cap depends on the memory tier: 160, 150 or 120 bits. Rho, P-1, P+1 and ECM together get one fifth of the sieve's estimated time. ECM spends its part working up the levels below. Then the sieve runs.
- Small leftovers. The same rule covers them. A fifth of a one-minute sieve is twelve seconds, which buys a short rho run and nothing more.
- Leftover over the cap. The sieve cannot run, so ECM is the only way forward and has no set end. After rho, P-1 and P+1 at their defaults, ECM works up levels 1 to 4 and then keeps running level 4 curves until a factor turns up or you stop it. When a factor leaves a part that fits the sieve, the rule above takes over.
- No sieve (tier 4, the CM). Rho runs without a cap on numbers of 20 digits or fewer. Larger leftovers get P-1 and then ECM in the same open-ended way. P+1 is left out of tier 4 to save memory. ECM finds nearly everything it would.
| ECM level | B1 | Curves | Aimed at factors of |
| 1 | 500 | 10 | 10 digits |
| 2 | 2,000 | 25 | 15 digits |
| 3 | 11,000 | 90 | 20 digits |
| 4 | 50,000 | 300 | 25 digits |

Levels 2 to 4 are the commonly quoted ECM settings. They assume a stronger second stage than this one, so treat the curve counts as starting values. Level 1 is my own guess.
### Work carries forward
Rho, P-1, P+1 and ECM each work on every prime factor of a number at once. So work done on a number has already been done on every part of it. When a factor is split off, the part that remains never repeats that work.
Work is counted in steps and curves, not in time, because the same curve is cheaper on a smaller number. Each composite carries three counts from its parent: rho steps done, the P-1 and P+1 bounds reached, and ECM curves done at each level.
When a part drops into sieve range, its fifth is worked out afresh at its new size. Carried work is taken off first. If the carried work already covers the fifth, the sieve starts at once.
For example, take a 50-digit number made of a 12-digit prime and two 19-digit primes.
- At 50 digits it is over the cap, so ECM starts and works up the levels.
- Say the 12-digit prime turns up on curve 9 of level 2. The 38-digit leftover now fits the sieve.
- The sieve would take about 6 hours, so the fifth is about 1.2 hours. At 38 digits that buys level 1 and little more.
- The leftover already carries all of level 1 and 9 curves of level 2. No more ECM is needed, and the sieve starts.
### What a fifth buys
| Leftover | Sieve, tier 1 | The fifth | How far ECM gets in it |
| 30 digits | 12 min | 2 min | Nowhere. A short rho run only |
| 36 digits | 2.3 h | 28 min | About 3 curves of level 1 |
| 40 digits | 14.5 h | 2.9 h | Level 1 and about 3 curves of level 2 |
| 44 digits | 2 to 3 days | 12 h | Level 1 and most of level 2 |
| 46 digits | 10 to 12 days | 2.2 days | Levels 1 and 2, and about 11 curves of level 3 |
| 49 digits, the cap | About 4 weeks | 5.6 days | Levels 1 and 2, and about 35 curves of level 3 |

A fifth is close to break-even. An ECM level finds a factor perhaps one time in four, so it is worth running only when it costs well under the sieve itself. A fixed fifth also scales the right way: the slower the sieve, the larger the factors ECM gets to reach for. The share should be tuned once real timings exist.
### No questions, just a visible estimate
FACTOR never stops to ask. Trial division, the power check and the prime check run first and take seconds, with each one named on the screen. Most numbers finish right there. For the rest, the program now knows the size of the leftover, so it works out the plan and carries straight on. The bottom line of the progress screen shows the estimate for the whole job.
ECM  C40  B1=500    
Curve 2/10  stage 1 
14%  left 0:58:00   
Job: up to 17 h     
The two-line machines show the job for two seconds each time a new step starts, then the usual progress lines.
C40 job to 17 h 
ECM then sieve  
Nothing waits for a key. ON/CLEAR pauses at any time, and Abandon on the pause screen drops the run.
Above the sieve cap there is no end to estimate, and the job line says so.
ECM  C60  B1=500    
Curve 1/10  stage 1 
Level 1 left 2:18:00
Job: no set end     

C60 no set end  
ECM level 1     
While it runs, the screen shows the level, the curve and the time left in that level. Each finished level rules out factors up to its size: about 10, 15, 20 and 25 digits.
ECM  C60  B1=11000  
Curve 12/90  stage 1
Level 3  left 16d 6h
Job: no set end     

ECM L3 12/90    
left 16d 6h     
### Pure sieve
QS(n) sends a number straight to the sieve, with no rho, P-1, P+1 or ECM first. It is the right call when the factors are known to be close in size, as with a number built from two similar primes. It refuses anything over the machine's sieve cap.
### When you stop it
An open-ended ECM run ends only when you stop it. The part still unfactored is then shown with a C label, along with how far ECM got. Keep and stop saves the curve counts, so RESUME carries on without repeating them. On the result screen, V and a letter stores the shown factor in a variable.
### Method notes
- Rho. The step is x squared plus c. If a batch GCD returns the whole number, the batch is replayed one step at a time. A failed run retries with a new c, up to three times.
- P-1. The base is 3. Stage 2 steps from prime to prime using a small table of powers, trimmed on the CM.
- P+1. One starting value is used. Each start has an even chance of acting as a second P-1, so extra starts are a possible tuning.
- ECM. Each curve comes from a starting number, called sigma, which is shown and logged. A lucky curve can then be repeated. Stage 1 is a Montgomery ladder.
- All methods stay in Montgomery form for the whole run and report which of them found each factor.
## The small quadratic sieve
The sieve is a multiple-polynomial quadratic sieve cut down to fit in 3,000 to 10,000 bytes. It is the one method here whose running time does not depend on luck, so it can promise a finish time.
### How it works
- Factor base. Take 2 and the smallest odd primes p for which the number N is a square modulo p. The memory tier sets how many at most: 64, 128 or 192.
- Polynomial. Pick a prime q, set a = q squared, and find b with b squared equal to N modulo a. Then (a x + b) squared minus N is divisible by a, and the quotient is small.
- Sieve. Walk x from -M to M in blocks. For each prime, add its logarithm at the two places in each stretch of p where it divides the quotient.
- Scan. A cell that reaches the threshold is probably a product of base primes. Trial division confirms it, and a confirmed cell is a relation. Only its value is stored.
- Repeat with a new q until there are nine more relations than primes.
- Combine. Free the sieve block and the position tables. Build the combining table in their place from the stored relations, which takes about a minute. Elimination then finds sets of relations whose product is a square. Each set gives a factor at least half the time.
### Memory plan
| Item | 64 primes | 128 primes | 192 primes |
| Tier | 3 | 2 | 1 |
| Bytes for each relation value | 15 | 19 | 20 |
| Relation values, held throughout | 1,095 | 2,603 | 4,020 |
| While sieving: prime tables, 9 bytes a prime | 576 | 1,152 | 1,728 |
| While sieving: sieve block | 1,024 | 2,048 | 2,048 |
| Total while sieving | 2,695 | 5,803 | 7,796 |
| While combining: prime list | 128 | 256 | 384 |
| While combining: combining table | 657 | 2,329 | 5,025 |
| While combining: pivot notes | 146 | 274 | 402 |
| Total while combining | 2,026 | 5,462 | 9,831 |
| Peak, bytes | 2,695 | 5,803 | 9,831 |

The relation values are sized for each tier's sieve cap: 15 bytes at 120 bits, 19 at 150 bits and 20 at 160 bits.
Three decisions keep these totals small.
- Relations store one number, not their prime powers. The number is (a x + b) divided by q, modulo N. Squaring it modulo N gives back the small quotient, which can be trial-divided again whenever its primes are needed.
- The combining table is built at the end. It is only needed once sieving is over, so it never shares memory with the sieve block. This is what lets 192 primes fit in 21,000 bytes.
- Elimination works in place. Once a column has been used as a pivot it is empty, so it is reused to record which rows were combined. No second table is needed. I tested this on 1,703 random cases in the prototype and every set it returned was valid.
A base of 256 primes would peak near 15,100 bytes for the sieve alone, about 1,000 more than tier 1 has to give. A base of 224 would fit with about 1,800 to spare and is listed as a stretch goal.
### Estimated times
I wrote this sieve in Python, ran it on random numbers with two prime factors of equal size, and counted its steps. The step counts were then priced in 6303 cycles.
| Digits | 64 primes | 128 primes | 192 primes |
| 20 | 35 s | 50 s | Not run |
| 24 | 4 min | 2 min | Not run |
| 28 | 15 min | 4 min | Not run |
| 32 | 3.1 h | 33 min | Not run |
| 36 | 1.4 days | 3.2 h | 2.3 h |
| 40 | 13 days | 21 h | 14.5 h |
| 44 | n/a | About a week | 2 to 3 days |
| 46 | n/a | About 4 weeks | 10 to 12 days |
| 48 | n/a | About 3 months | 3 to 4 weeks |
| 50 | n/a | About 10 months | 1 to 3 months |

An earlier run with 256 primes gave 6.5 hours at 40 digits and 22 hours at 44. That base does not fit in memory, but it shows the trend.
The program picks the base for the job. A 20-digit number uses 64 primes even on an LZ64, because the larger base only adds overhead at that size.
### The hard cap
The sieve refuses any number over its cap. The cap is 160 bits in tier 1, 150 bits in tier 2 and 120 bits in tier 3. Up to the cap, FACTOR sieves whatever the other methods leave, and shows its estimate as it starts.
| Tier | Primes | Cap | Digits | Time at the cap |
| 1 | 192 | 160 bits | 49 | About 4 weeks |
| 2 | 128 | 150 bits | 46 | About 4 weeks |
| 3 | 64 | 120 bits | 37 | About 3 days |

Tiers 1 and 2 are capped by patience: about four weeks, the same as a primality test at 8,192 bits. Tier 3 is capped by ECM, which overtakes its small sieve at about 37 digits. A run near a cap needs the mains adaptor and checkpoints.
A cap of 180 bits is out of reach. Each extra digit costs about 1.6 times as long, and one run at 52 digits with 192 primes came out at about two years.
### Where the caps come from
No cap is set above the size where ECM alone would beat the sieve, even on the worst case of two equal primes. Past that point the sieve is never the better choice, so the leftover stays with ECM.
| Leftover | 64 primes | 128 primes | 192 primes | ECM alone |
| 32 digits | 3.1 h | 33 min | Not run | 15 h |
| 36 digits | 1.4 days | 3.2 h | 2.3 h | 2.3 days |
| 38 digits | 5.6 days | 8 h | 6 h | 4.7 days |
| 40 digits | 13 days | 21 h | 14.5 h | 9.5 days |
| 44 digits | n/a | 1 week | 2 to 3 days | 5 weeks |
| 46 digits | n/a | 4 weeks | 10 to 12 days | 10 weeks |
| 48 digits | n/a | 3 months | 3 to 4 weeks | 4 months |
| 50 digits | n/a | 10 months | 1 to 3 months | 7 months |
| 52 digits | n/a | n/a | 3 months to 2 years | 14 months |

"ECM alone" is the time to reach factors half the leftover's length. ECM overtakes the sieve at about 37 digits with 64 primes, about 48 with 128 and about 52 with 192. Each cap sits at or below its crossover.
Every sieve figure is from prototype runs on two or three sample numbers, and single runs swing a lot. The 128-prime figures from 44 digits up are a smoothed line through runs that gave 5, 53 and 89 days at 44, 46 and 48 digits. The ECM column uses the optimistic standard curve counts. If the real program needs more curves, the crossovers move up a digit or two.
The 38-digit figures for 128 and 192 primes are interpolated.
### Assumptions behind the sieve times
Every sieve time in this section rests on these assumptions, and each could be out by a factor of two either way.
| Assumption | Value |
| One sieve update | 40 cycles |
| Filling and scanning one cell | 18 cycles |
| Setting up one polynomial | 1,000,000 cycles plus 6,000 a prime |
| Checking one candidate | 50,000 cycles plus 250 a prime |
| Sample | Two or three numbers at each size |

### What the prototype showed
- Polynomial set-up is a large share. At 40 digits with 192 primes, set-up takes 6.2 of the 14.5 hours. About 8,200 polynomials are needed.
- The sieve interval needs tuning on the machine. The best half-width M moved between 8,192 and 65,536 with no clear pattern. The starting value is 16,384.
- It beats ECM clearly on hard numbers. A 40-digit number with two 20-digit factors needs ECM level 3, about nine days. The sieve takes 14.5 hours with 192 primes.
The first finding points at the main upgrade. YAFU's sieve derives many polynomials from one set-up. Doing the same here with 192 primes would cut the 40-digit time from 14.5 hours to about 9, for roughly 1,500 bytes more. It is listed under stretch goals.
### Safety checks
- Each relation is verified when found: its square must equal the product of its primes modulo N.
- A square set that gives only the trivial factors is skipped, and the next set is tried.
- The nine spare relations give at least nine sets, so failing to split N is very unlikely.
## Primality
ISPRIME gives a quick answer that has never been known to be wrong. PROVE turns that answer into a certainty when the number allows it.
### The probable-prime test
| Step | What it does |
| 1. Small numbers | Below 100,000,000, trial division to 10,000 settles it outright |
| 2. Small factors | Trial division to 1,000 throws out most composites cheaply |
| 3. Strong test, base 2 | The Miller-Rabin test with base 2 |
| 4. Square check | A perfect square is composite. It must be caught here, because step 5 would never end on one |
| 5. Choose P | Q is fixed at 1. P starts at 3 and goes up by 1 until the Jacobi symbol of P squared minus 4 is -1. A symbol of 0 on the way means n shares a factor with that value, so n is composite |
| 6. Extra strong Lucas test | Grantham's test, run with that P and Q = 1 |

Steps 3 to 6 together are a Baillie-PSW test. A number that passes is labelled PRP. No composite is known that passes.
Step 6 works like this. Write n+1 as d times a power of 2, with d odd and s the power. The number passes if U at d is 0 and V at d is plus or minus 2, modulo n. It also passes if V at d times 2 to the r is 0 for some r from 0 to s-2. U and V are the Lucas sequences for P and Q = 1.
### Proven below 2 to the power 64
Below 2**64 a pass is labelled P, proven. Above it a pass is labelled PRP unless PROVE succeeds.
The guarantee comes from a computer search, not a theorem. Dana Jacobsen's pseudoprime page reports no Baillie-PSW pseudoprimes below 2**64 with any of four Lucas tests, the extra strong test included. The search rests on the complete lists of base-2 pseudoprimes in that range from Jan Feitsma and William Galway.
The guarantee holds only if the program matches that page exactly.
- The test is the extra strong test of Grantham's 2000 paper, theorem 2.3.
- The parameters are Q = 1 and P counted up from 3, as in step 5. The page credits this choice to OEIS sequence A217719 and Wikipedia.
- Q must be 1. The page warns that Q = -1 gives a completely broken test.
The extra strong form is chosen for two reasons.
- Half the work. Each bit costs one squaring and one multiplication, not two of each.
- Less memory. It tracks two numbers where the standard form tracks three. That matters on the CM.
### Proofs
PROVE(n) first checks that n is a probable prime, then tries these in order.
| Method | Needs | Result label |
| Small | n below 2**64 | P at once |
| N-1, half | Prime factors of n-1 whose product passes the square root of n | PROVED by N-1 |
| N-1, one third | The product passes the cube root of n, plus one extra square test | PROVED by N-1 |
| N+1 | Prime factors of n+1 whose product passes the square root of n | PROVED by N+1 |

The N-1 methods are Pocklington's theorem and its extension by Brillhart, Lehmer and Selfridge. The N+1 method is Morrison's theorem, which uses a Lucas sequence in place of a power. Their 1975 paper is the reference for the exact conditions.
The factoring uses the same chain as FACTOR and stops as soon as enough is factored. Each prime it relies on must itself be proven. Primes below 2**64 are free. A larger one is proved the same way, one level down.
When no proof is found the screen says how far it got, such as N-1 31% factored. More ECM curves run by hand on the leftover may then finish the job.
### Certificates
A proof is kept as a short list that can be checked by hand or on another machine. This is a real one, for the first prime after 10**30.
PROVE(10**30+57)
P31 by N-1 (one third)
q=2       a=5
q=3       a=2
q=79043   a=2
q=3998741 a=2
square test passed
Each line names a prime factor q of n-1 and a witness a. The witness must satisfy two conditions: a to the power n-1 is 1 modulo n, and a to the power (n-1)/q, less 1, shares no factor with n.
### Mersenne numbers
LLT(p) runs the Lucas-Lehmer test on 2**p-1. It is a full proof and much faster than the general test, because reducing modulo 2**p-1 needs no division.
| p | Digits | Estimated time |
| 127 | 39 | 1.4 s |
| 521 | 157 | 79 s |
| 1279 | 386 | 18 min |
| 2203 | 664 | 1.5 h |
| 4423 | 1,332 | 12 h |

4423 is the largest Mersenne prime exponent that fits the 8,192-bit cap. In the 2,048-bit tiers the largest is 1279.
### Next and previous prime
NEXTPRIME sieves a short window of candidates by the primes below 10,000. Survivors get the base-2 test, and only a number that passes gets the Lucas test. Near 10**30 that takes about 10 seconds. Near 10**100 it takes about a quarter of an hour.
## Time estimates
Arithmetic is quick at every size. Number theory on big numbers is slow, and the program says how slow as it starts.
Every figure in this section comes from a cost model, not from a real machine. The model assumes 921,600 cycles a second and 50 cycles for each pair of bytes multiplied. That is about 18,000 byte products a second. BENCH replaces the assumptions with measurements.
### What is practical
| Job | In minutes | Overnight | Days or more |
| Probable-prime test | Up to 155 digits | Up to 617 digits | 1,234 digits and above |
| Factor any number, tier 1 (LA, LZ, LZ64) | Up to 28 digits | 40 digits | 44 digits and above |
| Factor any number, tier 2 (XP) | Up to 28 digits | 36 digits | 40 digits and above |
| Factor any number, tier 3 | Up to 28 digits | 32 digits | Beyond that |
| Factor any number, tier 4 (CM) | Up to 20 digits | 24 digits | Beyond that |
| Find a factor of up to 8 digits | In numbers up to 60 digits | In much larger numbers | n/a |
| Find a 15-digit factor by ECM | No | No | About a day at 60 digits |

"Any number" means the worst case: two prime factors of equal size. Most numbers have a small factor and fall much faster.
### Arithmetic
| Bits | Digits | Multiply | Square | Modular multiply |
| 64 | 20 | 4 ms | 3 ms | 9 ms |
| 128 | 39 | 15 ms | 10 ms | 31 ms |
| 256 | 78 | 58 ms | 36 ms | 116 ms |
| 512 | 155 | 0.2 s | 0.1 s | 0.5 s |
| 1,024 | 309 | 0.9 s | 0.5 s | 1.8 s |
| 2,048 | 617 | 3.6 s | 2.2 s | 7.1 s |
| 4,096 | 1,234 | 14 s | 9 s | 29 s |
| 8,192 | 2,467 | 57 s | 34 s | 2 min |

### Primality
| Bits | Digits | Base-2 test | Lucas test | Both |
| 64 | 20 | 0.5 s | 1.0 s | 1.5 s |
| 128 | 39 | 3.3 s | 7.1 s | 10 s |
| 256 | 78 | 24 s | 54 s | 78 s |
| 512 | 155 | 3 min | 7 min | 10 min |
| 1,024 | 309 | 25 min | 55 min | 80 min |
| 2,048 | 617 | 3.3 h | 7.3 h | 10.6 h |
| 4,096 | 1,234 | 26 h | 2.4 days | 3.5 days |
| 8,192 | 2,467 | 8.6 days | 19 days | 28 days |

Each doubling of size multiplies the time by eight. A composite number usually fails in trial division or in the base-2 test, so a "no" arrives in a third of the time or less.
### Pollard rho
| Number | Steps a second | 6-digit factor | 8-digit factor | 10-digit factor | 12-digit factor |
| 20 digits | 48 | 19 s | 3 min | 31 min | 5.2 h |
| 30 digits | 26 | 35 s | 6 min | 59 min | 9.8 h |
| 40 digits | 16 | 57 s | 10 min | 1.6 h | 16 h |
| 60 digits | 8 | 2 min | 20 min | 3.3 h | 33 h |

These are average times. A run can take a few times longer or shorter.
### P-1, first stage
| Number | B1 = 2,000 | B1 = 11,000 | B1 = 50,000 |
| 20 digits | 35 s | 3 min | 15 min |
| 30 digits | 67 s | 6 min | 28 min |
| 40 digits | 2 min | 10 min | 46 min |
| 60 digits | 4 min | 21 min | 1.6 h |
| 100 digits | 11 min | 58 min | 4.4 h |

### ECM, one curve with both stages
| Number | B1 = 500 | B1 = 2,000 | B1 = 11,000 | B1 = 50,000 |
| 20 digits | 2 min | 8 min | 45 min | 3.4 h |
| 30 digits | 4 min | 16 min | 87 min | 6.6 h |
| 40 digits | 7 min | 26 min | 2.4 h | 11 h |
| 60 digits | 14 min | 54 min | 5.0 h | 23 h |
| 100 digits | 37 min | 2.5 h | 14 h | 2.6 days |

ECM is the slowest method here by a wide margin. At 60 digits, level 1 takes about 2.3 hours, level 2 about 22 hours and level 3 about 19 days. That is why the sieve earns its place for every number up to its cap.
### Other
| Job | Estimated time |
| Trial division to 10,000, 40-digit number | 2.5 s |
| Trial division to 10,000, 617-digit number | 34 s |
| Trial division to 10,000, 2,467-digit number | 2 min |
| Add or subtract at 8,192 bits | 16 ms |
| Show a 2,467-digit result | 31 s |

Sieve times are in the quadratic sieve section, and Lucas-Lehmer times are in the primality section.
## Long runs
A long run always shows where it is and, when it has an end, when that should be. It can be stopped at any moment. Checkpoints are optional and off by default, so the program needs no pack space to work.
### Progress and time left
| Method | Progress is measured in |
| Primality tests, MODEXP, LLT | Bits done out of bits to do |
| Pollard rho | Steps done out of the cap |
| P-1, P+1 | Primes passed in the current stage |
| ECM | Curve number, and primes passed within the curve |
| Quadratic sieve | Relations found out of relations needed |

The time left is worked out from the Organiser's own clock: time so far, scaled by the work remaining. The sieve waits for five relations before showing one, since early guesses swing wildly.
Rho, P-1, P+1 and ECM may never find a factor. Their time left counts down to the end of their allowance, not to a result. Above the sieve cap ECM has no allowance, so it shows the time left in the current level.
### Stopping
The program checks for ON/CLEAR at least every two seconds, including inside a single large multiplication. The pause screen then offers four choices.
| Choice | Effect |
| Continue | Carries on where it stopped |
| Skip | Moves to the next method in the chain |
| Keep and stop | Writes a checkpoint, then returns to the entry line |
| Abandon | Returns to the entry line with nothing kept |

Factors already found are never lost. They are shown, and logged if the log is on, whichever choice is made.
### Checkpoints
SET KEEP B: turns checkpoints on and names the device. A checkpoint is then written every EVERY minutes and on Keep and stop. RESUME shows the saved job and asks before continuing it.
Tier 4 has no checkpoints, no log and no SAVE or LOAD. Its pause screen offers Continue, Skip and Abandon only.
| Method | What is saved | Size at the largest job |
| Base-2 test, MODEXP, LLT | Bit position and one number | 2K |
| Lucas test | Bit position and two numbers | 4K |
| Pollard rho | Step count and three numbers | Under 1K |
| P-1, P+1 | Prime reached and one or two numbers | Under 1K |
| ECM | Curve number, sigma, prime reached and two numbers | Under 1K |
| Quadratic sieve | Each relation as it is found | 5K for 128 primes, 8K for 192 |

Numbers are written as text, two characters a byte, in records of up to 254 characters. That doubles their size but keeps the file readable through the Comms Link. Each checkpoint also holds the line that started the run and a checksum.
Two things differ from YAFU. A single ECM curve can be resumed part-way, because one curve can take hours here. And only one job is kept at a time.
### Choosing the device
- Rampak or A:. Best for timed checkpoints, since the old one is replaced each time.
- Datapak. Space used on a Datapak is not freed until the pack is erased. Timed checkpoints would eat it, so the program writes only on Keep and stop. Sieve relations are the exception. They are only ever added, so a Datapak suits them.
- A:. Shares memory with the working numbers. The program checks there is room before it starts.
### Results log
SET LOG B: appends every finished result to a text file: the line typed, the answer, the method that found each factor and the time taken. This is the counterpart of YAFU's session log. Certificates from PROVE go in the same file.
### Power
A run of many hours should use the mains adaptor. Battery life under continuous computing and the behaviour on low battery both need testing on real hardware.
## Memory and pack budget
The CM is the tight case. It fits on paper with about 800 bytes to spare, which makes it the biggest risk in this design.
All figures here are estimates in bytes.
### Memory while running
| Item | Tier 4 | Tier 3 | Tier 2 | Tier 1 |
| Arithmetic core | 1,500 | 1,500 | 1,500 | 1,500 |
| One method module | 400 | 600 | 600 | 600 |
| OPL procedures loaded at once | 1,500 | 2,000 | 2,000 | 2,000 |
| OPL variables, entry line, recall | 400 | 700 | 700 | 1,200 |
| Writing a checkpoint or log line | None | 1,000 | 1,000 | 1,000 |
| Largest job | 1,800 | 3,300 | 6,700 | 10,400 |
| Peak, and the tier's threshold | 5,600 | 9,100 | 12,500 | 16,700 |
| Usual machine | CM | A full XP or LZ | XP | LA, LZ, LZ64 |
| Typically free on that machine | 6,400 | n/a | 14,000 | 21,000 |
| Spare | 800 | n/a | 1,500 | 4,300 |

The largest job is whichever is bigger: a full-size primality test or a sieve at the tier's base size. They never run together, because the sieve only takes small numbers.
| Largest job | Tier 4 | Tier 3 | Tier 2 | Tier 1 |
| Primality test at the size cap | 1,800 | 1,800 | 6,700 | 6,700 |
| Sieve at its peak, plus small numbers | None | 3,300 | 6,400 | 10,400 |

Writing a checkpoint loads one more procedure and a file buffer, about 1,000 bytes in all. Tiers 1 to 3 allow for it. Tier 4 cannot, which is why it has no saving.
A primality test needs four numbers and one double-length product. At 2,048 bits that is 1,550 bytes. At 8,192 bits it is 6,150. The table adds 250 to 550 bytes for stored variables.
### The CM
You gave about 6,400 bytes free on a CM, which puts it in tier 4. The plan uses 5,600 and leaves about 800 spare. During a full-size primality test there is room for about 1,000 bytes of stored variables. Everyday work on smaller numbers leaves over 2,000.
Four savings are already applied to tier 4: no saving, an entry line of 128 characters, no P+1, and the smaller OPL procedures used on every tier. These further ones are held back as fallbacks.
| Fallback saving in tier 4 | Bytes | Cost |
| No recall of the previous line | 130 | Retype after a mistake |
| Several base tests in place of the Lucas test | 500 | A weaker probable-prime answer above about 24 digits |
| A 1,024-bit cap | 770 | Half the number size |

With about 800 bytes spare on paper, none of these is needed yet. They are there in case the real code comes out larger than planned. You have agreed the 1,024-bit cap as the last resort.
Measure the CM early. Milestone 3 in the build order is the place.
### The other machines
- XP. 14,000 bytes free puts it in tier 2, with about 1,500 to spare.
- LA, LZ and LZ64. 21,000 bytes free puts them in tier 1, with about 4,300 to spare.
- Any machine with a full A:. It drops a tier or two. Moving files to a pack and restarting the program restores it.
### Savings ideas, not applied
These are possible memory savings for later. None is in the budget above, and all figures are estimates in bytes.
| Idea | CM | XP | LA, LZ, LZ64 | Cost |
| Unload the running procedure before writing a checkpoint | n/a | 600 | 600 | Checkpoints take slightly longer |
| Keep recalled lines in one small shared buffer | 130 | 250 | 700 | Very long lines cannot be recalled |
| Run the primality test with three working numbers, not four | 250 | 300 | 0 | None, just careful ordering of the steps |
| Load the division and root routines only when needed | 350 | 350 | 350 | A short pause on first use, and more complexity |
| Total | 730 | 1,500 | 1,650 |  |
| Spare if all were applied | About 1,500 | About 3,000 | About 5,950 |  |

- Checkpoints. A checkpoint is a point where the run can be picked up again. So the running procedure can step aside while the save happens, and the two never sit in memory together.
- Recall. On the CM the previous line can be left in the entry buffer, so recall costs nothing. On the larger machines most lines are 10 to 30 characters, so full-length copies are wasteful.
- Primality. The Lucas test can write each result over a number it no longer needs. This saves nothing in tier 1, where the sieve sets the peak.
- Division. Long modular runs never divide, so those routines need not stay loaded. This idea adds the most complexity and should come last.
Tier 1 already has room on paper for a sieve of 224 primes. If all four ideas were applied, 256 primes would just fit as well.
### Pack space
| Part | Size |
| Arithmetic core | 1,500 |
| Method modules | 2,500 |
| Line reader, parser and evaluator | 3,500 |
| Number input, output and pager | 1,500 |
| Function library | 2,500 |
| Factor chain and result screens | 2,000 |
| Primality, proofs and certificates | 2,500 |
| Sieve driver and elimination | 2,500 |
| Settings, menu and help | 1,500 |
| Checkpoints, log, save and load | 2,000 |
| Total | 22,000 |

Splitting the OPL into small procedures adds perhaps 1,000 bytes on top. The program still fits a 32K pack, with about 9,000 bytes left for the log and checkpoints. Treat the total as good to within a third either way.
## Program structure
OPL handles everything a person sees. Machine code does everything that takes time.
### Layers
| Layer | Written in | Does |
| Shell | OPL | Entry line, menu, screens, pager, settings, files |
| Evaluator | OPL | Turns a line into a list of steps, then runs them in order |
| Drivers | OPL | One per long job. Sets up, calls a module, shows progress, handles stopping |
| Method modules | Machine code | The inner loops: powers, Lucas steps, rho batches, curve steps, sieve blocks, row combining |
| Arithmetic core | Machine code | Add, subtract, multiply, square, divide, reduce, shift, compare, memory block |

### Rules that keep it fast and small
- No OPL inside a hot loop. A module runs a slice of one to two seconds of work, then returns. The driver updates the screen, checks the keys and calls it again. OPL's overhead is paid once a slice.
- Flat calls. The main loop calls the parser, which returns. It then calls one driver, which returns. Only the main loop and one other procedure are ever loaded together.
- Small procedures. Nothing that loads on the CM is over about 1,000 bytes, and nothing elsewhere is over about 1,500. A long driver is split into a set-up part, a run part and a finish part that load one at a time. This saves about 500 bytes of memory on every tier. It costs perhaps 1,000 bytes more on the pack and a short pause as each part loads.
- One hand-over block. OPL and machine code pass pointers and counts through a single block at a fixed place.
- Modules load on demand. The core loads once at start-up. A method module loads when its method starts and is dropped when it ends.
- One build. The same pack runs on all five machines. The CM simply never loads the sieve or P+1.
The core and the modules are loaded the same way as the machine code in your other Organiser programs.
### One line, start to finish
- The shell reads the line.
- The parser checks it and writes the steps in reverse Polish order.
- The evaluator runs the steps. Numbers go on a stack inside the memory block. Operators call the core. Functions call a driver.
- The result goes to ANS and to the result screen.
- If the log is on, the line and the result are appended.
### Procedures
| Name | Job |
| BIGNUM | Start-up, memory sizing and the main loop |
| BNPARSE, BNEVAL | Parser and evaluator |
| BNFUNC | Short functions: GCD, roots, modular functions, sequences |
| BNSHOW, BNPAGE | Result screens and the number pager |
| BNFACT | The factoring chain |
| BNRHO, BNPM1, BNECM, BNQS | Method drivers |
| BNPRP, BNPROVE | Probable-prime test, proofs and certificates |
| BNSET, BNKEEP, BNBENCH | Settings and menu, checkpoints and log, benchmark |

Long drivers are split further into set-up, run and finish parts, as the small-procedures rule requires.
### Build order
- Core, number input and output, and the four operators on the LZ in the emulator.
- Parser, variables, pager and both screen sizes.
- Modular functions, BENCH and the memory tiers. First real timings, and the first CM memory check.
- ISPRIME, NEXTPRIME and LLT.
- Trial division, rho, P-1, P+1 and the FACTOR chain.
- ECM.
- The quadratic sieve.
- PROVE and certificates.
- Checkpoints, log, save and load.
- Fitting the CM.
- Real hardware.
Each milestone leaves a usable program. After milestone 5 it already factors most numbers people will type.
## Test plan
Every answer this program gives can be checked on a PC. So the tests are lists of known answers, run first on the emulator and then on real hardware.
### Known answers
I checked each of these on a PC.
| Line | Expected result |
| 2**127-1 | 170141183460469231731687303715884105727 |
| FACTOR(2**64+1) | 274177 and 67280421310721 |
| FACTOR(2**67-1) | 193707721 and 761838257287 |
| FACTOR(10**30+1) | 61, 101, 3541, 9901, 27961, 4188901 and 39526741 |
| FACTOR(FACT(25)+1) | 401 and 38681321803817920159601 |
| FACTOR(FACT(30)) | 2^26, 3^14, 5^7, 7^4, 11^2, 13^2, 17, 19, 23, 29 |
| FACTOR(2**101-1) | 7432339208719 and 341117531003194129. A 31-digit sieve job |
| FACTOR(2**128+1) | 59649589127497217 and 5704689200685129054721. A 39-digit sieve job |
| ISPRIME(10**50+151) | 1 |
| NEXTPRIME(10**20) | 100000000000000000039 |
| NEXTPRIME(10**30) | 1000000000000000000000000000057 |
| PROVE(2**127-1) | Proved by N+1 |
| PROVE(10**30+57) | Proved by N-1, with the certificate shown in the primality section |
| LLT(127), LLT(521) | 1 |
| LLT(131) | 0. 263 divides it |

### Numbers chosen to break things
| Test | Why |
| 3215031751 and 3825123056546413051 | Composites that pass the base-2 test. The Lucas test must reject them |
| 2047, 3277, 4033, 4681, 8321 | The five smallest composites that pass the base-2 test. Run them through the test alone, with trial division off |
| 561, 1105, 1729 | Carmichael numbers |
| FACTOR(7**40), FACTOR((10**15+37)**2) | Perfect powers |
| FACTOR(0), FACTOR(1), FACTOR(-12) | Odd inputs must give a sensible answer or BAD ARG |
| 2**8191 and 2**8192 | The largest allowed power of 2, then TOO BIG. In the 2,048-bit tiers, use 2047 and 2048 |
| (2**1024-1)*(2**1024-1) | Every carry at once |
| (A/B)*B+A%B for random A and B | Must equal A, including for negative values |
| QS on a prime, a prime power and a number with a small factor | The sieve must fail cleanly |
| QS on a number one bit over the tier's cap | Must refuse with NOT AVAILABLE |
| PP1, SAVE and RESUME in tier 4 | Must refuse with NOT AVAILABLE |
| A number that loses a factor to ECM and then fits the sieve | Carried work must be credited, with no ECM curve repeated |

The prime test also needs checking against published lists, because its guarantee below 2**64 depends on matching them exactly. Every term of OEIS A217719 in range must pass the Lucas step on its own and fail the base-2 step.
### Cross-checks against YAFU
- Generate random numbers of 10 to 49 digits on the PC.
- Factor each with YAFU.
- Run the same lines here with the log on.
- Pull the log over the Comms Link and compare the two lists.
The same loop works for ISPRIME, NEXTPRIME, MODEXP and the sequence functions.
### PC twin
A PC version of the sieve and of ECM, using the same settings as this spec, settles two things before they are fixed.
- Sieve caps. The 160, 150 and 120-bit caps rest on two or three sample runs each. Run a few hundred numbers at each size.
- ECM curve counts. The standard counts assume a stronger second stage than this program has. Measure how many curves each factor size really needs, and redo the crossovers that depend on them.
### Machines
- Emulator, all 29 ROMs. Run the short list on every ROM. It takes minutes and catches ROM differences.
- Emulator, one ROM per model. Run the long list, including the sieve jobs and a 2,048-bit primality test.
- Tiers. Fill A: on an emulated LZ to force each tier in turn. Check that the limits, the sieve cap and the entry-screen line change to match, and that tier 4 offers no saving.
- CM. Watch free memory through every method. This is where the design is tightest.
- Real hardware, near the end. Timing, key response during long runs, pack writes to a Datapak and a Rampak, battery life and low-battery behaviour.
### Timing
Run BENCH on the emulator and on a real machine, and compare both with the model. Emulator speed may not match the hardware. The real figures replace the tables in this document.
## Stretch goals and what is left to settle
The first version is complete without anything in this section. The stretch goals are ordered by how much they buy.
### Stretch goals
| Goal | Gain | Cost |
| Many polynomials from one set-up, as YAFU's sieve does | About a third faster from 36 digits up | About 1,500 bytes and a harder set-up step |
| A sieve of 224 primes in tier 1 | Faster from about 40 digits up. Not yet measured | About 2,500 of the 4,300 bytes spare |
| A tiny sieve of about 32 primes in tier 4 | Might cut 24-digit numbers on the CM from hours to under an hour. Not yet measured | Must fit in the space the primality test uses |
| Choose a multiplier for N before sieving | Steadier sieve times from number to number | Small |
| Karatsuba multiplication above 512 bits | Perhaps a quarter off big multiplies | A few hundred bytes of code and more working space |
| Combined N-1 and N+1 proofs | Proves more numbers | Moderate |
| Partial relations with one large prime | Faster sieve | Needs space for partials, probably on a pack |
| RAND and RSA test numbers, as in YAFU | Handy for demos | Small |
| Hex and binary | Not asked for | Small |

### Left to settle by measurement
No design questions are open. Three things wait on real measurements.
- Cycle costs. Every time in this spec assumes 50 cycles for each pair of bytes multiplied. BENCH on a real machine replaces that.
- Sieve caps. Provisional until the PC twin has run a larger batch.
- ECM curve counts. Starting values until the PC twin has measured them.