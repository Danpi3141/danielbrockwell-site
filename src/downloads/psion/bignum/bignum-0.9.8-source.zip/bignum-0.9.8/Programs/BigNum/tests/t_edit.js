// The entry line against a model: typing, the cursor, DEL both ways, lines too long, recall (and what is lost when it is
// full), the screen showing the part round the cursor.   node tests/t_edit.js [model] [seed] [keys]
'use strict';
const { BN, HZ, rng } = require('./lib');
const model = process.argv[2] || 'lz64', R = rng(+process.argv[3] || 1), N = +process.argv[4] || 3000, pick = (a) => a[R.int(a.length)];
const g = new BN(model, process.env.BB ? { build: process.env.BB } : {}).start(), m = g.m; g.wait();
const lmax = g.peek('kv_lmax'), small = g.peek('kv_tier') === 4, room = g.peekw('kv_recn');
let s = '', c = 0, rec = [], ri = 0, last = '', bad = 0; const hist = [];
const fail = (t) => { console.log(`FAIL ${model}: ${t}\n${g.text()}\n${hist.slice(-20).join(' ')}`); if (++bad > 3) process.exit(1); };
const put = (k) => { hist.push(k > 32 ? String.fromCharCode(k) : k); g.wait(); m.poke(0x76, k); m.run(2500); g.wait(); };
const line = () => { const a = g.peekw('kv_line'); return String.fromCharCode(...m.read(a + 1, m.peek(a))); };
const check = () => {
  if (line() !== s || g.peek('kv_cur') !== c) { fail(`line ${JSON.stringify(line())} cursor ${g.peek('kv_cur')}; want ${JSON.stringify(s)} ${c}`); s = line(); c = g.peek('kv_cur'); }
  // the screen: the row has a > and a part of the line round the cursor
  const W = m.cols, row = g.lines()[g.peek('kv_rw')], ws = g.peek('kv_ws');
  if (row[0] !== '>' || row.slice(1) !== s.slice(ws, ws + W - 1).padEnd(W - 1)) fail(`row ${JSON.stringify(row)} from ${ws}, line ${JSON.stringify(s)}`);
  if (c < ws || c > ws + W - 1) fail(`cursor ${c} not in sight from ${ws}`);
};
for (let i = 0; i < N; i++) {
  const k = R.int(40);
  if (k < 18) { const n = R.int(30) ? 1 : 1 + R.int(120); for (let j = 0; j < n; j++) { const ch = pick('0123456789+-*/()ABCXYZ,abc ="'.split('')); put(ch.charCodeAt(0)); if (s.length < lmax) { if (s.length === 0) last = ''; const u = ch.toUpperCase(); s = s.slice(0, c) + u + s.slice(c); c++; } } }
  else if (k < 22) { put(5); if (c) c--; }
  else if (k < 26) { put(6); if (c < s.length) c++; }
  else if (k < 30) { put(8); if (c) { c--; s = s.slice(0, c) + s.slice(c + 1); } }
  else if (k < 32) { put(7); if (c < s.length) s = s.slice(0, c) + s.slice(c + 1); }
  else if (k < 35) { put(3); if (small) { if (!s && last) { s = last; c = s.length; } } else if (ri < rec.length) { ri++; s = rec[ri - 1]; c = s.length; } }
  else if (k < 36) { put(4); if (!small && ri) { ri--; if (ri) { s = rec[ri - 1]; c = s.length; } else { s = ''; c = 0; } } else if (small) { /* nothing */ } }
  else if (k < 37 && s) { put(1); last = s; s = ''; c = 0; ri = 0; }        // (the smallest tier: UP brings it back)
  else if (k < 39) {                                  // a line worked out, or an error
    const t = pick(['1+1', '2**10', String(R.int(1e6)), '7*' + '1'.repeat(1 + R.int(Math.min(200, lmax - 10))), 'ABS(5)', '3+'.repeat(1 + R.int(40)) + '4']).slice(0, lmax);
    while (s) { put(1); last = s; s = ''; c = 0; } ri = 0;
    for (const ch of t) put(ch.charCodeAt(0));
    if (line() !== t) fail(`typed ${t}: ${line()}`);
    put(13); for (let j = 0; j < 4 && !g.atLine(); j++) put(1);
    if (!g.atLine()) { fail('not back'); process.exit(1); }
    const e = g.peek('kv_err'); if (rec[0] !== t) { rec.unshift(t); let n = 0; rec = rec.filter((x) => (n += x.length + 1) <= room - 0 && n < room + 1); }
    last = t; s = e ? t : ''; c = e ? g.peek('kv_cur') : 0; ri = 0; 
    if (e) { put(1); s = ''; c = 0; last = t; }
  }
  check();
  if (!small) { const q = g.peekw('kv_rec'); let a = q; for (let j = 0; j < rec.length; j++) { const n = m.peek(a); const t = String.fromCharCode(...m.read(a + 1, n)); if (n === 0) { if (rec.slice(0, j).reduce((x, y) => x + y.length + 1, 0) + rec[j].length + 1 < room - 1) fail(`line ${j} not kept: ${rec[j]}`); rec.length = j; break; } if (t !== rec[j]) { fail(`kept ${j}: ${t}; want ${rec[j]}`); rec[j] = t; } a += n + 1; } if (m.peek(a) !== 0 && rec.length && a < q + room) { const t = String.fromCharCode(...m.read(a + 1, m.peek(a))); rec.push(t); } }
}
console.log(bad ? `${bad} FAILED` : `t_edit ${model} ok (${N} keys)`);
process.exit(bad ? 1 : 0);
