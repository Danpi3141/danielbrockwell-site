// The factors' screen: the power after the prime (also where the prime is cut), on four lines and two; S: the result added to
// the log on a device, its records, what cancels it, an S meant to skip that comes late, a device that is not there.
//   node tests/t_factors.js [model]
'use strict';
const { BN, HZ } = require('./lib');
const model = process.argv[2] || 'lz64';
let bad = 0, n = 0; const fail = (s) => { console.log('FAIL', s); bad++; };
const g = new BN(model, /cm/.test(model) ? {} : { packC: { type: 1, size: 32 } }).start(), m = g.m; g.wait();
const four = g.four, small = g.peek('kv_tier') === 4, W = four ? 20 : 16;
const home = () => { for (let i = 0; i < 8 && !g.atLine(); i++) { g.inject('ON'); g.wait(); } };
const pw = (a, e, q) => { let r = 1n; a %= q; for (; e; e >>= 1n) { if (e & 1n) r = r * a % q; a = a * a % q; } return r; };
const prp = (v) => [2n, 3n, 5n, 7n, 11n, 13n].every((a) => v === a || (v % a && pw(a, v - 1n, v) === 1n));
// the lines a factor should have
const want = (p, e, j, of) => {
  const lab = (p < 1n << 64n ? 'P' : prp(p) ? 'PRP' : 'C') + String(p).length, x = e > 1 ? '^' + e : '';
  const fit = (w) => (String(p).length + x.length <= w ? String(p) : String(p).slice(0, w - 3 - x.length) + '...') + x;
  if (four) { const l = lab.padEnd(3) + ' '; return [l + fit(W - l.length)]; }
  return [lab.padEnd(W - (of > 9 ? 6 : 4)) + `${j + 1}/${of}`, fit(W)];
};
const CASES = [
  ['3**4*5*7**2*1009', [[3n, 4], [5n, 1], [7n, 2], [1009n, 1]]],
  ['2**1030', [[2n, 1030]]], ['3**99*(10**9+7)', [[3n, 99], [1000000007n, 1]]],
  ['(10**15+37)**2*11', [[11n, 1], [1000000000000037n, 2]]], ['(10**17+3)**3', [[100000000000000003n, 3]]],
  ['(10**24+7)**3', [[10n ** 24n + 7n, 3]]], ['(10**20+39)**10', [[10n ** 20n + 39n, 10]]], ['(2**61-1)**12', [[2n ** 61n - 1n, 12]]],
  ['FACT(30)', [[2n, 26], [3n, 14], [5n, 7], [7n, 4], [11n, 2], [13n, 2], [17n, 1], [19n, 1], [23n, 1], [29n, 1]]],
];
for (const [l, f] of CASES) {
  home(); const r = g.line(`FACTOR(${l})`, 1e6); n++; if (r.err) { fail(`${l}: ${r.err}`); continue; }
  for (let i = 0; i < f.length; i++) {
    const t = g.lines().map((x) => x.trimEnd());
    const w = four ? [...want(...f[i], i, f.length), ...(i + 1 < f.length ? want(...f[i + 1], i + 1, f.length) : [])] : want(...f[i], i, f.length);
    const got = four ? t.slice(1, 1 + w.length) : t; if (w.map((x) => x.trimEnd()).join('|') !== got.join('|')) fail(`${l}, factor ${i}: [${got.join('|')}] want [${w.join('|')}]`);
    if (i + 1 < f.length) { g.inject('DOWN'); g.wait(); }
  }
}
// ---- S
const bottom = () => g.lines()[four ? 3 : 1].trim();
const recs = () => { home(); g.line('LOG'); if (!/Log on A, B, C/.test(g.text())) { fail('LOG: ' + g.text()); return []; } g.inject('C'); g.wait(60); if (/No log/.test(g.text())) { g.inject('ON'); g.wait(); home(); return []; }
  const out = []; let last = ''; for (let i = 0; i < 60; i++) { const t = g.lines().map((x) => x.slice(0, W)).join('').trimEnd(); if (t === last && i) break; out.unshift(t); last = t; g.inject('UP'); g.wait(60); } home(); return out; };
home(); g.line('FACTOR(3**4*5*7**2*1009)'); const top0 = g.lines().join('|');
g.inject('S'); g.wait();
if (small) { if (g.lines().join('|') !== top0) fail('S on the smallest tier: ' + g.text()); } else {
  if (bottom() !== 'Save on A, B, C?') fail('S: ' + g.text());
  for (const k of ['S', 'ON', 'EXE', 'D', 'P', 'M', 'V', 'SPACE', 'UP']) { g.inject(k === 'SPACE' ? ' ' : k); g.wait(); if (g.lines().join('|') !== top0) fail(`S ${k}: ${g.text()}`); g.inject('S'); g.wait(); if (bottom() !== 'Save on A, B, C?') fail('S again: ' + g.text()); }
  g.inject('ON'); g.wait();
  if (recs().length) fail('something was written by a cancelled S');
  // written, from the third factor on: the same one is still at the top
  g.line('FACTOR(3**4*5*7**2*1009)'); g.inject('DOWN'); g.wait(); g.inject('DOWN'); g.wait(); const t2 = g.lines().join('|');
  g.inject('S'); g.wait(); g.inject('C'); g.wait(120); if (bottom() !== 'Saved: C:BIGLOG') fail('saved: ' + g.text()); g.inject('UP'); g.wait(); if (g.lines().join('|') !== t2) fail('after it: ' + g.text() + ' was ' + t2);
  g.inject('DOWN'); g.wait(); g.inject('V'); g.wait(); g.inject('X'); g.wait(); if (g.vars().X !== 1009n) fail('V after it: ' + g.vars().X);
  if (g.peek('st_log') !== 0) fail('the setting LOG is ' + g.peek('st_log'));
  let w = ['FACTOR(3**4*5*7**2*1009)', 'P1 3^4 Trial division', 'P1 5 Trial division', 'P1 7^2 Trial division', 'P4 1009 Trial division']; let got = recs();
  if (got.slice(0, 5).join('|') !== w.join('|') || !/^time /.test(got[5]) || got.length !== 6) fail('records: ' + got.join('|'));
  g.line('FACTOR((10**24+7)**3)', 1e6); g.inject('S'); g.wait(); g.inject('C'); g.wait(120); g.inject('EXE'); g.wait(); got = recs();
  if (got[7] !== 'PRP25 1000000000000000000000007^3 Power'.slice(0, 2 * W < 40 ? 32 : 80)) fail('records: ' + got.join('|'));
  // an S pressed as the job ends (it is in the keyboard's buffer when the screen comes): nothing is asked
  home(); const l = 'FACTOR(10007*10009)'; m.write(g.peekw('kv_line'), [l.length, ...[...l].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', l.length); m.poke(0x76, 13); m.run(3000);
  const fi = g.meta.ovl.indexOf('ov_fshow') + 1; let hit = false; for (let i = 0; i < 4000000 && !hit; i++) { m.run(200); hit = g.peek('kv_res') === fi; } m.poke(0x76, 83); m.run(2000); g.wait(); g.run(0.5); g.wait();
  if (!hit || /Save/.test(g.text()) || !/10007/.test(g.text())) fail('a late S: ' + hit + ' ' + g.text());
  // no such device, then the same one again
  m.removePack(1); g.inject('S'); g.wait(); g.inject('C'); g.run(8);  if (g.atLine() || /Saved/.test(g.text())) fail('no pack: ' + g.text());
  for (let i = 0; i < 6 && !/1000[79]/.test(g.text()); i++) { m.press('SPACE', 4, 4); g.run(1); } g.wait(); if (!/10007/.test(g.text()) || /Saved/.test(g.text())) fail('after no pack: ' + g.text());
  m.emptyPack(1, 32, 1); const lo0 = g.peekw('kv_lo'); g.inject('S'); g.wait(); g.inject('A'); g.wait(120); if (bottom() !== 'Saved: A:BIGLOG') fail('on A: ' + g.text()); if (g.peekw('kv_lo') - lo0 > 800) fail(`${g.peekw('kv_lo') - lo0} bytes taken for A:`); home();
  g.line('SET LOG A:'); home(); g.line('LOG'); if (!/^time /.test(g.text().trim())) fail('LOG of A: ' + g.text()); home(); g.line('SET LOG OFF'); home();
}
// hardly any memory left: said, and the factors are still there
if (!small) {
  home(); g.line('CLR'); home(); const ala = m.peekw(0x2040), heap = () => g.peekw('kv_hi') - g.peekw('kv_lo');
  for (const h of [1200, 700, 560, 520, 480, 440, 400, 360, 320]) {
    home(); m.pokew(0x2040, ala); g.line('1'); home(); m.pokew(0x2040, ala + heap() - h); g.line('1'); home(); const r = g.line('FACTOR(2**24-1)'); if (r.err) { if (r.err !== 7) fail(`FACTOR in ${h}: ${r.err}`); continue; }
    const t = g.lines().join('|'); g.inject('S'); g.wait(); if (/NO MEMORY/.test(bottom())) { g.inject('UP'); g.wait(); } else { g.inject('C'); g.wait(60); if (bottom() !== 'Saved: C:BIGLOG') fail(`S in ${h}: ${g.text()}`); g.inject('UP'); g.wait(); }
    if (g.lines().join('|') !== t) fail(`after S in ${h}: ${g.text()}`);
  }
  home(); m.pokew(0x2040, ala); g.line('1'); home();
}
console.log(bad ? `${bad} FAILED` : `t_factors ${model} ok (${n} numbers)`);
process.exit(bad ? 1 : 0);
