// Leaving: by the question, by the menu, with ON/CLEAR held down; from deep in a run: the memory is given back, OPL's
// own stack and the zero page's OS parts are as they were, and the program starts again.   node tests/t_leave.js [model ...]
'use strict';
const { BN, HZ } = require('./lib');
let bad = 0;
for (const mo of process.argv.length > 2 ? process.argv.slice(2) : ['cm', 'cm24', 'xp', 'xp24', 'la', 'lz', 'lz64', '33-cmf.rom', '42-lz.rom', '36-laf.rom']) {
  const g = new BN(mo), m = g.m; let sp0 = 0;
  for (const how of ['Y', 'menu', 'held', 'run', 'Y']) {
    g.start(); g.wait();
    // the zero page the program uses is kept in the launcher's code; OPL's program counter in it is at the USR
    const sp = m.peekw(g.addr('kv_sp')), kept = [m.peekw(sp), m.peekw(sp + 1)].find((a) => m.peek(m.peekw(a + 2)) === 0x9F) || 0, zp = m.read(kept, 57);
    if (m.peek(zp[2] << 8 | zp[3]) !== 0x9F) { bad++; console.log('FAIL', mo, 'kept zero page', zp.join(' ')); }
    g.line('FACT(50)'); for (let i = 0; i < 6 && !g.atLine(); i++) { g.inject('ON'); g.wait(); }
    if (how === 'Y') { g.inject('ON'); g.wait(); m.poke(0x76, 89); }
    else if (how === 'menu') { g.press('MODE'); g.run(1); g.press('Q'); if (!/Prog|PROG|Find|FIND/.test(g.text())) { g.run(0.5); } }
    else if (how === 'held') { g.inject('ON'); g.wait(); m.poke(0x76, 89); m.run(1500); m.keyDown('ON'); m.run(HZ * 3); if (/PAUSE|paused/i.test(g.text())) { bad++; console.log('FAIL', mo, 'held', g.text()); } m.keyUp('ON'); }
    else { const l = 'ISPRIME(2**521-1)'; g.wait(); m.write(g.peekw('kv_line'), [l.length, ...[...l].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', l.length); g.inject('EXE'); g.run(5); m.poke(0x76, 1); g.run(2); m.poke(0x76, 65); g.run(1); g.wait(); g.inject('ON'); g.wait(); g.inject('Y'); }
    if (how === 'Y') {
      const rts = g.addr('lv_x'); if (m.peek(rts) !== 0x39 || m.runTo([rts], HZ * 10) !== rts) { bad++; console.log('FAIL', mo, how, 'no leave'); }
      const now = m.read(0xA7, 57); if (now.join() !== zp.join()) { bad++; console.log('FAIL', mo, how, 'zero page', now.join(' '), 'was', zp.join(' ')); }
    }
    for (let i = 0; i < 40 && !/Prog|PROG|Find|FIND|RUN|Run/.test(g.text()); i++) g.run(0.25);
    g.run(1);
    if (!sp0) sp0 = m.peekw(0xA5); const ok = m.peekw(0xA5) === sp0 && m.peekw(0xA5) > 0x3000 && /Prog|PROG|Find|FIND|RUN|Run|CALC|Edit/i.test(g.text());
    if (!ok) { bad++; console.log(`FAIL ${mo} ${how}: A5 ${m.peekw(0xA5).toString(16)} was ${sp0.toString(16)} ${g.text().replace(/\n/g, '|')}`); for (let i = 0; i < 4; i++) g.press('ON'); }
    for (let i = 0; i < 4 && !/Prog|PROG|Find|FIND/.test(g.text()); i++) { g.press('ON'); g.run(0.5); }
  }
  console.log(mo, 'left five times');
}
console.log(bad ? `${bad} FAILED` : 't_leave ok');
process.exit(bad ? 1 : 0);
