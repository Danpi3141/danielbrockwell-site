// The CM's largest job: a stored 2,048-bit number tested, its value also in ANS: does it start?
'use strict';
const { BN, HZ } = require('./lib');
for (const mo of process.argv.slice(2).length ? process.argv.slice(2) : ['cm', 'cm24', 'cm26', '33-cmf.rom', '36-cmf.rom']) {
  const g = new BN(mo).start(); g.line('A=2**2047+1919'); for (let i = 0; i < 5 && !g.atLine(); i++) { g.inject('ON'); g.wait(); }
  const l = 'ISPRIME(A)'; g.wait(); g.m.write(g.peekw('kv_line'), [l.length, ...[...l].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', l.length); g.inject('EXE'); g.run(60);
  const ok = /Base 2/.test(g.text()); console.log(mo, 'heap', g.peekw('kv_hi') - g.peekw('kv_lo'), ok ? 'ok' : g.text().replace(/\n/g, ' | '));
  if (!ok) process.exitCode = 1;
}
