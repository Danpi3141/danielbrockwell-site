// The launcher on every ROM: it starts, the memory is taken and given back.
'use strict';
const { BN, ROMS } = require('./lib');
let bad = 0;
for (const r of process.argv[2] ? [process.argv[2]] : Object.keys(ROMS)) {
  try {
    const g = new BN(r); g.start();
    const inside = g.peekw('kv_hi') - g.peekw('kv_lo');
    console.log(r, 'free', g.free0, 'base', g.base.toString(16), 'lo', g.peekw('kv_lo').toString(16), 'heap', inside, 'tier', g.peek('kv_tier'), 'rows', g.peek('kv_wm'), 'os free now', g.free());
  } catch (e) { bad++; console.log(r, 'FAILED', e.message.slice(0, 200)); }
}
process.exit(bad ? 1 : 0);
