; points on the curve: slots 0, 1 R0; 2, 3 R1; 4, 5 the base; 6 (A+2)/4; 7 to 10 work.
; eclad: R0, R1 = k, k+1 times the base; k (1 or more) is the item at mx_e
eclad:  bsr  mrun               ; R0 = the base, R1 = twice it
        mo    M_CPY,0,4,4
        mo    M_CPY,1,5,5
        mo    M_CPY,2,4,4
        mol   M_CPY,3,5,5
        clr  ec_sw
        bsr  ecdbl1
        ldx  mx_e
        bsr  ibits
        subd #1
        std  ec_i
.l:     ldd  ec_i
        beq  ecswap0            ; (R0 and R1 as they should be)
        subd #1
        std  ec_i
        bsr  ebit               ; a 1: as a 0 with the two changed over
        pshb
        bsr  ecsw
        pulb
        stab ec_sw
        bsr  ecstep
        bra  .l
; ecsw: R0 and R1 changed over if B is not ec_sw
ecswap0: clrb
        bsr  ecsw
        clr  ec_sw
        rts
ecsw:   cmpb ec_sw
        beq  .x
        bsr  mrun
        mo    M_CPY,7,0,0
        mo    M_CPY,0,2,2
        mo    M_CPY,2,7,7
        mo    M_CPY,7,1,1
        mo    M_CPY,1,3,3
        mol   M_CPY,3,7,7
.x:     rts
; ecstep: R1 = R0 + R1, R0 = 2 R0
ecstep: bsr  mrun
        mo    M_ADD,7,0,1
        mo    M_SUB,8,0,1
        mo    M_ADD,9,2,3
        mo    M_SUB,10,2,3
        mo    M_MUL,9,8,9
        mo    M_MUL,10,7,10
        mo    M_SQR,7,7,7
        mo    M_SQR,8,8,8
        mo    M_MUL,0,7,8
        mo    M_SUB,7,7,8
        mo    M_MUL,1,6,7
        mo    M_ADD,1,1,8
        mo    M_MUL,1,1,7
        mo    M_ADD,2,9,10
        mo    M_SQR,2,2,2
        mo    M_MUL,2,2,5
        mo    M_SUB,3,9,10
        mo    M_SQR,3,3,3
        mol   M_MUL,3,3,4
        rts
; ecdbl1: R1 = 2 R1
ecdbl1: bsr  mrun
        mo    M_ADD,7,2,3
        mo    M_SUB,8,2,3
        mo    M_SQR,7,7,7
        mo    M_SQR,8,8,8
        mo    M_MUL,2,7,8
        mo    M_SUB,7,7,8
        mo    M_MUL,3,6,7
        mo    M_ADD,3,3,8
        mol   M_MUL,3,3,7
        rts
