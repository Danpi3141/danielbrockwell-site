// The sieve's combining from inside: every set it finds must be a square; X and Y squared the same modulo N.
//   node tests/t_qs2.js [model] N
'use strict';
const { BN, fromBytes, HZ } = require('./lib');
const model = process.argv[2] || 'lz64';
const N = BigInt(process.argv[3] || '529213055793261685771349');
const g = new BN(model).start(), m = g.m;
let fails = 0;
const fail = (s) => { console.log('FAIL', s); if (++fails > 10) process.exit(1); };
const t = `QS(${N})`;
g.wait(); m.write(g.peekw('kv_line'), [t.length, ...[...t].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', t.length);
m.poke(0x76, 13);
const OV = (o) => g.meta.ovl.indexOf(o) + 1;
const to = (ov, name, sec = 100000) => { const a = g.oaddr(ov, name); for (;;) { if (m.runTo([a], HZ * sec) !== a) throw new Error('never came to ' + name + '\n' + g.text()); if (g.peek('kv_res') === OV(ov)) return; m.run(1); } };
let c0 = m.cycles();
to('ov_qsl', 'qsl');
console.log(`sieved in ${((m.cycles() - c0) / HZ).toFixed(1)} s`); c0 = m.cycles();
const w = (n, o = 0) => g.peekw(n, o), b1 = (n, o = 0) => g.peek(n, o);
to('ov_qsx', 'qsx');
console.log(`combined in ${((m.cycles() - c0) / HZ).toFixed(1)} s`); c0 = m.cycles();
const ub = b1('q_ub'), F = b1('q_f'), k = BigInt(b1('q_k')), kN = k * N;
const n = b1('kv_fy'), rb = b1('kv_fy', 1), M = w('kv_fy', 2), piv = w('kv_fy', 4), use = w('kv_fy', 6);
console.log(`rows ${n} of ${rb} bytes, F ${F}`);
const rels = []; let e = w('q_rel');
for (let i = 0; i < n; i++) { const b = m.read(e, ub); const pair = b[0] & 0x80; b[0] &= 0x7f; const us = [fromBytes(b)]; e += ub; if (pair) { us.push(fromBytes(m.read(e, ub))); e += ub; } rels.push(us); }
const isqrt = (v) => { let x = 1n << BigInt(Math.ceil(v.toString(2).length / 2)); for (;;) { const y = (x + v / x) / 2n; if (y >= x) return x; x = y; } };
let free = 0, bad = 0, good = 0; 
const pv = m.read(piv, F + 1), us = m.read(use, n);
for (let r = 0; r < n; r++) {
  if (us[r] !== 0) { if (us[r] === 2) bad++; continue; }
  free++;
  const row = m.read(M + r * rb, rb); const set = new Set([r]);
  for (let c = 0; c <= F; c++) if (row[c >> 3] >> (c & 7) & 1) { if (pv[c] === 255) fail(`row ${r}: column ${c} has no pivot`); else set.add(pv[c]); }
  let prod = 1n; for (const i of set) for (const u of rels[i]) prod *= u * u - kN;
  const s = prod > 0n ? isqrt(prod) : 0n;
  if (prod <= 0n || s * s !== prod) fail(`row ${r}: ${set.size} relations, not a square (negative ${prod < 0n})`);
  else { let X = 1n; for (const i of set) for (const u of rels[i]) X = X * u % N; const Y = s % N; if (X * X % N !== Y * Y % N) fail('X, Y'); let a = X > Y ? X - Y : Y - X, b = N; while (b) [a, b] = [b, a % b]; if (a !== 1n && a !== N) good++; }
}
console.log(`${free} sets (${bad} rows no good), ${good} of them give a factor`);
// X and Y as the program has them
const tries = +process.argv[4] || 1;
for (let i = 0; i < tries; i++) {
  to('ov_qsx', 'sgcd', 400);
  const mn = w('mn'), ms = w('ms');
  const R = 1n << BigInt(8 * mn);
  const X = fromBytes(m.read(ms, mn)), Y = fromBytes(m.read(ms + mn, mn));
  console.log('X^2 = Y^2:', X * X % N === Y * Y % N, 'row', b1('kv_fs', 13), 'mn', mn, 'fx_n', w('kv_fx'));
}
console.log(fails ? `${fails} FAILED` : 'ok');
process.exit(fails ? 1 : 0);
