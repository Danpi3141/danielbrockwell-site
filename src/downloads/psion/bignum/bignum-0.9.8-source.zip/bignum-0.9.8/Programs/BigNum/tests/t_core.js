// The arithmetic core against BigInt: products, squares, Montgomery arithmetic, sums on the stack.
//   node tests/t_core.js [model] [seed]
'use strict';
const { BN, rng, toBytes, fromBytes } = require('./lib');
const model = process.argv[2] || 'lz64';
const R = rng(+process.argv[3] || 1);
const g = new BN(model).start();
let fails = 0;
const fail = (s) => { console.log('FAIL', s); if (++fails > 10) process.exit(1); };
const m = g.m;
const lo = g.peekw('kv_lo') + 16;
const room = g.peekw('kv_hi') - lo - 32;
const big = (bytes) => { // awkward values too: all ones, sparse, random
  const k = R.int(8); const one = (1n << BigInt(bytes * 8)) - 1n;
  if (k === 0) return one; if (k === 1) return 1n << BigInt(bytes * 8 - 1);
  if (k === 2 && bytes > 2) return one - R.bits(16); if (k === 3) return R.bits(bytes * 8) & R.bits(bytes * 8) & R.bits(bytes * 8) | 1n << BigInt(bytes * 8 - 1);
  return R.bits(bytes * 8) | 1n << BigInt(bytes * 8 - 1);
};
// ---- mulp, sqrp
const sizes = [1, 2, 3, 7, 8, 15, 16, 17, 20, 23, 24, 25, 31, 32, 33, 47, 48, 49, 64, 100, 128, 256];
const cost = {};
const mul = (na, nb) => {
  if (2 * (na + nb) + 10 > room) return;
  const a = big(na), b = big(nb); const pa = lo, pb = lo + na + 1, pp = pb + nb + 3;
  m.write(pa, toBytes(a, na)); m.write(pb, toBytes(b, nb)); m.poke(pp - 1, 0x5A); m.poke(pp + na + nb, 0xA5);
  g.pokew('ma', pa); g.pokew('mal', na); g.pokew('mb', pb); g.pokew('mbl', nb); g.pokew('mp', pp);
  const c = g.call('mulp').cycles;
  const p = fromBytes(m.read(pp, na + nb));
  if (p !== a * b) fail(`mulp ${na} x ${nb}: ${a.toString(16)} x ${b.toString(16)}`);
  if (m.peek(pp - 1) !== 0x5A || m.peek(pp + na + nb) !== 0xA5) fail(`mulp ${na} x ${nb} wrote past the product`);
  if (na === nb) cost[na] = [c];
};
const sqr = (n) => {
  if (3 * n + 10 > room) return;
  const a = big(n), pa = lo, pp = pa + n + 3;
  m.write(pa, toBytes(a, n)); m.poke(pp - 1, 0x5A); m.poke(pp + 2 * n, 0xA5);
  g.pokew('ma', pa); g.pokew('mal', n); g.pokew('mp', pp);
  const c = g.call('sqrp').cycles;
  if (fromBytes(m.read(pp, 2 * n)) !== a * a) fail(`sqrp ${n}: ${a.toString(16)}`);
  if (m.peek(pp - 1) !== 0x5A || m.peek(pp + 2 * n) !== 0xA5) fail(`sqrp ${n} wrote past the product`);
  if (cost[n]) cost[n][1] = c;
};
for (const n of sizes) { for (let i = 0; i < 6; i++) { mul(n, n); sqr(n); } }
for (let i = 0; i < 60; i++) { mul(1 + R.int(80), 1 + R.int(80)); sqr(1 + R.int(120)); }
if (room > 4200) { mul(1024, 1024); sqr(1024); mul(1000, 7); mul(5, 1001); }
// ---- Montgomery
const mont = (n, times) => {
  const NS = 4;
  if (n * (NS + 3) + 10 > room) return;
  for (let t = 0; t < times; t++) {
    const N = big(n) | 1n;
    const pT = lo + 4, pN = pT + 2 * n + 2, pS = pN + n;
    m.write(pN, toBytes(N, n));
    g.pokew('mn', n); g.pokew('mnp', pN); g.pokew('mne', pN + n); g.pokew('ms', pS); g.pokew('mp', pT);
    g.poke('mk', Number((256n - modinv(N, 256n)) % 256n));
    const A = t === 0 ? N - 1n : big(n) % N, B = t === 1 ? N - 1n : big(n) % N;
    m.write(pS, toBytes(A, n)); m.write(pS + n, toBytes(B, n));
    const Rinv = modinv(1n << BigInt(8 * n), N);
    const ops = { 1: A * B * Rinv % N, 2: A * A * Rinv % N, 3: (A + B) % N, 4: ((A - B) % N + N) % N, 5: A };
    for (const op of [1, 2, 3, 4, 5]) {
      g.poke('mi', 2); g.poke('mi', 0, 1); g.poke('mi', 1, 2);
      const c = g.call('mop', { b: op }).cycles;
      const r = fromBytes(m.read(pS + 2 * n, n));
      if (r !== ops[op]) fail(`op ${op} n ${n} N ${N.toString(16)} A ${A.toString(16)} B ${B.toString(16)} got ${r.toString(16)} want ${ops[op].toString(16)}`);
      (cost[n] = cost[n] || [])[1 + op] = c;
    }
  }
};
function modinv(a, n) { let [r0, r1, s0, s1] = [n, ((a % n) + n) % n, 0n, 1n]; while (r1) { const q = r0 / r1; [r0, r1] = [r1, r0 - q * r1]; [s0, s1] = [s1, s0 - q * s1]; } return ((s0 % n) + n) % n; }
for (const n of sizes) mont(n, 8);
if (room > 7300) mont(1024, 1);
console.log('bytes: product, square, modular multiply, modular square, modular add, sub, copy (cycles; per byte pair)');
for (const n of [8, 16, 20, 24, 32, 64, 128, 256, 1024]) if (cost[n]) console.log(n, cost[n].map((c, i) => c + (i < 2 ? '(' + (c / n / n).toFixed(1) + ')' : i < 4 ? '(' + (c / n / n / 2).toFixed(1) + ')' : '')).join('  '));
// ---- sums on the stack
g.clear();
for (let i = 0; i < 400; i++) {
  const sz = [0, 1, 2, 3, 9, 17, 40][R.int(7)], s2 = [0, 1, 2, 3, 9, 17, 40][R.int(7)];
  let a = R.bits(8 * sz), b = R.bits(8 * s2); if (R.int(2)) a = -a; if (R.int(2)) b = -b; if (!R.int(10)) b = -a; if (!R.int(10)) b = a;
  const c = R.bits(20);
  g.clear(); g.push(c); g.push(a); g.push(b);
  const k = R.int(6);
  let want;
  if (k === 0) { g.call('hadd'); want = [a + b, c]; } else if (k === 1) { g.call('hsub'); want = [a - b, c]; } else if (k === 2) { g.call('hmul'); want = [a * b, c]; }
  else if (k === 3) { g.call('hswap'); want = [a, b, c]; } else if (k === 4) { g.call('hover'); want = [a, b, a, c]; } else { g.call('hnip'); want = [b, c]; }
  const got = g.stack();
  if (got.join() !== want.join()) fail(`stack op ${k}: ${a} ${b} -> ${got} want ${want}`);
}
// compare
for (let i = 0; i < 100; i++) {
  const a = R.bits(8 * R.int(5)), b = R.int(3) ? R.bits(8 * R.int(5)) : a;
  g.clear(); g.push(a); g.push(b);
  const r = g.call('hcmp', { x: g.call('i2').x, d: g.peekw('kv_wp') });
  if ((r.carry === 1) !== a < b || (r.z === 1) !== (a === b)) fail(`hcmp ${a} ${b} carry ${r.carry} z ${r.z}`);
}
for (const v of [0, 1, 255, 256, 65535]) { g.clear(); g.call('hpush', { d: v }); if (g.stack()[0] !== BigInt(v)) fail('hpush ' + v); }
console.log(fails ? `${fails} FAILED` : `t_core ${model} ok`);
process.exit(fails ? 1 : 0);
