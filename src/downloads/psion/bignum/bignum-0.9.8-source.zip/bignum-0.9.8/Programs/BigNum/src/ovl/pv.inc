; PROVE's own variables (kv_pv)
pv_c    = kv_pv                 ; (2) the certificate, from here up to kv_osp
pv_m    = kv_pv+2               ; (2) the number being proved (its item on the stack of numbers)
pv_t    = kv_pv+4               ; the proof: PT_... (0 none)
pv_s    = kv_pv+5               ; the step: 0 N-1, 1 N+1 by trial division, 2 and 3 by the whole chain
pv_p    = kv_pv+6               ; (2) how much of N-1 and of N+1 is factored, per cent
pv_d    = kv_pv+8               ; N+1: the discriminant
pv_top  = kv_pv+9               ; 1: the number asked for itself (0: a factor of a factor)
pv_o    = kv_pv+10              ; (2) kv_osp as it was
pv_rl   = kv_pv+12              ; (4) the factors' list under it, if there is one (P on its screen)
pv_rec  = kv_pv+16              ; (2) the record in it
pv_run  = kv_pv+18              ; 1: a proof is running (the displays say PROVE)
pv_esc  = kv_pv+19              ; (4) where the whole goes when it is stopped (kv_esc, kv_ssp)
pv_q    = kv_pv+23              ; (2) the record being worked on
pv_a    = kv_pv+25              ; the witness being tried
PV_LEN  = 26
; the certificate's records: a tag, a word, an item: PT_... and a word for each number proved, its number;
; then each prime used, 1, with its witness
PT_Q    = 1
PT_HALF = 2                     ; N-1, its factored part past the square root
PT_THIRD = 3                    ; N-1, past the cube root
PT_PLUS = 4                     ; N+1
CT_N    = 3
