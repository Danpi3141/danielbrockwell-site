; =====================================================================
; Numbers in memory. An item is a word (bit 15: negative; the rest: its length in bytes) and its
; bytes, highest first, no leading zeros; zero has length 0 and is never negative.
; The block: [kv_lo: the operator stack, then a list of results, up to kv_lim ... free ... the stack
; of numbers, kv_wp its top, down from kv_vb][the variables, kv_vb up to kv_hi: a letter and an item
; each].
; =====================================================================

; walloc: D bytes off the top of the stack of numbers: X = their first byte
walloc: std  zt
        ldd  kv_wp
        subd zt
        bcs  nomem
        subd kv_lim
        bcs  nomem
        addd kv_lim
        std  kv_wp
        xgdx
        rts
nomem:  ldab #E_MEM
        bra  err
; ilen: D = the length of the item at X (N: it is negative)
ilenw:  ldx  kv_wp             ; (of the top number)
ilen:   ldd  0,x
        anda #$7F
        tst  0,x
        rts
; inext: X past the item at X; i2: X = the second number on the stack; i3: the third
i3:     bsr  i2
        bra  inext
i2:     ldx  kv_wp
inext:  bsr  ilen
        stx  zt
        addd zt
        addd #2
        xgdx
        rts
; hcopy: a copy of the item at X pushed; hdup: the top number again; hover: the second one; hover3: the third
hover3: bsr  i3
        bra  hcopy
hover:  bsr  i2
        bra  hcopy
hdup:   ldx  kv_wp
hcopy:  pshx
        bsr  ilen
        addd #2
        std  kv_al
        bsr  walloc
        pulx
        stx  zx
        ldx  kv_wp
        stx  zp
        ldd  kv_al
        bra  cpb
; hdrop: the top number dropped; hdrop2: the top two
hdrop2: bsr  hdrop
hdrop:  bsr  i2
        stx  kv_wp
        rts
; hnip: the second number dropped
hnip:   bsr  i3
        bra  hslx
; hpush: D (0-65535) pushed; hpush1: 1
hpush1: ldd  #1
hpush:  pshb
        psha
        ldd  #4
        bsr  walloc
        pula
        pulb
        std  2,x
        ldd  #2
        std  0,x
; hnorm (cpbn: after a cpb): the top number without leading zeros (and no sign on zero)
hnorm:  ldx  kv_wp
        ldd  0,x
        std  kv_al              ; (its sign and length)
        anda #$7F
        std  zt
        inx
        inx
.z:     ldd  zt
        beq  .d
        tst  0,x
        bne  .d
        inx
        subd #1
        std  zt
        bra  .z
.d:     ldaa kv_al              ; the sign, if it is not zero
        anda #$80
        oraa zt
        ldab zt+1
        dex
        dex
        std  0,x
        ldd  zt
        bne  .k
        clr  0,x
.k:     stx  kv_wp
        rts
; hslide: the top number, normalised, moved up to end at kv_se (over the numbers it was made from); hslx: at X
hslx:   stx  kv_se
hslide: bsr  hnorm
        bsr  ilen
        addd #2
        std  kv_al
        addd kv_wp
        std  zx
        ldd  kv_se
        std  zp
        subd kv_al
        std  kv_wp
        ldd  kv_al
; cpd: D bytes ending at zx moved to end at zp, falling
cpd:    std  zt
        lsr  zt
        ror  zt+1
        bcc  .e
        ldx  zx                 ; an odd byte first
        dex
        stx  zx
        ldaa 0,x
        ldx  zp
        dex
        stx  zp
        staa 0,x
.e:     ldd  zt
        beq  .x
        tstb
        beq  .l
        inca
        staa zt
.l:     ldx  zx
        dex
        dex
        stx  zx
        ldd  0,x
        ldx  zp
        dex
        dex
        stx  zp
        std  0,x
        dec  zt+1
        bne  .l
        dec  zt
        bne  .l
.x:     rts
; hswap: the top two numbers changed over
hswap:  bsr  hover              ; a copy of the second, then the two moved up over it
        bsr  i3
        stx  zx
        pshx
        bsr  inext
        stx  zp
        stx  kv_se
        pula
        pulb
        subd kv_wp
        std  kv_al
        ldd  kv_se
        subd kv_al
        std  kv_wp
        ldd  kv_al
        bra  cpd
cpbn:   bsr  cpb                ; a copy, then the top number normalised
        bra  hnorm
; hneg: the top number's sign changed
hneg:   ldx  kv_wp
        ldd  0,x
        beq  .x
        eora #$80
        std  0,x
.x:     rts

; hcmp: the magnitudes of the items at X and at D compared: carry set: X's is the smaller; Z: equal
hcmp:   std  zp
        stx  zx
        bsr  ilen
        std  zt
        ldx  zp
        bsr  ilen
        std  ze
        ldd  zt
        subd ze
        bne  .x
        ldx  zt
        beq  .x
.l:     stx  zt
        ldx  zx
        ldaa 2,x
        inx
        stx  zx
        ldx  zp
        cmpa 2,x
        bne  .x
        inx
        stx  zp
        ldx  zt
        dex
        bne  .l
.x:     rts

; hsub: second - top; hadd: second + top (both gone, the result pushed)
hsub:   bsr  hneg
hadd:   bsr  i2
        stx  kv_ia              ; A = the second, B = the top
        bsr  inext
        stx  kv_se
        ldx  kv_wp
        stx  kv_ib
        ldab 0,x
        ldx  kv_ia
        eorb 0,x
        stab kv_cy              ; (bit 7: the signs differ)
        ldd  kv_ib              ; A = the one with the larger magnitude
        bsr  hcmp
        bcc  .ok
        ldx  kv_ia
        ldd  kv_ib
        std  kv_ia
        stx  kv_ib
.ok:    ldx  kv_ia
        ldd  0,x
        pshb
        psha
        bsr  ilen
        addd #3                 ; (room for a carry)
        bsr  walloc
        pula
        pulb
        addd #1
        std  0,x
        ldx  kv_ia
        bsr  .end
        std  kv_na
        stx  zx
        ldx  kv_ib
        bsr  .end
        std  kv_nb
        stx  zp
        ldx  kv_wp
        bsr  .end
        std  zt
        stx  ze
        ldab kv_cy              ; a difference: B's bytes turned over, and one more
        aslb
        ldab #0
        sbcb #0
        stab kv_al
        andb #1
        stab kv_cy
.by:    ldx  zt                 ; R's bytes left
        beq  hslide
        dex
        stx  zt
        clrb                    ; B's byte
        ldx  kv_nb
        beq  .nb
        dex
        stx  kv_nb
        ldx  zp
        dex
        stx  zp
        ldab 0,x
.nb:    eorb kv_al
        clra                    ; A's
        ldx  kv_na
        beq  .na
        dex
        stx  kv_na
        ldx  zx
        dex
        stx  zx
        ldaa 0,x
.na:    lsr  kv_cy
        stab zm
        adca zm
        rol  kv_cy
        ldx  ze
        dex
        stx  ze
        staa 0,x
        bra  .by
; D = the length of the item at X, X past it
.end:   bsr  ilen
        pshb
        psha
        bsr  inext
        pula
        pulb
        rts

; hmul: second x top (both gone, the result pushed)
hmul:   bsr  i2
        ldab 0,x
        stx  kv_ia
        ldx  kv_wp
        eorb 0,x
        andb #$80
        stab kv_cy
        bsr  ilen
        std  mbl
        inx
        inx
        stx  mb
        ldx  kv_ia
        bsr  ilen
        std  mal
        inx
        inx
        stx  ma
        dex
        dex
        bsr  inext
        stx  kv_se
        ldd  mal
        addd mbl
        pshb
        psha
        addd #2
        bsr  walloc
        pula
        pulb
        oraa kv_cy
        std  0,x
        inx
        inx
        stx  mp
        bsr  mulp
        bra  hslide

; hmuladd: the top number x D (0-65535) + kv_na (0-65535); the number is not negative
hmuladd: std kv_nb
        bsr  ilenw              ; two bytes more at its front
        std  zt                 ; its length
        stx  zx
        addd zx
        addd #2
        std  zx                 ; its end
        dex
        dex
        stx  kv_wp
        cpx  kv_lim
        blo  nomem
        ldd  zt
        addd #2
        std  0,x
        ldd  kv_na
        std  zw                 ; the carry
        ldx  zt
        beq  .c
.l:     stx  zt
        ldx  zx
        dex
        stx  zx
        ldaa 0,x                ; byte x low
        ldab kv_nb+1
        mul
        addb zw+1
        adca #0
        staa zm
        ldaa 0,x
        stab 0,x
        ldab kv_nb              ; byte x high
        mul
        addb zm
        adca #0
        addb zw
        adca #0
        std  zw
        ldx  zt
        dex
        bne  .l
.c:     ldx  kv_wp              ; the carry at the front
        ldd  zw
        std  2,x
        bra  hnorm
