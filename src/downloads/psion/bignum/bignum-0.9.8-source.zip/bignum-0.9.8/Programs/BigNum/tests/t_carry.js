// Work carried forward: a number over the sieve's cap that loses a factor to ECM and then fits the sieve. Every
// method's start is noted: no ECM curve of a level may be run twice on a part of what it was run on.
//   node tests/t_carry.js [model] [N]
'use strict';
const { BN, HZ } = require('./lib');
const model = process.argv[2] || 'lz64';
const N = BigInt(process.argv[3] || (140737488355333n * 140737488356207n * 140737488360229n * 140737488400069n));
const g = new BN(model).start(), m = g.m; const OV = (o) => g.meta.ovl.indexOf(o) + 1;
const line = `FACTOR(${N})`; let bad = 0;
g.wait(); m.write(g.peekw('kv_line'), [line.length, ...[...line].map((x) => x.charCodeAt(0))]); g.poke('kv_cur', line.length); m.poke(0x76, 13);
const seen = {}; const log = [];
const c0 = m.cycles(); const at = g.addr('t_idle'), oc = g.addr('ov_call');
const names = { ov_rho: 'RHO', ov_pm1: 'PM1', ov_ecm: 'ECM', ov_qs: 'QS', ov_ecs: 'curve' };
for (;;) {
  const pc = m.runTo([at, oc], HZ * 1e7);
  if (pc === at) { if ((m.cycles() - c0) > HZ * 4) break; m.run(1); continue; }
  const o = g.meta.ovl[m.dbg.a() - 1], e = m.dbg.b();
  if (names[o]) {
    const dg = g.peekw('kv_fx', 2), t = ((m.cycles() - c0) / HZ).toFixed(0);
    if (o === 'ov_ecs') { const l = g.peek('kv_fx', 10), c = g.peekw('kv_fx', 6); const k = `${l}/${c}`; if (seen[k]) { console.log(`FAIL curve ${k} again`); bad++; } seen[k] = 1; } else log.push(`${t}s ${names[o]}${o === 'ov_pm1' && e ? '(P+1)' : ''} C${dg} lim ${g.peekw('kv_fx', 4)} level ${g.peek('kv_fx', 10)} curves ${g.peekw('kv_fx', 6)} of ${g.peekw('kv_fx', 8)} budget ${g.peekw('kv_fz', 5) * 65536 + g.peekw('kv_fz', 7)} ${g.peek('kv_fz', 9) ? 'then sieve' : 'no end'}`);
  }
  m.run(1);
}
console.log(log.join('\n')); console.log(g.text());
const got = []; let a = g.peekw('kv_rl'); const e = g.peekw('kv_lim'); while (a < e) { got.push(g.item(a + 20)); a += 22 + (m.peekw(a + 20) & 0x7fff); }
console.log(got.join(' '), 'product ok', got.reduce((x, y) => x * y, 1n) === N, `curves run ${Object.keys(seen).length}`, ((m.cycles() - c0) / HZ / 3600).toFixed(2), 'h');
process.exit(bad ? 1 : 0);
