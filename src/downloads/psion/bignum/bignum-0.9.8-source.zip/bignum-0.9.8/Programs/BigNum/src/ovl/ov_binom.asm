; =====================================================================
; OV_BINOM: BINOM(n, k)
; =====================================================================
        include "macros.inc"
        lastent binom

bn_n    = kv_fs                 ; n and k, if n is below 65536
bn_k    = kv_fs+2
bn_p    = kv_fs+4
binom:  bsr  i2                 ; 0 <= k <= n
        bsr  ilen
        bmi  arg
        bsr  ilenw
        bmi  arg
        bsr  i2
        ldd  kv_wp
        bsr  hcmp
        bcs  zero
        bsr  hover              ; k the smaller of k and n-k
        bsr  hover
        bsr  hsub               ; n k n-k
        ldx  kv_wp
        pshx
        bsr  i2
        pula
        pulb
        bsr  hcmp               ; k against n-k
        bls  .k
        bsr  hswap
.k:     bsr  hdrop
        bsr  word               ; k past 65535: far too big
        bne  big
        std  bn_k
        bsr  hdrop
        bsr  word
        bne  large
        std  bn_n
        bsr  hdrop
; n below 65536: each prime to the power it has (Kummer: the borrows of n - k in base p)
        ldd  #PS_LEN
        bsr  walloc
        stx  ps_buf
        bsr  hpush1
        bsr  hpush1
        ldd  #2
        bsr  prime
        clrb
        ldx  #3
        bsr  ps_go
.l:     bsr  ps_next
        tst  ps_p
        bne  .e
        ldd  ps_p+1
        subd bn_n
        bhi  .e
        ldd  ps_p+1
        bsr  prime
        bra  .l
.e:     bsr  fin
        bsr  i2
        ldab #PS_LEN
        abx
        bra  hslx
; prime: D = a prime: its power times the numbers gathered
prime:  std  bn_p
        ldd  bn_n
        std  bn_p+2
        ldd  bn_k
        std  bn_p+4
        clr  bn_p+6             ; the borrow
.g:     ldd  bn_p+2             ; the lowest digits
        beq  .x
        bsr  digit
        stx  bn_p+2
        pshb
        psha
        ldd  bn_p+4
        bsr  digit
        stx  bn_p+4
        addb bn_p+6
        adca #0
        std  zt
        pula
        pulb
        subd zt
        ldaa #0
        rola
        staa bn_p+6
        beq  .g
        ldd  bn_p               ; a borrow: p once more
        bsr  gather
        bra  .g
.x:     rts
; digit: D modulo bn_p, and X = D / bn_p
digit:  std  zx
        ldaa #16
        staa zm
        clra
        clrb
.b:     asl  zx+1
        rol  zx
        rolb
        rola
        bcs  .s
        subd bn_p
        bcc  .i
        addd bn_p
        bra  .n
.s:     subd bn_p
.i:      inc  zx+1
.n:     dec  zm
        bne  .b
        ldx  zx
        rts
; n large: the product of the n-i, over k!
large:  bsr  hpush1             ; n, the product, k!
        bsr  hpush1
        clra
        clrb
        std  bn_p
.l:     ldd  bn_p
        subd bn_k
        beq  .e
        bsr  hswap              ; n k! product
        bsr  hover3
        ldd  bn_p
        bsr  hpush
        bsr  hsub
        bsr  hmul
        bsr  ilenw              ; (far past the cap already?)
        lsrd
        subd kv_cap
        bhi  big
        bsr  hswap
        ldd  bn_p
        addd #1
        std  bn_p
        ldx  #0
        stx  kv_na
        bsr  hmuladd
        bsr  poll
        bra  .l
.e:     ovsub OV_DIV,0
        bra  hnip

zero:   bsr  hdrop2
        clra
        clrb
        bra  hpush
        include "gather.inc"
        include "primes.inc"
