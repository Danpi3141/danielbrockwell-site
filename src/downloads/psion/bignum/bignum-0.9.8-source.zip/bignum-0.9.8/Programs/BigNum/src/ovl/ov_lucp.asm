; =====================================================================
; OV_LUCP: the Lucas test of the top number (odd, above 10**4, kept): P is chosen here (from 3 up by 1 until
; the Jacobi symbol of P squared - 4 is -1; 0 on the way: composite; a square would never end), the test
; is OV_LUC's.
; =====================================================================
        include "macros.inc"
        lastent lucas

mx_e    = kv_fs                 ; the number
lu_p    = kv_fs+6               ; P
lucas:  ldaa #3
        staa kv_pw
        clr  kv_pk
        ldx  kv_wp
        stx  mx_e
        ldaa #3
.p:     staa lu_p
        tab                     ; P P - 4, over n
        mul
        subd #4
        bsr  hpush
        ldx  mx_e
        bsr  hcopy
        ldx  mx_e               ; (OV_FN uses none of kv_fs, but a run may)
        pshx
        ldaa lu_p
        psha
        ovsub OV_FN,2
        pula
        staa lu_p
        pulx
        stx  mx_e
        ldx  kv_wp
        ldaa 0,x
        oraa 1,x
        psha                    ; 0: a factor; bit 7: -1
        bsr  hdrop
        pula
        tsta
        beq  .rts
        bmi  .go
        ldaa lu_p
        cmpa #12                ; a square?
        beq  .sq
.nx:    inca
        cmpa #250
        bne  .p
.rts:   rts
.sq:    bsr  hdup
        ldx  mx_e
        pshx
        ovsub OV_ROOT,0
        pulx
        stx  mx_e
        bsr  hdup
        bsr  hmul
        ldx  kv_wp
        pshx
        ldx  mx_e
        pula
        pulb
        bsr  hcmp
        tpa
        psha
        bsr  hdrop
        pula
        tap
        beq  .square
        ldaa #12
        bra  .nx
.square: ldaa #4
        staa kv_pw
        rts

.go:    ovjump OV_LUC,0
