; =====================================================================
; OV_PM1A: P-1 and P+1 set up (for OV_PM1): the start A, the slots, the window. Carry set: a factor, pushed.
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        include "pslen.inc"
        include "pm1.inc"
        include "ckn.inc"
        lastent pm1a

pm1a:
        clr  pm_a               ; A = (c + t N) / d, for the t that makes it whole
.t:     ldx  fx_n
        bsr  hcopy
        ldab pm_c
        clra
        std  kv_na
        ldab pm_a
        bsr  hmuladd
        ldab pm_d
        clra
        bsr  hpush
        ovsub OV_DIV,2
        bsr  i2                 ; the remainder
        ldd  0,x
        beq  .whole
        bsr  hdrop2
        inc  pm_a
        ldaa pm_a
        cmpa pm_d
        bne  .t
        ldab pm_d               ; none: d divides the number
        clra
        bsr  hpush
        inc  fx_found
        sec
        rts
.whole: bsr  hnip
        ldx  kv_wp
        stx  pm_a
        ldab #24                ; slots: 7, and the second stage's table: 24, 4 or (no room) none
.sl:    stab pm_s
        addb #7+2
        bsr  room
        bcc  .fit
        ldab pm_s
        cmpb #24
        bne  .s4
        ldab #4
        bra  .sl
.s4:    tstb
        beq  .fit               ; (NO MEMORY, below)
        clrb
        bra  .sl
.fit:   ldab pm_s
        addb #7
        stab ms_b
        ldx  fx_n
        stx  ms_x
        ldd  #$0304             ; 1 in slot 3, R squared in slot 4
        std  ms_o
        ovsub OV_MSET,0
        ldx  pm_a               ; V(1) in slot 2, 2 in slot 3
        ldab #2
        bsr  toslot
        bsr  mrun
        mo    M_MUL,2,2,4
        mol   M_ADD,3,3,3
        ldd  #PS_LEN
        bsr  walloc
        stx  ps_buf
        ldd  fx_lim
        bsr  part
        ovsub OV_EST,6
        ldab pm_s
        beq  .no2
        ldaa #CK_PS2            ; RESUME: in the second stage?
        bsr  ckpeek
        bcc  .no2
        bsr  mrun
        mol   M_CPY,2,7,7
        ldab #2
        bra  .x
.no2:   ldaa #CK_PM1            ; in the first?
        bsr  ckset
        ldab #0
        rolb
.x:     clc
        rts
        include "ckset.inc"
        include "ckpeek.inc"
        include "room.inc"
        include "mslot.inc"
