; =====================================================================
; OV_PS: a window of primes sieved (primes.inc's ps_fill): from ps_lo, at ps_buf
; =====================================================================
        include "macros.inc"
        lastent ps_fill

        include "primes.inc"
