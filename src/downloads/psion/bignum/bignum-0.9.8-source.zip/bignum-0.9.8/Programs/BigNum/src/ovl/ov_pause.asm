; =====================================================================
; OV_PAUSE: a run paused (ON/CLEAR): what it is in kv_lbuf (line 0 after "Paused: " on four lines, line 1 on
; two). Back with B = 0 to go on, else why it is left: R_SKIP, R_KEEP, R_DROP.
; =====================================================================
        include "macros.inc"
        lastent paused

pa_on:  fcb  0                  ; the keys offered: bit 0 S, bit 1 K
paused: ldab kv_four            ; (nothing known about it: in the middle of a division, say)
        aslb
        aslb
        aslb
        ldx  #kv_lbuf
        abx
        cpx  kv_p
        bne  .kn
        bsr  pri
        fcl  "Working"
.kn:    clra
        tst  kv_skp             ; something to skip to?
        beq  .ns
        inca
.ns:    tst  kv_ckm             ; something to keep? (never on the smallest tier)
        beq  .nk
        ldab kv_tier
        cmpb #4
        beq  .nk
        oraa #2
.nk:    staa pa_on
        tst  kv_four
        beq  .two
        clrb                    ; four lines
        bsr  col
        bsr  pri
        fcl  "Paused:"
        ldx  kv_pe
        stx  kv_p
        bsr  cls
        bsr  outk
        bsr  ln1
        bsr  pri
        fcl  "C=continue"
        ldaa pa_on
        lsra
        bcc  .l1
        bsr  pri
        fcl  "  S=skip"
.l1:    bsr  out
        bsr  ln2
        ldaa pa_on
        anda #2
        beq  .l2
        bsr  pri
        fcl  "K=keep and stop"
        bsr  out
        ldaa #3
        bsr  ln
.l2:    bsr  pri
        fcl  "A=abandon"
        bra  .out
.two:   bsr  cls                ; two lines
        bsr  outk
        bsr  ln0
        bsr  pri
        fcl  "Paused  C"
        ldaa pa_on
        lsra
        bcc  .t1
        bsr  pri
        fcl  " S"
.t1:    ldaa pa_on
        anda #2
        beq  .t2
        bsr  pri
        fcl  " K"
.t2:    bsr  pri
        fcl  " A"
.out:   bsr  out
.k:     bsr  getk
        cmpb #'C'
        beq  .c
        cmpb #K_EXE
        beq  .c
        cmpb #'A'
        beq  .a
        ldaa pa_on
        lsra
        bcc  .ks
        cmpb #'S'
        beq  .s
.ks:    lsra
        bcc  .k
        cmpb #'K'
        bne  .k
        ovsub OV_KEEP,1         ; (kept when the step it is in is done)
.c:     clrb
        rts
.s:     ldab #R_SKIP
        rts
.a:     ldab #R_DROP
        rts
; outk: the line made up before
outk:   bra  out
