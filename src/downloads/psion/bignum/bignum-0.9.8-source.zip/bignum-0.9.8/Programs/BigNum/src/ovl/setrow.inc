; nth: X = setting B
nth:    ldx  #sets
.l:     decb
        bmi  .x
        pshb
        ldab 0,x
        addb #6
        abx
        pulb
        bra  .l
.x:     rts
li_row: bsr  nth
        pshx
        bsr  prs
        pulx
        ldab 0,x
        abx
        stx  ze
        ldab #8
        bsr  col
        ldx  ze
        ldaa 1,x
        cmpa #2
        beq  .b
        bhi  .d
        ldx  2,x
        ldd  0,x
        bne  putw
        bsr  pri
        fcl  "Auto"
        rts
.b:     ldx  2,x
        ldaa 0,x
        beq  .off
        bsr  pri
        fcl  "ON"
        rts
.off:   bsr  pri
        fcl  "OFF"
        rts
.d:     ldx  2,x
        ldaa 0,x
        beq  .off
        adda #'A'-1
        bsr  putc
        ldaa #':'
        bra  putc
