// Files that are not as the program wrote them: LOAD of odd data files, LOG of a file with anything in it, RESUME of a kept
// run with bytes changed, cut short or put in another order, settings with impossible values; SAVE with odd names and onto
// full packs. Nothing may crash, print control codes or give a wrong number.   node tests/t_files.js [model] [seed] [rounds]
'use strict';
const fs = require('fs'), path = require('path'), os = require('os');
const { BN, HZ, rng } = require('./lib');
const model = process.argv[2] || 'lz64', seed = +process.argv[3] || 1, N = +process.argv[4] || 1;
const R = rng(seed), pick = (a) => a[R.int(a.length)];
let bad = 0; const fail = (s) => { console.log(`FAIL ${model} seed ${seed}: ${s}`); if (++bad > 10) process.exit(1); };
const opts = (o = {}) => Object.assign(process.env.BB ? { build: process.env.BB } : {}, o);
// ---- packs made by hand
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'bnf')); let tn = 0;
const short = (t, d) => Buffer.concat([Buffer.from([d.length, t]), Buffer.from(d)]);
const file = (name, recs, t = 0x90) => Buffer.concat([short(0x81, Buffer.concat([Buffer.from(name.padEnd(8), 'latin1'), Buffer.from([t])])), ...recs.map((r) => short(t, r))]);
const pack = (files, k = 32) => {
  const h = Buffer.from([0x7A, k / 8, 126, 10, 24, 12, 0x44, 0x52, 0, 0]); let s = 0; for (let i = 0; i < 8; i += 2) s += h[i] << 8 | h[i + 1]; h[8] = s >> 8 & 255; h[9] = s & 255;
  const d = Buffer.concat([h, ...files, Buffer.from([0xFF, 0xFF])]); if (d.length > k * 1024) throw new Error('too much for the pack');
  const f = path.join(tmp, `p${tn++}.opk`); fs.writeFileSync(f, Buffer.concat([Buffer.from('OPK'), Buffer.from([d.length >> 16, d.length >> 8 & 255, d.length & 255]), d])); return f;
};
const str = (s) => Buffer.from(s, 'latin1');
const home = (g) => { for (let i = 0; i < 12 && !g.atLine(); i++) { if (/TRAP/.test(g.text())) return false; g.m.press('SPACE', 4, 3); g.m.poke(0x76, i & 1 ? 1 : 65); g.run(1); if (g.m.runTo([g.addr('t_idle')], HZ * 20) < 0) continue; } return g.atLine(); };
const ok = (g, what) => {
  if (/TRAP/.test(g.text()) || !home(g)) { fail(`${what}: ${g.text()}`); process.exit(1); }
  const odd = g.m.cells().find((v) => v >= 8 && v < 32); if (odd !== undefined) fail(`${what}: a strange character ${odd}`);
  const r = g.line('12345*6789'); if (r.val !== 83810205n) { fail(`${what}: then 12345*6789 = ${r.err} ${r.val}`); process.exit(1); } home(g);
};
// ---- LOAD
const g = new BN(model, opts({ packC: { type: 1, size: 32 } })).start(); g.wait();
const cap = g.peekw('kv_cap') * 8, LIM = 1n << BigInt(cap);
const cut = (s, n) => { const r = []; for (let i = 0; i < s.length; i += n) r.push(str(s.slice(i, i + n))); return r; };
const want = (recs) => { const t = Buffer.concat(recs).toString('latin1').replace(/[\x00-\x20]/g, ''); if (!recs.length) return null; if (!/^-?\d*$/.test(t)) return null; const v = BigInt((t.replace('-', '') || '0')) * (t[0] === '-' ? -1n : 1n); return v; };
const dg = (n) => { let s = ''; while (s.length < n) s += String(R.bits(60)); return s.slice(0, n); };
const cases = () => [
  [], [str('0')], [str('-0')], [str('-')], [str('5')], [str('-5')], [str('--5')], [str('5-')], [str('12-34')], [str('-12'), str('-34')], [str('+5')], [str('1 2\t3')], [str('12.5')], [str('1e5')], [str('abc')], [str('12'), str('x')],
  [Buffer.from([0x31, 0, 0x32])], [Buffer.from([0xFF, 0xFE])], [str(' ')], [str(' '), str('7')], cut(dg(254), 254), cut(dg(900), 1 + R.int(250)), cut('0'.repeat(2000) + dg(30), 200), cut('-' + dg(300), 7), cut(String(LIM - 1n), 200), cut(String(LIM), 200), cut(String(-LIM + 1n), 199), cut('9'.repeat(2600), 254), cut(dg(1 + R.int(600)), 1 + R.int(254)),
  cut(dg(9999), 254), [...Array(300)].map(() => str(dg(1 + R.int(3)))), [...cut(dg(400), 254), str('!')], [str('1'.repeat(254)), str('2'.repeat(254)), str('3'.repeat(254)), str('4'.repeat(254))], [...Array(40)].map(() => Buffer.from([...Array(1 + R.int(200))].map(() => R.int(256)))),
];
for (let k = 0; k < N; k++) for (const recs of cases()) {
  let f; try { f = pack([file('ODD', recs, 0x90 + R.int(8))]); } catch (e) { continue; }
  g.m.insertPack(f, 1); home(g); g.line('B=77'); home(g);
  const w = want(recs); g.wait(); const l = 'LOAD B,"C:ODD"'; g.m.write(g.peekw('kv_line'), [l.length, ...[...l].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', l.length); g.m.poke(0x76, 13); g.m.run(5000);
  if (g.m.runTo([g.addr('t_idle')], HZ * 400) < 0) { fail(`LOAD of ${recs.length} records does not end`); process.exit(1); }
  const e = g.peek('kv_err'), v = g.vars().B, what = `LOAD of ${JSON.stringify(Buffer.concat(recs).toString('latin1').slice(0, 30))} (${recs.length} records, ${Buffer.concat(recs).length} bytes)`;
  if (w !== null && w > -LIM && w < LIM) { if (v !== w) { if (e !== 7) fail(`${what}: ${v}, error ${e}; want ${w}`); } } else if (v !== 77n) fail(`${what}: B became ${v}`);
  ok(g, what);
}
// ---- LOG
for (let k = 0; k < 3 * N; k++) {
  const recs = [...Array(R.int(k === 0 ? 1 : 40))].map(() => { const n = 1 + R.int(R.int(3) ? 60 : 254); return R.int(3) ? Buffer.from([...Array(n)].map(() => R.int(256))) : str('2**64+1 = '.repeat(26).slice(0, n)); });
  g.m.insertPack(pack([file('BIGLOG', recs)]), 1); home(g); g.poke('st_log', 3); { const l = 'LOG'; g.wait(); g.m.write(g.peekw('kv_line'), [3, 76, 79, 71]); g.poke('kv_cur', 3); g.m.poke(0x76, 13); g.run(2); } for (let i = 0; i < 25; i++) { g.m.poke(0x76, pick([3, 4, 5, 6, 13, 3, 4])); g.run(0.3); const odd = g.m.cells().find((v) => v >= 8 && v < 32); if (odd !== undefined) { fail(`LOG: a strange character ${odd} of ${JSON.stringify(recs.map((r) => r.slice(0, 8).toString('hex')).slice(0, 4))}`); break; } }
  home(g); g.poke('st_log', 0); ok(g, 'LOG of ' + recs.length + ' records');
}
// ---- SAVE: names, full packs, read-only, none
g.m.emptyPack(1, 32, 1); g.line('A=3**400'); home(g);
for (const nm of ['"C:AB"', 'C:AB', '"C:ABCDEFGH"', '"C:ABCDEFGHI"', '"ABCDEFGHIJ"', '"ABCDEFGHIJK"', '"1AB"', '""', '"', '"C:"', '":X"', '"C:A B"', '"D:X"', '"Z:X"', '"C:ab"', '"C:A%"', '"C:A$"', '"MAIN"', '"C:MAIN"', '"C:\x01"', '"A:X"', '"B:X"', '"C:X"Y', '"C::X"', '"CC:X"']) {
  for (const cmd of ['SAVE A,', 'LOAD B,']) { const l = cmd + nm; g.wait(); g.m.write(g.peekw('kv_line'), [l.length, ...[...l].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', l.length); g.m.poke(0x76, 13); g.run(3); if (/Replace/.test(g.text())) { g.m.poke(0x76, pick([89, 78])); g.run(2); } ok(g, l); }
}
for (const [t, k] of [[1, 8], [1, 8], [2, 32]]) { g.m.emptyPack(t, k, 1); for (let i = 0; i < 12; i++) { const l = `SAVE A,"C:F${i}"`; g.line(`A=${pick(['2**2000', '3**1200', '10**600'])}`); home(g); g.wait(); g.m.write(g.peekw('kv_line'), [l.length, ...[...l].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', l.length); g.m.poke(0x76, 13); g.run(6); if (/Replace/.test(g.text())) { g.m.poke(0x76, 89); g.run(2); } ok(g, l + ' ' + k + 'K'); if (i === 5 && t === 2) break; } }
g.m.emptyPack(1, 8, 1); g.line('SET LOG C:'); home(g); for (let i = 0; i < 40; i++) { { const l = `A=3**${900 + i}`; home(g); g.wait(); g.m.write(g.peekw('kv_line'), [l.length, ...[...l].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', l.length); g.m.poke(0x76, 13); g.run(4); } const z = g.peek('st_log'); g.poke('st_log', 0); ok(g, 'a full log'); g.poke('st_log', z); } g.poke('st_log', 0); home(g);
// ---- settings with impossible values
for (let k = 0; k < 6 * N; k++) {
  const n = g.sym.st_last[0] - g.sym.st_beep[0]; const b = [...Array(n)].map(() => (R.int(3) ? pick([0, 1, 255, 2, 128]) : R.int(256))); g.m.write(g.addr('st_beep'), b);
  for (const l of ['FACTOR(2**67-1)', 'TRIAL(91*97,0)', 'RHO(10403)', 'PM1(2**67-1)', 'PP1(2**67-1)', 'ECM(2**67-1,1)', 'ISPRIME(2**89-1)', 'SET', '2+2', 'FACT(50)', 'LOG', 'BENCH', 'QS(10007*1000003)']) {
    home(g); g.wait(); g.m.write(g.peekw('kv_line'), [l.length, ...[...l].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', l.length); g.m.poke(0x76, 13); g.run(25); if (/TRAP/.test(g.text())) { fail(`settings ${b}: ${l}: ${g.text()}`); process.exit(1); }
    for (let i = 0; i < 6 && !home(g); i++) ; if (!g.atLine()) { fail(`settings ${b}: ${l}: not back: ${g.text()}`); process.exit(1); }
  }
  g.m.write(g.addr('st_beep'), [...Array(n)].fill(0)); g.pokew('st_tdiv', 10000); g.pokew('st_every', 30); g.pokew('st_ups', 3600);
  if (g.line('CLR').err) fail('CLR'); ok(g, `settings ${b}`);
}
// ---- RESUME: a kept run spoiled
for (const [line, secs, val] of [['LLT(521)', 20, 1n], ['FACTOR(2**101-1)+A', 40, null], ['QS(353890612479965357292787308697)', 70, null]]) {
  const h = new BN(model, opts()).start(), m = h.m; const pk = m.emptyPack(1, 32, 1); h.wait(); h.line('A=5'); home(h); h.line('SET KEEP C:'); home(h);
  const say = (l) => { h.wait(); m.write(h.peekw('kv_line'), [l.length, ...[...l].map((c) => c.charCodeAt(0))]); h.poke('kv_cur', l.length); m.poke(0x76, 13); m.run(5000); };
  say(line); h.run(secs); m.poke(0x76, 1); h.run(3); m.poke(0x76, 75); h.run(40); home(h);
  const raw = []; for (let a = 0; a < 32768; a++) raw.push(pk.readByte(a) & 255);
  let end = 32767; while (end > 0 && raw[end] === 255) end--; const good = Buffer.from(raw.slice(0, end + 1));
  // its records: where each starts
  const rec = []; let p = 10; while (p < good.length && good[p] !== 255) { const l = good[p], t = good[p + 1]; let n = 2 + l; if (t === 0x80) n = 4 + (good[p + 2] << 8 | good[p + 3]); rec.push([p, n, t]); p += n; }
  const keep = rec.filter((r) => r[2] >= 0x90 && r[2] < 0xFF); if (keep.length < 3) { fail(`${line}: no kept run (${rec.length} records)`); continue; }
  for (let k = 0; k < 14 * N; k++) {
    let d = Buffer.from(good), how;
    const r = pick(keep), kind = k % 7;
    if (kind === 0) { const a = r[0] + 2 + R.int(Math.max(1, r[1] - 2)); d[a] ^= 1 << R.int(8); how = `a bit at ${a}`; }
    else if (kind === 1) { for (let i = 0; i < 5; i++) { const q = pick(keep); d[q[0] + 2 + R.int(Math.max(1, q[1] - 2))] = R.int(256); } how = 'five bytes'; }
    else if (kind === 2) { d = Buffer.concat([d.slice(0, r[0])]); how = `cut at ${r[0]}`; }
    else if (kind === 3) { d[r[0] + 1] &= 0x7F; how = `record at ${r[0]} gone`; }
    else if (kind === 4) { const q = pick(keep); const x = d.slice(r[0], r[0] + r[1]), y = d.slice(q[0], q[0] + q[1]); if (r[0] < q[0]) d = Buffer.concat([d.slice(0, r[0]), y, d.slice(r[0] + r[1], q[0]), x, d.slice(q[0] + q[1])]); how = `records at ${r[0]} and ${q[0]} changed over`; }
    else if (kind === 5) { const x = d.slice(r[0], r[0] + r[1]); d = Buffer.concat([d.slice(0, r[0]), x, d.slice(r[0])]); how = `record at ${r[0]} twice`; }
    else { const a = r[0] + 2; for (let i = 0; i < r[1] - 2; i++) d[a + i] = pick([48, 70, 71, 0, 255, 32]); how = `record at ${r[0]} overwritten`; }
    const f = path.join(tmp, `k${tn++}.opk`); d = Buffer.concat([d, Buffer.from([0xFF, 0xFF])]); fs.writeFileSync(f, Buffer.concat([Buffer.from('OPK'), Buffer.from([d.length >> 16, d.length >> 8 & 255, d.length & 255]), d]));
    m.insertPack(f, 1); home(h); say('RESUME'); h.run(3);
    const t = h.text().replace(/\n/g, '|'); const odd = m.cells().find((v) => v >= 8 && v < 32); if (odd !== undefined) fail(`RESUME ${line}, ${how}: a strange character ${odd}: ${t}`);
    if (/Resume\?/.test(t)) { m.poke(0x76, 89); h.run(20); if (/TRAP/.test(h.text())) { fail(`RESUME ${line}, ${how}: ${h.text()}`); process.exit(1); } if (val !== null && /LLT/.test(line) && k % 3 === 0) { m.runTo([h.addr('t_idle')], HZ * 120); const v = h.vars()['@']; if (!h.atLine() && v !== val) fail(`RESUME ${line}, ${how}: ${v}`); } }
    for (let i = 0; i < 4 && !home(h); i++) ; ok(h, `RESUME ${line}, ${how}`);
  }
}
fs.rmSync(tmp, { recursive: true, force: true });
console.log(bad ? `${bad} FAILED` : `t_files ${model} seed ${seed} ok`);
process.exit(bad ? 1 : 0);
