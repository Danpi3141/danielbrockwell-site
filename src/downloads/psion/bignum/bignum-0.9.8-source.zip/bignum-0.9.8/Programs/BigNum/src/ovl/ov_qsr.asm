; =====================================================================
; OV_QSR: the records of the sieve for a new a: for every sieved prime p its roots for the first b and the
; changes for the others. With h = g q^-1 modulo p for each prime q of a (so that B a^-1 = h), the changes
; are 2 h, and the roots (+-t) a^-1 less the sum of the h's, and M (the block starts at -M).
; =====================================================================
        include "macros.inc"
        include "qs.inc"
        lastent qsr

qa_p    = kv_fs                 ; (2) the prime
qa_r    = kv_fs+2               ; (2) its record
qa_i    = kv_fs+4               ; its place
qa_l    = kv_fs+5
qa_s    = kv_fs+6               ; (2) the sum of the h's
qa_x    = kv_fs+8               ; (2)
qa_v    = kv_fs+10              ; (2) the inverse of the product of the first l primes
qsr:    ldx  q_rec
        stx  qa_r
        ldab q_i0
        stab qa_i
.rec:   bsr  poll
        ldab qa_i               ; p
        ldx  q_p
        abx
        abx
        ldd  0,x
        std  qa_p
        ldx  qa_r
        std  QR_P,x
        ldx  #15                ; its log2, to the nearest
.n:     tsta
        bmi  .f
        asld
        dex
        bra  .n
.f:     asla
        cmpa #$6A               ; (the square root of 2: $B504)
        blo  .lo
        inx
.lo:    xgdx
        ldx  qa_r
        stab QR_L,x
        ldd  #$FFFF             ; not sieved by: in a, or a divisor of k
        std  QR_R1,x
        std  QR_R2,x
        ldab qa_i
        ldx  q_t
        abx
        abx
        ldd  0,x
        beq  .next
        ldx  #q_qi
        ldab q_s
        ldaa qa_i
.in:    cmpa 0,x
        beq  .next
        inx
        decb
        bne  .in
        bsr  roots
.next:  ldx  qa_r
        ldab q_rs
        abx
        stx  qa_r
        inc  qa_i
        ldaa qa_i
        cmpa q_f
        bne  .rec
        rts

; ---- one prime: with P(l) = q(0) ... q(l-1): all of them, one inverse, and back: q(l)^-1 = P(l+1)^-1 P(l).
; The P(l) are pushed on the way up.
roots:  ldd  #1
        std  qa_x
        clr  qa_l
.up:    ldx  qa_x
        pshx
        bsr  qval
        bsr  mulq               ; qa_x = qa_x times q modulo p
        inc  qa_l
        ldaa qa_l
        cmpa q_s
        bne  .up
        bsr  inv16              ; D = the inverse of qa_x
        std  qa_v
        std  kv_al              ; (a^-1)
        clra
        clrb
        std  qa_s
.dn:    dec  qa_l
        pulx                    ; q^-1 = the inverse of P(l+1) times P(l)
        stx  qa_x
        ldd  qa_v
        bsr  mulw
        ldx  #q_ga              ; h
        ldab qa_l
        aslb
        abx
        ldd  0,x
        bsr  mulq
        ldd  qa_s
        addd qa_x
        bsr  red1
        std  qa_s
        ldab qa_l               ; the change: 2 h (none for the last B, which never changes)
        incb
        cmpb q_s
        beq  .last
        ldd  qa_x
        asld
        bsr  red1
        std  zt
        ldx  qa_r
        ldab qa_l
        aslb
        abx
        ldd  zt
        std  QR_D,x
.last:  ldx  qa_v               ; the inverse of P(l) = that of P(l+1) times q
        stx  qa_x
        bsr  qval
        bsr  mulq
        ldx  qa_x
        stx  qa_v
        tst  qa_l
        bne  .dn
        ldab qa_i               ; t a^-1
        ldx  q_t
        abx
        abx
        ldd  0,x
        std  qa_x
        ldd  kv_al
        bsr  mulw
        ldd  q_m                ; M - the sum, modulo p
.m:     subd qa_p
        bcc  .m
        addd qa_p
        subd qa_s
        bcc  .ms
        addd qa_p
.ms:    std  qa_s
        addd qa_x
        bsr  red1
        ldx  qa_r
        std  QR_R1,x
        ldd  qa_s
        subd qa_x
        bcc  .r2
        addd qa_p
.r2:    std  QR_R2,x
        rts
; qval: D = a's prime numbered qa_l
qval:   ldx  #q_qi
        ldab qa_l
        abx
        ldab 0,x
        ldx  q_p
        abx
        abx
        ldd  0,x
        rts
; red1: D (below 2 p) modulo p
red1:   subd qa_p
        bcc  .x
        addd qa_p
.x:     rts
; mulq: qa_x = qa_x D modulo p (D below 1,024); mulw: D below 4,096
mulq:   asld
        asld
        asld
        asld
        asld
        asld
        std  zp
        ldaa #10
        bra  mulg
mulw:   asld
        asld
        asld
        asld
        std  zp
        ldaa #12
mulg:   staa zw
        clra
        clrb
.l:     asld
        subd qa_p
        bcc  .ma
        addd qa_p
.ma:    asl  zp+1
        rol  zp
        bcc  .mb
        addd qa_x
        subd qa_p
        bcc  .mb
        addd qa_p
.mb:    dec  zw
        bne  .l
        std  qa_x
        rts
; inv16: D = the inverse of qa_x modulo p
inv16:  ldd  qa_p               ; r0 = p, r1 = x, t0 = 0, t1 = 1
        std  zx
        ldd  qa_x
        std  zp
        clra
        clrb
        std  ze
        ldd  #1
        std  zt
.l:     ldd  zx                 ; r0 -= r1, t0 -= t1 (modulo p), while it goes
        subd zp
        bcs  .sw
        std  zx
        ldd  ze
        subd zt
        bcc  .p
        addd qa_p
.p:     std  ze
        bra  .l
.sw:    ldx  zx                 ; the two pairs changed over
        ldd  zp
        std  zx
        stx  zp
        ldx  ze
        ldd  zt
        std  ze
        stx  zt
        ldd  zp
        bne  .l
        ldd  ze
        rts
