hk_l:   bsr  pri
        fcl  "Curve "
        bsr  hkc
        ldd  kv_pe              ; (with many curves, only s1 or s2)
        subd kv_p
        cmpb #9
        blo  .s
        bsr  pri
        fcl  "  stage "
        bra  .n
.s:     bsr  pri
        fcl  " s"
.n:     ldab ec_st
        clra
        bra  putw
hk_q:   bsr  pri
        fcl  "ECM "
        ldaa kv_run             ; (paused)
        deca
        bne  .p
        ldaa fx_job
        cmpa #2
        bne  hkc
        ldaa #'L'               ; (no end: the level, and no percentage)
        bsr  putc
        ldaa fx_lvl
        adda #'0'
        bsr  putc
        bsr  putsp
        bsr  hkc
        ldx  kv_pe
        stx  kv_p
        rts
.p:
        bsr  pri
        fcl  "curve "
        ldd  fx_cur
        bra  putw
; with no end to the job: the level, and the time left in it at the right edge
hk_3:   ldaa fx_job
        cmpa #2
        bne  pr_pct
        ovsub OV_HEAD,2
        rts
hkc:    ldd  fx_cur
        bsr  putw
        bsr  putsl
        ldd  fx_crv
        bra  putw
