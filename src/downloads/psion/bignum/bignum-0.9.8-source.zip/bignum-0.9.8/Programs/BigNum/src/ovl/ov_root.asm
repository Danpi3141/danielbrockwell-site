; =====================================================================
; OV_ROOT: SQRT, NROOT (rounded down), by Newton's method. Entry 2: the top number (not negative)
; replaced by its root of the order rt_n (kv_fs, a word)
; =====================================================================
        include "macros.inc"
        entry f_sqrt
        entry f_nroot
        lastent root

rt_n    = kv_fs                 ; the order
f_sqrt: ldd  #2
        bra  rt_go
f_nroot: bsr  ilenw             ; the order: 1 or more
        bmi  rt_arg
        subd #1
        bcs  rt_arg
        beq  .b
        subd #1
        beq  .w
        ldd  #$7FFF             ; (a very high order)
        bra  .d
.w:     ldd  2,x
        bpl  .d
        ldd  #$7FFF
        bra  .d
.b:     ldab 2,x
        clra
.d:     std  rt_n
        bsr  hdrop
        ldd  rt_n
rt_go:  std  rt_n
        ldx  kv_wp
        tst  0,x
        bpl  root
        ldab rt_n+1             ; negative: only an odd order
        lsrb
        bcc  rt_arg
        bsr  hneg               ; rounded down: -(root(|a|-1)+1)
        bsr  hpush1
        bsr  hsub
        bsr  root
        bsr  hpush1
        bsr  hadd
        bra  hneg
rt_arg: bra  errarg

root:   ldx  kv_wp
        ldd  0,x
        beq  rt_x               ; 0
        ldd  rt_n
        subd #1
        beq  rt_x               ; the first root
        ldd  kv_cap             ; (the powers below may pass the cap a little)
        asld
        std  kv_cap
        ovsub OV_DIGS,0         ; kv_bits
        ldd  rt_n
        subd kv_bits
        bhs  .one               ; the order is as much as the bits: 1
        ldx  #0                 ; the start: 2 to the k = (bits + n - 1) / n
        ldd  kv_bits
        addd rt_n
        subd #1
.q:     subd rt_n
        bcs  .k
        inx
        bra  .q
.k:     stx  kv_al
        ldd  kv_al
        lsrd
        lsrd
        lsrd
        addd #1                 ; its bytes
        std  kv_se
        addd #2
        bsr  walloc
        ldd  kv_se
        std  0,x
        inx
        inx
        bsr  clrx
        ldab kv_al+1            ; and the one bit
        andb #7
        ldaa #1
.b:     decb
        bmi  .bd
        asla
        bra  .b
.bd:    ldx  kv_wp
        staa 2,x
        bra  rt_l
.one:   bsr  hdrop
        bsr  hpush1
        bra  rt_cap
; a x: the next x = ((n-1) x + a / x**(n-1)) / n, while it gets smaller
rt_l:   bsr  hdup
        ldd  rt_n
        subd #1
        bsr  hpush
        ldd  rt_n               ; (OV_POW uses kv_fs)
        pshb
        psha
        ovsub OV_POW,0
        pula
        pulb
        std  rt_n
        bsr  hover3
        bsr  hswap
        ovsub OV_DIV,0          ; a x t
        bsr  hover
        ldx  #0
        stx  kv_na
        ldd  rt_n
        subd #1
        bsr  hmuladd
        bsr  hadd
        ldd  rt_n
        bsr  hpush
        ovsub OV_DIV,0          ; a x y
        ldx  kv_wp
        pshx
        bsr  i2
        pula
        pulb
        bsr  hcmp               ; x against y
        bls  .done
        bsr  hnip
        bra  rt_l
.done:  bsr  hdrop
        bsr  hnip
rt_cap: ldd  kv_cap
        lsrd
        std  kv_cap
rt_x:   rts
