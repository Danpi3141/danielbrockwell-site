; ibits: D = the bits of the number (not 0) at X (kept)
ibits:  bsr  ilen
        subd #1
        asld
        asld
        asld
        std  zt
        ldab 2,x
        clra
.b:     inca
        lsrb
        bne  .b
        tab
        clra
        addd zt
        rts
