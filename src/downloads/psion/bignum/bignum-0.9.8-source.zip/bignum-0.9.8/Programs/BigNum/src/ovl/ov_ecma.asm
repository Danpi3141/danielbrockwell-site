; =====================================================================
; OV_ECMA: ECM set up: the bound, the slots, the window, the estimate (for OV_ECM)
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        include "pslen.inc"
        include "ec.inc"
        include "ckn.inc"
        lastent ecma

ecma:
        ldd  fx_lim             ; (the second stage starts at 315 or more)
        subd #315
        bcc  .b
        ldd  #315
        std  fx_lim
.b:     ldab #24                ; the second stage's table: 24 values of u, or 4: three slots each
.sl:    stab ec_s
        ldaa #3
        mul
        addb #14
        stab ms_b
        addb #2
        bsr  room
        bcc  .fit
        ldab ec_s
        cmpb #4
        beq  .fit               ; (NO MEMORY, below)
        ldab #4
        bra  .sl
.fit:   ldx  fx_n
        stx  ms_x
        ldd  #$FFFF
        std  ms_o
        ovsub OV_MSET,0
        ldd  #PS_LEN
        bsr  walloc
        stx  ps_buf
        stx  ec_w
        ldd  fx_crv             ; 64 units a curve
        ldx  #64
        os   UT$UMUL
        xgdx
        bsr  part
        ovsub OV_EST,8
        ldaa #CK_ECM2           ; RESUME: in a curve's second stage?
        bsr  ckpeek
        bcc  .no2
        bsr  mrun
        mo    M_CPY,4,14,14
        mol   M_CPY,5,15,15
        ldab #2
        rts
.no2:   ldaa #CK_ECM1           ; in its first?
        bsr  ckset
        ldab #0
        rolb
        rts
        include "ckset.inc"
        include "ckpeek.inc"
        include "room.inc"
