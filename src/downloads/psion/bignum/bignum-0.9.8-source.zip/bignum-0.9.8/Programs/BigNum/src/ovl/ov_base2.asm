; =====================================================================
; OV_BASE2: the strong test to base 2 of the top number (odd, above 2, kept): kv_pk = 2 if it passes, else
; 0; kv_digs, kv_bits its size. Entry 1: without the display (kv_digs not set). Two slots: the number squared, and 1.
; =====================================================================
        include "macros.inc"
        include "ckn.inc"
        entry base2
        lastent quick

; ---- the strong test to base 2: kv_pk = 2 if it passes
bt_e    = kv_fs                 ; (mx_e: the number, for ebit)
bt_i    = kv_fs+2               ; the bit to do, plus 1
bt_s    = kv_fs+4               ; n - 1 = d 2 to the bt_s
bt_w    = kv_fs+6
quick:  ldaa #1
        bra  bt_go
base2:  ovsub OV_DIGS,0
        clra
bt_go:  psha
        clr  kv_pk
        ldaa #2
        staa kv_pw
        ldx  kv_wp
        stx  bt_w
        stx  mx_e
        bsr  ibits
        std  bt_i
        std  kv_bits
        mset 2,1,NO
        clra                 ; the zeros at the end of n - 1
        clrb
.s:     addd #1
        std  bt_s
        bsr  ebit
        bne  .sd
        ldd  bt_s
        bra  .s
.sd:    pula
        tsta
        bne  bt_q
        ldd  bt_i
        bsr  part
        ovsub OV_EST,3
        ldx  #hook
        bsr  hookx
bt_q:
        bsr  mrun
        mol   M_CPY,0,1,1
        ldaa #CK_BASE2
        bsr  ckset
.l:     bsr  safe
        ldd  bt_i               ; down to the bit bt_s
        subd bt_s
        bls  .d
        ldd  bt_i
        subd #1
        std  bt_i
        ldx  kv_done
        inx
        stx  kv_done
        bsr  mrun
        mol   M_SQR,0,0,0
        ldd  bt_i
        bsr  ebit
        beq  .l
        bsr  mrun
        mol   M_ADD,0,0,0
        bra  .l
.d:     clrb                    ; 1?
        bsr  mslot
        pshb
        psha
        ldab #1
        bsr  mslot
        xgdx
        pula
        pulb
        bsr  cmpn
        beq  .pass
.r:     clrb                    ; -1? (with 1 more it is N: added in the product's room)
        bsr  mslot
        addd mn
        std  zx
        ldab #1
        bsr  mslot
        addd mn
        std  zp
        ldd  mp
        addd mn
        std  ze
        bsr  add3
        bcs  .nm
        ldx  mp
        ldd  mnp
        bsr  cmpn
        beq  .pass
.nm:
        ldd  bt_s
        subd #1
        beq  .fail
        std  bt_s
        bsr  mrun
        mol   M_SQR,0,0,0
        bra  .r
.pass:  ldaa #2
        staa kv_pk
.fail:  ldx  bt_w
        stx  kv_wp
        bra  hook0
hk_t:   fcl  "BPSW  "
hk_p:   fcl  "Base 2 bit "
hk_q:   fcl  "Base 2 "
mx_e    = kv_fs
        include "ibits.inc"
        include "bhook.inc"
        include "ebit.inc"
        include "ckset.inc"
        include "cksafe.inc"
