PS_LEN  = 132                   ; the primes' window (psn.inc)
