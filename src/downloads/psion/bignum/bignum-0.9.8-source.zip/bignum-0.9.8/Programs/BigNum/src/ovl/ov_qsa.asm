; =====================================================================
; OV_QSA: a new a for the sieve: the product of q_s primes of the base, near 2 to the q_lgt/256; the B's
; with b = the sum of +-B, b squared = kN modulo a. Goes on to OV_QSR for the records.
; =====================================================================
        include "macros.inc"
        include "qs.inc"
        lastent qsa

qa_n    = kv_fs                 ; primes chosen
qa_sum  = kv_fs+1               ; (2) their 256 log2
qa_bd   = kv_fs+3               ; (2) how near the target the last one comes
qa_bi   = kv_fs+5               ; which it is
qa_try  = kv_fs+6
qa_best = kv_fs+7               ; (2) the best of the tries
qa_c    = kv_fs+9               ; the window the primes are taken from: its first place
qa_w    = kv_fs+10              ; and its width
qa_l    = kv_fs+11
qa_x    = kv_fs+12              ; (2)
qa_m    = kv_fs+14              ; (2) a modulus
qa_y    = kv_fs+16              ; (2) a number modulo it
; ---- the primes: s-1 at random from a window, the last the one that comes nearest the target; the best of 4
qsa:    ldd  q_np               ; under a cell in four polynomials looked at: more of them are worth it (a cell takes about
        lsrd                    ; as long as a polynomial; measured on the emulator, 36 to 48 digits)
        lsrd
        subd q_cn
        bls  .enough
        ldaa q_fill
        cmpa q_fmax
        bhs  .enough
        adda #2
        staa q_fill
.enough: ldx #0
        stx  q_cn
        bsr  window
        ldd  #$FFFF
        std  qa_best
        ldaa #12
        staa qa_try
.try:   bsr  pick
        ldd  qa_bd              ; (near enough will do: only the nearest would be the same few again and again, and a long
        subd #160               ; job runs out of new ones)
        blo  .got
        ldd  qa_bd
        subd qa_best
        bhs  .nt
        ldd  qa_bd
        std  qa_best
        ldab q_s                ; kept (in the place of the g's)
        ldx  #q_qi
.kp:    ldaa 0,x
        staa 10,x
        inx
        decb
        bne  .kp
.nt:    dec  qa_try
        bne  .try
        ldab q_s
        ldx  #q_qi
.kb:    ldaa 10,x
        staa 0,x
        inx
        decb
        bne  .kb
.got:
; ---- a, and the B's: B = (a/q) g, g = t (a/q)^-1 modulo q (or q - g, if that is smaller)
        ldaa #$FF
        bsr  prod
        ldx  q_a
        bsr  tofix
        clr  qa_l
.bl:    ldab qa_l               ; (a/q) modulo q
        bsr  qval
        std  qa_m
        ldd  #1
        std  qa_y
        clrb
.pm:    cmpb qa_l
        beq  .ps
        pshb
        bsr  qval
        bsr  mulm
        pulb
.ps:    incb
        cmpb q_s
        bne  .pm
        ldx  #0                 ; its inverse: how many times it makes 1
        clra
        clrb
.iv:    inx
        addd qa_y
        subd qa_m
        bcc  .ic
        addd qa_m
.ic:    tsta
        bne  .iv
        cmpb #1
        bne  .iv
        stx  qa_y               ; times t
        ldx  #q_qi
        ldab qa_l
        abx
        ldab 0,x
        ldx  q_t
        abx
        abx
        ldd  0,x
        bsr  mulm
        ldd  qa_m               ; the smaller of g and q - g
        subd qa_y
        std  zt
        subd qa_y
        bcc  .g
        ldd  zt
        std  qa_y
.g:     ldx  #q_ga
        ldab qa_l
        aslb
        abx
        ldd  qa_y
        std  0,x
        ldaa qa_l
        bsr  prod
        ldx  #0
        stx  kv_na
        ldd  qa_y
        bsr  hmuladd
        ldab qa_l
        ldaa q_ub
        mul
        addd q_bl
        xgdx
        bsr  tofix
        inc  qa_l
        ldaa qa_l
        cmpa q_s
        bne  .bl
        ldx  q_b                ; b = the sum of the B's
        ldab q_ub
        clra
        std  mn
        bsr  clrx
        ldd  q_bl
        std  qa_x
        ldab q_s
.sb:    pshb
        ldd  q_b
        addd mn
        std  zx
        std  ze
        ldd  qa_x
        addd mn
        std  qa_x
        std  zp
        bsr  add3
        pulb
        decb
        bne  .sb
        ldx  #0                 ; the polynomials: 2 to the s-1
        stx  q_pi
        ldab q_s
        stab zt
        ldd  #1
        bra  .ne
.np:    asld
.ne:    dec  zt
        bne  .np
        std  q_np
        ovjump OV_QSR,0

; window: where the primes are taken from: around the one nearest 2 to the target/s
window: ldx  q_lgt
        ldab q_s
        clra
        os   UT$UDIV            ; (X / D)
        stx  kv_al
        ldx  q_lg
        ldab q_plo
.c:     cmpb q_phi
        beq  .cd
        pshb
        ldd  0,x
        inx
        inx
        subd kv_al
        pulb
        bcc  .cd
        incb
        bra  .c
.cd:    ldaa q_s                ; its half width: s + 5, at least 8
        adda #5
        cmpa #8
        bhs  .w
        ldaa #8
.w:     staa qa_w
        subb qa_w               ; from that far below ...
        bcs  .lo
        cmpb q_plo
        bhs  .l1
.lo:    ldab q_plo
.l1:    stab qa_c
        ldaa q_phi              ; ... twice as wide, within the primes there are
        sba
        asl  qa_w
        cmpa qa_w
        bhs  .x
        staa qa_w
.x:     rts
; pick: q_qi: different primes at random from the window (with fewer than 6, the last is the nearest); qa_bd = how
; far off the target
pick:   clr  qa_n
        clra
        clrb
        std  qa_sum
.r:     bsr  rand               ; a place in the window
        ldab qa_w
        mul
        adda qa_c
        bsr  free
        beq  .r
        bsr  put
        bsr  lgof
        addd qa_sum
        std  qa_sum
        inc  qa_n
        ldaa q_s                ; all of them at random, or (few: short jobs) the last one the nearest
        cmpa #6
        bhs  .all
        deca
.all:   cmpa qa_n
        bne  .r
        ldaa q_s
        cmpa qa_n
        bne  .last
        ldd  qa_sum
        subd q_lgt
        bcc  .d
        coma
        comb
        addd #1
.d:     std  qa_bd
        rts
.last:  ldd  #$FFFF             ; the last: the nearest
        std  qa_bd
        ldaa q_plo
.n:     bsr  free
        beq  .nn
        psha
        bsr  lgof
        addd qa_sum
        subd q_lgt
        bcc  .ps
        coma
        comb
        addd #1
.ps:    std  kv_al
        subd qa_bd
        pula
        bhs  .nn
        ldx  kv_al
        stx  qa_bd
        staa qa_bi
.nn:    inca
        cmpa q_phi
        bne  .n
        ldaa qa_bi
put:    ldx  #q_qi              ; A put in (kept)
        ldab qa_n
        abx
        staa 0,x
        rts
; free: Z if the place A is taken, or its prime divides k (A kept)
free:   ldx  #q_qi
        ldab qa_n
        beq  .no
.l:     cmpa 0,x
        beq  .x
        inx
        decb
        bne  .l
.no:    ldx  q_t
        tab
        abx
        abx
        ldx  0,x
.x:     rts
; lgof: D = 256 log2 of the prime at A
lgof:   suba q_plo
        ldx  q_lg
        tab
        abx
        abx
        ldd  0,x
        rts
; rand: A = a random byte
rand:   ldx  #3                 ; (a shift register and a counter: 4 thousand million before it comes round)
.s:     ldd  q_rng
        asld
        bcc  .n
        eorb #$2D
.n:     std  q_rng
        dex
        bne  .s
        ldd  q_rng2
        addd #$9E37
        std  q_rng2
        eora q_rng+1
        rts
; qval: D = the prime numbered B of a
qval:   ldx  #q_qi
        abx
        ldab 0,x
        ldx  q_p
        abx
        abx
        ldd  0,x
        rts
; prod: the product of a's primes but for the one numbered A ($FF: all), pushed
prod:   staa qa_x
        bsr  hpush1
        clrb
.l:     cmpb qa_x
        beq  .n
        pshb
        bsr  qval
        ldx  #0
        stx  kv_na
        bsr  hmuladd
        pulb
.n:     incb
        cmpb q_s
        bne  .l
        rts
; mulm: qa_y = qa_y D modulo qa_m (D below 1,024)
mulm:   asld
        asld
        asld
        asld
        asld
        asld
        std  zp
        ldaa #10
        staa zw
        clra
        clrb
.l:     asld
        subd qa_m
        bcc  .a
        addd qa_m
.a:     asl  zp+1
        rol  zp
        bcc  .b
        addd qa_y
        subd qa_m
        bcc  .b
        addd qa_m
.b:     dec  zw
        bne  .l
        std  qa_y
        rts
; tofix: the top number (not negative) into the ub bytes at X, and dropped
tofix:  ldab q_ub
        clra
        bsr  clrx
        stx  zp
        bsr  ilenw
        pshb
        psha
        bsr  inext
        stx  zx
        pula
        pulb
        bsr  cpd
        bra  hdrop
