; the busiest variables, in the OS's zero page: OPL's and the calculator's variables, which the OS does not look at
; while this runs, nor do its alarms (but for $C5-$CB, left alone; $E0-$E1 are the alarms' too, $E2-$F9 the rows').
; kinit saves what was there, and leave puts it back. Chosen by counting: no tst, inc, clr... of one is any shorter.
ZP_1    = $A7
ZP_1N   = 30
ZP_2    = $CC
ZP_2N   = 20
ZP_N    = ZP_2+ZP_2N-ZP_1
kv_fs   = $A7                   ; (24) a function's own variables (kept while other overlays come and go)
kv_lim  = $BF                   ; (2)
ps_lo   = $C1                   ; (3)
kv_h    = $C4                   ; (1) the display's lines
kv_wp   = $CC                   ; (2)
kv_al   = $CE                   ; (2)
mn      = $D0                   ; (2) the modulus's bytes
kv_se   = $D2                   ; (2)
ma      = $D4                   ; (2)
mal     = $D6                   ; (2)
kv_n    = $D8                   ; (4)
ps_d    = $DC                   ; (2)
kv_done = $DE                   ; (2) units done
; the variables, after the code (cleared at start); then the overlay slot, as long as the machine needs: the
; smallest tier's overlays are all short (OV_SMALL); the sieve's and the files' are longer (OV_SIZE)
kv_vars:
kv_sp:   rmb 2                  ; the stack pointer to leave with
kv_osk:  rmb 2                  ; RTA_SP to go back to
kv_dev:  rmb 1                  ; the device BNK is on
kv_bpa:  rmb 3                  ; the overlays' pack address, in BNK
kv_bpl:  rmb 3                  ; and in BNL (those from OV_2 on)
kv_res:  rmb 1                  ; the overlay in the slot
kv_slt:  rmb 2                  ; where an overlay is read to (the slot)
kv_bs:   rmb 2
kv_fo:   rmb 2
kv_cnt:  rmb 1
kv_tmp:  rmb 2
kv_four: rmb 1                  ; 1 four lines
kv_oldm: rmb 1
kv_kbst: rmb 1
kv_w:    rmb 1                  ; the display's width
kv_lbuf: rmb 20                 ; a line being made up
kv_ln:   rmb 1
kv_p:    rmb 2
kv_pe:   rmb 2
md_h:    rmb 4                  ; (muldiv)
md_a:    rmb 4
kv_nd:   rmb 1
kv_ts:   rmb 2
; the block
kv_lo:   rmb 2
kv_vb:   rmb 2
kv_hi:   rmb 2
kv_tier: rmb 1                  ; 1 to 4
kv_cap:  rmb 2                  ; the largest number, bytes
kv_cap0: rmb 2
kv_wm:   rmb 1                  ; the rows' width
kv_et:   rmb 2                  ; the rows' entries
kv_rx:   rmb 2                  ; the address of their last jmp's operand
; the line
kv_boot  = kv_fs                ; (2) the bootstrap's place, at the start
kv_line: rmb 2                  ; its text (a length byte, then the text)
kv_lmax: rmb 1                  ; the longest it may be
kv_rec:  rmb 2                  ; the lines kept for recall
kv_recn: rmb 2                  ; their room
kv_epos: rmb 1                  ; where in the line an error is
kv_err:  rmb 1                  ; the error to show (0 none)
kv_ri:   rmb 1                  ; the line recalled (0 none, 1 the newest)
kv_cur:  rmb 1                  ; the cursor in the line
kv_ws:   rmb 1                  ; the first character shown
kv_rw:   rmb 1                  ; the row it is on
kv_osp:  rmb 2                  ; the operator stack's top
kv_tp:   rmb 1                  ; the place in the line
kv_tp0:  rmb 1                  ; where the expression starts
kv_cp:   rmb 1                  ; an operator's place
kv_id:   rmb 1                  ; a name: where it starts
kv_il:   rmb 1                  ; and its letters
kv_fn:   rmb 3                  ; a function: its arguments, overlay and entry
kv_chk:  rmb 1                  ; the line is only being checked
kv_dst:  rmb 1                  ; the variable it goes to
kv_rk:   rmb 1                  ; the kind of result (RK_...)
; a long run
kv_run:  rmb 1
kv_hook: rmb 2                  ; the display's routine (in the overlay running)
kv_hov:  rmb 1                  ; the overlay it is in (0: resident)
kv_tot:  rmb 2                  ; of so many
kv_est:  rmb 4                  ; the seconds the whole should take
kv_e0:   rmb 4                  ; when this part of it began
kv_ld:   rmb 2                  ; the time left: the units done when it was last worked out
kv_le:   rmb 2                  ; and when that was (seconds)
kv_ext:  rmb 4                  ; the seconds the parts to come should take
kv_pk:   rmb 1                  ; prime: 0 no 1 yes 2 probably
kv_pw:   rmb 1                  ; why not
kv_pf:   rmb 2                  ; a small factor
kv_rl:   rmb 2                  ; the list of results
kv_full: rmb 1                  ; everything is to be drawn
kv_skp:  rmb 1                  ; S skips
kv_why:  rmb 1
kv_esc:  rmb 2                  ; where to go when it is stopped (overlay, entry)
kv_ssp:  rmb 2
kv_sec:  rmb 1
kv_ckm:  rmb 1                  ; what can be kept of the run (0 nothing)
kv_ckd:  rmb 1                  ; 1: to be kept at the next safe place, 2: and the run left; bit 7: RESUME
kv_ckt:  rmb 2                  ; seconds until the next time it is kept (0: never)
kv_el:   rmb 4                  ; seconds
; numbers
kv_ia:   rmb 2
kv_ib:   rmb 2
kv_na:   rmb 2
kv_nb:   rmb 2
kv_cy:   rmb 1
kv_digs: rmb 2                  ; a number's digits
kv_bits: rmb 2                  ; SIZE's bits
st_beep: rmb 1                  ; settings
st_rho:  rmb 2
st_pm1:  rmb 2
st_pp1:  rmb 2
st_ecm:  rmb 2
st_cur:  rmb 2
st_tdiv: rmb 2
st_proof: rmb 1
st_keep: rmb 1
st_every: rmb 2
st_log:  rmb 1
st_ups:  rmb 2                  ; units of 256 cycles a second (3600, or as BENCH measures)
st_last:
dg_at    = kv_fs
dg_end   = kv_fs+2
dg_n     = kv_fs+4
dg_sk    = kv_fs+6
dg_neg   = kv_fs+7
pg_at    = kv_fs+8               ; the pager: the page's first character
pg_i     = kv_fs+10              ; the next one to draw
pg_w     = kv_fs+12              ; characters on a row
pg_v     = kv_fs+13              ; 1: V can store it
ms_x:    rmb 2                  ; OV_MSET's modulus
ms_b:    rmb 1                  ; how many slots
ms_o:    rmb 1                  ; the slot for 1
ms_r:    rmb 1                  ; and for R squared
kv_pv:   rmb 26                 ; PROVE's
kv_fz:   rmb 18                 ; FACTOR's
kv_fx:   rmb 24                 ; the same for the drivers of other functions
ps_buf:  rmb 2                  ; the primes (primes.inc): the window
ps_i:    rmb 2
ps_p:    rmb 3
ps_wi:   rmb 1
; the core
mb:      rmb 2
mbl:     rmb 2
mp:      rmb 2
mpe:     rmb 2
mye:     rmb 2
mrem:    rmb 2
mq:      rmb 2
mwq:     rmb 1
mpc:     rmb 2
mr2:     rmb 2
mnp:     rmb 2                  ; the modulus
mne:     rmb 2                  ; its end
ms:      rmb 2                  ; the slots
mrs:     rmb 2
mk:      rmb 1
mi:      rmb 3
kv_slz:  rmb 2                  ; the slot's size
kv_end:
ov_slot: rmb OV_SIZE
; (not on the smallest tier)
kv_prg:  rmb PRG_SIZE           ; OV_PROG, kept
kv_fy:   rmb 18                 ; the combining's
kv_ckv:  rmb 1                  ; the device (1 to 3) of the kept run
kv_ckw:  rmb 1                  ; 1: it has been written
q_svn:   rmb 2                  ; the sieve's relations written
q_svp:   rmb 2                  ; and partial ones
; the quadratic sieve
q_bits:  rmb 2                  ; kN's bits
q_bs:    rmb 2
q_k:     rmb 1                  ; the multiplier (these three together: KEEP)
q_s:     rmb 1                  ; the primes in an a
q_f:     rmb 1                  ; the primes of the base
q_ub:    rmb 1                  ; the bytes of u, a, b
q_i0:    rmb 1                  ; the first of them sieved by
q_rs:    rmb 1                  ; a record's bytes
q_lm:    rmb 1                  ; log2(M)
q_fill:  rmb 1                  ; what a cell starts at
q_fmax:  rmb 1                  ; and may come to
q_cn:    rmb 2                  ; the cells looked at for the a
q_plo:   rmb 1                  ; the primes for a's
q_phi:   rmb 1
q_svz:   rmb 2                  ; the sieve's numbers
q_m:     rmb 2                  ; half of them
q_lgt:   rmb 2                  ; 256 log2 of the a wanted
q_kn:    rmb 2                  ; kN, 2 ub bytes
q_p:     rmb 2                  ; the primes
q_t:     rmb 2                  ; the square roots
q_lg:    rmb 2                  ; 256 log2 of the primes for a's
q_a:     rmb 2                  ; a
q_b:     rmb 2                  ; b (it may be negative)
q_bl:    rmb 2                  ; the B's
q_u:     rmb 2                  ; work
q_v:     rmb 2
q_sv:    rmb 2                  ; the sieve
q_rec:   rmb 2                  ; the records
q_rece:  rmb 2
q_rel:   rmb 2                  ; the relations
q_rn:    rmb 2                  ; their entries
q_pa:    rmb 2                  ; the partial ones, down from q_pe
q_pe:    rmb 2
q_pn:    rmb 2
q_nr:    rmb 2                  ; relations so far
q_need:  rmb 2                  ; wanted
q_lp:    rmb 2                  ; the largest prime allowed outside the base (0 none)
q_rng:   rmb 2
q_rng2:  rmb 2
q_pi:    rmb 2                  ; the polynomial
q_np:    rmb 2                  ; of so many
q_qi:    rmb 10                 ; a's primes (their places in the base)
q_ga:    rmb 20                 ; and the numbers that make the B's
kv_big:
