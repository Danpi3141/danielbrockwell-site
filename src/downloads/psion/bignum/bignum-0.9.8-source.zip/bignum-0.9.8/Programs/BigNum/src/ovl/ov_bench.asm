; =====================================================================
; OV_BENCH: times this machine: modular products of 64 to 1,024 bits, each for two seconds or more, and how fast
; that is against what the estimates reckoned with: st_ups, kept with the settings, is put right.
; =====================================================================
        include "macros.inc"
        lastent bench

be_i    = kv_fx                 ; the size: 0 to 4
be_n    = kv_fx+1               ; (2) products
be_t    = kv_fx+3               ; (2) when it began, in twentieths of a second
be_w    = kv_fx+5               ; (2) the stack of numbers
be_r    = kv_fx+7               ; (10) the results, in tenths of a millisecond
SIZES   = 5
bench:  bsr  cls
        bsr  ln0
        bsr  pri
        fcl  "BENCH  15 s"
        bsr  out
        ldx  kv_wp
        stx  be_w
        clr  be_i
.s:     ldaa #8                 ; a modulus of 8, 16, 32, 64, 128 bytes, all $AB
        ldab be_i
.sz:    decb
        bmi  .sm
        asla
        bra  .sz
.sm:    psha
        tab
        clra
        addd #2
        bsr  walloc
        pulb
        clra
        std  0,x
        ldaa #$AB
.f:     staa 2,x
        inx
        decb
        bne  .f
        ldx  kv_wp
        stx  ms_x
        ldab #3
        stab ms_b
        ldd  #$01FF
        std  ms_o
        ovsub OV_MSET,0
        bsr  mrun               ; some number
        mo    M_ADD,2,1,1
        mol   M_ADD,2,2,1
        ldx  #0
        stx  be_n
        ldx  TMW_FRAM           ; from the start of a twentieth
.b:     cpx  TMW_FRAM
        beq  .b
        ldx  TMW_FRAM
        stx  be_t
.l:     bsr  mrun
        mol   M_MUL,2,2,2
        ldx  be_n
        inx
        stx  be_n
        ldd  TMW_FRAM
        subd be_t
        subd #40
        blo  .l
        addd #40
        std  kv_n+2             ; twentieths x 500 / products
        ldx  #0
        stx  kv_n
        std  kv_se
        ldd  #500
        std  kv_na
        ldd  be_n
        std  kv_nb
        bsr  muldiv
        ldab be_i
        aslb
        ldx  #be_r
        abx
        ldd  kv_n+2
        std  0,x
        ldaa be_i               ; 64 bytes: 944 x 256 cycles each: how many of those a second
        cmpa #3
        bne  .n
        ldd  #18880
        std  kv_n+2
        clra
        clrb
        std  kv_n
        ldd  be_n
        std  kv_na
        ldd  kv_se
        std  kv_nb
        bsr  muldiv
        ldd  kv_n+2
        std  st_ups
.n:     ldx  be_w
        stx  kv_wp
        inc  be_i
        ldaa be_i
        cmpa #SIZES
        bne  .s
        ovsub OV_SETF,1
        ldaa #SIZES+1
        bsr  list
        clr  RTB_BL
        rts
; a line: " 128b   31.0ms", or the speed
li_row: cmpb #SIZES
        beq  .sp
        pshb
        stab zm
        ldd  #64
.d:     dec  zm
        bmi  .p
        asld
        bra  .d
.p:     bsr  putw
        ldaa #'b'
        bsr  putc
        ldab #7
        bsr  col
        pulb
        aslb
        ldx  #be_r
        abx
        ldd  0,x
        std  kv_n+2
        ldx  #0
        stx  kv_n
        ldab #10
        bsr  ndiv
        psha
        bsr  putn
        ldaa #'.'
        bsr  putc
        pula
        adda #'0'
        bsr  putc
        bsr  pri
        fcl  "ms"
        rts
.sp:    bsr  pri
        fcl  "Speed "
        ldd  st_ups
        std  kv_n+2
        ldx  #0
        stx  kv_n
        ldab #36
        bsr  ndiv
        bsr  putn
        ldaa #'%'
        bra  putc
        include "list.inc"
