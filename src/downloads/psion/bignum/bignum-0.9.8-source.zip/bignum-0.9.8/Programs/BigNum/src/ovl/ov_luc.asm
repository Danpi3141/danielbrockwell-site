; =====================================================================
; OV_LUC: the extra strong Lucas test (Grantham; Q = 1, P = lu_p, chosen by OV_LUCP) of the number at mx_e:
; kv_pk = 2 if it passes, else 0.
; =====================================================================
        include "macros.inc"
        include "ckn.inc"
        lastent lucas

mx_e    = kv_fs                 ; the number, for ebit
lu_i    = kv_fs+2               ; the bit to do, plus 1
lu_s    = kv_fs+4               ; n + 1 = d 2 to the lu_s
lu_p    = kv_fs+6               ; P
lu_f    = kv_fs+7               ; there is room for slots 2 (1), 3 (P) and 4 (2)
lu_o    = kv_fs+8               ; addc, subc: M_ADD or M_SUB
lu_b    = kv_fs+9               ; and the slot
lu_q    = kv_fs+10              ; 256**n / N
lucas:  ldx  mx_e
        bsr  ibits
        std  kv_bits
        ldx  mx_e               ; room for five slots? (or there are two)
        bsr  ilen
        std  zt
        asld
        asld
        asld
        subd zt                 ; 7 n, and 32
        addd #32
        std  zt
        ldd  kv_wp
        subd kv_lim
        subd zt
        ldaa #0
        rola
        eora #1
        staa lu_f
        ldx  mx_e
        stx  ms_x
        ldx  #$02FF
        ldab #5
        tsta
        bne  .c
        ldx  #$FFFF             ; two slots, and no 1
        ldab #2
.c:     stab ms_b
        stx  ms_o
        ovsub OV_MSET,0
        tst  lu_f
        bne  .q
        bsr  quot
.q:
        ldd  #$FFFF             ; the ones at the end of n
.s:     addd #1
        std  lu_s
        subd kv_bits
        bhs  .sd
        ldd  lu_s
        bsr  ebit
        beq  .sd
        ldd  lu_s
        bra  .s
.sd:    ldd  kv_bits
        std  lu_i
        bsr  part
        ovsub OV_EST,2
        ldx  #0
        stx  kv_ext
        stx  kv_ext+2
        ldx  #hook
        bsr  hookx
        tst  lu_f
        beq  .z
        bsr  mrun
        mo    M_ADD,4,2,2
        mol   M_CPY,3,2,2
        ldaa lu_p
.mp:    deca
        beq  .v
        psha
        bsr  mrun
        mol   M_ADD,3,3,2
        pula
        bra  .mp
.v:     bsr  mrun               ; V0 = 2, V1 = P
        mo    M_ADD,0,2,2
        mol   M_CPY,1,2,2
        ldaa lu_p
        deca
        ldab #1
        bsr  addc
        bra  .k
.z:     clrb
        bsr  mslot
        xgdx
        bsr  clrxn
        bsr  clrxn
        clrb
        ldaa #2
        bsr  addc
        ldab #1
        ldaa lu_p
        bsr  addc
.k:
        ldaa #CK_LUC
        bsr  ckset
; the ladder, for the bits of d = (n >> s) | 1
.l:     bsr  safe
        ldd  lu_i
        subd lu_s
        beq  .end
        bcs  .end
        ldd  lu_i
        subd #1
        std  lu_i
        ldx  kv_done
        inx
        stx  kv_done
        subd lu_s
        beq  .one               ; (the lowest bit of d is 1)
        ldd  lu_i
        bsr  ebit
        bne  .one
        bsr  mrun
        mo    M_MUL,1,0,1
        mol   M_SQR,0,0,0
        ldab #1
        bra  .sub
.one:   bsr  mrun
        mo    M_MUL,0,0,1
        mol   M_SQR,1,1,1
        clrb
.sub:   pshb                    ; slot B less P, the other less 2
        ldaa lu_p
        bsr  subc
        pulb
        eorb #1
        ldaa #2
        bsr  subc
        bra  .l
; (n all ones: no bits of n are left: d = 1)
.end:   ldd  lu_s
        subd kv_bits
        bne  .chk
        bsr  mrun               ; V1 = P, V2 = P P - 2
        mo    M_CPY,0,1,1
        mol   M_SQR,1,1,1
        ldab #1
        ldaa #2
        bsr  subc
; V(d) = 2 and V(d+1) = P, or both the negative?
.chk:   clrb
        ldaa #2
        bsr  subc
        clrb
        bsr  iszero
        bne  .m
        ldab #1
        ldaa lu_p
        bsr  subc
        bra  .z1
.m:     clrb
        ldaa #4
        bsr  addc
        clrb
        bsr  iszero
        bne  .w
        ldab #1
        ldaa lu_p
        bsr  addc
.z1:    ldab #1
        bsr  iszero
        beq  .pass
        bra  .fail
.w:     clrb
        ldaa #2
        bsr  subc
; or V(d 2**r) = 0 for an r from 0 to s-2 (lu_i = 0: RESUME comes back to here)
        clra
        clrb
        std  lu_i
.r:     bsr  safe
        ldx  kv_done
        inx
        stx  kv_done
        ldd  lu_s
        subd #1
        beq  .fail
        bcs  .fail
        std  lu_s
        clrb
        bsr  iszero
        beq  .pass
        bsr  mrun
        mol   M_SQR,0,0,0
        clrb
        ldaa #2
        bsr  subc
        bra  .r
.pass:  ldaa #2
        staa kv_pk
.fail:  ldx  mx_e
        stx  kv_wp
        bra  hook0
; subc: slot B less A; addc: plus A (times 1). With room they are slots; without, they are done by adding multiples of N
addc:   pshb
        ldab #M_ADD
        bra  sc
subc:   pshb
        ldab #M_SUB
        tst  lu_f
        beq  sc
        cmpa #2
        beq  .two
        cmpa lu_p
        bne  sc
        ldaa #3
        bra  .f
.two:   ldaa #4
.f:     staa mi+2
        pulb
        stab mi
        stab mi+1
        ldab #M_SUB
        bra  mop
sc:     stab lu_o
        tst  lu_f
        bne  .m
        pulb
        stab lu_b
        ldab lu_o
        cmpb #M_SUB
        beq  .dn
        psha                    ; x + c = -(-x - c)
        bsr  neg
        pula
        bsr  .dn
        bra  neg
.dn:    tsta
        beq  .x
        psha
        bsr  sub1
        pula
        deca
        bra  .dn
.m:     pulb
        stab mi
        stab mi+1
        ldab #2
        stab mi+2
.l:     tsta
        beq  .x
        psha
        ldab lu_o
        bsr  mop
        pula
        deca
        bra  .l
.x:     rts
; quot: lu_q: N added to nothing until there is a carry (in the product's room)
quot:   clr  lu_q
        ldx  mp
        bsr  clrxn
.l:     bsr  poll               ; (up to 255 of them)
        ldd  mp
        addd mn
        std  zx
        std  ze
        ldx  mne
        stx  zp
        bsr  add3
        bcs  .x
        inc  lu_q
        bra  .l
.x:     rts
; sub1: the slot less 1 (R modulo N, which is R - lu_q N): lu_q N added and R dropped, or N as well
sub1:   bsr  ends2
        ldx  mn
        stx  zt
        clr  zm
.l:     ldx  zp
        dex
        stx  zp
        ldab 0,x
        ldaa lu_q
        mul
        addb zm
        adca #0
        ldx  zx
        dex
        stx  zx
        addb 0,x
        adca #0
        stab 0,x
        staa zm
        ldx  zt
        dex
        stx  zt
        bne  .l
        tst  zm
        bne  .x
        bsr  ends2
        bra  add3
.x:     rts
; neg: the slot = N less it (0 stays)
neg:    ldab lu_b
        bsr  iszero
        beq  .x
        bsr  ends2
        ldd  zx
        ldx  zp
        std  zp
        stx  zx
        bra  sub3
.x:     rts
; ends2: zx, ze = the slot's end, zp = N's
ends2:  ldab lu_b
        bsr  mslot
        addd mn
        std  zx
        std  ze
        ldx  mne
        stx  zp
        rts
hk_t:   fcl  "BPSW  "
hk_p:   fcl  "Lucas bit "
hk_q:   fcl  "Lucas "
        include "iszero.inc"
        include "ibits.inc"
        include "bhook.inc"
        include "ebit.inc"
        include "ckset.inc"
        include "cksafe.inc"
