; =====================================================================
; OV_QSX: the sieve's answer: each free row of OV_QSL's table stands for relations whose product is a square:
; X = the product of their u's, Y = the square root of the product of the u u - kN (from the primes'
; exponents), and the GCD of X - Y and N is a factor half the time at least. fx_found = 1 and the factor
; pushed, or 0.
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        include "qs.inc"
        include "ql.inc"
        lastent qsx

qx_r    = kv_fs+13              ; the row
qx_j    = kv_fs+14              ; a relation
qx_e    = kv_fs+16              ; (2) its entry
qx_in   = kv_fy+10              ; (2) which relations are in it
qx_ex   = kv_fy+12              ; (2) the exponents
qx_w    = kv_fy+14              ; (2) the stack of numbers
; slots: 0 X, 1 Y, 2 scratch, 3 R squared, 4 1
qsx:    ldab ql_n
        clra
        bsr  walloc
        stx  qx_in
        ldab q_f
        clra
        asld
        bsr  walloc
        stx  qx_ex
        ldx  fx_n
        mset 5,4,3
        ldd  mn
        std  mnx
        ldx  kv_wp
        stx  qx_w
        ldab ql_n
        clra
        bsr  part
        ldx  #hook
        bsr  hookx
        clr  qx_r
.row:   ldx  ql_use             ; the next free row
        ldab qx_r
        abx
        tst  0,x
        beq  .go
.next:  ldx  qx_w
        stx  kv_wp
        inc  qx_r
        ldaa qx_r
        cmpa ql_n
        bne  .row
        rts                     ; (no luck with any of them)
.go:    ldx  qx_in              ; the relations in it: itself, and the pivots of the columns noted
        ldab ql_n
        clra
        bsr  clrx
        ldx  qx_in
        ldab qx_r
        abx
        inc  0,x
        clr  qx_j
.c:     ldab qx_j
        lsrb
        lsrb
        lsrb
        pshb
        ldaa qx_r
        ldab ql_rb
        mul
        addd ql_m
        xgdx
        pulb
        abx
        ldaa 0,x
        ldab qx_j
        andb #7
.sh:    decb
        bmi  .sd
        lsra
        bra  .sh
.sd:    lsra
        bcc  .cn
        ldx  ql_piv
        ldab qx_j
        abx
        ldab 0,x
        cmpb #255
        beq  .cn
        ldx  qx_in
        abx
        inc  0,x
.cn:    inc  qx_j
        ldaa qx_j
        deca
        cmpa q_f
        bne  .c
        ldx  qx_ex
        ldab q_f
        clra
        asld
        bsr  clrx
        bsr  mrun
        mo    M_CPY,0,4,4
        mol   M_CPY,1,4,4
        bsr  hpush1             ; the part of Y made so far, as a number
        ldab ql_n               ; (each try a part of its own)
        clra
        bsr  part
        ldx  q_rel
        stx  qx_e
        clr  qx_j
.rel:   ldx  qx_e
        ldaa 0,x
        psha
        ldx  qx_in
        ldab qx_j
        abx
        ldab 0,x
        pshb
        beq  .r1
        ldx  qx_e
        bsr  one
.r1:    bsr  nexte
        pulb
        pula
        tsta
        bpl  .rn
        tstb
        beq  .r2
        pshb
        ldx  qc_b               ; a pair: its large prime into Y
        ldab 0,x
        clra
        ldaa qc_n
        deca
        beq  .b1
        ldd  0,x
        bra  .lp
.b1:    clra
.lp:    bsr  yprime
        pulb
        ldx  qx_e
        bsr  one
.r2:    bsr  nexte
.rn:    ldx  kv_done
        inx
        stx  kv_done
        inc  qx_j
        ldaa qx_j
        cmpa ql_n
        bne  .rel
; Y: each prime to half its exponent
        clr  qx_j
.y:     ldab qx_j
        ldx  qx_ex
        abx
        abx
        ldd  0,x
        lsrd
        std  qx_e
.yl:    ldd  qx_e
        beq  .yn
        subd #1
        std  qx_e
        ldab qx_j
        ldx  q_p
        abx
        abx
        ldd  0,x
        bsr  yprime
        bra  .yl
.yn:    inc  qx_j
        ldaa qx_j
        cmpa q_f
        bne  .y
        bsr  yflush
        bsr  mrun
        mol   M_SUB,2,0,1
        ldab #2
        bsr  sgcd
        bsr  kind
        beq  .next
        bcc  .next
        inc  fx_found
        rts
; one: the entry at X: X times u, the exponents added up
one:    ldd  mp                 ; (qstd squares u into its own room)
        pshb
        psha
        bsr  qstd
        pula
        pulb
        std  mp
        ldd  mnx
        std  mn
        ldab #2                 ; u into slot 2
        bsr  mslot
        xgdx
        ldd  mnx
        bsr  clrx
        stx  zp
        ldab q_ub
        clra
        std  zt
        ldd  q_u
        addd #2
        addd zt
        std  zx
        ldd  zt
        bsr  cpd
        bsr  mrun
        mo    M_MUL,2,2,3
        mol   M_MUL,0,0,2
        rts
mnx     = kv_fs+20              ; N's bytes (qstd uses mn)
; yprime: the prime D into Y
yprime: ldx  #0
        stx  kv_na
        bsr  hmuladd
        bsr  ilenw              ; into slot 1 before it is as long as N
        addd #2
        subd mnx
        blo  yp_x
yflush: ldx  kv_wp
        ldd  mnx
        std  mn
        ldab #2
        bsr  toslot
        bsr  mrun
        mo    M_MUL,2,2,3
        mol   M_MUL,1,1,2
        bsr  hdrop
        bra  hpush1
yp_x:   rts
nexte:  ldx  qx_e
        ldab q_ub
        abx
        stx  qx_e
        rts
neg:    rts
hit:    psha
        ldx  qx_ex
        abx
        abx
        pulb
        clra
        addd 0,x
        std  0,x
        rts

hk_l:   bsr  pri
        fcl  "Square root"
        rts
hk_q:   bsr  pri
        fcl  "QS root"
        rts
        include "sgcd.inc"
        include "mslot.inc"
        include "qstd.inc"
        include "qdiv.inc"
        include "mhook.inc"
hk_3    = pr_pct
