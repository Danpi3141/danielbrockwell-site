; =====================================================================
; OV_HEAD: the fixed lines of a method's display (four lines): its name and the number's size, and the last
; line. fx_m = the method.
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        include "fa.inc"
        entry head
        entry job
        lastent level

head:   bsr  clsf
        bsr  ln0
        ldx  #names
        ldab fx_m
.f:     beq  .n
        pshb
        ldab 0,x
        inx
        abx
        pulb
        decb
        bra  .f
.n:     bsr  prs
        bsr  pri
        fcl  "  C"
        ldd  fx_dg
        bsr  putw
        ldab fx_m               ; the bounds: B1; the sieve's primes
        decb
        bmi  .o
        cmpb #3
        beq  .qs
        bhi  .o
        bsr  pri
        fcl  "  B1="
        ldd  fx_lim
        bsr  putw
        bra  .o
.qs:    bsr  pri
        fcl  "  base "
        ldab q_f
        clra
        bsr  putw
.o:     bsr  out
        ldaa #3
        bsr  ln
        bsr  jobline
        bra  out
; level: the line begun: ECM's level, and the time left in it at the right edge
level:  bsr  pr_left            ; (how long it is)
        ldd  kv_p
        subd #kv_lbuf
        pshb
        bsr  ln2
        pulb
        pshb
        ldaa #'L'
        bsr  putc
        cmpb #13
        bhs  .n                 ; (a long time: only its number)
        bsr  pri
        fcl  "evel "
.n:     ldaa fx_lvl
        adda #'0'
        bsr  putc
        pulb
        bsr  rcol
        bra  pr_left
; job: two lines: the job, and the step, for two seconds
job:    bsr  cls
        bsr  ln0
        ldaa #'C'
        bsr  putc
        ldd  fx_dg
        bsr  putw
        ldaa fx_job
        deca
        beq  .time
        bsr  pri
        fcl  " no set end"
        bra  .o
.time:  bsr  pri
        fcl  " job "
        ldd  fx_js
        std  kv_n
        ldd  fx_js+2
        std  kv_n+2
        bsr  putj
.o:     bsr  out
        bsr  ln1
        ldx  #names
        ldab fa_st
        cmpb #4                 ; (the sieve by itself)
        bne  .f
        bsr  pri
        fcl  "Sieve"
        bra  .w
.f:     tstb
        beq  .n
        pshb
        ldab 0,x
        incb
        abx
        pulb
        decb
        bra  .f
.n:     bsr  prs
        ldaa fx_job
        deca
        bne  .l
        bsr  pri
        fcl  " then sieve"
        bra  .w
.l:     ldaa fa_st
        cmpa #3
        bne  .w
        bsr  pri
        fcl  " level "
        ldaa fx_lvl
        adda #'0'
        bsr  putc
.w:     bsr  out
        ldx  #40                ; (twentieths of a second)
.t:     ldd  TMW_FRAM
        std  kv_al
.u:     pshx
        bsr  poll
        pulx
        ldd  TMW_FRAM
        subd kv_al
        beq  .u
        dex
        bne  .t
        inc  kv_full
        rts
names:  fcl  "RHO"
        fcl  "P-1"
        fcl  "P+1"
        fcl  "ECM"
        fcl  "QS"
; the last line: the job's time, if it is known, or the keys
jobline: ldaa fx_job
        beq  .keys
        bsr  pri
        fcl  "Job: "
        ldaa fx_job
        deca
        beq  .time
        bsr  pri
        fcl  "no set end"
        rts
.time:  ldaa fx_m               ; (the sieve: it is the last step)
        cmpa #4
        beq  .qs
        bsr  pri
        fcl  "up to "
        bra  .js
.qs:    bsr  pri
        fcl  "about "
.js:    ldd  fx_js
        std  kv_n
        ldd  fx_js+2
        std  kv_n+2
        bra  putj
.keys:  bsr  pri
        fcl  "ON=stop"
        tst  kv_skp
        beq  .x
        bsr  pri
        fcl  "  S=skip"
.x:     rts
; putj: kv_n seconds, roughly: 35 s, 112 min, 17 h, 9 days, 5 weeks
putj:   ldx  #.u
.l:     ldd  kv_n               ; the first unit it is under so many of
        bne  .n
        ldd  kv_n+2
        subd 0,x
        bcs  .got
.n:     ldab 2,x                ; (to the nearest)
        pshx
        pshb
        lsrb
        clra
        addd kv_n+2
        std  kv_n+2
        bcc  .nc
        ldx  kv_n
        inx
        stx  kv_n
.nc:    pulb
        bsr  ndiv
        pulx
        inx
        inx
        inx
        inx
        inx
        inx
        inx
        bra  .l
.got:   pshx
        bsr  putn
        bsr  putsp
        pulx
        ldab #4
        inx
        inx
        inx
        bra  prb
.u:     fdb  100
        fcb  60
        fcc  "s   "
        fdb  200
        fcb  60
        fcc  "min "
        fdb  48
        fcb  24
        fcc  "h   "
        fdb  28
        fcb  7
        fcc  "days"
        fdb  $FFFF
        fcb  7
        fcc  "wks "
