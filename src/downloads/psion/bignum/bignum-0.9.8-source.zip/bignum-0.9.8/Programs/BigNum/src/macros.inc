; ---- error codes (err, E_...: the messages are in ov_edit)
E_SYN   = 1                     ; SYNTAX
E_BIG   = 2                     ; TOO BIG
E_DIV   = 3                     ; DIV BY 0
E_INV   = 4                     ; NO INVERSE
E_ARG   = 5                     ; BAD ARG
E_AVL   = 6                     ; NOT AVAILABLE
E_MEM   = 7                     ; NO MEMORY
E_SET   = 8                     ; NOT SET (a variable with nothing in it)
E_MSG   = 100                   ; (not an error: the text at RTB_BL is shown in the header's place)
E_LINE  = 101                   ; (the same: the text goes into the line)
; ---- why a run was left (kv_why)
R_SKIP  = 1
R_KEEP  = 2
R_DROP  = 3
; ---- overlays (tools/build.py numbers them in its list OVL and checks these)
        include "ovnums.inc"

; call an overlay's entry (back after the call); from the kernel
ovcall  macro id,e
        jsr  ovc
        fcb  \id,\e
        endm
; go to an overlay's entry (it returns to whoever called this code)
ovjump  macro id,e
        jsr  ovj
        fcb  \id,\e
        endm
; call an overlay's entry from an overlay (or a kernel routine an overlay called): this overlay is
; read in again before coming back (B and the flags are kept; A and X are not)
ovsub   macro id,e
        jsr  ovs
        fcb  \id,\e
        endm
; mset: Montgomery work for the modulus at X: slots; the slot for 1; for R squared (NO: not wanted)
NO      = $FF
mset    macro n,o,r
        stx  ms_x
        ldd  #\n*256+\o
        std  ms_b
        ldaa #\r
        staa ms_r
        ovsub OV_MSET,0
        endm
; mrun's operations: code, result, a, b (slots 0 to 15); mol: the last
mo      macro c,r,a,b
        fcb  (\c)*16+(\r),(\a)*16+(\b)
        endm
mol     macro c,r,a,b
        fcb  128+(\c)*16+(\r),(\a)*16+(\b)
        endm
