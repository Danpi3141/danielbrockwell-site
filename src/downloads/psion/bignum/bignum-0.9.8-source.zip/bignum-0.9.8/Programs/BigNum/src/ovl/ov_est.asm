; =====================================================================
; OV_EST: how long a run should take: kv_est (seconds). Entry 0: D (kv_tot) bits of MODEXP: a square
; each, and a product in 5. Entry 1: kv_tot squares. Entry 2: kv_tot squares and as many products. Entry 3:
; as 1, and kv_ext as 2.
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        entry e_mexp
        entry e_sqr
        entry e_both
        entry e_bpsw
        entry e_llt
        entry e_rho
        entry e_pm1
        entry e_ps2
        lastent e_ecm

; entry 4: LLT: the squares alone (15 n n)
e_llt:  clra
        clrb
        std  kv_est
        std  kv_est+2
        clra
        bsr  cyc
        ldd  #35
        std  kv_na
        ldd  #100
        std  kv_nb
        bsr  muldiv
        ldd  kv_tot
        bsr  secs
        bra  keep
e_bpsw: bsr  e_both
        ldd  kv_est
        std  kv_ext
        ldd  kv_est+2
        std  kv_ext+2
        bra  e_sqr
; entry 6: the first stage of P-1 and P+1 to kv_tot: a square and a product a bit, 1.44 bits a unit
e_pm1:  bsr  e_both
        ldd  #36
        std  kv_na
        ldd  #25
        std  kv_nb
        bsr  muldiv
        bra  keep
; entry 7: their second stage: about 60 products for each 256 numbers of kv_tot
e_ps2:  bsr  prod
        ldd  #60
        std  kv_na
        ldd  #1
        std  kv_nb
        bsr  muldiv
        ldd  kv_tot
        bsr  secs
        bra  keep
; entry 8: the curves fx_crv of ECM (kv_tot = 64 a curve), each 33 B1 products
e_ecm:  bsr  prod
        ldd  fx_lim
        std  kv_na
        ldd  #2                 ; (33 B1 / 64 a unit)
        std  kv_nb
        bsr  muldiv
        ldd  kv_tot
        bsr  secs
        bra  keep
; entry 5: rho: a square a step, and a product every other one; 3.6 ms more for the rest of a step and its share of the
; GCDs, and 2 s for the GCDs of the first short runs (as measured, 16 to 77 digits: within 15% from 250 steps on)
e_rho:  bsr  prod
        ldd  kv_n+2
        addd #26                ; (halved below)
        std  kv_n+2
        bcc  .c
        inc  kv_n+1
.c:     ldaa #1
        bsr  e_d
        ldd  kv_est+2
        addd #2
        std  kv_est+2
        bcc  .x
        inc  kv_est+1
.x:     rts
e_mexp: bsr  prod
        ldaa #2                 ; / 4 (a little over 1 in 5)
e_d:    lsr  kv_n
        ror  kv_n+1
        ror  kv_n+2
        ror  kv_n+3
        deca
        bne  e_d
        bsr  keep
        bra  sum
e_sqr:  ldd  #0
        std  kv_est
        std  kv_est+2
        bra  sum
e_both: bsr  prod
        bsr  keep
sum:    clra
        bsr  cyc
        ldd  kv_n+2
        addd kv_est+2
        std  kv_n+2
        ldd  kv_n
        adcb kv_est+1
        adca kv_est
        std  kv_n
        ldd  kv_tot
        bsr  secs
keep:   ldd  kv_n
        std  kv_est
        ldd  kv_n+2
        std  kv_est+2
        rts
prod:   ldaa #1
        bra  cyc
        include "est.inc"
