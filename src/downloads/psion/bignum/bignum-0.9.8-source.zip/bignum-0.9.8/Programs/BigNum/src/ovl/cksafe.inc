; safe: a place where the run can be kept, if it is to be
safe:   ldaa kv_ckd
        anda #3
        beq  .x
        ovsub OV_KEEP,0
.x:     rts
