// The time left: it never goes up while nothing has been done, it is near the truth, and FACTOR's Job agrees with it.
// node tests/t_left.js [model]
'use strict';
const { BN, HZ } = require('./lib');
const model = process.argv[2] || 'lz64'; let bad = 0;
// line, how far off the time left may be once a fifth is done (a ratio either way)
const JOBS = [['LLT(521)', 1.25], ['MODEXP(3,2**521-2,2**521-1)', 1.25], ['QS(408376394972792325960210891289657)', 2.3], ['QS(4083763949728956323469088409)', 2.3], ['RHO(10000019*(10**24+7))', 99], ['PM1((2**89-1)*(10**20+39))', 99], ['PP1((2**89-1)*(10**20+39))', 99], ['RHO(10**40+121)', 99], ['ECM((2**61-1)*(10**20+39),1)', 99], ['FACTOR(2**101-1)', 2.3]];
const sec = (t) => { const m = /left (?:(\d+)d (\d+)h|(\d+):(\d\d):(\d\d))/.exec(t); return !m ? -1 : m[1] !== undefined ? +m[1] * 86400 + +m[2] * 3600 : +m[3] * 3600 + +m[4] * 60 + +m[5]; };
for (const [line, tol] of JOBS) {
  const g = new BN(model, process.env.BB ? { build: process.env.BB } : {}).start(), m = g.m, at = g.addr('t_idle'), pl = g.addr('poll'); g.wait();
  m.write(g.peekw('kv_line'), [line.length, ...[...line].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', line.length); g.inject('EXE');
  const c0 = m.cycles(), log = []; let end = 0, up = 0, first = '', over = '';
  for (let i = 0; i < 4000; i++) {
    if (m.runTo([at], HZ) === at) { end = (m.cycles() - c0) / HZ; break; }
    if (m.runTo([pl], HZ * 3) !== pl) continue;                 // (not in the middle of something)
    const t = g.text(), l = sec(t), dn = g.peekw('kv_ld'), e0 = g.peekw('kv_e0', 2), name = g.lines()[0];
    if (l < 0 || !g.peek('kv_run')) continue;
    const pc = /(\d+)%/.exec(t); if (!over && (pc && +pc[1] > 100 || dn < 65280 && dn > g.peekw('kv_tot') && l > 0 && !g.peekw('kv_ext', 2) && !g.peekw('kv_ext'))) over = t.replace(/\n/g, '|');
    const job = /Job: (up to|about) (\d+) (s|min|h)/.exec(t);
    log.push({ at: (m.cycles() - c0) / HZ, l, dn, tot: g.peekw('kv_tot'), e0, name, rel: /Relations|QS \d/.test(t), job: job ? +job[2] * { s: 1, min: 60, h: 3600 }[job[3]] : 0, about: job && job[1] === 'about' });
    const n = log.length; const b = log[n - 2], c = log[n - 3];
    if (n > 2 && b.dn === dn && c.dn === dn && c.e0 === e0 && b.e0 === e0 && b.name === name && c.rel === log[n - 1].rel && c.tot === b.tot && b.tot === log[n - 1].tot && l > b.l) { up++; first = first || `${log[n - 2].l} then ${l}: ${t.replace(/\n/g, '|')}`; }
  }
  if (!end) { bad++; console.log('FAIL', line, 'did not end'); continue; }
  if (up) { bad++; console.log(`FAIL ${line}: the time left went up ${up} times with nothing done: ${first}`); }
  if (over) { bad++; console.log(`FAIL ${line}: past the end: ${over}`); }
  // each part (one kv_e0) against when it really ended
  let worst = 1, where = '';
  for (const e of new Set(log.map((r) => r.e0 + '/' + r.tot))) {
    const p = log.filter((r) => r.e0 + '/' + r.tot === e), t1 = p[p.length - 1].at, t0 = p[0].at; if (t1 - t0 < 20) continue;
    if (!p.some((r) => r.rel) && !/LLT|MODEXP/.test(p[0].name)) continue;   // (the others may end early, with a factor)
    for (const r of p) { const left = t1 - r.at; if (r.at - t0 < 0.2 * (t1 - t0) || left < 40) continue; const q = Math.max((r.l + 3) / (left + 3), (left + 3) / (r.l + 3)); if (q > worst) { worst = q; where = `${r.name.trim()} ${r.dn}/${r.tot}: ${r.l} s, it was ${left.toFixed(0)}`; } }
  }
  if (worst > tol) { bad++; console.log(`FAIL ${line}: the time left is out by a factor of ${worst.toFixed(2)}`); }
  for (const r of log) if (r.about && r.rel && r.dn > 0 && r.job < r.l * 0.9 - 60) { bad++; console.log(`FAIL ${line}: job ${r.job} s, left ${r.l} s`); break; }
  console.log(`${line}: ${end.toFixed(0)} s, within a factor of ${worst.toFixed(2)} (${where})`);
}
console.log(bad ? `${bad} FAILED` : `t_left ${model} ok`);
process.exit(bad ? 1 : 0);
