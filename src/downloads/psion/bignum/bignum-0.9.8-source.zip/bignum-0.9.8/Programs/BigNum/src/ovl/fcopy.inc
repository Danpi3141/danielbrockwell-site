; copyf: the factor B on the stack of numbers; kv_ia its record
copyf:  ldx  kv_vb
        stx  kv_wp
        bsr  nth
        stx  kv_ia
        ldab #FR_N
        abx
        bra  hcopy
; nth: X = the record B
nth:    ldx  kv_rl
.l:     decb
        bmi  .x
        pshb
        bsr  fl_next
        pulb
        bra  .l
.x:     rts
