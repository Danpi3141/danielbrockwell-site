; =====================================================================
; BigNum: the machine code, assembled as if at 0 and moved to the top of the block by the fixer.
; Entered with A = the device BNK came from, RTA_SP at the bottom of the block. Returns with RTA_SP as
; it was.
; =====================================================================
        include "defs.inc"
        include "macros.inc"

entry:  jmp  ov_slot            ; the start-up code (kinit.asm), where the overlays go
        fcc  "BNK1"             ; the tag tests find the kernel by

        include "kmain.asm"
        include "kov.asm"
        include "kscr.asm"
        include "kheap.asm"
        include "rows.asm"
        include "core.asm"

        include "kvars.inc"
