// RHO, PM1, PP1, ECM by themselves: factors built so that each method must find them.
//   node tests/t_meth.js [model] [seed] [which]
'use strict';
const { BN, rng } = require('./lib');
const model = process.argv[2] || 'lz64';
const R = rng(+process.argv[3] || 1);
const which = process.argv[4] || 'all';
const g = new BN(model).start();
let fails = 0, n = 0;
const fail = (s) => { console.log('FAIL', s); if (++fails > 12) process.exit(1); };
const powm = (b, e, m) => { let r = 1n % m; b %= m; while (e) { if (e & 1n) r = r * b % m; b = b * b % m; e >>= 1n; } return r; };
const prime = (v) => { if (v < 2n) return false; for (const p of [2n, 3n, 5n, 7n, 11n, 13n, 17n, 19n, 23n, 29n, 31n, 37n]) if (v % p === 0n) return v === p; let d = v - 1n, s = 0; while (!(d & 1n)) { d >>= 1n; s++; }
  next: for (const a of [2n, 3n, 5n, 7n, 11n, 13n, 17n, 19n, 23n, 29n, 31n, 37n]) { let x = powm(a, d, v); if (x === 1n || x === v - 1n) continue; for (let i = 1; i < s; i++) { x = x * x % v; if (x === v - 1n) continue next; } return false; } return true; };
const small = []; for (let i = 2; i < 60000; i++) if (prime(BigInt(i))) small.push(BigInt(i));
const rp = (bits) => { let v; do { v = R.bits(bits) | 1n | 1n << BigInt(bits - 1); } while (!prime(v)); return v; };
// a prime p with p-s = (primes up to b1) x (one prime in (b1, b2])
const smooth = (s, bits, b1, b2, ok) => { for (;;) { let v = 2n; while (v.toString(2).length < bits - 16) { const q = small[R.int(small.findIndex((x) => x > BigInt(b1)))]; let k = v, pw = q; while (k % q === 0n) { k /= q; pw *= q; } if (pw <= BigInt(b1)) v *= q; } if (b2) { const i = small.findIndex((x) => x > BigInt(b1)), j = small.findIndex((x) => x > BigInt(b2)); v *= small[i + R.int(j - i)]; } const p = v + BigInt(s); if (prime(p) && (!ok || ok(p))) return p; } };
const run = (t, f) => { n++; const r = g.line(t, 1e6); const okv = !r.err && (f.includes(r.val)); if (!okv) fail(`${t}: ${r.err} ${r.val} want one of ${f}`); else console.log(`  ${t}: ${r.val}  ${(r.cycles / 921600).toFixed(1)} s`); };
if (which === 'all' || which === 'rho') {
  for (let i = 0; i < 6; i++) { const p = rp(18), q = rp(60); run(`RHO(${p * q})`, [p, q]); }
}
if (which === 'all' || which === 'pm1') {
  for (let i = 0; i < 3; i++) { const p = smooth(1, 50, 2000, 0), q = rp(64); run(`PM1(${p * q})`, [p]); }
  for (let i = 0; i < 5; i++) { const p = smooth(1, 60, 2000, 50000), q = rp(64); run(`PM1(${p * q})`, [p]); }
  { const p = rp(60), q = rp(64); run(`PM1(${p * q})`, [1n]); }
}
if (which === 'all' || which === 'pp1') {
  for (let i = 0; i < 3; i++) { const p = smooth(-1, 50, 2000, 0, (x) => x % 3n === 2n), q = rp(64); run(`PP1(${p * q})`, [p]); }
  for (let i = 0; i < 5; i++) { const p = smooth(-1, 60, 2000, 50000, (x) => x % 3n === 2n), q = rp(64); run(`PP1(${p * q})`, [p]); }
}
if (which === 'all' || which === 'ecm') {
  const { curveFinds } = require('../ref/ecm');
  const B1 = +process.argv[5] || 400;
  g.pokew('st_ecm', B1);
  // sigma = curve + 5: which curve finds p first (q must be found by none of them)
  for (let i = 0, done = 0; done < 6 && i < 60; i++) {
    const p = rp(36), q = rp(50); let c = 0, st = 0;
    for (let k = 1; k <= 4 && !c; k++) { st = curveFinds(p, k + 5, B1); if (st) c = k; }
    let cq = 0; for (let k = 1; k <= 4 && !cq; k++) if (curveFinds(q, k + 5, B1)) cq = k;
    if (cq || (!c && done % 3)) continue;
    console.log(`   model: curve ${c} stage ${st}`);
    run(`ECM(${p * q},4)`, [c ? p : 1n]); done++;
    if (c && g.peekw('kv_fx', 6) !== c) fail(`found by curve ${g.peekw('kv_fx', 6)}, the model says ${c}`);
  }
}
console.log(fails ? `${fails} FAILED` : `t_meth ${model} ok (${n} checks)`);
process.exit(fails ? 1 : 0);
