; gather: the top number x D; on into the second when it is as long as a row of the multiplication
gather: ldx  #0
        stx  kv_na
        bsr  hmuladd
        bsr  poll
        bsr  ilenw
        tsta
        bne  .m
        cmpb kv_wm
        bhs  .m
        rts
.m:     bsr  hmul
        bsr  chk
        bra  hpush1
; fin: the last of it; chk: the result not past the cap
fin:    bsr  hmul
chk:    bsr  ilenw
        subd kv_cap
        bhi  big
        rts
big:    bra  errbig
arg:    bra  errarg
; word: D = the top number, if it is of at most 2 bytes (Z clear: it is not; carry: negative)
word:   bsr  ilenw
        bmi  arg
        subd #1
        bcs  .z
        beq  .b
        subd #1
        bne  .x
        ldd  2,x
        bra  .y
.z:     clrb
        bra  .c
.b:     ldab 2,x
.c:     clra
.y:     psha
        clra                    ; (Z)
        pula
.x:     rts
