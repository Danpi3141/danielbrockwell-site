; =====================================================================
; OV_SETL: the settings listed (SET alone, or from the menu): EXE turns ON and OFF about and goes through the
; devices; for a number, SET and its name go into the line (RTB_BL).
; =====================================================================
        include "macros.inc"
        lastent setm

setm:   ldaa #ST_N
        bsr  list
.k:     clr  RTB_BL
        cmpb #K_EXE
        bne  .x
        ldab li_i
        bsr  nth
        stx  ze
        ldaa 0,x
        tab
        abx
        ldaa 1,x
        ldx  2,x
        cmpa #2
        beq  .flip
        bhi  .dev
        ldx  #RTB_BL+1          ; a number: SET and its name into the line
        ldd  #$5345
        std  0,x
        ldd  #$5420
        std  2,x
        ldx  #RTB_BL+5
        stx  zp
        ldx  ze
        ldab 0,x
        pshb
        inx
        stx  zx
        clra
        bsr  cpb
        pulb
        ldx  zp                 ; (past it)
        ldx  #RTB_BL+5
        abx
        ldaa #32
        staa 0,x
        addb #5
        stab RTB_BL
.x:     rts
.flip:  ldaa 0,x
        eora #1
        staa 0,x
        bra  .kept
.dev:   ldaa 0,x                ; OFF, A:, B:, C:
        inca
        anda #3
        staa 0,x
.kept:  ovsub OV_SETF,1
        bsr  li_dr
        bra  .k
        include "setrow.inc"
        include "list.inc"
        include "sets.inc"
