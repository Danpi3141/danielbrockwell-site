; as primes.inc, the window filled by OV_PS (a driver's: it is far apart)
PS_LEN  = 132
PS_N    = 1050
        ifused ps_go
ps_go:  stab ps_lo
        stx  ps_lo+1
        bra  ps_fill
        endif
ps_next: ldd ps_i
        addd #1
        std  ps_i
        subd #PS_N
        bcs  .in
        bsr  ps_win             ; the next window
        bra  ps_next
.in:    ldd  ps_i
        bsr  ps_bit
        bitb 0,x
        bne  ps_next
        ldd  ps_i
        asld
        addd ps_lo+1
        std  ps_p+1
        ldab ps_lo
        adcb #0
        stab ps_p
        rts
ps_win: ldd  ps_lo+1
        addd #2*PS_N
        std  ps_lo+1
        ldab ps_lo
        adcb #0
        stab ps_lo
        bra  ps_fill
; ps_bit: D = an odd number's place: X its byte, B its bit
ps_bit: pshb
        lsrd
        lsrd
        lsrd
        addd ps_buf
        xgdx
        pulb
        andb #7
        ldaa #1
.b:     decb
        bmi  .x
        asla
        bra  .b
.x:     tab
        rts
ps_fill: ovsub OV_PS,0
        rts
