; aroom: the memory A: grows into made long enough for D bytes more (carry set: there is not enough to spare). The
; block's bottom goes up, the operators and the list in it with it.
aroom:  addd ALA_FREE
        bcs  .no
        addd #256+RESERVE
        bcs  .no
        std  kv_al
        subd RTA_SP
        bls  .ok
        std  kv_se
        addd kv_lim
        bcs  .no
        std  zp
        addd #300               ; (some left to work with)
        bcs  .no
        subd kv_wp
        bhi  .no
        ldd  kv_lim
        std  zx
        subd kv_lo
        bsr  cpd
        ldx  #.p
.l:     pshx
        ldx  0,x
        beq  .d
        ldd  0,x
        addd kv_se
        std  0,x
        pulx
        inx
        inx
        bra  .l
.d:     pulx
        ldd  kv_al
        std  RTA_SP
.ok:    clc
        rts
.no:    sec
        rts
.p:     fdb  kv_lo,kv_lim,kv_osp,kv_rl,0
