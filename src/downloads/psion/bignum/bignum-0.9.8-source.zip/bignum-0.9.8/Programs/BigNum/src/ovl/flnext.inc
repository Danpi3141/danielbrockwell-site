; the list of factors, from kv_rl up to kv_lim: records of a type, an exponent (word), the work done on it
; (7 words: rho steps, P-1's and P+1's bounds, ECM's curves at levels 1 to 4), how it was found, and the number.
FT_NEW  = 0                     ; not looked at yet
FT_P    = 1                     ; a prime
FT_PRP  = 2                     ; a probable prime
FT_C    = 3                     ; composite, to be factored (a power?)
FT_CN   = 4                     ; the same, and not a power
FT_GAVE = 5                     ; composite, given up
FT_TRIED = 6                    ; a probable prime with no proof found
FR_E    = 1                     ; a record: the exponent
FR_W    = 3                     ; the work
FR_M    = 17                    ; the method that found it (0 trial division; fx_m + 1; 6 as a power)
FR_S    = 18                    ; (2) ECM: sigma
FR_N    = 20                    ; the number's item
FL_LEN  = 19                    ; a record's bytes after the type, before the item
; fl_next: X past the record at X
fl_next: ldab #FR_N
        abx
        bra  inext
