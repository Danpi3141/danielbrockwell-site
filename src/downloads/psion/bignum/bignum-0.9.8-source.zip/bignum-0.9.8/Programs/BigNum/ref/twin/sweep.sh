#!/bin/bash
# best factor base size at each number of digits
run() { ./Qs.exe "$@"; }
export -f run
{
for d in 18 20 22 24; do for f in 24 32 48 64; do echo $d $f 1024 16 0 7 12 20 30 100 1e9; echo $d $f 2048 18 0 7 12 20 30 100 1e9; done; done
for d in 26 28 30 32; do for f in 48 64 96 128; do echo $d $f 2048 18 0 7 10 20 40 100 1e9; echo $d $f 2048 18 10 7 10 20 40 100 1e9; done; done
for d in 34 36 38; do for f in 96 128 160 192; do echo $d $f 2048 18 10 7 8 20 40 150 1e9;  echo $d $f 2048 22 0 7 8 20 40 150 1e9; done; done
} | xargs -P 14 -L 1 ./Qs.exe | sort -V
