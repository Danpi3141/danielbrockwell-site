; =====================================================================
; OV_SET: SET name value, or SET alone (the list: OV_SETL)
; =====================================================================
        include "macros.inc"
        lastent set

se_k    = kv_fs                 ; a setting's kind
se_a    = kv_fs+1               ; (2) where it is
se_d    = kv_fs+3               ; (2) what it is at first
se_v    = kv_fs+5               ; (2) the new value
se_n    = kv_fs+7               ; its number in the list
set:    bsr  nextc
        tstb
        bne  .name
        ovsub OV_SETL,0         ; SET alone
        ldab RTB_BL
        beq  .x
        ldaa #E_LINE            ; (the text it left goes into the line)
        staa kv_err
.x:     rts
.name:  dec  kv_tp              ; the name
        ldx  kv_line
        ldab kv_tp
        abx
        stx  zx
        stab kv_epos
        dec  kv_epos
        clr  se_n
        ldx  #sets
.f:     ldab 0,x
        beq  bad
        stx  ze
        ldx  zx
        stx  zp
        ldx  ze
.c:     inx                     ; the letters compared
        pshx
        pshb
        ldx  zp
        ldab 0,x
        inx
        stx  zp
        bsr  upc
        stab zm
        pulb
        pulx
        ldaa 0,x
        cmpa zm
        bne  .no
        decb
        bne  .c
        inx                     ; all the same: found (if the name ends here)
        pshx
        ldx  ze
        ldaa 0,x
        adda kv_tp
        staa kv_tp
        pulx
        bra  .got
.no:    inc  se_n
        ldx  ze
        ldab 0,x
        addb #6
        abx
        bra  .f
.got:   ldaa 0,x
        staa se_k
        ldd  1,x
        std  se_a
        ldd  3,x
        std  se_d
        ldx  kv_line            ; a space must follow it
        ldab kv_tp
        decb
        cmpb 0,x
        bhs  bad
        incb
        abx
        ldaa 0,x
        cmpa #32
        bne  bad
        bsr  nextc              ; the value
        ldaa kv_tp
        suba #2
        staa kv_epos
        ldaa se_k
        cmpa #2
        bhi  sdev
        beq  .bool
        cmpb #'0'
        blo  .auto
        cmpb #'9'
        bhi  .auto
        ldx  #0
        stx  se_v
.d:     subb #'0'               ; a number to 65535
        pshb
        ldd  se_v
        ldx  #10
        os   UT$UMUL            ; D:X
        subd #0
        bne  .big
        xgdx
        std  se_v
        pulb
        clra
        addd se_v
        bcs  arg
        std  se_v
        bsr  nextc
        cmpb #'0'
        blo  .e
        cmpb #'9'
        bls  .d
.e:     tstb
        bne  bad
        ldd  se_v
        bne  put
        tst  se_k
        beq  put
        bra  arg
.big:   pulb
        bra  arg
.auto:  bsr  upc                ; AUTO: what it is at first
        cmpb #'A'
        bne  bad
        ldd  se_d
        std  se_v
        bra  put
.bool:  bsr  onoff
        bcs  bad
put:    ldx  se_a
        ldab se_v+1
        ldaa se_k
        cmpa #2
        bhs  .byte
        ldd  se_v
        std  0,x
        bra  .sv
.byte:  stab 0,x
.sv:    ovsub OV_SETF,1         ; kept for the next time
        bsr  ln0                ; and shown
        ldab se_n
        bsr  li_row
        ldx  #kv_lbuf
        stx  zx
        ldx  #RTB_BL+1
        stx  zp
        ldab #16
        stab RTB_BL
        ldaa #E_MSG
        staa kv_err
        clra
        bra  cpb
sdev:   bsr  upc
        subb #'A'-1
        cmpb #3
        bls  .dd
        addb #'A'-1
        bsr  onoff
        bcs  bad
        tst  se_v+1
        bne  bad
        bra  put
.dd:    clra
        std  se_v
        bsr  nextc              ; (its colon, or nothing)
        tstb
        beq  put
        cmpb #':'
        bne  bad
        bsr  nextc
        tstb
        bne  bad
        bra  put
bad:    ldab #E_SYN
        bra  err
arg:    bra  errarg
; onoff: ON or OFF: se_v; carry set: neither
onoff:  ldx  #1
        stx  se_v
        bsr  upc
        cmpb #'O'
        bne  .no
        bsr  nextc
        bsr  upc
        cmpb #'N'
        beq  .e
        cmpb #'F'
        bne  .no
        bsr  nextc
        bsr  upc
        cmpb #'F'
        bne  .no
        ldx  #0
        stx  se_v
.e:     bsr  nextc
        tstb
        bne  .no
        clc
        rts
.no:    sec
        rts

        include "setrow.inc"
        include "nextc.inc"
        include "sets.inc"
