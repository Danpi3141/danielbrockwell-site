// Small numbers: the sieve must not stall (0.9.5 to 0.9.7 could, about 16 digits: with a small base the a's came round again);
// rho's estimate against the time it takes; FACTOR of what is left after a little trial division.
//   node tests/t_small.js [model] [numbers of each length]
'use strict';
const { BN, HZ, rng } = require('./lib');
const model = process.argv[2] || 'lz64', cnt = +process.argv[3] || 5;
let bad = 0, n = 0; const fail = (s) => { console.log('FAIL', s); bad++; };
const pw = (a, e, q) => { let r = 1n; a %= q; for (; e; e >>= 1n) { if (e & 1n) r = r * a % q; a = a * a % q; } return r; };
const pr = (v) => [2n, 3n, 5n, 7n, 11n, 13n, 17n].every((a) => v === a || (v % a && pw(a, v - 1n, v) === 1n)); const nx = (v) => { v |= 1n; while (!pr(v)) v += 2n; return v; };
const R = rng(+process.argv[4] || 3);
const g = new BN(model).start(), m = g.m; g.wait();
const home = () => { for (let i = 0; i < 8 && !g.atLine(); i++) { g.inject('ON'); g.wait(); } };
const semi = (d) => { const hi = 10n ** BigInt(d - (d >> 1)), lo = 10n ** BigInt(d >> 1); for (;;) { const p = nx(lo / 10n + R.bits(90) % (lo - lo / 10n)), q = nx(hi / 10n + R.bits(90) % (hi - hi / 10n)); if (p !== q && String(p * q).length === d) return p * q; } };
// a line that must be done in so many seconds
const run = (l, v, sec) => {
  home(); g.wait(); m.write(g.peekw('kv_line'), [l.length, ...[...l].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', l.length); m.poke(0x76, 13); m.run(5000); n++; const c0 = m.cycles();
  if (m.runTo([g.addr('t_idle')], HZ * sec) !== g.addr('t_idle')) { fail(`${l}: not done in ${sec} s: ${g.lines().join('|')}`); m.runTo([g.addr('poll')], HZ * 5); m.poke(0x76, 1); g.run(3); m.poke(0x76, 65); g.run(3); g.wait(600); return 0; }
  const r = g.vars()['@']; if (!(r > 1n && r < v && v % r === 0n)) fail(`${l}: ${r}`); return (m.cycles() - c0) / HZ;
};
const tier = g.peek('kv_tier');
if (tier < 4) {
  for (const v of [4815869661367049n, 1206534041530397n]) run(`QS(${v})`, v, 60);
  for (let d = 9; d <= 22; d++) for (let i = 0; i < cnt; i++) { const v = semi(d); run(`QS(${v})`, v, d < 18 ? 60 : d < 21 ? 100 : 180); }
  // with less and less room (fewer primes than there should be)
  for (const l of 'BCDEFGHIJKLMNO') { g.line(`${l}=2**2000`); home(); if (g.peekw('kv_wp') - g.peekw('kv_lo') < 2600) break; }
  let f = []; for (const d of [16, 18, 22, 24, 26, 28]) { const v = semi(d); run(`QS(${v})`, v, 2400); f.push(`${d}: ${g.peek('q_f')}`); }
  console.log(`${model}: with ${g.peekw('kv_wp') - g.peekw('kv_lo')} bytes, digits: primes ${f.join(', ')}`); home(); g.line('CLR'); home();
}
// FACTOR
for (let d = 9; d <= (tier < 4 ? 24 : 12); d += 3) for (let i = 0; i < 2; i++) { const v = semi(d); run(`FACTOR(${v})`, v, d < 21 ? 200 : 400); }
// rho's estimate (nothing is found)
for (const [d, L] of [[18, 510], [18, 2046], [25, 510], [32, 1022], [48, 510]]) {
  home(); g.line(`SET RHOIT ${L}`); home(); const h = 10n ** BigInt(d >> 1), v = nx(h * 10n ** BigInt(d % 2) * 3n / 2n + 12345n) * nx(h * 13n / 20n + 777n); const r = g.line(`RHO(${v})`, 1e4), t = r.cycles / HZ, e = g.peekw('kv_est', 2); n++;
  const lo = tier === 4 ? 0.75 : 0.88, hi = tier === 4 ? 1.35 : 1.15; if (e < t * lo - 1 || e > t * hi + 1) fail(`RHO of ${d} digits, ${L} steps: estimate ${e} s, ${t.toFixed(1)} s`);
}
home(); g.line('SET RHOIT AUTO');
console.log(bad ? `${bad} FAILED` : `t_small ${model} ok (${n} numbers)`);
process.exit(bad ? 1 : 0);
