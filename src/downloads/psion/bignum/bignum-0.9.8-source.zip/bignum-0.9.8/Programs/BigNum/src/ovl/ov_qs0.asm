; =====================================================================
; OV_QS0: the sieve set up, first part: the multiplier k (Knuth and Schroeppel), kN, how many primes, how
; big a sieve, the room for everything. Carry set: not enough room. Entry 1: q_f and nothing else, for a number
; of kv_bits bits.
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        include "qs.inc"
        entry qs0
        lastent size

ks_p    = kv_fs                 ; N modulo the small primes (21)
ks_k    = kv_fs+21              ; the k being tried
ks_x    = kv_fs+22              ; (2) its place in the table
; ---- the multiplier: for each k the sum of 2 log2(p)/(p-1) over the first primes p with kN a square modulo
; p (half for a p that divides k), and 2, 1 or 1/2 for kN = 1, 5, 3 or 7 modulo 8, less half log2(k); in 1/16
size:   clr  ks_k
        ldd  kv_bits
        bra  sizes
qs0:    ldx  #pw                ; N modulo each prime
        stx  zx
        ldx  #ks_p
        stx  ze
.r:     ldx  zx
        ldab 0,x
        beq  .rd
        inx
        inx
        stx  zx
        bsr  remb
        ldx  ze
        staa 0,x
        inx
        stx  ze
        bra  .r
.rd:    ldx  #0
        stx  q_bs               ; the best score so far
        ldaa #1
        staa q_k
        ldx  #ks
        stx  ks_x
.k:     ldx  ks_x
        ldab 0,x
        beq  .kd
        stab ks_k
        bsr  score
        subd q_bs
        bls  .kn
        addd q_bs
        std  q_bs
        ldab ks_k
        stab q_k
.kn:    ldx  ks_x
        inx
        inx
        stx  ks_x
        bra  .k
; ---- sizes
.kd:    ldx  fx_n               ; kN
        bsr  hcopy
        ldx  #0
        stx  kv_na
        ldab q_k
        clra
        bsr  hmuladd
        ldx  kv_wp
        bsr  ibits
sizes:  std  q_bits
        addd #22                ; ub = (bits / 2 + 11) / 8, rounded up: u < sqrt(2 kN) and some, its top bit 0
        lsrd
        addd #7
        lsrd
        lsrd
        lsrd
        stab q_ub
        ldx  #0                 ; the primes, the sieve, a large prime as well (all as measured):
        stx  q_lp
        ldd  q_bits
        subd #73
        bcc  .lp
        addd #73-18             ; up to 72 bits: bits - 18, 36 at least, 2,048 numbers, no large prime
        tsta
        bmi  .s0
        cmpb #36
        bhs  .f
.s0:    ldab #36
        bra  .f
.lp:    addd #73                ; past it: 3 bits - 186, 48 to 240, and a large prime
        inc  q_lp+1
        std  zt
        asld
        addd zt
        subd #186
        tsta
        bne  .max
        cmpb #48
        bhs  .m
        ldab #48
.m:     cmpb #240
        bls  .f
.max:   ldab #240
.f:     stab q_f
        ldd  #4096              ; 4,096 numbers from 88 bits
        ldx  q_bits
        cpx  #88
        bhs  .sv
        ldd  #2048
.sv:    std  q_svz
.fit:   bsr  target
        bsr  need
        ldd  kv_wp
        subd kv_lim
        subd zt
        bcc  .fits
        ldd  q_svz              ; no room: half the sieve, then fewer primes
        cmpa #8
        bls  .fw
        ldd  #2048
        bra  .sv
.fw:    ldab q_f
        decb
        stab q_f
        cmpb #64
        bhs  .fit
        ldd  #1024
        std  q_svz
        ldab q_f
        cmpb #24
        bhs  .fit
        sec
        rts
.fits:  tst  ks_k               ; (only the size wanted)
        beq  .sized
        ldaa kv_ckd             ; RESUME: as many primes as there were, if there is room
        bpl  .go
        ovsub OV_CKL,2
        tstb
        beq  .go
        cmpb q_f
        bls  .as
        stab q_f
.as:    bsr  target             ; (and as many in an a: the relations have them)
        ldab q_bs
        bsr  inas
        bsr  need
        ldd  kv_wp
        subd kv_lim
        subd zt
        bcc  .go
        clr  kv_ckd             ; (no: from the start)
        bra  .fit
.go:
; ---- the room: kN, the arrays p and t, the work, the primes for a
        ldab q_ub               ; kN in 2 ub bytes
        clra
        asld
        bsr  walloc
        stx  q_kn
        ldab q_ub
        clra
        asld
        bsr  clrx
        stx  zp
        ldx  q_kn               ; (its item is just above)
        ldab q_ub
        abx
        abx
        bsr  ilen
        pshb
        psha
        bsr  inext
        stx  zx
        pula
        pulb
        bsr  cpd
        ldab q_f
        clra
        asld
        bsr  walloc
        stx  q_p
        ldab q_f
        clra
        asld
        bsr  walloc
        stx  q_t
        ldd  #2*Q_POOL
        bsr  walloc
        stx  q_lg
        ldab q_ub               ; a, b, the B's (s), u (ub and 2), v (2 ub and 3), the quotients (ub and 2)
        ldaa q_s
        adda #7
        mul
        addd #90
        bsr  walloc
        stx  q_a
        ldab q_ub
        abx
        stx  q_b
        abx
        stx  q_bl
        ldaa q_s
        mul
        addd q_bl
        std  q_u
        addb q_ub
        adca #0
        addd #6
        std  q_v
        ldd  fx_lg2
        std  q_lgt
.sized: clc
        rts
; target: q_s = the primes in an a, q_lgt, q_m: log2 of a should be (bits + 1)/2 - log2(M), in 1/256
target: ldd  q_svz
        lsrd
        std  q_m
        ldaa #8                 ; log2(M)
        ldab q_m
.l:     inca
        lsrb
        bne  .l
        deca                    ; (M = 2 to the A)
        staa q_lm
        ldd  q_bits
        addd #1
        lsrd
        subb q_lm
        sbca #0
        tba
        clrb
        psha
        ldaa q_bits+1           ; (the half bit)
        lsra
        pula
        bcs  .nh
        addd #128
.nh:    std  fx_lg2
        ldaa #220               ; s: the fewest with log2(a)/s below 8.6 (ref/twin/QsP.cs) (8.6 x 256 = 2200 = 220 x 10)
        ldab q_f
        cmpb #Q_FEW
        bhs  .t
        ldaa #196               ; (below 7.64 with few primes: 8.6 bits may be past all of them, and the same a's come again)
.t:     staa zm
        ldab #1
.s:     incb
        pshb
        ldaa zm
        mul
        std  zt
        asld
        asld
        addd zt
        asld
        std  zt
        pulb
        ldx  zt
        cpx  fx_lg2
        bhs  .d
        cmpb #Q_SMAX
        bne  .s
; inas: B primes in an a
.d:
inas:   stab q_s
        decb                    ; a record's bytes
        aslb
        addb #QR_D
        stab q_rs
        rts
; need: zt = the room wanted: 4 F + 2 (F + 10) ub + (s + 12) ub + 432, and the larger of F rs + the sieve and
; (combining) (F + 10) (F + 8) / 8 + 4 F
need:   ldaa q_f
        ldab q_rs
        mul
        addd q_svz
        std  zw
        ldab q_f
        clra
        addd #8
        lsrd
        lsrd
        lsrd
        ldaa q_f
        adda #10
        mul
        std  zt
        ldaa q_f
        ldab #4
        mul
        std  zx
        addd zt
        subd zw
        bcc  .c
        clra
        clrb
.c:     addd zw
        addd zx
        addd #432
        std  zt
        ldaa q_f
        adda #10
        ldab q_ub
        mul
        ldx  q_lp               ; (with a large prime a relation can take two entries)
        beq  .one
        asld
.one:   addd zt
        std  zt
        ldaa q_s
        adda #12
        ldab q_ub
        mul
        addd zt
        std  zt
        rts
; remb: A = N modulo B
remb:   stab zm
        ldx  fx_n
        bsr  ilen
        stab zt
        ldaa #0
.l:     ldab 2,x
        inx
        pshx
        ldx  #8
.b:     aslb
        rola
        bcs  .s
        cmpa zm
        blo  .n
.s:     suba zm
.n:     dex
        bne  .b
        pulx
        dec  zt
        bne  .l
        rts
; score: D = the score of ks_k (1000 added, so that it is not negative)
score:  ldx  ks_x               ; 1000 less the penalty
        ldab 1,x
        clra
        std  zt
        ldd  #1000
        subd zt
        std  kv_al
        ldx  fx_n               ; kN modulo 8
        bsr  inext
        dex
        ldaa 0,x
        ldab ks_k
        mul
        andb #7
        ldaa #32
        cmpb #1
        beq  .two
        ldaa #16
        cmpb #5
        beq  .two
        ldaa #8
.two:   tab
        clra
        addd kv_al
        std  kv_al
        ldx  #pw
        stx  zx
        ldx  #ks_p
        stx  ze
.p:     ldx  zx
        ldaa 0,x
        beq  .x
        staa zm
        ldx  ze                 ; kN modulo p
        ldab 0,x
        inx
        stx  ze
        ldaa ks_k
        mul
        bsr  modp
        ldx  zx
        ldab 1,x
        inx
        inx
        stx  zx
        tsta
        bne  .sq
        lsrb                    ; p divides k
        bra  .add
.sq:    stab zw                 ; a square modulo p?
        staa zw+1
        clrb
        stab zp                 ; x
        clra                    ; x squared
.s:     inc  zp
        ldab zp                 ; + 2 x - 1
        aslb
        decb
        aba
.m:     cmpa zm
        blo  .m1
        suba zm
        bra  .m
.m1:    cmpa zw+1
        beq  .is
        ldab zp
        aslb
        cmpb zm
        blo  .s
        bra  .p                 ; it is not
.is:    ldab zw
.add:   clra
        addd kv_al
        std  kv_al
        bra  .p
.x:     ldd  kv_al
        rts
; modp: A = D modulo zm (D below 256 zm)
modp:   ldx  #8
.b:     aslb
        rola
        bcs  .s
        cmpa zm
        blo  .n
.s:     suba zm
.n:     dex
        bne  .b
        rts
; the primes and 16 x 2 log2(p)/(p-1)
pw:     fcb  3,25,5,19,7,15,11,11,13,10,17,8,19,8,23,7,29,6,31,5,37,5,41,4,43,4,47,4,53,4,59,3,61,3,67,3,71,3,73,3,79,3,0
; the multipliers and 8 log2(k)
ks:     fcb  1,0,2,8,3,13,5,19,6,21,7,22,10,27,11,28,13,30,14,30,15,31,17,33,19,34,21,35,22,36,23,36
        fcb  26,38,29,39,30,39,31,40,33,40,34,41,35,41,37,42,38,42,39,42,41,43,42,43,43,43,46,44,47,44,51,45
        fcb  53,46,55,46,57,47,58,47,59,47,61,47,62,48,65,48,66,48,67,49,69,49,70,49,71,49,73,50
        fcb  0
fx_lg2  = kv_se
        include "ibits.inc"
