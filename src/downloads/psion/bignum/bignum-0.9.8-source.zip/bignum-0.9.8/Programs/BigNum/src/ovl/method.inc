; method: the name of the method B (a record's FR_M) at the pen
method: ldx  #.n
.f:     decb
        bmi  .p
        pshb
        ldab 0,x
        incb
        abx
        pulb
        bra  .f
.p:     bra  prs
.n:     fcl  "Trial division"
        fcl  "RHO"
        fcl  "P-1"
        fcl  "P+1"
        fcl  "ECM"
        fcl  "QS"
        fcl  "Power"
