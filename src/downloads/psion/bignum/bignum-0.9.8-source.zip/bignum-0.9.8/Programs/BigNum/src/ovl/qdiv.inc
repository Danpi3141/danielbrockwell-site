; a quotient (qc_n bytes, qc_b to qc_e) divided by small primes, exactly. The digits of a division are made
; QT bytes past the quotient's own.
QT      = 52
qc_b    = kv_fs+6               ; (2) the quotient left: its first byte
qc_e    = kv_fs+8               ; (2) and its end
qc_n    = kv_fs+10              ; its bytes
td_p    = zm                    ; (2) the divisor
td_r    = zx                    ; (2)
td_t    = zp                    ; (2)
td_i    = ze                    ; -1/p modulo 256
td_q    = ze+1
; inva: B = -1/A modulo 256 (A odd)
inva:   staa td_q
        tab
        bsr  .s
        bsr  .s
        negb
        rts
.s:     pshb
        ldaa td_q
        mul
        negb
        addb #2
        pula
        mul
        rts
; divq: the quotient divided by td_p if it goes exactly: Z, else as it was
divq:   clra
        clrb
        std  td_r
        ldx  qc_e
        tst  td_p
        beq  .sh
.l:     dex
        ldab 0,x
        clra
        addd td_r
        std  td_t
        ldaa td_i
        mul
        stab QT,x
        stab td_q
        ldaa td_p+1
        mul
        addd td_t
        tab
        ldaa #0
        adca #0
        std  td_t
        ldaa td_q
        ldab td_p
        mul
        addd td_t
        std  td_r
        cpx  qc_b
        bne  .l
        bra  .e
.sh:    dex                     ; (p below 256)
        ldab 0,x
        clra
        addb td_r+1
        adca #0
        std  td_t
        ldaa td_i
        mul
        stab QT,x
        ldaa td_p+1
        mul
        addd td_t
        staa td_r+1
        cpx  qc_b
        bne  .sh
.e:     ldd  td_r
        subd td_p
        bne  .x
        ldx  qc_e               ; it goes: the quotient = the digits' negative
        ldab qc_n
        clc
.n:     dex
        ldaa #0
        sbca QT,x
        staa 0,x
        decb
        bne  .n
        bsr  trim
        clra
.x:     rts
; trim: the quotient's zeros at the front left out
trim:   ldx  qc_b
        ldab qc_n
.l:     tst  0,x
        bne  .x
        inx
        decb
        cmpb #1
        bhi  .l
.x:     stx  qc_b
        stab qc_n
        rts
; half: the quotient (even) halved
half:   ldx  qc_b
        ldab qc_n
        clc
.r:     ror  0,x
        inx
        decb
        bne  .r
        bra  trim
; negb_: the B bytes at X made negative
negb_:  stab zt
        abx
        ldab zt
        clc
.l:     dex
        ldaa #0
        sbca 0,x
        staa 0,x
        decb
        bne  .l
        rts
; sqkn: the ub bytes at ma squared, less kN: its size, 2 ub bytes, in q_v+2 (two zero bytes before it),
; ending at qc_e; carry set: it was negative
sqkn:   ldab q_ub
        clra
        std  mal
        ldx  q_v
        clr  0,x
        clr  1,x
        inx
        inx
        stx  mp
        bsr  sqrp
        ldd  mq                 ; (its end)
        std  zx
        std  ze
        std  qc_e
        ldab q_ub
        clra
        asld
        std  mn
        addd q_kn
        std  zp
        bsr  sub3
        bcc  .x
        ldx  q_v
        inx
        inx
        ldab q_ub
        aslb
        bsr  negb_
        sec
.x:     rts
