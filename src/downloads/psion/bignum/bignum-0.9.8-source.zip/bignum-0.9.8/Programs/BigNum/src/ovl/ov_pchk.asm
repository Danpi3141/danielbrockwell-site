; =====================================================================
; OV_PCHK: the factors of pv_m - 1 or + 1 found so far (the list at kv_rl): are they enough for a proof? pv_t =
; the kind of proof, or 0; carry set: enough. pv_p: how much is factored.
; The sizes are compared in bits, on the safe side: F is at least 2**(bits-1).
; =====================================================================
        include "macros.inc"
        include "fa.inc"
        include "pv.inc"
        lastent chk

chk:    ldx  kv_wp              ; (the number factored may be on top: all this is dropped again)
        pshx
        bsr  hpush1             ; F: the product of the primes found
        ldx  kv_rl
.f:     cpx  kv_lim
        beq  .e
        stx  pv_q
        ldaa 0,x
        deca
        cmpa #1
        bhi  .n
        ldab #FR_N
        abx
        bsr  hcopy
        ldx  pv_q
        ldd  FR_E,x
        subd #1
        beq  .one
        addd #1
        bsr  hpush
        ovsub OV_POW,0
.one:   bsr  hmul
.n:     ldx  pv_q
        bsr  fl_next
        bra  .f
.e:     ldx  kv_wp
        bsr  ibits
        std  kv_al
        pulx
        stx  kv_wp
        ldx  pv_m
        bsr  ibits
        std  kv_se
        tst  pv_top             ; the percentage
        beq  .np
        clra
        clrb
        std  kv_n
        ldd  kv_al
        subd #1
        std  kv_n+2
        ldd  #100
        std  kv_na
        ldd  kv_se
        subd #1
        std  kv_nb
        bsr  muldiv
        ldaa kv_n+3
        cmpa #100
        bls  .p
        ldaa #100
.p:     ldab pv_s
        ldx  #pv_p
        lsrb
        bcc  .p0
        inx
.p0:    staa 0,x
.np:    clr  pv_t
        ldd  kv_al              ; 2 (bits - 1) past N's bits: half
        subd #1
        asld
        subd kv_se
        bls  .third
        ldaa #PT_HALF
        ldab pv_s
        lsrb
        bcc  .yes
        ldaa #PT_PLUS
.yes:   staa pv_t
        sec
        rts
.third: ldab pv_s               ; 3 (bits - 1) at least N's bits: a third (N-1, and the chain only)
        cmpb #2
        bne  .no
        ldd  kv_al
        subd #1
        std  zt
        asld
        addd zt
        subd kv_se
        blo  .no
        ldaa #PT_THIRD
        bra  .yes
.no:    clc
        rts
        include "flnext.inc"
        include "ibits.inc"
