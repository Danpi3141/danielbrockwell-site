; dgch: A = the digit D's character (0 the first)
dgch:   addb dg_sk
        adca #0
        lsrd
        pshb
        psha
        tpa
        staa zm                 ; (carry: the low half of the byte)
        pula
        pulb
        addd dg_at
        xgdx
        ldab 0,x
        ldaa zm
        lsra
        bcs  .lo
        lsrb
        lsrb
        lsrb
        lsrb
.lo:    andb #15
        addb #'0'
        tba
        rts
