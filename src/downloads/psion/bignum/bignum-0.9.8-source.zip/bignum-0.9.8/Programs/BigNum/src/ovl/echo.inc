; echo: the line typed, and =, on the first line; echon: without the =; echot: B characters at X and =
        ifused echon
echon:  ldaa #1
        bra  echo_
        endif
echo:   clra
echo_:  ldx  kv_line
        ldab 0,x
        inx
        tsta
        bne  echo2
echot:  clra
echo2:  psha
        pshb
        pshx
        bsr  ln0
        pulx
        pulb
        pula
        psha
        asla                    ; room for " ="
        suba #2
        adda kv_w
        staa zt
        cmpb zt
        bls  .all
        ldab zt
        subb #3
        bsr  prb
        ldab #3
        ldaa #'.'
.dots:  bsr  putc
        decb
        bne  .dots
        bra  .eq
.all:   bsr  prb
.eq:    pula
        tsta
        bne  .o
        bsr  putsp
        ldaa #'='
        bsr  putc
.o:     bra  out
