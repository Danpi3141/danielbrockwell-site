// The memory tiers forced: an array of N words above the program. Each tier's limits, and its largest jobs: the
// biggest sieve's set-up and combining, a primality test at the cap, without NO MEMORY.   node tests/t_tiers.js [model]
'use strict';
const path = require('path'), { execFileSync } = require('child_process');
const { BN, HZ, ROOT } = require('./lib');
const model = process.argv[2] || 'lz64';
let bad = 0; const fail = (s) => { console.log('FAIL', s); bad++; };
const out = path.join(ROOT, 'build', 'pad');
const start = (words) => { const d = `${out}${words}`; execFileSync('python', [path.join(ROOT, 'tools', 'build.py'), '--out', d, '--pad', String(words)]); const g = new BN(model, { build: d }); return g; };
const powm = (b, e, p) => { let r = 1n; b %= p; while (e) { if (e & 1n) r = r * b % p; b = b * b % p; e >>= 1n; } return r; };
const free0 = new BN(model).free0;
const want = process.argv[3] ? [process.argv[3].split(',').map(Number)] : [[0, 1], [2350, 1], [2500, 2], [4450, 2], [4600, 3], [5300, 3], [5600, 4], [7000, 4], [8300, 4], [8400, 0]];
for (const [pad, tier] of want) {
  const words = pad; let g = start(words || 1);
  g.m.runProc('PAD', 'B'); let up = false;
  for (let i = 0; i < 100 && !up; i++) { g.run(0.1); up = g.sync() >= 0; }
  if (!up) { const t = g.text(); console.log(`pad ${words * 2}: ${t.replace(/\n/g, ' | ')}`); if (tier) fail('did not start'); else if (!/NEEDS/.test(t)) fail('no NEEDS'); continue; }
  g.run(0.5);
  const heap = g.peekw('kv_hi') - g.peekw('kv_lo'), t = g.peek('kv_tier');
  if (t !== tier) fail(`pad ${words * 2}: tier ${t}, not ${tier} (heap ${heap})`);
  const cap = [0, 8192, 8192, 2048, 2048][t], qcap = [0, 184, 168, 148, 0][t];
  const head = g.lines()[0];
  if (!head.startsWith(`BigNum ${cap}b`)) fail(head);
  const L = t === 4 ? 128 : 254;
  if (g.peek('kv_lmax') !== L) fail('line ' + g.peek('kv_lmax'));
  let r = g.line(`2**${cap - 1}`, 1e6); if (r.err) fail(`2**${cap - 1}: ${r.err}`); r = g.line(`2**${cap}`, 1e6); if (r.err !== 2) fail(`2**${cap}: ${r.err}`);
  const ref = (l, e) => { const q = g.line(l, 1e6); if (q.err !== e) fail(`${l}: ${q.err}`); };
  if (t === 4) { for (const l of ['SAVE A,"X"', 'RESUME', 'LOG', 'QS(2**64+1)']) ref(l, 6); } else ref(`QS(2**${qcap}+1)`, 6);
  g.line('CLR'); g.line('1');
  // a primality test at the cap: it must get into both its parts (base 2 stopped, Lucas begun by hand: the test called)
  const n = cap === 2048 ? '2**2047+1919' : '2**8191+4';                       // (any number will do for the memory)
  const typed = (l) => { for (let i = 0; i < 6 && !g.atLine(); i++) { g.inject('ON'); g.wait(); } g.wait(); g.m.write(g.peekw('kv_line'), [l.length, ...[...l].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', l.length); g.inject('EXE'); };
  const lines = [`ISPRIME(2**${cap - 1}+1)`];
  typed(cap === 2048 ? 'ISPRIME(2**2047+1919)' : 'ISPRIME(2**8191-2**4000+1)');
  g.run(cap === 2048 ? 20 : 120);
  if (g.atLine()) fail(`ISPRIME at the cap: error ${g.peek('kv_err')}`); else if (!/Base 2|divides|not prime|Trial/.test(g.text())) fail('ISPRIME: ' + g.text());
  const seen = g.lines()[g.four ? 1 : 0];
  g.m.poke(0x76, 1); g.run(3); g.m.poke(0x76, 65); g.run(3); g.wait(600);
  // Lucas's slots at the cap
  g.back(); const N = (1n << BigInt(cap - 1)) + 1919n;
  // the sieve near its cap: set up, and the memory its combining will need
  let q = '';
  if (t < 4) {
    const bits = qcap - 2; let a = (1n << BigInt(bits >> 1)) + 1n, b = (1n << BigInt(bits - (bits >> 1))) + 1n; const pr = (v) => powm(2n, v - 1n, v) === 1n && powm(3n, v - 1n, v) === 1n;
    while (!pr(a)) a += 2n; while (!pr(b)) b += 2n;
    b = a; do b += 2n; while (!pr(b)); typed(`QS(${a * b})`); g.run(400); if (!g.atLine()) g.m.runTo([g.addr('poll')], HZ * 5);   // (not inside an OS call: the LZ64 has another bank at $4000 then)
    if (g.atLine()) fail(`QS at ${bits} bits: error ${g.peek('kv_err')}`);
    const F = g.peek('q_f'), rb = (F + 8) >> 3, ub = g.peek('q_ub'); const use = (F + 10) * rb + 4 * F + Math.ceil(1.5 * (F + 10)) * ub; const room = g.peekw('q_pe') - g.peekw('kv_lim');
    q = `sieve ${bits} bits F ${F} sv ${g.peekw('q_svz')} relations' room ${Math.floor((g.peekw('q_pe') - g.peekw('q_rel')) / ub)} of ${F + 10}; combining ${use} of ${room}`;
    if (use > room) fail('combining: ' + q);
    g.m.poke(0x76, 1); g.run(3); g.m.poke(0x76, 65); g.run(3);
  }
  console.log(`pad ${words * 2} free ${free0 - 2 * words}: tier ${t} heap ${heap}, ${seen.trim()}; ${q}`);
}
console.log(bad ? `${bad} FAILED` : `t_tiers ${model} ok`);
process.exit(bad ? 1 : 0);
