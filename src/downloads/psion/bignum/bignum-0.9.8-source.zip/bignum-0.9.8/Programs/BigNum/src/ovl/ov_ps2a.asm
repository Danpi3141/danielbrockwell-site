; =====================================================================
; OV_PS2A: the second stage of P-1 and P+1 set up (for OV_PS2): the table of V(u), the first step
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        include "p2.inc"
        lastent ps2a

ps2a:   ldab #105
        ldaa pm_s
        cmpa #24
        beq  .d
        ldab #15
.d:     stab p2_d
        ldd  fx_lim             ; 25 B1
        ldx  #25
        os   UT$UMUL
        stab p2_h
        stx  p2_h+1
        ldd  p2_h               ; (the display's units: 256)
        bsr  part
        ldd  fx_lim
        tab
        clra
        std  kv_done
        ovsub OV_EST,7
; V(u) for u = 1, 3, 5 ...: 0 V(u), 1 V(u-2), 4 V(2)
        bsr  mrun
        mo    M_SQR,4,2,2
        mo    M_SUB,4,4,3
        mo    M_CPY,0,2,2        ; V(1), and V(-1) = V(1)
        mol   M_CPY,1,2,2
        ldaa #7
        staa p2_t
        ldaa #1
        staa p2_u
.u:     bsr  cop                ; one that is kept?
        bne  .nu
        ldaa p2_t
        inc  p2_t
        staa mi
        clra
        clrb
        std  mi+1
        ldab #M_CPY
        bsr  mop
.nu:    bsr  mrun               ; the next
        mo    M_MUL,6,0,4
        mo    M_SUB,6,6,1
        mo    M_CPY,1,0,0
        mol   M_CPY,0,6,6
        ldaa p2_u
        adda #2
        staa p2_u
        cmpa p2_d
        bls  .u
; V(D): from V(1) by the ladder
        ldab p2_d
        clra
        asld
        bsr  ladr
        bsr  mrun
        mo    M_CPY,4,0,0
        mo    M_CPY,5,2,2        ; (the product starts with anything that is not 0)
        mol   M_CPY,2,0,0
; the first window: from 210 m - 105, m = (B1 + 105) / 210, at least 1
        ldd  fx_lim
        addd #105
        ldx  #0
.m:     subd #210
        bcs  .md
        inx
        bra  .m
.md:    cpx  #0
        bne  .m1
        inx
.m1:    stx  kv_al
        ldab #210
        ldaa kv_al+1
        mul
        std  zt
        ldaa kv_al
        ldab #210
        mul
        addb zt
        stab zt
        adca #0
        staa ps_lo
        ldd  zt
        subd #105
        std  ps_lo+1
        ldaa ps_lo
        sbca #0
        staa ps_lo
        ldd  kv_al              ; v: for D = 30, 7 m - 3
        ldaa p2_d
        cmpa #105
        beq  .v
        ldd  kv_al
        asld
        asld
        asld
        subd kv_al
        subd #3
        bra  .vv
.v:     ldd  kv_al
.vv:    subd #1                 ; V((v-1)D) and V(vD) from the ladder on V(D)
        bsr  ladr               ; 0 V((v-1)D), 1 V(vD)
        bsr  mrun               ; changed over
        mo    M_CPY,6,0,0
        mo    M_CPY,0,1,1
        mol   M_CPY,1,6,6
        rts
; ladr: slots 0, 1 = V(D), V(D+1) of slot 2 (D may be 0); slot 3 = 2
ladr:   std  p2_i
        bsr  mrun
        mo    M_CPY,0,3,3
        mol   M_CPY,1,2,2
        ldaa #16
        staa p2_k
.t:     ldd  p2_i               ; (leading zeros)
        bmi  .l
        asld
        std  p2_i
        dec  p2_k
        bne  .t
        rts
.l:     ldd  p2_i
        asld
        std  p2_i
        bcc  .z
        bsr  mrun
        mo    M_MUL,0,0,1
        mo    M_SUB,0,0,2
        mo    M_SQR,1,1,1
        mol   M_SUB,1,1,3
        bra  .n
.z:     bsr  mrun
        mo    M_MUL,1,0,1
        mo    M_SUB,1,1,2
        mo    M_SQR,0,0,0
        mol   M_SUB,0,0,3
.n:     dec  p2_k
        bne  .l
        rts

        include "cop.inc"
