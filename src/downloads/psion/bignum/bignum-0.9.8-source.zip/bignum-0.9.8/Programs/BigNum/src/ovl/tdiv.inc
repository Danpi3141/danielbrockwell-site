; tdiv: does the odd number td_p (up to 65535) divide the number at td_x (its bytes' end in td_e, the first
; in td_x)? Z: yes. Byte by byte from the low end: each time the multiple of p that clears the low byte
; is added and the byte dropped, so it finds N / 256**n modulo p.
td_p    = zm                    ; (2: $41, $42)
td_r    = zx                    ; (2) what is carried
td_q    = zp                    ; (1)
td_i    = zp+1                  ; (1) -1/p modulo 256
td_t    = zw                    ; (2)
tdiv:   ldaa td_p+1             ; the inverse
        tab                     ; x = p, right to 3 bits
        bsr  .s
        bsr  .s
        negb
        stab td_i
        clra
        clrb
        std  td_r
        ldx  td_e
        tst  td_p
        beq  .short
.l:     dex
        ldab 0,x
        clra
        addd td_r
        bcs  .c
        std  td_t
        ldaa td_i
        mul
        stab td_q
        ldaa td_p+1
        mul
        addd td_t
        ldab #0
        rolb                    ; (the carry)
        staa td_t+1
        stab td_t
        ldaa td_q
        ldab td_p
        mul
        addb td_t+1
        adca td_t
        std  td_r
        cpx  td_x
        bne  .l
.e:     ldd  td_r
        beq  .x
        subd td_p
.x:     rts
.c:     std  td_t               ; (r + byte past 65535: 65536 more, 256 after the shift)
        ldaa td_i
        mul
        stab td_q
        ldaa td_p+1
        mul
        addd td_t
        ldab #1
        adcb #0
        staa td_t+1
        stab td_t
        ldaa td_q
        ldab td_p
        mul
        addb td_t+1
        adca td_t
        std  td_r
        cpx  td_x
        bne  .l
        bra  .e
; p below 256
.short: dex
        ldab 0,x
        addb td_r+1
        ldaa #0
        rola
        std  td_t
        ldaa td_i
        mul
        ldaa td_p+1
        mul
        addd td_t
        staa td_r+1
        cpx  td_x
        bne  .short
        bra  .e
.s:     pshb                    ; x = x (2 - p x)
        ldaa td_p+1
        mul
        negb
        addb #2
        pula
        mul
        rts
        ifused tdset
; tdset: the top number for tdiv
tdset:  ldx  kv_wp
        inx
        inx
        stx  td_x
        ldx  kv_wp
        bsr  inext
        stx  td_e
        rts
        endif
td_x    = kv_fs+16
td_e    = kv_fs+18
