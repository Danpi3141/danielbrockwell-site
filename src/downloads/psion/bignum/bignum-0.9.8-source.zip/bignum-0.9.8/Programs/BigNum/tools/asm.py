#!/usr/bin/env python3
"""HD6303 macro assembler for Drakeloft (grown from Tools/asm6303.py).

Everything the game runs lives in one OPL array whose address is only known at run time, so
every unit (the kernel, each overlay) is assembled at its offset inside that array, and every
16-bit value that depends on a relocatable symbol is listed as a fix-up for the loader to add
the array's address to.

Syntax (Motorola style):

    label:  ldaa  #$10        ; comment
    .loop:  staa  3,x         ; '.name' is local to the last global label
            ldab  count       ; direct page when the value is absolute and < $100
            os    KB$GETK     ; SWI + service number
    name    =     expr        ; or 'equ'; 'set' may be redefined
            org   expr        ; (code) pad up to an offset in this unit
            fcb   1,2,"text"  ; bytes
            fdb   label,$1234 ; words (relocatable ones are fixed up)
            fcl   "text"      ; length byte then text
            rmb   n           ; n zero bytes
            include "file"
            if expr / else / endif
    name    macro a,b         ; \\a \\b are the arguments, \\@ a number unique to the expansion,
            ...               ; \\# the number of arguments
            endm
            export name,...   ; (no-op marker; every global symbol is in the symbol table)

Branches: b?? and bsr assemble short when the target is in range and become a long form
(inverse branch over a jmp, or jsr) when it is not; the assembler repeats passes until the
layout settles. 'jbra'/'jbsr' are accepted as synonyms for bra/bsr.

Segments: 'rel' symbols (labels, and anything defined from them) move with the array; 'abs'
symbols do not. Symbols imported from another unit keep their segment.
"""
import os
import re
import sys

INH = {
    'nop': 0x01, 'lsrd': 0x04, 'asld': 0x05, 'lsld': 0x05, 'tap': 0x06, 'tpa': 0x07, 'inx': 0x08, 'dex': 0x09,
    'clv': 0x0A, 'sev': 0x0B, 'clc': 0x0C, 'sec': 0x0D, 'cli': 0x0E, 'sei': 0x0F, 'sba': 0x10,
    'cba': 0x11, 'tab': 0x16, 'tba': 0x17, 'xgdx': 0x18, 'daa': 0x19, 'slp': 0x1A, 'aba': 0x1B,
    'tsx': 0x30, 'ins': 0x31, 'pula': 0x32, 'pulb': 0x33, 'des': 0x34, 'txs': 0x35, 'psha': 0x36,
    'pshb': 0x37, 'pulx': 0x38, 'rts': 0x39, 'abx': 0x3A, 'rti': 0x3B, 'pshx': 0x3C, 'mul': 0x3D,
    'wai': 0x3E, 'swi': 0x3F,
    'nega': 0x40, 'coma': 0x43, 'lsra': 0x44, 'rora': 0x46, 'asra': 0x47, 'asla': 0x48, 'lsla': 0x48,
    'rola': 0x49, 'deca': 0x4A, 'inca': 0x4C, 'tsta': 0x4D, 'clra': 0x4F,
    'negb': 0x50, 'comb': 0x53, 'lsrb': 0x54, 'rorb': 0x56, 'asrb': 0x57, 'aslb': 0x58, 'lslb': 0x58,
    'rolb': 0x59, 'decb': 0x5A, 'incb': 0x5C, 'tstb': 0x5D, 'clrb': 0x5F,
}
BRANCH = {
    'bra': 0x20, 'brn': 0x21, 'bhi': 0x22, 'bls': 0x23, 'bcc': 0x24, 'bhs': 0x24, 'bcs': 0x25, 'blo': 0x25,
    'bne': 0x26, 'beq': 0x27, 'bvc': 0x28, 'bvs': 0x29, 'bpl': 0x2A, 'bmi': 0x2B, 'bge': 0x2C,
    'blt': 0x2D, 'bgt': 0x2E, 'ble': 0x2F, 'bsr': 0x8D,
}
INVERSE = {'beq': 'bne', 'bne': 'beq', 'bcc': 'bcs', 'bcs': 'bcc', 'bhs': 'blo', 'blo': 'bhs',
           'bhi': 'bls', 'bls': 'bhi', 'bpl': 'bmi', 'bmi': 'bpl', 'bge': 'blt', 'blt': 'bge',
           'bgt': 'ble', 'ble': 'bgt', 'bvc': 'bvs', 'bvs': 'bvc'}
MEM = {'neg': 0x60, 'com': 0x63, 'lsr': 0x64, 'ror': 0x66, 'asr': 0x67, 'asl': 0x68, 'lsl': 0x68, 'rol': 0x69,
       'dec': 0x6A, 'inc': 0x6C, 'tst': 0x6D, 'jmp': 0x6E, 'clr': 0x6F}
BITIMM = {'aim': 0x01, 'oim': 0x02, 'eim': 0x05, 'tim': 0x0B}
REG = {
    'suba': (0x80, 1), 'cmpa': (0x81, 1), 'sbca': (0x82, 1), 'subd': (0x83, 2), 'anda': (0x84, 1),
    'bita': (0x85, 1), 'ldaa': (0x86, 1), 'staa': (0x87, 0), 'eora': (0x88, 1), 'adca': (0x89, 1),
    'oraa': (0x8A, 1), 'adda': (0x8B, 1), 'cpx': (0x8C, 2), 'jsr': (0x8D, 0), 'lds': (0x8E, 2),
    'sts': (0x8F, 0),
    'subb': (0xC0, 1), 'cmpb': (0xC1, 1), 'sbcb': (0xC2, 1), 'addd': (0xC3, 2), 'andb': (0xC4, 1),
    'bitb': (0xC5, 1), 'ldab': (0xC6, 1), 'stab': (0xC7, 0), 'eorb': (0xC8, 1), 'adcb': (0xC9, 1),
    'orab': (0xCA, 1), 'addb': (0xCB, 1), 'ldd': (0xCC, 2), 'std': (0xCD, 0), 'ldx': (0xCE, 2),
    'stx': (0xCF, 0),
}
ALIAS = {'lda': 'ldaa', 'ldb': 'ldab', 'sta': 'staa', 'stb': 'stab', 'ora': 'oraa', 'orb': 'orab',
         'jbra': 'bra', 'jbsr': 'bsr', 'cmpd': None}

SERVICES = {
    'AL$FREE': 0, 'AL$GRAB': 1, 'AL$GROW': 2, 'AL$SHNK': 4, 'AL$SIZE': 5,
    'BT$SWOF': 12, 'BZ$ALRM': 13, 'BZ$BELL': 14, 'BZ$TONE': 15,
    'DP$EMIT': 16, 'DP$PRNT': 17, 'DP$STAT': 20, 'DP$WRDY': 22,
    'ER$MESS': 32, 'FL$BACK': 33, 'FL$BCAT': 34, 'FL$BOPN': 36, 'FL$CATL': 38, 'FL$CRET': 40, 'FL$DELN': 41,
    'FL$ERAS': 42, 'FL$FFND': 43, 'FL$FIND': 44, 'FL$NEXT': 46, 'FL$OPEN': 47, 'FL$PARS': 48, 'FL$READ': 49,
    'FL$RECT': 50, 'FL$RSET': 52, 'FL$SETP': 53, 'FL$SIZE': 54, 'FL$WRIT': 55,
    'KB$BREK': 70, 'KB$FLSH': 71, 'KB$GETK': 72, 'KB$INIT': 73, 'KB$STAT': 74, 'KB$TEST': 75, 'KB$UGET': 76,
    'PK$PKOF': 91, 'PK$QADD': 92, 'PK$RBYT': 93, 'PK$READ': 94, 'PK$RWRD': 95, 'PK$SADD': 96, 'PK$SAVE': 97,
    'PK$SETP': 98, 'PK$SKIP': 99, 'FL$RENM': 51, 'FL$FREC': 45,
    'TM$DAYV': 105, 'TM$TGET': 106, 'TM$UPDT': 107, 'TM$WAIT': 108,
    'UT$CPYB': 109, 'UT$DDSP': 110, 'UT$DISP': 111, 'UT$ENTR': 112, 'UT$FILL': 113, 'UT$ICPB': 114,
    'UT$ISBF': 115, 'UT$LEAV': 116, 'UT$SDIV': 117, 'UT$SMUL': 118, 'UT$SPLT': 119, 'UT$UDIV': 120,
    'UT$UMUL': 121, 'UT$UTOB': 122, 'UT$XCAT': 123, 'UT$XTOB': 124, 'UT$YSNO': 125,
    'BT$TOFF': 129, 'DP$MSET': 130, 'DP$CSET': 131, 'DP$CPRN': 132, 'DP$UDG': 133,
    'TM$NDYS': 149, 'TM$TSET': 179,
    'MN$DISP': 80, 'MN$1DSP': 135, 'MN$XDSP': 134, 'ED$EDIT': 28, 'ED$EPOS': 29, 'ED$VIEW': 30,
    'DP$VIEW': 21, 'DP$SAVE': 19, 'DP$REST': 18, 'ER$LKUP': 31, 'FL$BDEL': 35, 'FL$COPY': 39,
    'UT$CDSP': 126, 'KB$CONK': 177, 'BT$NOF': 9, 'BT$NON': 10, 'BT$PPRG': 11, 'TL$XXMD': 104,
}


class AsmError(Exception):
    pass


class Line:
    __slots__ = ('text', 'file', 'no', 'mac')

    def __init__(self, text, file, no, mac=''):
        self.text, self.file, self.no, self.mac = text, file, no, mac


def strip_comment(text):
    m = re.match(r'^((?:[^;"\']|"[^"]*"|\'.\')*)', text)
    rest = text[m.end():]
    if rest and not rest.startswith(';'):
        raise AsmError('a quotation mark that does not close: %s' % text.strip())
    return m.group(1).rstrip()


TEXTS = {}   # ftx: string -> its number in the text table (set by the build)


def split_args(arg):
    out, cur, i, depth = [], '', 0, 0
    while i < len(arg):
        ch = arg[i]
        if ch == '"':
            j = arg.index('"', i + 1)
            cur += arg[i:j + 1]
            i = j + 1
            continue
        if ch == "'" and i + 2 < len(arg) and arg[i + 2] == "'":
            cur += arg[i:i + 3]
            i += 3
            continue
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
        elif ch == ',' and depth == 0:
            out.append(cur.strip())
            cur = ''
            i += 1
            continue
        cur += ch
        i += 1
    if cur.strip() or out:
        out.append(cur.strip())
    return out


class Assembler:
    def __init__(self, path=None, source=None, origin=0, imports=None, defines=None, incdirs=None, share=None):
        self.share = share              # share jumps (a tuple of files to leave alone) or None
        self.origin = origin            # offset of this unit inside the array
        self.imports = dict(imports or {})   # name -> (value, seg) with value an array offset or absolute
        self.defines = dict(defines or {})
        self.incdirs = list(incdirs or [])
        if path:
            self.incdirs.insert(0, os.path.dirname(os.path.abspath(path)))
            source = open(path, encoding='utf-8').read()
            name = os.path.basename(path)
        else:
            name = '<asm>'
        self.lines = self.read(source, name)
        self.long = set()               # (file,no,mac,count) of branches that must be long

    def read(self, source, name):
        return [Line(t, name, i + 1) for i, t in enumerate(source.replace('\r', '').split('\n'))]

    # ------------------------------------------------------------------ expressions
    def ev(self, expr, final):
        """Returns (value, seg) with value an offset (rel) or absolute; (None, 'unknown') before final."""
        e = expr.strip()
        if not e:
            raise AsmError('empty expression')
        e = re.sub(r"'(.)'", lambda m: str(ord(m.group(1))), e)
        e = re.sub(r'\$([0-9A-Fa-f]+)', lambda m: str(int(m.group(1), 16)), e)
        e = re.sub(r'(?<![\w)])%([01]+)', lambda m: str(int(m.group(1), 2)), e)
        used = []

        def ident(m):
            n = m.group(0)
            if n.startswith('.'):
                n = self.scope + n
            if n in ('hi', 'lo', 'min', 'max', 'abs'):
                return n
            used.append(n)
            return 'S[%r]' % n
        e = re.sub(r'(?<![\w.\]])\.?[A-Za-z_][\w.$]*', ident, e)
        e = e.replace('/', '//').replace('*', '*')
        tab = {}
        segs = {}
        for n in used:
            v = self.lookup(n)
            if v is None:
                if final:
                    raise AsmError('undefined symbol %s' % n)
                return None, 'unknown'
            tab[n], segs[n] = v
        funcs = {'hi': lambda v: (v >> 8) & 255, 'lo': lambda v: v & 255, 'min': min, 'max': max, 'abs': abs}

        def val(shift):
            t = {n: tab[n] + (shift if segs[n] == 'rel' else 0) for n in tab}
            try:
                return eval(e, {'__builtins__': {}}, dict(funcs, S=t))
            except Exception as ex:
                raise AsmError('bad expression %r: %s' % (expr, ex))
        v = val(0)
        if not any(s == 'rel' for s in segs.values()):
            return v, 'abs'
        d = val(0x1000) - v
        if d == 0:
            return v, 'abs'
        if d == 0x1000:
            return v, 'rel'
        raise AsmError('expression is not relocatable: %r' % expr)

    def lookup(self, n):
        if n not in self.ifused:
            self.used.add(n)
        if n in self.sym:
            return self.sym[n]
        if n in self.imports:
            return self.imports[n]
        return None

    # ------------------------------------------------------------------ passes
    def assemble(self):
        self.via, self.isl, self.lost = {}, {}, set()
        self.settle()
        if self.share is None:
            return self
        # a far jsr, jmp or bcc reaches its target through a jmp to the same place nearby (one that is there
        # anyway, or one put in after an rts or bra): repeated while it gets shorter
        for _ in range(30):
            keep = (len(self.out) + len(self.fix) / 2, dict(self.via), dict(self.isl))
            if not self.plan():
                break
            self.settle()
            if len(self.out) + len(self.fix) / 2 >= keep[0]:
                self.via, self.isl = keep[1:]
                self.settle()
                break
        return self

    def plan(self):
        """One more round of sharing, from the layout as it is. True if something was found."""
        R = 118
        found = False
        # islands that are no longer worth it
        n = {}
        for k, i in self.viaused.items():
            n[i] = n.get(i, 0) + (3.5 if k[0] == 'bcc' else 1.5)
        for i in [i for i in self.isl if n.get(i, 0) <= 3.5]:
            del self.isl[i]
            self.via = {k: v for k, v in self.via.items() if v != i}
            found = True
        if found:
            return True
        cost = {'jsr': 1.5, 'jmp': 1.5, 'bcc': 3.5}
        targets = {}
        for pos, kind, name, key in self.far:
            targets.setdefault(name, []).append((pos, kind, key))
        taken = {p for p in self.isl}
        busy = set(self.via.values())           # jumps that others go through stay as they are
        for name, us in sorted(targets.items()):
            left = sorted(us, key=lambda u: u[0])
            # those in reach of an island there is
            isl = [(p, i) for i, (p, t) in self.islpos.items() if t == name and (i in self.isl or i in busy)]
            for p, kind, key in list(left):
                if key in busy:
                    continue
                for ip, i in isl:
                    if abs(ip - p) <= R and i != key:
                        self.via[key] = i
                        left.remove((p, kind, key))
                        found = True
                        break
            while True:
                best = (0.4, None, ())
                cand = [(p + (2 if kind == 'bcc' else 0), key, 0) for p, kind, key in left if kind != 'jsr']
                cand += [(p, ('new', key), 3.5) for p, key in self.safe if ('new', key) not in taken]
                for p, key, c in cand:
                    mem = [u for u in left if abs(u[0] - p) <= R and u[2] != key and u[2] not in busy]
                    g = sum(cost[u[1]] for u in mem) - c
                    if g > best[0]:
                        best = (g, key, mem)
                if not best[1]:
                    break
                found = True
                if best[1][0] == 'new':
                    self.isl[best[1]] = name
                    taken.add(best[1])
                else:
                    busy.add(best[1])
                for u in best[2]:
                    self.via[u[2]] = best[1]
                    left.remove(u)
                left = [u for u in left if u[2] != best[1]]
        return found

    def settle(self):
        self.sym = {}
        self.long = set(self.via.values())      # (the jumps others go through are always there)
        self.lost = set()
        prev = None
        self.prevsym, self.prevpc, self.curpc = {}, {}, {}
        self.prevused, self.used = None, set()
        self.islprev, self.islpos = {}, {}
        self.entmode = {}
        for attempt in range(80):
            self.run_pass(False)
            self.prevsym, self.prevpc, self.curpc = dict(self.sym), self.curpc, {}
            self.prevused, self.used = self.used, set()
            self.islprev = self.islpos
            state = (dict(self.sym), set(self.long), dict(self.entmode), frozenset(self.prevused), dict(self.islprev), set(self.lost))
            if state == prev:
                self.run_pass(True)
                if (dict(self.sym), set(self.long)) == prev[:2] and self.islpos == self.islprev:
                    return self
                self.prevsym, self.prevpc, self.curpc = dict(self.sym), self.curpc, {}
                self.prevused, self.used = self.used, set()
                self.islprev = self.islpos
            prev = state
        raise AsmError('layout did not settle')

    # ------------------------------------------------------------------ sharing jumps
    def target(self, arg):
        """The whole name of a branch's target, or None if it is not a plain name."""
        a = arg.strip()
        if not re.match(r'^\.?[A-Za-z_][\w.$]*$', a):
            return None
        return self.scope + a if a.startswith('.') else a

    def short(self, key):
        """Through which jump this far branch goes: its offset from the unit's start, or None."""
        i = self.via.get(key)
        if i is None or key in self.lost:
            return None
        p = self.islprev.get(i)
        if p is None:
            return -1                   # (not laid out yet: taken as near)
        at = self.prevpc.get(key)
        if at is not None and not -124 <= p[0] - (at + 2) <= 123:
            self.lost.add(key)
            return None
        return p[0]

    def hop(self, code, p, raw):
        off = p - (self.pc + 2) if self.final else 0
        if not -128 <= off <= 127:
            raise AsmError('a shared jump is out of reach')
        self.emit([code, off & 255], raw)

    def farcall(self, kind, arg, key, at):
        name = self.target(arg)
        if self.share is not None and name and key[0] not in self.share:
            self.far.append((self.pc, kind, name, key))
            if kind != 'jsr':
                self.islpos[key] = (self.pc + at, name)

    def run_pass(self, final):
        self.final = final
        self.macros = {}
        self.out = bytearray()
        self.fix = []
        self.listing = []
        self.scope = ''
        self.pc = 0
        self.uniq = 0
        self.cond = []
        self.ifused = []                # the ifused blocks open: a name used in its own block only is not used
        self.entries = []               # the entries' places (entry, lastent)
        self.far, self.safe, self.viaused, self.islpos = [], [], {}, {}
        self.defined_this_pass = set()
        for k, v in self.defines.items():
            self.setsym(k, v, 'abs', redefine=True)
        self.expand(self.lines, depth=0)
        if self.cond:
            raise AsmError('if without endif')

    def expand(self, lines, depth):
        i = 0
        while i < len(lines):
            ln = lines[i]
            i += 1
            try:
                text = strip_comment(ln.text)
                label, op, arg = self.parse(text)
                # conditionals
                if op in ('if', 'ifdef', 'ifndef', 'ifused', 'else', 'endif'):
                    self.conditional(op, arg)
                    continue
                if self.cond and not all(self.cond):
                    continue
                if op == 'macro':
                    body = []
                    nest = 0
                    while True:
                        if i >= len(lines):
                            raise AsmError('macro %s without endm' % label)
                        t = strip_comment(lines[i].text)
                        _, o2, _ = self.parse(t)
                        i += 1
                        if o2 == 'macro':
                            nest += 1
                        if o2 == 'endm':
                            if nest == 0:
                                break
                            nest -= 1
                        body.append(lines[i - 1])
                    params = [p.strip().lower() for p in arg.split(',')] if arg.strip() else []
                    self.macros[label.lower()] = (params, body)
                    continue
                if op == 'include':
                    fn = arg.strip().strip('"')
                    path = self.find_include(fn)
                    sub = self.read(open(path, encoding='utf-8').read(), os.path.basename(path))
                    self.expand(sub, depth + 1)
                    continue
                if op in self.macros:
                    if label:
                        self.label(label)
                    params, body = self.macros[op]
                    args = split_args(arg) if arg.strip() else []
                    if len(args) > len(params):
                        raise AsmError('macro %s takes %d arguments' % (op, len(params)))
                    self.uniq += 1
                    u = self.uniq
                    sub = []
                    for b in body:
                        t = b.text
                        for p, a in sorted(zip(params, args + [''] * (len(params) - len(args))), key=lambda z: -len(z[0])):
                            t = re.sub(r'\\' + re.escape(p) + r'(?![\w])', lambda m, a=a: a, t, flags=re.I)
                        t = t.replace('\\@', str(u)).replace('\\#', str(len(args)))
                        sub.append(Line(t, b.file, b.no, (ln.mac + '>' if ln.mac else '') + '%s:%d' % (op, u)))
                    if depth > 40:
                        raise AsmError('macros nested too deeply')
                    self.expand(sub, depth + 1)
                    continue
                self.statement(label, op, arg, ln)
            except AsmError as ex:
                if getattr(ex, 'located', False):
                    raise
                where = '%s:%d' % (ln.file, ln.no) + (' (in %s)' % ln.mac if ln.mac else '')
                err = AsmError('%s: %s\n    %s' % (where, ex, ln.text.strip()))
                err.located = True
                raise err

    def find_include(self, fn):
        for d in self.incdirs:
            p = os.path.join(d, fn)
            if os.path.exists(p):
                return p
        raise AsmError('include not found: %s' % fn)

    def conditional(self, op, arg):
        if op == 'if':
            if self.cond and not all(self.cond):
                self.cond.append(False)
            else:
                v, _ = self.ev(arg, True)
                self.cond.append(bool(v))
            self.ifused.append(None)
        elif op == 'ifused':            # a routine of a shared file: only if the rest of the unit uses it
            n = arg.strip()
            self.cond.append(self.prevused is None or n in self.prevused)
            self.ifused.append(n)
        elif op == 'ifdef':
            self.cond.append(self.lookup(arg.strip()) is not None)
            self.ifused.append(None)
        elif op == 'ifndef':
            self.cond.append(self.lookup(arg.strip()) is None)
            self.ifused.append(None)
        elif op == 'else':
            if not self.cond:
                raise AsmError('else without if')
            outer = all(self.cond[:-1])
            self.cond[-1] = (not self.cond[-1]) and outer
        elif op == 'endif':
            if not self.cond:
                raise AsmError('endif without if')
            self.cond.pop()
            self.ifused.pop()

    @staticmethod
    def parse(text):
        if not text.strip():
            return None, '', ''
        label = None
        if not text[0].isspace():
            m = re.match(r'^(\.?[A-Za-z_][\w.$]*):?\s*(.*)$', text)
            if not m:
                raise AsmError('bad label')
            label, rest = m.group(1), m.group(2)
        else:
            rest = text.strip()
            m2 = re.match(r'^(\.?[A-Za-z_][\w.$]*):\s*(.*)$', rest)
            if m2:
                label, rest = m2.group(1), m2.group(2)
        parts = rest.split(None, 1)
        op = parts[0].lower() if parts else ''
        arg = parts[1].strip() if len(parts) > 1 else ''
        return label, op, arg

    # ------------------------------------------------------------------ symbols
    def setsym(self, name, value, seg, redefine=False):
        if not redefine:
            if self.final:
                old = self.sym.get(name)
                if old != (value, seg) and not self.final_changed_ok:
                    pass
            if name in self.defined_this_pass:
                raise AsmError('duplicate symbol %s' % name)
            self.defined_this_pass.add(name)
        self.sym[name] = (value, seg)

    final_changed_ok = True

    def label(self, label):
        if not label.startswith('.'):
            self.scope = label
            name = label
        else:
            name = self.scope + label
        self.setsym(name, self.origin + self.pc, 'rel')

    # ------------------------------------------------------------------ output
    def emit(self, data, text=''):
        self.listing.append((self.origin + self.pc, bytes(data), text))
        self.out += bytes(data)
        self.pc += len(data)

    def word(self, v, seg, at):
        if seg == 'rel':
            self.fix.append(self.pc + at)
        v = (v or 0) & 0xFFFF
        return [v >> 8, v & 255]

    def byte(self, v, seg, what):
        if seg == 'rel':
            raise AsmError('%s must not be relocatable' % what)
        if v is None:
            return 0
        if not -128 <= v <= 255:
            raise AsmError('%s out of range: %d' % (what, v))
        if what == 'index offset' and v < 0:
            raise AsmError('index offset %d: offsets are unsigned (0-255) on the 6303' % v)
        return v & 255

    def key(self, ln):
        return (ln.file, ln.no, ln.mac)

    def endsafe(self, op, key):
        """After an rts or bra a shared jump may stand."""
        if self.share is None or op not in ('rts', 'bra') or key[0] in self.share:
            return
        i = ('new', key)
        if i in self.isl:
            name = self.isl[i]
            self.islpos[i] = (self.pc, name)
            v = self.lookup(name)
            self.emit([0x7E] + self.word(v[0] if v else 0, 'rel', 1), '        jmp  %s   ; (shared)' % name)
        else:
            self.safe.append((self.pc, key))

    # ------------------------------------------------------------------ statements
    def statement(self, label, op, arg, ln):
        final = self.final
        if op in ('=', 'equ', 'set'):
            v, seg = self.ev(arg, final)
            if v is None:
                v, seg = 0, 'abs'
            name = label if not label.startswith('.') else self.scope + label
            self.setsym(name, v, seg, redefine=(op == 'set'))
            return
        if label:
            self.label(label)
        if not op:
            return
        op = ALIAS.get(op, op) or op
        raw = ln.text
        if op == 'export':
            return
        if op == 'org':
            v, _ = self.ev(arg, True)
            v -= self.origin
            if v < self.pc:
                raise AsmError('org moves backwards ($%X < $%X)' % (v + self.origin, self.pc + self.origin))
            self.emit(bytes(v - self.pc), raw)
            return
        if op == 'rmb':
            v, _ = self.ev(arg, True)
            self.emit(bytes(v), raw)
            return
        if op == 'ftx':
            # a text kept on the pack: its number (the build adds every ftx string to the text table first)
            t = arg.strip()
            if not (len(t) >= 2 and t[0] == '"' and t[-1] == '"'):
                raise AsmError('ftx takes one "string"')
            if t[1:-1] not in TEXTS:
                raise AsmError('ftx %s: not in the text table (the build scans for ftx lines)' % t)
            n = TEXTS[t[1:-1]]
            self.emit(bytes([n >> 8, n & 255]), raw)
            return
        if op in ('fcb', 'fcc', 'fcl'):
            data = []
            for item in split_args(arg):
                if item.startswith('"'):
                    if item.count('"') != 2 or not item.endswith('"'):
                        raise AsmError('bad text %s' % item)
                    data += list(item[1:-1].encode('latin-1'))
                else:
                    v, seg = self.ev(item, final)
                    data.append(self.byte(v, seg, 'fcb value'))
            if op == 'fcl':
                data = [len(data)] + data
            self.emit(data, raw)
            return
        if op == 'fdb':
            data = []
            for item in split_args(arg):
                v, seg = self.ev(item, final)
                data += self.word(v, seg, len(data))
            self.emit(data, raw)
            return
        if op == 'error':
            raise AsmError(arg)
        if op == 'os':
            if arg not in SERVICES:
                raise AsmError('unknown service %s' % arg)
            self.emit([0x3F, SERVICES[arg]], raw)
            return
        if op in INH:
            if arg:
                raise AsmError('%s takes no operand' % op)
            self.emit([INH[op]], raw)
            self.endsafe(op, self.key(ln))
            return
        if op in BRANCH or (op.startswith('l') and op[1:] in BRANCH):
            longform = op.startswith('l') and op[1:] in BRANCH
            if longform:
                op = op[1:]
            v, seg = self.ev(arg, final)
            k = self.key(ln)
            # decide the size: long if forced, recorded as long, or known to be out of range
            is_long = longform or k in self.long
            # decide on the previous pass's layout as a whole (its symbols and this branch's
            # address then): mixing this pass's addresses with last pass's forward labels
            # marks branches long that are not (TFA, 20 Nov)
            if not is_long and not final and k in self.prevpc:
                saved, self.sym = self.sym, self.prevsym
                try:
                    pv, pseg = self.ev(arg, False)
                finally:
                    self.sym = saved
                if pv is not None and pseg == 'rel':
                    off = pv - (self.origin + self.prevpc[k] + 2)
                    if not -128 <= off <= 127:
                        self.long.add(k)
                        is_long = True
            if op == 'bra' and not is_long and self.share is not None:   # to what comes next: nothing
                gone = self.entmode.get(k, False)
                if not final and k in self.prevpc:
                    saved, self.sym = self.sym, self.prevsym
                    try:
                        pv, _ = self.ev(arg, False)
                    finally:
                        self.sym = saved
                    gone = pv is not None and pv - (self.origin + self.prevpc[k]) == (0 if gone else 2)
                    self.entmode[k] = gone
                if gone:
                    self.curpc[k] = self.pc
                    if final and v != self.origin + self.pc:
                        raise AsmError('%s no longer comes next' % arg)
                    return
            self.curpc[k] = self.pc
            if not is_long and seg != 'rel' and v is not None and final:
                raise AsmError('branch to an absolute address')
            if is_long:
                p = self.short(k)
                if p is not None:
                    self.viaused['jsr' if op == 'bsr' else 'jmp' if op == 'bra' else 'bcc', k] = self.via[k]
                    self.hop(BRANCH[op], p, raw)
                    self.endsafe(op, k)
                    return
                self.farcall('jsr' if op == 'bsr' else 'jmp' if op == 'bra' else 'bcc', arg, k, 0 if op in ('bra', 'bsr') else 2)
                if op == 'bra':
                    self.emit([0x7E] + self.word(v, 'rel' if seg != 'abs' else seg, 1), raw)
                elif op == 'bsr':
                    self.emit([0xBD] + self.word(v, 'rel' if seg != 'abs' else seg, 1), raw)
                elif op == 'brn':
                    self.emit([0x21, 0], raw)
                else:
                    self.emit([BRANCH[INVERSE[op]], 3, 0x7E] + self.word(v, 'rel' if seg != 'abs' else seg, 3), raw)
                self.endsafe(op, k)
                return
            off = 0
            if final:
                off = v - (self.origin + self.pc + 2)
                if not -128 <= off <= 127:
                    self.long.add(k)
                    off = 0
            self.emit([BRANCH[op], off & 255], raw)
            self.endsafe(op, k)
            return
        if op in ('entry', 'lastent'):
            # an entry of an overlay's table, 3 bytes: a bra (no fix-up) where it reaches, or a jmp; the last one
            # nothing at all if its routine comes next
            v, seg = self.ev(arg, final)
            k = self.key(ln)
            self.entries.append(self.pc)
            mode = self.entmode.get(k, 'jmp')
            if not final and k in self.prevpc:
                saved, self.sym = self.sym, self.prevsym
                try:
                    pv, _ = self.ev(arg, False)
                finally:
                    self.sym = saved
                pp = self.prevpc[k]
                off = pv - (self.origin + pp + 2) if pv is not None else 999
                if op == 'lastent' and off + 2 == (0 if mode == 'none' else 3):
                    mode = 'none'
                else:
                    mode = 'bra' if -128 <= off <= 127 else 'jmp'
                self.entmode[k] = mode
            self.curpc[k] = self.pc
            if mode == 'none':
                if final and v != self.origin + self.pc:
                    raise AsmError('%s no longer comes next' % arg)
            elif mode == 'bra':
                off = v - (self.origin + self.pc + 2) if final else 0
                if not -128 <= off <= 127:
                    raise AsmError('%s is out of reach' % arg)
                self.emit([0x20, off & 255, 0x01], raw)
            else:
                self.emit([0x7E] + self.word(v, 'rel', 1), raw)
            return
        if op in BITIMM:
            a = split_args(arg)
            if len(a) < 2 or not a[0].startswith('#'):
                raise AsmError('%s needs #mask,address' % op)
            mv, ms = self.ev(a[0][1:], final)
            mask = self.byte(mv, ms, 'mask')
            if len(a) == 3 and a[2].lower() == 'x':
                v, seg = self.ev(a[1] or '0', final)
                self.emit([0x60 + BITIMM[op], mask, self.byte(v, seg, 'index offset')], raw)
            else:
                v, seg = self.ev(a[1].lstrip('<'), final)
                self.emit([0x70 + BITIMM[op], mask, self.byte(v, seg, 'direct address')], raw)
            return
        if op in MEM or op in REG:
            mode, expr = self.operand(arg)
            v, seg = self.ev(expr, final)
            if op in MEM:
                base = MEM[op]
                if mode == 'imm':
                    raise AsmError('%s cannot be immediate' % op)
                if mode == 'idx':
                    self.emit([base, self.byte(v, seg, 'index offset')], raw)
                else:
                    if op == 'jmp' and seg == 'rel':
                        k = self.key(ln)
                        self.curpc[k] = self.pc
                        p = self.short(k)
                        if p is not None:
                            self.viaused['jmp', k] = self.via[k]
                            self.hop(0x20, p, raw)
                            return
                        self.farcall('jmp', arg, k, 0)
                    self.emit([base + 0x10] + self.word(v, seg, 1), raw)
                return
            base, immsize = REG[op]
            if op == 'jsr' and mode == 'auto' and seg == 'rel':
                k = self.key(ln)
                self.curpc[k] = self.pc
                p = self.short(k)
                if p is not None:
                    self.viaused['jsr', k] = self.via[k]
                    self.hop(0x8D, p, raw)
                    return
                self.farcall('jsr', arg, k, 0)
            if mode == 'imm':
                if immsize == 0:
                    raise AsmError('%s cannot be immediate' % op)
                if immsize == 1:
                    self.emit([base, self.byte(v, seg, 'immediate')], raw)
                else:
                    self.emit([base] + self.word(v, seg, 1), raw)
            elif mode == 'idx':
                self.emit([base + 0x20, self.byte(v, seg, 'index offset')], raw)
            elif mode == 'dir' or (mode == 'auto' and seg == 'abs' and v is not None and 0 <= v < 0x100):
                self.emit([base + 0x10, self.byte(v, seg, 'direct address')], raw)
            else:
                self.emit([base + 0x30] + self.word(v, seg, 1), raw)
            return
        raise AsmError('unknown instruction %s' % op)

    @staticmethod
    def operand(arg):
        if not arg:
            raise AsmError('operand missing')
        if arg.startswith('#'):
            return 'imm', arg[1:]
        m = re.match(r'^(.*),\s*[xX]$', arg)
        if m:
            return 'idx', m.group(1).strip() or '0'
        if arg.startswith('<'):
            return 'dir', arg[1:]
        if arg.startswith('>'):
            return 'ext', arg[1:]
        return 'auto', arg

    # ------------------------------------------------------------------ results
    def symbols(self):
        return {n: v for n, v in self.sym.items() if '.' not in n}

    def listing_text(self):
        out = []
        for pc, data, raw in self.listing:
            hx = data.hex().upper()
            out.append('%04X  %-12s %s' % (pc, hx[:12], raw.rstrip()))
            for i in range(12, min(len(hx), 48), 12):
                out.append('      %-12s' % hx[i:i + 12])
        return '\n'.join(out)


def assemble(path=None, source=None, origin=0, imports=None, defines=None, incdirs=None, share=None):
    return Assembler(path, source, origin, imports, defines, incdirs, share).assemble()


if __name__ == '__main__':
    try:
        a = assemble(sys.argv[1])
    except AsmError as ex:
        sys.exit(str(ex))
    print(a.listing_text())
    print('; %d bytes, %d fix-ups' % (len(a.out), len(a.fix)))
