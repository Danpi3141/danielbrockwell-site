; =====================================================================
; OV_FILE: SAVE A,"name" and LOAD A,"name": a number in a data file, its decimal digits in records of up to 200
; (a minus sign first). On A: unless the name says another device. Not on the smallest tier.
; =====================================================================
        include "macros.inc"
        entry save
        lastent load

fi_b    = kv_fs+16              ; (2) the record buffer
fi_i    = kv_fs+18              ; (2) the digit, or the record
fi_n    = kv_fs+20              ; the character
fi_s    = kv_fs+21              ; 1: the first one has been seen
REC     = 200
save:   bsr  args
        ldab kv_dst
        bsr  vfind
        bcc  .set
        ldab #E_SET
        bra  err
.set:   bsr  hcopy
        ldx  #fname             ; (the name, for the overlay that does it)
        stx  zx
        ldx  #kv_lbuf
        stx  zp
        ldd  #14
        bsr  cpb
        ovsub OV_FSAV,0
        jmp  main
load:   bsr  args
        cmpa #'@'
        beq  syn
        bsr  runon
        ldx  #fname
        os   FL$OPEN
        bcs  oserr
        tab
        os   FL$RECT
        clra
        clrb
        bsr  hpush
        ldd  #256
        bsr  walloc
        stx  fi_b
        ldx  #1
        stx  fi_i
        clr  kv_cy              ; the sign
        clr  fi_s
        bsr  grp
.r:     ldd  fi_i
        os   FL$FREC
        bcs  .e
        ldd  fi_i
        os   FL$RSET
        ldx  fi_b
        os   FL$READ
        bcs  oserr
        clr  fi_n
.c:     ldx  fi_b               ; (the buffer moves as the number grows)
        ldab fi_n
        cmpb 0,x
        beq  .n
        inc  fi_n
        abx
        ldaa 1,x
        bsr  digit
        bra  .c
.n:     ldx  fi_i
        inx
        stx  fi_i
        bra  .r
.e:     bsr  put
        ldx  fi_b               ; the buffer gone: the number is above it
        ldab #128
        abx
        abx
        stx  kv_wp
        bsr  ilenw              ; (past the cap by the last digits)
        subd kv_cap
        bhi  big
        ldx  fi_i               ; (no records, no number)
        dex
        beq  arg
        tst  kv_cy
        beq  .pos
        bsr  hneg
.pos:   ovsub OV_DIGS,0
        ovsub OV_SHOW,5         ; kept in the variable
        ldx  #loaded
        bra  report

; report: the text at X, the digits, " digits", for the header
report: pshx
        bsr  ln0
        pulx
        bsr  prs
        ldd  kv_digs
        bsr  pdig
        ldx  #kv_lbuf
        stx  zx
        ldx  #RTB_BL+1
        stx  zp
        ldab #20
        stab RTB_BL
        ldaa #E_MSG
        staa kv_err
        clra
        bsr  cpb
        jmp  main
loaded: fcl  "Loaded "

; a character of the file: A
digit:  cmpa #33                ; (spaces and TABs are nothing)
        blo  digx
        tst  fi_s               ; a minus sign: only before all else
        bne  .d
        inc  fi_s
        cmpa #'-'
        bne  .d
        inc  kv_cy
        rts
.d:
        suba #'0'
        blo  arg
        cmpa #9
        bhi  arg
        tab
        pshb                    ; into the group of four
        ldd  kv_ia
        ldx  #10
        os   UT$UMUL
        xgdx
        std  kv_ia
        pulb
        clra
        addd kv_ia
        std  kv_ia
        ldd  kv_ib
        ldx  #10
        os   UT$UMUL
        stx  kv_ib
        cpx  #10000
        bne  digx
put:    ldd  fi_b               ; the group into the number (which lies above the buffer)
        addd #256
        std  kv_wp
        ldd  kv_ia
        std  kv_na
        ldd  kv_ib
        bsr  mul_
        ldx  fi_b
        stx  kv_wp
grp:    ldx  #0
        stx  kv_ia
        ldx  #1
        stx  kv_ib
digx:   rts
; mul_: the number at fi_b + 256 times D plus kv_na: it grows over the buffer, so the buffer moves down first
mul_:   pshb
        psha
        bsr  ilenw              ; past the cap: too big
        subd kv_cap
        bhi  big
        ldd  kv_wp
        subd #256
        std  zx                 ; the buffer four bytes down
        subd #4
        std  zp
        std  fi_b
        ldx  kv_wp
        ldd  zp
        subd kv_lim
        bcs  nomem
        ldd  #256
        bsr  cpb
        pula
        pulb
        bsr  hmuladd            ; (into the four bytes)
        ldd  fi_b               ; and the buffer up to it again
        addd #256
        std  zx
        ldd  kv_wp
        std  zp
        subd #256
        std  fi_b
        ldd  #256
        bra  cpd
big:    bra  errbig
arg:    ldab #E_ARG
        clr  kv_epos
        bra  err
oserr:  pshb
        bsr  cls
        pulb
        os   ER$MESS            ; (it waits for SPACE)
        jmp  main

; args: the variable (kv_dst, and A), the comma, the name (fname)
args:   ldaa kv_tier
        cmpa #4
        beq  .avl
        bsr  nextc
        bsr  upc
        cmpb #'A'
        blo  syn
        cmpb #'Z'
        bhi  syn
        stab kv_dst
        bsr  nextc
        cmpb #','
        beq  .name
        bsr  upc                ; ANS
        cmpb #'N'
        bne  syn
        bsr  nextc
        bsr  upc
        cmpb #'S'
        bne  syn
        ldaa kv_dst
        cmpa #'A'
        bne  syn
        ldaa #'@'
        staa kv_dst
        bsr  nextc
        cmpb #','
        bne  syn
.name:  bsr  nextc
        cmpb #'"'
        bne  .n0
        bsr  nextc
.n0:    clr  fname
        ldx  #fname+1
.c:     cmpb #'"'
        beq  .e
        tstb
        beq  .e
        ldaa fname
        cmpa #10
        beq  syn
        bsr  upc
        stab 0,x
        inx
        inc  fname
        pshx
        bsr  nextc
        pulx
        bra  .c
.e:     ldaa fname
        beq  syn
        ldaa fname+2            ; no device: A:
        cmpa #':'
        beq  .dev
        ldab fname
        ldx  #fname
        abx
.mv:    ldaa 0,x
        staa 2,x
        dex
        decb
        bne  .mv
        inc  fname
        inc  fname
        ldd  #$413A             ; A:
        std  fname+1
.dev:   ldaa kv_dst
        rts
.avl:   ldab #E_AVL
        clr  kv_epos
        bra  err
syn:    ldab #E_SYN
        ldaa kv_tp
        deca
        deca
        staa kv_epos
        bra  err
vfind:  stab zm
        ldx  kv_vb
.f:     cpx  kv_hi
        beq  .no
        ldab zm
        cmpb 0,x
        beq  .y
        inx
        bsr  inext
        bra  .f
.y:     inx
        clc
        rts
.no:    sec
        rts
fname:  rmb  14
        include "nextc.inc"
