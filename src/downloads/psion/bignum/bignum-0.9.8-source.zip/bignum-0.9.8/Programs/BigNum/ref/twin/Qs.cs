// The PC twin of BigNum's sieve: a self-initialising quadratic sieve with the Psion's small factor bases,
// run for real on random semiprimes, its steps counted and priced in 6303 cycles.
//   csc /o+ /r:System.Numerics.dll Qs.cs
//   Qs digits F M s thresholdSlack lpMult seed count [mode]    (mode 1: MPQS with a = q*q, as in the spec)
using System;
using System.Collections.Generic;
using System.Numerics;

class Qs
{
    static Random rnd;
    static BigInteger RandBits(int bits) { byte[] b = new byte[bits / 8 + 2]; rnd.NextBytes(b); b[b.Length - 1] = 0; BigInteger v = new BigInteger(b); v &= (BigInteger.One << bits) - 1; return v; }
    static BigInteger RandBelow(BigInteger n) { int bits = 1; while ((BigInteger.One << bits) < n) bits++; BigInteger v; do { v = RandBits(bits); } while (v >= n); return v; }
    static bool IsPrime(BigInteger n)
    {
        if (n < 2) return false; int[] ps = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37 };
        foreach (int p in ps) if (n % p == 0) return n == p;
        BigInteger d = n - 1; int s = 0; while (d.IsEven) { d >>= 1; s++; }
        foreach (int a in ps) { BigInteger x = BigInteger.ModPow(a, d, n); if (x.IsOne || x == n - 1) continue; bool ok = false; for (int i = 1; i < s; i++) { x = x * x % n; if (x == n - 1) { ok = true; break; } } if (!ok) return false; }
        return true;
    }
    static BigInteger RandPrime(BigInteger lo, BigInteger hi) { for (; ; ) { BigInteger v = lo + RandBelow(hi - lo); v |= 1; if (v < hi && IsPrime(v)) return v; } }
    static BigInteger Sqrt(BigInteger n) { if (n.IsZero) return 0; BigInteger x = (BigInteger)Math.Exp(BigInteger.Log(n) / 2); for (int i = 0; i < 200; i++) { BigInteger y = (x + n / x) >> 1; if (BigInteger.Abs(y - x) <= 1) { x = y; break; } x = y; } while (x * x > n) x--; while ((x + 1) * (x + 1) <= n) x++; return x; }
    static int ModInv(int a, int p) { int t = 0, nt = 1, r = p, nr = a % p; while (nr != 0) { int q = r / nr; int x = t - q * nt; t = nt; nt = x; x = r - q * nr; r = nr; nr = x; } return t < 0 ? t + p : t; }
    static int Pow(long b, long e, long m) { long r = 1; b %= m; while (e > 0) { if ((e & 1) == 1) r = r * b % m; b = b * b % m; e >>= 1; } return (int)r; }
    static int SqrtMod(int a, int p) { for (int x = 0; x < p; x++) if ((long)x * x % p == a) return x; return -1; }

    public class Result { public double cycles; public double tSieve, tPoly, tA, tCand, tLin; public int polys, aas, cands, full, partial, rels; public bool ok; public int F, pmax; public double msPerPoly; }

    static int[] primesList;
    static void InitPrimes() { List<int> l = new List<int>(); for (int i = 2; i < 20000; i++) { bool p = true; for (int d = 2; d * d <= i; d++) if (i % d == 0) { p = false; break; } if (p) l.Add(i); } primesList = l.ToArray(); }

    static int Multiplier(BigInteger N, int F)
    {
        int[] ks = { 1, 2, 3, 5, 6, 7, 10, 11, 13, 14, 15, 17, 19, 21, 22, 23, 26, 29, 30, 31, 33, 34, 35, 37, 38, 39, 41, 42, 43, 46, 47, 51, 53, 55, 57, 58, 59, 61, 62, 65, 66, 67, 69, 70, 71, 73 };
        double best = -1e9; int bk = 1;
        foreach (int k in ks)
        {
            BigInteger kN = N * k; double s = -0.5 * Math.Log(k); int m8 = (int)(kN % 8);
            if (m8 == 1) s += 2 * Math.Log(2); else if (m8 == 5) s += Math.Log(2); else if (m8 == 3 || m8 == 7) s += 0.5 * Math.Log(2);
            for (int i = 1; i < 120; i++) { int p = primesList[i]; int a = (int)(kN % p); if (a == 0) s += Math.Log(p) / p; else if (Pow(a, (p - 1) / 2, p) == 1) s += 2 * Math.Log(p) / (p - 1); }
            if (s > best) { best = s; bk = k; }
        }
        return bk;
    }

    // cost constants (6303 cycles)
    public static double C_UPD = 20, C_PRIMEROOT = 34, C_CELL = 8, C_SWITCH = 65, C_AINIT = 1300, C_AFIX = 400000, C_CAND = 45000, C_CANDP = 260, C_POLYFIX = 30000;

    public static Result Run(BigInteger N, int Fmax, int M, double slack, int lpMult, int smallP, int qMin, bool mult, double maxCycles)
    {
        Result R = new Result();
        int k = mult ? Multiplier(N, Fmax) : 1;
        BigInteger kN = N * k;
        List<int> fb = new List<int>(), ts = new List<int>();
        fb.Add(2); ts.Add(1);
        for (int i = 1; fb.Count < Fmax; i++) { int p = primesList[i]; int a = (int)(kN % p); if (a == 0) { fb.Add(p); ts.Add(0); } else if (Pow(a, (p - 1) / 2, p) == 1) { fb.Add(p); ts.Add(SqrtMod(a, p)); } }
        int F = fb.Count; int[] P = fb.ToArray(); int[] T = ts.ToArray(); int pmax = P[F - 1]; R.F = F; R.pmax = pmax;
        int[] lg = new int[F]; for (int i = 0; i < F; i++) lg[i] = (int)Math.Round(Math.Log(P[i], 2));
        double log2N = BigInteger.Log(kN) / Math.Log(2);
        double target = log2N / 2 + 0.5 - Math.Log(M, 2);       // log2 of a = sqrt(2 kN) / M
        // a's primes: from the base, between qMin and QMAX, s so that they are near the middle
        int s = 1; for (s = 2; s < 14; s++) { double each = target / s; if (each < Math.Log(QMID, 2)) break; }
        if (target / s < Math.Log(qMin, 2)) s--;
        int wlo = 2; while (wlo < F - 1 && P[wlo] < qMin) wlo++;
        int whi = wlo; while (whi < F && P[whi] < QMAX) whi++;
        { double each = target / s; int c = wlo; while (c < whi - 1 && Math.Log(P[c], 2) < each) c++; int w = Math.Max(s + 3, 8); wlo = Math.Max(wlo, c - w); whi = Math.Min(whi, c + w); }
        R.msPerPoly = s;
        HashSet<string> used = new HashSet<string>();
        int need = F + 10;
        int fulls = 0; Dictionary<int, int> partials = new Dictionary<int, int>(); int combos = 0;
        int lpMax = lpMult * pmax;
        double logQ = log2N / 2 - 0.5 + Math.Log(M, 2);         // log2 of M sqrt(kN/2)
        int thr = (int)(logQ - slack - (lpMult > 0 ? Math.Log(lpMax, 2) : 0));
        int[] sieve = new int[2 * M];
        double upd = 0;
        while (fulls + combos < need)
        {
            // a new a: s-1 random primes of the window, the last to come nearest the target
            int[] qi = new int[s]; double bestDiff = 1e9; int[] bestQ = null;
            for (int tr = 0; tr < 30; tr++)
            {
                HashSet<int> set = new HashSet<int>(); double sum = 0; while (set.Count < s - 1) { int j = wlo + rnd.Next(whi - wlo); if (T[j] == 0) continue; if (set.Add(j)) sum += Math.Log(P[j], 2); }
                int bj = -1; double bd = 1e9; for (int j = 2; j < F && P[j] < QMAX; j++) if (!set.Contains(j) && T[j] != 0 && P[j] >= qMin / 2) { double d = Math.Abs(sum + Math.Log(P[j], 2) - target); if (d < bd) { bd = d; bj = j; } }
                List<int> li = new List<int>(set); li.Add(bj); li.Sort(); string key = string.Join(",", li);
                if (used.Contains(key)) continue; if (bd < bestDiff) { bestDiff = bd; bestQ = li.ToArray(); }
                if (bd < 0.15) break;
            }
            if (bestQ == null) { bestQ = new int[0]; R.ok = false; return R; }
            used.Add(string.Join(",", bestQ)); qi = bestQ;
            BigInteger a = 1; foreach (int j in qi) a *= P[j];
            R.aas++; R.tA += C_AFIX + C_AINIT * F * s;
            BigInteger[] B = new BigInteger[s];
            for (int l = 0; l < s; l++) { int q = P[qi[l]]; BigInteger aq = a / q; int inv = ModInv((int)(aq % q), q); int g = (int)((long)T[qi[l]] * inv % q); if (g > q / 2) g = q - g; B[l] = aq * g; }
            bool[] inA = new bool[F]; foreach (int j in qi) inA[j] = true;
            int[,] delta = new int[s, F]; int[] ainv = new int[F];
            for (int i = 1; i < F; i++) if (!inA[i]) { int p = P[i]; ainv[i] = ModInv((int)(a % p), p); for (int l = 0; l < s; l++) delta[l, i] = (int)((long)(2 * (B[l] % p) % p) * ainv[i] % p); }
            BigInteger b = 0; foreach (BigInteger x in B) b += x;
            int[] r1 = new int[F], r2 = new int[F];
            for (int i = 1; i < F; i++) if (!inA[i]) { int p = P[i]; int bp = (int)(b % p); int x1 = (int)(((long)(T[i] - bp + p) % p) * ainv[i] % p), x2 = (int)(((long)(p - T[i] - bp + p) % p) * ainv[i] % p); r1[i] = (x1 + M) % p; r2[i] = (x2 + M) % p; }
            int polys = 1 << (s - 1);
            for (int poly = 0; poly < polys; poly++)
            {
                if (poly > 0)
                {
                    int v = 0; int t = poly; while ((t & 1) == 0) { t >>= 1; v++; }
                    bool neg = ((poly >> (v + 1)) & 1) == 0;   // subtract when the Gray code's bit goes in
                    if (neg) b -= 2 * B[v]; else b += 2 * B[v];
                    for (int i = 1; i < F; i++) if (!inA[i]) { int p = P[i]; int d = neg ? delta[v, i] : p - delta[v, i]; if (d == p) d = 0; r1[i] += d; if (r1[i] >= p) r1[i] -= p; r2[i] += d; if (r2[i] >= p) r2[i] -= p; }
                    R.tPoly += C_SWITCH * F + C_POLYFIX;
                }
                R.polys++;
                Array.Clear(sieve, 0, 2 * M);
                double u = 0; int np = 0;
                for (int i = 1; i < F; i++) if (!inA[i] && P[i] >= smallP)
                    {
                        int p = P[i], L = lg[i]; np++;
                        for (int x = r1[i]; x < 2 * M; x += p) { sieve[x] += L; u++; }
                        if (T[i] != 0) for (int x = r2[i]; x < 2 * M; x += p) { sieve[x] += L; u++; }
                    }
                upd += u; R.tSieve += u * C_UPD + np * 2 * C_PRIMEROOT * 1.0 + 2.0 * M * C_CELL;
                BigInteger c = (b * b - kN) / a;
                for (int x = 0; x < 2 * M; x++) if (sieve[x] >= thr)
                    {
                        R.cands++; R.tCand += C_CAND + C_CANDP * F;
                        BigInteger X = x - M; BigInteger Q = BigInteger.Abs((a * X + 2 * b) * X + c);
                        for (int i = 0; i < F && !Q.IsOne; i++) { int p = P[i]; for (; ; ) { BigInteger rem; BigInteger qq = BigInteger.DivRem(Q, p, out rem); if (!rem.IsZero) break; Q = qq; } }
                        if (Q.IsOne) { fulls++; R.full++; }
                        else if (lpMult > 0 && Q < lpMax) { int lp = (int)Q; R.partial++; if (partials.ContainsKey(lp)) combos++; else if (partials.Count < LPSTORE) partials[lp] = 1; }
                    }
                if (fulls + combos >= need) break;
            }
            R.cycles = R.tSieve + R.tPoly + R.tA + R.tCand;
            if (R.cycles > maxCycles) { // extrapolate
                double frac = Math.Max(1, fulls + combos) / (double)need; R.cycles /= frac; R.ok = false; R.rels = fulls + combos; return R;
            }
        }
        R.rels = fulls + combos; R.ok = true;
        return R;
    }
    public static int LPSTORE = 300, QMAX = 256, QMID = 200; static double sAvg;

    static void Main(string[] av)
    {
        InitPrimes();
        int digits = int.Parse(av[0]); int F = int.Parse(av[1]); int M = int.Parse(av[2]); double slack = double.Parse(av[3]); int lp = int.Parse(av[4]); int seed = int.Parse(av[5]); int count = int.Parse(av[6]);
        int smallP = av.Length > 7 ? int.Parse(av[7]) : 20; int qmin = av.Length > 8 ? int.Parse(av[8]) : 60; if (av.Length > 11) { QMAX = int.Parse(av[11]); QMID = int.Parse(av[12]); } if (av.Length > 9) LPSTORE = int.Parse(av[9]);
        double maxSec = av.Length > 10 ? double.Parse(av[10]) : 1e12;
        rnd = new Random(seed);
        List<double> secs = new List<double>(); double ts = 0, tp = 0, ta = 0, tc = 0; double polys = 0, aas = 0, cands = 0, fulls = 0, parts = 0; int pmax = 0; int nok = 0;
        for (int i = 0; i < count; i++)
        {
            BigInteger lo = Sqrt(BigInteger.Pow(10, digits - 1)), hi = Sqrt(BigInteger.Pow(10, digits)); BigInteger p = RandPrime(lo, hi), q = RandPrime(lo, hi); BigInteger N = p * q;
            Result r = Run(N, F, M, slack, lp, smallP, qmin, true, maxSec * 921600);
            secs.Add(r.cycles / 921600); ts += r.tSieve; tp += r.tPoly; ta += r.tA; tc += r.tCand; polys += r.polys; aas += r.aas; cands += r.cands; fulls += r.full; parts += r.partial; pmax = r.pmax; if (r.ok) nok++; sAvg += r.msPerPoly;
        }
        secs.Sort(); double avg = 0; foreach (double d in secs) avg += d; avg /= count; double tot = ts + tp + ta + tc;
        Console.WriteLine("{0}d F={1} M={2} slack={3} lp={4} small={5} q>{6}: avg {7} med {8} max {9}  sieve {10:P0} switch {11:P0} a {12:P0} cand {13:P0}  polys {14:F0} a {15:F0} cands {16:F0} full {17:F0} part {18:F0} pmax {19} ok {20}/{21} s {22:F1} store {23}", digits, F, M, slack, lp, smallP, qmin, T(avg), T(secs[count / 2]), T(secs[count - 1]), ts / tot, tp / tot, ta / tot, tc / tot, polys / count, aas / count, cands / count, fulls / count, parts / count, pmax, nok, count, sAvg / count, LPSTORE);
    }
    static string T(double s) { if (s < 120) return s.ToString("F0") + "s"; if (s < 7200) return (s / 60).ToString("F1") + "m"; if (s < 172800) return (s / 3600).ToString("F1") + "h"; return (s / 86400).ToString("F1") + "d"; }
}
