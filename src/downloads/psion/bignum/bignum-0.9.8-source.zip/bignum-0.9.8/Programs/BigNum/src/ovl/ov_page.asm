; =====================================================================
; OV_PAGE: the pager: the digits (dec.inc: dg_...) a page at a time
; =====================================================================
        include "macros.inc"
        lastent pages

; ---- pages ----------------------------------------------------------------
pages:  ldx  #0
        stx  pg_at
        ldab #20
        tst  kv_four
        bne  .w
        ldab #15
.w:     stab pg_w
.page:  bsr  cls
        ldd  pg_at
        std  pg_i
        clra
        tst  kv_four
        beq  .rows
        bsr  where
        ldaa #1
.rows:  bsr  row
        cmpa kv_h
        bne  .rows
        tst  kv_four
        bne  .k
        ldd  pg_at              ; two lines: the marks
        beq  .m2
        ldab #15
        ldaa #'^'
        bsr  mark
.m2:    bsr  chars
        subd pg_i
        bls  .k
        ldab #31
        ldaa #'v'
        bsr  mark
.k:     bsr  getk
        cmpb #K_DOWN
        beq  .down
        cmpb #K_UP
        beq  .up
        cmpb #'S'
        beq  .s
        cmpb #K_EXE
        beq  .x
        cmpb #K_ON
        beq  .x
        cmpb #K_MODE
        beq  .x
        cmpb #'V'
        bne  .k
        ldaa pg_v               ; (V only for a line's result)
        deca
        bne  .k
        ovjump OV_SHOW,3
.x:     rts
.down:  bsr  size
        ldd  pg_at
        addd zt
        std  zw
        bsr  chars
        subd zw
        bls  .k
        ldd  zw
        bra  .go
.up:    bsr  size
        ldd  pg_at
        beq  .k
        subd zt
.go:    std  pg_at
        bra  .page
.s:     tst  kv_four            ; the place, for a moment (two lines)
        bne  .k
        bsr  cls
        bsr  where
        ldaa #24
.w2:    psha
        os   KB$TEST
        pula
        tstb
        bne  .page
        slp
        deca
        bne  .w2
        bra  .page
; mark: A printed at the screen position B
mark:   psha
        tba
        clrb
        os   DP$STAT
        pula
        bra  emit
; size: zt = the characters a page holds
size:   ldd  #60
        tst  kv_four
        bne  .f
        ldd  #30
.f:     std  zt
        rts
; where: "Digits 1-60 of 617" ("Digits 1-30" / "of 617")
where:  bsr  ln0
        ldd  pg_at              ; (without the word where it would not fit: past 99 of 617, or 60 of 2,467)
        beq  .w
        tst  kv_four
        beq  .w
        subd #99
        bcc  .nw
        bsr  chars
        subd #1000
        bcc  .nw
.w:     bsr  pri
        fcl  "Digits "
.nw:    ldd  pg_at
        addd #1
        bsr  putw
        ldaa #'-'
        bsr  putc
        bsr  size
        ldd  pg_at
        addd zt
        std  zw
        bsr  chars
        subd zw
        bcc  .in
        addd zw
        bra  .p
.in:    ldd  zw
.p:     bsr  putw
        tst  kv_four
        bne  .o
        bsr  out
        bsr  ln1
        bra  .of
.o:     bsr  putsp
.of:    bsr  pri
        fcl  "of "
        bsr  chars
        bra  putwo
        include "row.inc"
        include "dgch.inc"
