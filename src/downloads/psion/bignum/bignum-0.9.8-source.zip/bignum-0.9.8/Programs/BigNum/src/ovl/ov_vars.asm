; =====================================================================
; OV_VARS: the variables and their sizes. Entry 0: the command VARS (EXE shows the one picked). 1: from the
; menu (EXE: its letter goes into the line, RTB_BL).
; =====================================================================
        include "macros.inc"
        entry vars
        lastent pick

vars:   bsr  count
        beq  none
        bsr  list
.k:     cmpb #K_EXE
        bne  .x
        ldab li_i
        bsr  nth
        bsr  get
        ldab li_i
        pshb
        ovsub OV_SHOW,1
        pulb
        stab li_i
        bsr  count
        staa li_n
        bsr  li_go
        bra  .k
.x:     rts
pick:   bsr  count
        beq  none
        bsr  list
        clr  RTB_BL
        cmpb #K_EXE
        bne  .x
        ldab li_i
        bsr  nth
        ldaa 0,x
        cmpa #'@'
        beq  .ans
        staa RTB_BL+1
        ldaa #1
        staa RTB_BL
.x:     rts
.ans:   ldx  #$0341             ; ANS
        stx  RTB_BL
        ldx  #$4E53
        stx  RTB_BL+2
        rts
none:   bsr  cls
        bsr  ln0
        bsr  pri
        fcl  "No variables"
        bsr  out
        clr  RTB_BL
        bra  getk
; count: A = how many variables (Z: none)
count:  ldx  kv_vb
        clra
.l:     cpx  kv_hi
        beq  .x
        inca
        inx
        bsr  next
        bra  .l
.x:     tsta
        rts
next:   psha
        bsr  inext
        pula
        rts
; nth: X = variable B
nth:    ldaa #'A'               ; (in order: A to Z, then ANS)
.l:     psha
        ldx  kv_vb
.f:     cpx  kv_hi
        beq  .no
        cmpa 0,x
        beq  .got
        inx
        pshb
        psha
        bsr  inext
        pula
        pulb
        bra  .f
.got:   decb
        bmi  .x
.no:    pula
        inca
        cmpa #'Z'+1
        bne  .l
        ldaa #'@'
        bra  .l
.x:     pula
        rts
; get: the number of the variable at X pushed
get:    inx
        bra  hcopy
; a line: "A  39 digits"
li_row: bsr  nth
        ldaa 0,x
        cmpa #'@'
        bne  .l
        bsr  get
        bsr  pri
        fcl  "ANS "
        bra  .d
.l:     bsr  putc
        bsr  putsp2
        bsr  get
.d:
        ldx  kv_p
        pshx
        ldaa li_r
        psha
        ovsub OV_DIGS,0
        pula
        staa li_r
        pulx
        stx  kv_p
        bsr  hdrop
        ldd  kv_digs
        bsr  putwp
        fcl  " digit"
        ldd  kv_digs
        subd #1
        beq  .x
        ldaa #'s'
        bsr  putc
.x:     rts
        include "list.inc"
