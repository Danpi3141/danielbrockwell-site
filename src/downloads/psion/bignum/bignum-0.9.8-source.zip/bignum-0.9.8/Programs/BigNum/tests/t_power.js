// Switched off and on again: by itself at the line, by a low battery at the line and in the middle of a run; the work
// goes on to the right result. (The OS writes $F6-$FE when it is switched on.)   node tests/t_power.js [rom ...]
'use strict';
const { BN, ROMS, HZ } = require('./lib');
let bad = 0;
for (const rom of process.argv.length > 2 ? process.argv.slice(2) : Object.keys(ROMS)) {
  const g = new BN(rom), m = g.m; let low = false;
  const r0 = m.bus.read.bind(m.bus); m.bus.read = (a) => { const v = r0(a); return a === 0x15 && low ? v | 1 : v; };
  const fail = (s) => { bad++; console.log(`FAIL ${rom} ${s}: ${g.text().replace(/\n/g, '|')}`); };
  const at = g.start() && g.addr('t_idle');
  const home = () => { for (let i = 0; i < 6 && !g.atLine(); i++) { g.inject('ON'); g.wait(); } };
  const on = () => { low = false; for (let i = 0; i < 4 && !m.isOn(); i++) { m.press('ON', 6, 6); m.runSeconds(1); } };
  const looks = !/^24-/.test(rom);              // (2.4's ROMs do not look at the battery)
  // at the line
  g.wait(); g.line('A=2**100'); g.wait(); home();
  for (const how of looks ? ['low', 'auto'] : ['auto']) {
    const keep = [m.peek(0x7C), m.peekw(0x7D)];
    if (how === 'low') low = true; else { m.poke(0x7C, 1); m.pokew(0x7D, 1); }
    for (let i = 0; i < 40 && m.isOn(); i++) m.runSeconds(0.5);
    if (m.isOn()) fail(how + ': not switched off');
    m.runSeconds(3); on(); m.poke(0x7C, keep[0]); m.pokew(0x7D, keep[1]); home();
    const r = g.line('A-2**99'); if (r.val !== 2n ** 99n) fail(how + ' ' + r.val); g.wait(); home();
  }
  // working
  const n = 2n ** 127n - 1n; const line = `MODEXP(3,2**127-2,2**127-1)+MODEXP(5,2**521-2,2**521-1)+FACT(30)`;
  g.wait(); m.write(g.peekw('kv_line'), [line.length, ...[...line].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', line.length); g.inject('EXE');
  let offs = 0, done = false;
  for (let k = 0; k < 300 && !done; k++) {
    done = m.runTo([at], HZ * 4) === at && !/Paused/.test(g.text()); if (done) break;
    if (offs < 3 && g.peek('kv_run')) { low = true; for (let i = 0; i < 12 && m.isOn(); i++) m.runSeconds(0.5); if (!m.isOn()) { offs++; m.runSeconds(2); } on(); }
    if (/Paused/.test(g.text())) { m.poke(0x76, 67); m.run(HZ); }
  }
  let f = 1n; for (let i = 2n; i <= 30n; i++) f *= i;
  const v = g.vars()['@'];
  if (!done || v !== f + 2n || (looks && !offs)) fail(`running: ${v}, switched off ${offs} times`);
  // just as an overlay is to be read
  home(); g.wait(); const l2 = 'FACTOR((10**6+3)*(10**7+19))+1'; m.write(g.peekw('kv_line'), [l2.length, ...[...l2].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', l2.length); m.poke(0x76, 13);
  let n2 = 0; const ol = g.addr('ov_load');
  for (let k = 0; k < 40; k++) {
    if (m.runTo([ol, at], HZ * 60) !== ol) break;
    if (k % 5 === 4 && looks) { m.poke(0x8C, 0xFF); low = true; for (let i = 0; i < 30 && m.isOn(); i++) m.runSeconds(0.5); if (!m.isOn()) n2++; m.runSeconds(1); on(); }
    else m.run(200);
  }
  for (let i = 0; i < 60; i++) { if (/Paused/.test(g.text())) { m.poke(0x76, 67); m.run(HZ); } if (m.runTo([at], HZ * 5) === at && !/Paused/.test(g.text())) break; }
  if (g.vars()['@'] !== 10n ** 6n + 4n || (looks && !n2)) fail(`reading an overlay: ${g.vars()['@']}, switched off ${n2} times`);
  else if (done && v === f + 2n) console.log(`${rom}: switched off at the line twice, in a run ${offs} times, reading an overlay ${n2} times`);
}
console.log(bad ? `${bad} FAILED` : 't_power ok');
process.exit(bad ? 1 : 0);
