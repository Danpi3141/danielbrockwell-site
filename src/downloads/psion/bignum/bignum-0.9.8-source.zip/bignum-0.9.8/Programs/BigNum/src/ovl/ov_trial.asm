; =====================================================================
; OV_TRIAL: trial division. Entry 0: the top number (positive) divided by every prime up to the setting
; TDIV, each added to the list of factors; what is left stays on top (1, or a number with no small factor;
; kv_pk = 1 if it is sure to be a prime). Entry 1: TRIAL(n, limit): the smallest prime factor up to the
; limit, or 1.
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        include "fa.inc"
        entry trial
        lastent f_trial

tr_l    = kv_fs+20              ; (2) the limit
tr_f    = kv_fs+22              ; 1: TRIAL(): the first one will do
f_trial: bsr  ilenw             ; the limit: 65535 at most
        bmi  tr_arg
        subd #1
        bcs  tr_arg
        beq  .b
        subd #1
        bne  .max
        ldd  2,x
        bra  .l
.b:     ldab 2,x
        clra
        bra  .l
.max:   ldd  #65535
.l:     std  tr_l
        bsr  hdrop
        ldx  kv_wp
        ldd  0,x
        beq  tr_arg
        bmi  tr_arg
        ldaa #1
        staa tr_f
        bsr  run
        bsr  hdrop
        ldd  kv_pf              ; (0: none)
        bne  .v
        incb
.v:     bra  hpush
tr_arg: bra  errarg
trial:  clr  tr_f
        ldd  st_tdiv
        std  tr_l
        ldx  #shook
        bsr  hookx
        bsr  shook
run:    clr  kv_pk
        clra
        clrb
        std  kv_pf
        ldx  kv_wp              ; the window, and the number below it
        pshx
        ldd  #PS_LEN
        bsr  walloc
        stx  ps_buf
        pulx
        bsr  hcopy
        bsr  tdset
        ldd  #2
        bsr  divs
        bne  .odd
        ldd  #2
        bsr  found
        bcs  .out
.odd:   clrb
        ldx  #3
        bsr  ps_go
.l:     bsr  poll
        bsr  ps_next
        tst  ps_p
        bne  .out
        ldd  ps_p+1
        subd tr_l
        bhi  .out
        bsr  sq                 ; p squared past what is left: it is a prime (or 1)
        bcs  .prime
        ldd  ps_p+1
        std  td_p
        bsr  tdiv
        bne  .l
        ldd  ps_p+1
        bsr  found
        bcc  .l
        bra  .out
.prime: inc  kv_pk
        tst  tr_f               ; TRIAL: it may be within the limit itself
        beq  .out
        bsr  ilenw
        subd #2
        bhi  .out
        beq  .w
        ldab 2,x
        clra
        bra  .c
.w:     ldd  2,x
.c:     subd #2
        bcs  .out
        addd #2
        std  kv_al
        subd tr_l
        bhi  .out
        ldd  kv_al
        std  kv_pf
.out:   bsr  i2                 ; over the window and the number it was made from
        ldab #PS_LEN
        abx
        bsr  inext
        bra  hslx
; found: the prime D divides the number: counted, divided out, into the list. Carry set: that is all
found:  std  kv_pf
        tst  tr_f
        beq  .go
        sec
        rts
.go:    ovsub OV_TRF,0
        bsr  tdset
        clc
        rts
; divs: Z if the prime D divides the number
divs:   cmpb #2
        bne  .o
        tsta
        bne  .o
        ldx  td_e
        dex
        ldab 0,x
        andb #1
        rts
.o:     std  td_p
        bra  tdiv
; sq: carry set if ps_p+1 squared is more than the number on top
sq:     bsr  ilenw
        subd #4
        bhi  .no
        ldx  #0                 ; the number as 4 bytes, kv_n
        stx  kv_n
        stx  kv_n+2
        ldx  td_x
        stx  zx
        ldd  td_e
        subd td_x
        beq  .z
        stab zm
        ldab #4
        subb zm
        ldx  #kv_n
        abx
        stx  zp
        ldab zm
        clra
        bsr  cpb
.z:     ldd  ps_p+1
        ldx  ps_p+1
        os   UT$UMUL            ; D:X
        stx  kv_al
        std  kv_se
        ldd  kv_n+2
        subd kv_al
        ldd  kv_n
        sbcb kv_se+1
        sbca kv_se
        rts
.no:    clc
        rts
sh_t:   fcl  "Trial division.."
        include "shook.inc"
        include "tdiv.inc"
        include "psn.inc"
