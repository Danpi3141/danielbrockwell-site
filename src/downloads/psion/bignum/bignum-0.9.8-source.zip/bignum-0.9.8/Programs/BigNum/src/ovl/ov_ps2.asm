; =====================================================================
; OV_PS2: the second stage of P-1 and P+1 (goes on from OV_PM1, its slots and variables): V = V(E) in slot
; 2, 2 in slot 3; every prime q from B1 to 25 B1. With q = v D - u or v D + u, V(q) is 2 where V(vD) = V(u),
; so the product of V(vD) - V(u) over the pairs (v, u) that give a prime is gathered: D = 210 with 24 values
; of u, or 30 with 4. The primes come a window of 2,100 numbers at a time.
; Slots: 0 V(vD), 1 V((v-1)D), 2 V(1), 3 2 (then scratch), 4 V(D), 5 the product, 6 scratch, 7 on V(u).
; =====================================================================
        include "macros.inc"
        include "ckn.inc"
        include "fx.inc"
        include "p2.inc"
        lastent ps2

ps2:    ovsub OV_PS2A,0         ; the table, the start
        ldx  #hook
        bsr  hookx
        ldaa #CK_PS2
        bsr  ckset
        bsr  ps_fill
.win:   bsr  safe
        ldab p2_d
        clra
        std  p2_c
        ldaa #10
        cmpb #105
        beq  .g
        ldaa #70
.g:     staa p2_g
.step:  ldaa #7                 ; the pairs of this step
        staa p2_t
        ldaa #1
        staa p2_u
.p:     bsr  cop
        bne  .np
        ldab p2_u               ; vD + u, vD - u: either prime?
        clra
        addd p2_c
        bsr  isp
        beq  .yes
        ldab p2_u
        clra
        std  zt
        ldd  p2_c
        subd zt
        bsr  isp
        bne  .no
.yes:   clr  mi+1
        ldaa #6
        staa mi
        ldaa p2_t
        staa mi+2
        ldab #M_SUB
        bsr  mop
        bsr  mrun
        mol   M_MUL,5,5,6
.no:    inc  p2_t
.np:    ldaa p2_u
        adda #2
        staa p2_u
        cmpa p2_d
        bls  .p
        bsr  mrun               ; the next step
        mo    M_MUL,6,0,4
        mo    M_SUB,6,6,1
        mo    M_CPY,1,0,0
        mol   M_CPY,0,6,6
        ldab p2_d
        clra
        asld
        addd p2_c
        std  p2_c
        dec  p2_g
        bne  .step
        ldd  ps_lo              ; the end?
        std  kv_done
        ldd  ps_lo+1
        addd #2100
        std  zt
        ldab ps_lo
        adcb #0
        cmpb p2_h
        bhi  .end
        blo  .more
        ldd  zt
        subd p2_h+1
        bhs  .end
.more:  bsr  ps_win
        bra  .win
.end:   ldab #5
        bsr  sgcd
        bsr  kind
        beq  .none
        bcc  .none
        inc  fx_found
        ldx  fx_wp
        bsr  hslx
        bra  hook0
.none:  ldx  fx_wp
        stx  kv_wp
        bra  hook0
hk_l:   bsr  pri
        fcl  "Stage 2  "
        ldd  ps_lo              ; the number reached
        std  kv_n+1
        ldab ps_lo+2
        stab kv_n+3
        clr  kv_n
        bra  putn
hk_q:   ldab pm_f
        bmi  .p
        bsr  pri
        fcl  "P-1 stage 2"
        rts
.p:     bsr  pri
        fcl  "P+1 stage 2"
        rts
        include "cop.inc"
        include "isp.inc"
        include "sgcd.inc"
        include "mhook.inc"
hk_3    = pr_pct
        include "fslot.inc"
        include "psn.inc"
        include "ckset.inc"
        include "cksafe.inc"
