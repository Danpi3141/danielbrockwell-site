; qstd: the relation's entry at X divided out: u u - kN. Calls neg if it is negative, and hit for every prime
; that divides it: B = its place in the base, A = how often. What is left (1, or the large prime) is in qc_n,
; qc_b. u itself (bit 7 of its first byte off) is the ub bytes at q_u+2.
qt_i    = kv_fs+11              ; the prime's place
qt_c    = kv_fs+12              ; how often it has gone
qstd:   stx  zx
        ldd  q_u
        addd #2
        std  ma
        std  zp
        ldab q_ub
        clra
        bsr  cpb
        ldx  ma
        ldaa 0,x
        anda #$7F
        staa 0,x
        bsr  sqkn
        bcc  .p
        bsr  neg
.p:     ldab q_ub
        aslb
        stab qc_n
        ldx  q_v
        inx
        inx
        stx  qc_b
        bsr  trim
        clr  qt_i               ; twos
        clr  qt_c
.two:   ldx  qc_e
        dex
        ldab 0,x
        lsrb
        bcs  .odd
        bsr  half
        inc  qt_c
        bra  .two
.odd:   ldaa qt_c
        beq  .next
        clrb
        bsr  hit
.next:  inc  qt_i
        ldab qt_i
        cmpb q_f
        beq  .x
        ldaa qc_n               ; nothing left: done
        deca
        bne  .go
        ldx  qc_b
        ldaa 0,x
        deca
        beq  .x
.go:    ldx  q_p
        abx
        abx
        ldd  0,x
        std  td_p
        tba
        bsr  inva
        stab td_i
        clr  qt_c
.l:     bsr  divq
        bne  .e
        inc  qt_c
        bra  .l
.e:     ldaa qt_c
        beq  .next
        ldab qt_i
        bsr  hit
        bra  .next
.x:     rts
