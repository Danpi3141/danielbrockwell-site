; =====================================================================
; OV_VSHOW: PROVE's result: the number is in the certificate's first record (kv_rl), or, with no proof, only
; how far it got is shown. C shows the certificate.
; =====================================================================
        include "macros.inc"
        include "pv.inc"
        lastent vshow

vshow:  bsr  cls
        tst  kv_four
        beq  .l1
        bsr  strip
        ldaa #1
        bsr  echo2              ; (without =)
        ldaa #1
        bra  .ln
.l1:    clra
.ln:    bsr  ln
        tst  pv_t
        beq  .none
        ldx  kv_vb
        stx  kv_wp
        ldx  kv_rl
        ldab #CT_N
        abx
        bsr  hcopy
        ldab kv_ln
        pshb
        ovsub OV_DIGS,0
        pula
        bsr  ln
        ldaa #'P'
        bsr  putc
        ldd  kv_digs
        bsr  putw
        tst  kv_four
        bne  .f
        bsr  pri
        fcl  " PROVED "
        bsr  way
        bsr  out
        bra  .c
.f:     bsr  pri
        fcl  "  PROVED  by "
        bsr  way
        bsr  out
        bsr  ln2
        bsr  far
        bsr  out
.c:     ldaa kv_h
        deca
        bsr  lnpri
        fcl  "C=certificate"
        bsr  out
        bra  .keys
.none:  bsr  pri
        fcl  "PRP  no proof"
        bsr  out
        ldaa kv_ln
        inca
        bsr  ln
        clr  pv_s
        ldaa pv_p               ; the better one, if there is one line only
        tst  kv_four
        bne  .n2
        cmpa pv_p+1
        bhs  .n1
        inc  pv_s
.n1:    bsr  far
        bsr  out
        bra  .keys
.n2:    bsr  far
        bsr  out
        ldaa #3
        bsr  ln
        inc  pv_s
        bra  .n1
.keys:  bsr  getk
        cmpb #'C'
        bne  .k
        tst  pv_t
        beq  .keys
        ovsub OV_CSHOW,0
        bra  vshow
.k:     cmpb #K_EXE
        beq  .x
        cmpb #K_ON
        beq  .x
        cmpb #K_MODE
        bne  .keys
.x:     rts
; way: "N-1" or "N+1"; far: "100% of N+1 factored" or "N-1 31% factored"
way:    ldaa pv_t
        cmpa #PT_PLUS
        beq  .p
        bsr  pri
        fcl  "N-1"
        rts
.p:     bsr  pri
        fcl  "N+1"
        rts
far:    tst  pv_t
        beq  .no
        ldaa pv_t
        ldab pv_p
        cmpa #PT_PLUS
        bne  .a
        ldab pv_p+1
.a:     clra
        bsr  putwp
        fcl  "% of "
        bsr  way
        bra  .f
.no:    ldab pv_p
        tst  pv_s
        beq  .m
        bsr  pri
        fcl  "N+1 "
        ldab pv_p+1
        bra  .w
.m:     bsr  pri
        fcl  "N-1 "
        ldab pv_p
.w:     clra
        bsr  putw
        ldaa #'%'
        bsr  putc
.f:     bsr  pri
        fcl  " factored"
        rts
        include "strip.inc"
        include "echo.inc"
