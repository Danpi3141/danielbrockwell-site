; =====================================================================
; OV_POW: the second number to the power of the top one
; =====================================================================
        include "macros.inc"
        lastent power

pw_e    = kv_fs
pw_b    = kv_fs+2
pw_n    = kv_fs+4
; ---- power -------------------------------------------------------------
power:  bsr  ilenw
        bmi  .arg               ; a negative exponent
        bsr  i2
        stx  kv_ia
        bsr  ilen               ; 0, 1 or -1 to a power
        std  zt
        beq  .zero
        subd #1
        bne  .big
        ldab 2,x
        decb
        bne  .big
        ldaa 0,x                ; 1, or -1 (an even exponent makes it 1)
        bpl  .drop
        bsr  ilenw
        std  zt
        beq  .neg
        stx  zx
        addd zx
        xgdx
        ldab 1,x                ; the exponent's lowest byte
        lsrb
        bcs  .drop
.neg:   bsr  hdrop
        bra  hneg
.zero:  ldx  kv_wp              ; 0: 0**0 is 1
        ldd  0,x
        bne  .drop
        bsr  hdrop2
        bra  hpush1
.drop:  bra  hdrop
.arg:   bra  errarg
.over:  bra  errbig
.big:   bsr  ilenw              ; the exponent must be short
        ldx  2,x
        stx  kv_al
        subd #1
        bhi  .two
        beq  .one
        ldx  #0
        stx  kv_al
        bra  .ok
.one:   ldaa #0
        ldab kv_al
        std  kv_al
        bra  .ok
.two:   subd #1
        bne  .over
.ok:    bsr  hdrop              ; e in kv_al
        ldd  kv_al
        std  pw_e
        bne  .e1
        bsr  hdrop              ; to the power 0: 1
        bra  hpush1
.e1:    bsr  ilenw              ; the base's bits, less 1, times e: must be under the cap's bits
        subd #1
        asld
        asld
        asld
        ldx  kv_wp
        ldx  2,x
        stx  zw
.b:     lsr  zw
        beq  .bd
        addd #1
        bra  .b
.bd:    std  pw_b               ; bits - 1
        ldx  pw_e
        os   UT$UMUL            ; D the high word, X the low
        subd #0
        bne  .over
        stx  zt
        ldd  kv_cap
        asld
        asld
        asld
        subd zt
        bls  .over
        bsr  ilenw              ; a power of 2? (the first byte one bit, the rest 0)
        std  zt
        ldab 2,x
        tba
        deca
        stab zw
        anda zw
        bne  .gen
        ldd  zt
.p2:    subd #1
        beq  .sh2
        tst  3,x
        bne  .gen
        inx
        bra  .p2
.sh2:   ldd  pw_b               ; 2 to the power of bits times e
        ldx  pw_e
        os   UT$UMUL
        xgdx
        bra  shl1
; the general way: bits of e from the top
.gen:   bsr  hdup
        ldd  pw_e
        ldx  #16
.t:     asld
        bcs  .go
        dex
        bra  .t
.go:    std  pw_e
        dex
        stx  pw_n
.l:     ldx  pw_n
        beq  .done
        dex
        stx  pw_n
        bsr  ilenw              ; (its square must fit the cap)
        std  zt
        bsr  small2
        bsr  hsqr
        ldd  pw_e
        asld
        std  pw_e
        bcc  .l
        bsr  hover
        bsr  small
        bsr  hmul
        bra  .l
.done:  bra  hnip
; small: the top two numbers' product must fit the cap
small:  bsr  i2
        bsr  ilen
        std  zt
small2: bsr  ilenw
        addd zt
        subd #1
        bls  .x
        subd kv_cap
        bls  .x
        bra  errbig
.x:     rts
; shl1: the top number replaced by 1 with D zeros after it (its sign: as it was, if e is odd)
shl1:   std  zw
        ldx  kv_wp
        ldaa 0,x
        ldab pw_e+1
        lsrb
        bcs  .s
        clra
.s:     anda #$80
        psha
        ldd  zw
        pshb
        lsrd
        lsrd
        lsrd
        addd #1
        std  zw                 ; bytes
        bsr  hdrop
        ldd  zw
        addd #2
        bsr  walloc
        ldd  zw
        std  0,x
        pshx
        inx
        inx
        pshx
        bsr  clrx
        pulx
        pula
        pulb
        std  zt
        pulb
        andb #7
        ldaa #1
.b:     decb
        bmi  .d
        asla
        bra  .b
.d:     staa 0,x
        ldx  zt
        pulb
        orab 0,x
        stab 0,x
        rts
        include "hsqr.inc"
