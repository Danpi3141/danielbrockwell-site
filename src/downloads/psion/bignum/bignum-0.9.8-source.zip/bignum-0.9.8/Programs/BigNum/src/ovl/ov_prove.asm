; =====================================================================
; OV_PROVE: entry 0: PROVE(n): 1 if it is a prime for sure. Entry 1: P on the factors' screen: the first
; probable prime of the list proved, its screen shown, and back to the factors. 2: a proof given up (kv_why).
; 4: P on ISPRIME's screen (the number at kv_rl).
; 5: C there (pv_rec).
; 3: every probable prime of the list proved (the setting PROOF), nothing shown.
; =====================================================================
        include "macros.inc"
        include "fa.inc"
        include "pv.inc"
        entry prove
        entry pkey
        entry given
        entry all
        entry pscr
        lastent ckey

prove:  ovsub OV_PRP,0
        ldaa kv_pk
        cmpa #2
        beq  .go
        ovjump OV_PRP,3         ; settled already: ISPRIME's screen
.go:    clr  pv_all
        ldx  #0                 ; (given up: nothing is left)
        stx  pv_esc
        stx  pv_rl
        ldx  kv_osp
        stx  kv_lim
        bsr  run
        bsr  hdrop
        ldab #1
        tst  pv_t
        bne  .v
        clrb
.v:     clra
        bsr  hpush
        ldaa #OV_VSHOW
        staa kv_rk
        rts
; run: the top number proved (kept): pv_t
run:    ldaa #1
        staa pv_run
        ovsub OV_PRVM,0
        clr  pv_run
        ldx  #0
        stx  kv_esc
        bra  hook0
pscr:   clr  pv_all
        ldx  kv_vb              ; from ISPRIME's screen: the number at kv_rl
        stx  kv_wp
        ldx  #0
        stx  pv_rl
        stx  pv_esc
        ldx  kv_rl
        bsr  hcopy
        ldx  kv_osp
        stx  kv_lim
        bsr  runon
        bsr  run
        clr  kv_run
        ovjump OV_VSHOW,0
; ---- from the factors' screen
pkey:   clr  pv_all
        bsr  save
        sts  pv_esc+2
        bsr  first
        bcs  .back
.go:    bsr  runon
        bsr  number
        bsr  run
        clr  kv_run
        bsr  mark
        ovsub OV_VSHOW,0
.back:  bsr  unsave
        ovjump OV_FSHOW,1
ckey:   clr  pv_all             ; (C: the prime at pv_rec)
        bsr  save
        sts  pv_esc+2
        bra  pkey.go
; stopped in the middle
given:  clr  pv_run
        tst  pv_all             ; (in FACTOR, for PROOF: no more proofs, on with what is known)
        bne  all_x
        clr  kv_run
        ldx  pv_rl
        beq  .main
        bra  pkey_b
.main:  jmp  main
pkey_b: bsr  unsave
        ovjump OV_FSHOW,1
; all: PROOF is on
all:    ldx  kv_wp
        pshx
        ldaa #1
        staa pv_all
.l:     bsr  save
        sts  pv_esc+2
        bsr  first
        bcs  all_x
        bsr  number
        bsr  run
        ldx  pv_rec             ; (not proved: looked at once only: marked for now)
        ldaa #FT_TRIED
        tst  pv_t
        beq  .m
        ldaa #FT_P
.m:     staa 0,x
        bsr  unsave
        pulx
        pshx
        stx  kv_wp
        bra  .l
all_x:  bsr  unsave
        clr  pv_all
        pulx
        stx  kv_wp
        rts
; save: the factors' list kept under the proof's own
save:   ldx  kv_rl
        stx  pv_rl
        ldx  kv_lim
        stx  pv_rl+2
        ldx  kv_osp
        stx  pv_o2
        ldx  kv_lim
        stx  kv_osp
        ldd  #OV_PROVE*256+2
        std  pv_esc
        rts
unsave: ldx  pv_rl
        stx  kv_rl
        ldx  pv_rl+2
        stx  kv_lim
        ldx  pv_o2
        stx  kv_osp
        rts
pv_o2   = kv_fz+16
pv_all  = kv_fz+15             ; 1: PROOF's
; first: the first probable prime of the list: pv_rec; carry set: none
first:  ldx  pv_rl
.f:     cpx  pv_rl+2
        beq  .no
        ldaa 0,x
        cmpa #FT_PRP
        beq  .yes
        bsr  fl_next
        bra  .f
.yes:   stx  pv_rec
        clc
        rts
.no:    sec
        rts
; number: the record's number alone on the stack of numbers
number: ldx  pv_rec
        ldab #FR_N
        abx
        bra  hcopy
; mark: proved: a prime for sure
mark:   tst  pv_t
        beq  .x
        ldx  pv_rec
        ldaa #FT_P
        staa 0,x
.x:     rts
        include "flnext.inc"
