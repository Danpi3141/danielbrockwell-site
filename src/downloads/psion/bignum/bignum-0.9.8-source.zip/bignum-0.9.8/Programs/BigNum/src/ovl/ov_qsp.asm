; =====================================================================
; OV_QSP: a relation kept: u is the q_ub bytes at q_u+2. Entry 0: whole. Entry 1: but for the prime kv_al
; (below q_lp): paired with another that has the same prime, or kept until there is one. Comes back to
; OV_QSV (which is read in again).
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        include "qs.inc"
        entry whole
        lastent part1

qp_o    = kv_fs+13              ; (2) the one found
whole:  bsr  same
        beq  back
        ldx  q_u
        inx
        inx
        ldaa #0
        bsr  keep
        bcs  back
        bra  one
; a partial one: is there another with its prime?
part1:  ldx  q_pa
.f:     cpx  q_pe
        beq  .new
        ldd  0,x
        subd kv_al
        beq  .pair
        ldab q_ub
        addb #2
        abx
        bra  .f
.new:   ldd  q_pa               ; no: kept, if there is room
        subb q_ub
        sbca #0
        subd #2
        std  zp
        bsr  relend
        addb q_ub
        adca #0
        addb q_ub
        adca #0
        subd zp
        bhs  .full
        ldd  zp
        std  q_pa
        ldx  q_pn
        inx
        stx  q_pn
        ldx  q_pa
        bra  .put
; no room: in the place of the one with the largest prime, if this one's is smaller (it pairs more easily)
.full:  ldd  kv_al
        bsr  maxp
        tst  kv_cy
        beq  back
        ldx  zp
.put:   ldd  kv_al
        std  0,x
        inx
        inx
        stx  zp
        ldd  q_u
        addd #2
        std  zx
        ldab q_ub
        clra
        bsr  cpb
        bra  back
.pair:  inx                     ; yes: the two (not if it is the same one over again)
        inx
        stx  qp_o
        ldd  q_u
        addd #2
        std  zx
        bsr  eqx
        beq  back
        ldx  q_u
        inx
        inx
        bsr  same
        beq  back
        ldx  qp_o               ; (the other one out of the way: the partial ones may move)
        stx  zx
        ldx  q_v
        stx  zp
        stx  qp_o
        ldab q_ub
        clra
        bsr  cpb
        ldx  q_u
        inx
        inx
        ldaa #$80               ; (the first of a pair: bit 7 of its first byte)
        bsr  keep
        bcs  back
        ldx  qp_o
        clra
        bsr  keep
        bcc  one
        ldx  q_rn               ; (no room for the second: the first off again)
        dex
        stx  q_rn
        bra  back
one:    ldx  q_nr
        inx
        stx  q_nr
        cpx  #8                 ; (until there are a few the time is OV_QEST's)
        blo  back
        bsr  share
        std  kv_done
back:   ldaa #OV_QSV            ; OV_QSV again (whoever called it goes on there)
        bra  ov_load
        include "share.inc"
; maxp: zp = the partial relation with the largest prime past D (kv_cy: 0 if there is none; then zp is the newest)
maxp:   std  kv_se
        ldx  q_pa
        stx  zp
        clr  kv_cy
.m:     cpx  q_pe
        beq  .x
        ldd  0,x
        subd kv_se
        bls  .n
        ldd  0,x
        std  kv_se
        stx  zp
        ldaa #1
        staa kv_cy
.n:     ldab q_ub
        addb #2
        abx
        bra  .m
.x:     rts
; relend: D = the end of the relations
relend: ldaa q_rn+1
        ldab q_ub
        mul
        std  zt
        ldaa q_rn
        ldab q_ub
        mul
        tba
        clrb
        addd zt
        addd q_rel
        rts
; keep: the entry at X added, with A set in its first byte: carry set: no room
keep:   psha
        stx  zx
        bsr  relend
        std  zp
        addb q_ub
        adca #0
        subd q_pa
        bls  .ok
        ldd  q_pn               ; the partial one with the largest prime gives way
        beq  .no
        subd #1
        std  q_pn
        ldx  zx
        pshx
        clra
        clrb
        bsr  maxp
        ldd  q_pa               ; (the newest one into its place)
        std  zx
        addb q_ub
        adca #0
        addd #2
        std  q_pa
        ldab q_ub
        addb #2
        clra
        bsr  cpb
        pulx
        pula
        bra  keep
.no:    pula
        sec
        rts
.ok:    ldx  zp
        pshx
        ldab q_ub
        clra
        bsr  cpb
        pulx
        pula
        oraa 0,x
        staa 0,x
        ldx  q_rn
        inx
        stx  q_rn
        clc
        rts
; same: Z if u is among the relations already
same:   bsr  relend
        std  ze
        ldx  q_rel
.l:     cpx  ze
        beq  .no
        stx  zp
        ldd  q_u
        addd #2
        std  zx
        bsr  eqx
        beq  .x
        ldx  zp
        ldab q_ub
        abx
        bra  .l
.no:    ldaa #1
.x:     rts
; eqx: Z if the ub bytes at X and at zx are the same (bit 7 of the first left out)
eqx:    stx  zt
        ldab q_ub
        ldaa 0,x
        ldx  zx
        eora 0,x
        anda #$7F
        bne  .x
.l:     ldx  zt
        ldaa 0,x
        inx
        stx  zt
        ldx  zx
        eora 0,x
        inx
        stx  zx
        anda #$7F
        bne  .x
        decb
        bne  .l
.x:     rts
