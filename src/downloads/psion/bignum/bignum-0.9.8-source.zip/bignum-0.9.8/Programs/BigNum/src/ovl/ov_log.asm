; =====================================================================
; OV_LOG: the result of a line added to the log (BIGLOG on the device of the setting LOG): the line, the value
; or the factors (each with the method that found it), or how it was proved, and the time. The number on top of
; the stack is kept. Carry set: an error (shown).
; =====================================================================
        include "macros.inc"
        include "pv.inc"
        lastent log

log:    sts  lg_sp
        ldx  kv_wp
        stx  lg_w
        ldd  #256
        bsr  walloc
        stx  lg_b
        clr  0,x
        ldaa st_log
        adda #'A'-1
        staa name+1
        cmpa #'A'               ; on A: memory made for it
        bne  .o
        ldx  lg_w               ; (three digits a byte, and some)
        bsr  ilen
        addd kv_lim
        subd kv_lo
        std  zt
        asld
        addd zt
        addd #400
        bsr  aroom
        bcc  .o
        ldab #254               ; OUT OF MEMORY
.err:   bra  lg_err
.o:     ldx  #name
        os   FL$OPEN
        bcc  .rt
        ldx  #name
        os   FL$CRET
        bcs  .err
.rt:    tab
        os   FL$RECT
        ldx  kv_line            ; the line
        bsr  ltx
        bsr  flush
        ldaa kv_rk
        cmpa #OV_FSHOW
        beq  .fac
        cmpa #OV_PSHOW
        beq  .prp
        ldx  lg_w
        bsr  hcopy
        ldaa #'='
        bsr  lch
        bsr  digs
        bsr  flush
        ldaa kv_rk
        cmpa #OV_VSHOW
        bne  .time
        tst  pv_t
        beq  .time
        ovsub OV_LOGC,0         ; a certificate
        bra  .time
.fac:   bsr  facs
        bra  .time
.prp:   ldx  #not
        ldaa kv_pk
        beq  .pt
        ldx  #prv
        deca
        beq  .pt
        ldx  #tprb
.pt:    bsr  ltx
        bsr  flush
.time:  bsr  lnew
        bsr  pri
        fcl  "time "
        ldd  kv_el
        std  kv_n
        ldd  kv_el+2
        std  kv_n+2
        bsr  putt
        bsr  llb
        bsr  flush
        bra  lg_x
; facs: the factors, a record each
facs:   ldx  kv_rl
.l:     cpx  kv_lim
        beq  .x
        stx  lg_r
        ldab #FR_N
        abx
        bsr  hcopy
        bsr  digs0
        bsr  lnew
        ldx  lg_r
        ldab 0,x
        ldx  #lbl
        abx
        abx
        abx
        ldab #3
.lb:    ldaa 0,x
        cmpa #32
        beq  .ld
        bsr  putc
        inx
        decb
        bne  .lb
.ld:    ldd  dg_n
        bsr  putw
        bsr  putsp
        bsr  llb
        bsr  digs1
        bsr  lnew
        ldx  lg_r               ; its power after it
        ldd  FR_E,x
        subd #1
        beq  .e1
        ldaa #'^'
        bsr  putc
        ldx  lg_r
        ldd  FR_E,x
        bsr  putw
        bsr  llb                ; (with the method it can be too long for a line of 16)
        bsr  lnew
.e1:    bsr  putsp
        ldx  lg_r
        ldab FR_M,x
        bsr  method
        ldx  lg_r
        ldd  FR_S,x
        beq  .s0
        bsr  pri
        fcl  " s="
        ldx  lg_r
        ldd  FR_S,x
        bsr  putw
.s0:    bsr  llb
        bsr  flush
        ldx  lg_b               ; (the buffer is the last thing taken: the digits go)
        stx  kv_wp
        ldx  lg_r
        bsr  fl_next
        bra  .l
.x:     rts
name:   fcl  "A:BIGLOG"
not:    fcl  "not prime"
prv:    fcl  "prime (proven)"
tprb:   fcl  "probable prime"
lbl:    fcc  "U  P  PRPC  C  C  PRP"
        include "lg.inc"
        include "flnext.inc"
        include "method.inc"
        include "dec.inc"
        include "aroom.inc"
