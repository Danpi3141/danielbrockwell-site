; =====================================================================
; OV_MSET: Montgomery work set up: entry 0: for the modulus at ms_x (an item, odd) with ms_b slots; then 1
; in slot ms_o and R squared in slot ms_r (each $FF: not wanted). Entry 1: only the slots ms_o, ms_r.
; =====================================================================
        include "macros.inc"
        entry set
        lastent set1

set:    ldx  ms_x
        ldab ms_b
        bsr  mctx
set1:   ldab ms_o
        bmi  .r
        bsr  mone
.r:     ldab ms_r
        bmi  .x
        bsr  mone
        ldab ms_r
        bra  mr2s
.x:     rts
; Montgomery work. mctx: X = the modulus (an item, odd, that stays where it is), B = how many slots: room
; for them and the product taken off the top of the stack of numbers.
; The slots hold numbers of mn bytes less than the modulus, times R = 256 to the mn.
mctx:   pshb
        bsr  ilen
        std  mn
        inx
        inx
        stx  mnp
        addd mnp
        std  mne
        pulb                    ; B slots and 2 for the product, and a byte
        addb #2
        pshb
        ldaa mn+1
        mul
        std  zt
        pulb
        ldaa mn
        mul
        tba
        clrb
        addd zt
        addd #1
        bsr  walloc
        inx
        stx  mp
        ldd  mn
        asld
        addd mp
        std  ms
; mkinv: mk = -1/N modulo 256 (N odd)
mkinv:  ldx  mne
        dex
        ldaa 0,x
        staa zm                 ; x = N (right to 3 bits)
        bsr  .s
        bsr  .s
        nega
        staa mk
        rts
.s:     psha                    ; x = x (2 - N x)
        ldab zm
        mul
        negb
        addb #2
        pula
        mul
        tba
        rts
; mone: slot B = R modulo N, which is 1: from the power of 2 just under N, doubled up to R
mone:   bsr  mslot
        std  kv_se              ; its place
        xgdx
        bsr  clrxn
        ldx  mnp
        ldab 0,x
        ldaa #8+1               ; the doublings: 8 less the bits of N's top byte, and 1
.b:     deca
        lsrb
        bne  .b
        psha
        ldab #128               ; (the top bit of N's top byte)
        deca
.b2:    beq  .p
        lsrb
        deca
        bra  .b2
.p:     ldx  kv_se
        stab 0,x
        pula
.d:     psha
        bsr  .dbl
        pula
        deca
        bne  .d
        rts
.dbl:   ldd  kv_se
        std  ma
        std  mb
        std  mrs
        bra  op_add
; mr2: slot B = R squared modulo N (2 to the 8 mn, as 1 is R): from slot B = 1 (mone done)
mr2s:   stab mi
        stab mi+1
        stab mi+2
        ldd  mn
        asld
        asld
        asld
        ldx  #16
.t:     dex
        asld
        bcc  .t
        std  kv_al
        ldab #M_ADD             ; 2
        bsr  .op
.l:     cpx  #0
        beq  .x
        dex
        ldab #M_SQR
        bsr  .op
        asl  kv_al+1
        rol  kv_al
        bcc  .l
        ldab #M_ADD
        bsr  .op
        bra  .l
.op:    pshx
        ldaa kv_al
        psha
        ldaa kv_al+1
        psha
        bsr  mop
        pula
        staa kv_al+1
        pula
        staa kv_al
        pulx
.x:     rts
