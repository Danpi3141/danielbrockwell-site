; cyc: the time of a modular square (A = 0) or product (A not 0) of mn bytes, in units of 256 cycles
; (1/3600 s), or of 1024 (1/900 s) if mn is over 255: kv_n
cyc:    psha
        ldd  mn
        std  kv_al
        ldx  mn                 ; n squared
        os   UT$UMUL            ; D the high word, X the low
        std  kv_n
        stx  kv_n+2
        pula
        tsta
        beq  .sq
        ldx  #57
        ldd  #230
        bra  .f
.sq:    ldx  #43
        ldd  #380
.f:     std  kv_se
        stx  kv_na
        ldd  #1
        std  kv_nb
        bsr  muldv_
        ldd  kv_al
        ldx  kv_se
        os   UT$UMUL
        stx  kv_al
        addd kv_n
        std  kv_n
        ldd  kv_n+2
        addd kv_al
        std  kv_n+2
        bcc  .c
        ldx  kv_n
        inx
        stx  kv_n
.c:     ldd  #1
        std  kv_na
        ldd  #256
        tst  mn
        beq  .q
        ldd  #1024
.q:     std  kv_nb
        bra  muldv_
; secs: kv_n (from cyc) x D = kv_n seconds
secs:   std  kv_na
        ldd  st_ups
        tst  mn
        beq  .q
        lsrd
        lsrd
.q:     std  kv_nb
        bra  muldv_
        include "mdiv.inc"
