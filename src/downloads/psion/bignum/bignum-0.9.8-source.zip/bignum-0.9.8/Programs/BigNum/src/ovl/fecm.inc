; ecm: how far ECM got with the composite record at kv_ia: its highest level and the curves there
ecm:    ldx  kv_ia
        ldaa 0,x
        cmpa #FT_GAVE
        bne  .x
        ldab #FR_W+12
        abx
        ldaa #4
.l:     ldab 0,x
        orab 1,x
        bne  .got
        dex
        dex
        deca
        bne  .l
.x:     rts
.got:   psha
        pshx
        bsr  pri
        fcl  " ECM L"
        pulx
        pula
        adda #'0'
        bsr  putc
        bsr  putsp
        ldd  0,x
        bra  putw
