; strip: X, B = the line typed; if it is all one function, NAME(...), only what is in its brackets
strip:  ldx  kv_line
        ldab 0,x
        inx
        stab zt
        stab zm
        stx  zx
        clr  zt+1               ; brackets open
.l:     tst  zm
        beq  .no
        ldaa 0,x
        inx
        dec  zm
        cmpa #'('
        beq  .go
        cmpa #'A'
        bhs  .l
.no:    ldx  zx
        ldab zt
        rts
.go:    stx  zp                 ; what is inside
        ldab zm
        stab zw
        inc  zt+1
.m:     tst  zm
        beq  .no
        ldaa 0,x
        inx
        dec  zm
        cmpa #'('
        bne  .c
        inc  zt+1
.c:     cmpa #')'
        bne  .m
        dec  zt+1
        bne  .m
        tst  zm                 ; its own bracket: must be the last character
        bne  .no
        ldx  zp
        ldab zw
        decb
        rts
