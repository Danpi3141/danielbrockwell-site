// The short list on a ROM (or all 29): node tests/t_short.js [rom]
'use strict';
const { BN, ROMS, HZ } = require('./lib');
const { execFileSync, spawn } = require('child_process');
const arg = process.argv[2];
if (!arg) {
  const q = Object.keys(ROMS); let bad = 0, run = 0; const out = {};
  const next = () => { const r = q.shift(); if (!r) { if (!run) { console.log(Object.values(out).join('')); console.log(bad ? `${bad} ROMs FAILED` : `t_short: all ${Object.keys(ROMS).length} ROMs ok`); process.exit(bad ? 1 : 0); } return; }
    run++; const p = spawn(process.execPath, [__filename, r]); let s = ''; p.stdout.on('data', (d) => s += d); p.stderr.on('data', (d) => s += d); p.on('close', (c) => { run--; if (c) { bad++; } out[r] = s; next(); }); };
  for (let i = 0; i < 12; i++) next();
  return;
}
const g = new BN(arg).start(), small = g.peek('kv_tier') === 4, m = g.m;
let bad = 0, n = 0; const fail = (s) => { console.log(`${arg} FAIL ${s}`); bad++; };
const fact = (k) => { let r = 1n; for (let i = 2n; i <= k; i++) r *= i; return r; };
const val = (l, v) => { n++; const r = g.line(l, 1e6); if (r.err || r.val !== v) fail(`${l}: ${r.err} ${r.val}`); return r; };
const err = (l, e) => { n++; const r = g.line(l, 1e6); if (r.err !== e) fail(`${l}: error ${r.err}, not ${e} (${r.val})`); };
const factors = (l, f) => { n++; const r = g.line(l, 1e6); const got = []; let a = g.peekw('kv_rl'); const e = g.peekw('kv_lim'); while (a < e) { const k = m.peekw(a + 1); const v = g.item(a + 20); got.push(k > 1 ? `${v}^${k}` : `${v}`); a += 22 + (m.peekw(a + 20) & 0x7fff); } if (r.err || got.join(' ') !== f) fail(`${l}: ${r.err} ${got.join(' ')}`); };
val('2**127-1', (1n << 127n) - 1n); val('-7/2', -4n); val('-7%2', 1n); val('2**3**2', 512n); val('-2**2', -4n); val('(1+2)*3-4', 5n); val('FACT(25)', fact(25n)); val('SQRT(10**40)', 10n ** 20n); val('NROOT(10**42,3)', 10n ** 14n);
val('GCD(2**60-1,2**40-1)', (1n << 20n) - 1n); val('LCM(12,18)', 36n); val('MODEXP(3,1000,10**9+7)', 56888193n); val('MODINV(3,11)', 4n); val('CRT(2,3,3,5)', 8n); val('JACOBI(5,21)', 1n); val('MODSQRT(2,7)', g.line('MODSQRT(2,7)').val === 3n ? 3n : 4n);
val('FIB(200)', 280571172992510140037611932413038677189525n); val('LUC(50)', 28143753123n); val('PRIMORIAL(30)', 6469693230n); val('BINOM(40,20)', 137846528820n); val('SIZE(2**100)', 31n); val('ABS(-5)', 5n);
for (const c of [3215031751n, 3825123056546413051n, 2047n, 3277n, 4033n, 4681n, 8321n, 561n, 1105n, 1729n]) val(`ISPRIME(${c})`, 0n);
val('ISPRIME(2**61-1)', 1n); val('NEXTPRIME(10**20)', 100000000000000000039n); val('PREVPRIME(100)', 97n); val('LLT(127)', 1n); val('LLT(131)', 0n);
factors('FACTOR(2**64+1)', '274177 67280421310721'); factors('FACTOR(FACT(25)+1)', '401 38681321803817920159601'); factors('FACTOR(7**40)', '7^40'); factors('FACTOR(FACT(20))', '2^18 3^8 5^4 7^2 11 13 17 19'); factors('FACTOR((10**9+7)**2)', '1000000007^2');
val('PHI(360)', 96n); val('TAU(360)', 24n); val('SIGMA(360)', 1170n); val('RHO(10007*(10**12+39))', 10007n); val('TRIAL(91,100)', 7n); val('PM1(4295098369)', 1n); val('FACTOR(1)', 1n);
val('PROVE(2**89-1)', 1n);
val('A=12345', 12345n); val('A*A', 152399025n); val('ANS+1', 152399026n);
err('1/0', 3); err('MODINV(2,4)', 4); err('FACT(-1)', 5); err('1+', 1); err('Z', 8); err('FOO(1)', 1); err(small ? '2**2048' : '2**8192', 2); err('FACTOR(0)', 5); err('FACTOR(-12)', 5); err('SET FOO 1', 1);
val(small ? '2**2047' : '2**8191', 1n << (small ? 2047n : 8191n));
if (small) { for (const l of ['QS(2**64+1)', 'SAVE A,"X"', 'LOAD A,"X"', 'RESUME', 'LOG']) err(l, 6); } else { n++; const qv = g.line('QS(10007*(10**12+39))').val; if (qv !== 10007n && qv !== 10n ** 12n + 39n) fail('QS ' + qv); n++; const r = g.line('A=2**200'); g.line('SAVE A,"NUM"'); g.line('LOAD B,"NUM"'); if (g.vars().B !== 1n << 200n) fail('SAVE, LOAD'); val('B-A', 0n); err('QS(2**190+1)', 6); }
// leaving gives the memory back
const f0 = g.free0; g.inject('ON'); for (let i = 0; i < 5 && !g.atLine(); i++) { g.inject('ON'); g.wait(); } g.line('CLR'); g.inject('ON'); g.inject('Y'); g.run(2);
const files = small ? 0 : 1; if (Math.abs(g.free() - f0) > 200 && g.m.peekw(0xA5) < 0x3000) fail(`free ${g.free()} was ${f0}`);
console.log(`${arg} tier ${small ? 4 : g.peek('kv_tier')} ${n} checks ${bad ? bad + ' FAILED' : 'ok'}, free ${f0} then ${g.free()}`);
process.exit(bad ? 1 : 0);
