; what the ECM overlays share
mx_e    = kv_fs                 ; an exponent's item
ec_i    = kv_fs+2               ; the ladder's bit
ec_sw   = kv_fs+4               ; R0 and R1 are changed over
ec_s    = kv_fs+5               ; the values of u kept by the second stage: 24 or 4
ec_al   = kv_fs+6               ; (2) a prime power
ec_w    = kv_fs+8               ; (2) the stack of numbers below the sieve's window
ec_st   = kv_fs+10              ; the stage (1, 2)
