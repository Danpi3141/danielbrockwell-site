; =====================================================================
; OV_PM1: P-1 (entry 0) and P+1 (entry 1) on the number at fx_n, first stage to fx_lim, then OV_PS2's
; second stage: fx_found = 1 and the factor on top of the stack of numbers, or 0.
; Both are Lucas sequences: V(E) from V(1) = A, where E is the product of the prime powers up to B1. With
; A = 10/3 = 3 + 1/3 every prime is a P-1 prime (to the base 3); with A = 2/7 (Williams's) it is P+1 for
; the p that are 2 modulo 3.
; =====================================================================
        include "macros.inc"
        include "ckn.inc"
        include "fx.inc"
        entry pm1
        lastent pp1

        include "pm1.inc"
pp1:    ldd  #$0702
        ldx  #$8000
        bra  pm_go
pm1:    ldd  #$030A
        ldx  #0
pm_go:  std  pm_d
        stx  pm_f
        ldaa #1
        tst  pm_f
        beq  .m
        inca
.m:     staa fx_m
        ldd  kv_wp
        std  fx_wp
        clr  fx_found
        ovsub OV_PM1A,0         ; the room, the start (carry set: a factor came up)
        bcs  .fnd2
        pshb
        ldx  #hook
        bsr  hookx
        pulb
        tstb                    ; (RESUME: B = 1 in this stage, 2 in the second)
        beq  .new
        decb
        beq  .res
        ovjump OV_PS2,0
.res:
        ldd  ps_p+1             ; from the next odd number on
        addd #2
        orab #1
        xgdx
        clrb
        bsr  ps_go
        bra  .more
.new:   clrb
        ldx  #3
        stx  ps_p+1
        bsr  ps_go
        ldd  #2
        bra  .first
.more:  bsr  safe
        bsr  hpush1             ; a chunk of the exponent
.c:     bsr  ps_next
        tst  ps_p
        bne  .last
        ldd  ps_p+1
        std  kv_done
        subd fx_lim
        bhi  .last
        bsr  powr
        bsr  ilenw              ; long enough?
        subd #24
        bcs  .c
        bsr  ladder
        bra  .more
.first: std  ps_p+1
        bsr  hpush1
        bsr  powr
        bra  .c
.last:  bsr  ladder
        ldd  fx_lim
        std  kv_done
; the first stage's GCD: V - 2
        bsr  mrun
        mol   M_SUB,0,2,3
        clrb
        bsr  sgcd
        bsr  kind
        beq  .s2
        bcs  .fnd
        bra  .none
.s2:    bsr  hdrop
        ldab pm_s               ; the second stage, if there is room for it
        beq  .none
        ovjump OV_PS2,0
.fnd:   inc  fx_found
.fnd2:   ldx  fx_wp
        bsr  hslx
        bra  hook0
.none:  ldx  fx_wp
        stx  kv_wp
        bra  hook0

; powr: the prime ps_p+1 times itself while it is within B1, into the exponent
powr:   ldx  ps_p+1
        stx  kv_al
.l:     ldd  kv_al
        ldx  ps_p+1
        os   UT$UMUL
        subd #0
        bne  .x
        xgdx
        std  kv_se
        subd fx_lim
        bhi  .x
        ldd  kv_se
        std  kv_al
        bra  .l
.x:     ldx  #0
        stx  kv_na
        ldd  kv_al
        bra  hmuladd
; ladder: slot 2 = V(the exponent on top, dropped) of slot 2; slots 0, 1 work
ladder: ldx  kv_wp
        stx  mx_e
        bsr  mrun
        mo    M_CPY,0,3,3
        mol   M_CPY,1,2,2
        ldx  mx_e
        bsr  ibits
        std  pm_i
.l:     ldd  pm_i
        beq  .d
        subd #1
        std  pm_i
        bsr  ebit
        beq  .z
        bsr  mrun               ; a 1
        mo    M_MUL,0,0,1
        mo    M_SUB,0,0,2
        mo    M_SQR,1,1,1
        mol   M_SUB,1,1,3
        bra  .l
.z:     bsr  mrun
        mo    M_MUL,1,0,1
        mo    M_SUB,1,1,2
        mo    M_SQR,0,0,0
        mol   M_SUB,0,0,3
        bra  .l
.d:     bsr  mrun
        mol   M_CPY,2,0,0
        bra  hdrop

hk_l:   bsr  pri
        fcl  "Stage 1  "
        ldd  kv_done
        bra  putw
hk_q:   bsr  hkname
        bsr  pri
        fcl  "stage 1"
        rts
hkname: ldab pm_f
        bmi  .p
        bsr  pri
        fcl  "P-1 "
        rts
.p:     bsr  pri
        fcl  "P+1 "
        rts
        include "sgcd.inc"
        include "mhook.inc"
hk_3    = pr_pct
        include "mslot.inc"
        include "ibits.inc"
        include "ebit.inc"
        include "psn.inc"
        include "cksafe.inc"
