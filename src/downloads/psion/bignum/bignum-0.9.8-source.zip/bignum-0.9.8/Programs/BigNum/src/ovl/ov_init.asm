; =====================================================================
; OV_INIT: the start: the tier, the rows' code, the buffers at the top of the block, the settings.
; =====================================================================
        include "macros.inc"
        entry init
        lastent rows

init:   ldx  #tiers             ; the tier from the block's size
        ldd  kv_hi
        subd kv_lo
        std  zt
        ldd  kv_slz             ; (with the short slot it is the smallest, whatever is free)
        subd #OV_SIZE
        bcc  .t1
        ldx  #tiers4
        ldaa #4
        bra  .got
.t1:    ldaa #1
.t:     psha
        ldd  zt
        subd 0,x
        pula
        bcc  .got
        inca
        ldab #T_LEN
        abx
        cmpa #4
        bne  .t
.got:   staa kv_tier
        ldd  2,x
        std  kv_cap0
        ldab 4,x
        stab kv_wm
        ldab 5,x
        stab kv_lmax
        ldaa kv_tier            ; the smallest tier: the rows' code lies in the OS's buffer for files, which is free
        cmpa #4                 ; between file calls (there are none but for the settings), the line in the
        bne  .big               ; bootstrap's place
        bsr  rows
        ldd  kv_boot
        std  kv_line
        ldd  kv_hi
        std  kv_vb
        bra  .b
.big:   pshx
        bsr  rowgen
        pulx
.l:     ldd  kv_hi              ; the line
        subb kv_lmax
        sbca #0
        subd #1
        std  kv_line
        subd 6,x                ; the lines kept
        std  kv_rec
        std  kv_hi
        ldd  6,x
        std  kv_recn
        ldd  kv_hi
        std  kv_vb
.b:     ldx  kv_line
        clr  0,x
        ldaa kv_tier
        cmpa #4
        beq  .np
        ldx  #kv_prg            ; OV_PROG read in for good (this overlay is still in the slot)
        stx  kv_slt
        ldaa #OV_PROG
        bsr  ov_load
        ldx  #ov_slot
        stx  kv_slt
        ldaa #OV_INIT
        staa kv_res
.np:    ovjump OV_SETF,0        ; the settings

; rows: the smallest tier's rows made in the OS's buffer
rows:   ldx  kv_hi
        pshx
        ldx  #RTT_BF+256
        stx  kv_hi
        bsr  rowgen
        pulx
        stx  kv_hi
        rts
; the block at least (the rows and the line come out of it: about 1,500), cap (bytes), the rows' width, the longest line, room for lines kept
T_LEN   = 8
tiers:  fdb  12000,1024           ; (a sieve of about 200 primes at 184 bits)
        fcb  24,254
        fdb  600
        fdb  7800,1024           ; (a primality test of 8,192 bits)
        fcb  24,254
        fdb  400
        fdb  5900,256            ; (a sieve of 64 primes at 152 bits)
        fcb  24,254
        fdb  400
tiers4: fdb  0,256
        fcb  8,128
        fdb  0

        include "rowgen.inc"
