; =====================================================================
; OV_PHI: PHI(n), TAU(n), SIGMA(n), from the factors of n
; =====================================================================
        include "macros.inc"
        include "fa.inc"
        entry phi
        entry tau
        lastent sigma

ph_f    = kv_fx                 ; 0 PHI, 1 TAU, 2 SIGMA
ph_r    = kv_fx+1               ; (2) the record
phi:    clrb
        bra  go
tau:    ldab #1
        bra  go
sigma:  ldab #2
go:     pshb
        ldx  kv_wp
        ldd  0,x
        beq  .arg
        bmi  .arg
        ovsub OV_FACT,2
        pulb
        stab ph_f
        ldx  kv_rl              ; not all factored (given up): the factors found, and back to the line
.c:     cpx  kv_lim
        beq  .all
        ldaa 0,x
        deca
        cmpa #1
        bhi  .part
        bsr  fl_next
        bra  .c
.arg:   bra  errarg
.part:  clr  kv_run
        ovsub OV_FSHOW,0
        jmp  main
.all:   bsr  hdrop
        bsr  hpush1
        ldx  kv_rl
.l:     stx  ph_r
        cpx  kv_lim
        beq  .x
        ldaa ph_f
        deca
        beq  .tau
        bmi  .phi
        bsr  p                  ; (p**(e+1) - 1) / (p - 1)
        bsr  e
        addd #1
        bsr  pow
        bsr  less1
        bsr  p
        bsr  less1
        ovsub OV_DIV,0
        bsr  hmul
        bra  .n
.tau:   bsr  e                  ; e + 1
        addd #1
        bsr  hpush
        bsr  hmul
        bra  .n
.phi:   bsr  p                  ; p**(e-1) (p - 1)
        bsr  e
        subd #1
        bsr  pow
        bsr  hmul
        bsr  p
        bsr  less1
        bsr  hmul
.n:     ldx  ph_r
        bsr  fl_next
        bra  .l
.x:     ldx  kv_osp             ; (the list is done with)
        stx  kv_lim
        rts
p:      ldx  ph_r
        ldab #FR_N
        abx
        bra  hcopy
e:      ldx  ph_r
        ldd  FR_E,x
        rts
pow:    bsr  hpush
        ovsub OV_POW,0
        rts
less1:  bsr  hpush1
        bra  hsub
        include "flnext.inc"
