; =====================================================================
; OV_CKL: the kept run read back (RESUME: bit 7 of kv_ckd). Entry 0: the method kv_ckm's state, if it is the one in
; the file and for the same number: carry set, and nothing more is looked for. 1: FACTOR's list, for the number on
; top: carry set. 2: the sieve: B = its primes in the file (0: not
; there), q_bs = the primes in an a. 3: as 0, but the rest is still looked for.
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        include "fa.inc"
        include "qs.inc"
FR_N    = 20
        entry meth
        entry fact
        entry qsf
        entry peek
        lastent isit

meth:   bsr  get
        bcc  .no
        clr  kv_ckd
        ldaa #1
        staa kv_ckw
        sec
.no:    rts
peek:   bra  get
; get: the state of kv_ckm, if it is there: carry set
get:    bsr  open
        bcs  .no
        clr  ck_n
.r:     bsr  next
        bcs  .no
        cmpa #'S'
        beq  .s
        tst  ck_n
        beq  .r                 ; (not there yet)
        cmpa #'R'
        beq  .rr
        cmpa #'E'
        beq  .e
        bra  .r
.s:     tst  ck_n               ; its first record: is it the one?
        bne  .s2
        bsr  mine
        bne  .no
.s2:    ldx  #st                ; kept, to be put where it belongs
        ldab ck_n
        abx
        bsr  copy
        ldab ck_n
        addb ck_c
        stab ck_n
        bra  .r
.rr:    tst  ck_d               ; the big numbers
        bne  .r2
        inc  ck_d
        bsr  ck_tab
        bsr  ck_reg
        ldx  zx
        stx  ck_a
.r2:    ldx  ck_a
        bsr  copy
        ldx  zp
        stx  ck_a
        bra  .r
.no:    clc
        rts
.e:     ldd  st+3               ; all there: the variables
        std  kv_el
        ldd  st+5
        std  kv_el+2
        bsr  ck_tab
        ldd  #st+7
        std  zx
        inx
        inx
        inx
        inx
.v:     ldd  0,x
        beq  .q
        std  zp
        ldab 2,x
        inx
        inx
        inx
        pshx
        clra
        bsr  cpb
        pulx
        bra  .v
.q:     ldaa kv_ckm             ; the sieve: its relations
        cmpa #CK_QS
        bne  .yes
        bsr  rels
.yes:   ldd  kv_est             ; the part began when it would have, by its estimate: for the time left
        std  kv_n
        ldd  kv_est+2
        std  kv_n+2
        ldd  kv_done
        std  kv_na
        ldd  kv_tot
        std  kv_nb
        bsr  muldiv
        ldd  kv_el+2
        subd kv_n+2
        std  kv_e0+2
        ldd  kv_el
        sbcb kv_n+1
        sbca kv_n
        std  kv_e0
        sec
        rts
; rels: the relations and the partial ones
rels:   clra
        clrb
        std  q_rn
        std  q_nr
        std  q_pn
        ldx  q_rel
        stx  ck_a
.r:     bsr  next
        bcs  .e
        cmpa #'Q'
        beq  .q
        cmpa #'P'
        bne  .r
        ldd  q_pa               ; a partial one: is there room?
        subb ck_c
        sbca #0
        std  ck_t
        subd ck_a
        bcs  .r
        ldx  ck_t
        stx  q_pa
        bsr  copy
        ldx  q_pn
        inx
        stx  q_pn
        bra  .r
.q:     ldx  ck_a
        tst  buf+2              ; (the first of a pair counts for nothing by itself)
        bmi  .q2
        ldd  q_nr
        addd #1
        std  q_nr
.q2:    bsr  copy
        ldx  zp
        stx  ck_a
        ldx  q_rn
        inx
        stx  q_rn
        bra  .r
.e:     ldd  q_rn
        std  q_svn
        ldd  q_pn
        std  q_svp
        bsr  share
        std  kv_done
        rts
        include "share.inc"
; the sieve's primes in the file
qsf:    ldaa #CK_QS
        staa kv_ckm
        bsr  isit
        ldab buf+10
        stab q_bs
        ldab buf+11
        bcs  .x
        clrb
.x:     rts
isit:   bsr  open
        bcs  .no
.r:     bsr  next
        bcs  .no
        cmpa #'S'
        bne  .r
        bsr  mine
        bne  .no
        sec
        rts
.no:    clc
        rts
; mine: is the state's first record the one for kv_ckm, and what it works on? (the sieve's: with this multiplier too. To
; 0.9.4 it was shorter, and its multipliers were others)
mine:   ldaa buf+2
        cmpa kv_ckm
        bne  .x
        cmpa #CK_QS
        bne  .s
        ldab ck_c
        cmpb #10
        bne  .x
        ldab buf+9
        cmpb q_k
        bne  .x
.s:     bsr  ck_tab
        bsr  ck_sum
        subd buf+3
.x:     rts
; FACTOR's list
fact:   bsr  open
        bcs  .no
        clr  ck_n
        ldx  kv_rl
        stx  ck_a
.r:     bsr  next
        bcs  .no
        cmpa #'F'
        beq  .f
        cmpa #'L'
        beq  .l
        cmpa #'S'
        bne  .r
        tst  ck_n               ; the end of it
        beq  .no
        ldx  ck_a
        stx  kv_lim
        ldx  #st                ; its variables
        stx  zx
        ldx  #kv_fz
        stx  zp
        ldx  fa_wp
        pshx
        ldaa fa_m
        psha
        ldd  #18
        bsr  cpb
        ldx  #kv_fx
        stx  zp
        ldd  #24
        bsr  cpb
        pula
        staa fa_m
        pulx
        stx  fa_wp
        ldd  fa_rec
        addd kv_rl
        std  fa_rec
        addd #FR_N
        std  fx_n
        sec
        rts
.no:    clc
        rts
.f:     ldx  #st
        ldab ck_n
        abx
        bsr  copy
        ldab ck_n
        addb ck_c
        stab ck_n
        cmpb #42
        bne  .r
        ldaa st+14              ; the same kind of job, for the same number?
        cmpa fa_m
        bne  .no
        ldx  fa_wp
        bsr  sum
        subd st+3
        bne  .no
        bra  .r
.l:     ldx  ck_a
        ldab ck_c
        abx
        xgdx
        subd kv_wp
        bcc  .no
        ldx  ck_a
        bsr  copy
        ldx  zp
        stx  ck_a
        bra  .r
; open: the file; carry set: none. The first record (the line) is passed over
open:   ldaa kv_ckv
        adda #'A'-1
        staa name+1
        ldx  #name
        os   FL$OPEN
        bcs  .x
        tab
        os   FL$RECT
        ldx  #1
        stx  ck_r
        clr  ck_d
        clc
.x:     rts
; next: the next record: A its letter, ck_c bytes decoded at buf+2; carry set: no more
next:   ldx  ck_r
        inx
        stx  ck_r
        xgdx
        os   FL$RSET
        ldx  #buf
        os   FL$READ
        bcs  .x
        ldab buf
        decb
        lsrb
        stab ck_c
        ldx  #buf+2
        stx  ck_p
        stx  ck_t
        beq  .d
        pshb
.l:     ldx  ck_p
        ldaa 0,x
        bsr  hex
        asla
        asla
        asla
        asla
        staa zm
        ldaa 1,x
        bsr  hex
        oraa zm
        inx
        inx
        stx  ck_p
        ldx  ck_t
        staa 0,x
        inx
        stx  ck_t
        pulb
        decb
        pshb
        bne  .l
        pulb
.d:     ldaa buf+1
        clc
.x:     rts
hex:    suba #'0'
        cmpa #9
        bls  .x
        suba #7
.x:     rts
; copy: the record's bytes to X (zp past them)
copy:   stx  zp
        ldx  #buf+2
        stx  zx
        ldab ck_c
        clra
        bra  cpb
name:   fcl  "A:BIGKEEP"
ck_r:   fdb  0
ck_p:   fdb  0
ck_t:   fdb  0
ck_a:   fdb  0
ck_c:   fcb  0
ck_n:   fcb  0
ck_d:   fcb  0
st:     rmb  44
        include "ck.inc"
buf:    rmb  100
