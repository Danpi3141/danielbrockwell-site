# RAM savings parked for later

Two ideas from the round of 25 November 2026, put aside at Daniel's request until the memory they use has been checked further ("Let's park ideas 1 & 2 ... will do some more checks on this memory area"). Both were built and tested in a scratch copy of 0.9.5. Neither is in the program. Together they give **383 bytes on every model**.

| | Saving | On | Pack |
|---|---|---|---|
| 1. The 256 bytes OPL keeps free under its stack | 256 | every model | about 0 |
| 2. Variables in two of the OS's scratch areas | 127 | every model | smaller (no fix-ups for them) |

## 1. The gap under OPL's stack

**Now.** The bootstrap and OV_EDIT put `RTA_SP` at `ALA_FREE` + 256 + 56 (`RESERVE`), and the block for numbers starts there (`kv_lo` = `RTA_SP`). So 312 bytes above the OS's memory are never used for numbers. The 256 are what OPL's `FREE` takes off, for its own working; the 56 let the settings file be made. Files that grow take their room out of the block beforehand (`aroom`), not out of the gap.

**The idea.** Leave `RTA_SP` where it is, so that the OS sees the same free memory and checks the same limits, but start the block 256 lower: `kv_lo` = `RTA_SP` - 256.

**The change**, two places:

- `src/kernel/kinit.asm`: `ldx RTA_SP / stx kv_lo` becomes `ldd RTA_SP / subd #256 / std kv_lo`.
- `src/ovl/ov_edit.asm`, at `edit`: `subd #256` between `std RTA_SP` and `std kv_lo`.
- `aroom` needs nothing: it moves everything by the difference.
- Then `NEED` and `BIGRAM` can come down by 256. Tests that say `RTA_SP` is not above `kv_lo` (`t_events`, `t_stress`) need `lo + 256`; `t_tiers`' thresholds move.

**Evidence so far.** With every read and write by ROM code logged, the ROM touched the gap only where the settings file's cell grew: its first 34 bytes or so, which the 56 reserved cover. Runs: 12 minutes of random events each on CM 2.4 and 3.3, XP, LA, LZ and LZ64 (packs in and out, low battery, switched off and on, the clock set, menus, keys), and `t_alarm`, `t_power`, `t_leave` and `t_start` on their ROMs. `t_stress` and the rest of the suite passed with it on (with ideas 2 to 4 as well).

**To check before using it.**

- An OS routine that takes the gap as working room without growing a cell. Not seen, not ruled out. Likely ones: the diary's and the alarms' screens, copying and sorting, long menus, a file full or write-protected on A:, B: and C:.
- A device that boots while the program runs (the Comms Link put in, then ON). It makes a cell at the bottom of memory larger and moves the rest up. The OS should refuse it if it wants more than 56 bytes, as now (from how `FREE` is worked out; not tried). A small one would move the cells into the 56 kept.
- Memory nearly full of the user's own diary, notes and files on A:, and a CM at its least free memory.
- A real Organiser, with the Comms Link in.

## 2. Variables in the OS's scratch memory

**The areas** (from [jaapsch.net's system variables](https://www.jaapsch.net/psion/sysvars.htm)):

| Where | Bytes | The OS's use | What would go there |
|---|---|---|---|
| `$234D`-`$23AC` | 96 | `itt_regs`, `itt_stak`: registers and stack of the table interpreter (`IT$STRT`) | `kv_pv` 26, `kv_fz` 18, `kv_fx` 24, `kv_lbuf` 20, `ps_buf ps_i ps_p ps_wi` 8: exactly 96 |
| `$23B5`-`$23D3` | 31 | `acw_stop` to `lxb_ftyp`: the OPL translator's | the core's `mb` to `mi`: exactly 31 |

Left alone between and after them: `$23AD` (a saved sign), `$23AE`-`$23B4` (the random numbers' seed), `$23D4` on (the calculator's places and the last procedure's name, which the OS does read again).

**The change.** In `src/kernel/kvars.inc` these names become constants (`kv_pv = $234D` and so on) in place of their `rmb`s. `src/kernel/kinit.asm` fills both areas with zeros (`UT$FILL`) before anything else uses them: variables on the pack are zeros, and these would not be. No other source changes.

**Evidence so far.**

- The ROM did not read or write either area while BigNum ran, in the runs listed above, and did not read one before writing it after leaving (`t_leave`, ten ROMs). `$2292`-`$22C7` looked free on some ROMs, but a CM or XP from 2.5 keeps the user-defined characters there when it switches off.
- `docs/parked/os_scratch_check.js`: both areas filled with rubbish (all `$FF`, and a pattern) while BigNum waits for a key, then it is left and 220 random keys are pressed in the OS. The screens were the same as without the rubbish in all 116 runs, on all 29 ROMs.
- The suite passed with it on.

**To check before using it.**

- What the OS's top level is doing while an OPL procedure runs. If it runs under the table interpreter, its registers or stack would be overwritten and leaving would go wrong. The 116 runs say not, for BigNum started from Prog, Run. Not tried: started by another procedure, from a procedure put on the top menu, or from Calc.
- Translating, finding, the calculator and the diary right after leaving, done on purpose and not only by random keys.
- An alarm with a diary entry on it ringing while it runs, on every ROM (`t_alarm`'s eight ROMs have been logged).
- The OS's own error screens and TRAP, which may use them.
- A real Organiser.

## To repeat the measurements

    node -r ./docs/parked/os_ram_log.js tests/t_alarm.js        (or t_power, t_leave, t_start, t_events lz64 7 12...)
    node docs/parked/os_scratch_check.js [rom ...]
