; =====================================================================
; OV_MENU: the menu (MODE on the entry line), drawn by the OS. Text to go into the line is left in RTB_BL.
; =====================================================================
        include "macros.inc"
        lastent menu

menu:   bsr  cls
        ldx  #items
        ldaa kv_tier
        cmpa #4
        bne  .m
        ldx  #items4
.m:     ldd  #$1003             ; ON, MODE and EXE end it
        os   MN$DISP
        clr  RTB_BL
        cmpb #K_EXE
        bne  .x
        ldab T0+1               ; the item
        ldaa kv_tier
        cmpa #4
        bne  .go
        cmpb #3                 ; (no Resume, no Log)
        blo  .go
        incb
        cmpb #5
        blo  .go
        incb
.go:    tstb
        beq  .ins
        decb
        beq  .vars
        decb
        beq  .set
        decb
        beq  .res
        decb
        beq  .bench
        decb
        beq  .log
        jmp  leave
.ins:   ovjump OV_INS,0
.vars:  ovjump OV_VARS,1
.set:   ovjump OV_SETL,0
.res:   ovjump OV_RES,0
.bench: ovjump OV_BENCH,0
.log:   ovjump OV_LOGV,0
.x:     rts
items:  fcl  "Insert"
        fdb  0
        fcl  "Vars"
        fdb  0
        fcl  "Set"
        fdb  0
        fcl  "Resume"
        fdb  0
        fcl  "Bench"
        fdb  0
        fcl  "Log"
        fdb  0
        fcl  "Quit"
        fdb  0
        fcb  0
items4: fcl  "Insert"
        fdb  0
        fcl  "Vars"
        fdb  0
        fcl  "Set"
        fdb  0
        fcl  "Bench"
        fdb  0
        fcl  "Quit"
        fdb  0
        fcb  0
