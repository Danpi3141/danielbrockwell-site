; the settings: the name, its kind (0 a number, 0 is Auto; 1 a number that is never 0; 2 ON or OFF; 3 a device or
; OFF), where it is, what it is at first
sets:   fcl  "TDIV"
        fcb  1
        fdb  st_tdiv,10000
        fcl  "RHOIT"
        fcb  0
        fdb  st_rho,0
        fcl  "PM1B1"
        fcb  0
        fdb  st_pm1,0
        fcl  "PP1B1"
        fcb  0
        fdb  st_pp1,0
        fcl  "ECMB1"
        fcb  0
        fdb  st_ecm,0
        fcl  "CURVES"
        fcb  0
        fdb  st_cur,0
        fcl  "PROOF"
        fcb  2
        fdb  st_proof,0
        fcl  "KEEP"
        fcb  3
        fdb  st_keep,0
        fcl  "EVERY"
        fcb  1
        fdb  st_every,30
        fcl  "LOG"
        fcb  3
        fdb  st_log,0
        fcl  "BEEP"
        fcb  2
        fdb  st_beep,1
        fcb  0
ST_N    = 11
