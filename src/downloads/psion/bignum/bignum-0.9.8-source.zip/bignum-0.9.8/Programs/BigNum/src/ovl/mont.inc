; Montgomery work. mctx: X = the modulus (an item, odd, that stays where it is), B = how many slots: room
; for them and the product taken off the top of the stack of numbers.
; The slots hold numbers of mn bytes less than the modulus, times R = 256 to the mn.
mctx:   pshb
        bsr  ilen
        std  mn
        inx
        inx
        stx  mnp
        addd mnp
        std  mne
        pulb                    ; B slots and 2 for the product, and a byte
        addb #2
        pshb
        ldaa mn+1
        mul
        std  zt
        pulb
        ldaa mn
        mul
        tba
        clrb
        addd zt
        addd #1
        bsr  walloc
        inx
        stx  mp
        ldd  mn
        asld
        addd mp
        std  ms
; mkinv: mk = -1/N modulo 256 (N odd)
mkinv:  ldx  mne
        dex
        ldaa 0,x
        staa zm                 ; x = N (right to 3 bits)
        bsr  .s
        bsr  .s
        nega
        staa mk
        rts
.s:     psha                    ; x = x (2 - N x)
        ldab zm
        mul
        negb
        addb #2
        pula
        mul
        tba
        rts
; mone: slot B = R modulo N, which is 1: from the power of 2 just under N, doubled up to R
mone:   bsr  mslot
        std  kv_se              ; its place
        xgdx
        bsr  clrxn
        ldx  mnp
        ldab 0,x
        ldaa #8+1               ; the doublings: 8 less the bits of N's top byte, and 1
.b:     deca
        lsrb
        bne  .b
        psha
        ldab #128               ; (the top bit of N's top byte)
        deca
.b2:    beq  .p
        lsrb
        deca
        bra  .b2
.p:     ldx  kv_se
        stab 0,x
        pula
.d:     psha
        bsr  .dbl
        pula
        deca
        bne  .d
        rts
.dbl:   ldd  kv_se
        std  ma
        std  mb
        std  mrs
        bra  op_add
; mr2: slot B = R squared modulo N (2 to the 8 mn, as 1 is R): from slot B = 1 (mone done)
mr2s:   stab mi
        stab mi+1
        stab mi+2
        ldd  mn
        asld
        asld
        asld
        ldx  #16
.t:     dex
        asld
        bcc  .t
        std  kv_al
        ldab #M_ADD             ; 2
        bsr  .op
.l:     cpx  #0
        beq  .x
        dex
        ldab #M_SQR
        bsr  .op
        asl  kv_al+1
        rol  kv_al
        bcc  .l
        ldab #M_ADD
        bsr  .op
        bra  .l
.op:    pshx
        ldaa kv_al
        psha
        ldaa kv_al+1
        psha
        bsr  mop
        pula
        staa kv_al+1
        pula
        staa kv_al
        pulx
.x:     rts
; toslot: the item at X (less than N, not negative) into slot B
toslot: pshx
        bsr  mslot
        std  kv_se
        xgdx
        bsr  clrxn
        stx  zp                 ; the slot's end
        pulx
        bsr  ilen
        pshb
        psha
        bsr  inext
        stx  zx
        pula
        pulb
        bra  cpd
; fromslot: slot B pushed as a number
fromslot: bsr mslot
        std  zx
        pshb
        psha
        ldd  mn
        addd #2
        bsr  walloc
        ldd  mn
        std  0,x
        inx
        inx
        stx  zp
        pula
        pulb
        std  zx
        ldd  mn
        bra  cpbn
; sone: slot B = the number 1 (not 1 times R)
sone:   bsr  mslot
        xgdx
        bsr  clrxn
        dex
        inc  0,x
        rts
