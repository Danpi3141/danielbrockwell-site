; =====================================================================
; OV_MEVEN: MODEXP with an even modulus: squares and products with divisions. The stack: a e m r (a modulo
; m); kv_fs+12 = r's item, kv_fs+14 = m's, mx_e = e's. The result on top.
; =====================================================================
        include "macros.inc"
        lastent even

mx_e    = kv_fs
mx_i    = kv_fs+2
even:   ldx  #0
        stx  kv_done
        stx  kv_est
        stx  kv_est+2
        bsr  hpush1
        ldx  mx_e
        bsr  ilen
        asld
        asld
        asld
        std  mx_i
        std  kv_tot
.l:     ldd  mx_i
        beq  .x
        subd #1
        std  mx_i
        bsr  hsqr
        bsr  .mod
        ldd  mx_i
        bsr  ebit
        beq  .l
        ldx  kv_fs+12
        bsr  hcopy
        bsr  hmul
        bsr  .mod
        bra  .l
.mod:   ldx  kv_fs+14
        bsr  hcopy
        ovsub OV_DIV,1
.x:     rts
        include "hsqr.inc"
        include "ebit.inc"
