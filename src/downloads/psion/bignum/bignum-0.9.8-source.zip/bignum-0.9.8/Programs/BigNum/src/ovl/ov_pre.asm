; =====================================================================
; OV_PRE: the start of a line looked at (for OV_EVAL's check): a command is carried out (and back to the main
; loop), P= leaves the variable in kv_dst and kv_tp0 past it.
; =====================================================================
        include "macros.inc"
        lastent pre

pre:    ldx  #0                 ; kept now and then, if KEEP is on
        stx  kv_ckt
        ldaa kv_tier
        cmpa #4
        beq  .nt
        clr  kv_ckw
        ldaa st_keep
        beq  .nt
        ldaa st_every+1
        ldab #60
        mul
        std  kv_ckt
        ldaa st_every
        ldab #60
        mul
        tba
        clrb
        addd kv_ckt
        std  kv_ckt
        ldaa st_keep            ; on A:: memory made for it now (a Lucas test of 8,192 bits, or less)
        deca
        bne  .nt
        ldx  #4500
        ldaa kv_tier
        deca
        beq  .a
        ldx  #2300
        deca
        beq  .a
        ldx  #1200
.a:     xgdx
        bsr  aroom
.nt:    ldaa #1
        staa kv_chk
        clr  kv_dst
        staa kv_tp
        staa kv_tp0
        bsr  ident              ; a name at the start?
        beq  .x
        decb
        bne  .cmd
        bsr  nextc              ; one letter: =
        cmpb #'='
        bne  .x
        ldx  kv_line
        ldab kv_id
        abx
        ldab 0,x
        bsr  upc
        stab kv_dst
        ldaa kv_tp
        staa kv_tp0
.x:     rts
.cmd:   bsr  nextc              ; a name with no bracket after it, other than ANS: a command
        cmpb #'('
        beq  .x
        bsr  isans
        beq  .x
        ovsub OV_NAMES,1
        bcs  .syn
        ldab kv_id              ; (what follows the name)
        addb kv_il
        stab kv_tp
        ldd  kv_fn+1
        bsr  ovd
        jmp  main
.syn:   ldab kv_id
        decb
        stab kv_epos
        ldab #E_SYN
        bra  err
isdig:  cmpb #'0'
        blo  .no
        cmpb #'9'
        bhi  .no
        subb #'0'
        clc
        rts
.no:    sec
        rts
; ident: the letters from kv_tp on (after spaces): kv_id where they start, B = kv_il how many (Z: 0)
ident:  bsr  nextc
        dec  kv_tp
        ldaa kv_tp
        staa kv_id
        clr  kv_il
.l:     ldx  kv_line
        ldab kv_tp
        cmpb 0,x
        bhi  .x
        abx
        ldab 0,x
        bsr  upc
        cmpb #'A'
        blo  .dg
        cmpb #'Z'
        bhi  .x
.in:    inc  kv_tp
        inc  kv_il
        bra  .l
.dg:    ldaa kv_il              ; (a digit after two letters: PM1)
        cmpa #2
        blo  .x
        bsr  isdig
        bcc  .in
.x:     ldab kv_il
        rts
; isans: Z if the name is ANS
isans:  ldab kv_il
        cmpb #3
        bne  .x
        ldx  kv_line
        ldab kv_id
        abx
        ldd  0,x
        anda #$DF
        andb #$DF
        subd #$414E             ; AN
        bne  .x
        ldab 2,x
        andb #$DF
        cmpb #'S'
.x:     rts
        include "nextc.inc"
        include "aroom.inc"
