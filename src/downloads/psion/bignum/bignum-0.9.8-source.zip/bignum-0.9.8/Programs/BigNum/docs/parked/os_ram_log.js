// What the ROM touches of the OS's RAM while BigNum runs, and what it reads before writing after leaving. Put in front of
// any test:   node -r ./docs/parked/os_ram_log.js tests/t_alarm.js        (see docs/parked-ram-savings.md)
'use strict';
const { BN } = require('../../tests/lib');
const LOGS = [], start = BN.prototype.start;
BN.prototype.start = function (...a) { hook(this); return start.apply(this, a); };
function hook(g) {
  if (g.hooked) return; g.hooked = true; const m = g.m;
  const L = { mo: g.model, t: new Uint8Array(0x8000), rbw: new Uint8Array(0x8000), w: new Uint8Array(0x8000), gap: {}, was: false }; LOGS.push(L);
  const r1 = m.bus.read.bind(m.bus), w1 = m.bus.write.bind(m.bus);
  const acc = (a, wr) => {
    if (a >= 0x8000 || a < 0x2000 || m.dbg.pc() < 0x8000) return;                                   // (only the ROM's own code)
    const a5 = r1(0xA5) << 8 | r1(0xA6), al = r1(0x2040) << 8 | r1(0x2041), inn = g.base > 0 && a5 < g.base;   // (OPL's stack below the program: it is running)
    if (inn) { if (!L.was) { L.was = true; L.w.fill(0); } if (a >= al && a < a5) L.gap[a - al] = (L.gap[a - al] || 0) + 1; else L.t[a] = 1; }
    else if (L.was) { if (wr) L.w[a] = 1; else if (!L.w[a]) L.rbw[a] = 1; }
  };
  m.bus.read = (a) => { acc(a, 0); return r1(a); };
  m.bus.write = (a, v) => { acc(a, 1); return w1(a, v); };
}
process.on('exit', () => {
  const runs = (f, lo, hi) => { const o = []; let s = -1; for (let a = lo; a <= hi; a++) { const y = a < hi && f(a); if (y && s < 0) s = a; if (!y && s >= 0) { o.push(s.toString(16) + (a - 1 > s ? '-' + (a - 1).toString(16) : '')); s = -1; } } return o.join(' ') || 'none'; };
  const by = {}; for (const l of LOGS) (by[l.mo] = by[l.mo] || []).push(l);
  for (const mo in by) {
    const t = (a) => by[mo].some((l) => l.t[a]), r = (a) => by[mo].some((l) => l.rbw[a]), gp = Object.keys(Object.assign({}, ...by[mo].map((l) => l.gap))).map(Number);
    console.log(`LOG ${mo}: touched in 2288-2410: ${runs(t, 0x2288, 0x2411)}; read before written after leaving: ${runs(r, 0x2288, 0x2411)}; in the gap above the OS's memory: ${gp.length ? 'offsets ' + Math.min(...gp) + ' to ' + Math.max(...gp) : 'nothing'}`);
  }
});
