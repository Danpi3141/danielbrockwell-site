; cop: Z if p2_u (odd) has no factor in common with D: not a multiple of 3 or 5, nor, for D = 210, of 7
cop:    ldab p2_u
        ldaa #3
        bsr  .m
        beq  .no
        ldaa #5
        bsr  .m
        beq  .no
        ldaa p2_d
        cmpa #105
        bne  .yes
        ldaa #7
        bsr  .m
        beq  .no
.yes:   clra
        rts
.no:    inca
        rts
.m:     staa zm                 ; Z if A divides B
        pshb
.s:     subb zm
        beq  .x
        bcc  .s
.x:     pulb
        rts
