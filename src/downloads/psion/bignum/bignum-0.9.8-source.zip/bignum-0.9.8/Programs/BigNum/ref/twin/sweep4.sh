#!/bin/bash
# tier 1 near the cap
{ for d in 55 56 57 58; do for i in 1 2 3; do echo $d 240 2048 16 15 $((10+i)) 2 20 40 150 1e14; done; done; } | xargs -P 12 -L 1 ./Qs.exe
