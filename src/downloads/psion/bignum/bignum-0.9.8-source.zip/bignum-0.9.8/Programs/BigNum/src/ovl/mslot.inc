        ifused toslot
; toslot: the item at X (less than N, not negative) into slot B
toslot: pshx
        bsr  mslot
        std  kv_se
        xgdx
        bsr  clrxn
        stx  zp                 ; the slot's end
        pulx
        bsr  ilen
        pshb
        psha
        bsr  inext
        stx  zx
        pula
        pulb
        bra  cpd
        endif
        include "fslot.inc"
        ifused sone
; sone: slot B = the number 1 (not 1 times R)
sone:   bsr  mslot
        xgdx
        bsr  clrxn
        dex
        inc  0,x
        rts
        endif
