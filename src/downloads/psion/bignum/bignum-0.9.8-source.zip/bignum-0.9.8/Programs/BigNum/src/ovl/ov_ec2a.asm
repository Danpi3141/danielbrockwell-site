; =====================================================================
; OV_EC2A: ECM's second stage set up (for OV_EC2): the table of u Q, the first step
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        include "ec.inc"
        include "ec2.inc"
        lastent ec2a

ec2a:   inc  ec_st
        ldab #105
        ldaa ec_s
        cmpa #24
        beq  .d
        ldab #15
.d:     stab p2_d
        ldd  fx_lim             ; 100 B1
        ldx  #100
        os   UT$UMUL
        stab p2_h
        stx  p2_h+1
; u Q for u = 1, 3, 5 ...: 2 Q is the step
        bsr  mrun
        mo    M_CPY,2,4,4
        mol   M_CPY,3,5,5
        bsr  ecdbl1
        bsr  mrun
        mo    M_ADD,9,2,3
        mo    M_SUB,10,2,3
        mo    M_CPY,0,4,4
        mo    M_CPY,1,5,5
        mo    M_CPY,2,4,4
        mo    M_CPY,3,5,5
        mol   M_CPY,11,4,4       ; (the product starts with anything that is not 0)
        ldaa #14
        staa p2_t
        ldaa #1
        staa p2_u
.u:     bsr  cop                ; one that is kept?
        bne  .nu
        ldab #M_CPY
        clra
        bsr  .keep
        ldab #M_CPY
        ldaa #1
        bsr  .keep
        ldaa #0
        staa mi+1
        inca
        staa mi+2
        ldaa p2_t
        inc  p2_t
        staa mi
        ldab #M_MUL
        bsr  mop
.nu:    bsr  step
        ldaa p2_u
        adda #2
        staa p2_u
        cmpa p2_d
        bls  .u
; D Q, in slots 4, 5
        ldab p2_d
        clra
        asld
        bsr  times
        bsr  mrun
        mo    M_CPY,4,0,0
        mol   M_CPY,5,1,1
; the first window: from 210 m - 105, m = (B1 + 105) / 210 (2 or more)
        ldd  fx_lim
        addd #105
        ldx  #0
.m:     subd #210
        bcs  .md
        inx
        bra  .m
.md:    stx  kv_al
        ldab #210
        ldaa kv_al+1
        mul
        std  zt
        ldaa kv_al
        ldab #210
        mul
        addb zt
        stab zt
        adca #0
        staa ps_lo
        ldd  zt
        subd #105
        std  ps_lo+1
        ldaa ps_lo
        sbca #0
        staa ps_lo
        ldd  kv_al              ; v: for D = 30, 7 m - 3
        ldaa p2_d
        cmpa #105
        beq  .v
        ldd  kv_al
        asld
        asld
        asld
        subd kv_al
        subd #3
        bra  .vv
.v:     ldd  kv_al
.vv:    subd #1
        bsr  times              ; 0, 1 (v-1) D Q; 2, 3 v D Q
        ldab #1
        bsr  ecsw               ; changed over
        bsr  mrun
        mo    M_ADD,9,4,5
        mol   M_SUB,10,4,5
        rts
.keep:  staa mi+1
        ldaa p2_t
        inc  p2_t
        staa mi
        clr  mi+2
        bra  mop
; times: R0, R1 = D, D+1 times the base
times:  bsr  hpush
        ldx  kv_wp
        stx  mx_e
        bsr  eclad
        bra  hdrop
        include "ecst.inc"
        include "cop.inc"
        include "ecl.inc"
        include "ibits.inc"
        include "ebit.inc"
