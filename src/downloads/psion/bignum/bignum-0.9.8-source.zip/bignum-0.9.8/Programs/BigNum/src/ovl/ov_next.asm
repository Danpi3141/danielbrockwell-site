; =====================================================================
; OV_NEXT: NEXTPRIME(n), PREVPRIME(n): a window of odd candidates sieved by the primes below 10,000, the
; ones left tested
; =====================================================================
        include "macros.inc"
        entry f_next
        lastent f_prev

NX_LEN  = 64                    ; the window: 512 candidates
nx_d    = kv_fx                 ; 0 up, 1 down
nx_b    = kv_fx+2               ; the first candidate's item
nx_w    = kv_fx+4               ; the window
nx_i    = kv_fx+6               ; the place in it
nx_e    = kv_fx+8               ; the argument's end
nx_l    = kv_fx+12              ; the primes to sieve by
nx_s    = kv_fx+10              ; the stack of numbers for a candidate
f_prev: ldaa #1
        bra  nx_go
f_next: clra
nx_go:  staa nx_d
        bsr  i2
        stx  nx_e
        ldx  kv_wp              ; small arguments: the prime 2
        ldd  0,x
        bmi  .low
        beq  .low
        subd #1
        bne  .big
        ldab 2,x
        tst  nx_d
        bne  .pv
        cmpb #2
        blo  .two
        bra  .big
.pv:    cmpb #3
        bhi  .big
        beq  .two
        bra  .arg
.low:   tst  nx_d
        bne  .arg
.two:   bsr  hdrop
        ldd  #2
        bra  hpush
.arg:   bra  errarg
; the first candidate: the odd number after n (before it)
.big:   bsr  inext
        dex
        ldab 0,x
        clra
        lsrb
        ldab #1
        bcc  .ev
        incb
.ev:    bsr  hpush
        tst  nx_d
        bne  .sub
        bsr  hadd
        bra  .set
.sub:   bsr  hsub
.set:   bsr  ilenw              ; below 65536: each candidate by trial division
        subd #2
        bhi  .large
.sm:    ovsub OV_PRP,0
        tst  kv_pk
        bne  .found
        ldd  #2
        bsr  hpush
        tst  nx_d
        bne  .sms
        bsr  hadd
        bra  .sm
.sms:   bsr  hsub
        bra  .sm
.large: bsr  ilenw              ; the sieve's limit: 160 a byte, at most 10,000
        subd #62
        bcs  .lm
        clra
        clrb
.lm:    addd #62
        ldaa #160
        mul
        std  nx_l
        ldd  #PS_LEN+NX_LEN     ; (the windows are above the candidates' base)
        bsr  walloc
        stx  ps_buf
        ldab #PS_LEN
        abx
        stx  nx_w
        ldx  #hook
        bsr  hookx
.win:   ldx  nx_w
        ldd  #NX_LEN
        bsr  clrx
        stx  nx_b               ; (the base lies just above them)
        clrb
        ldx  #3
        bsr  ps_go
.p:     bsr  poll
        bsr  ps_next
        ldd  ps_p+1
        subd nx_l
        bcc  .test
        ldd  ps_p+1             ; not past the root of the candidates: a small one is not to be struck
        std  kv_na
        bsr  rem16
        std  kv_al              ; r
        tst  nx_d
        bne  .dn
        ldd  ps_p+1             ; up: the first i with p | b + 2i
        subd kv_al
        subd ps_p+1
        beq  .i0
        addd ps_p+1
        bra  .hf
.i0:    clra
        clrb
        bra  .st
.dn:    ldd  kv_al              ; down: p | b - 2i
.hf:    bitb #1
        beq  .h
        addd ps_p+1
.h:     lsrd
.st:    std  zx
.s:     ldd  zx
        subd #NX_LEN*8
        bcc  .p
        ldd  zx
        bsr  bit
        orab 0,x
        stab 0,x
        ldd  zx
        addd ps_p+1
        std  zx
        bra  .s
; those left
.test:  ldd  #$FFFF
        std  nx_i
        ldx  kv_wp
        stx  nx_s
.t:     ldd  nx_i
        addd #1
        std  nx_i
        subd #NX_LEN*8
        bcc  .over
        ldd  nx_i
        bsr  bit
        bitb 0,x
        bne  .t
        bsr  cand
        ovsub OV_BASE2,1        ; (the quick way in: no display)
        tst  kv_pk
        beq  .nt
        ovsub OV_DIGS,0
        ovsub OV_LUCP,0
        tst  kv_pk
        bne  .found
.nt:    ldx  nx_s
        stx  kv_wp
        bra  .t
.found: ldx  nx_e
        bra  hslx
.over:  bsr  cand               ; the next window: from the one after the last
        ldx  nx_b
        bsr  inext
        bsr  hslx
        ldd  #PS_LEN+NX_LEN
        bsr  walloc
        stx  ps_buf
        ldab #PS_LEN
        abx
        stx  nx_w
        bra  .win
; cand: the candidate nx_i pushed
cand:   ldx  nx_b
        bsr  hcopy
        ldd  nx_i
        asld
        bsr  hpush
        tst  nx_d
        bne  hsub
        bra  hadd
; bit: D = a place: X the byte, B the bit
bit:    pshb
        lsrd
        lsrd
        lsrd
        addd nx_w
        xgdx
        pulb
        andb #7
        ldaa #1
.b:     decb
        bmi  .x
        asla
        bra  .b
.x:     tab
        rts
; rem16: D = the number at nx_b modulo kv_na
rem16:  ldx  nx_b
        bsr  ilen
        std  zt
        inx
        inx
        stx  zx
        clra
        clrb
.l:     ldx  zx
        pshb
        ldab 0,x
        stab zm
        pulb
        inx
        stx  zx
        ldx  #8
.b:     asl  zm
        rolb
        rola
        bcs  .s
        subd kv_na
        bcc  .n
        addd kv_na
        bra  .n
.s:     subd kv_na
.n:     dex
        bne  .b
        ldx  zt
        dex
        stx  zt
        bne  .l
        rts

hook:   bsr  cls
        bsr  ln0
        tst  nx_d
        bne  .p
        bsr  pri
        fcl  "NEXTPRIME"
        bra  .o
.p:     bsr  pri
        fcl  "PREVPRIME"
.o:     bsr  out
        ldaa kv_h
        deca
        bra  onstop
        include "primes.inc"
