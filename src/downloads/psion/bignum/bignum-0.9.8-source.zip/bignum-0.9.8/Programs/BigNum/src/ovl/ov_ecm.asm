; =====================================================================
; OV_ECM: elliptic curves on the number at fx_n: the curves fx_cur+1 to fx_crv of level fx_lvl, with the
; bound fx_lim: fx_found = 1 and the factor on top of the stack of numbers, or 0; fx_cur = the last curve
; done (the one that found it).
; =====================================================================
        include "macros.inc"
        include "ckn.inc"
        include "fx.inc"
        include "ec.inc"
        lastent ecm

ecm:    ldd  kv_wp
        std  fx_wp
        clr  fx_found
        ldaa #3
        staa fx_m
        ovsub OV_ECMA,0         ; the room
        tstb                    ; (RESUME: B = 1 in a curve's first stage, 2 in its second)
        beq  .curve
        decb
        bne  .stage2
        bsr  .on
        ldd  ps_p+1
        addd #2
        orab #1
        xgdx
        clrb
        bsr  ps_go
        bsr  hpush1
        bra  .c
.on:    clr  ec_st
        inc  ec_st
        ldx  #hook
        bra  hookx
.curve: ldd  fx_cur
        ldx  #64
        os   UT$UMUL
        stx  kv_done
        ldd  fx_cur             ; all done?
        subd fx_crv
        bhs  .none
        ldd  fx_cur
        addd #1
        std  fx_cur
        bsr  .on
        ovsub OV_ECS,0          ; the curve: slots 4, 5 the point, 6 (A+2)/4
        bcs  .found             ; (it found a factor by itself)
; the first stage: the prime powers up to B1, in exponents of 24 bytes or so
        clrb
        ldx  #3
        bsr  ps_go
        bsr  hpush1
        ldd  #2
        std  ps_p+1
        clr  ps_p
        bsr  powr
.c:     bsr  ps_next
        tst  ps_p
        bne  .last
        ldd  ps_p+1
        subd fx_lim
        bhi  .last
        bsr  powr
        bsr  ilenw
        subd #24
        bcs  .c
        bsr  mult
        bsr  prog
        ldaa #CK_ECM1
        staa kv_ckm
        bsr  safe
        bsr  hpush1
        bra  .c
.last:  bsr  mult               ; (its GCD is looked at by the second stage)
.stage2: ovsub OV_EC2,0
        tst  fx_found
        beq  .curve
        bra  .done
.found: inc  fx_found
.done:  ldx  fx_wp
        bsr  hslx
        bra  hook0
.none:  ldx  fx_wp
        stx  kv_wp
        bra  hook0

; mult: the base times the exponent on top (dropped), the new base
mult:   ldx  kv_wp
        stx  mx_e
        bsr  eclad
        bsr  mrun
        mo    M_CPY,4,0,0
        mol   M_CPY,5,1,1
        ldx  ec_w
        stx  kv_wp
        rts
; prog: kv_done from the prime reached: 28 of a curve's 64 units are the first stage
prog:   clra
        clrb
        std  kv_n
        ldd  ps_p+1
        std  kv_n+2
        ldd  #28
        std  kv_na
        ldd  fx_lim
        std  kv_nb
        bsr  muldiv
        ldd  fx_cur
        subd #1
        ldx  #64
        os   UT$UMUL
        xgdx
        addd kv_n+2
        std  kv_done
        rts
; powr: the prime ps_p+1 times itself while it is within B1, into the exponent
powr:   ldx  ps_p+1
        stx  ec_al
.l:     ldd  ec_al
        ldx  ps_p+1
        os   UT$UMUL
        subd #0
        bne  .x
        xgdx
        std  kv_se
        subd fx_lim
        bhi  .x
        ldd  kv_se
        std  ec_al
        bra  .l
.x:     ldx  #0
        stx  kv_na
        ldd  ec_al
        bra  hmuladd
        include "echook.inc"
        include "ecl.inc"
        include "mhook.inc"
        include "ibits.inc"
        include "ebit.inc"
        include "psn.inc"
        include "cksafe.inc"
