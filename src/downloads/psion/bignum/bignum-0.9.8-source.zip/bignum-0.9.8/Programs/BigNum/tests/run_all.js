// Every test: node tests/run_all.js   (about half an hour on a fast PC; ten at a time)
'use strict';
const { spawn } = require('child_process'), path = require('path');
const J = [['t_start'], ['t_short'], ['t_leave'], ['t_alarm'], ['t_power'], ['t_help'], ['t_left'], ['t_version'], ['t_files', 'lz64'], ['t_odd', 'lz64'], ['t_edit', 'lz64'], ['t_edit', 'cm'], ['t_fuzz', 'lz64', '1', '400'], ['t_fuzz', 'cm', '2', '400'], ['t_events', 'lz64', '1', '40'], ['t_events', 'cm', '2', '40'], ['t_events', 'xp', '3', '40'], ['t_tiers', 'lz64'], ['t_tiers', 'xp', '350,2'], ['t_tight', 'cm'], ['t_tight', 'xp'], ['t_factors', 'lz64'], ['t_factors', 'xp'], ['t_factors', 'cm'], ['t_small', 'lz64', '3'], ['t_small', 'xp', '2'], ['t_small', 'cm']];
for (const m of ['lz64', 'cm', 'xp', 'la']) { for (const t of ['t_core', 't_eval', 't_func']) J.push([t, m]); J.push(['t_prime', m, '--quick'], ['t_meth', m], ['t_known', m, '6', '1', '28'], ['t_prove', m], ['t_stress', m, '31', '60']); }
for (const m of ['lz64', 'xp', 'la']) J.push(['t_keep', m]);
J.push(['t_qs1'], ['t_qs2', 'lz64', '4246408700664570451551746970972071'], ['t_pause', 'lz64', 'FACT|SQRT|MODEXP|LLT|FACTOR|QS', '4'], ['t_pause', 'cm', 'FACT|MODEXP|LLT|FACTOR|PM1', '4']);
let run = 0, bad = 0; const t0 = Date.now();
const next = () => {
  const j = J.shift(); if (!j) { if (!run) { console.log(bad ? `${bad} FAILED` : 'all ok', ((Date.now() - t0) / 60000).toFixed(1), 'min'); process.exit(bad ? 1 : 0); } return; }
  run++; const p = spawn(process.execPath, [path.join(__dirname, j[0] + '.js'), ...j.slice(1)]); let s = '';
  p.stdout.on('data', (d) => s += d); p.stderr.on('data', (d) => s += d);
  p.on('close', (c) => { run--; if (c) { bad++; console.log('FAILED', j.join(' '), '\n' + s.slice(-1500)); } else console.log('ok', j.join(' '), s.trim().split('\n').pop().slice(0, 100)); next(); });
};
for (let i = 0; i < 10; i++) next();
