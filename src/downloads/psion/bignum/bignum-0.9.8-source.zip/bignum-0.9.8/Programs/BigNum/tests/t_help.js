// HELP: every line as it is in the source, scrolled to the end and back, paged with EXE; nothing past the end, no beep,
// no control codes.   node tests/t_help.js [model ...]
'use strict';
const fs = require('fs'), path = require('path');
const { BN, HZ, ROOT } = require('./lib');
let bad = 0;
const src = fs.readFileSync(path.join(ROOT, 'src/ovl/ov_help.asm'), 'utf8'), want = [];
let n = 0;                                      // (characters of a line made of pieces still to come)
for (const l of src.slice(src.indexOf('\ntext:')).split('\n')) {
  let m;
  if ((m = /^\s+fcl\s+"(.*)"/.exec(l))) want.push(m[1]);
  else if ((m = /^\s+fcb\s+(\d+)\s*$/.exec(l))) { if (n) { want[want.length - 1] += String.fromCharCode(+m[1]); n--; } else { want.push(''); n = +m[1]; } }
  else if ((m = /^\s+fcc\s+"(.*)"/.exec(l))) { want[want.length - 1] += m[1]; n -= m[1].length; }
}
const LINES = +/LINES\s+=\s+(\d+)/.exec(src)[1];
if (want.length !== LINES || n) { bad++; console.log('FAIL the source has', want.length, 'lines, LINES is', LINES, n); }
if (!want.includes('SAVE A,"name"')) { bad++; console.log('FAIL no SAVE line', want.join('|')); }
for (const w of want) if (w.length > 16) { bad++; console.log('FAIL too long:', w); }
for (const mo of process.argv.length > 2 ? process.argv.slice(2) : ['cm', 'xp', 'la', 'lz', 'lz64']) {
  const g = new BN(mo).start(), m = g.m, at = g.addr('t_idle');
  const key = (c) => { m.poke(0x76, c); m.run(2000); m.runTo([at], HZ * 5); };
  const see = () => g.lines().map((l) => l.trimEnd());
  const chk = (top, what) => { const s = see(), h = s.length; const w = want.slice(top, top + h); if (s.join('\n') !== w.join('\n')) { bad++; console.log(`FAIL ${mo} ${what} at ${top}:`, s.join('|'), 'want', w.join('|')); } };
  const help = () => { g.wait(); for (let i = 0; i < 4 && !g.atLine(); i++) { g.inject('ON'); g.wait(); } m.write(g.peekw('kv_line'), [4, 72, 69, 76, 80]); g.poke('kv_cur', 4); key(13); };
  const h = g.lines().length, last = LINES - h;
  help(); chk(0, 'first');
  m.buzzStart();
  for (let i = 1; i <= last + 5; i++) { key(4); chk(Math.min(i, last), 'down'); }
  for (let i = last - 1; i >= -5; i--) { key(3); chk(Math.max(i, 0), 'up'); }
  const tones = m.buzzStop().filter((t) => t.ms > 5); if (tones.length) { bad++; console.log('FAIL', mo, 'beeps', JSON.stringify(tones.slice(0, 3))); }
  let top = 0;
  for (let i = 0; i < 40 && top < last; i++) { key(13); top = Math.min(top + h, last); chk(top, 'EXE'); }
  key(13); g.wait(); if (!g.atLine()) { bad++; console.log('FAIL', mo, 'EXE at the end: still there', see().join('|')); }
  console.log(`${mo}: ${LINES} lines`);
}
console.log(bad ? `${bad} FAILED` : 't_help ok');
process.exit(bad ? 1 : 0);
