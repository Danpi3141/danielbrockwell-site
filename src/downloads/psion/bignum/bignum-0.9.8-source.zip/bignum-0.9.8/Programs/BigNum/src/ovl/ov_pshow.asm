; =====================================================================
; OV_PSHOW: ISPRIME's result: the number is the item at kv_rl. kv_pk, kv_pw, kv_pf as OV_PRP leaves them.
; =====================================================================
        include "macros.inc"
        lastent pshow

pshow:  bsr  cls
        ldx  kv_vb              ; the number's digits
        stx  kv_wp
        ldx  kv_rl
        bsr  hcopy
        ovsub OV_DIGS,0
        clra
        tst  kv_four
        beq  .two
        bsr  echon              ; four lines: the line typed first
        ldaa #1
.two:   bsr  ln
        ldaa kv_pk
        beq  .comp
        deca
        beq  .prov
        bsr  pri
        fcl  "PRP  "
        ldd  kv_digs
        bsr  pdig
        bsr  out
        tst  kv_four
        beq  .p
        bsr  ln2
        bsr  pri
        fcl  "BPSW passed  "
        bsr  took
        bsr  out
.p:     bsr  last
        bsr  pri
        fcl  "P=prove"
        bsr  out
        bra  .keys
.prov:  ldaa #'P'
        bsr  putc
        ldd  kv_digs
        bsr  putwp
        fcl  "  proven"
        bsr  out
        bsr  next
        ldx  kv_rl              ; below 10**8 by trial division
        bsr  ilen
        subd #4
        bhi  .b64
        blo  .tri
        ldd  2,x
        subd #$05F5
        bhi  .b64
        blo  .tri
        ldd  4,x
        subd #$E100
        bcc  .b64
.tri:   bsr  pri
        fcl  "By division"
        bra  .o
.b64:   bsr  pri
        fcl  "Below 2**64"
        bra  .o
.comp:  ldaa kv_pw
        cmpa #5
        bne  .c
        bsr  pri
        fcl  "Not prime"
        bra  .o
.c:     ldaa #'C'
        bsr  putc
        ldd  kv_digs
        bsr  putwp
        fcl  "  not prime"
        bsr  out
        bsr  next
        ldab kv_pw
        decb
        bne  .w2
        ldd  kv_pf
        bsr  putwp
        fcl  " divides it"
        bra  .o
.w2:    ldx  #why
.f:     decb
        beq  .w3
        pshb
        ldab 0,x
        inx
        abx
        pulb
        bra  .f
.w3:    bsr  prs
.o:     bsr  out
.keys:  bsr  getk
        cmpb #'V'
        beq  .v
        cmpb #'P'
        bne  .n
        ldaa kv_pk
        cmpa #2
        bne  .keys
        ovjump OV_PROVE,4
.n:     cmpb #K_EXE
        beq  .x
        cmpb #K_ON
        beq  .x
        cmpb #K_MODE
        bne  .keys
.x:     rts
.v:     ovsub OV_SHOW,2
        bra  pshow
last:   ldaa kv_h
        deca
        bra  ln
next:   ldaa kv_ln
        inca
        bra  ln
; took: the time the run took
took:   ldd  kv_el
        std  kv_n
        bne  putt
        ldd  kv_el+2
        std  kv_n+2
        subd #100
        bcc  putt
        bsr  putn
        ldaa #'s'
        bra  putc
why:    fcl  "Failed base 2"
        fcl  "Failed Lucas"
        fcl  "A square"
        include "echo.inc"
