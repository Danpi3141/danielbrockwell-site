; =====================================================================
; OV_ECS: a curve for ECM (Suyama's, from sigma): slots 4, 5 = the point, 6 = (A+2)/4. Carry set: a factor
; came up at once (pushed).
;   u = s s - 5, v = 4 s, X = u u u, Z = v v v, (A+2)/4 = (v-u)^3 (3u+v) / (16 u^3 v)
; sigma is 1000 times the level and the curve's number (and 5 more), so no curve comes twice.
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        lastent ecs

ecs:    ldab fx_lvl
        clra
        ldx  #1000
        os   UT$UMUL
        xgdx
        addd fx_cur
        addd #5
        std  fx_sg
        ldaa #8                 ; R squared in slot 8, 1 in 9
        staa ms_r
        inca
        staa ms_o
        ovsub OV_MSET,1
        ldab #7                 ; s in 7 (times R)
        bsr  sone
        ldd  fx_sg
        dex
        std  0,x
        bsr  mrun
        mo    M_MUL,7,7,8
        mo    M_SQR,0,7,7        ; u = s s - 5
        mo    M_ADD,1,9,9
        mo    M_ADD,1,1,1
        mo    M_SUB,0,0,1
        mo    M_SUB,0,0,9
        mo    M_ADD,7,7,7        ; v = 4 s
        mo    M_ADD,7,7,7
        mo    M_SQR,1,0,0        ; X = u^3
        mo    M_MUL,4,1,0
        mo    M_SQR,1,7,7        ; Z = v^3
        mo    M_MUL,5,1,7
        mo    M_SUB,1,7,0        ; (v-u)^3
        mo    M_SQR,2,1,1
        mo    M_MUL,1,2,1
        mo    M_ADD,2,0,0        ; 3u+v
        mo    M_ADD,2,2,0
        mo    M_ADD,2,2,7
        mo    M_MUL,6,1,2
        mo    M_MUL,0,4,7        ; 16 u^3 v
        mo    M_ADD,0,0,0
        mo    M_ADD,0,0,0
        mo    M_ADD,0,0,0
        mo    M_ADD,0,0,0
        mol   M_CPY,10,0,0
        clr  iv_a               ; inverted, in slots 0 to 3
        clrb                    ; (0 has no inverse)
        bsr  mslot
        xgdx
        ldd  mn
        std  zt
.z:     tst  0,x
        bne  .nz
        inx
        ldd  zt
        subd #1
        std  zt
        bne  .z
        bra  .no
.nz:    bsr  inv
        bcs  .no
        bsr  mrun               ; 1/(x R): times R squared twice
        mo    M_MUL,0,0,8
        mo    M_MUL,0,0,8
        mol   M_MUL,6,6,0
        clc
        rts
.no:    ldab #10                ; a common factor, or the number itself: that curve is no use
        bsr  sgcd
        bsr  kind
        beq  .bad
        bcs  .fac
.bad:   bsr  hdrop
        ldd  fx_cur             ; (the next sigma)
        addd #1
        std  fx_cur
        bra  ecs
.fac:   sec
        rts
        include "sgcd.inc"
        include "mslot.inc"
        include "inv.inc"
