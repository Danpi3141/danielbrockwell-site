; ckset: a method is at work (A = CK_...): what can be kept; carry set: its state has come out of the file (RESUME)
ckset:  staa kv_ckm
        ldaa kv_ckd
        bpl  .n
        ovsub OV_CKL,0
        rts
.n:     clc
        rts
