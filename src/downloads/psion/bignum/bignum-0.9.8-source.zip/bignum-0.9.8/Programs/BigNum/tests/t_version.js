// Two versions at once: one in each slot, files of both on one pack, the pack changed for the other version's (or taken out)
// while the program runs. It runs the right one, or says FILE NOT FOUND or PACK CHANGED and leaves.   node tests/t_version.js
'use strict';
const fs = require('fs'), path = require('path'), os = require('os'), { execFileSync } = require('child_process');
const { BN, HZ, ROOT } = require('./lib');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'bnv')), other = path.join(tmp, 'other');
execFileSync('python', [path.join(ROOT, 'tools', 'build.py'), '--out', other, '--ver', 'another']);
const here = path.join(ROOT, 'build', 'game'), V = { here, other }, img = (v) => fs.readFileSync(path.join(V[v], 'BIGNUM.opk')), opk = (v) => path.join(V[v], 'BIGNUM.opk');
let bad = 0, n = 0; const fail = (s) => { bad++; console.log('FAIL', s); };
const parts = (b) => { const o = {}; let p = 16; while (p < b.length && b[p] !== 0xFF) { const name = b.slice(p + 2, p + 10).toString('latin1').trim(); let q = p + 2 + b[p]; q += 4 + (b[q + 2] << 8 | b[q + 3]); o[name] = b.slice(p, q); p = q; } return o; };
const P = { here: parts(img('here')), other: parts(img('other')) };
const mix = (list) => { const all = Buffer.concat([img('here').slice(0, 16), ...list.map(([v, f]) => P[v][f]), Buffer.from([255, 255])]); const l = all.length - 6; all[3] = l >> 16; all[4] = l >> 8 & 255; all[5] = l & 255; const f = path.join(tmp, `m${n}.opk`); fs.writeFileSync(f, all); return f; };
const menu = (g) => /PROG|Prog|EDIT|Edit|FIND|Find|RUN|Run/.test(g.text());
// want: the build that should run, or null: a message and back to the menu
const run = (mo, b, c, dev, want, label) => {
  n++; const g = new BN(mo, { build: V[want || 'here'], pack: b }), m = g.m; if (c) m.insertPack(c, 1);
  m.runProc('BIGNUM', dev); let up = false; for (let i = 0; i < 80 && !up; i++) { m.runSeconds(0.1); up = g.sync() >= 0 && m.peekw(0xA5) < g.base; } m.runSeconds(1.5);
  if (want) { if (!up) return fail(`${mo} ${label}: ${g.text()}`); const id = fs.readFileSync(path.join(V[want], 'kernel.lst'), 'utf8').match(/83([0-9A-F]{4})\s+subd #BUILD/)[1]; const k = Buffer.from(m.read(g.base, g.sym.kv_vars[0])).toString('hex').toUpperCase(); if (!k.includes('83' + id)) return fail(`${mo} ${label}: not the right build`); const r = g.line('FACT(30)/FACT(28)'); if (r.val !== 870n) fail(`${mo} ${label}: ${r.err} ${r.val}`); return; }
  if (!/NOT FOUND|introuvable/i.test(g.text())) return fail(`${mo} ${label}: ${g.text()}`); m.press('SPACE', 4, 4); m.runSeconds(2); if (!menu(g)) fail(`${mo} ${label}: then ${g.text()}`);
};
for (const mo of ['cm', 'xp', 'lz64']) {
  for (const [b, c] of [['here', 'other'], ['other', 'here']]) { run(mo, opk(b), opk(c), 'B', b, `${b} in B:, ${c} in C:, from B:`); run(mo, opk(b), opk(c), 'C', c, `${b} in B:, ${c} in C:, from C:`); }
  if (mo === 'xp') continue;
  for (const [l, k, f] of [['here', 'other', 'other'], ['here', 'here', 'other'], ['here', 'other', 'here'], ['other', 'here', 'here']]) run(mo, mix([[l, 'BIGNUM'], [k, 'BNK'], [f, 'BNL']]), null, 'B', null, `${l} BIGNUM, ${k} BNK, ${f} BNL`);
  run(mo, mix([['here', 'BIGNUM']]), opk('here'), 'B', 'here', 'BIGNUM on B:, the rest on C:');
  run(mo, mix([['here', 'BIGNUM'], ['here', 'BNK']]), mix([['here', 'BNL']]), 'B', null, 'BNL on C: only');
}
for (const mo of ['cm', 'xp', 'lz64']) for (const to of ['other', null]) for (const l of ['2**100', 'HELP', 'FACTOR(91)', '(']) {
  n++; const g = new BN(mo).start(), m = g.m; g.wait(); g.line('1+1'); for (let i = 0; i < 4 && !g.atLine(); i++) { g.inject('ON'); g.wait(); }
  if (to) m.insertPack(opk(to), 0); else m.removePack(0);
  m.write(g.peekw('kv_line'), [l.length, ...[...l].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', l.length); m.poke(0x76, 13); m.runSeconds(6); const t = g.text(); m.press('SPACE', 4, 4); m.runSeconds(3);
  if (!/PACK CHANGED/.test(t) || !menu(g)) fail(`${mo}, the pack ${to ? 'changed' : 'taken out'}, ${l}: ${t.replace(/\n/g, '|')} -> ${g.text().replace(/\n/g, '|')}`);
}
// taken out at every moment of an overlay's being read
for (const mo of ['cm', 'lz64']) for (let k = 0; k < 30; k++) {
  n++; const g = new BN(mo).start(), m = g.m; g.wait(); const l = 'FACT(9)'; m.write(g.peekw('kv_line'), [l.length, ...[...l].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', l.length); m.poke(0x76, 13);
  m.runTo([g.addr('ov_load')], HZ * 3); m.run(k * 2000 + 500); m.removePack(0); m.runSeconds(4); const t = g.text(); m.press('SPACE', 4, 4); m.runSeconds(3);
  if (/TRAP/.test(t + g.text()) || !/PACK CHANGED/.test(t) || !menu(g)) fail(`${mo}, taken out ${k * 2000 + 500} cycles into a load: ${t.replace(/\n/g, '|')} -> ${g.text().replace(/\n/g, '|')}`);
}
fs.rmSync(tmp, { recursive: true, force: true });
console.log(bad ? `${bad} FAILED` : `t_version ok (${n} tries)`);
process.exit(bad ? 1 : 0);
