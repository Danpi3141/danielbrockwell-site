; =====================================================================
; OV_TRF: trial division has found that the prime kv_pf divides the top number: divided out and into the list
; =====================================================================
        include "macros.inc"
        include "fa.inc"
        lastent found

found:  bsr  fl_new
        clra
        clrb
        std  FL_E
.l:     bsr  hdup
        ldd  kv_pf
        bsr  hpush
        ovsub OV_DIV,2          ; the quotient and the remainder, over the number
        bsr  i2
        ldd  0,x
        bne  .e
        bsr  hnip               ; it goes: the quotient instead of the number
        bsr  hnip
        ldd  FL_E
        addd #1
        std  FL_E
        bra  .l
.e:     bsr  hdrop2
        ldd  kv_pf
        bsr  hpush
        ldaa #FT_P
        bra  fl_add
        include "flist.inc"
