; =====================================================================
; OV_FACT: FACTOR(n). The list of factors (flist.inc) starts as what trial division finds and the rest of n;
; then each new number in it is tested, and each composite one checked for a power and given to OV_PLAN's
; methods; a factor splits it in two new ones, which carry on the work done.
; Entry 0: FACTOR. 1: a run stopped or a method skipped (kv_why). 2: the factors of the top number (kept),
; for PHI and the others: the list at kv_rl. 3: the same for PROVE, with fa_m = 2 (stopped when what is found is
; enough: OV_PCHK) or 3 (trial division and prime checks only).
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        include "fa.inc"
        include "pv.inc"
        entry factor
        entry stopped
        entry list
        lastent go

factor: ldaa #1
        staa fa_m
        ldx  kv_wp
        ldd  0,x
        beq  .arg
        bpl  go
.arg:   bra  errarg
list:   clr  fa_m
go:     ldx  kv_osp
        stx  kv_rl
        stx  kv_lim
        ovsub OV_DIGS,0
        ldd  kv_digs
        std  fa_dg
        ldaa #OV_FACT
        ldab #1
        std  kv_esc
        sts  kv_ssp
        clr  kv_skp
        ldx  kv_wp              ; the number itself stays
        stx  fa_wp
        ldaa kv_ckd             ; RESUME: the list as it was?
        bpl  .new
        ovsub OV_CKL,1
        bcc  .new
        ovsub OV_PLAN,2         ; on with the method
        bra  after
.new:   ldx  kv_wp
        bsr  hdup
        ovsub OV_TRIAL,0
        ldx  kv_wp              ; what is left: 1?
        ldd  0,x
        subd #1
        bne  .add
        ldaa 2,x
        deca
        beq  .one
.add:   ovsub OV_FSPL,3
        bra  loop
.one:   bsr  hdrop
; ---- the list gone through: new numbers first
loop:   ldaa fa_m
        cmpa #2
        bne  .s
        ovsub OV_PCHK,0
        bcs  finish
.s:     ldx  kv_rl
.f:     cpx  kv_lim
        beq  .comp
        ldaa 0,x
        beq  new
        bsr  fl_next
        bra  .f
.comp:  ldaa fa_m
        cmpa #3
        beq  finish
        ldx  kv_rl
.g:     cpx  kv_lim
        beq  finish
        ldaa 0,x
        cmpa #FT_C
        beq  power
        cmpa #FT_CN
        beq  split
        bsr  fl_next
        bra  .g
; a new number: prime?
new:    stx  fa_rec
        ldab #FR_N
        abx
        bsr  hcopy
        bsr  small              ; below TDIV squared it is
        bcs  .p
        ldx  #shook
        bsr  hookx
        bsr  shook
        ovsub OV_PRP,2
        ldaa kv_pk
        bne  .t
        ldaa #FT_C
        bra  .set
.t:     cmpa #2
        beq  .prp
.p:     ldaa #FT_P
        bra  .set
.prp:   ldaa #FT_PRP
.set:   ldx  fa_rec
        staa 0,x
        bsr  hdrop
        ldx  fa_rec
        ldaa 0,x
        cmpa #FT_C
        beq  loop
        ovsub OV_FSPL,2
        bra  loop
; a composite number: a power?
power:  stx  fa_rec
        ovsub OV_PPOW,0
        ldx  fa_rec
        ldaa kv_pk
        bne  .yes
        ldaa #FT_CN
        staa 0,x
        bra  loop
.yes:   ovsub OV_FSPL,1
        bra  loop
; a composite number to be split: the methods
split:  stx  fa_rec
        ovsub OV_PLAN,0
after:  tst  fx_found
        bne  .yes
        ldx  fa_rec             ; given up
        ldaa #FT_GAVE
        staa 0,x
        bra  loop
.yes:   ovsub OV_FSPL,0
        bra  loop

; stopped: a method skipped: the next one; or the whole run given up: what is known so far
stopped: ldx fa_wp
        stx  kv_wp
        clr  fx_found
        ldaa kv_why
        cmpa #R_SKIP
        bne  .up
        ovsub OV_PLAN,1
        bra  after
.up:    ldaa fa_m               ; (PROVE is given up altogether)
        beq  finish             ; (PHI and the others see to it themselves)
        cmpa #2
        bhs  .pv
        clr  kv_dst             ; FACTOR: what is known is shown, whatever it was part of
        bsr  finish
        clr  kv_run
        ovsub OV_SHOW,0
        jmp  main
.pv:
        ldx  pv_esc
        stx  kv_esc
        ldx  pv_esc+2
        stx  kv_ssp
        ldaa kv_why
        jmp  stop
; the end: kv_rl the list; the value is the smallest prime factor, or 1
finish: clr  kv_skp
        ldx  #0
        stx  kv_esc
        bsr  hook0
        ldx  fa_wp
        stx  kv_wp
        ldaa fa_m
        deca
        bne  .x
        tst  st_proof           ; every prime to be proved
        beq  .np
        ovsub OV_PROVE,3
.np:    bsr  hdrop
        ldx  kv_rl              ; the smallest prime
.f:     cpx  kv_lim
        beq  .v
        ldaa 0,x
        deca
        cmpa #1
        bls  .c
        bsr  fl_next
        bra  .f
.v:     bsr  hpush1
        bra  .k
.c:     ldab #FR_N
        abx
        bsr  hcopy
.k:     ldaa #OV_FSHOW
        staa kv_rk
.x:     rts
; small: carry set if the top number is below TDIV squared
small:  ldd  st_tdiv
        ldx  st_tdiv
        os   UT$UMUL
        std  kv_n
        stx  kv_n+2
        bsr  ilenw
        subd #4
        bhi  .no
        blo  .yes
        ldd  2,x
        subd kv_n
        bne  .x
        ldd  4,x
        subd kv_n+2
.x:     rts
.no:    clc
        rts
.yes:   ldd  st_tdiv            ; (3 bytes or fewer: TDIV over 4,096 settles it)
        subd #4096
        bcc  .sure
        clc                     ; (a low TDIV: the test will say)
        rts
.sure:  sec
        rts
sh_t:   fcl  "Prime check..."
        include "shook.inc"
        include "flnext.inc"
