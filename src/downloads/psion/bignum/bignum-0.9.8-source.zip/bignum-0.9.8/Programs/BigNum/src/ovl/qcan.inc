; qcan: carry clear if the sieve can take the number (its bits: kv_bits)
qcan:   ldab kv_tier
        ldx  #caps-1
        abx
        ldab 0,x
        beq  .no
        clra
        subd kv_bits
        rts
.no:    sec
        rts
caps:   fcb  184,168,148,0      ; the most bits, by tier (about four weeks, from the PC twin)
