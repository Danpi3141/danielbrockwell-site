p2_d    = kv_fs+12              ; D / 2
p2_u    = kv_fs+13              ; u
p2_t    = kv_fs+14              ; its first slot
p2_g    = kv_fs+15              ; steps left in the window
p2_c    = kv_fs+16              ; (2) v D's place in the window
p2_h    = kv_fs+18              ; (3) the end: B2
