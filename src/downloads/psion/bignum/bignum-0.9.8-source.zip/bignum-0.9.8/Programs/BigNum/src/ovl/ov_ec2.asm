; =====================================================================
; OV_EC2: ECM's second stage (from OV_ECM, its slots): Q in slots 4, 5; every prime q from B1 to 100 B1: q =
; v D - u or v D + u is caught where X(vD) Z(u) = X(u) Z(vD). D = 210 with 24 values of u, or 30 with 4; the
; primes come a window of 2,100 numbers at a time. fx_found = 1 and the factor pushed, or 0.
; Slots: 0, 1 vD Q; 2, 3 the one before; 4, 5 D Q; 6 (A+2)/4; 9, 10 X+Z, X-Z of the step; 11 the product;
; 12 X Z of vD Q; 7, 8, 13 work; from 14 on X, Z, X Z of each u Q.
; =====================================================================
        include "macros.inc"
        include "ckn.inc"
        include "fx.inc"
        include "ec.inc"
        include "ec2.inc"
        lastent ec2

ec2:    ldab #5                 ; the first stage's GCD, of Z
        bsr  sgcd
        bsr  kind
        beq  .s2
        bcc  hdrop              ; (both at once: the curve is lost)
        inc  fx_found
        rts
.s2:    bsr  hdrop
        ovsub OV_EC2A,0         ; the table, the start
        ldx  #hook
        bsr  hookx
        ldaa #CK_ECM2
        bsr  ckset
        bsr  ps_fill
.win:   bsr  safe
        ldab p2_d
        clra
        std  p2_c
        ldaa #10
        cmpb #105
        beq  .g
        ldaa #70
.g:     staa p2_g
.step:  bsr  mrun
        mol   M_MUL,12,0,1
        ldaa #14                ; the pairs of this step
        staa p2_t
        ldaa #1
        staa p2_u
.p:     bsr  cop
        bne  .np
        ldab p2_u               ; vD + u, vD - u: either prime?
        clra
        addd p2_c
        bsr  isp
        beq  .yes
        ldab p2_u
        clra
        std  zt
        ldd  p2_c
        subd zt
        bsr  isp
        bne  .no
.yes:   ldaa p2_t               ; (Xv - Xu)(Zv + Zu) - Xv Zv + Xu Zu
        ldab #7
        stab mi
        clr  mi+1
        staa mi+2
        ldab #M_SUB
        bsr  mop
        ldaa p2_t
        inca
        staa mi+2
        ldaa #8
        staa mi
        ldaa #1
        staa mi+1
        ldab #M_ADD
        bsr  mop
        bsr  mrun
        mo    M_MUL,7,7,8
        mol   M_SUB,7,7,12
        ldaa p2_t
        adda #2
        staa mi+2
        ldaa #7
        staa mi
        staa mi+1
        ldab #M_ADD
        bsr  mop
        bsr  mrun
        mol   M_MUL,11,11,7
.no:    ldaa p2_t
        adda #3
        staa p2_t
.np:    ldaa p2_u
        adda #2
        staa p2_u
        cmpa p2_d
        bls  .p
        bsr  step               ; the next step
        ldab p2_d
        clra
        asld
        addd p2_c
        std  p2_c
        dec  p2_g
        bne  .step
        bsr  prog
        ldd  ps_lo+1            ; the end?
        addd #2100
        std  zt
        ldab ps_lo
        adcb #0
        cmpb p2_h
        bhi  .end
        blo  .more
        ldd  zt
        subd p2_h+1
        bhs  .end
.more:  bsr  ps_win
        bra  .win
.end:   ldab #11
        bsr  sgcd
        bsr  kind
        beq  .none
        bcc  .none
        inc  fx_found
        rts
.none:  bra  hdrop
; prog: kv_done: the second stage is 36 of a curve's 64 units, after 28
prog:   clra                 ; (the place, over B2, both / 256)
        clrb
        std  kv_n
        ldd  ps_lo
        std  kv_n+2
        ldd  #36
        std  kv_na
        ldd  p2_h
        std  kv_nb
        bsr  muldiv
        ldd  fx_cur
        subd #1
        ldx  #64
        os   UT$UMUL
        xgdx
        addd kv_n+2
        addd #28
        std  kv_done
        rts
        include "cop.inc"
        include "isp.inc"
        include "echook.inc"
        include "ecst.inc"
        include "sgcd.inc"
        include "mhook.inc"
        include "fslot.inc"
        include "psn.inc"
        include "ckset.inc"
        include "cksafe.inc"
