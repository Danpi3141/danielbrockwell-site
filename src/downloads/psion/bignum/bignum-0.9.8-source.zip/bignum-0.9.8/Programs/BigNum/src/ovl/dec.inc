; decimal: the top number (which is used up) as decimal digits, two a byte, in memory taken below it:
; dg_at = their first byte, dg_sk = how many digits to skip there, dg_n = how many digits, dg_neg = $80
; if negative. kv_wp is left at the digits' room (the number is above it).
decimal: ldx  kv_wp
        stx  dg_at
        stx  dg_end
        ldaa 0,x
        anda #$80
        staa dg_neg
        bsr  ilen
        std  mal                ; the bytes left of the number
        inx
        inx
        stx  ma
        ldaa #155               ; groups of four digits: at most bytes x 155 / 256 + 2
        mul
        staa zt+1
        ldab mal
        ldaa #155
        mul
        addb zt+1
        adca #0
        addd #2
        asld
        bsr  walloc
.grp:   bsr  poll
        ldx  #0
        stx  ze
        ldd  mal
        beq  .no
        tstb
        beq  .ev
        inca
.ev:    std  zt
        ldx  ma                 ; the number / 10000
.l:     ldd  ze                 ; the remainder so far, and a byte
        asld
        asld
        ldab #209
        mul
        asld
        staa zm                 ; the quotient's byte, or up to 4 under it
        tab
        ldaa #$27
        mul
        stab zw
        ldaa zm
        ldab #$10
        mul
        adda zw
        std  zp
        ldaa ze+1
        ldab 0,x
        subd zp
.c:     subd #10000
        bcs  .ok
        inc  zm
        bra  .c
.ok:    addd #10000
        std  ze
        ldaa zm
        staa 0,x
        inx
        dec  zt+1
        bne  .l
        dec  zt
        bne  .l
        ldx  ma                 ; its leading zeros gone
        ldd  mal
.z:     tst  0,x
        bne  .nz
        inx
        subd #1
        bne  .z
.nz:    stx  ma
        std  mal
.no:    ldd  ze                 ; the four digits
        clr  zm
.h:     subd #100
        bcs  .h1
        inc  zm
        bra  .h
.h1:    addb #100
        ldx  dg_at
        dex
        dex
        stx  dg_at
        bsr  bcd
        stab 1,x
        ldab zm
        bsr  bcd
        stab 0,x
        ldd  mal
        bne  .grp
        clr  dg_sk              ; the zeros at the front (one digit stays)
        ldd  dg_end
        subd dg_at
        asld
        std  dg_n
.s:     ldd  dg_n
        subd #1
        beq  .x
        std  zt
        clra
        clrb
        bsr  dgch
        cmpa #'0'
        bne  .x
        inc  dg_sk
        ldd  zt
        std  dg_n
        bra  .s
.x:     rts
; bcd: B (0-99) as two digits in a byte
bcd:    clra
.t:     subb #10
        bcs  .u
        adda #16
        bra  .t
.u:     addb #10
        aba
        tab
        rts
        include "dgch.inc"
