        ifused fromslot
; fromslot: slot B pushed as a number
fromslot: bsr mslot
        std  zx
        pshb
        psha
        ldd  mn
        addd #2
        bsr  walloc
        ldd  mn
        std  0,x
        inx
        inx
        stx  zp
        pula
        pulb
        std  zx
        ldd  mn
        bra  cpbn
        endif
