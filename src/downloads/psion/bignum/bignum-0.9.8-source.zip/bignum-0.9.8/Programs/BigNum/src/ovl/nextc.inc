; nextc: B = the next character of the line that is not a space (0: none), past it
nextc:  ldx  kv_line
        ldab kv_tp
        cmpb 0,x
        bhi  .end
        abx
        ldab 0,x
        inc  kv_tp
        cmpb #32
        beq  nextc
        rts
.end:   inc  kv_tp
        clrb
        rts
