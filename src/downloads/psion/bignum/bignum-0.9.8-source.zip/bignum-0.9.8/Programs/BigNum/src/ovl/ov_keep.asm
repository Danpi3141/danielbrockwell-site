; =====================================================================
; OV_KEEP: the run kept in the file BIGKEEP (ck.inc). Entry 0: at a safe place of a method: it is written (and,
; if kv_ckd is 2, the run is left). 1: K on the pause screen: to be done at the next safe place (a device is asked
; for, if KEEP is off; carry set: none). 2: the file deleted (the run has come to its end).
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        include "fa.inc"
        include "qs.inc"
        entry safe_
        entry key
        lastent gone

key:    ldaa st_keep
        bne  .dev
        bsr  cls                ; which device?
        bsr  ln0
        bsr  pri
        fcl  "Keep on A, B, C?"
        bsr  out
.k:     bsr  getk
        cmpb #K_ON
        beq  .no
        subb #'A'-1
        bls  .k
        cmpb #3
        bhi  .k
        stab kv_ckv
        bra  .go
.dev:   staa kv_ckv
.go:    ldaa #2
        staa kv_ckd
        rts
.no:    sec
        rts

gone:   ldaa kv_ckv
        adda #'A'-1
        staa name+1
        clr  kv_ckw
        ldx  #name
        os   FL$DELN
        rts

; ---- written
safe_:  sts  ck_sp
        ldaa kv_ckd
        anda #3
        cmpa #2
        beq  .two
        clr  kv_ckd             ; timed: (a Datapak is written only when asked, but for the sieve's relations)
        bsr  timer
        ldaa st_keep
        staa kv_ckv
        bsr  pack
        bcc  .w
        ldaa kv_ckm
        cmpa #CK_QS
        bne  .x
        bra  .w
.two:   inc  ck_stop
.w:     clr  kv_ckd
        ldaa kv_ckv
        adda #'A'-1
        staa name+1
        ldaa kv_ckm             ; the sieve: only what is new, if the rest is there
        cmpa #CK_QS
        bne  .all
        tst  kv_ckw
        bne  .rel
.all:   ldx  #name
        os   FL$DELN
        ldx  #name
        os   FL$CRET
        bcs  kerr
        tab
        os   FL$RECT
        clra
        clrb
        std  ck_s
        std  q_svn
        std  q_svp
        bsr  base
        ldaa kv_ckm
        cmpa #CK_QS
        bne  .done
        bra  .r2
.rel:   ldx  #name
        os   FL$OPEN
        bcs  .all
        tab
        os   FL$RECT
.r2:    bsr  rels
.done:  ldaa #1
        staa kv_ckw
        tst  ck_stop
        beq  .x
        clr  kv_ckw             ; (it stays, whatever is shown next)
        ldaa #R_KEEP
        jmp  stop
.x:     inc  kv_full
        rts
kerr:   lds  ck_sp              ; it cannot be written: said, and the run goes on
        pshb
        bsr  cls
        pulb
        os   ER$MESS
        inc  kv_full
        rts
; timer: the next one
timer:  ldd  st_every           ; (18 hours at most: 16 bits of seconds)
        subd #1093
        bcs  .in
        ldd  #65520
        bra  .set
.in:    ldaa st_every+1
        ldab #60
        mul
        std  kv_ckt
        ldaa st_every
        ldab #60
        mul
        tba
        clrb
        addd kv_ckt
.set:   std  kv_ckt
        rts
; pack: carry set if the device is a Datapak
pack:   ldab st_keep
        decb
        beq  .no
        os   PK$SETP
        bcs  .no
        ldaa #0
        ldx  #0
        os   PK$SADD
        os   PK$RBYT
        bitb #2
        beq  .no
        sec
        rts
.no:    clc
        rts
; base: all but the relations
base:   ldx  kv_line            ; the line
        bsr  wrec
; V the variables it uses
        ldx  kv_vb
.v:     cpx  kv_hi
        beq  .vd
        stx  ck_p
        ldab 0,x
        bsr  used
        bne  .nv
        ldx  ck_p
        inx
        bsr  ilen
        addd #3
        ldx  ck_p
        stx  ck_a
        std  ck_n
        ldaa #'V'
        bsr  sect
.nv:    ldx  ck_p
        inx
        bsr  inext
        bra  .v
.vd:    tst  kv_esc             ; F, L: FACTOR
        beq  .nof
        ldaa kv_esc
        cmpa #OV_FACT
        bne  .nof
        ldd  fa_rec             ; (its record as a distance; the checksum of the number)
        pshb
        psha
        subd kv_rl
        std  fa_rec
        ldx  fa_wp
        pshx
        bsr  sum
        std  fa_wp
        ldx  #kv_fz
        stx  ck_a
        ldd  #18
        std  ck_n
        ldaa #'F'
        bsr  sect
        ldx  #kv_fx
        stx  ck_a
        ldd  #24
        std  ck_n
        ldaa #'F'
        bsr  sect
        ldx  kv_rl
        stx  ck_a
        ldd  kv_lim
        subd kv_rl
        std  ck_n
        ldaa #'L'
        bsr  sect
        pulx
        stx  fa_wp
        pulx
        stx  fa_rec
.nof:   bsr  ck_tab             ; S
        ldaa kv_ckm
        staa st
        bsr  ck_sum
        std  st+1
        ldd  kv_el
        std  st+3
        ldd  kv_el+2
        std  st+5
        ldd  #st+7
        std  zp
        inx
        inx
        inx
        inx
.sv:    ldd  0,x
        beq  .se
        std  zx
        ldab 2,x
        inx
        inx
        inx
        pshx
        clra
        bsr  cpb
        pulx
        bra  .sv
.se:    ldd  #st
        std  ck_a
        ldd  zp
        subd #st
        std  ck_n
        ldaa #'S'
        bsr  sect
        bsr  ck_tab             ; R
        bsr  ck_reg
        std  ck_n
        ldx  zx
        stx  ck_a
        ldaa #'R'
        bsr  sect
        ldd  ck_s               ; E
        std  st
        ldd  #st
        std  ck_a
        ldd  #2
        std  ck_n
        ldaa #'E'
        bra  sect
; used: Z if the line uses the variable B (ANS: if it has ANS in it)
used:   stab zm
        ldx  kv_line
        ldaa 0,x
        staa zt
.l:     tst  zt
        beq  .no
        inx
        dec  zt
        ldab 0,x
        bsr  upc
        ldaa zm
        cmpa #'@'
        beq  .ans
        cba                     ; the letter by itself?
        bne  .l
        tst  zt                 ; (the last character: none after it)
        beq  .p
        ldab 1,x
        bsr  .let
        beq  .l
.p:        dex
        cpx  kv_line            ; (the first character: none before it)
        beq  .fst
        ldab 0,x
        inx
        bsr  .let
        beq  .l
        clra
        rts
.fst:   clra
        rts
.ans:   cmpb #'A'
        bne  .l
        ldab 1,x
        bsr  upc
        cmpb #'N'
        bne  .l
        clra
        rts
.no:    inca
        rts
.let:   bsr  upc                ; Z: a letter
        cmpb #'A'
        blo  .n
        cmpb #'Z'
        bhi  .n
        cmpb #0
        beq  .n
        clra
        rts
.n:     ldaa #1
        rts
; rels: the relations and partial ones not yet written
rels:   ldd  q_rn
        subd q_svn
        beq  .p
        ldaa q_svn+1            ; the next
        ldab q_ub
        mul
        std  zt
        ldaa q_svn
        ldab q_ub
        mul
        tba
        clrb
        addd zt
        addd q_rel
        std  ck_a
        ldab q_ub
        clra
        std  ck_n
        ldaa #'Q'
        bsr  sect
        ldx  q_svn
        inx
        stx  q_svn
        bra  rels
.p:     ldd  q_svp              ; (some may have given way)
        subd q_pn
        bls  .p1
        ldd  q_pn
        std  q_svp
.p1:    ldd  q_pn
        subd q_svp
        beq  .x
        ldab q_ub               ; the next: down from the end
        addb #2
        stab zt
        ldaa q_svp+1
        inca
        mul
        std  zx
        ldaa q_svp
        ldab zt
        mul
        tba
        clrb
        addd zx
        std  zx
        ldd  q_pe
        subd zx
        std  ck_a
        ldab q_ub
        addb #2
        clra
        std  ck_n
        ldaa #'P'
        bsr  sect
        ldx  q_svp
        inx
        stx  q_svp
        bra  .p1
.x:     rts
; sect: a section A: the ck_n bytes at ck_a, 48 a record
sect:   staa ck_l
.r:     ldd  ck_n
        beq  .x
        subd #48
        bcc  .m
        addd #48
        bra  .g
.m:     ldd  #48
.g:     stab ck_c
        clra
        std  zt
        ldd  ck_n
        subd zt
        std  ck_n
        ldaa ck_l
        staa buf+1
        ldab ck_c
        aslb
        incb
        stab buf
        ldx  #buf+2
        stx  ck_b
.b:     ldx  ck_a
        ldaa 0,x
        inx
        stx  ck_a
        psha
        lsra
        lsra
        lsra
        lsra
        bsr  .d
        pula
        anda #15
        bsr  .d
        dec  ck_c
        bne  .b
        ldx  #buf
        bsr  wrec
        bra  .r
.d:     adda #'0'
        cmpa #'9'
        bls  .h
        adda #7
.h:     ldx  ck_b
        staa 0,x
        inx
        stx  ck_b
.x:     rts
; wrec: the record written, its bytes in the checksum
wrec:   pshx
        ldab 0,x
.s:     inx
        pshb
        ldab 0,x
        clra
        addd ck_s
        std  ck_s
        pulb
        decb
        bne  .s
        pulx
        os   FL$WRIT
        bcs  kerr
        rts
name:   fcl  "A:BIGKEEP"
ck_sp:  fdb  0
ck_s:   fdb  0
ck_p:   fdb  0
ck_a:   fdb  0
ck_n:   fdb  0
ck_b:   fdb  0
ck_l:   fcb  0
ck_c:   fcb  0
ck_stop: fcb 0
st:     rmb  32
        include "ck.inc"
buf:    rmb  100
