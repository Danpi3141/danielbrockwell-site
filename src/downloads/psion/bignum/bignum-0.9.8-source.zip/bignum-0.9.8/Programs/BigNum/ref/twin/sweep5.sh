#!/bin/bash
# tiers 2 and 3 near their caps, with the bases their memory allows
{ for d in 46 48 50 52; do for i in 1 2 3; do echo $d 112 1024 15 15 $((20+i)) 2 20 40 150 1e14; echo $d 128 1024 15 15 $((20+i)) 2 20 40 150 1e14; done; done
for d in 38 40 42 44 46 48; do for i in 1 2 3; do echo $d 64 1024 13 15 $((20+i)) 2 20 30 150 1e14; echo $d 56 512 13 15 $((20+i)) 2 20 30 150 1e14; done; done; } | xargs -P 10 -L 1 timeout 7200 ./Qs.exe
