// The plain functions against BigInt: GCD LCM JACOBI ABS SIZE SQRT NROOT FACT PRIMORIAL FIB LUC BINOM and the
// modular ones.   node tests/t_func.js [model] [seed]
'use strict';
const { BN, rng } = require('./lib');
const model = process.argv[2] || 'lz64';
const R = rng(+process.argv[3] || 1);
const g = new BN(model).start();
const cap = g.peekw('kv_cap') * 8;
let fails = 0, n = 0;
const fail = (s) => { console.log('FAIL', s); if (++fails > 12) process.exit(1); };
const chk = (t, want, secs) => { n++; const r = g.line(t, 6000); if (r.err || r.val !== want) fail(`${t}: got ${r.err ? 'error ' + r.err + ' at ' + r.pos : r.val} want ${want}`); else if (secs !== undefined) console.log(`  ${t}: ${(r.cycles / 921600).toFixed(1)} s`); return r; };
const bad = (t, e) => { n++; const r = g.line(t, 6000); if (r.err !== e) fail(`${t}: got error ${r.err} value ${r.val}, want error ${e}`); };
const abs = (x) => (x < 0n ? -x : x);
const gcd = (a, b) => { a = abs(a); b = abs(b); while (b) [a, b] = [b, a % b]; return a; };
const mod = (a, m) => ((a % m) + m) % m;
const jac = (a, n) => { a = mod(a, n); let t = 1n; while (a) { while (!(a & 1n)) { a >>= 1n; if ((n & 7n) === 3n || (n & 7n) === 5n) t = -t; } [a, n] = [n, a]; if ((a & 3n) === 3n && (n & 3n) === 3n) t = -t; a %= n; } return n === 1n ? t : 0n; };
const powm = (b, e, m) => { let r = 1n % m; b = mod(b, m); while (e) { if (e & 1n) r = r * b % m; b = b * b % m; e >>= 1n; } return r; };
const inv = (a, m) => { let [r0, r1, s0, s1] = [m, mod(a, m), 0n, 1n]; while (r1) { const q = r0 / r1; [r0, r1] = [r1, r0 - q * r1]; [s0, s1] = [s1, s0 - q * s1]; } return r0 === 1n ? mod(s0, m) : null; };
const root = (a, k) => { if (a < 0n) { return -(root(-a - 1n, k) + 1n); } let lo = 0n, hi = 1n; while (hi ** k <= a) hi *= 2n; while (hi - lo > 1n) { const m = (lo + hi) / 2n; if (m ** k <= a) lo = m; else hi = m; } return lo; };
const isp = (n) => { if (n < 2n) return false; for (let d = 2n; d * d <= n; d++) if (n % d === 0n) return false; return true; };
const S = (v) => String(v);
const big = (b) => { const k = R.int(5); return k === 0 ? (1n << BigInt(b)) - 1n : R.bits(b); };

if (!process.argv[4]) {
chk('GCD(0,0)', 0n); chk('GCD(0,5)', 5n); chk('GCD(5,0)', 5n); chk('GCD(-12,18)', 6n); chk('GCD(2**100,2**77*3)', 2n ** 77n); chk('LCM(4,6)', 12n); chk('LCM(0,5)', 0n); chk('LCM(0,0)', 0n); chk('LCM(-4,6)', 12n); chk('ABS(-7)', 7n); chk('ABS(0)', 0n);
for (let i = 0; i < 25; i++) { const c = big([1, 8, 30, 60][R.int(4)]), a = big([4, 8, 40, 90, 160][R.int(5)]) * c << BigInt(R.int(20)), b = big([4, 8, 40, 90, 160][R.int(5)]) * c << BigInt(R.int(20)); chk(`GCD(${a},${b})`, gcd(a, b)); }
for (let i = 0; i < 8; i++) { const a = big(60), b = big(50); chk(`LCM(${a},${b})`, a && b ? a * b / gcd(a, b) : 0n); }
chk('GCD(FACT(60),2**190-1)', gcd([...Array(60)].reduce((p, _, i) => p * BigInt(i + 1), 1n), 2n ** 190n - 1n));
chk('JACOBI(5,1)', 1n); chk('JACOBI(0,1)', 1n); chk('JACOBI(0,9)', 0n); chk('JACOBI(6,9)', 0n); chk('JACOBI(-1,7)', -1n); chk('JACOBI(1001,9907)', -1n); bad('JACOBI(3,8)', 5); bad('JACOBI(3,0)', 5); bad('JACOBI(3,-7)', 5);
for (let i = 0; i < 30; i++) { const m = big([4, 8, 30, 100][R.int(4)]) | 1n; let a = big([4, 8, 30, 110][R.int(4)]); if (R.int(3) === 0) a = -a; chk(`JACOBI(${a},${m})`, jac(a, m)); }
for (const [t, d, b] of [['0', 1, 0], ['9', 1, 4], ['10', 2, 4], ['10**30', 31, 100], ['10**30-1', 30, 100], ['2**127-1', 39, 127], ['-(10**50)', 51, 167], ['10**100-1', 100, 333], ['10**100', 101, 333], ['10**100+1', 101, 333], ['10**616', 617, 2047], ['10**616-1', 616, 2047]]) { chk(`SIZE(${t})`, BigInt(d)); if (g.peekw('kv_bits') !== b) fail(`SIZE(${t}) bits ${g.peekw('kv_bits')} want ${b}`); }
if (cap > 8000) { chk('SIZE(10**2465)', 2466n, 1); chk('SIZE(10**2465-1)', 2465n); }
for (let i = 0; i < 40; i++) { const e = 1 + R.int(150); const v = R.int(2) ? 10n ** BigInt(e) + BigInt(R.int(3) - 1) : big(1 + R.int(400)); if (v > 0n && S(v).length < 120) chk(`SIZE(${v})`, BigInt(S(v).length)); }
chk('SQRT(0)', 0n); chk('SQRT(1)', 1n); chk('SQRT(15)', 3n); chk('SQRT(16)', 4n); chk('SQRT(10**100)', 10n ** 50n); chk('SQRT(10**100-1)', 10n ** 50n - 1n); bad('SQRT(-1)', 5); chk('NROOT(27,3)', 3n); chk('NROOT(26,3)', 2n); chk('NROOT(-27,3)', -3n); chk('NROOT(-28,3)', -4n); chk('NROOT(5,1)', 5n); chk('NROOT(2**200,200)', 2n); chk('NROOT(2**200-1,200)', 1n); chk('NROOT(7,99999999)', 1n); chk('NROOT(0,5)', 0n); bad('NROOT(5,0)', 5); bad('NROOT(-4,2)', 5); bad('NROOT(5,-1)', 5);
for (let i = 0; i < 15; i++) { const k = BigInt(2 + R.int(9)), v = R.int(2) ? big(150) : (big(20) + 2n) ** k - BigInt(R.int(2)); if (S(v).length < 110) chk(`NROOT(${v},${k})`, root(v, k)); }
var fact = (k) => { let p = 1n; for (let i = 2n; i <= k; i++) p *= i; return p; };
for (const k of [0, 1, 2, 25, 100, 300]) chk(`FACT(${k})`, fact(BigInt(k)), k > 99 ? 1 : undefined); bad('FACT(-1)', 5); bad('FACT(99999)', 2);
var prml = (k) => { let p = 1n; for (let i = 2n; i <= k; i++) if (isp(i)) p *= i; return p; };
for (const k of [0, 1, 2, 3, 10, 100, 1480]) chk(`PRIMORIAL(${k})`, prml(BigInt(k)), k > 999 ? 1 : undefined);
var fib = (k) => { let a = 0n, b = 1n; for (let i = 0; i < k; i++) [a, b] = [b, a + b]; return a; };
for (const k of [0, 1, 2, 3, 10, 100, 1001, 2951]) { chk(`FIB(${k})`, fib(k), k > 999 ? 1 : undefined); if (k < 2000) chk(`LUC(${k})`, k ? fib(k - 1) + fib(k + 1) : 2n); } bad('FIB(60000)', 2); bad('FIB(-1)', 5);
var bin = (a, b) => { let p = 1n; for (let i = 0n; i < b; i++) p = p * (a - i) / (i + 1n); return p; };
chk('BINOM(5,0)', 1n); chk('BINOM(5,5)', 1n); chk('BINOM(5,6)', 0n); chk('BINOM(10,3)', 120n); chk('BINOM(0,0)', 1n); bad('BINOM(-5,2)', 5); chk('BINOM(10**20,3)', bin(10n ** 20n, 3n)); chk('BINOM(70000,69990)', bin(70000n, 10n)); chk('BINOM(65535,20)', bin(65535n, 20n)); chk('BINOM(2052,1026)', bin(2052n, 1026n), 1); chk('BINOM(64,32)', bin(64n, 32n));
if (cap < 4096) { bad('FACT(301)', 2); bad('PRIMORIAL(1481)', 2); bad('FIB(2952)', 2); bad('BINOM(2054,1027)', 2); }
else { chk('FACT(966)', fact(966n), 1); bad('FACT(967)', 2); chk('PRIMORIAL(5782)', prml(5782n), 1); bad('PRIMORIAL(5783)', 2); chk('FIB(11801)', fib(11801), 1); bad('FIB(11802)', 2); chk('BINOM(8198,4099)', bin(8198n, 4099n), 1); bad('BINOM(8200,4100)', 2); }
}
// ---- modular
const primes = [3n, 5n, 7n, 13n, 17n, 41n, 97n, 193n, 257n, 65537n, 1000003n, 2n ** 31n - 1n, 2n ** 61n - 1n, 2n ** 64n - 59n, 10n ** 15n + 37n, 2n ** 89n - 1n, 2n ** 127n - 1n, 3n * 2n ** 41n + 1n, 10n ** 30n + 57n];
chk('MODEXP(0,0,5)', 1n); chk('MODEXP(5,0,1)', 0n); chk('MODEXP(2,10,1000)', 24n); chk('MODEXP(-3,3,10)', 3n); chk('MODEXP(0,5,7)', 0n); bad('MODEXP(2,-1,7)', 5); bad('MODEXP(2,5,0)', 5); bad('MODEXP(2,5,-7)', 5); chk('MODEXP(7,1,9)', 7n); chk('MODEXP(7,15,9)', powm(7n, 15n, 9n));
for (let i = 0; i < 25; i++) { const m = big([3, 8, 30, 64, 120][R.int(5)]) + 1n, a = big([8, 60, 130][R.int(3)]), e = big([1, 5, 16, 40, 100][R.int(5)]); chk(`MODEXP(${a},${e},${m})`, powm(a, e, m)); }
bad('MODINV(2,4)', 4); bad('MODINV(0,5)', 4); chk('MODINV(1,1)', 0n); chk('MODINV(3,7)', 5n); chk('MODINV(3,8)', 3n); chk('MODINV(-3,8)', inv(-3n, 8n)); chk('MODINV(1,2)', 1n); bad('MODINV(5,0)', 5); chk('MODINV(7,2**100)', inv(7n, 2n ** 100n));
for (let i = 0; i < 30; i++) { const m = big([3, 8, 30, 64, 120, 200][R.int(6)]) + 1n, a = big([8, 60, 130][R.int(3)]); const v = inv(a, m); if (v === null) bad(`MODINV(${a},${m})`, 4); else chk(`MODINV(${a},${m})`, v); }
for (let i = 0; i < 12; i++) { let m = big([4, 20, 60][R.int(3)]) + 1n, n2 = big([4, 20, 60][R.int(3)]) + 1n; const a = big(40), b = big(40); if (gcd(m, n2) !== 1n) { bad(`CRT(${a},${m},${b},${n2})`, 4); continue; } const x = mod(a + m * (mod((b - a) * (inv(m, n2) || 0n), n2)), m * n2); chk(`CRT(${a},${m},${b},${n2})`, x); }
chk('MODSQRT(0,7)', 0n); chk('MODSQRT(1,2)', 1n); bad('MODSQRT(3,7)', 5); bad('MODSQRT(1,8)', 5); bad('MODSQRT(2,0)', 5);
for (const p of primes) for (let i = 0; i < 2; i++) { const r0 = big(60) % p, a = r0 * r0 % p; n++; const r = g.line(`MODSQRT(${a},${p})`, 6000); if (r.err || r.val * r.val % p !== a || r.val >= p) fail(`MODSQRT(${a},${p}): ${r.err} ${r.val}`); }
console.log(fails ? `${fails} FAILED` : `t_func ${model} ok (${n} checks)`);
process.exit(fails ? 1 : 0);
