; =====================================================================
; OV_FLINE: the factor fs_j on the line fs_l of the factors' screen
; =====================================================================
        include "macros.inc"
        include "fa.inc"
        include "fs.inc"
        lastent factor

; factor: the factor fs_j on the line fs_l: its label, its digits and its power
factor: ldab fs_j
        bsr  copyf
        ovsub OV_DIGS,0
        ldaa fs_l
        bsr  ln
        ldab fs_j
        bsr  nth
        stx  kv_ia
        ldab 0,x
        ldx  #lbl
        abx
        abx
        abx
        ldab #3
.lb:    ldaa 0,x
        cmpa #32
        beq  .ld
        bsr  putc
        inx
        decb
        bne  .lb
.ld:    ldd  kv_digs
        bsr  putw
        tst  kv_four
        bne  .four
        bsr  ecm                ; two lines: how far ECM got; which of how many, at the right
        ldab #4
        ldaa fs_n
        cmpa #10
        blo  .r5
        incb
        incb
.r5:    bsr  rcol
        ldab fs_j
        incb
        clra
        bsr  putw
        bsr  putsl
        ldab fs_n
        clra
        bsr  putwo
        bsr  ln1
        ldab kv_w
        bra  .num
.four:  bsr  putsp
        ldd  kv_p               ; the number after the label, at column 4 or later
        subd #kv_lbuf
        cmpb #4
        bhs  .fc
        ldab #4
        pshb
        bsr  col
        pulb
.fc:    negb
        addb kv_w
.num:   stab fs_w
        clr  fs_x               ; room for the power
        bsr  expo
        subd #1
        beq  .px
        ldab #2
        stab fs_x
        bsr  expo
        ldx  #tens
.pl:    subd 0,x
        bcs  .pd
        addd 0,x
        inc  fs_x
        inx
        inx
        bra  .pl
.pd:    ldab fs_w
        subb fs_x
        stab fs_w
.px:    ldab fs_j
        bsr  copyf
        bsr  decimal
        ldab fs_w
        clra
        subd dg_n
        bcs  .cut
        ldab dg_n+1
        bsr  digs
        bra  .pw
.cut:   ldaa fs_c               ; (the first one cut)
        inca
        bne  .c2
        ldaa fs_j
        staa fs_c
.c2:    ldab fs_w
        subb #3
        bsr  digs
        ldab #3
        ldaa #'.'
.dt:    bsr  putc
        decb
        bne  .dt
.pw:    tst  fs_x
        beq  .x
        ldaa #'^'
        bsr  putc
        bsr  expo
        bsr  putw
.x:     bra  out
; expo: D = the power
expo:   ldab fs_j
        bsr  nth
        ldd  FR_E,x
        rts
tens:   fdb  10,100,1000,10000,65535
; digs: the first B digits at the pen
digs:   stab fs_w
        clra
        clrb
.l:     pshb
        bsr  dgch
        bsr  putc
        pulb
        clra
        incb
        cmpb fs_w
        bne  .l
        rts
lbl:    fcc  "U  P  PRPC  C  C  "
        include "fcopy.inc"
        include "fecm.inc"
        include "flnext.inc"
        include "dec.inc"
