; ckpeek: as ckset, but the rest is still looked for
ckpeek: staa kv_ckm
        ldaa kv_ckd
        bpl  .n
        ovsub OV_CKL,3
        rts
.n:     clc
        rts
