; =====================================================================
; Start, the main loop, errors, leaving, and long runs (progress, stopping)
; =====================================================================

; from the start-up code (kinit.asm), which the first overlay goes over
kgo:    ovcall OV_INIT,0        ; the settings, the rows' code
main:   clr  kv_ckd
        lds  kv_sp
        clr  kv_run
        ldd  kv_cap0
        std  kv_cap
        ldx  kv_vb              ; nothing on the stack of numbers
        stx  kv_wp
        ldx  kv_lo
        stx  kv_lim
        stx  kv_osp
        bsr  alpha
        ovcall OV_EDIT,0        ; a line
main_go: lds kv_sp
        ovcall OV_EVAL,0        ; checked (and a command carried out)
        bsr  runon              ; a run like any other, that only shows itself if it takes a while
        ovcall OV_EVAL,1        ; worked out
        clr  kv_run
        ovcall OV_SHOW,0        ; the result, kept in ANS or a variable
        bra  main

; err: the error B (E_...): back to the line, with the cursor at kv_epos
errbig: ldab #E_BIG
        fcb  $8C
errarg: ldab #E_ARG
err:    lds  kv_sp
        stab kv_err
        bra  main

; ---- leave: back to the launcher (from any depth) ----------------------
leave:  lds  kv_sp
        ldab kv_kbst
        os   KB$STAT
        tst  kv_four
        beq  .x
        ldaa kv_oldm
        os   DP$MSET
.x:     bsr  cls
        ldd  #ZP_N              ; the zero page as it was (KB$BREK looks at OPL's escape flag there)
        std  T0
        pulx
        ldd  #ZP_1
        os   UT$CPYB
        os   KB$BREK            ; (ON/CLEAR still down would pause the OPL that called: wait until it is up)
        os   KB$FLSH
        ldd  kv_osk
        std  RTA_SP             ; the memory given back
        ldx  #0
lv_x:   rts                     ; (tests stop here)

; ---- keys ---------------------------------------------------------------
; getk: wait for a key: B (letters in upper case)
getk:
t_idle: os   KB$TEST            ; (tests stop here)
        tstb
        bne  .k
        slp
        bra  t_idle
.k:     os   KB$GETK
upc:    cmpb #'a'
        blo  .x
        cmpb #'z'
        bhi  .x
        subb #32
.x:     rts
; alpha: letters, capitals
alpha:  clrb
        os   KB$STAT
        rts
; bell: a short beep
bell:   ldd  #120
        ldx  #60
        os   BZ$TONE
        rts

; ---- long runs ----------------------------------------------------------
; poll: called often while the numbers work (A, B, X and T0-T11 may change; everything a long job
; needs is elsewhere). A key: ON/CLEAR pauses, S skips. Once a second: the time counted, the battery
; looked at (KB$TEST), the display brought up to date.
poll:   ldaa KBB_NKYS
        bne  poll_k
        ldaa TMB_SECS
        cmpa kv_sec
        bne  .tick
        rts
.tick:  tab                     ; the seconds that have passed
        subb kv_sec
        bpl  .p
        addb #60
.p:     staa kv_sec
        tst  kv_run             ; (the time of a run)
        beq  .q
        clra
        addd kv_el+2
        std  kv_el+2
        bcc  .q
        ldx  kv_el
        inx
        stx  kv_el
.q:     ldx  kv_ckt             ; a run to be kept now and then
        beq  .nk
        dex
        stx  kv_ckt
        bne  .nk
        inc  kv_ckd
.nk:    ldx  TMW_TCNT           ; (not switched off for want of keys)
        stx  TMW_TOUT
        os   KB$TEST            ; (a low battery: the OS says so and switches off; it goes on here)
        tstb
        bne  poll_k
        ldaa kv_tier            ; (the smallest tier: every fourth second, as each time costs two overlays)
        cmpa #4
        bne  phook
        ldaa kv_el+3
        anda #3
        beq  phook
        tst  kv_full
        beq  poll_x
phook:  tst  kv_run
        beq  poll_x
        ldaa kv_hov             ; the display (if the overlay it is in is there)
        beq  .h
        cmpa kv_res
        bne  poll_x
.h:     ldx  kv_hook
        beq  poll_x
        jmp  0,x
; hookx: the display's routine is X, in this overlay; hook0: the one for those that have none
hook0:  clr  kv_ckm             ; (nothing to keep)
        ldx  #wkhook
        clr  kv_hov
        bra  hookx2
hookx:  ldaa kv_res
        staa kv_hov
        inc  kv_full
hookx2: stx  kv_hook
        rts
poll_k:   os   KB$GETK
        tst  kv_run
        beq  poll_x             ; (not in a run: the key is lost)
        bsr  upc
        cmpb #K_ON
        beq  pause
        cmpb #'S'
        bne  poll_x
        tst  kv_skp             ; nothing to skip to?
        beq  poll_x
        ldaa #R_SKIP
; stop: the run left: A = R_SKIP, R_KEEP or R_DROP: to the overlay and entry kv_esc, with the stack as
; it was at kv_ssp (so its rts goes back to whoever called the driver that set it)
stop:   staa kv_why
        ldd  kv_esc
        beq  main               ; (nothing to go back to but the line)
        lds  kv_ssp
        bra  ov_call
; wkhook: the display of a run that has none of its own
wkhook: ldaa kv_run
        deca
        bne  .w
        tst  kv_full
        beq  poll_x
        clr  kv_full
        bsr  cls
        bsr  ln0
        bsr  .w
        bsr  out
        ldaa kv_h
        deca
        bra  onstop
.w:     bsr  pri
        fcl  "Working..."
        rts
onstop: bsr  ln
        bsr  pri
        fcl  "ON=stop"
        bra  out
poll_x: rts
pause:  ldaa #2                 ; (the display's routine only says what it is)
        staa kv_run
        ldaa kv_four            ; on line 0 after "Paused: ", or on line 1
        eora #1
        bsr  ln
        ldab kv_four
        aslb
        aslb
        aslb
        bsr  col
        bsr  phook
        ovsub OV_PAUSE,0        ; the run goes on: B = 0; else the code
        ldaa #1
        staa kv_run
        tstb
        beq  .go
        tba
        bra  stop
.go:    ldaa TMB_SECS           ; (the time paused does not count)
        staa kv_sec
        inc  kv_full            ; everything drawn again
        bra  phook
; part: a part of a run starts: D units
part:   std  kv_tot
        ldd  #0
        std  kv_done
        coma                    ; (no units: the time left is to be worked out)
        std  kv_ld
        ldd  kv_el
        std  kv_e0
        ldd  kv_el+2
        std  kv_e0+2
        rts
; runon: a run starts: the clock from nothing
runon:  clr  kv_skp
        bsr  hook0
        ldx  #0
        stx  kv_esc
        stx  kv_el
        stx  kv_el+2
        stx  kv_e0
        stx  kv_e0+2
        stx  kv_ext
        stx  kv_ext+2
        dex
        stx  kv_ld
        ldaa TMB_SECS
        staa kv_sec
        ldaa #1
        staa kv_run
        staa kv_full
        rts
