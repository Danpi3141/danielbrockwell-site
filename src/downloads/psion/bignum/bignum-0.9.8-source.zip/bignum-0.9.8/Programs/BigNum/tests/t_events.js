// Unusual events at random moments while random work goes on: packs put in, taken out, full, write-protected; a low
// battery; switched off and on; the clock set; keys held down, typed ahead, with SHIFT, CAP and NUM; the menu. After each:
// the kernel's code as it was, the pointers in order, sums still right.   node tests/t_events.js [model] [seed] [minutes]
'use strict';
const { BN, HZ, rng } = require('./lib');
const model = process.argv[2] || 'lz64', seed = +process.argv[3] || 1, mins = +process.argv[4] || 60;
const R = rng(seed), pick = (a) => a[R.int(a.length)];
const cm = /cm/.test(model);
const g = new BN(model, Object.assign(process.env.BB ? { build: process.env.BB } : {}, cm ? {} : { packC: { type: 1, size: 32 } })), m = g.m;
let low = false; const r0 = m.bus.read.bind(m.bus); m.bus.read = (a) => { const v = r0(a); return a === 0x15 && low ? v | 1 : v; };
g.start(); g.wait();
let small = g.peek('kv_tier') === 4; const hist = []; const note = (s) => { hist.push(s); if (hist.length > 40) hist.shift(); };
const fail = (s) => { console.log(`FAIL ${model} seed ${seed}: ${s}\n${g.text()}\non ${m.isOn()} pc ${m.dbg.pc().toString(16)} last: ${hist.join(' ~ ')}`); process.exit(1); };
let code = null; const ex = new Set();
const poll = () => { m.runTo([g.addr('poll'), g.addr('t_idle')], HZ * 5); };
const learn = () => { const c = m.read(g.base, g.sym.kv_vars[0]); if (code) for (let i = 0; i < c.length; i++) if (c[i] !== code[i]) ex.add(i); code = c; };
const learnAll = () => { const kp = [g.peek('st_keep'), g.peek('st_log')]; g.poke('st_keep', 0); g.poke('st_log', 0); code = null; ex.clear(); learn(); for (const l of ['FACT(60)*FACT(50)', 'FACTOR(2**64+1)', 'ISPRIME(2**127-1)', '10**60/7', small ? '1' : 'QS(10007*1000003)']) { g.line(l, 2000); g.wait(); learn(); } g.poke('st_keep', kp[0]); g.poke('st_log', kp[1]); };
const check = () => {
  const c = m.read(g.base, g.sym.kv_vars[0]); for (let i = 0; i < c.length; i++) if (c[i] !== code[i] && !ex.has(i)) fail(`code changed at ${i.toString(16)}`);
  const [lo, lim, wp, vb, hi] = ['kv_lo', 'kv_lim', 'kv_wp', 'kv_vb', 'kv_hi'].map((n) => g.peekw(n));
  if (!(lo <= lim && lim <= wp && wp <= vb && vb <= hi)) fail(`pointers ${[lo, lim, wp, vb, hi].map((x) => x.toString(16))}`);
  if (m.peekw(0xA5) > lo || m.peekw(0x2040) > m.peekw(0xA5)) fail(`memory ${m.peekw(0x2040).toString(16)} ${m.peekw(0xA5).toString(16)} ${lo.toString(16)}`);
};
const dis = () => { low = false; for (let i = 0; i < 5 && !m.isOn(); i++) { m.press('ON', 6, 6); m.runSeconds(0.6); } };
const atKey = (s) => m.runTo([g.addr('t_idle')], HZ * s) === g.addr('t_idle');
const osmsg = () => /space key|SPACE key|touche|taste|TASTE|ESPACE|espace|Leertaste|LEER/i.test(g.text()) && !atKey(0.05);
let quits = 0, works = 0, events = 0, changed = false;
const home = () => {
  for (let i = 0; i < 80; i++) {
    dis(); if (!m.isOn()) continue;
    if (/TRAP/.test(g.text())) fail('TRAP');
    if (m.peekw(0xA5) > g.base) return false;                                        // (it has left: the pack was changed, or Q on the menu)
    if (g.atLine() && atKey(1)) { if (/Quit\?/.test(g.text())) { m.poke(0x76, 78); m.run(HZ / 2); continue; } return true; }
    const k = /Paused/.test(g.text()) ? 65 : /Quit\?|Resume\?|Replace/.test(g.text()) ? 78 : /ALARM/i.test(g.text()) ? 1 : [1, 32, 1, 65, 32][i % 5];
    m.poke(0x76, k); if (k === 32 || /ALARM/i.test(g.text())) m.press(k === 32 ? 'SPACE' : 'ON', 4, 3); m.run(HZ * (i < 40 ? 1 : 5));
  }
  fail('never back at the line');
};
const start = () => { m.insertPack(g.bdir + '/BIGNUM.opk', 0); for (let i = 0; i < 12; i++) { dis(); m.press('SPACE', 3, 4); m.press('ON', 3, 8); m.runSeconds(0.3); } m.poke(0x7B, 0); g.start(); g.wait(); small = g.peek('kv_tier') === 4; learnAll(); };
learnAll();
const jobs = ['FACT(200)', '2**999/3**50', 'FACTOR(2**67-1)', 'ISPRIME(2**521-1)', 'NEXTPRIME(10**40)', 'MODEXP(3,2**521-2,2**521-1)', 'LLT(521)', 'RHO(10000019*(10**24+7))', 'PM1(2**89-1)', 'ECM(10**30+57,2)', 'PROVE(2**107-1)', 'SQRT(10**300)', 'FACTOR(2**101-1)', 'QS(10007*1000003)', 'QS(353890612479965357292787308697)', 'SAVE A,"C:NN"', 'SAVE A,"NN"', 'LOAD B,"C:NN"', 'LOAD B,"NN"', 'LOG', 'RESUME', 'BENCH', 'VARS', 'SET', 'HELP', 'SET KEEP C:', 'SET KEEP A:', 'SET KEEP OFF', 'SET LOG C:', 'SET LOG A:', 'SET LOG OFF', 'SET EVERY 1', 'A=3**500', 'CLR', 'SET PROOF ON', 'SET PROOF OFF', 'SET BEEP ON', 'FACTOR(10**20+39)*FACTOR(91)'];
const send = (l) => { g.wait(); m.write(g.peekw('kv_line'), [l.length, ...[...l].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', l.length); m.poke(0x76, 13); m.run(5000); };
const KEYS = ['A', 'B', 'C', 'K', 'P', 'S', 'V', 'X', 'EXE', 'ON', 'UP', 'DOWN', 'LEFT', 'RIGHT', 'DEL', 'MODE', 'SPACE', 'M', 'Q', 'N'];
const EV = {
  off: () => { m.poke(0x7C, 1); m.pokew(0x7D, 1); m.runSeconds(3 + R.int(4)); if (m.isOn()) { m.poke(0x7C, 0); } else m.runSeconds(R.int(3) ? 2 : 1200); dis(); m.poke(0x7C, 0); },
  low: () => { low = true; m.runSeconds(1 + R.int(4)); m.runSeconds(R.int(5)); low = false; dis(); },
  lowdip: () => { low = true; m.run(R.int(200000)); low = false; },
  clock: () => { const t = m.read(0x20C5, 6); const k = R.int(4); if (k === 0) m.write(0x20C5, [t[0], 11, 30, 23, 59, 50 + R.int(9)]); else if (k === 1) m.write(0x20C8, [R.int(24), R.int(60), R.int(60)]); else if (k === 2) m.write(0x20C5, [99 + R.int(30), R.int(12), R.int(28), R.int(24), R.int(60), R.int(60)]); else m.write(0x20CA, [R.int(60)]); m.runSeconds(R.int(5)); },
  hold: () => { const k = pick(KEYS); m.keyDown(k); m.runSeconds(0.5 + R.int(30) / 10); m.keyUp(k); m.runSeconds(0.1); },
  ahead: () => { const n = 2 + R.int(18); for (let i = 0; i < n; i++) m.press(pick(KEYS.filter((k) => k !== 'MODE')), 1, 1 + R.int(2)); },
  shift: () => { m.keyDown('SHIFT'); m.runTicks(1); m.press(pick(['A', 'F', 'K', 'UP', 'DOWN', 'LEFT', 'RIGHT', 'DEL', 'Z', 'M', 'EXE', 'ON', 'MODE']), 2, 2); m.keyUp('SHIFT'); m.runTicks(2); },
  two: () => { const a = pick(KEYS), b = pick(KEYS); m.keyDown(a); m.runTicks(1); m.keyDown(b); m.runTicks(1 + R.int(6)); m.keyUp(a); m.keyUp(b); m.runTicks(2); },
  cout: () => { if (!cm) m.removePack(1); },
  cnew: () => { if (!cm) m.emptyPack(pick([1, 1, 2, 0]), pick([8, 16, 32]), 1); },
  mode: () => { m.press('MODE', 3, 6); m.runSeconds(0.3 + R.int(3)); m.press(pick(['I', 'V', 'S', 'B', 'L', 'R', 'ON', 'Q', 'EXE', 'DOWN', 'RIGHT']), 3, 6); m.runSeconds(R.int(4)); },
  bpull: () => { if (R.int(4)) return; const t = 1 + R.int(2); m.removePack(0); if (t === 1) { m.runSeconds(1); m.insertPack(g.bdir + '/BIGNUM.opk', 0); } else m.runSeconds(3); changed = true; },
  wait: () => m.runSeconds(R.int(10)),
  kbstat: () => { m.poke(0x7B, pick([0, 1, 0x40, 0x41])); },
};
const t0 = m.cycles();
while ((m.cycles() - t0) / HZ < mins * 60) {
  if (!home()) { if (m.peekw(0xA5) < g.base) fail('did not leave'); quits++; try { start(); } catch (e) { if (!/cannot select/.test(e.message)) throw e; note('(the OS would not start it: ended)'); break; } continue; }
  if (!changed) check(); changed = false;
  if (R.int(5) === 0) {
    const lg = g.peek('st_log'), kq = g.peek('st_keep'); g.poke('st_log', 0); g.poke('st_keep', 0); m.poke(0x7C, 0);                         // (a log on a pack that is not there has an error after each result)
    const r = g.line('12345678901234567890*98765432109876543210', 2000); if (r.err ? r.err !== 7 : r.val !== 1219326311370217952237463801111263526900n) fail(`a product: ${r.err} ${r.val}`);
    const q = g.line('2**300%(10**20+39)', 2000); if (q.err ? q.err !== 7 : q.val !== 2n ** 300n % (10n ** 20n + 39n)) fail(`a remainder: ${q.err} ${q.val}`);
    const f = g.line('GCD(FACT(40),6**50)', 2000); let k = 1n; for (let i = 2n; i <= 40n; i++) k *= i; let a = k, b = 6n ** 50n; while (b) [a, b] = [b, a % b]; if (f.err ? f.err !== 7 : f.val !== a) fail(`a GCD: ${f.err} ${f.val}`);
    if (!home()) { quits++; start(); continue; }
    g.poke('st_log', lg); g.poke('st_keep', kq);
  }
  const l = pick(jobs); note(l); works++; send(l); m.runSeconds(R.int(4) ? R.int(20) : 60 + R.int(200));
  const n = R.int(5);
  for (let i = 0; i < n; i++) { const e = pick(Object.keys(EV)); note(e); events++; EV[e](); if (/TRAP/.test(g.text())) fail('TRAP after ' + e); m.runSeconds(R.int(6)); }
}
if (home()) check();
console.log(`t_events ${model} seed ${seed}: ${works} jobs, ${events} events, left ${quits} times: ok`);
