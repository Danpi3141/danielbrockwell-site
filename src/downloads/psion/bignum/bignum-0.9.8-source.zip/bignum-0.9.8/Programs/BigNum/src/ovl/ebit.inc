; ebit: D = a bit's number: B = it (Z)
ebit:   std  zt
        ldx  mx_e
        bsr  ilen2
        pshb
        psha
        ldd  zt
        lsrd
        lsrd
        lsrd
        std  zp
        pula
        pulb
        subd zp
        stx  zp
        addd zp
        xgdx
        ldaa 1,x                ; (2 for the length, less 1)
        ldab zt+1
        andb #7
.s:     decb
        bmi  .d
        lsra
        bra  .s
.d:     tab
        andb #1
        rts
ilen2:  ldd  0,x
        anda #$7F
        rts
