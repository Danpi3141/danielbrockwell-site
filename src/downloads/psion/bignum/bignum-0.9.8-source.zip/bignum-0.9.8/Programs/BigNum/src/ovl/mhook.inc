; the display of a method: fx_m its number (OV_HEAD's names), hk_l the second line; hk_q what two lines
; begin with; hk_3 the third line (pr_pct)
hook:   ldaa kv_run
        deca
        bne  hk_q               ; (paused: only what it is)
        tst  kv_four
        beq  .two
        tst  kv_full
        beq  .p
        ovsub OV_HEAD,0
.p:     bsr  ln1
        bsr  hk_l
        bsr  out
        bsr  ln2
        bsr  hk_3
        bra  out
.two:   clr  kv_full
        bsr  ln0
        bsr  hk_q
        bsr  putsp2
        bra  pr_two
