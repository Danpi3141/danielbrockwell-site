; =====================================================================
; OV_WITT: t = 2 (a a + D) / (a a - D) modulo the number at pv_m, for pv_a and pv_d: pushed. Carry set: there is
; none (a a = D, or the divisor has no inverse). The square test of a proof by N-1 is OV_SQT's.
; =====================================================================
        include "macros.inc"
        include "pv.inc"
        lastent t_

t_:     bsr  aa                 ; 2 (a a + D)
        ldab pv_d
        clra
        bsr  hpush
        bsr  hadd
        bsr  hdup
        bsr  hadd
        bsr  aa                 ; a a - D modulo N
        ldab pv_d
        clra
        bsr  hpush
        bsr  hsub
        ldx  pv_m
        bsr  hcopy
        ovsub OV_DIV,1
        ldx  kv_wp
        ldd  0,x
        beq  .none
        ldx  pv_m
        bsr  hcopy
        ovsub OV_MINV,0
        bsr  hmul
        ldx  pv_m
        bsr  hcopy
        ovsub OV_DIV,1
        clc
        rts
.none:  bsr  hdrop2
        sec
        rts
aa:     ldaa pv_a
        tab
        mul
        bra  hpush
