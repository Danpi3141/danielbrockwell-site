; =====================================================================
; OV_MSQR: MODSQRT(a, p): a square root of a modulo the prime p (Tonelli and Shanks)
; =====================================================================
        include "macros.inc"
        lastent f_msqr

sq_e    = kv_fs+8               ; the arguments' end
sq_s    = kv_fs+10              ; p - 1 = q 2 to the s
sq_z    = kv_fs+12              ; a number that is not a square
sq_i    = kv_fs+14
sq_q    = kv_fs+16              ; items: q, (q-1)/2, a modulo p
sq_h    = kv_fs+18
sq_a    = kv_fs+20
f_msqr: ldx  kv_wp              ; p positive
        ldd  0,x
        beq  .arg
        bmi  .arg
        bsr  i2
        bsr  inext
        stx  sq_e
        bsr  hswap              ; p a -> p, a modulo p
        bsr  hover
        ovsub OV_DIV,1
        ldx  kv_wp
        ldd  0,x
        beq  .num               ; 0: 0
        bsr  i2                 ; p even: only 2 will do
        ldab 1,x
        decb
        bne  .big
        ldab 2,x
        cmpb #2
        beq  .num               ; (a is 1)
.big:   bsr  inext
        dex
        ldab 0,x
        lsrb
        bcc  .arg
        bsr  hdup               ; a must be a square modulo p
        bsr  hover3
        ovsub OV_FN,2
        bsr  isone
        bne  .arg
        bsr  hdrop
        ldd  #2                 ; the first number that is not
.z:     std  sq_z
        bsr  hpush
        bsr  hover3
        ovsub OV_FN,2
        ldx  kv_wp
        ldaa 0,x
        psha
        bsr  hdrop
        pula
        tsta
        bmi  .zz
        ldd  sq_z
        addd #1
        cmpb #100               ; (p is not a prime, or a square)
        beq  .arg
        bra  .z
.arg:   bra  errarg
.num:   ldx  sq_e
        bra  hslx
.zz:    ldx  kv_wp              ; p a: q and s
        stx  sq_a
        bsr  hover
        ldx  kv_wp              ; (p is odd: p-1 is its last byte less 1)
        bsr  inext
        dex
        dec  0,x
        ldx  #0
        stx  sq_s
.h:     bsr  half
        ldx  sq_s
        inx
        stx  sq_s
        ldx  kv_wp
        bsr  inext
        dex
        ldab 0,x
        lsrb
        bcc  .h
        ldx  kv_wp
        stx  sq_q
        bsr  hdup               ; (q-1)/2
        bsr  half
        ldx  kv_wp
        stx  sq_h
        ldx  sq_a               ; p
        bsr  inext
        mset 8,6,7
        bsr  hook0
        ldaa #1
        staa mx_w
        ldx  sq_a               ; a in 5
        ldab #5
        bsr  toslot
        ldd  sq_z               ; z in 1
        bsr  zslot
        bsr  mrun
        mo    M_MUL,5,5,7
        mol   M_MUL,1,1,7
        ldx  sq_q               ; c = z to the q, in 4
        stx  mx_e
        bsr  mexp
        bsr  mrun
        mo    M_CPY,4,0,0
        mo    M_CPY,1,5,5
        mol   M_CPY,0,6,6
        ldx  sq_h               ; w = a to the (q-1)/2; x = w a (2), t = w x (3)
        stx  mx_e
        ldd  0,x
        beq  .w1
        bsr  mexp
.w1:    bsr  mrun
        mo    M_MUL,2,0,5
        mol   M_MUL,3,0,2
.loop:  ldab #3                 ; t = 1: done
        bsr  is1
        beq  .done
        bsr  mrun               ; the least i with t to the 2**i = 1
        mol   M_CPY,0,3,3
        clra
        clrb
.i:     addd #1
        std  sq_i
        subd sq_s
        bhs  .arg               ; (p is not a prime)
        bsr  mrun
        mol   M_SQR,0,0,0
        clrb
        bsr  is1
        beq  .got
        ldd  sq_i
        bra  .i
.got:   ldd  sq_s               ; b = c to the 2**(s-i-1)
        subd sq_i
        ldx  sq_i
        stx  sq_s
.b:     subd #1
        beq  .bd
        pshb
        psha
        bsr  mrun
        mol   M_SQR,4,4,4
        pula
        pulb
        bra  .b
.bd:    bsr  mrun
        mo    M_MUL,2,2,4
        mo    M_SQR,4,4,4
        mol   M_MUL,3,3,4
        bra  .loop
.done:  bsr  mrun               ; x squared must be a
        mol   M_SQR,0,2,2
        clrb
        bsr  mslot
        pshb
        psha
        ldab #5
        bsr  mslot
        pulx
        bsr  cmpn
        bne  .arg
        ldab #1
        bsr  sone
        bsr  mrun
        mol   M_MUL,2,2,1
        ldab #2
        bsr  fromslot
        bra  .num
; is1: Z if slot B is 1 (slot 6)
is1:    bsr  mslot
        pshb
        psha
        ldab #6
        bsr  mslot
        pulx
        bra  cmpn
; isone: Z if the top number is 1
isone:  ldx  kv_wp
        ldd  0,x
        subd #1
        bne  .x
        ldaa 2,x
        deca
.x:     rts
; half: the top number halved (even, not 0)
half:   bsr  ilenw
        tstb
        beq  .o
        inca
.o:     staa zt
        clc
.s:     ror  2,x
        inx
        decb
        bne  .s
        dec  zt
        bne  .s
        bra  hnorm
; zslot: slot 1 = D (a small number)
zslot:  pshb
        ldab #1
        bsr  mslot
        xgdx
        bsr  clrxn
        dex
        pulb
        stab 0,x
        rts
        include "mslot.inc"
        include "mexp.inc"
mx_set:
mx_safe: rts
