; =====================================================================
; OV_DIV: the second number divided by the top one (the remainder is never negative): entry 0 the
; quotient, 1 the remainder, 2 both (the quotient on top).
; =====================================================================
        include "macros.inc"
        entry quot
        entry rem
        lastent both

quot:   bsr  divide
        bra  hslide             ; (the quotient is on top)
rem:    bsr  divide
        ldx  drh
        stx  kv_wp
        bra  hslide
both:   bsr  divide
        pshx                    ; the remainder moved up to the end
        ldx  drh
        stx  kv_wp
        bsr  hslide
        ldx  kv_wp              ; and the quotient up to it
        stx  kv_se
        pulx
        stx  kv_wp
        bra  hslide

drh     = kv_ib                 ; the remainder's item
du      = kv_na                 ; the two numbers
dvi     = kv_nb
dqp     = ma                    ; the quotient's next byte
dqe     = mal                   ; its end
dvp     = mb                    ; the divisor, shifted up so that its top bit is set
dvn     = mbl                   ; its bytes
dwp     = mp                    ; the window: the dividend, its bits turned over
dv2     = mq                    ; the divisor's top two bytes, plus 1
dsh     = mwq                   ; 2 to the shift

; divide: X = kv_wp = the quotient's item, the remainder's at drh, both with their signs (not yet
; without leading zeros); kv_se the end of the two operands
divide: ldx  kv_wp
        stx  dvi
        ldd  0,x
        bne  .nz
        ldab #E_DIV
        bra  err
.nz:    bsr  ilen
        std  dvn
        bsr  i2
        stx  du
        bsr  inext
        stx  kv_se
        ldx  du
        ldd  dvi
        bsr  hcmp
        bcc  .go
; a smaller dividend: 0 and itself (made as long as the divisor)
        ldd  dvn
        addd #2+3
        bsr  walloc
        ldd  #1                 ; the quotient: a zero byte
        std  0,x
        clr  2,x
        inx
        inx
        inx
        stx  drh
        ldd  dvn
        std  0,x
        inx
        inx
        bsr  clrx
        stx  zp                 ; its end
        ldx  du
        bsr  ilen
        pshb
        psha
        stx  zx
        addd zx
        addd #2
        std  zx
        pula
        pulb
        bsr  cpd
        bra  signs
.go:    ldx  du
        bsr  ilen
        std  mrem               ; the dividend's bytes
        subd dvn
        addd #2
        std  mr2                ; the quotient's, and one more for a carry
        addd dvn
        addd mrem
        addd #2+1+3+2
        bsr  walloc
        ldd  mr2
        std  0,x
        clr  2,x
        inx
        inx
        inx
        stx  dqp
        addd dqp
        subd #1
        std  dqe
        std  dvp
        addd dvn
        addd #4
        std  dwp
        ldx  dvi                ; the shift, from the divisor's top byte
        ldab 2,x
        ldaa #1
.sh:    tstb
        bmi  .shd
        aslb
        asla
        bra  .sh
.shd:   staa dsh
        bsr  inext              ; the divisor shifted, a zero after it
        stx  zx
        ldd  dvp
        addd dvn
        std  zp
        xgdx
        clr  0,x
        ldx  dvn
        clra
        bsr  shift
        ldx  dvp
        ldd  0,x
        addd #1
        std  dv2
        ldx  kv_se              ; the dividend shifted and turned over, a byte before and one after
        stx  zx
        ldd  dwp
        addd mrem
        addd #1
        std  zp
        xgdx
        ldaa #$FF
        staa 0,x
        ldx  mrem
        bsr  shift
        ldx  dwp
        ldab zm
        comb
        stab 0,x

; a quotient byte
.q:     bsr  poll
        ldx  dwp
        ldaa 2,x                ; the window's top three bytes, over the divisor's two and 1
        coma
        staa zw
        ldd  0,x
        coma
        comb
        ldx  dv2
        bne  .dv
        staa zw                 ; (over 65,536)
        bra  .qd
.dv:    ldx  #8
.dl:    asl  zw
        rolb
        rola
        bcs  .ds
        subd dv2
        bcc  .d1
        addd dv2
        bra  .dn
.ds:    subd dv2
.d1:    inc  zw
.dn:    dex
        bne  .dl
.qd:    ldx  dqp
        ldab zw
        stab 0,x
        beq  .c
        stx  ze
        bsr  row
.c:     ldx  dwp                ; is what is left as much as the divisor?
        ldaa 0,x
        inca
        bne  .again
        stx  zp
        ldx  dvp
        stx  zx
        ldd  dvn
        std  zt
.cl:    ldx  zp
        ldab 1,x
        comb
        inx
        stx  zp
        ldx  zx
        cmpb 0,x
        blo  .next
        bhi  .again
        inx
        stx  zx
        ldx  zt
        dex
        stx  zt
        bne  .cl
.again: ldx  dqp                ; one more
        inc  0,x
        ldx  #one
        stx  ze
        bsr  row
        bra  .c
.next:  ldx  dwp
        inx
        stx  dwp
        ldx  dqp
        inx
        stx  dqp
        cpx  dqe
        bne  .q
; the remainder: dvn bytes at dwp, turned back and shifted back down
        ldab dsh
        ldaa #128               ; 256 / dsh (0: no shift)
        decb
        bne  .f
        clra
        bra  .f1
.f:     incb
.f2:    lsrb
        cmpb #1
        beq  .f1
        lsra
        bra  .f2
.f1:    staa zw
        ldx  dvn
        stx  zt
        ldx  dwp
        clr  zm
.r:     ldab 0,x
        comb
        ldaa zw
        beq  .rs
        mul
        oraa zm
        stab zm
        tab
.rs:    stab 0,x
        inx
        pshx
        ldx  zt
        dex
        stx  zt
        pulx
        bne  .r
        ldx  dwp
        dex
        dex
        stx  drh
        ldd  dvn
        std  0,x
; the signs: U = Q V + R, R not negative
signs:  ldx  du
        ldab 0,x
        bpl  .pos
        ldx  drh                ; U is negative: if there is a remainder, it is V less it, and the
        bsr  ilen               ; quotient one more
        std  zt
.z:     tst  2,x
        bne  .rem
        inx
        ldd  zt
        subd #1
        std  zt
        bne  .z
        bra  .pos
.rem:   ldx  drh                ; R = V - R
        bsr  inext
        stx  zp
        ldx  dvi
        bsr  inext
        stx  zx
        ldd  dvn
        std  zt
        clr  zw
.sb:    ldx  zx
        dex
        stx  zx
        ldaa 0,x
        ldx  zp
        dex
        stx  zp
        lsr  zw
        sbca 0,x
        rol  zw
        staa 0,x
        ldx  zt
        dex
        stx  zt
        bne  .sb
        ldx  kv_wp              ; Q + 1
        bsr  inext
.i:     dex
        inc  0,x
        beq  .i
.pos:   ldx  du                 ; Q's sign
        ldaa 0,x
        ldx  dvi
        eora 0,x
        anda #$80
        ldx  kv_wp
        oraa 0,x
        staa 0,x
        rts

; the window += (the byte at ze) x the divisor
row:    ldd  dvp
        addd dvn
        std  mye
        ldd  dwp
        addd dvn
        addd #1
        std  mpe
        ldd  dvn
.l:     std  mrem
        bsr  chunkw
        bsr  chunky
        bsr  chunkp
        ldx  ze
        inx
        stx  zx
        ldab zw
        bsr  mulr
        bsr  chunkd
        bne  .l
        tstb
        bne  .l
        rts
; shift: X bytes ending at zx times dsh, turned over if A is $FF, to end at zp; zm = what goes over
; the front
shift:  staa zw
        clr  zm
.l:     stx  zt
        ldx  zx
        dex
        stx  zx
        ldaa 0,x
        ldab dsh
        mul
        addb zm
        staa zm
        eorb zw
        ldx  zp
        dex
        stx  zp
        stab 0,x
        ldx  zt
        dex
        bne  .l
        rts
one:    fcb  1

