; Primes one after another, up to 24 bits, from a sieve of 1,050 odd numbers (2,100 numbers: ten steps of
; 210, for the second stages) at a time (PS_LEN bytes at ps_buf). ps_go: start at the odd number B:X (B its top byte; 3 or more); ps_next: ps_p = the next
; prime (never 2)
PS_LEN  = 132
PS_N    = 1050
ps_go:  stab ps_lo
        stx  ps_lo+1
        bra  ps_fill
ps_next: ldd ps_i
        addd #1
        std  ps_i
        subd #PS_N
        bcs  .in
        bsr  ps_win             ; the next window
        bra  ps_next
.in:    ldd  ps_i
        bsr  ps_bit
        bitb 0,x
        bne  ps_next
        ldd  ps_i
        asld
        addd ps_lo+1
        std  ps_p+1
        ldab ps_lo
        adcb #0
        stab ps_p
        rts
ps_win: ldd  ps_lo+1
        addd #2*PS_N
        std  ps_lo+1
        ldab ps_lo
        adcb #0
        stab ps_lo
        bra  ps_fill
; ps_bit: D = an odd number's place: X its byte, B its bit
ps_bit: pshb
        lsrd
        lsrd
        lsrd
        addd ps_buf
        xgdx
        pulb
        andb #7
        ldaa #1
.b:     decb
        bmi  .x
        asla
        bra  .b
.x:     tab
        rts
; the window from ps_lo sieved
ps_fill: ldx ps_buf
        ldd  #PS_LEN
        bsr  clrx
        ldd  #$FFFF
        std  ps_i
        ldd  #3
        std  ps_d
.d:     ldaa ps_d               ; its square, zw:zx
        tab
        mul
        stab zw
        ldaa ps_d+1
        tab
        mul
        std  zx
        ldd  ps_d
        mul
        asld
        addb zx
        stab zx
        adca zw
        staa zw
        ldd  zx                 ; less the window's start
        subd ps_lo+1
        std  zx
        ldaa zw
        sbca ps_lo
        bcs  .below
        bne  .done              ; past the window
        ldd  zx
        subd #2*PS_N
        bcc  .done
        ldd  zx                 ; the first to strike: the square itself
        lsrd
        bra  .go
.below: ldaa #24                ; the start modulo d
        staa zt
        ldx  ps_lo+1
        stx  zp
        ldaa ps_lo
        staa zm
        clra
        clrb
.m:     asl  zp+1
        rol  zp
        rol  zm
        rolb
        rola
        subd ps_d
        bcc  .m1
        addd ps_d
.m1:    dec  zt
        bne  .m
        std  zx
        subd #0
        beq  .go                ; a multiple itself
        ldd  ps_d
        subd zx                 ; the way to the next multiple: to the one after if it is odd
        bitb #1
        beq  .ev
        addd ps_d
.ev:    lsrd
.go:    std  zx
.s:     ldd  zx
        subd #PS_N
        bcc  .next
        ldd  zx
        bsr  ps_bit
        orab 0,x
        stab 0,x
        ldd  zx
        addd ps_d
        std  zx
        bra  .s
.next:  ldd  ps_d               ; the next d: 3 5 7, then those not a multiple of 2, 3 or 5
        cmpb #7
        bhs  .w
        tsta
        bne  .w
        addd #2
        std  ps_d
        cmpb #7
        bne  .d
        clr  ps_wi
        bra  .d
.w:     ldx  #ps_wh
        ldab ps_wi
        abx
        incb
        andb #7
        stab ps_wi
        ldab 0,x
        clra
        addd ps_d
        std  ps_d
        bra  .d
.done:  rts
ps_wh:  fcb  4,2,4,2,4,6,2,6
