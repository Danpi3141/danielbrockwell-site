// The sieve as the program does it: how a's primes are picked (OV_QSA), duplicate relations dropped, the room shared by
// relations and partial ones, the multiplier by the program's own score. It counts; times come from the emulator's costs.
//   csc /o+ /r:System.Numerics.dll QsP.cs
//   QsP key=value ...   n= (or digits= seed= count=) F= M= s=(0: the rule 7.64, -1: by the pool, else s) smax= ktab=old|new
//   tol=(1/256 bits) tries= used=0|1 (remember the a's) room=(entries of ub bytes) tp= ta= tc= (seconds)
using System;
using System.Collections.Generic;
using System.Numerics;

class QsP
{
    static Random rnd;
    static BigInteger RandBelow(BigInteger n) { byte[] b = new byte[n.ToByteArray().Length + 2]; rnd.NextBytes(b); b[b.Length - 1] = 0; return new BigInteger(b) % n; }
    static bool IsPrime(BigInteger n)
    {
        if (n < 2) return false; int[] ps = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37 };
        foreach (int p in ps) if (n % p == 0) return n == p;
        BigInteger d = n - 1; int s = 0; while (d.IsEven) { d >>= 1; s++; }
        foreach (int a in ps) { BigInteger x = BigInteger.ModPow(a, d, n); if (x.IsOne || x == n - 1) continue; bool ok = false; for (int i = 1; i < s; i++) { x = x * x % n; if (x == n - 1) { ok = true; break; } } if (!ok) return false; }
        return true;
    }
    static BigInteger RandPrime(int dg) { BigInteger lo = BigInteger.Pow(10, dg - 1); for (; ; ) { BigInteger v = lo + RandBelow(9 * lo) | 1; if (IsPrime(v)) return v; } }
    static int ModInv(int a, int p) { int t = 0, nt = 1, r = p, nr = a % p; while (nr != 0) { int q = r / nr; int x = t - q * nt; t = nt; nt = x; x = r - q * nr; r = nr; nr = x; } return t < 0 ? t + p : t; }
    static int Pow(long b, long e, long m) { long r = 1; b %= m; while (e > 0) { if ((e & 1) == 1) r = r * b % m; b = b * b % m; e >>= 1; } return (int)r; }
    static int SqrtMod(int a, int p) { for (int x = 0; x < p; x++) if ((long)x * x % p == a) return x; return -1; }
    static int[] primes;
    static void Init() { var l = new List<int>(); for (int i = 2; i < 40000; i++) { bool p = true; for (int d = 2; d * d <= i; d++) if (i % d == 0) { p = false; break; } if (p) l.Add(i); } primes = l.ToArray(); }
    static double Log2(BigInteger v) { return BigInteger.Log(v) / Math.Log(2); }
    // the program's score, in 1/16: over 3 to 73; pen 8 log2 k
    static int Mult(BigInteger N, int[] ks, int np)
    {
        double best = -1e9; int bk = 1;
        foreach (int k in ks)
        {
            int m8 = (int)(N * k % 8); double s = -0.5 * Math.Log(k, 2); s += m8 == 1 ? 2 : m8 == 5 ? 1 : m8 == 3 || m8 == 7 ? 0.5 : 0;
            for (int i = 1; i <= np; i++) { int p = primes[i]; int a = (int)(N * k % p); if (a == 0) s += Math.Log(p, 2) / (p - 1); else if (Pow(a, (p - 1) / 2, p) == 1) s += 2 * Math.Log(p, 2) / (p - 1); }
            if (s > best) { best = s; bk = k; }
        }
        return bk;
    }
    static Dictionary<string, string> A = new Dictionary<string, string>();
    static double G(string k, double d) { string v; return A.TryGetValue(k, out v) ? double.Parse(v) : d; }
    static string GS(string k, string d) { string v; return A.TryGetValue(k, out v) ? v : d; }

    static void Run(BigInteger N, string name)
    {
        int Fmax = (int)G("F", 230), M = (int)G("M", 1024), sArg = (int)G("s", 0), smax = (int)G("smax", 10), tries = (int)G("tries", 12); double tol = G("tol", 160) / 256, maxPolys = G("maxpolys", 2e7);
        string kt = GS("ktab", "old"); int[] ks;
        if (kt == "old") ks = new int[] { 1, 3, 5, 7, 11, 13, 15, 17, 19, 21, 23, 29, 31, 33, 35, 37, 39, 41, 43, 47 };
        else if (kt == "odd73") ks = new int[] { 1, 3, 5, 7, 11, 13, 15, 17, 19, 21, 23, 29, 31, 33, 35, 37, 39, 41, 43, 47, 51, 53, 55, 57, 59, 61, 65, 67, 69, 71, 73 };
        else if (kt == "all47") ks = new int[] { 1, 2, 3, 5, 6, 7, 10, 11, 13, 14, 15, 17, 19, 21, 22, 23, 26, 29, 30, 31, 33, 34, 35, 37, 38, 39, 41, 42, 43, 46, 47 };
        else ks = new int[] { 1, 2, 3, 5, 6, 7, 10, 11, 13, 14, 15, 17, 19, 21, 22, 23, 26, 29, 30, 31, 33, 34, 35, 37, 38, 39, 41, 42, 43, 46, 47, 51, 53, 55, 57, 58, 59, 61, 62, 65, 66, 67, 69, 70, 71, 73 };
        int k = A.ContainsKey("k") ? (int)G("k", 1) : Mult(N, ks, (int)G("kp", 20));
        BigInteger kN = N * k; int bits = (int)Math.Floor(Log2(kN)) + 1;
        var fb = new List<int> { 2 }; var ts = new List<int> { 1 };
        for (int i = 1; fb.Count < Fmax; i++) { int p = primes[i]; int a = (int)(kN % p); if (a == 0) { fb.Add(p); ts.Add(0); } else if (Pow(a, (p - 1) / 2, p) == 1) { fb.Add(p); ts.Add(SqrtMod(a, p)); } }
        int F = fb.Count; int[] P = fb.ToArray(), T = ts.ToArray(); int pmax = P[F - 1];
        double lm = Math.Log(M, 2), target = (bits + 1) / 2.0 - lm;
        int plo = 0; while (P[plo] < (int)G("qmin", 20)) plo++; int phi = plo; while (phi < F && phi - plo < (int)G("pmax", 32) && P[phi] < (int)G("qmax", 256)) phi++;
        double[] lg = new double[F]; int[] ilg = new int[F]; for (int i = 0; i < F; i++) { lg[i] = Math.Log(P[i], 2); ilg[i] = (int)Math.Round(lg[i]); }
        double mean = 0; int np = 0; for (int i = plo; i < phi; i++) if (T[i] != 0) { mean += lg[i]; np++; } mean /= np;
        int s; if (sArg > 0) s = sArg; else if (sArg == 0) { s = 1; do s++; while (target > s * G("per", 7.65625) && s < smax); } else { s = (int)Math.Round(target / (mean + G("bias", 0))); if (s < 2) s = 2; if (s > smax) s = smax; }
        // the window (OV_QSA window)
        double each = target / s; int c = plo; while (c < phi && lg[c] < each) c++; int hw = Math.Max(8, s + 5); int wlo = Math.Max(plo, c - hw), ww = Math.Min(phi - wlo, 2 * hw);
        if (A.ContainsKey("whole")) { wlo = plo; ww = phi - plo; }
        int lpMax = 15 * pmax; double thrD = bits / 2 + lm - 18; { int zm = (int)Math.Floor(Math.Log(lpMax, 2)) + 1; int sl = bits < 80 ? 13 : bits < 110 ? 11 : 13; thrD = bits / 2 + lm - sl - zm - G("dthr", 0); } int thr = (int)(A.ContainsKey("thr") ? G("thr", 0) : thrD);
        int ub = (bits / 2 + 11 + 7) / 8; int room = (int)G("room", 480); int need = F + 10;
        var used = new HashSet<string>(); var seen = new HashSet<BigInteger>(); var part = new Dictionary<int, List<BigInteger>>();
        int[] sv = new int[2 * M]; long polys = 0, cands = 0; int aas = 0, rep = 0, fulls = 0, combos = 0, dup = 0, parts = 0, pstored = 0; double missSum = 0;
        double upd = 0; for (int i = 1; i < F; i++) if (P[i] >= 20) upd += (T[i] != 0 ? 2 : 1) * 2.0 * M / P[i]; double tp = G("tp", (2 * M * 8 + 20 * upd + F * 150 + 30000) / 921600), ta = G("ta", 0.3 + F * s * G("tak", 0.0022)), tc = G("tc", (45000 + 260.0 * F) / 921600);
        bool remember = G("used", 0) > 0; int report = (int)G("report", 0);
        while (fulls + combos < need && polys < maxPolys)
        {
            int[] best = null; double bd = 1e9;
            for (int t = 0; t < tries; t++)
            {
                var set = new List<int>(); double sum = 0; int lim = s >= 6 ? s : s - 1; int guard = 0;
                while (set.Count < lim && guard++ < 10000) { int j = wlo + rnd.Next(256) * ww / 256; if (T[j] == 0 || set.Contains(j)) continue; set.Add(j); sum += lg[j]; }
                if (lim < s) { int bj = -1; double bdd = 1e9; for (int j = plo; j < phi; j++) if (T[j] != 0 && !set.Contains(j)) { double d = Math.Abs(sum + lg[j] - target); if (d < bdd) { bdd = d; bj = j; } } set.Add(bj); sum += lg[bj]; }
                else if (A.ContainsKey("fixlast")) { // one prime exchanged for the best one
                    int bi = -1, bj = -1; double bdd = Math.Abs(sum - target); int x = rnd.Next(s); for (int j = plo; j < phi; j++) if (T[j] != 0 && !set.Contains(j)) { double d = Math.Abs(sum - lg[set[x]] + lg[j] - target); if (d < bdd) { bdd = d; bi = x; bj = j; } }
                    if (bi >= 0) { sum += lg[bj] - lg[set[bi]]; set[bi] = bj; } }
                set.Sort(); if (remember && used.Contains(string.Join(",", set))) continue;
                double df = Math.Abs(sum - target); if (df < bd) { bd = df; best = set.ToArray(); }
                if (df < tol) break;
            }
            if (best == null) { tol += 0.1; if (tol > 8) break; continue; }
            string key = string.Join(",", best); if (!used.Add(key)) rep++; aas++; missSum += bd;
            BigInteger a = 1; foreach (int j in best) a *= P[j];
            var Bz = new BigInteger[s]; for (int l = 0; l < s; l++) { int q = P[best[l]]; BigInteger aq = a / q; int inv = ModInv((int)(aq % q), q); int g = (int)((long)T[best[l]] * inv % q); if (g > q / 2) g = q - g; Bz[l] = aq * g; }
            bool[] inA = new bool[F]; foreach (int j in best) inA[j] = true;
            int[] r1 = new int[F], r2 = new int[F]; int[][] dl = new int[s][]; for (int l = 0; l < s; l++) dl[l] = new int[F];
            BigInteger b = 0; foreach (var x in Bz) b += x;
            for (int i = 1; i < F; i++) if (!inA[i]) { int p = P[i]; int ai = ModInv((int)(a % p), p); for (int l = 0; l < s; l++) dl[l][i] = (int)((long)(2 * (int)(Bz[l] % p) % p) * ai % p); int bp = (int)(b % p); r1[i] = (int)(((long)(T[i] - bp + p) % p * ai + M) % p); r2[i] = (int)(((long)(2 * p - T[i] - bp) % p * ai + M) % p); }
            long npoly = 1L << (s - 1);
            for (long poly = 0; poly < npoly && fulls + combos < need; poly++)
            {
                if (poly > 0) { int v = 0; long t = poly; while ((t & 1) == 0) { t >>= 1; v++; } bool neg = ((poly >> (v + 1)) & 1) == 0; if (neg) b -= 2 * Bz[v]; else b += 2 * Bz[v]; int[] d0 = dl[v]; for (int i = 1; i < F; i++) if (!inA[i]) { int p = P[i]; int d = neg ? d0[i] : p - d0[i]; int x1 = r1[i] + d; if (x1 >= p) x1 -= p; r1[i] = x1; int x2 = r2[i] + d; if (x2 >= p) x2 -= p; r2[i] = x2; } }
                polys++; Array.Clear(sv, 0, sv.Length);
                for (int i = 1; i < F; i++) if (!inA[i] && P[i] >= 20) { int p = P[i], L = ilg[i]; for (int x = r1[i]; x < sv.Length; x += p) sv[x] += L; if (T[i] != 0) for (int x = r2[i]; x < sv.Length; x += p) sv[x] += L; }
                BigInteger cc = 0; bool have = false;
                for (int x = 0; x < sv.Length; x++) if (sv[x] >= thr)
                    {
                        if (!have) { cc = (b * b - kN) / a; have = true; }
                        cands++; BigInteger X = x - M; BigInteger Q = BigInteger.Abs((a * X + 2 * b) * X + cc); BigInteger u = BigInteger.Abs(a * X + b);
                        for (int i = 0; i < F && !Q.IsOne; i++) { int p = P[i]; for (; ; ) { BigInteger rem; BigInteger qq = BigInteger.DivRem(Q, p, out rem); if (!rem.IsZero) break; Q = qq; } }
                        if (Q.IsOne) { if (seen.Add(u)) fulls++; else dup++; }
                        else if (Q < lpMax) { int lp = (int)Q; parts++; List<BigInteger> li; if (part.TryGetValue(lp, out li)) { if (li.Contains(u) || seen.Contains(u)) dup++; else { seen.Add(u); li.Add(u); combos++; } }
                            else { int capP = (int)Math.Max(0, (room - fulls - 2 * combos) * ub / (ub + 2)); if (pstored < capP) { part[lp] = new List<BigInteger> { u }; pstored++; } else { int mx = -1; foreach (var kv in part) if (kv.Value.Count == 1 && kv.Key > mx) mx = kv.Key; if (mx > lp) { part.Remove(mx); part[lp] = new List<BigInteger> { u }; } if (pstored > capP) pstored = capP; } } }
                    }
                if (report > 0 && polys % report == 0) Console.WriteLine("   polys {0} a {1} rep {2} full {3} combos {4} dup {5} cands {6}", polys, aas, rep, fulls, combos, dup, cands);
            }
        }
        double frac = Math.Min(1.0, (fulls + combos) / (double)need); double h = (polys * tp + aas * ta + cands * tc) / 3600 / (frac < 1 ? frac : 1);
        Console.WriteLine("{0} bits {1} k {2} F {3} M {4} pool {5} mean {6:F2} target {7:F1} s {8} thr {9}: {10:F2} h{11} polys {12} a {13} rep {14} miss {15:F2} cands {16} full {17} combos {18} parts {19} dup {20}", name, bits, k, F, M, np, mean, target, s, thr, h, frac < 1 ? "*" : "", polys, aas, rep, missSum / Math.Max(1, aas), cands, fulls, combos, parts, dup);
    }
    static void Main(string[] av)
    {
        System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.InvariantCulture;
        Init(); foreach (string x in av) { int i = x.IndexOf('='); A[x.Substring(0, i)] = x.Substring(i + 1); }
        rnd = new Random((int)G("seed", 1));
        if (A.ContainsKey("n")) { foreach (string t in A["n"].Split(',')) Run(BigInteger.Parse(t), t.Substring(0, 6)); return; }
        int dg = (int)G("digits", 40); for (int i = 0; i < (int)G("count", 4); i++) { BigInteger n; var sv = rnd; rnd = new Random(1000 * dg + i + (int)G("nseed", 0)); do { n = RandPrime(dg / 2) * RandPrime(dg - dg / 2); } while (n.ToString().Length != dg); rnd = new Random((int)G("seed", 1) + i); Run(n, n.ToString().Substring(0, 6)); }
    }
}
