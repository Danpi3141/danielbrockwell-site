; msg: the lbc at X put in the header's place when the entry line comes back
msg:    ldd  #RTB_BL
        std  zp
        stx  zx
        ldab 0,x
        clra
        addd #1
        bsr  cpb
        ldaa #E_MSG
        staa kv_err
        rts
