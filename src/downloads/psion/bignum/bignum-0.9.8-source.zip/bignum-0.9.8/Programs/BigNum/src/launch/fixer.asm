; =====================================================================
; The kernel's fixer: read in just after the kernel and its start-up code, run once by the
; bootstrap: T0 = the kernel's base, X = the end of the fix-ups, on the stack the device. Adds the
; base to every word in the list (steps two a byte: tools/build.py encode_fixups) and jumps to the
; kernel with A = the device. Position independent.
; =====================================================================
        include "../defs.inc"

fix:    dex
        stx  T4                 ; one before the end
        ldd  T0
        addd #$FFFF
        std  T8                 ; the last word fixed, less one
        addd #KLEN+FIXLEN
        std  T2                 ; one before the next encoded byte
.fx:    ldx  T2
        cpx  T4
        beq  .go
        ldab 1,x                ; two steps: 1-15 on and fix, 0 on 15
        inx
        stx  T2
        pshb
        lsrb
        lsrb
        lsrb
        lsrb
        bsr  .st
        pulb
        andb #15
        bsr  .st
        bra  .fx
.st:    clra
        tstb
        beq  .z
        bsr  .on
        xgdx                    ; X = the word to fix, less one
        ldd  1,x
        addd T0
        std  1,x
        rts
.z:     ldab #15
.on:    addd T8
        std  T8
        rts
.go:    pula                    ; the device
        ldx  T0                 ; the kernel's entry is its first byte
        jmp  0,x
fix_end:
FIXLEN  = fix_end-fix
