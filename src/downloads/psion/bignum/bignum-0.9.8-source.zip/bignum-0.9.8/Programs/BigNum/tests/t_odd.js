// The methods and tests given odd things: 0, 1, negative, even, primes, squares, pseudoprimes, huge arguments, silly bounds.
// A factor must divide, a prime must be one, an error must leave everything as it was.   node tests/t_odd.js [model] [seed]
'use strict';
const { BN, HZ, rng } = require('./lib');
const model = process.argv[2] || 'lz64', R = rng(+process.argv[3] || 1);
const g = new BN(model, process.env.BB ? { build: process.env.BB } : {}).start(), m = g.m; let bad = 0, n = 0;
const fail = (s) => { console.log('FAIL', model, s); if (++bad > 12) process.exit(1); };
const powm = (b, e, p) => { let r = 1n; b %= p; while (e) { if (e & 1n) r = r * b % p; b = b * b % p; e >>= 1n; } return r; };
const isp = (v) => { if (v < 2n) return false; for (const p of [2n, 3n, 5n, 7n, 11n, 13n, 17n, 19n, 23n, 29n, 31n, 37n]) if (v % p === 0n) return v === p; let d = v - 1n, s = 0; while (!(d & 1n)) { d >>= 1n; s++; } next: for (const a of [2n, 3n, 5n, 7n, 11n, 13n, 17n, 19n, 23n, 29n, 31n, 37n, 41n, 43n]) { let x = powm(a, d, v); if (x === 1n || x === v - 1n) continue; for (let i = 1; i < s; i++) { x = x * x % v; if (x === v - 1n) continue next; } return false; } return true; };
const back = () => { for (let i = 0; i < 14 && !g.atLine(); i++) { m.poke(0x76, /Paused/.test(g.text()) ? 65 : 1); g.run(1); m.runTo([g.addr('t_idle')], HZ * 5); } };
const run = (l, secs = 400) => {
  n++; back(); g.wait(); m.write(g.peekw('kv_line'), [l.length, ...[...l].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', l.length); g.poke('kv_err', 0); const old = g.vars()['@']; m.poke(0x76, 13); m.run(5000);
  const r = m.runTo([g.addr('t_idle')], HZ * secs) >= 0;
  if (/TRAP/.test(g.text())) { fail(`${l}: ${g.text()}`); process.exit(1); }
  if (!r) { m.poke(0x76, 1); g.run(3); m.poke(0x76, 65); g.run(3); back(); if (!g.atLine()) { fail(`${l}: cannot be stopped: ${g.text()}`); process.exit(1); } return { long: true }; }
  if (g.atLine()) { const e = g.peek('kv_err'); if (e && e < 100 && g.vars()['@'] !== old) fail(`${l}: error ${e}, but ANS changed`); return { err: e }; }
  return { val: g.vars()['@'] };
};
const V = ['0', '1', '-1', '2', '-2', '3', '4', '9', '15', '16', '25', '49', '121', '91', '97', '561', '1105', '2047', '3277', '65535', '65536', '65537', '4294967295', '4294967296', '4294967297', '1373653', '25326001', '3215031751', '2**61-1', '2**64', '2**64-1', '2**64+1', '2**67', '10007**2', '10007**3', '65537**2', '(2**31-1)**2', '10007*10009', '(10**9+7)*(10**9+9)', '3**40', '6**20', '2**89-1', '(2**61-1)**2', '-(10007*10009)', '10**20', '10**20+39', '341550071728321', '3825123056546413051', '318665857834031151167461'];
const val = (s) => eval(s.replace(/(\d+)/g, '$1n'));
for (const s of V) {
  const v = val(s);
  for (const f of ['ISPRIME', 'FACTOR', 'RHO', 'PM1', 'PP1', 'QS', 'PHI', 'TAU', 'SIGMA', 'NEXTPRIME', 'PREVPRIME', 'SIZE', 'ABS', 'SQRT']) {
    if (model !== 'lz64' && R.int(3)) continue;
    const l = `${f}(${s})`, r = run(l, /FACTOR|QS|PHI|TAU|SIGMA/.test(f) ? 900 : 300); if (r.long) continue;
    if (r.err) { if (f === 'ISPRIME' || (f === 'FACTOR' && v > 0n && v < 2n ** 70n) || f === 'ABS' || f === 'SIZE') fail(`${l}: error ${r.err}`); continue; }
    if (f === 'ISPRIME' && r.val !== (isp(v) ? 1n : 0n)) fail(`${l} = ${r.val}`);
    if (f === 'FACTOR' && v > 1n && (v % r.val !== 0n || !isp(r.val))) fail(`${l} = ${r.val}`);
    if (/^(RHO|PM1|PP1|QS)$/.test(f) && (r.val < 1n || (v && v % r.val !== 0n) || (r.val !== 1n && r.val === (v < 0n ? -v : v)))) fail(`${l} = ${r.val}`);
    if (f === 'NEXTPRIME' && (r.val <= v || !isp(r.val))) fail(`${l} = ${r.val}`);
    if (f === 'PREVPRIME' && (r.val >= v || !isp(r.val))) fail(`${l} = ${r.val}`);
    if (f === 'SQRT' && !(r.val * r.val <= v && (r.val + 1n) ** 2n > v)) fail(`${l} = ${r.val}`);
  }
}
for (const l of ['LLT(0)', 'LLT(1)', 'LLT(2)', 'LLT(3)', 'LLT(4)', 'LLT(9)', 'LLT(11)', 'LLT(13)', 'LLT(-3)', 'LLT(65536)', 'LLT(10**9)', 'LLT(10**30)']) { const r = run(l, 60); const k = { 'LLT(2)': 1n, 'LLT(3)': 1n, 'LLT(11)': 0n, 'LLT(13)': 1n }[l]; if (k !== undefined && r.val !== k) fail(`${l} = ${r.err} ${r.val}`); if (k === undefined && !r.long && r.val === 1n) fail(`${l} = 1`); }
for (const l of ['PROVE(0)', 'PROVE(1)', 'PROVE(2)', 'PROVE(3)', 'PROVE(-7)', 'PROVE(91)', 'PROVE(2**64)', 'PROVE(2**61-1)', 'PROVE(2**89-1)', 'PROVE((2**61-1)**2)', 'PROVE(318665857834031151167461)', 'PROVE(561)', 'PROVE(10**20+39)']) { const r = run(l, 900); if (r.long || r.err) { if (/\((2|3|91|561)\)/.test(l)) fail(`${l}: error ${r.err}`); continue; } const v = val(l.slice(6, -1)); if (r.val !== (isp(v) ? 1n : 0n)) fail(`${l} = ${r.val}`); }
// [line, the value (null: an error; undefined: anything that is sound)]
const X = [['ECM(10**20+39,0)'], ['ECM(10**20+39,-1)'], ['ECM(10**20+39,65535)'], ['ECM(10**20+39,65536)'], ['ECM(10**20+39,10**30)'], ['ECM(0,1)'], ['ECM(1,1)'], ['ECM(2,1)'], ['ECM(9,1)'], ['ECM(91,1)'], ['ECM(10007**2,1)'], ['ECM(2**64,1)'],
  ['TRIAL(0,10)'], ['TRIAL(1,10)'], ['TRIAL(91,0)'], ['TRIAL(91,1)'], ['TRIAL(91,6)', 1n], ['TRIAL(91,7)', 7n], ['TRIAL(-91,100)'], ['TRIAL(10007*10009,-5)'], ['TRIAL(10007*10009,10**30)'], ['TRIAL(2**200,100)', 2n],
  ['NROOT(10,0)', null], ['NROOT(10,-1)', null], ['NROOT(10,10**20)', 1n], ['NROOT(0,0)', null], ['NROOT(-8,3)', -2n], ['NROOT(-8,2)', null], ['NROOT(1,65536)', 1n], ['NROOT(2**500,500)', 2n], ['NROOT(2**500-1,500)', 1n], ['NROOT(5,70000)', 1n],
  ['BINOM(10**30,2)', 10n ** 30n * (10n ** 30n - 1n) / 2n], ['BINOM(10**30,10**30-2)', 10n ** 30n * (10n ** 30n - 1n) / 2n], ['BINOM(10**30,10**20)', null], ['BINOM(5,-1)'], ['BINOM(0,1)', 0n], ['FACT(10**30)', null], ['FIB(10**30)', null], ['PRIMORIAL(10**30)', null], ['LUC(-5)', null],
  ['CRT(1,0,1,5)', null], ['CRT(1,1,1,1)'], ['CRT(1,2,0,4)', null], ['CRT(-5,7,-6,11)', 16n], ['MODSQRT(2,15)'], ['MODSQRT(-1,13)'], ['MODSQRT(2,2)', 0n], ['MODSQRT(2,1)'], ['MODSQRT(5,0)', null], ['MODSQRT(10,2**61-1)'], ['JACOBI(1,2)', null], ['JACOBI(0,0)', null], ['MODINV(1,0)', null], ['MODINV(0,1)'],
  ['MODEXP(0,0,0)', null], ['MODEXP(0,0,1)', 0n], ['MODEXP(2,10**30,1)', 0n], ['MODEXP(2,10**30,2)', 0n], ['MODEXP(2,10**30,10**30)'], ['GCD(0,0)', 0n], ['LCM(0,0)', 0n], ['0**0', 1n], ['0**-1', null], ['1**-1'], ['2**-1', null], ['(-1)**-1'], ['(-1)**(10**30)', 1n], ['(-1)**(10**30+1)', -1n], ['0**(10**30)', 0n], ['1**(10**30)', 1n],
  ['10**10**10', null], ['2**2**2**2**2', null], ['0/5', 0n], ['0%5', 0n], ['-0', 0n], ['--0', 0n], ['5%-3', 2n], ['-5%-3', 1n], ['-5/3', -2n], ['7/-7', -1n], ['-7/7', -1n], ['(-2)**3', -8n], ['-2**2', -4n], ['2**-0', 1n]];
for (const [l, w] of X) {
  const r = run(l, 120); if (r.long) continue;
  if (w === null ? r.err === undefined : w !== undefined && r.val !== w) fail(`${l}: error ${r.err} value ${r.val}, want ${w}`);
  if (/^ECM|^TRIAL/.test(l) && r.val !== undefined) { const v = val(l.slice(l.indexOf('(') + 1, l.lastIndexOf(','))); if (v && (r.val < 1n || v % r.val !== 0n)) fail(`${l} = ${r.val}`); }
}
console.log(bad ? `${bad} FAILED` : `t_odd ${model} ok (${n} lines)`);
process.exit(bad ? 1 : 0);
