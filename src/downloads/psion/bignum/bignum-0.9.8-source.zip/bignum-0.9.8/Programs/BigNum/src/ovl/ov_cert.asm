; =====================================================================
; OV_CERT: the number pv_m has been proved: its part of the certificate made out of the factors' list (which is
; used up) at kv_osp: the number's own record, then one for each prime. kv_osp goes past it.
; =====================================================================
        include "macros.inc"
        include "fa.inc"
        include "pv.inc"
        lastent cert

cert:   ldx  kv_rl              ; the list's records made short, in place
        stx  pv_q
        stx  kv_se              ; (where the next goes)
.f:     ldx  pv_q
        cpx  kv_lim
        beq  .e
        bsr  fl_next
        pshx                    ; (the one after)
        ldx  pv_q
        ldaa 0,x
        deca
        cmpa #1
        bhi  .n
        ldd  FR_W,x
        pshb
        psha
        ldab #FR_N
        abx
        stx  zx
        bsr  ilen
        addd #2
        std  kv_al
        ldx  kv_se
        ldaa #PT_Q
        staa 0,x
        pula
        pulb
        std  1,x
        ldab #CT_N
        abx
        stx  zp
        ldd  kv_al
        addd zp
        std  kv_se
        ldd  kv_al
        bsr  cpb
.n:     pulx
        stx  pv_q
        bra  .f
.e:     ldx  pv_m               ; room for the number's own in front of them
        bsr  ilen
        addd #CT_N+2
        std  kv_al
        ldd  kv_wp
        subd kv_al
        bcs  nomem
        subd kv_se
        bls  nomem
        ldd  kv_se
        std  zx
        addd kv_al
        std  zp
        std  kv_lim
        ldd  kv_se
        subd kv_rl
        bsr  cpd
        ldx  kv_rl
        ldaa pv_t
        staa 0,x
        clra
        ldab pv_d
        std  1,x
        ldab #CT_N
        abx
        stx  zp
        ldx  pv_m
        stx  zx
        ldd  kv_al
        subd #CT_N
        bsr  cpb
        ldx  kv_lim
        stx  kv_osp
        rts
        include "flnext.inc"
