// Where the sieve's time goes: node tests/m_qsp.js model N [slack] [F] [svz] [lp 0/1]
'use strict';
const { BN, HZ } = require('./lib');
const [model, N, slack, F, svz, lp] = process.argv.slice(2);
const g = new BN(model).start(), m = g.m;
const t = `QS(${N})`;
g.wait(); m.write(g.peekw('kv_line'), [t.length, ...[...t].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', t.length);
m.poke(0x76, 13);
const OV = (o) => g.meta.ovl.indexOf(o) + 1, rv = OV('ov_qsv');
const A = (o, n) => g.oaddr(o, n);
const stop = { [A('ov_qsv', 'qsv')]: 'qsv', [A('ov_qsv', 'cand')]: 'cand', [A('ov_qsv', 'switch')]: 'switch', [A('ov_qsl', 'qsl')]: 'qsl', [A('ov_qsx', 'qsx')]: 'qsx', [A('ov_qs0', 'target')]: 'target', [A('ov_qsa', 'qsa')]: 'qsa' };
const bps = Object.keys(stop).map(Number).concat([g.addr('t_idle')]);
let cands = 0, polys = 0, as = 0, inA = 0, tA = 0, t0 = m.cycles(), tc = 0, tsw = 0, tl = 0, start = t0, tsetup = 0, fset = false;
for (;;) {
  const pc = m.runTo(bps, HZ * 1e6); const ov = g.meta.ovl[g.peek('kv_res') - 1]; let n = stop[pc]; if (pc === A('ov_qsv', 'qsv')) n = ov.slice(3);
  if (pc === g.addr('t_idle')) { if (m.cycles() - start > HZ * 3) break; m.run(1); continue; }
  if (n === 'target' && ov === 'ov_qs0') { if (F && !fset) { g.poke('q_f', +F); fset = true; } if (svz) g.pokew('q_svz', +svz); }
  else if (n === 'qs1' && lp !== undefined && lp !== '-') g.pokew('q_lp', +lp);
  else if (ov === 'ov_qsv' && n === 'qsv') { if (!tsetup) { tsetup = m.cycles() - start; if (slack) { g.poke('q_fill', g.peek('q_fill') + +slack); } t0 = m.cycles(); } as++; }
  else if (ov === 'ov_qsv' && n === 'switch') { polys++; const c = m.cycles(); const ret = m.peekw(m.dbg.sp()); m.runTo([ret], HZ * 100); tsw += m.cycles() - c; continue; }
  else if (ov === 'ov_qsv' && n === 'cand') { cands++; const sp = m.dbg.sp(); const ret = m.peekw(sp); const c = m.cycles(); for (;;) { const r = m.runTo([ret], HZ * 100); if (r !== ret) break; if (m.dbg.sp() > sp) break; m.run(1); } tc += m.cycles() - c; continue; }
  else if (ov === 'ov_qsl' && n === 'qsl') { tl = m.cycles(); }
  else if (ov === 'ov_qsx' && n === 'qsx') { console.log('combining', ((m.cycles() - tl) / HZ).toFixed(0)); }
  m.run(1);
}
const sv = (tl - t0), s = (x) => (x / HZ).toFixed(0);
console.log(`bits ${g.peekw('q_bits')} F ${g.peek('q_f')} s ${g.peek('q_s')} svz ${g.peekw('q_svz')} lp ${g.peekw('q_lp')} fill ${g.peek('q_fill')}: setup ${s(tsetup)} sieving ${s(sv)} (a's ${as}, polys ${polys + as}, cands ${cands}: ${s(tc)} s, ${(tc / cands / 1000).toFixed(0)}K each; switch ${s(tsw)} s; rest ${s(sv - tc - tsw)} s, ${((sv - tc - tsw) / (polys + as) / 1000).toFixed(0)}K a poly) total ${s(m.cycles() - start)} value ${g.vars()['@']}`);
