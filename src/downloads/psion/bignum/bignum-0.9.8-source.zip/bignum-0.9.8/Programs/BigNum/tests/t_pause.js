// ON pressed at random moments of long work: how long until the pause screen (2 seconds at most), and the result
// after Continue must be the same.   node tests/t_pause.js [model] [which regex] [presses]
'use strict';
const { BN, HZ, rng } = require('./lib');
const model = process.argv[2] || 'lz64', re = new RegExp(process.argv[3] || '.'), P = +process.argv[4] || 6;
const R = rng(5); let bad = 0; const fail = (s) => { console.log('FAIL', s); bad++; };
const small = /^cm/.test(model), c = small ? 2047 : 8191, h = c >> 1;
const J = [`(2**${h}-1)*(2**${h}-1)`, `(3**${Math.floor(c / 1.6)})/(7**${Math.floor(c / 5.8)})`, small ? 'FACT(300)' : 'FACT(966)', small ? 'FIB(2900)' : 'FIB(11800)', small ? 'BINOM(2000,1000)' : 'BINOM(8000,4000)', small ? 'PRIMORIAL(1480)' : 'PRIMORIAL(5782)',
  `SQRT(3**${Math.floor(c / 1.6)})`, `NROOT(3**${Math.floor(c / 1.6)},3)`, `GCD(3**${Math.floor(c / 1.6)},2**${c - 3}-1)`, `MODINV(3**${h},2**${c}-1)`, `MODEXP(3,2**${small ? 700 : 900}-1,2**${small ? 700 : 900})`, `MODEXP(3,2**600-1,2**607-1)`, `MODSQRT(5,2**255-19)`,
  'LLT(607)', 'NEXTPRIME(10**120)', 'ISPRIME(2**521-1)', 'TRIAL(10**300+7,60000)', 'RHO((2**61-1)*(2**89-1))', 'PM1((2**61-1)*(2**89-1))', 'PP1((2**61-1)*(2**89-1))', 'ECM((2**61-1)*(2**89-1),1)', 'FACTOR(10**30+1)', 'PROVE(10**25+13)', 'PHI(2**64+1)', 'JACOBI(3,2**2000+1)'];
if (!small) J.push('QS(353890612479965357292787308697)');
for (const line of J) {
  if (!re.test(line)) continue;
  const g = new BN(model).start(), m = g.m;
  const r0 = g.line(line, 1e6); if (r0.err) { fail(`${line}: error ${r0.err}`); continue; }
  const total = r0.cycles; const ts = []; for (let i = 0; i < P; i++) ts.push(Math.floor(total * (0.02 + 0.93 * (R.int(10000) / 10000)))); ts.sort((a, b) => a - b);
  for (let i = 0; i < 6 && !g.atLine(); i++) { g.inject('ON'); g.wait(); }
  g.wait(); m.write(g.peekw('kv_line'), [line.length, ...[...line].map((x) => x.charCodeAt(0))]); g.poke('kv_cur', line.length); m.poke(0x76, 13);
  let now = 0, worst = 0; const at = g.addr('t_idle');
  for (const t of ts) {
    const d = t - now; if (d > 0) { const c0 = m.cycles(); if (m.runTo([at], d) === at && /Paused/.test(g.text()) === false) break; now += m.cycles() - c0; }
    m.poke(0x76, 1); const c0 = m.cycles();
    if (m.runTo([at], HZ * 30) !== at) { fail(`${line}: no pause in 30 s at ${(t / HZ).toFixed(1)} s: ${g.text()}`); break; }
    const lat = (m.cycles() - c0) / HZ;
    if (!/Paused/.test(g.text())) break;                       // (it came to its end)
    if (lat > worst) worst = lat;
    now += m.cycles() - c0;
    m.poke(0x76, 67); m.run(2000);
  }
  m.runTo([at], HZ * 1e6);
  for (let i = 0; i < 3 && /Paused/.test(g.text()); i++) { m.poke(0x76, 67); m.run(2000); m.runTo([at], HZ * 1e6); }
  const v = g.vars()['@'];
  if (v !== r0.val && !/QS|RHO/.test(line)) fail(`${line}: ${v} was ${r0.val}`);
  if (worst > 2) fail(`${line}: ${worst.toFixed(2)} s`);
  console.log(`${line}: ${(total / HZ).toFixed(1)} s, slowest pause ${worst.toFixed(2)} s`);
}
console.log(bad ? `${bad} FAILED` : `t_pause ${model} ok`);
process.exit(bad ? 1 : 0);
