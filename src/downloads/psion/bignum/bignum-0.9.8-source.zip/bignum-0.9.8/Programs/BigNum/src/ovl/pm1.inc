pm_d    = kv_fs                 ; 3 or 7
pm_c    = kv_fs+1               ; 10 or 2
pm_a    = kv_fs+2               ; A's item
pm_p    = kv_fs+4               ; where the exponent's item begins; P+1: bit 7 of pm_f
pm_f    = kv_fs+6               ; $80 P+1
pm_i    = kv_fs+7               ; (2) the exponent's bit, plus 1
mx_e    = kv_fs+9               ; (2) the exponent
pm_s    = kv_fs+11              ; the slots for the second stage's table (24, 4 or 0)
