; =====================================================================
; OV_QSL: the sieve's relations combined: a row of bits for each relation (the sign, then each prime's
; exponent modulo 2), eliminated in place: once a column has been used as a pivot it is empty but for the
; pivot's row, so it is used to note which rows had the pivot's added to them.
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        include "qs.inc"
        include "ql.inc"
        lastent qsl

qx_r    = kv_fs+13              ; the row
qx_a    = kv_fs+14              ; (2) its address
qx_e    = kv_fs+16              ; (2) the relation's entry
qx_c    = kv_fs+18              ; a column
qx_l    = kv_fs+19              ; (2) what is left of the first of a pair
qsl:    ldaa q_rn               ; the sieve and the records are done with: the relations up to the end of
        ldab q_ub               ; their room (the partial ones too)
        mul
        tba
        clrb
        std  zt
        ldaa q_rn+1
        ldab q_ub
        mul
        addd zt
        std  kv_al
        addd q_rel
        std  zx
        ldd  q_pe
        std  zp
        subd kv_al
        std  q_rel
        ldd  kv_al
        bsr  cpd
        ldx  q_rel
        stx  kv_wp
        ldaa q_need+1
        staa ql_n
        ldab q_f                ; a row: the sign and the primes
        clra
        addd #8
        lsrd
        lsrd
        lsrd
        stab ql_rb
        ldab q_f
        incb
        clra
        bsr  walloc
        stx  ql_piv
        ldab q_f
        incb
        ldaa #255
        os   UT$FILL
        ldab ql_n
        clra
        bsr  walloc
        stx  ql_use
        ldab ql_n
        clra
        bsr  clrx
        ldaa ql_n
        ldab ql_rb
        mul
        bsr  walloc
        stx  ql_m
        ldaa ql_n
        ldab ql_rb
        mul
        bsr  clrx
        ldab ql_n
        clra
        addb q_f
        adca #0
        addd #1                 ; (and the sign's column)
        bsr  part
        ldx  #hook
        bsr  hookx
; ---- the rows
        ldx  q_rel
        stx  qx_e
        clr  qx_r
.row:   ldaa qx_r
        ldab ql_rb
        mul
        addd ql_m
        std  qx_a
        ldx  qx_e
        ldaa 0,x
        psha
        bsr  qstd
        bsr  nexte
        bsr  remn
        std  qx_l
        pula
        tsta
        bmi  .pair
        ldd  qx_l
        subd #1
        beq  .ok
        bra  .bad
.pair:  ldx  qx_e               ; the second of a pair: the same prime left
        bsr  qstd
        bsr  nexte
        bsr  remn
        subd qx_l
        beq  .ok
.bad:   ldx  ql_use             ; (not as it should be: never used)
        ldab qx_r
        abx
        ldaa #2
        staa 0,x
.ok:    ldx  kv_done
        inx
        stx  kv_done
        inc  qx_r
        ldaa qx_r
        cmpa ql_n
        bne  .row
; ---- the elimination
        clr  qx_c
.col:   bsr  poll
        bsr  colbit
        ldx  ql_m               ; the first row, not a pivot yet, with a 1 here
        stx  qx_a
        clr  qx_r
.f:     bsr  isone
        bne  .found
.fn:    bsr  nextr
        bne  .f
        bra  .nc
.found: ldx  ql_use
        ldab qx_r
        abx
        ldaa #1
        staa 0,x
        ldx  ql_piv
        ldab qx_c
        abx
        ldaa qx_r
        staa 0,x
        ldx  qx_a
        stx  qx_e               ; (the pivot's row)
.a:     bsr  nextr              ; added to every later row with a 1 here
        beq  .nc
        bsr  isone
        beq  .a
        ldx  qx_a
        stx  zp
        ldx  qx_e
        stx  zx
        ldab ql_rb
.x:     ldx  zx
        ldaa 0,x
        inx
        stx  zx
        ldx  zp
        eora 0,x
        staa 0,x
        inx
        stx  zp
        decb
        bne  .x
        bsr  colbit             ; and the 1 put back: the note
        ldx  qx_a
        ldab ql_cb
        abx
        ldaa 0,x
        oraa ql_cm
        staa 0,x
        bra  .a
.nc:    ldx  kv_done
        inx
        stx  kv_done
        inc  qx_c
        ldaa qx_c
        deca
        cmpa q_f
        bne  .col
        rts
; colbit: ql_cb, ql_cm = the byte and the bit of column qx_c
colbit: ldab qx_c
        lsrb
        lsrb
        lsrb
        stab ql_cb
        ldab qx_c
        andb #7
        ldaa #1
.b:     decb
        bmi  .x
        asla
        bra  .b
.x:     staa ql_cm
        rts
; isone: not Z if row qx_r is free and has a 1 in the column
isone:  ldx  ql_use
        ldab qx_r
        abx
        ldaa 0,x
        bne  .no
        ldx  qx_a
        ldab ql_cb
        abx
        ldaa 0,x
        anda ql_cm
        rts
.no:    clra
        rts
; nextr: the next row (Z: there is none)
nextr:  ldd  qx_a
        addb ql_rb
        adca #0
        std  qx_a
        inc  qx_r
        ldaa qx_r
        cmpa ql_n
        rts
; nexte: on to the next entry
nexte:  ldx  qx_e
        ldab q_ub
        abx
        stx  qx_e
        rts
; remn: D = what is left of a relation (0 if more than 2 bytes)
remn:   ldx  qc_b
        ldaa qc_n
        deca
        beq  .b
        deca
        bne  .no
        ldd  0,x
        rts
.b:     ldab 0,x
        clra
        rts
.no:    clra
        clrb
        rts
; a negative one, a prime: the column's bit turned over
neg:    clrb
        bra  flip
hit:    lsra
        bcc  flipx
        incb
flip:   stab qx_c
        bsr  colbit
        ldx  qx_a
        ldab ql_cb
        abx
        ldaa 0,x
        eora ql_cm
        staa 0,x
flipx:  rts

hk_l:   bsr  pri
        fcl  "Combining"
        rts
hk_q:   bsr  pri
        fcl  "QS combine"
        rts
        include "qstd.inc"
        include "qdiv.inc"
        include "mhook.inc"
hk_3    = pr_pct
