; =====================================================================
; OV_METH: one method by itself: RHO(n), PM1(n), PP1(n), ECM(n, curves), QS(n): a factor, or 1
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        include "fa.inc"
        entry m_rho
        entry m_pm1
        entry m_pp1
        entry m_ecm
        lastent m_qs

m_rho:  bsr  start
        ldd  st_rho
        bne  .l
        ldd  #8000
.l:     std  fx_lim
        ovsub OV_RHO,0
        bra  end
m_pm1:  bsr  start
        ldd  st_pm1
        bsr  b1
        ovsub OV_PM1,0
        bra  end
m_pp1:  bsr  start
        ldd  st_pp1
        bsr  b1
        ovsub OV_PM1,1
        bra  end
b1:     bne  .l
        ldd  #2000
.l:     std  fx_lim
        rts
; ECM(n, curves): level 0: the bound is the setting's, or 2,000
m_ecm:  bsr  ilenw
        bmi  arg
        ldx  2,x
        subd #1
        bcs  arg
        beq  .b
        subd #1
        bne  .max
        xgdx
        bra  .c
.b:     xgdx
        tab
        clra
.c:     subd #1000
        bcs  .ok
.max:   clra
        clrb
.ok:    addd #1000
        std  fx_crv
        bsr  hdrop
        bsr  start
        ldd  st_ecm
        bsr  b1
        clra
        clrb
        std  fx_cur
        clr  fx_lvl
        ovsub OV_ECM,0
        bra  end
m_qs:   bsr  start
        bsr  qcan               ; too large for the sieve (or no sieve here)
        bcc  .ok
        ldab #E_AVL
        bra  err
.ok:    ovsub OV_PRP,0          ; (a prime has nothing to find)
        tst  kv_pk
        bne  none
        ldaa kv_pw              ; (nor has one with a small factor: it comes up at once)
        deca
        bne  .sv
        bsr  hdrop
        ldd  kv_pf
        bra  hpush
.sv:    ldx  kv_osp             ; nor a power: its root is a factor
        stx  kv_rl
        stx  kv_lim
        stx  fa_rec
        ldd  fx_dg
        std  fa_dg
        bsr  hdup
        bsr  fl_new
        clra
        bsr  fl_add
        ovsub OV_PPOW,0
        ldx  kv_osp
        stx  kv_lim
        tst  kv_pk
        bne  hnip
        ldx  kv_wp
        stx  fx_n
        ovsub OV_QS,0
        bra  end
; start: the number: below 1: BAD ARG; 1 to 3: 1; even: 2 (both straight back to the caller)
start:  ldx  kv_wp
        ldd  0,x
        beq  arg
        bmi  arg
        subd #1
        bne  .big
        ldab 2,x
        cmpb #3
        bhi  .big
        ldd  #1
.ret:   pulx
        pshb
        psha
        bsr  hdrop
        pula
        pulb
        bra  hpush
.big:   bsr  inext
        dex
        ldab 0,x
        lsrb
        bcs  .odd
        ldd  #2
        bra  .ret
.odd:   ldx  kv_wp
        stx  fx_n
        clr  fx_job
        ovsub OV_DIGS,0
        ldd  kv_digs
        std  fx_dg
        rts
arg:    bra  errarg
; end: the factor, or 1, in the number's place
end:    tst  fx_found
        bne  hnip
none:   bsr  hdrop
        bra  hpush1
        include "qcan.inc"
        include "flist.inc"
