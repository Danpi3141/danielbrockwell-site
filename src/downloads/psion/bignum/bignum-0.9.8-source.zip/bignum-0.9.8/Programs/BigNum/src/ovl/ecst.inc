; step: the point in 0, 1 plus the one whose X+Z, X-Z are in 9, 10 (their difference in 2, 3), the old
; point into 2, 3
step:   bsr  mrun
        mo    M_ADD,7,0,1
        mo    M_SUB,8,0,1
        mo    M_MUL,8,8,9
        mo    M_MUL,7,7,10
        mo    M_ADD,13,8,7
        mo    M_SQR,13,13,13
        mo    M_MUL,13,13,3
        mo    M_SUB,8,8,7
        mo    M_SQR,8,8,8
        mo    M_MUL,8,8,2
        mo    M_CPY,2,0,0
        mo    M_CPY,3,1,1
        mo    M_CPY,0,13,13
        mol   M_CPY,1,8,8
        rts
