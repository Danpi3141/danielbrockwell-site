; =====================================================================
; OV_PRP: is the top number (kept) prime? kv_pk = 0 no, 1 yes (proven: below 2**64), 2 probably; kv_pw =
; why not (1 a small factor, kv_pf; 2 base 2; 3 Lucas; 4 a square; 5 below 2).
; Entry 0: all of it. 1: ISPRIME(n). 2: without the trial division (for numbers sieved already).
; 3: ISPRIME's value and screen, the test done.
; =====================================================================
        include "macros.inc"
        include "ckn.inc"
        entry prp
        entry isprime
        entry prp2
        lastent shown

pr_lim  = kv_fs+12              ; trial division's limit
isprime: bsr prp
shown:        ldx  kv_osp             ; the number kept for the screen
        stx  kv_rl
        bsr  ilenw
        addd #2
        std  kv_al
        addd kv_osp
        std  kv_lim
        ldd  kv_wp
        subd kv_lim
        bcs  nomem
        ldd  kv_wp
        std  zx
        ldd  kv_osp
        std  zp
        ldd  kv_al
        bsr  cpb
        bsr  hdrop
        ldab kv_pk
        beq  .v
        ldab #1
.v:     clra
        bsr  hpush
        ldaa #OV_PSHOW
        staa kv_rk
        rts

prp:    clr  kv_pk
        ldaa #5
        staa kv_pw
        ldx  kv_wp              ; below 2
        ldd  0,x
        beq  .no
        bmi  .no
        subd #1
        bne  .t
        ldaa 2,x
        deca
        beq  .no
        deca
        beq  proven             ; 2
.t:     ldaa #1
        staa kv_pw
        bsr  inext              ; even
        dex
        ldab 0,x
        lsrb
        bcc  .two
        bsr  ilenw              ; trial division: to 1,000; numbers below 10**8 to 10,000, which settles them
        subd #4
        bhi  .big
        blo  .small
        ldd  2,x
        subd #$05F5             ; 10**8 = $05F5E100
        bhi  .big
        blo  .small
        ldd  4,x
        subd #$E100
        bcc  .big
.small: ldd  #10000
        bra  .lim
.big:   ldd  #1000
.lim:   std  pr_lim
        ldx  kv_wp
        pshx
        ldd  #PS_LEN
        bsr  walloc
        stx  ps_buf
        pulx
        pshx
        inx                     ; the number, for tdiv
        inx
        stx  td_x
        dex
        dex
        bsr  inext
        stx  td_e
        clrb
        ldx  #3
        bsr  ps_go
.l:     bsr  poll
        bsr  ps_next
        ldd  ps_p+1
        subd pr_lim
        bhi  .past
        ldd  ps_p+1
        std  td_p
        std  kv_pf
        bsr  tdiv
        bne  .l
        pulx                    ; a factor: the number itself?
        stx  kv_wp
        bsr  ilen
        subd #2
        bhi  .x
        beq  .two2
        ldab 2,x
        clra
        bra  .cmp
.two2:  ldd  2,x
.cmp:   subd kv_pf
        beq  proven
.x:     rts
.two:   ldd  #2
        std  kv_pf
.no:    rts
.past:  pulx
        stx  kv_wp
        ldd  pr_lim
        subd #10000
        beq  proven
        bra  prp2
proven: ldaa #1
        staa kv_pk
        rts

prp2:   ldaa kv_ckd             ; RESUME, in the Lucas test: base 2 is behind it
        bpl  .b2
        ldx  kv_wp
        stx  kv_fs
        ldaa #CK_LUC
        staa kv_ckm
        ovsub OV_CKL,4
        bcc  .b2
        ovsub OV_DIGS,0
        bra  .luc
.b2:    ovsub OV_BASE2,0
        tst  kv_pk
        beq  .x
.luc:
        ovsub OV_LUCP,0
        tst  kv_pk
        beq  .x
        bsr  ilenw              ; passed: proven if below 2**64
        subd #8
        bls  proven
        ldaa #2
        staa kv_pk
.x:     rts

        include "tdiv.inc"
        include "primes.inc"
