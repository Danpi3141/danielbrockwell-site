; =====================================================================
; OV_SQT: the last test of a proof by N-1 whose factored part F is only past the cube root: with N - 1 =
; (c2 F + c1) F, N is a prime if c1 c1 - 4 c2 is not a square. Carry set: it is one.
; =====================================================================
        include "macros.inc"
        include "fa.inc"
        include "pv.inc"
        lastent sqt

sqt:    ldx  kv_wp
        pshx
        bsr  hpush1             ; F
        ldx  kv_rl
.f:     cpx  kv_lim
        beq  .e
        stx  pv_q
        ldaa 0,x
        deca
        cmpa #1
        bhi  .n
        ldab #FR_N
        abx
        bsr  hcopy
        ldx  pv_q
        ldd  FR_E,x
        bsr  hpush
        ovsub OV_POW,0
        bsr  hmul
.n:     ldx  pv_q
        bsr  fl_next
        bra  .f
.e:     bsr  hdup               ; F F
        ldx  pv_m
        bsr  hcopy
        bsr  hpush1
        bsr  hsub
        bsr  hswap
        ovsub OV_DIV,0          ; F (N-1)/F
        bsr  hswap
        ovsub OV_DIV,2          ; quotient and remainder: c1 below c2
        bsr  hswap              ; c2, c1 on top
        bsr  hdup
        bsr  hmul
        bsr  hswap
        ldd  #4
        bsr  hpush
        bsr  hmul
        bsr  hsub
        ldx  kv_wp
        ldd  0,x
        bmi  .ok                ; (negative: not a square)
        bsr  hdup
        ovsub OV_ROOT,0
        bsr  hdup
        bsr  hmul
        bsr  i2
        ldd  kv_wp
        bsr  hcmp
        beq  .sq
.ok:    pulx
        stx  kv_wp
        clc
        rts
.sq:    pulx
        stx  kv_wp
        sec
        rts
        include "flnext.inc"
