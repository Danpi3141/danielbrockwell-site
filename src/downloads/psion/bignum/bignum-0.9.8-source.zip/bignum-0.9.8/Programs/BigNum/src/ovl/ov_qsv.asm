; =====================================================================
; OV_QSV: all the polynomials of an a sieved. Polynomial i: b changes by twice a B (a Gray code), so each
; root changes by a stored amount; the block of q_svz numbers from -M is filled, the logarithms of the
; primes added at their roots, and the cells that reach 128 looked at (OV_QSC's job is done here: every
; cell that passes is divided out at once).
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        include "qs.inc"
        lastent qsv

qc_x    = kv_fs                 ; (2) the cell
qc_a    = kv_fs+2               ; (2) its distance from the middle
qc_v    = kv_fs+16              ; which B changes
qc_d    = kv_fs+17              ; which way (bit 0)

qsv:    ldx  #hook
        bsr  hookx
poly:   bsr  poll
        ldd  q_pi
        beq  .fill
        bsr  switch
; ---- the block filled
.fill:  ldaa q_fill
        tab
        ldx  q_sv
.f:     std  0,x
        std  2,x
        std  4,x
        std  6,x
        std  8,x
        std  10,x
        std  12,x
        std  14,x
        std  16,x
        std  18,x
        std  20,x
        std  22,x
        std  24,x
        std  26,x
        std  28,x
        std  30,x
        xgdx
        addd #32
        xgdx
        ldaa q_fill
        tab
        cpx  q_rec              ; (the records come after it)
        bne  .f
; ---- and sieved
        ldd  q_rec              ; (the block's end, in the loops)
        std  .e1+1
        std  .e2+1
        std  .e3+1
        ldx  q_rec
.pr:    stx  zt
        ldd  QR_R1,x
        bmi  .np
        addd q_sv
        std  zx
        ldd  QR_R2,x
        addd q_sv
        std  zp
        ldaa QR_L,x
        ldab QR_P,x
        beq  .small
        cmpb #1
        bhi  .large
; p from 256 to 511: p = 2 B + 1
        staa .l2+1
        ldab QR_P+1,x
        lsrb
        orab #$80
        ldx  zx
        bsr  .m2
        ldx  zp
        bsr  .m2
        bra  .np
.m2:
.c2:    ldaa 0,x
.l2:    adda #0
        staa 0,x
        abx
        abx
        inx
.e2:    cpx  #0
        blo  .c2
        rts
; p below 256
.small: staa .l1+1
        ldab QR_P+1,x
        ldx  zx
        bsr  .m1
        ldx  zp
        bsr  .m1
        bra  .np
.m1:    ldaa 0,x
.l1:    adda #0
        staa 0,x
        abx
.e1:    cpx  #0
        blo  .m1
        rts
; larger ones
.large: staa .l3+1
        ldd  QR_P,x
        std  .a3+1
        ldx  zx
        bsr  .m3
        ldx  zp
        bsr  .m3
.np:    ldx  zt                 ; the next prime
        ldab q_rs
        abx
        cpx  q_rece
        bne  .pr
        bra  .scan
.m3:    cpx  q_rec
        bhs  .x3
.c3:    ldaa 0,x
.l3:    adda #0
        staa 0,x
        xgdx
.a3:    addd #0
        xgdx
.e3:    cpx  #0
        blo  .c3
.x3:    rts
; ---- the cells that reach 128
.scan:  ldx  q_sv
.s:     ldaa 0,x
        oraa 1,x
        oraa 2,x
        oraa 3,x
        oraa 4,x
        oraa 5,x
        oraa 6,x
        oraa 7,x
        bmi  .hit
.sn:    ldab #8
        abx
        cpx  q_rec
        bne  .s
        ldx  q_pi               ; the next polynomial
        inx
        stx  q_pi
        cpx  q_np
        beq  .x
        ldd  q_nr
        subd q_need
        bcs  poly
.x:     rts
.hit:   ldab #8                 ; which of the eight
.h:     tst  0,x
        bpl  .hn
        pshb
        pshx
        bsr  cand
        pulx
        pulb
.hn:    inx
        decb
        bne  .h
        dex
        dex
        dex
        dex
        dex
        dex
        dex
        dex
        bra  .sn

; switch: the polynomial q_pi: b and the roots changed
switch: ldd  q_pi               ; v = the zeros at its end; the bit after the 1 says which way
        clr  qc_v
.z:     lsrd
        bcs  .o
        inc  qc_v
        bra  .z
.o:     stab qc_d
        ldaa qc_v               ; B(v), twice
        inca
        ldab q_ub
        mul
        addd q_bl
        std  kv_al
        ldab q_ub
        clra
        std  mn
        bsr  bch
        bsr  bch
        ldab qc_v
        aslb
        addb #QR_D
        ldx  q_rec
        ldaa qc_d
        lsra
        bcs  .sub
        stab .a1+1
        stab .a2+1
.a:     ldd  QR_R1,x
        bmi  .an
.a1:    addd 0,x
        subd QR_P,x
        bcc  .ax
        addd QR_P,x
.ax:    std  QR_R1,x
        ldd  QR_R2,x
.a2:    addd 0,x
        subd QR_P,x
        bcc  .ay
        addd QR_P,x
.ay:    std  QR_R2,x
.an:    ldab q_rs
        abx
        cpx  q_rece
        bne  .a
        rts
.sub:   stab .s1+1
        stab .s2+1
.s:     ldd  QR_R1,x
        bmi  .sn
.s1:    subd 0,x
        bcc  .sx
        addd QR_P,x
.sx:    std  QR_R1,x
        ldd  QR_R2,x
.s2:    subd 0,x
        bcc  .sy
        addd QR_P,x
.sy:    std  QR_R2,x
.sn:    ldab q_rs
        abx
        cpx  q_rece
        bne  .s
        rts
; b less (or, if bit 0 of qc_d is 1, plus) the B that ends at kv_al
bch:    ldd  q_b
        addd mn
        std  zx
        std  ze
        ldd  kv_al
        std  zp
        ldaa qc_d
        lsra
        bcs  .add
        bra  sub3
.add:   bra  add3

; ---- a cell: u = a x + b; (u u - kN) / a divided by the primes of the base
cand:   xgdx
        ldx  q_cn               ; (counted: OV_QSA)
        inx
        stx  q_cn
        subd q_sv
        std  qc_x
        subd q_m                ; x
        bcc  .ps
        coma
        comb
        addd #1
.ps:    std  qc_a
        ldx  q_a                ; a |x|
        stx  ma
        ldab q_ub
        clra
        std  mal
        std  mn
        ldx  #qc_a
        stx  mb
        ldd  #2
        std  mbl
        ldx  q_u
        stx  mp
        bsr  mulp
        ldd  q_u                ; b + it, or b - it
        addd mn
        addd #2
        std  zp
        std  ze
        ldd  q_b
        addd mn
        std  zx
        ldd  qc_x
        subd q_m
        bcs  .mi
        bsr  add3
        bra  .sg
.mi:    bsr  sub3
.sg:    ldx  q_u                ; its size
        inx
        inx
        stx  ma
        tst  0,x
        bpl  .sq
        ldab q_ub
        bsr  negb_
.sq:    bsr  sqkn               ; squared, less kN
; divided by a, exactly: Montgomery's rows with a leave the quotient's negative in the low bytes
        ldab q_ub
        ldx  q_a
        abx
        dex
        ldaa 0,x                ; -1/a modulo 256
        bsr  inva
        stab zk
        ldx  q_a
        bsr  ycl
        ldab q_ub
        clra
        std  zt
        ldd  qc_e
        subd zt
        subd #1
        std  zp
        subb q_ub
        sbca #0
        subd #1
        std  ze
        ldx  qc_e
        ldaa 0,x
        staa zm
        ldab q_ub
        bsr  redr
        ldd  qc_e
        subb q_ub
        sbca #0
        subd #1
        std  qc_b
        xgdx
        ldab q_ub
        incb
        stab qc_n
        bsr  negb_
        bsr  trim
; ---- twos
.two:   ldx  qc_e
        dex
        ldab 0,x
        lsrb
        bcs  .odd
        bsr  half
        bra  .two
.odd:   ldx  q_p                ; the primes not sieved by
        ldab q_i0
        decb
        beq  .recs
.sm:    inx
        inx
        pshb
        pshx
        ldd  0,x
        bsr  divall
        pulx
        pulb
        decb
        bne  .sm
; the others: where the cell is at one of their roots
.recs:  ldx  q_rec
.r:     ldd  QR_R1,x
        bmi  .dir
        ldd  qc_x
.m:     subd QR_P,x
        bcc  .m
        addd QR_P,x
        subd QR_R1,x
        beq  .dir
        addd QR_R1,x
        subd QR_R2,x
        beq  .dir
.rn:    ldab q_rs
        abx
        cpx  q_rece
        bne  .r
        bra  .done
.dir:   pshx
        ldd  QR_P,x
        bsr  divall
        pulx
        bra  .rn
.done:  ldab qc_n               ; what is left: 1, or a prime within bounds, or nothing
        decb
        beq  .one
        decb
        bne  .x
        ldx  qc_b
        ldd  0,x
        bra  .lp
.one:   ldx  qc_b
        ldab 0,x
        clra
        cmpb #1
        beq  full
.lp:    std  kv_al
        subd q_lp
        bhs  .x
        ovjump OV_QSP,1         ; a partial relation
.x:     rts
full:   ovjump OV_QSP,0

; divall: the quotient divided by D as often as it goes
divall: std  td_p
        tba                     ; -1/p modulo 256
        bsr  inva
        stab td_i
.l:     bsr  divq
        beq  .l
        rts
hk_l:   bsr  pri
        fcl  "Relations "
        ldd  q_nr
        bsr  putw
        bsr  putsl
        ldd  q_need
        bra  putw
hk_q:   bsr  pri
        fcl  "QS "
        ldd  q_nr
        bsr  putw
        bsr  putsl
        ldd  q_need
        bra  putw
        include "qdiv.inc"
        include "mhook.inc"
hk_3    = pr_pct
