// Times the sieve: node tests/m_qs.js model digits seed [build dir]
'use strict';
const { BN, rng, HZ } = require('./lib');
const [model, digits, seed, bdir] = [process.argv[2], +process.argv[3], +process.argv[4], process.argv[5]];
const R = rng(seed * 1000 + digits);
const powm = (b, e, p) => { let r = 1n; b %= p; while (e) { if (e & 1n) r = r * b % p; b = b * b % p; e >>= 1n; } return r; };
const prime = (v) => { for (const p of [2n, 3n, 5n, 7n, 11n, 13n, 17n, 19n, 23n, 29n, 31n, 37n]) if (v % p === 0n) return v === p; let d = v - 1n, s = 0; while (!(d & 1n)) { d >>= 1n; s++; }
  next: for (const a of [2n, 3n, 5n, 7n, 11n, 13n, 17n]) { let x = powm(a, d, v); if (x === 1n || x === v - 1n) continue; for (let i = 1; i < s; i++) { x = x * x % v; if (x === v - 1n) continue next; } return false; } return true; };
const root = (v) => { let x = 1n << BigInt(Math.ceil(v.toString(2).length / 2)); for (;;) { const y = (x + v / x) / 2n; if (y >= x) return x; x = y; } };
const lo = root(10n ** BigInt(digits - 1)), hi = root(10n ** BigInt(digits));
const rp = () => { for (;;) { const v = lo + R.bits(Number((hi - lo).toString(2).length) + 8) % (hi - lo) | 1n; if (v < hi && prime(v)) return v; } };
const P = rp(), Q = rp(), N = P * Q;
const g = new BN(model, bdir ? { build: require('path').resolve(bdir) } : {}).start();
const r = g.line(`QS(${N})`, 1e9);
console.log(`${digits} digits ${N.toString(2).length} bits F ${g.peek('q_f')} s ${g.peek('q_s')} k ${g.peek('q_k')} ub ${g.peek('q_ub')} lp ${g.peekw('q_lp')} sv ${g.peekw('q_svz')}: ${(r.cycles / HZ).toFixed(0)} s ${r.val === P || r.val === Q ? 'ok' : 'WRONG ' + r.err + ' ' + r.val} N=${N}`);
