; =====================================================================
; The start-up code: assembled where the overlays go, stored on the pack after the resident code, run
; once. (The variables are zeros on the pack.) Entered with A = the device BNK came from.
; =====================================================================
        include "defs.inc"
        include "macros.inc"

kinit:  staa kv_dev
        pulx                    ; OPL's stack as it was
        stx  kv_osk
        pulx                    ; the bootstrap's own place, which is free now (past the name's place)
        xgdx
        subd #2+6+ZP_N          ; the zero page is kept in the launcher's code before it, which has run (the last of
        pshb                    ; it is the USR, 6 bytes before the bootstrap: tools/build.py checks)
        psha                    ; (its place stays on the stack: leave)
        ldx  #ZP_N
        stx  T0
        ldx  #ZP_1
        os   UT$CPYB
        ldx  #ZP_1
        clra
        ldab #ZP_1N
        os   UT$FILL
        ldx  #ZP_2
        clra
        ldab #ZP_2N
        os   UT$FILL
        pulx
        pshx
        ldab #6+ZP_N
        abx
        stx  kv_boot
        ldd  kv_osk             ; the slot ends there, or the sieve's variables do
        subd #ov_slot
        std  kv_slz
        ldx  #ov_slot
        stx  kv_slt
        ldx  RTA_SP             ; the block: from the bottom up to this code
        stx  kv_lo
        ldx  #entry
        stx  kv_hi
        ldaa KBB_STAT           ; the keyboard as it was, for leaving
        staa kv_kbst
        ldx  #MODEL&$FF00
        ldd  #$0210             ; two lines of 16
        tim  #8,MODEL&255,x     ; four-line (LZ, LZ64): bit 3 of the model byte
        beq  .two
        ldaa #1
        os   DP$MSET            ; four lines (the old mode kept for leaving)
        staa kv_oldm
        inc  kv_four
        ldd  #$0414
.two:   staa kv_h
        stab kv_w
        ldx  #kv_lbuf
        abx
        stx  kv_pe
        sts  kv_sp
; the pack addresses of the overlays: BNK's, and those in BNL
        ldx  #bnk_n
        bsr  open
        ldd  #22                ; past the stub, the build's number and the two sizes
        os   PK$SKIP
        os   PK$RWRD            ; the kernel's part
        os   PK$SKIP
        os   PK$QADD
        stab kv_bpa
        stx  kv_bpa+1
        ldx  #bnl_n
        bsr  open
        ldd  #16
        os   PK$SKIP
        os   PK$RWRD            ; (another version's?)
        subd #BUILD
        bne  .no
        os   PK$QADD
        stab kv_bpl
        stx  kv_bpl+1
        jmp  kgo
.no:    ldab #234               ; FILE NOT FOUND
        os   ER$MESS
        bra  leave
open:   ldab kv_dev
        addb #'A'
        stab 1,x
        ldab #$83
        os   FL$BOPN
        bcs  kinit.no
        rts

bnk_n:  fcl  "A:BNK"
bnl_n:  fcl  "A:BNL"
