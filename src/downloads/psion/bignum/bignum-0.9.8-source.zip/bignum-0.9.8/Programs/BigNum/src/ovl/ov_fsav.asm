; =====================================================================
; OV_FSAV: the top number (used up) written to the file whose name is at kv_lbuf (lbc)
; =====================================================================
        include "macros.inc"
        lastent save

fi_b    = kv_fs+16              ; (2) the record buffer
fi_i    = kv_fs+18              ; (2) the digit
REC     = 200
save:   ldx  #kv_lbuf           ; the name
        stx  zx
        ldx  #fname
        stx  zp
        ldd  #14
        bsr  cpb
        bsr  runon
        ldx  #fname             ; there already?
        os   FL$OPEN
        bcs  .new
        bsr  ask
        bcs  .x
        ldx  #fname
        os   FL$DELN
        bcs  oserr
.new:   bsr  decimal
        ldd  #REC+3
        bsr  walloc
        stx  fi_b
        ldaa fname+1            ; on A: room for the digits, and 4 bytes a record
        cmpa #'A'
        bne  .mk
        ldd  dg_n
        lsrd
        lsrd
        lsrd
        lsrd
        lsrd
        addd dg_n
        addd #80
        bsr  aroom
        bcs  nomem
.mk:    ldx  #fname
        os   FL$CRET
        bcs  oserr
        tab
        os   FL$RECT
        clra
        clrb
        std  fi_i
.rec:   ldx  fi_b               ; a record
        clr  0,x
        ldd  fi_i
        bne  .c
        tst  dg_neg
        beq  .c
        inc  0,x
        ldaa #'-'
        staa 1,x
.c:     ldd  fi_i
        bsr  dgch
        ldx  fi_b
        inc  0,x
        ldab 0,x
        abx
        staa 0,x
        ldx  fi_i
        inx
        stx  fi_i
        cpx  dg_n
        beq  .w
        ldx  fi_b
        ldab 0,x
        cmpb #REC
        bne  .c
.w:     ldx  fi_b
        os   FL$WRIT
        bcs  .full
        ldd  fi_i
        subd dg_n
        bne  .rec
        clr  kv_run
        bsr  ln0
        bsr  pri
        fcl  "Saved "
        ldd  dg_n
        bsr  pdig
        ldx  #kv_lbuf
        stx  zx
        ldx  #RTB_BL+1
        stx  zp
        ldab #20
        stab RTB_BL
        ldaa #E_MSG
        staa kv_err
        clra
        bsr  cpb
.x:     rts
.full:  pshb                    ; no room: nothing rather than half of it
        ldx  #fname
        os   FL$DELN
        pulb
oserr:  pshb
        bsr  cls
        pulb
        os   ER$MESS            ; (it waits for SPACE)
        rts
; ask: the file is there: may it go? carry set: no
ask:    bsr  cls
        bsr  ln0
        ldx  #fname
        bsr  prs
        bsr  pri
        fcl  " exists"
        bsr  out
        bsr  ln1
        bsr  pri
        fcl  "Replace? Y/N"
        bsr  out
.k:     bsr  getk
        cmpb #'Y'
        beq  .y
        cmpb #'N'
        beq  .n
        cmpb #K_ON
        bne  .k
.n:     sec
        rts
.y:     clc
        rts
fname:  rmb  14
        include "dec.inc"
        include "aroom.inc"
