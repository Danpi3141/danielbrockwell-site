; isp: Z if the number D on from the window's start (D even) is prime
isp:    lsrd
        bsr  ps_bit
        bitb 0,x
        rts
