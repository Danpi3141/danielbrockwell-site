; =====================================================================
; OV_CSHOW: the certificate (kv_rl to kv_lim), a line for each number proved and each prime with its witness; UP
; and DOWN go through it, EXE shows a number too long for its line.
; =====================================================================
        include "macros.inc"
        include "pv.inc"
        lastent cshow

cs_i    = kv_fs+16              ; the first line shown
cs_n    = kv_fs+17              ; how many
cs_l    = kv_fs+18              ; a row
cs_s    = kv_fs+19              ; a line after a third: the square test
cs_w    = kv_fs+20
cs_r    = kv_fs+21              ; (2) a record
cshow:  clr  cs_i
        ldab #255               ; how many lines
        bsr  find
        ldab cs_n
draw:   bsr  cls
        clr  cs_l
.l:     ldab cs_i
        addb cs_l
        bsr  find
        bcs  .keys
        bsr  line
        inc  cs_l
        ldaa cs_l
        cmpa kv_h
        bne  .l
.keys:  bsr  getk
        cmpb #K_DOWN
        beq  .down
        cmpb #K_UP
        beq  .up
        cmpb #K_EXE
        beq  .exe
        cmpb #K_ON
        beq  .x
        cmpb #K_MODE
        bne  .keys
.x:     rts
.down:  ldab cs_i
        incb
        addb kv_h
        decb
        bsr  find
        bcs  .keys
        inc  cs_i
        bra  draw
.up:    tst  cs_i
        beq  .keys
        dec  cs_i
        bra  draw
.exe:   ldab cs_i               ; the first line's number
        bsr  find
        tst  cs_s
        bne  .x
        bsr  num
        ovsub OV_DIGS,0
        ldaa #0
        ldab kv_w
        subb #8
        subd kv_digs
        bcc  .x
        ovsub OV_SHOW,1
        bra  draw
; find: line B: X = its record (cs_r), cs_s = 1 if it is the line after the records of a third; carry: none
find:   stab cs_w
        clr  cs_s
        clr  cs_n
        clr  kv_cy              ; 1: in a third
        ldx  kv_rl
.f:     stx  cs_r
        cpx  kv_lim
        beq  .end
        ldaa 0,x
        cmpa #PT_Q
        beq  .q
        bsr  .third             ; another number: the square test's line first
        beq  .got
        ldx  cs_r
        clr  kv_cy
        ldaa 0,x
        cmpa #PT_THIRD
        bne  .q
        inc  kv_cy
.q:     ldab cs_n
        cmpb cs_w
        beq  .yes
        inc  cs_n
        ldab #CT_N
        abx
        bsr  inext
        bra  .f
.end:   bsr  .third
        beq  .got
        sec
        rts
.third: clr  cs_s
        ldaa kv_cy
        beq  .nt
        ldab cs_n
        inc  cs_n
        inc  cs_s
        cmpb cs_w
        rts
.nt:    inca
        rts
.yes:   clr  cs_s
.got:   clc
        rts
; num: the record's number pushed, alone
num:    ldx  kv_vb
        stx  kv_wp
        ldx  cs_r
        ldab #CT_N
        abx
        bra  hcopy
; line: the line found, on row cs_l
line:   tst  cs_s
        bne  .sq
        ldx  cs_r
        ldaa 0,x
        cmpa #PT_Q
        beq  .q
        bsr  num
        ovsub OV_DIGS,0
        ldaa cs_l
        bsr  ln
        ldaa #'P'
        bsr  putc
        ldd  kv_digs
        bsr  putwp
        fcl  " by "
        ldx  cs_r
        ldaa 0,x
        cmpa #PT_PLUS
        beq  .plus
        cmpa #PT_THIRD
        beq  .third
        bsr  pri
        fcl  "N-1 half"
        bra  out
.third: bsr  pri
        fcl  "N-1 third"
        bra  out
.plus:  bsr  pri
        fcl  "N+1 D="
        ldx  cs_r
        ldd  1,x
        bra  putwo
.sq:    ldaa cs_l
        bsr  lnpri
        fcl  "square test pass"
        tst  kv_four
        beq  out
        bsr  pri
        fcl  "ed"
        bra  out
.q:     bsr  num                ; q=3998741 a=2
        bsr  decimal
        ldaa cs_l
        bsr  lnpri
        fcl  "q="
        ldab kv_w
        subb #7
        pshb
        clra
        subd dg_n
        pulb
        bcs  .cut
        ldab dg_n+1
        bsr  digs
        ldab #7                 ; (short ones in a column)
        ldaa dg_n+1
        cmpa #7
        bhs  .a
        sba
        nega
        tab
.sp:    bsr  putsp
        decb
        bne  .sp
        bra  .a
.cut:   subb #2
        bsr  digs
        ldaa #'.'
        bsr  putc
        bsr  putc
.a:     bsr  pri
        fcl  " a="
        ldx  cs_r
        ldd  1,x
        bra  putwo
digs:   stab cs_w
        clra
        clrb
.l:     pshb
        bsr  dgch
        bsr  putc
        pulb
        clra
        incb
        cmpb cs_w
        bne  .l
        rts
        include "dec.inc"
