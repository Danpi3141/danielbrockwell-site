; inv: the slot iv_a (a number less than the odd modulus of mctx, not 0) inverted modulo N, into slot
; iv_a; slots iv_a+1 to iv_a+3 are used. Carry set: there is none (the GCD is not 1).
; Binary: u = a, v = N, x = 1, y = 0 (slots iv_a, +1, +2, +3); u and v are halved while they are even and
; the smaller taken from the larger, x and y following, until one of them is 1 (or 0).
iv_a    = kv_fs+23
inv:    ldab iv_a               ; v = N
        incb
        bsr  mslot
        ldx  mnp
        bsr  cpn
        ldab iv_a               ; x = 1
        addb #2
        bsr  sone
        ldab iv_a               ; y = 0
        addb #3
        bsr  mslot
        xgdx
        bsr  clrxn
.l:     ldab iv_a
        bsr  halve              ; u, x
        ldab iv_a
        incb
        bsr  halve              ; v, y
        bsr  poll
        ldab iv_a               ; u against v
        incb
        bsr  mslot
        std  mb
        ldab iv_a
        bsr  mslot
        std  ma
        ldx  ma
        ldd  mb
        bsr  cmpn
        beq  .done              ; the same: the GCD
        bcs  .v
        ldab iv_a               ; u -= v, x -= y
        bsr  .less
        bra  .l
.v:     ldab iv_a               ; v -= u, y -= x
        incb
        bsr  .less
        bra  .l
.done:  ldx  ma                 ; is it 1?
        ldd  mn
        subd #1
        std  zt
        beq  .last
.z:     tst  0,x
        bne  .no
        inx
        ldd  zt
        subd #1
        std  zt
        bne  .z
.last:  ldaa 0,x
        deca
        bne  .no
        ldab iv_a               ; x is the answer
        stab mi
        addb #2
        stab mi+1
        ldab #M_CPY
        bsr  mop
        clc
        rts
.no:    sec
        rts
; slot B less the other of u, v (plain: it is the larger); and the same for x, y (modulo N)
.less:  stab mi
        stab mi+1
        eorb #1                 ; (iv_a is even)
        stab mi+2
        ldab mi
        bsr  mslot
        std  mrs
        addd mn
        std  zx
        std  ze
        ldab mi+2
        bsr  mslot
        addd mn
        std  zp
        bsr  sub3
        inc  mi
        inc  mi
        inc  mi+1
        inc  mi+1
        inc  mi+2
        inc  mi+2
        ldab #M_SUB
        bra  mop
; halve: slot B halved while it is even, and slot B+2 with it modulo N
halve:  stab mi
        bsr  mslot
        std  ma
        ldab mi
        addb #2
        bsr  mslot
        std  mb
.h:     ldd  ma
        addd mn
        xgdx
        dex
        ldaa 0,x
        lsra
        bcs  .x
        clc
        ldx  ma
        bsr  .ror
        ldd  mb                 ; x: if odd, N added first
        addd mn
        std  zx
        std  ze
        xgdx
        dex
        ldaa 0,x
        lsra
        bcc  .e
        ldx  mne
        stx  zp
        bsr  add3
        bra  .r
.e:     clc
.r:     ldx  mb
        bsr  .ror
        bra  .h
; the mn bytes at X shifted down one bit, the carry in at the top
.ror:   tpa
        psha
        ldd  mn
        tstb
        beq  .o
        inca
.o:     staa zt
        pula
        tap
.s:     ror  0,x
        inx
        decb
        bne  .s
        dec  zt
        bne  .s
.x:     rts
