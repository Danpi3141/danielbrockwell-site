; a list to pick from: A items; li_row draws item B at the pen. Back with B = the key that ended it, li_i = the
; item. UP, DOWN, and letters (the next item that begins with it).
li_n    = kv_fs+16              ; how many
li_i    = kv_fs+17              ; the one picked
li_t    = kv_fs+18              ; the one on the top line
li_r    = kv_fs+19              ; a line
li_k    = kv_fs+20              ; a key
list:   staa li_n
        clr  li_i
li_go:  clr  li_t
li_dr:  ldaa li_i               ; the one picked must be in sight
        suba li_t
        bcc  .b
        ldab li_i
        stab li_t
.b:     cmpa kv_h
        blo  .d
        ldab li_i
        subb kv_h
        incb
        stab li_t
.d:     bsr  cls
        clr  li_r
.r:     ldab li_t
        addb li_r
        cmpb li_n
        bhs  .k
        ldaa li_r
        bsr  item
        bsr  out
        inc  li_r
        ldaa li_r
        cmpa kv_h
        bne  .r
.k:     bsr  getk
        cmpb #K_UP
        beq  .up
        cmpb #K_DOWN
        beq  .down
        stab li_k
        cmpb #'A'
        blo  .x
        ldaa li_n               ; a letter: the next one it begins
        staa li_r
        ldab li_i
.s:     incb
        cmpb li_n
        blo  .c
        clrb
.c:     pshb
        clra
        bsr  item
        ldx  #kv_lbuf
        ldaa 1,x
        pulb
        cmpa li_k
        beq  .got
        dec  li_r
        bne  .s
        bra  .k
.got:   stab li_i
        bra  li_dr
.up:    tst  li_i
        beq  .k
        dec  li_i
        bra  li_dr
.down:  ldab li_i
        incb
        cmpb li_n
        bhs  .k
        stab li_i
        bra  li_dr
.x:     ldab li_k
        rts
item:   pshb
        bsr  ln
        pulb
        pshb
        ldaa #32
        cmpb li_i
        bne  .m
        ldaa #'>'
.m:     bsr  putc
        pulb
        bra  li_row
