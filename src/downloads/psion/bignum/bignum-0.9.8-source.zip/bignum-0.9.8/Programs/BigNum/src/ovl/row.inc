; chars: D = the characters of the number, with its sign
chars:  ldab dg_neg
        rolb
        rolb
        andb #1
        clra
        addd dg_n
        rts
; row: pg_w characters from pg_i on (moved on) on row A; A one more
row:    psha
        bsr  ln
        ldab pg_w
.n:     pshb
        bsr  chars
        subd pg_i
        bls  .e
        ldd  pg_i
        tst  dg_neg
        beq  .d
        subd #1                 ; (the sign is the first character)
        bcc  .d
        ldaa #'-'
        bra  .p
.d:     bsr  dgch
.p:     bsr  putc
        ldx  pg_i
        inx
        stx  pg_i
        pulb
        decb
        bne  .n
        pshb
.e:     pulb
        bsr  out
        pula
        inca
        rts
