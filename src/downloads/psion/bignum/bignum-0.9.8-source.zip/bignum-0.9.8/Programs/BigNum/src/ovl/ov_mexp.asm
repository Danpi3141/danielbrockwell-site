; =====================================================================
; OV_MEXP: MODEXP(a, e, m)
; =====================================================================
        include "macros.inc"
        include "ckn.inc"
        lastent modexp

modexp: ldx  kv_wp              ; m positive
        ldd  0,x
        beq  .arg
        bmi  .arg
        bsr  i2                 ; e not negative
        ldd  0,x
        bpl  .ok
.arg:   bra  errarg
.ok:    ovsub OV_DIGS,0         ; (m's, for the display)
        bsr  i3
        bsr  inext
        stx  kv_fs+10           ; the arguments' end
        bsr  hover3             ; a modulo m
        bsr  i2
        bsr  hcopy
        ovsub OV_DIV,1          ; a e m r
        ldx  kv_wp
        stx  kv_fs+12
        bsr  i2                 ; m = 1: 0
        ldd  0,x
        subd #1
        bne  .n1
        ldaa 2,x
        deca
        bne  .n1
        clra
        clrb
.num:   bsr  hpush
        bra  .close
.n1:    bsr  i3                 ; e = 0: 1
        stx  mx_e
        ldd  0,x
        bne  .e
        ldd  #1
        bra  .num
.e:     bsr  i2
        stx  kv_fs+14
        bsr  inext
        dex
        ldab 0,x
        lsrb
        bcs  .odd
        ovsub OV_MEVEN,0
        bra  .close
.odd:
        ldx  kv_fs+14           ; an odd modulus: room for windows?
        ldab #4
        stab mx_w
        bsr  ilen
        std  zt
        asld                    ; 12 n and some
        addd zt
        asld
        asld
        addd #40
        std  zt
        ldd  kv_wp
        subd kv_lim
        subd zt
        ldaa #1
        bcs  .w
        ldaa #4
.w:     staa mx_w
        ldab #2
        cmpa #1
        beq  .c
        ldab #10
.c:     stab ms_b
        ldx  kv_fs+14
        stx  ms_x
        ldd  #$FF00
        std  ms_o
        ovsub OV_MSET,0
        bsr  shown
        ldx  kv_fs+12           ; the base in slot 1, times R: through R squared in slot 0
        ldab #1
        bsr  toslot
        bsr  mrun
        mol   M_MUL,1,1,0
        bsr  mexp
        ldab #1                 ; and back
        bsr  sone
        bsr  mrun
        mol   M_MUL,0,0,1
        clrb
        bsr  fromslot
.close: bsr  hook0
        ldx  kv_fs+10
        bra  hslx

; the display
shown:  ldx  mx_e
        bsr  ilen
        asld
        asld
        asld
        bsr  part
        ovsub OV_EST,0
        ldx  #hook
        bra  hookx
hk_t:   fcl  "MODEXP  "
hk_p:   fcl  "Bit "
hk_q:   fcl  "MODEXP "
        include "bhook.inc"
        include "mslot.inc"
        include "mexp.inc"
        include "ckset.inc"
        include "cksafe.inc"
mx_set: ldaa #CK_MEXP
        bra  ckset
mx_safe = safe
