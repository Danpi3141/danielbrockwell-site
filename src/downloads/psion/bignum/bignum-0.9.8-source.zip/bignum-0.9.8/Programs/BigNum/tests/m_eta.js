// The first estimate of a long run against the time it took: node tests/m_eta.js [model] [line ...]
'use strict';
const { BN, HZ } = require('./lib');
const model = process.argv[2] || 'lz64';
const small = /^cm/.test(model);
const lines = process.argv.length > 3 ? process.argv.slice(3) : ['ISPRIME(2**127-1)', 'ISPRIME(2**521-1)', 'LLT(521)', 'LLT(1279)', 'MODEXP(3,2**521-2,2**521-1)', 'RHO((2**61-1)*(2**89-1))', 'PM1((2**61-1)*(2**89-1))', 'PP1((2**61-1)*(2**89-1))', 'ECM((2**61-1)*(2**89-1),1)'].concat(small ? [] : ['QS(353890612479965357292787308697)']);
for (const line of lines) {
  const g = new BN(model).start(), m = g.m;
  g.wait(); m.write(g.peekw('kv_line'), [line.length, ...[...line].map((x) => x.charCodeAt(0))]); g.poke('kv_cur', line.length); m.poke(0x76, 13);
  let first = null; const c0 = m.cycles(); const at = g.addr('t_idle');
  for (let i = 0; i < 4000 && !first; i++) { if (m.runTo([at], HZ / 4) === at && i > 8) break; const mm = g.text().match(/left ((\d+)d (\d+)h|(\d+):(\d+):(\d+))/); if (mm) first = mm[2] ? +mm[2] * 86400 + +mm[3] * 3600 : +mm[4] * 3600 + +mm[5] * 60 + +mm[6]; }
  const t1 = m.cycles(); m.runTo([at], HZ * 1e6);
  const took = (m.cycles() - t1) / HZ;
  console.log(`${model} ${line}: first estimate ${first} s, took ${took.toFixed(0)} s (${(first / took).toFixed(2)})`);
}
