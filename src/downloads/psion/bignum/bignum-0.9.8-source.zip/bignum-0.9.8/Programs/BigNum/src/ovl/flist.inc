        include "flnext.inc"
FL_E    = kv_fs                 ; fl_add: the exponent and the work of the record to add (19 bytes)
        ifused fl_add
; fl_add: the top number (dropped) added as a record of type A, with the exponent and work at FL_E, before
; the first larger one (the list is in order of size)
fl_add: staa kv_cy
        bsr  ilenw
        addd #FR_N+2
        std  kv_al              ; the record's bytes
        addd kv_lim
        bcs  nomem
        std  kv_se              ; the list's end
        ldd  kv_wp
        subd kv_se
        bcs  nomem
        ldx  kv_rl              ; its place
.f:     cpx  kv_lim
        beq  .at
        pshx
        ldab #FR_N
        abx
        ldd  kv_wp
        bsr  hcmp
        pulx
        bhi  .at
        bsr  fl_next
        bra  .f
.at:    stx  kv_ia
        ldd  kv_lim             ; those after it up
        std  zx
        subd kv_ia
        ldx  kv_se
        stx  zp
        bsr  cpd
        ldx  kv_ia
        ldaa kv_cy
        staa 0,x
        inx
        stx  zp
        ldx  #FL_E
        stx  zx
        ldd  #FL_LEN
        bsr  cpb
        ldx  kv_wp
        stx  zx
        ldd  kv_ia
        addd #FR_N
        std  zp
        ldd  kv_al
        subd #FR_N
        bsr  cpb
        ldd  kv_se
        std  kv_lim
        bra  hdrop
        endif
        ifused fl_new
; fl_new: FL_E = an exponent of 1 and no work
fl_new: ldx  #FL_E
        ldd  #FL_LEN
        bsr  clrx
        ldx  #FL_E
        inc  1,x
        rts
        endif
        ifused fl_get
; fl_get: FL_E = the exponent and work of the record at X (kept)
fl_get: pshx
        inx
        stx  zx
        ldx  #FL_E
        stx  zp
        ldd  #FL_LEN
        bsr  cpb
        pulx
        rts
        endif
        ifused fl_del
; fl_del: the record at X taken out
fl_del: pshx
        bsr  fl_next
        stx  zx
        pulx
        stx  zp
        ldd  kv_lim
        subd zx
        pshb
        psha
        ldd  zx
        subd zp
        std  kv_al
        ldd  kv_lim
        subd kv_al
        std  kv_lim
        pula
        pulb
        bra  cpb
        endif
