// The prime tests with little memory: the Lucas test in two slots (no 1, no P, no 2 kept), which is only used when there is
// no room for five. The block is made just big enough by moving the OS's memory up. Primes with every number of bits in the
// top byte, composites that pass base 2, the least block there is, and one kept in a tight block and resumed in a large one.
//   node tests/t_tight.js [model]
'use strict';
const { BN, HZ, rng } = require('./lib');
const model = process.argv[2] || 'cm'; const R = rng(7);
let bad = 0, n = 0, tight = 0; const fail = (s) => { console.log('FAIL', s); bad++; };
const pw = (a, e, m) => { let r = 1n; a %= m; for (; e; e >>= 1n) { if (e & 1n) r = r * a % m; a = a * a % m; } return r; };
const isP = (v) => v > 1n && [2n, 3n, 5n, 7n, 11n, 13n, 17n, 19n, 23n].every((a) => { if (v === a) return true; if (v % a === 0n) return false; let d = v - 1n, s = 0; while (!(d & 1n)) { d >>= 1n; s++; } let x = pw(a, d, v); if (x === 1n || x === v - 1n) return true; while (--s > 0) { x = x * x % v; if (x === v - 1n) return true; } return false; });
const spsp2 = (v) => { let d = v - 1n, s = 0; while (!(d & 1n)) { d >>= 1n; s++; } let x = pw(2n, d, v); if (x === 1n || x === v - 1n) return true; while (--s > 0) { x = x * x % v; if (x === v - 1n) return true; } return false; };
const g = new BN(model, { packC: { type: 1, size: 32 } }).start(), m = g.m; g.wait();
if (g.peek('kv_tier') < 4) { g.line('SET KEEP C:'); g.wait(); }                       // (before anything is moved: it makes the settings' file)
const ala = m.peekw(0x2040);
const home = () => { for (let i = 0; i < 8 && !g.atLine(); i++) { g.inject('ON'); g.wait(); } };
const heap = () => g.peekw('kv_hi') - g.peekw('kv_lo');
// the block made h bytes (at the next line)
const block = (h) => { home(); m.pokew(0x2040, ala); g.line('1'); home(); m.pokew(0x2040, ala + heap() - h); g.line('1'); home(); if (heap() !== h) fail(`block ${heap()}, not ${h}`); };
const luc = g.meta.ovl.indexOf('ov_luc') + 1;
// was the two-slot way taken? (lu_f, kv_fs+7, looked at when the Lucas test has begun)
const run = (v, want) => {
  const l = `ISPRIME(A)`; let f = -1; n++; home(); g.wait();
  m.write(g.peekw('kv_line'), [l.length, ...[...l].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', l.length); m.poke(0x76, 13);
  const idle = g.addr('t_idle'), hk = g.addr('sqrp');
  for (let i = 0; i < 1e6; i++) { const a = m.runTo([idle, hk], HZ * 3000); if (a === idle) break; if (g.peek('kv_res') === luc && g.peekw('kv_fs', 2) && f < 0) f = g.peek('kv_fs', 7); m.run(8); if (f >= 0) { m.runTo([idle], HZ * 1e6); break; } }
  g.wait(1e6); const err = g.atLine() ? g.peek('kv_err') : 0, val = err ? null : g.vars()['@'];
  if (err || val !== BigInt(want)) fail(`ISPRIME(${v}) in ${heap()}: error ${err}, ${val}, not ${want}`);
  if (f === 0) tight++; return f;
};
const set = (v) => { block(big); g.line('A=' + v); home(); };
const big = heap();
// A in a variable and 1 in ANS: too little for five slots (7 n + 32 free), enough for two
const nb = (v) => (v.toString(2).length + 7) >> 3;
const test = (v, want) => { const k = nb(v); set(v); block(k < 40 ? 9 * k + 36 : 6 * k + 60); const f = run(v, want); if (f === 1) fail(`${v}: five slots in ${heap()}`); };
// primes: every number of bits in the top byte (so every size of 256**n / N), random and as small and as large as can be
for (let b = 209; b <= 216; b++) { for (const v0 of [R.bits(b) | 1n | 1n << BigInt(b - 1), (1n << BigInt(b - 1)) + 1n, (1n << BigInt(b)) - 1n - 2000n | 1n]) { let v = v0; while (!isP(v)) v += 2n; test(v, 1); } }
for (const b of [128, 400]) { let v = R.bits(b) | 1n | 1n << BigInt(b - 1); while (!isP(v)) v += 2n; test(v, 1); }
test((1n << 127n) - 1n, 1); test((1n << 521n) - 1n, 1);                              // (n + 1 a power of 2)
// composites that pass base 2: p (2 p - 1), p (3 p - 2), Mersenne numbers and Fermat's
for (const [k, sh] of [[2n, 60n], [3n, 70n], [2n, 100n], [4n, 64n]]) for (let c = 0, p = (1n << sh) + 3n; c < 2; p += 2n) { if (!isP(p)) continue; const q = k * p - k + 1n; if (!isP(q)) continue; const v = p * q; if (!spsp2(v)) continue; c++; test(v, 0); }
test((1n << 128n) + 1n, 0); test((1n << 257n) - 1n, 0);
if (tight < 35) fail(`the two-slot way only ${tight} times`);
// the least block for a number in A, with 1 in ANS
{
  const v = (1n << 521n) - 1n, k = nb(v); set(v); const ok = (h) => { block(h); home(); const r = g.line('ISPRIME(A)', 1e5); return r.err === 0 && r.val === 1n; };
  let a = 4 * k, b = 9 * k; while (b - a > 1) { const c = (a + b) >> 1; if (ok(c)) b = c; else a = c; }
  console.log(`${model}: ISPRIME(A) of ${k} bytes, 1 in ANS: least block ${b} (${(b / k).toFixed(2)} n)`); if (b > 6 * k + 30) fail('least block ' + b);
}
// kept in a tight block (Lucas in two slots), resumed in the whole of it (five)
if (g.peek('kv_tier') < 4) {
  const v = (1n << 521n) - 1n; set(v); block(nb(v) * 6 + 48);
  const l = 'ISPRIME(A)'; g.wait(); m.write(g.peekw('kv_line'), [l.length, ...[...l].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', l.length); m.poke(0x76, 13);
  for (let i = 0; i < 400 && !/Lucas (bit )?[1-9]/.test(g.text()); i++) g.run(1); g.run(40); const f = g.peek('kv_fs', 7), at = g.lines().join(' ').trim();
  m.poke(0x76, 1); g.run(2); m.poke(0x76, 75); g.run(2); g.wait(600); home(); if (heap() > 1000) fail('the block grew'); block(big);
  g.wait(); m.write(g.peekw('kv_line'), [6, ...[...'RESUME'].map((c) => c.charCodeAt(0))]); g.poke('kv_cur', 6); m.poke(0x76, 13); m.run(3000); g.wait(60); g.inject('Y'); g.run(5); const at2 = g.lines().join(' ').trim(); g.run(1);
  g.wait(1e5); const r = g.vars()['@'];
  console.log(`kept at [${at}] lu_f ${f}, resumed [${at2}]: ${r}`); if (f !== 0 || r !== 1n) fail('keep and resume');
}
console.log(bad ? `${bad} FAILED` : `t_tight ${model} ok (${n} numbers, two slots ${tight} times)`);
process.exit(bad ? 1 : 0);
