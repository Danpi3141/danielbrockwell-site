; room: carry set if B times the number's bytes (fx_n) and 200 more are not free
room:   ldx  fx_n
        pshb
        bsr  ilen
        std  zt
        pulb
        pshb
        ldaa zt+1
        mul
        std  zp
        pulb
        ldaa zt
        mul
        tba
        clrb
        addd zp
        bcs  .x
        addd #200
        bcs  .x
        std  zt
        ldd  kv_wp
        subd kv_lim
        subd zt
.x:     rts
