; =====================================================================
; OV_QS: the quadratic sieve on the number at fx_n (odd, composite, not a power, no small factors): fx_found
; = 1 and a factor on top of the stack of numbers, or 0 (it did not work out).
; Entry 0: all of it.
; =====================================================================
        include "macros.inc"
        include "ckn.inc"
        include "fx.inc"
        include "qs.inc"
        lastent qs

qs:     ldaa #3                 ; (if none of the sets gives a factor, one time in a thousand: all over again)
        staa fx_rec
        ldd  kv_wp
        std  fx_wp
.again: ldx  fx_wp
        stx  kv_wp
        clr  fx_found
        ldaa #4
        staa fx_m
        ovsub OV_QS0,0          ; the multiplier, the sizes
        bcs  .none              ; (no room)
        ldab q_f                ; (the factor base takes about q_f / 16 seconds)
        lsrb
        lsrb
        lsrb
        lsrb
        clra
        bsr  setest
        ovsub OV_QS1,0          ; the factor base, the room
        bcs  .out               ; (a factor came up: pushed)
        ovsub OV_QEST,1
        ldd  kv_n+2
        ldx  kv_n
        bsr  setest2
        ldd  q_need
        bsr  part
        clra
        clrb
        std  q_svn
        std  q_svp
        ldaa #CK_QS
        bsr  ckset
.a:     ldaa fx_job             ; FACTOR's: how long the whole will take, as it looks now
        deca
        bne  .nj
        bsr  pr_ln
        ldd  kv_n+2
        addd kv_el+2
        std  fx_js+2
        ldd  kv_n
        adcb kv_el+1
        adca kv_el
        std  fx_js
        inc  kv_full
.nj:    bsr  safe
        ovsub OV_QSA,0          ; an a
        ovsub OV_QSV,0          ; all its polynomials
        ldd  q_nr
        subd q_need
        blo  .a
        ldaa q_f                ; (the combining, and a square root: about q_f squared / 512 seconds)
        tab
        mul
        tab
        lsrb
        clra
        bsr  setest
        ovsub OV_QSL,0          ; the combining
        ldd  kv_est+2           ; (a root takes half as long)
        lsrd
        std  kv_est+2
        ovsub OV_QSX,0          ; the factor
        tst  fx_found
        bne  .fin
        dec  fx_rec
        bne  .again
        bra  .none
.out:   inc  fx_found
.fin:   ldx  fx_wp
        bsr  hslx
        bra  hook0
.none:  ldx  fx_wp
        stx  kv_wp
        bra  hook0
setest: ldx  #0
setest2: stx kv_est
        std  kv_est+2
        rts
        include "ckset.inc"
        include "cksafe.inc"
