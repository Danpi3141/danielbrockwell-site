; =====================================================================
; OV_PRVM: the top number (a probable prime past 2**64, kept) proved: pv_t = how, or 0; the certificate from
; kv_rl up to kv_lim. Each large prime it rests on is proved the same way after it.
; =====================================================================
        include "macros.inc"
        include "fa.inc"
        include "pv.inc"
        lastent main_

main_:  ldx  kv_osp
        stx  pv_o
        stx  pv_c
        stx  kv_lim
        clra
        clrb
        std  pv_p
        ldaa #1
        staa pv_top
.num:   bsr  one
        tst  pv_t
        beq  .end
        tst  pv_top
        beq  .sub
        ldaa pv_t               ; (the result's is the first one's)
        psha
        clr  pv_top
        bra  .scan
.sub:   bsr  hdrop
.scan:  ldx  pv_c               ; a prime past 2**64 that has no proof of its own yet
.f:     cpx  kv_osp
        beq  .ok
        ldaa 0,x
        deca
        bne  .n
        inx
        inx
        inx
        bsr  ilen
        dex
        dex
        dex
        subd #8
        bls  .n
        bsr  has
        beq  .n
        ldab #CT_N
        abx
        bsr  hcopy
        bra  .num
.n:     bsr  ct_next
        bra  .f
.ok:    pula
        staa pv_t
.out:   ldx  pv_c
        stx  kv_rl
        ldx  kv_osp
        stx  kv_lim
        ldx  pv_o
        stx  kv_osp
        rts
.end:   tst  pv_top             ; no proof
        bne  .out
        pula
        bsr  hdrop
        bra  .out
; has: Z if the prime of the record at X (kept) has a proof
has:    pshx
        ldab #CT_N
        abx
        stx  kv_ia
        ldx  pv_c
.f:     cpx  kv_osp
        beq  .no
        ldaa 0,x
        deca
        beq  .n
        pshx
        ldab #CT_N
        abx
        ldd  kv_ia
        bsr  hcmp
        pulx
        beq  .x
.n:     bsr  ct_next
        bra  .f
.no:    ldaa #1
.x:     pulx
        rts
ct_next: ldab #CT_N
        abx
        bra  inext
; one: the top number: pv_t
one:    ldx  kv_wp
        stx  pv_m
        clr  pv_s
.s:     ldx  pv_m               ; N - 1 or N + 1
        stx  kv_wp
        bsr  hcopy
        bsr  hpush1
        ldab pv_s
        lsrb
        bcs  .plus
        bsr  hsub
        bra  .f
.plus:  bsr  hadd
.f:     ldaa #3                 ; by trial division, or the chain
        ldab pv_s
        lsrb
        lsrb
        bcc  .m
        ldaa #2
.m:     staa fa_m
        ldx  pv_esc
        stx  kv_esc
        ldx  pv_esc+2
        stx  kv_ssp
        ovsub OV_FACT,3
        ldx  pv_m
        stx  kv_wp
        ldx  pv_esc
        stx  kv_esc
        ldx  pv_esc+2
        stx  kv_ssp
        ovsub OV_PCHK,0
        tst  pv_t
        beq  .no
        ovsub OV_WIT,0
        tst  pv_t
        beq  .no
        ovsub OV_CERT,0
        rts
.no:    inc  pv_s
        ldaa pv_s
        cmpa #4
        bne  .s
        ldx  kv_osp
        stx  kv_lim
        rts
