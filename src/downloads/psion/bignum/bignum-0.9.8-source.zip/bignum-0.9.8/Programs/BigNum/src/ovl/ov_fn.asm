; =====================================================================
; OV_FN: GCD, LCM, JACOBI, ABS, SIZE
; =====================================================================
        include "macros.inc"
        entry f_gcd
        entry f_lcm
        entry f_jac
        entry f_abs
        lastent f_size

f_gcd:  bsr  f_abs
        bsr  hswap
        bsr  f_abs
        bsr  near
        bra  gcd
; near: if the lengths of the top two are far apart, the longer is first reduced by the other
near:   bsr  i2                 ; the second the longer
        ldd  kv_wp
        bsr  hcmp
        bcc  .o
        bsr  hswap
.o:     bsr  ilenw
        subd #0
        beq  .x
        std  kv_na
        bsr  i2
        bsr  ilen
        subd kv_na
        subd #3
        bls  .x
        bsr  hswap              ; a, b: b, a mod b
        bsr  hover
        ovsub OV_DIV,1
.x:     rts
; LCM: a b / GCD
f_lcm:  bsr  f_abs
        bsr  hswap
        bsr  f_abs
        bsr  hover              ; b a b
        bsr  hover              ; b a b a
        bsr  near
        bsr  gcd                ; b a g
        ldx  kv_wp              ; both 0: 0
        ldd  0,x
        beq  .z
        ovsub OV_DIV,0          ; b a/g
        bra  hmul
.z:     bra  hdrop2
f_abs:  ldx  kv_wp
        ldaa 0,x
        anda #$7F
        staa 0,x
        rts
; JACOBI(a, n): n odd and positive
f_jac:  bsr  ilenw
        bmi  arg
        subd #0
        beq  arg
        stx  zx
        addd zx
        xgdx
        ldab 1,x
        lsrb
        bcc  arg
        bsr  hswap              ; n a -> n, a mod n
        bsr  hover
        ovsub OV_DIV,1
        ldx  kv_wp
        ldd  0,x
        beq  .zero
        bsr  hswap
        bsr  gd_set             ; A = a mod n, B = n
        bsr  gd_odd             ; a's twos
        lsrb
        bcc  .o
        bsr  gd_lowb
        inca
        anda #4
        beq  .o
        bsr  gd_neg
.o:     bsr  gd_go
        bsr  gd_res
.one:   ldx  kv_wp              ; 0 unless the GCD is 1
        ldd  0,x
        subd #1
        bne  .no
        ldaa 2,x
        deca
        bne  .no
        ldaa gd_s
        oraa 0,x
        staa 0,x
        rts
.no:    bsr  hdrop
        clra
        clrb
        bra  hpush
.zero:  bsr  hdrop              ; a is 0 modulo n: 1 if n is 1
        clr  gd_s
        bra  .one
arg:    bra  errarg
; SIZE: the decimal digits, and the bits beside them
f_size: ovsub OV_DIGS,0
        bsr  hdrop
        ldd  kv_digs
        bsr  hpush
        ldaa #1
        staa kv_rk
        rts
        include "gcd.inc"
