; iszero: Z if slot B is 0
iszero: bsr  mslot
        xgdx
        ldd  mn
        std  zt
.l:     tst  0,x
        bne  .x
        inx
        ldd  zt
        subd #1
        std  zt
        bne  .l
.x:     rts
