; =====================================================================
; OV_SETF: the settings' file, BIGNUM on A: (one record: a version, then the settings). Entry 0: read, at the
; start (what they are at first, if there is none). 1: written.
; =====================================================================
        include "macros.inc"
        entry read
        lastent write

SF_VER  = 2
SF_LEN  = st_last-st_beep
read:   ldd  #10000             ; as they are at first
        std  st_tdiv
        ldd  #30
        std  st_every
        inc  st_beep
        ldd  #3030              ; (the smallest tier's rows are narrower)
        std  st_ups
        ldaa kv_tier
        cmpa #4
        beq  .s
        ldx  kv_rec
        clr  0,x
        ldd  #3600
        std  st_ups
.s:     bsr  .r
        bra  clean
.r:     bsr  open
        bcs  .x
        os   FL$RECT
        ldd  #1
        os   FL$RSET
        ldd  #1                 ; its length
        os   FL$FREC
        bcs  .x
        cmpa #SF_LEN+1
        bne  .x
        ldx  #RTB_BL
        os   FL$READ
        bcs  .x
        ldx  #RTB_BL
        ldd  0,x
        cmpb #SF_VER
        bne  .x
        ldx  #RTB_BL+2
        stx  zx
        ldx  #st_beep
        stx  zp
        ldd  #SF_LEN
        bra  cpb
.x:     rts
write:  bsr  open
        bcc  .old
        ldx  #name
        os   FL$CRET
        bcs  .x
        tab
.old:   os   FL$RECT
        ldd  #1
        os   FL$RSET
        os   FL$ERAS            ; (there may be none)
        ldx  #RTB_BL
        ldd  #(SF_LEN+1)*256+SF_VER
        std  0,x
        ldx  #st_beep
        stx  zx
        ldx  #RTB_BL+2
        stx  zp
        ldd  #SF_LEN
        bsr  cpb
        ldx  #RTB_BL
        os   FL$WRIT
        bcc  clean
.x:     pshb                    ; no room: the OS's message
        bsr  cls
        pulb
        os   ER$MESS
; on the smallest tier the rows' code lies in the buffer the file calls use: made again
clean:  ldaa kv_tier
        cmpa #4
        bne  .c
        ovsub OV_INIT,1
.c:     rts
open:   ldx  #name
        os   FL$OPEN
        tab
        rts
name:   fcl  "A:BIGNUM"
