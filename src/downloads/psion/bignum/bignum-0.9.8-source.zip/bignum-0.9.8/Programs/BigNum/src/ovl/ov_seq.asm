; =====================================================================
; OV_SEQ: FACT, PRIMORIAL, FIB, LUC
; =====================================================================
        include "macros.inc"
        entry f_fact
        entry f_prim
        entry f_fib
        lastent f_luc

sq_n    = kv_fs                 ; the argument
sq_k    = kv_fs+2
; arg16: the top number dropped into sq_n; more than 65535: TOO BIG; negative: BAD ARG
arg16:  bsr  word
        bne  big
        std  sq_n
        bra  hdrop
; FACT(n): small products gathered up to a row's width, then multiplied on
f_fact: bsr  arg16
        bsr  ones
        ldd  #1
        std  sq_k
.l:     ldd  sq_k
        subd sq_n
        bhs  fin
        ldd  sq_k
        addd #1
        std  sq_k
        bsr  gather
        bra  .l
ones:   bsr  hpush1
        bra  hpush1
; PRIMORIAL(n)
f_prim: bsr  arg16
        ldd  #PS_LEN
        bsr  walloc
        stx  ps_buf
        bsr  ones
        ldd  sq_n
        subd #2
        bcs  .e
        ldd  #2
        bsr  gather
        clrb
        ldx  #3
        bsr  ps_go
.l:     bsr  ps_next
        tst  ps_p
        bne  .e
        ldd  ps_p+1
        subd sq_n
        bhi  .e
        ldd  ps_p+1
        bsr  gather
        bra  .l
.e:     bsr  fin
        bsr  i2                 ; over the sieve's room
        ldab #PS_LEN
        abx
        bra  hslx

; FIB(n), LUC(n): a = F(k), b = F(k+1), k doubled for each bit of n
f_luc:  bsr  pair               ; 2 b - a
        bsr  hdup
        bsr  hadd
        bsr  hswap
        bsr  hsub
        bra  chk
f_fib:  bsr  pair
        bsr  hdrop
        bra  chk
pair:   bsr  arg16
        ldd  kv_cap
        asld
        asld
        asld
        asld
        subd sq_n               ; (F(n) has 0.69 n bits: an n past 16 x the cap in bytes is too big)
        bcs  big
        clra
        clrb
        bsr  hpush
        bsr  hpush1
        ldab #16
        stab sq_k
.l:     bsr  hover              ; a b a
        bsr  hover              ; a b a b
        bsr  hdup
        bsr  hadd
        bsr  hswap
        bsr  hsub               ; a b 2b-a
        bsr  hover3
        bsr  hmul               ; a b a'
        bsr  hswap              ; a a' b
        bsr  hsqr
        bsr  hover3             ; a a' b2 a
        bsr  hsqr
        bsr  hadd               ; a a' b'
        bsr  i3                 ; a goes: the two above it moved up
        stx  zx
        pshx
        bsr  inext
        stx  kv_se
        stx  zp
        pula
        pulb
        subd kv_wp
        std  kv_al
        ldd  kv_se
        subd kv_al
        std  kv_wp
        ldd  kv_al
        bsr  cpd
        ldd  sq_n
        asld
        std  sq_n
        bcc  .n
        bsr  hswap              ; one on: b, a + b
        bsr  hover
        bsr  hadd
.n:     dec  sq_k
        bne  .l
        rts
        include "gather.inc"
        include "hsqr.inc"
        include "primes.inc"
