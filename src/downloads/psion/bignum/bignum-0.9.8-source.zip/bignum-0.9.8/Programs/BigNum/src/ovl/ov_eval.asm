; =====================================================================
; OV_EVAL: a line read: entry 0 only checks it (and does it, if it is a command: then back to main);
; entry 1 works it out, the result left on the stack of numbers. Operators wait on a stack of their
; own (3 bytes each: the operator, its place in the line, the arguments so far) that grows up from
; kv_lo; every operator is carried out when one that binds less comes after it.
; =====================================================================
        include "macros.inc"
        entry check
        lastent work

O_ADD   = 1
O_SUB   = 2
O_MUL   = 3
O_DIV   = 4
O_MOD   = 5
O_NEG   = 6
O_POW   = 7
O_PAR   = 8                     ; (
O_FN    = 16                    ; functions, from here (their numbers in the table)

check:  ovsub OV_PRE,0          ; a command is done there; kv_dst, kv_tp0 past P=
        bra  go
work:   clr  kv_chk
go:     ldaa kv_tp0
        staa kv_tp
start:  ldx  kv_lo
        stx  kv_osp
        stx  kv_lim
        clr  kv_rk

; ---- an operand is wanted ----------------------------------------------
opnd:   bsr  nextc
        ldaa kv_tp
        deca
        staa kv_cp
        cmpb #'-'
        beq  .neg
        cmpb #'+'               ; (a plus in front says nothing)
        beq  opnd
        cmpb #'('
        beq  .par
        bsr  isdig
        bcc  num
        bsr  upc
        cmpb #'A'
        blo  syn
        cmpb #'Z'
        bhi  syn
        dec  kv_tp
        bsr  ident
        ldaa kv_id
        staa kv_cp
        decb
        beq  .var
        bsr  isans
        beq  .ans
        ovsub OV_NAMES,0        ; a function
        bcs  .nof
        bsr  nextc              ; its bracket must follow
        cmpb #'('
        bne  syn
        ldab kv_id
        stab kv_cp
        bsr  opush              ; two entries: its arguments, overlay and entry; then its place
        ldd  kv_fn
        std  0,x
        ldaa kv_fn+2
        staa 2,x
        ldaa #O_FN
        bsr  opush
        bra  opnd
.nof:   ldab kv_id
        bra  synat
.neg:   ldaa #O_NEG
        bra  .p
.par:   ldaa #O_PAR
.p:     bsr  opush
        bra  opnd
.ans:   ldab #'@'
        bra  .v
.var:   ldx  kv_line
        ldab kv_id
        abx
        ldab 0,x
        bsr  upc
.v:     tst  kv_chk
        bne  oper
        bsr  vfind
        bcs  .unset
        bsr  hcopy
        bra  oper
.unset: ldab kv_cp
        decb
        stab kv_epos
        ldab #E_SET
        bra  err

; a number: its digits four at a time
num:    tst  kv_chk
        bne  .skip
        dec  kv_tp
        clra
        clrb
        bsr  hpush
.g:     clra
        clrb
        std  kv_al              ; the group
        incb
        std  kv_se              ; 10 to the digits in it
        ldaa #4
        staa kv_cnt
.d:     bsr  nextd
        bcs  .e
        pshb
        ldd  kv_al
        bsr  x10
        std  kv_al
        pulb
        clra
        addd kv_al
        std  kv_al
        ldd  kv_se
        bsr  x10
        std  kv_se
        dec  kv_cnt
        bne  .d
        bsr  .put
        bra  .g
.e:     ldaa kv_cnt
        cmpa #4
        beq  oper
        bsr  .put
        bra  oper
.put:   ldd  kv_al
        std  kv_na
        ldd  kv_se
        bra  hmuladd
.skip:  bsr  nextd
        bcc  .skip
        bra  oper

; ---- an operator is wanted ----------------------------------------------
oper:   bsr  nextc
        ldaa kv_tp
        deca
        staa kv_cp
        tstb
        beq  .end
        cmpb #')'
        beq  .close
        cmpb #','
        beq  .comma
        ldaa #O_ADD
        cmpb #'+'
        beq  .op
        inca
        cmpb #'-'
        beq  .op
        inca
        cmpb #'*'
        beq  .mul
        inca
        cmpb #'/'
        beq  .op
        inca
        cmpb #'%'
        bne  syn
        bra  .op
.mul:   ldx  kv_line            ; ** ?
        ldab kv_tp
        cmpb 0,x
        bhi  .op
        abx
        ldab 0,x
        cmpb #'*'
        bne  .op
        inc  kv_tp
        ldaa #O_POW
.op:    psha                    ; those waiting that bind as much or more are done first
.ol:    bsr  otop
        beq  .push
        pulb
        pshb
        bsr  binds
        bcs  .push
        bsr  apply
        bra  .ol
.push:  pula
        bsr  opush
        bra  opnd
.end:   bsr  otop               ; the end: everything waiting
        beq  .fin
        cmpa #O_PAR
        bhs  .open
        bsr  apply
        bra  .end
.open:  bra  synend             ; (a bracket not closed)
.fin:   rts
.close: bsr  otop
        beq  syn
        cmpa #O_PAR
        beq  .pop
        bhi  .call
        bsr  apply
        bra  .close
.pop:   bsr  opop
        bra  oper
.comma: bsr  otop
        beq  syn
        cmpa #O_PAR
        beq  syn
        bhi  .arg
        bsr  apply
        bra  .comma
.arg:   inc  2,x
        bra  opnd
; a function's bracket closed
.call:  ldab 1,x
        decb
        stab kv_epos
        ldab 2,x                ; its arguments: as many as it wants?
        dex
        dex
        dex
        cmpb 0,x
        bne  synfn
        ldd  1,x
        pshb
        psha
        clr  kv_rk
        bsr  opop
        bsr  opop
        pula
        pulb
        tst  kv_chk
        bne  oper
        bsr  ovd
        bsr  chkbig
        bra  oper

synfn:  ldab 4,x
        bra  synat
syn:    ldab kv_tp              ; at the character just read
        decb
        ldx  kv_line
        cmpb 0,x
        bhi  synend
synat:  decb
        bra  synb
synend: ldx  kv_line
        ldab 0,x
synb:   stab kv_epos
        ldab #E_SYN
        bra  err

; ---- the operators' stack -------------------------------------------------
; opush: A pushed, with its place (kv_cp); a list of results there is given up
opush:  ldx  kv_osp
        staa 0,x
        ldab kv_cp
        stab 1,x
        ldab #1
        stab 2,x
        ldd  kv_osp
        addd #3
        std  kv_osp
        std  kv_lim
        clr  kv_rk
        ldd  kv_wp
        subd kv_osp
        bcs  nomem
        subd #3
        bcs  nomem
        rts
; opop: the top one dropped
opop:   ldd  kv_osp
        subd #3
        std  kv_osp
        tst  kv_rk              ; (a list of results lies on it: kv_lim stays)
        bne  .x
        std  kv_lim
.x:     rts
; otop: A = the top one, X its place; Z: there is none
otop:   ldx  kv_osp
        cpx  kv_lo
        beq  .x
        dex
        dex
        dex
        ldaa 0,x
.x:     rts
; binds: A waiting, B to come: carry clear if A is to be done first
binds:  cmpa #O_PAR
        bhs  .no
        cmpa #O_POW             ; ** waiting: before anything but another **
        bne  .a
        cmpb #O_POW
        beq  .no
        bra  .yes
.a:     cmpb #O_POW             ; ** to come: before anything else
        beq  .no
        cmpa #O_NEG
        beq  .yes
        cmpa #O_MUL
        bhs  .yes               ; * / % waiting
        cmpb #O_MUL             ; + - waiting: before + -
        bhs  .no
.yes:   clc
        rts
.no:    sec
        rts
; apply: the top operator carried out and dropped
apply:  bsr  otop
        psha
        ldab 1,x
        decb
        stab kv_epos
        clr  kv_rk
        bsr  opop
        pula
        tst  kv_chk
        bne  ap_x
        deca
        beq  .add
        deca
        beq  .sub
        deca
        beq  .mul
        deca
        beq  .div
        deca
        beq  .mod
        deca
        beq  .neg
        ovsub OV_POW,0
        bra  chkbig
.add:   bsr  hadd
        bra  chkbig
.sub:   bsr  hsub
        bra  chkbig
.neg:   bra  hneg
.div:   ovsub OV_DIV,0
        bra  chkbig
.mod:   ovsub OV_DIV,1
        bra  chkbig
.mul:   bsr  i2
        bsr  ilen
        std  zt
        bsr  ilenw
        addd zt
        subd #1
        bls  .m
        subd kv_cap
        bhi  big
.m:     bsr  hmul
chkbig: bsr  ilenw              ; the result must not be longer than the cap
        subd kv_cap
        bhi  big
ap_x:   rts
big:    bra  errbig

; ---- reading --------------------------------------------------------------
; nextc: B = the next character that is not a space (0: the end), kv_tp past it
nextc:  ldx  kv_line
        ldab kv_tp
        cmpb 0,x
        bhi  .end
        abx
        ldab 0,x
        inc  kv_tp
        cmpb #32
        beq  nextc
        rts
.end:   inc  kv_tp
        clrb
        rts
; nextd: B = the value of the digit at kv_tp, past it; carry set: it is not one
nextd:  ldx  kv_line
        ldab kv_tp
        cmpb 0,x
        bhi  .no
        abx
        ldab 0,x
        bsr  isdig
        bcs  .no
        inc  kv_tp
        rts
.no:    sec
        rts
isdig:  cmpb #'0'
        blo  .no
        cmpb #'9'
        bhi  .no
        subb #'0'
        clc
        rts
.no:    sec
        rts
; ident: the letters from kv_tp on (after spaces): kv_id where they start, B = kv_il how many (Z: 0)
ident:  bsr  nextc
        dec  kv_tp
        ldaa kv_tp
        staa kv_id
        clr  kv_il
.l:     ldx  kv_line
        ldab kv_tp
        cmpb 0,x
        bhi  .x
        abx
        ldab 0,x
        bsr  upc
        cmpb #'A'
        blo  .dg
        cmpb #'Z'
        bhi  .x
.in:    inc  kv_tp
        inc  kv_il
        bra  .l
.dg:    ldaa kv_il              ; (a digit after two letters: PM1)
        cmpa #2
        blo  .x
        bsr  isdig
        bcc  .in
.x:     ldab kv_il
        rts
; isans: Z if the name is ANS
isans:  ldab kv_il
        cmpb #3
        bne  .x
        ldx  kv_line
        ldab kv_id
        abx
        ldd  0,x
        anda #$DF
        andb #$DF
        subd #$414E             ; AN
        bne  .x
        ldab 2,x
        andb #$DF
        cmpb #'S'
.x:     rts
; vfind: B = a variable's letter: X = its item; carry set: it has nothing
vfind:  stab zm
        ldx  kv_vb
.f:     cpx  kv_hi
        beq  .no
        ldab zm
        cmpb 0,x
        beq  .y
        inx
        bsr  inext
        bra  .f
.y:     inx
        clc
        rts
.no:    sec
        rts
; x10: D = 10 D
x10:    asld
        std  zt
        asld
        asld
        addd zt
        rts
