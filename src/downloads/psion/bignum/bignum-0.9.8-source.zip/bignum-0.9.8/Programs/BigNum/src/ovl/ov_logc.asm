; =====================================================================
; OV_LOGC: a certificate (kv_rl to kv_lim) into the log: a line for each number proved and each prime
; =====================================================================
        include "macros.inc"
        include "pv.inc"
        lastent logc

lc_t    = kv_fx                 ; the kind of proof being written
lc_r    = kv_fx+1               ; (2) the record
logc:   clr  lc_t
        ldx  kv_rl
.l:     stx  lc_r
        cpx  kv_lim
        beq  sq
        ldaa 0,x
        deca
        beq  .q
        bsr  sq
        ldx  lc_r
        ldaa 0,x
        staa lc_t
        bsr  num
        bsr  digs0
        bsr  lnew
        ldaa #'P'
        bsr  putc
        ldd  dg_n
        bsr  putw
        bsr  llb
        ldx  #t2
        ldaa lc_t
        cmpa #PT_HALF
        beq  .t
        ldx  #t3
        cmpa #PT_THIRD
        beq  .t
        ldx  #t4
.t:     bsr  ltx
        ldaa lc_t
        cmpa #PT_PLUS
        bne  .n
        bsr  lnew
        ldx  lc_r
        ldd  1,x
        bsr  putw
        bsr  llb
.n:     ldaa #32
        bsr  lch
        bsr  digs1
        bra  .nx
.q:     ldx  #tq
        bsr  ltx
        bsr  num
        bsr  digs0
        bsr  digs1
        bsr  lnew
        bsr  pri
        fcl  " a="
        ldx  lc_r
        ldd  1,x
        bsr  putw
        bsr  llb
.nx:    bsr  flush
        ldx  lg_b
        stx  kv_wp
        ldx  lc_r
        ldab #CT_N
        abx
        bsr  inext
        bra  .l
; sq: the end of a third: the square test
sq:     ldaa lc_t
        cmpa #PT_THIRD
        bne  .x
        ldx  #t5
        bsr  ltx
        bra  flush
.x:     rts
num:    ldx  lc_r
        ldab #CT_N
        abx
        bra  hcopy
tq:     fcl  "q="
t2:     fcl  " by N-1 (half)"
t3:     fcl  " by N-1 (one third)"
t4:     fcl  " by N+1 P=2a Q=a*a-D D="
t5:     fcl  "square test passed"
        include "lg.inc"
        include "dec.inc"
