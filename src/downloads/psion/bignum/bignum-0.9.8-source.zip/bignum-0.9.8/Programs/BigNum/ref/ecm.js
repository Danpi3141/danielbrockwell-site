// ECM as the program does it (Suyama's curves from the same sigmas; primes to B1, then to 100 B1): which
// curves find which factors.   curveFinds(p, sigma, b1) -> 1 first stage, 2 second stage, 0 no
'use strict';
const primes = (() => { const n = 5100000, s = new Uint8Array(n + 1); const r = []; for (let i = 2; i <= n; i++) { if (!s[i]) { r.push(i); for (let j = i * i; j <= n; j += i) s[j] = 1; } } return r; })();
const mod = (a, m) => { a %= m; return a < 0n ? a + m : a; };
function powm(b, e, m) { let r = 1n; b = mod(b, m); while (e) { if (e & 1n) r = r * b % m; b = b * b % m; e >>= 1n; } return r; }
// over a prime p: the point's multiple by the group order's test: work with the point itself
function curve(p, sigma) {
  const s = BigInt(sigma), u = mod(s * s - 5n, p), v = mod(4n * s, p);
  const d = mod(16n * u * u * u * v, p); if (d === 0n) return null;
  return { x: u * u * u % p, z: v * v * v % p, a: mod((v - u) ** 3n * (3n * u + v), p) * powm(d, p - 2n, p) % p };
}
const dbl = (P, a, p) => { const t1 = (P.x + P.z) ** 2n % p, t2 = mod(P.x - P.z, p) ** 2n % p, t3 = mod(t1 - t2, p); return { x: t1 * t2 % p, z: t3 * (t2 + a * t3) % p }; };
const add = (P, Q, D, p) => { const u = mod(P.x - P.z, p) * (Q.x + Q.z) % p, v = (P.x + P.z) * mod(Q.x - Q.z, p) % p; return { x: (u + v) ** 2n % p * D.z % p, z: mod(u - v, p) ** 2n % p * D.x % p }; };
function mul(k, P, a, p) { if (k === 1n) return P; let R0 = P, R1 = dbl(P, a, p); for (const b of k.toString(2).slice(1)) { if (b === '1') { R0 = add(R0, R1, P, p); R1 = dbl(R1, a, p); } else { R1 = add(R0, R1, P, p); R0 = dbl(R0, a, p); } } return R0; }
function curveFinds(p, sigma, b1) {
  const c = curve(p, sigma); if (!c) return 1;
  let Q = { x: c.x, z: c.z }; let e = 1n;
  for (const q of primes) { if (q > b1) break; let k = q; while (k * q <= b1) k *= q; e *= BigInt(k); if (e > 1n << 200n) { Q = mul(e, Q, c.a, p); e = 1n; } }
  Q = mul(e, Q, c.a, p);
  if (Q.z === 0n) return 1;
  // a prime q in (b1, 100 b1] with q Q = O: the order of Q; by baby steps over the primes' gaps
  const D = 210; const m0 = Math.floor((b1 + 105) / 210); const b2 = 100 * b1;
  const S = mul(BigInt(D), Q, c.a, p); let Rp = mul(BigInt(m0 - 1 || 1), S, c.a, p), R = mul(BigInt(m0), S, c.a, p);
  const us = []; const tab = {}; { let a = Q, b = Q; const Q2 = dbl(Q, c.a, p); for (let u = 1; u < 105; u += 2) { if (u % 3 && u % 5 && u % 7) { us.push(u); tab[u] = a; } const n = add(a, Q2, b, p); b = a; a = n; } }
  if (!curveFinds.set) { curveFinds.set = new Uint8Array(5200000); for (const q of primes) curveFinds.set[q] = 1; }
  const isp = curveFinds.set;
  let end = 210 * m0 - 105; while (end < b2) end += 2100;
  for (let m = m0; 210 * m - 105 < end; m++) { const c0 = 210 * m; for (const u of us) if (isp[c0 + u] || isp[c0 - u]) { if (mod(R.x * tab[u].z - tab[u].x * R.z, p) === 0n) return 2; } const n = add(R, S, Rp, p); Rp = R; R = n; }
  return 0;
}
module.exports = { curveFinds, primes, powm };
