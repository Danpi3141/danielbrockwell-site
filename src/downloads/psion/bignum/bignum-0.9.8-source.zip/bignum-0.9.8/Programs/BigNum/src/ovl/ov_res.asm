; =====================================================================
; OV_RES: RESUME: the job kept in BIGKEEP is shown; Y: its line is run again (its variables put back), and what was
; kept is picked up on the way (OV_CKL).
; =====================================================================
        include "macros.inc"
        lastent res

re_r    = kv_fs+16              ; (2) the record
re_s    = kv_fs+18              ; (2) the checksum
re_m    = kv_fs+20              ; the method
re_l    = kv_fs+21              ; (2) bytes of a variable to come
re_v    = kv_fs+23              ; its letter
res:    clr  RTB_BL
        ldaa kv_tier
        cmpa #4
        bne  .ok
        ldab #E_AVL
        clr  kv_epos
        bra  err
.ok:    ldaa #1                 ; on A:, B: or C:
.dev:   staa kv_ckv
        adda #'A'-1
        staa name+1
        ldx  #name
        os   FL$OPEN
        bcc  .got
        ldaa kv_ckv
        inca
        cmpa #4
        bne  .dev
.none:  bsr  cls
        bsr  ln0
        bsr  pri
        fcl  "Nothing kept"
        bsr  out
        bra  getk
.got:   tab
        os   FL$RECT
        bsr  check
        bcs  .none
; shown
        bsr  cls
        tst  kv_four
        beq  .two
        bsr  ln0
        bsr  pri
        fcl  "Kept run:"
        bsr  out
        ldaa #1
.two:   bsr  ln                 ; (A: 0 on two lines)
        bsr  first
        ldx  #buf
        ldab 0,x
        cmpb kv_w
        bls  .s
        ldab kv_w
.s:     inx
        bsr  prb
        bsr  out
        ldaa #2
        tst  kv_four
        beq  .q
        bsr  ln
        ldx  #names
        ldab re_m
.f:     decb
        beq  .n
        pshb
        ldab 0,x
        incb
        abx
        pulb
        bra  .f
.n:     bsr  prs
        bsr  out
.q:     ldaa kv_h
        deca
        bsr  lnpri
        fcl  "Resume? Y/N"
        bsr  out
.k:     bsr  getk
        cmpb #'N'
        beq  .x
        cmpb #K_ON
        beq  .x
        cmpb #'Y'
        bne  .k
; the variables
        ldx  kv_vb
        stx  kv_wp
        ldx  #2
        stx  re_r
        ldx  #0
        stx  re_l
.v:     ldd  re_r
        os   FL$RSET
        ldx  #buf
        os   FL$READ
        bcs  .run
        ldaa buf+1
        cmpa #'V'
        bne  .run
        bsr  decode
        ldx  re_l
        bne  .more
        ldaa buf+2              ; a new one
        staa re_v
        ldd  buf+3
        anda #$7F
        addd #2
        std  re_l
        bsr  walloc
        stx  re_p
        ldx  #buf+3
        dec  buf
        bra  .cp
.more:  ldx  #buf+2
.cp:    stx  zx
        ldx  re_p
        stx  zp
        ldab buf
        clra
        std  kv_al
        bsr  cpb
        ldx  zp
        stx  re_p
        ldd  re_l
        subd kv_al
        std  re_l
        bne  .nx
        ldaa re_v
        staa kv_dst
        ovsub OV_SHOW,5         ; kept
        ldx  kv_vb
        stx  kv_wp
        bsr  reopen
.nx:    ldx  re_r
        inx
        stx  re_r
        bra  .v
.run:   bsr  first              ; the line, and off
        ldx  #buf
        stx  zx
        ldx  kv_line
        stx  zp
        ldab buf
        clra
        addd #1
        bsr  cpb
        ldaa #$80
        staa kv_ckd
        jmp  main_go
.x:     rts
re_p    = kv_fx                 ; (2) where a variable's next bytes go
reopen: ldaa kv_ckv
        adda #'A'-1
        staa name+1
        ldx  #name
        os   FL$OPEN
        tab
        os   FL$RECT
        rts
; first: the line at buf
first:  ldd  #1
        os   FL$RSET
        ldx  #buf
        os   FL$READ
        rts
; check: the checksum, and re_m; carry set: it is not whole
check:  clra
        clrb
        std  re_s
        clr  re_m
        ldx  #0
.r:     inx
        stx  re_r
        xgdx
        os   FL$RSET
        ldx  #buf
        os   FL$READ
        bcs  .bad
        ldx  re_r
        dex
        beq  .sum
        ldaa buf+1
        cmpa #'E'
        beq  .e
        cmpa #'S'
        bne  .sum
        tst  re_m
        bne  .sum
        ldaa buf+3              ; (the number of the method: 1 to 10, two digits)
        suba #'0'
        cmpa #9
        bls  .m
        suba #7
.m:     staa re_m
.sum:   ldx  #buf
        ldab 0,x
        beq  .n
.s:     inx
        pshb
        ldab 0,x
        clra
        addd re_s
        std  re_s
        pulb
        decb
        bne  .s
.n:     ldx  re_r
        bra  .r
.e:     bsr  decode
        ldd  buf+2
        subd re_s
        bne  .bad
        tst  re_m
        beq  .bad
        clc
        rts
.bad:   sec
        rts
; decode: the hex digits of the record at buf made bytes, buf = how many
decode: ldab buf
        decb
        lsrb
        stab buf
        ldx  #buf+2
        stx  zx
        stx  zp
.l:     pshb
        ldx  zx
        ldaa 0,x
        bsr  hex
        asla
        asla
        asla
        asla
        staa zm
        ldaa 1,x
        bsr  hex
        oraa zm
        inx
        inx
        stx  zx
        ldx  zp
        staa 0,x
        inx
        stx  zp
        pulb
        decb
        bne  .l
        rts
hex:    suba #'0'
        cmpa #9
        bls  .x
        suba #7
.x:     rts
name:   fcl  "A:BIGKEEP"
names:  fcl  "Base 2 test"
        fcl  "Lucas test"
        fcl  "MODEXP"
        fcl  "LLT"
        fcl  "RHO"
        fcl  "P-1, P+1"
        fcl  "P-1, P+1 stage 2"
        fcl  "ECM stage 1"
        fcl  "ECM stage 2"
        fcl  "QS"
buf:    rmb  256
