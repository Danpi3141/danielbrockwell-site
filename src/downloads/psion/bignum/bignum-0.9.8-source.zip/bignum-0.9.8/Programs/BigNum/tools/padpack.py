#!/usr/bin/env python3
"""A test pack: the program's files plus PAD (an array of N words, then BLACKJ; with --nocheck a
BLACKJ whose memory check always passes: the program's own limit).
    python tools/padpack.py N out.opk [--nocheck]"""
import os
import re
import sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import pack  # noqa: E402
b = os.path.join(os.path.dirname(HERE), 'build', 'game')
n, out = int(sys.argv[1]), sys.argv[2]
d = os.path.dirname(out)
pad = os.path.join(d, 'PAD%d.opl' % n)
with open(pad, 'w', encoding='latin-1', newline='\n') as f:
    f.write('PAD:\nLOCAL p%%(%d)\nBLACKJ:\n' % max(n, 1))
img = pack.PackImage('datapak', 32, target='cm')
bj = os.path.join(b, 'BLACKJ.opl')
if '--nocheck' in sys.argv:
    t = open(bj, encoding='latin-1').read()
    t = re.sub(r'n%=\d+', 'n%=0', t, count=1)
    bj = os.path.join(d, 'nc%d.opl' % n)
    with open(bj, 'w', encoding='latin-1', newline='\n') as f:
        f.write(t)
img.add_opl(pad, source=False)
img.add_opl(bj)
img.add_opl(os.path.join(b, 'BJG.opl'), source=False)
img.add_data('BJK', open(os.path.join(b, 'bjk.bin'), 'rb').read())
img.write(out)
