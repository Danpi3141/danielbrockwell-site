; =====================================================================
; OV_RHO: Pollard's rho (Brent's version) on the number at fx_n, up to fx_lim steps: fx_found = 1 and the
; factor on top of the stack of numbers, or 0. The differences are gathered for RB steps between GCDs; if
; a GCD is the number itself the batch is gone through again a step at a time.
; =====================================================================
        include "macros.inc"
        include "ckn.inc"
        include "fx.inc"
        lastent rho

RB      = 100
rh_r    = kv_fs                 ; the length of the run (r)
rh_k    = kv_fs+2               ; steps of it done
rh_j    = kv_fs+4               ; steps of the batch
rh_c    = kv_fs+5               ; the constant (1 to 3)
; slots: 0 x, 1 y, 2 the product, 3 y before the batch, 4 scratch, 5 the constant
rho:    ldd  kv_wp
        std  fx_wp
        clr  fx_found
        clr  fx_m
        ldaa #1
        staa rh_c
        ldx  fx_n
        mset 6,NO,NO
        bsr  useful             ; the steps there will be
        bsr  part
        ovsub OV_EST,5
        ldx  #hook
        bsr  hookx
.new:   ldab #5                 ; the constant
        bsr  sone
        ldaa rh_c
        staa 0,x
        ldab #1                 ; y = 2
        bsr  sone
        ldaa #2
        staa 0,x
        ldab #2                 ; the product: not 0 (1 will do, whatever it stands for)
        bsr  sone
        ldd  #1
        std  rh_r
        ldaa #CK_RHO
        bsr  ckset
        bcc  .run
        ldab #5                 ; (the constant as it was)
        bsr  sone
        ldaa rh_c
        staa 0,x
        bra  .bat
.run:   bsr  mrun               ; x = y
        mol   M_CPY,0,1,1
        ldd  rh_r               ; r steps
.s1:    pshb
        psha
        bsr  step
        pula
        pulb
        subd #1
        bne  .s1
        clra
        clrb
        std  rh_k
.bat:   bsr  safe
        bsr  mrun
        mol   M_CPY,3,1,1
        ldd  rh_r               ; a batch: the smaller of RB and what is left of the run
        subd rh_k
        subd #RB
        bcs  .few
        ldab #RB
        bra  .b
.few:   addb #RB
.b:     stab rh_j               ; (and no further than the last step)
        ldd  kv_tot
        subd kv_done
        tsta
        bne  .b2
        tstb
        beq  .b2
        cmpb rh_j
        bhs  .b2
        stab rh_j
.b2:    ldab rh_j
        clra
        addd rh_k
        std  rh_k
.bl:    bsr  step
        bsr  mrun
        mo    M_SUB,4,0,1
        mol   M_MUL,2,2,4
        dec  rh_j
        bne  .bl
        ldab #2
        bsr  sgcd               ; the GCD of slot 2 and the number, on the stack
        bsr  kind
        beq  .more              ; 1
        bcs  found
        bra  .back
.more:  bsr  hdrop
        ldd  kv_done            ; all the steps done?
        subd kv_tot
        bhs  .none
        ldd  rh_k
        subd rh_r
        bcs  .bat
        ldd  rh_r
        asld
        std  rh_r
        bra  .run
; the number itself: the batch again, a step at a time
.back:  bsr  hdrop
        bsr  mrun
        mol   M_CPY,1,3,3
.bk:    bsr  step
        bsr  mrun
        mol   M_SUB,4,0,1
        ldab #4
        bsr  sgcd
        bsr  kind
        beq  .b1
        bcs  found
        bsr  hdrop              ; the number again: another constant
        inc  rh_c
        ldaa rh_c
        cmpa #4
        bne  .new
.none:  ldd  fx_lim             ; (as good as so many: for the work noted)
        std  kv_done
        ldx  fx_wp
        stx  kv_wp
        bra  hook0
.b1:    bsr  hdrop
        bra  .bk
found:  inc  fx_found
        ldx  fx_wp
        bsr  hslx
        bra  hook0
; useful: D = fx_lim, or fewer: a run's first r steps find nothing (they have no differences), so if the limit falls in
; them they are not begun. The runs before end at s = 4 r - 2 steps, for r = 1, 2, 4...
useful: ldd  #2
.l:     std  zt                 ; s
        addd #2                 ; the next one's first steps: s + (s + 2) / 2
        bcs  .s
        lsrd
        addd zt
        bcs  .s
        subd fx_lim
        bhs  .s
        ldd  zt                 ; or the limit is among those that count, up to 2 s + 2
        asld
        bcs  .all
        addd #2
        bcs  .all
        std  zp
        subd fx_lim
        bhs  .all
        ldd  zp
        bra  .l
.s:     ldd  zt
        rts
.all:   ldd  fx_lim
        rts
; step: y = y y + c
step:   ldx  kv_done
        inx
        stx  kv_done
        bsr  mrun
        mo    M_SQR,1,1,1
        mol   M_ADD,1,1,5
        rts
        include "sgcd.inc"
hk_l:   bsr  pri
        fcl  "Step "
        ldd  kv_done
        bsr  putw
        bsr  putsl
        ldd  kv_tot
        bra  putw
hk_q:   bsr  pri
        fcl  "RHO"
        rts
        include "mhook.inc"
hk_3    = pr_pct
        include "mslot.inc"
        include "ckset.inc"
        include "cksafe.inc"
