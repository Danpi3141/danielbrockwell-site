// Test helpers: BigNum on an emulated Organiser (tools/emu.js). The kernel is found in RAM by its
// "BNK1" tag (base = tag - 3); its variables through build/game/kernel.sym.json.
'use strict';
const fs = require('fs');
const path = require('path');
const { Machine } = require('../tools/emu');

const ROOT = path.join(__dirname, '..');
const TAG = [0x42, 0x4E, 0x4B, 0x31];
const MODELS = {
  cm: { rom: '33-cm.rom', ram: 8 }, cm24: { rom: '24-cm.rom', ram: 8 }, cm26: { rom: '26-cm.rom', ram: 8 },
  xp: { rom: '31-xp.rom', ram: 16 }, xp24: { rom: '24-xp.rom', ram: 16 }, xp26: { rom: '26-xp.rom', ram: 16 },
  la: { rom: '36-la.rom', ram: 32 }, lz: { rom: '46-lz.rom', ram: 32 }, lz64: { rom: '46a-lz64.rom', ram: 64 },
};
const ROMS = {
  '24-cm.rom': 8, '26-cm.rom': 8, '33-cm.rom': 8, '33-cmf.rom': 8, '36-cmf.rom': 8,
  '24-xp.rom': 16, '26-xp.rom': 16, '31-xp.rom': 16,
  '30-lahp.rom': 32, '33-la.rom': 32, '34-lag.rom': 32, '36-la.rom': 32, '36-laf.rom': 32, '36-lag.rom': 32, '37-lam.rom': 32,
  '42-lz.rom': 32, '44-lz.rom': 32, '45-lz.rom': 32, '45-lzi.rom': 32, '45-lzs.rom': 32, '46-lz.rom': 32, '46-lzi.rom': 32,
  '43-lz64.rom': 64, '44-lz64.rom': 64, '45-lz64.rom': 64, '46a-lz64.rom': 64, '46b-lz64.rom': 64, '46-lz64i.rom': 64, '46-lz64s.rom': 64,
};
const HZ = 921600;

// BigInt <-> bytes, highest first
function toBytes(v, n) { const r = []; let x = v < 0n ? -v : v; while (x > 0n) { r.unshift(Number(x & 255n)); x >>= 8n; } while (n !== undefined && r.length < n) r.unshift(0); return r; }
function fromBytes(b) { let s = ''; for (const v of b) s += v.toString(16).padStart(2, '0'); return s ? BigInt('0x' + s) : 0n; }
function item(v) { const b = toBytes(v); const h = b.length | (v < 0n ? 0x8000 : 0); return [h >> 8, h & 255, ...b]; }

class BN {
  constructor(model = 'lz64', opts = {}) {
    this.model = model;
    const mm = MODELS[model] || (ROMS[model] ? { rom: model, ram: ROMS[model] } : null);
    if (!mm) throw new Error('no model ' + model);
    this.m = new Machine({ rom: mm.rom, ram: mm.ram });
    this.four = this.m.lines === 4;
    this.bdir = opts.build || path.join(ROOT, 'build', 'game');
    this.sym = JSON.parse(fs.readFileSync(path.join(this.bdir, 'kernel.sym.json'), 'utf8'));
    this.osym = JSON.parse(fs.readFileSync(path.join(this.bdir, 'ovl.sym.json'), 'utf8'));
    this.meta = JSON.parse(fs.readFileSync(path.join(this.bdir, 'build.json'), 'utf8'));
    this.m.boot();
    if (opts.packC) this.m.emptyPack(opts.packC.type, opts.packC.size, 1);
    this.m.insertPack(opts.pack || path.join(this.bdir, 'BIGNUM.opk'), 0);
    this.base = -1;
    this.free0 = this.free();
  }
  // free memory as OPL's FREE sees it at the moment
  free() { return this.m.peekw(0xA5) - this.m.peekw(0x2040) - 256; }
  text() { return this.m.screenText(); }
  lines() { return this.m.screen(); }
  has(re) { return re.test(this.text()); }
  sync() { const a = this.m.find(TAG, 0x2000, 0xFFF0); this.base = a >= 0 ? a - 3 : -1; return this.base; }
  start(maxSec = 20, proc = 'BIGNUM') {
    for (let a; (a = this.m.find(TAG, 0x2000, 0xFFF0)) >= 0;) this.m.poke(a, 0);   // stale tags in freed RAM
    this.m.runProc(proc, 'B');
    for (let i = 0; i < maxSec * 10; i++) {
      this.m.runSeconds(0.1);
      if (this.sync() >= 0) { this.run(0.5); return this; }
    }
    throw new Error('BIGNUM did not start\n' + this.text());
  }
  addr(name) {
    const s = this.sym[name];
    if (!s) throw new Error('no symbol ' + name);
    return s[1] === 'abs' ? s[0] : this.base + s[0];
  }
  // an overlay's own symbol
  oaddr(ov, name) { const s = this.osym[ov][name]; if (!s) throw new Error(ov + ' has no ' + name); return s[1] === 'abs' ? s[0] : this.base + s[0]; }
  peek(n, o = 0) { return this.m.peek(this.addr(n) + o); }
  peekw(n, o = 0) { return this.m.peekw(this.addr(n) + o); }
  poke(n, v, o = 0) { this.m.poke(this.addr(n) + o, v); }
  pokew(n, v, o = 0) { this.m.pokew(this.addr(n) + o, v); }
  read(n, len, o = 0) { return this.m.read(this.addr(n) + o, len); }
  run(s) { this.m.runSeconds(s); return this; }
  press(k, hold = 3, gap = 4) { this.m.press(k, hold, gap); return this; }
  key(k, s = 0.3) { this.press(k); this.run(s); return this; }
  // ---- calling the machine code
  // calls a resident routine (or an address) with registers; returns {d, x, carry, cycles}
  call(where, regs = {}, maxSec = 600) {
    const m = this.m, d = m.dbg;
    const a = typeof where === 'number' ? where : this.addr(where);
    this.park();
    const ret = this.addr('leave');                  // (a breakpoint: never run on from)
    const sp = d.sp();
    // Jape's SP points at the last byte pushed
    m.poke(sp - 1, ret & 255); m.poke(sp - 2, ret >> 8);
    d.setSP(sp - 2);
    if (regs.d !== undefined) { d.setA(regs.d >> 8); d.setB(regs.d & 255); }
    if (regs.a !== undefined) d.setA(regs.a);
    if (regs.b !== undefined) d.setB(regs.b);
    if (regs.x !== undefined) d.setX(regs.x);
    d.setPC(a);
    const c0 = d.cycles();
    const r = m.runTo([ret], HZ * maxSec);
    if (r !== ret) throw new Error('call ' + where + ' did not return; pc ' + d.pc().toString(16));
    const out = { d: d.d(), a: d.a(), b: d.b(), x: d.x(), carry: d.p() & 1, z: (d.p() >> 2) & 1, cycles: d.cycles() - c0 };
    d.setPC(this.addr('t_idle')); d.setSP(sp);       // back to waiting for a key
    return out;
  }
  // waiting in getk, stopped exactly at its top
  park() {
    const a = this.addr('t_idle');
    if (this.m.dbg.pc() === a && !this.m.dbg.sleeping()) return;
    if (this.m.runTo([a], HZ * 20) !== a) throw new Error('no key wait\n' + this.text());
  }
  // ---- numbers
  item(addr) { const h = this.m.peekw(addr); const v = fromBytes(this.m.read(addr + 2, h & 0x7fff)); return h & 0x8000 ? -v : v; }
  // the stack of numbers, the top first
  stack() { const r = []; let a = this.peekw('kv_wp'); const e = this.peekw('kv_vb'); while (a < e) { r.push(this.item(a)); a += 2 + (this.m.peekw(a) & 0x7fff); } return r; }
  push(v) { const b = item(v); const a = this.peekw('kv_wp') - b.length; this.m.write(a, b); this.pokew('kv_wp', a); }
  clear() { this.pokew('kv_wp', this.peekw('kv_vb')); this.pokew('kv_lim', this.peekw('kv_lo')); this.pokew('kv_osp', this.peekw('kv_lo')); }
}

// a small deterministic random source
function rng(seed) { let s = BigInt(seed) * 0x9E3779B97F4A7C15n & 0xffffffffffffffffn || 1n;
  const next = () => { s ^= s << 13n & 0xffffffffffffffffn; s ^= s >> 7n; s ^= s << 17n & 0xffffffffffffffffn; return s; };
  return { next, bits: (n) => { let v = 0n; for (let i = 0; i < n; i += 64) v = v << 64n | next(); return v & ((1n << BigInt(n)) - 1n); }, int: (n) => Number(next() % BigInt(n)) }; }
module.exports = { BN, MODELS, ROMS, ROOT, HZ, toBytes, fromBytes, item, rng };

// ---- typing lines straight into the line buffer
// key codes put into the OS's one-key buffer, taken at the next key wait
const CODE = { EXE: 13, ON: 1, MODE: 2, UP: 3, DOWN: 4, LEFT: 5, RIGHT: 6, DELR: 7, DEL: 8 };
BN.prototype.wait = function (sec = 120) {
  const a = this.addr('t_idle');
  if (this.m.runTo([a], HZ * sec) !== a) throw new Error('no key wait\n' + this.text());
  return this;
};
BN.prototype.inject = function (k, sec = 120) {
  this.wait(sec);
  this.m.poke(0x76, CODE[k] || k.charCodeAt(0));
  this.m.run(3000);
  return this;
};
// at the entry line: the line's text put in and EXE; returns {err, pos} or {val, screen}
BN.prototype.line = function (text, sec = 600) {
  for (let i = 0; i < 6 && !this.atLine(); i++) { this.inject('ON'); this.wait(); }
  this.wait();
  const a = this.peekw('kv_line');
  this.m.write(a, [text.length, ...[...text].map((c) => c.charCodeAt(0))]);
  this.poke('kv_cur', text.length);
  const c0 = this.m.cycles();
  this.inject('EXE');
  this.wait(sec);
  const cycles = this.m.cycles() - c0;
  if (this.atLine()) { const e = this.peek('kv_err'); return { err: e, pos: this.peek('kv_epos'), cycles, screen: this.lines() }; }
  return { err: 0, val: this.vars()['@'], cycles, screen: this.lines() };
};
BN.prototype.atLine = function () { return this.meta.ovl[this.peek('kv_res') - 1] === 'ov_edit'; };
BN.prototype.vars = function () {
  const r = {}; let a = this.peekw('kv_vb'); const e = this.peekw('kv_hi');
  while (a < e) { r[String.fromCharCode(this.m.peek(a))] = this.item(a + 1); a += 3 + (this.m.peekw(a + 1) & 0x7fff); }
  return r;
};
// after calling overlays directly: the entry line's overlay back in the slot, so that it can go on waiting
BN.prototype.back = function () { this.clear(); this.call('ov_load', { a: this.meta.ovl.indexOf('ov_edit') + 1 }); return this; };
