; =====================================================================
; OV_MINV: MODINV(a, m), CRT(a, m, b, n)
; =====================================================================
        include "macros.inc"
        entry f_inv
        lastent f_crt

mi_s    = kv_fs                 ; the arguments' end
f_inv:  ldx  kv_wp              ; m positive
        ldd  0,x
        beq  f_argx
        bmi  f_argx
        bsr  i2                 ; a modulo m
        bsr  inext
        stx  mi_s
        bsr  hdup
        bsr  hover3
        bsr  hswap
        ovsub OV_DIV,1          ; a m r
        bsr  i2                 ; m odd?
        bsr  inext
        dex
        ldab 0,x
        lsrb
        bcc  f_even
        bsr  oddinv
        bra  f_close
f_argx: bra  errarg
; an even m (r must be odd): with k = -1/m modulo r, the inverse is (1 + m k) / r
f_even: ldx  kv_wp
        ldd  0,x
        beq  noinv
        bsr  inext
        dex
        ldab 0,x
        lsrb
        bcc  noinv
        bsr  hover              ; a m r, m modulo r
        bsr  hover
        ovsub OV_DIV,1          ; a m r s
        bsr  oddinv             ; a m r j (j = 1/m modulo r)
        bsr  hover
        bsr  hswap
        bsr  hsub               ; r - j
        bsr  hover3
        bsr  hmul
        bsr  hpush1
        bsr  hadd               ; a m r (1 + m k)
        bsr  hswap
        ovsub OV_DIV,0          ; a m (..)/r
        bsr  hover              ; (m = 1 or r = 1: within m)
        ovsub OV_DIV,1
f_close: ldx mi_s
        bra  hslx
noinv:  ldab #E_INV
        bra  err
; oddinv: the top number (less than the second, which is odd and stays) replaced by its inverse modulo
; the second
oddinv: ldx  kv_wp
        ldd  0,x
        bne  .nz
        bsr  i2                 ; 0: only modulo 1
        ldd  0,x
        subd #1
        bne  noinv
        ldaa 2,x
        deca
        bne  noinv
        rts
.nz:    ldx  kv_wp
        pshx
        bsr  i2
        pshx
        mset 2,NO,NO            ; (four slots, two of them where products would be made: there are none)
        ldx  mp
        stx  ms
        pulx
        pulx
        pshx
        clrb
        bsr  toslot
        clr  iv_a
        bsr  inv
        bcs  noinv
        clrb
        bsr  fromslot
        pulx
        bsr  inext
        bra  hslx

; CRT(a, m, b, n): x = a + m ((b - a) / m modulo n), modulo m n
f_crt:  ldx  kv_wp              ; n, m positive
        ldd  0,x
        beq  f_argx
        bmi  f_argx
        bsr  i3
        ldd  0,x
        beq  f_argx
        bmi  f_argx
        bsr  inext
        bsr  inext
        stx  mi_s+2             ; (mi_s is f_inv's)
        bsr  hover3             ; 1/m modulo n
        bsr  hover
        bsr  f_inv              ; a m b n j
        bsr  hover3             ; a m b n j b
        bsr  i3                 ; a: the sixth
        bsr  inext
        bsr  inext
        bsr  inext
        bsr  hcopy
        bsr  hsub               ; a m b n j (b-a)
        bsr  hmul
        bsr  hover
        ovsub OV_DIV,1          ; a m b n t
        bsr  i3
        bsr  inext
        bsr  hcopy              ; a m b n t m
        bsr  hmul
        bsr  i3                 ; a
        bsr  inext
        bsr  inext
        bsr  hcopy
        bsr  hadd               ; a m b n (a + m t)
        bsr  i3                 ; modulo m n
        bsr  inext
        bsr  hcopy
        bsr  hover3
        bsr  hmul
        ovsub OV_DIV,1
        ldx  mi_s+2
        bra  hslx
        include "mslot.inc"
        include "inv.inc"
