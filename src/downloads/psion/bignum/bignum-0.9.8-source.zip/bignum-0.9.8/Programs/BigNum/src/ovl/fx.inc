; what the factoring chain and its methods share (kv_fx)
fx_n    = kv_fx                 ; the number's item (odd, composite; it does not move)
fx_dg   = kv_fx+2               ; its digits
fx_lim  = kv_fx+4               ; the most rho steps, or the bound B1
fx_cur  = kv_fx+6               ; ECM: the curve (from 1)
fx_crv  = kv_fx+8               ; of so many
fx_lvl  = kv_fx+10              ; ECM's level (1 to 4; 0: bounds of your own)
fx_found = kv_fx+11             ; 1: a factor is on top of the stack of numbers
fx_wp   = kv_fx+12              ; the stack of numbers before the method
fx_job  = kv_fx+14              ; the last line: 0 keys, 1 the job's time (fx_js), 2 no end to it
fx_js   = kv_fx+15              ; seconds (4)
fx_rec  = kv_fx+19              ; the record being worked on
fx_m    = kv_fx+21              ; the method (for the results)
fx_sg   = kv_fx+22              ; ECM: sigma (2)
