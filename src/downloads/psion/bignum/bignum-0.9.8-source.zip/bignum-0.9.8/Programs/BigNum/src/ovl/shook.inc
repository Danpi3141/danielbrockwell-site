; the display of a quick step of FACTOR: the text sh_t (lbc)
shook:  ldaa kv_run             ; (paused: it would not fit: just Working)
        deca
        bne  .x
        tst  kv_full
        beq  .x
        bsr  clsf
        tst  kv_four
        beq  .two
        bsr  ln0
        bsr  pri
        fcl  "FACTOR  "
        ldd  fa_dg
        bsr  pdig
        bsr  out
        ldaa #1
        bsr  .t
        ldaa #3
        bra  onstop
.two:   clra
        bsr  .t
        ldaa #1
        bra  onstop
.t:     bsr  ln
        bsr  .t2
        ldab kv_w               ; ("Trial division..": one more dot on four lines)
        cmpb #20
        bne  .o
        ldx  kv_p
        dex
        dex
        dex
        ldaa 0,x
        cmpa #'.'
        beq  .o
        ldaa #'.'
        bsr  putc
.o:     bra  out
.t2:    ldx  #sh_t
        bra  prs
.x:     rts
