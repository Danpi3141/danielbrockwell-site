; =====================================================================
; OV_DIGS: how many decimal digits the top number (kept) has: kv_digs; and kv_bits its bits
; =====================================================================
        include "macros.inc"
        lastent digs

digs:   bsr  ilenw
        subd #0
        bne  .n
        std  kv_bits            ; 0: one digit, no bits
        incb
        std  kv_digs
        rts
.n:     subd #1
        asld
        asld
        asld
        std  zt
        ldab 2,x
        clra
.b:     inca
        lsrb
        bne  .b
        tab
        clra
        addd zt
        std  kv_bits
        bsr  lg                 ; the most digits it can have, and the fewest
        pshb
        psha
        ldd  kv_bits
        subd #1
        bsr  lg
        pulx
        stx  kv_digs
        subd kv_digs
        beq  .x
        ldaa #1                 ; they differ: against 10 to the kv_digs-1, in 8 bytes first
        bsr  p10
        ldx  kv_na              ; (the bytes left off)
        beq  .exact
        bsr  ilenw
        addd kv_na
        std  kv_se
        bsr  i2
        bsr  ilen
        subd kv_se
        blo  .less
        bhi  .drop
        ldx  kv_wp              ; as long: the first 6 bytes
        ldd  2,x
        pshb
        psha
        ldd  4,x
        pshb
        psha
        ldd  6,x
        pshb
        psha
        bsr  i2
        pula
        pulb
        std  kv_se
        pula
        pulb
        std  kv_ia
        pula
        pulb
        subd 2,x
        bne  .dec
        ldd  kv_ia
        subd 4,x
        bne  .dec
        ldd  kv_se
        subd 6,x
        beq  .again             ; too close: exactly
.dec:   bhi  .less
        bra  .drop
.again: bsr  hdrop
        clra
        bsr  p10
.exact: bsr  i2
        ldd  kv_wp
        bsr  hcmp
        bcc  .drop
.less:  ldd  kv_digs            ; less: one digit fewer
        subd #1
        std  kv_digs
.drop:  bra  hdrop
.x:     rts
; lg: D -> D x log10(2), rounded down, + 1
lg:     std  kv_al
        ldx  #$4D42
        os   UT$UMUL
        std  kv_se              ; (the high word)
        ldd  kv_al
        ldx  #$4D10
        os   UT$UMUL
        std  kv_al
        xgdx
        addd kv_se
        ldd  kv_al
        adcb #0
        adca #0
        addd #1
        rts
; p10: 10 to the kv_digs-1 pushed; A = 1: only its first bytes (kv_na = the bytes left off)
p10:    staa kv_cy
        ldx  #0
        stx  kv_fs+8
        bsr  hpush1
        ldd  kv_digs
        subd #1
        std  kv_fs+10
.l:     ldd  kv_fs+10
        subd #4
        bcs  .last
        std  kv_fs+10
        ldd  #10000
        bsr  .mul
        bra  .l
.last:  ldab kv_fs+11           ; 0 to 3 more
        beq  .x
        dec  kv_fs+11
        ldd  #10
        bsr  .mul
        bra  .last
.x:     ldx  kv_fs+8
        stx  kv_na
        rts
.mul:   ldx  #0
        stx  kv_na
        bsr  hmuladd
        tst  kv_cy
        beq  .xx
        bsr  ilenw
        subd #13
        bcs  .xx
        addd #11                ; two bytes off its end
        std  0,x
        ldx  kv_fs+8
        inx
        inx
        stx  kv_fs+8
        ldx  kv_wp              ; (the number moved up over them)
        bsr  inext
        stx  zx
        inx
        inx
        stx  zp
        bsr  ilenw
        addd #2
        bsr  cpd
        ldx  zp
        stx  kv_wp
.xx:    rts
