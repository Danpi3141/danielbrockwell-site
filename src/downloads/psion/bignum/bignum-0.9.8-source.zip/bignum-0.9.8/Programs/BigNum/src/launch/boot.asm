; =====================================================================
; BigNum's bootstrap. It lies in the launcher's own translated text (a string after its RETURN:
; tools/build.py puts it there) and is run where it lies: USR(PEEKW($A9)+k,0). It finds the kernel
; block BNK on C:, B: or A:, takes memory from under OPL's stack (RTA_SP lowered to just above the
; allocator's memory, with RESERVE left for files on A: to grow), reads the kernel into the top of
; it and runs the fixer. Position independent: relative branches only.
; BNK's data: the build's number, the resident sizes (code, variables, slot: small and large), the length of what follows, the kernel's
; code and start-up code, the fixer, the fix-ups.
; =====================================================================
        include "../defs.inc"

boot:   bsr  .find              ; (pushes the name's address)
.name:  fcb  5
        fcc  "B:BNK"
.find:  ldaa #'C'               ; C:, then B:, then A:
.dev:   pulx                    ; X = the name
        pshx
        staa 1,x                ; its device letter
        psha
        ldab #$83               ; a procedure (a block file of type $83)
        os   FL$BOPN            ; found: the pack address is at its data
        bcs  .nx
        ldd  #16                ; past the object length and the RETURN stub
        os   PK$SKIP
        os   PK$RWRD            ; this build's number (or it is another version's)
        subd #BUILD
        beq  .found
.nx:    pula
        deca
        cmpa #'A'-1
        bne  .dev
        pulx
        ldab #234               ; FILE NOT FOUND
        os   ER$MESS
.x:     ldx  #0
        rts
.found: pula
        ldx  RTA_SP             ; (for the start-up code: the name's address, and this)
        pshx
        suba #'A'               ; the device: A: 0, B: 1, C: 2
        psha
        os   PK$RWRD            ; the resident size: with little memory, the small one
        pshb
        psha
        os   PK$RWRD
        xgdx
        ldd  RTA_SP
        subd ALA_FREE
        subd #BIGRAM
        pula
        pulb
        bcs  .sm
        xgdx
.sm:    pshb
        psha
        ldd  RTA_SP
        tsx
        subd 0,x                ; the kernel's place: the top of the block
        pulx
        pshb
        psha                    ; (stack: base, device)
        ldx  ALA_FREE
        ldd  #256+RESERVE
        stx  T0
        addd T0
        std  RTA_SP             ; the block: [RTA_SP, the old one)
        os   PK$RWRD            ; the kernel's length
        pulx
        pshx
        pshb
        psha
        os   PK$READ
        pula
        pulb
        pulx                    ; X = the base
        stx  T0
        addd T0                 ; D = the end of what was read
        pshb
        psha
        ldd  #KLEN
        addd T0
        pulx                    ; X = the end
        pshb                    ; into the fixer, just after the kernel: A... the base in T0, X = the end
        psha
        rts
