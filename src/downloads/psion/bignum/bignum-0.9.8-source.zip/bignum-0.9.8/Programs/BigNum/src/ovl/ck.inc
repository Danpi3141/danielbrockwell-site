; what is kept of a run (OV_KEEP writes it, OV_CKL reads it). The file BIGKEEP is text: records of a letter and hex
; digits (but for the line), each a piece of its section:
;   the line; V a variable it uses (its letter's code, then its item); F FACTOR's state, when it is at work (kv_fz,
;   kv_fx; then the list of factors, L); S the method's: its number (kv_ckm), the checksum of what it works on,
;   the seconds so far, its variables; R its big numbers; E the checksum of all that. Then, for the sieve: Q a
;   relation, P a partial one (with its prime).
        include "ckn.inc"
; ck_tab: X = kv_ckm's entry: the pointer to the item it works on, the first slot and how many (0: none), its
; variables (an address and a length each, a 0 at the end)
ck_tab: ldab kv_ckm
        ldx  #.t
.f:     decb
        beq  .x
        inx
        inx
        inx
        inx
.n:     ldaa 0,x
        oraa 1,x
        beq  .z
        inx
        inx
        inx
        bra  .n
.z:     inx
        inx
        bra  .f
.x:     rts
.t:     fdb  kv_fs              ; base 2: the number; slot 0; the bit, the bits done
        fcb  0,1
        fdb  kv_fs+2
        fcb  2
        fdb  kv_done
        fcb  2
        fdb  0
        fdb  kv_fs              ; Lucas: slots 0, 1
        fcb  0,2
        fdb  kv_fs+2            ; (the bit, and the twos left)
        fcb  4
        fdb  kv_done
        fcb  2
        fdb  0
        fdb  ms_x               ; MODEXP: the modulus; slot 0; the bit, whether it has begun
        fcb  0,1
        fdb  kv_fs+2
        fcb  2
        fdb  kv_fs+7
        fcb  1
        fdb  kv_done
        fcb  2
        fdb  0
        fdb  0                  ; LLT: its number is not in a slot (kv_fs+8)
        fcb  0,0
        fdb  kv_fs
        fcb  2
        fdb  kv_fs+4
        fcb  2
        fdb  kv_done
        fcb  2
        fdb  0
        fdb  fx_n               ; rho: slots 0 to 2; r, k, the constant
        fcb  0,3
        fdb  kv_fs
        fcb  4
        fdb  kv_fs+5
        fcb  1
        fdb  kv_done
        fcb  2
        fdb  0
        fdb  fx_n               ; P-1, P+1: slot 2; the prime reached
        fcb  2,1
        fdb  ps_p
        fcb  3
        fdb  kv_done
        fcb  2
        fdb  0
        fdb  fx_n               ; their second stage: slots 0 to 7; the window's start
        fcb  0,8
        fdb  ps_lo
        fcb  3
        fdb  kv_done
        fcb  2
        fdb  0
        fdb  fx_n               ; ECM: slots 4 to 6; the prime reached, the curve
        fcb  4,3
        fdb  ps_p
        fcb  3
        fdb  fx_cur
        fcb  2
        fdb  fx_sg
        fcb  2
        fdb  kv_done
        fcb  2
        fdb  0
        fdb  fx_n               ; ECM's second stage: slots 0 to 15; the window's start
        fcb  0,16
        fdb  ps_lo
        fcb  3
        fdb  fx_cur
        fcb  2
        fdb  fx_sg
        fcb  2
        fdb  kv_done
        fcb  2
        fdb  0
        fdb  fx_n               ; the sieve: the relations are kept by themselves
        fcb  0,0
        fdb  q_k                ; the multiplier, the primes in an a, the primes of the base
        fcb  3
        fdb  0
; ck_sum: D = the checksum of what the method at X (its entry) works on (X kept)
ck_sum: pshx
        ldx  0,x
        beq  .no
        ldx  0,x
        bsr  sum
        std  ck_t2
        ldaa kv_ckm             ; MODEXP: its base and exponent too
        cmpa #CK_MEXP
        bne  .m
        ldx  kv_fs
        bsr  sum
        addd ck_t2
        std  ck_t2
        ldx  kv_fs+12
        bsr  sum
        addd ck_t2
        bra  .x
.m:     cmpa #CK_PM1            ; P-1 or P+1?
        beq  .p
        cmpa #CK_PS2
        bne  .d
.p:     ldab kv_fs+6
        clra
        addd ck_t2
        bra  .x
.d:     ldd  ck_t2
.x:     pulx
        rts
.no:    ldd  kv_fs              ; (LLT: p)
        bra  .x
ck_t2:  fdb  0
; sum: D = the checksum of the item at X
sum:    bsr  ilen
        addd #2
        std  zt
        clra
        clrb
.l:     addb 0,x
        adca #0
        asld
        adcb #0
        inx
        pshx
        ldx  zt
        dex
        stx  zt
        pulx
        bne  .l
        rts
; ck_reg: zx = the method's big numbers (its entry at X), D how many bytes
ck_reg: ldaa kv_ckm
        cmpa #CK_LLT
        beq  .llt
        ldab 3,x
        pshb
        ldab 2,x
        bsr  mslot
        std  zx
        pulb
        pshb
        ldaa mn+1
        mul
        std  zt
        pulb
        ldaa mn
        mul
        tba
        clrb
        addd zt
        rts
.llt:   ldx  kv_fs+8
        stx  zx
        ldd  mn
        rts
