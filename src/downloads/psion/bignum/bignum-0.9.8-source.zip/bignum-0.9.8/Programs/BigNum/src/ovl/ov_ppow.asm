; =====================================================================
; OV_PPOW: is the number at fa_rec's record (no factors below 2**13) a perfect power? kv_pk = the exponent (a
; prime), the root on top of the stack of numbers; or 0.
; For each prime k, primes q = 1 modulo k: N must be a k-th power modulo q; only then is the root taken.
; =====================================================================
        include "macros.inc"
        include "fa.inc"
        lastent ppow

pp_k    = kv_fs+12              ; the exponent
pp_q    = kv_fs+14              ; (2) a prime
pp_c    = kv_fs+16              ; how many have been tried
pp_w    = kv_fs+18              ; (2) the stack of numbers
pp_e    = kv_fs+20              ; (2) kv_bits / 13
ppow:   ldx  #shook
        bsr  hookx
        bsr  shook
        ldx  kv_wp
        stx  pp_w
        ldx  fa_rec
        ldab #FR_N
        abx
        bsr  hcopy
        ovsub OV_DIGS,0
        ldx  kv_bits
        ldd  #13
        os   UT$UDIV
        stx  pp_e
        ldab #2
.k:     stab pp_k
        clra
        subd pp_e
        bhi  .none
        ldd  #1                 ; its q's: 1 + 2 k, 1 + 4 k, ... that are primes; 6 of them
        std  pp_q
        clr  pp_c
.q:     ldab pp_k
        clra
        asld
        addd pp_q
        std  pp_q
        bsr  isprime
        bne  .q
        ldd  pp_q
        std  kv_na
        bsr  rem16
        subd #0
        beq  .yes               ; (q divides N: says nothing)
        bsr  power              ; N to the (q-1)/k
        subd #1
        bne  .next
.yes:   inc  pp_c
        ldaa pp_c
        cmpa #6
        bne  .q
        ldab pp_k               ; a power, very likely: the root
        clra
        std  kv_fs
        bsr  hdup
        ldab pp_k
        pshb
        ldx  pp_w
        pshx
        ldx  pp_e
        pshx
        ovsub OV_ROOT,2
        pulx
        stx  pp_e
        pulx
        stx  pp_w
        pulb
        stab pp_k
        bsr  hdup               ; to the power again: the same?
        ldab pp_k
        clra
        bsr  hpush
        ldab pp_k
        pshb
        ldx  pp_w
        pshx
        ldx  pp_e
        pshx
        ovsub OV_POW,0
        pulx
        stx  pp_e
        pulx
        stx  pp_w
        pulb
        stab pp_k
        bsr  i3                 ; N root power
        ldd  kv_wp
        bsr  hcmp
        beq  .found
        bsr  hdrop2
.next:  ldab pp_k               ; the next prime
.nk:    incb
        cmpb #4
        beq  .nk
        cmpb #6
        beq  .nk
        cmpb #9
        bls  .sm
        bitb #1
        beq  .nk
        cmpb #15
        beq  .nk
        cmpb #21
        beq  .nk
        bra  .k
.sm:    cmpb #8
        beq  .nk
        cmpb #9
        beq  .nk
        bra  .k
.found: bsr  hdrop
        ldaa pp_k
        bra  .out
.none:  clra
.out:   staa kv_pk
        tsta
        beq  .drop
        ldd  pp_w               ; the root up over the number
        std  kv_se
        bra  hslide
.drop:  ldx  pp_w
        stx  kv_wp
        rts
; isprime: Z if pp_q is a prime
isprime: ldd #3
        std  kv_al
.l:     ldd  pp_q               ; modulo kv_al
        std  zx
        clra
        clrb
        ldx  #16
.b:     asl  zx+1
        rol  zx
        rolb
        rola
        subd kv_al
        bcc  .i
        addd kv_al
        bra  .n
.i:     inc  zx+1
.n:     dex
        bne  .b
        subd #0
        beq  .z
        ldd  zx
        subd kv_al
        bcs  .y
        ldd  kv_al
        addd #2
        std  kv_al
        bra  .l
.z:     ldd  pp_q
        subd kv_al
        rts
.y:     clra
        rts
; power: D (below q) to the power (q-1)/k, modulo q
power:  std  kv_al
        ldx  pp_q
        dex
        ldab pp_k
        clra
        os   UT$UDIV
        stx  kv_se              ; the exponent
        ldd  #1
        std  kv_ia
        ldaa #16
        staa kv_cnt
.l:     ldd  kv_ia
        std  kv_ib
        bsr  mulm               ; squared
        asl  kv_se+1
        rol  kv_se
        bcc  .n
        ldd  kv_al
        std  kv_ib
        bsr  mulm
.n:     dec  kv_cnt
        bne  .l
        ldd  kv_ia
        rts
; mulm: kv_ia = kv_ia kv_ib modulo q (q below 32768)
mulm:   ldx  #16
        clra
        clrb
.l:     asld
        subd pp_q
        bcc  .a
        addd pp_q
.a:     asl  kv_ib+1
        rol  kv_ib
        bcc  .b
        addd kv_ia
        subd pp_q
        bcc  .b
        addd pp_q
.b:     dex
        bne  .l
        std  kv_ia
        rts
; rem16: D = the top number modulo kv_na
rem16:  bsr  ilenw
        std  zt
        inx
        inx
        stx  zx
        clra
        clrb
.l:     ldx  zx
        pshb
        ldab 0,x
        stab zm
        pulb
        inx
        stx  zx
        ldx  #8
.b:     asl  zm
        rolb
        rola
        bcs  .s
        subd kv_na
        bcc  .n
        addd kv_na
        bra  .n
.s:     subd kv_na
.n:     dex
        bne  .b
        ldx  zt
        dex
        stx  zt
        bne  .l
        rts
sh_t:   fcl  "Power check..."
        include "shook.inc"
        include "flist.inc"
