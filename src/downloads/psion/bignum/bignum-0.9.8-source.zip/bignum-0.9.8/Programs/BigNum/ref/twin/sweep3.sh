#!/bin/bash
# the caps: tier 1 (240 primes), tier 2 (128 to 176), tier 3 (48 to 96) at larger sizes
{
for d in 44 46 48 50 52 54; do for M in 2048 4096; do for lp in 6 15 40; do echo $d 240 $M 16 $lp 7 4 20 40 150 1e13; done; done; done
for d in 34 38 40 42 44 46 48 50; do for f in 128 152 176; do for M in 1024 2048; do for lp in 10 30; do echo $d $f $M 15 $lp 7 5 20 40 150 1e13; done; done; done; done
for d in 26 28 30 32 34 36 38 40 42; do for f in 48 64 80 96; do for lp in 10 30; do echo $d $f 1024 15 $lp 7 8 20 30 150 1e13; done; echo $d $f 1024 20 0 7 8 20 30 150 1e13;  done; done
for d in 14 16 18 20 22 24 26 28; do for f in 24 32 40 48; do for lp in 0 10 30; do for s in 12 15 18; do echo $d $f 512 $s $lp 7 12 20 20 150 1e12; done; done; done; done
} | xargs -P 12 -L 1 timeout 5400 ./Qs.exe
