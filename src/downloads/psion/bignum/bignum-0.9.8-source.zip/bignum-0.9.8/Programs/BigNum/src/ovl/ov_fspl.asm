; =====================================================================
; OV_FSPL: FACTOR's list changed. Entry 0: the number at fa_rec in two (its factor is on top of the stack, used
; up). 1: the number at fa_rec is a power (kv_pk; the root on top). 2: the prime at fa_rec is in the list twice.
; 3: the top number (used up) a new one; kv_pk = 1: a prime.
; =====================================================================
        include "macros.inc"
        include "fx.inc"
        include "fa.inc"
        entry split
        entry power
        entry merge
        lastent add

add:    bsr  fl_new
        ldaa kv_pk
        bra  fl_add
power:  ldx  fa_rec
        bsr  fl_get
        ldab kv_pk              ; the exponent times it
        ldaa FL_E
        mul
        pshb
        ldab kv_pk
        ldaa FL_E+1
        mul
        std  FL_E
        pulb
        addb FL_E
        stab FL_E
        ldaa #6                 ; (found as a power)
        staa FL_E+FR_M-1
        ldx  fa_rec
        bsr  fl_del
        clra
        bsr  fl_add
        rts
split:  ldx  fa_rec             ; the factor f on top: N/f as well
        ldab #FR_N
        abx
        bsr  hcopy
        bsr  hover
        ovsub OV_DIV,0
        ldx  fa_rec
        bsr  fl_get
        ldab fx_m               ; how it was found
        incb
        stab FL_E+FR_M-1
        ldaa fx_m
        cmpa #3
        beq  .sg
        clr  fx_sg
        clr  fx_sg+1
.sg:    ldd  fx_sg
        std  FL_E+FR_S-1
        ldx  fa_rec
        bsr  fl_del
        clra
        bsr  fl_add
        clra
        bsr  fl_add
        rts

; merge: the prime at fa_rec is in the list already: the exponents added up, this one taken out
merge:  ldx  kv_rl
.f:     cpx  kv_lim
        beq  .x
        cpx  fa_rec
        beq  .n
        ldaa 0,x
        deca
        cmpa #1
        bhi  .n
        pshx
        ldab #FR_N
        abx
        stx  kv_al
        ldx  fa_rec
        ldab #FR_N
        abx
        ldd  kv_al
        bsr  hcmp
        pulx
        beq  .same
.n:     bsr  fl_next
        bra  .f
.same:  ldd  FR_E,x
        pshx
        ldx  fa_rec
        addd FR_E,x
        pulx
        std  FR_E,x
        ldx  fa_rec
        bra  fl_del
.x:     rts
        include "flist.inc"
