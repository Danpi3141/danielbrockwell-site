; the display of a part counted in bits: the texts hk_t (the title), hk_p (the part, four lines) and hk_q
; (two lines), each with a length byte
hook:   ldaa kv_run
        deca
        bne  .q                 ; (paused: only what it is)
        tst  kv_four
        beq  .two
        tst  kv_full
        beq  .p
        bsr  clsf
        bsr  ln0
        ldx  #hk_t
        tst  kv_pv+18           ; (pv_run)
        beq  .t
        ldx  #.pv
.t:     bsr  prs
        ldd  kv_digs
        bsr  pdig
        bsr  out
        ldaa #3
        bsr  onstop
.p:     bsr  ln1
        ldx  #hk_p
        bsr  prs
        ldd  kv_done
        bsr  putw
        bsr  putsl
        ldd  kv_tot
        bsr  putwo
        bsr  ln2
        bsr  pr_pct
        bra  out
.two:   clr  kv_full
        bsr  ln0
        ldx  #hk_q
        bsr  prs
        bra  pr_two
.q:     ldx  #hk_q
        bsr  prs
        bra  pr_num
.pv:    fcl  "PROVE  "
