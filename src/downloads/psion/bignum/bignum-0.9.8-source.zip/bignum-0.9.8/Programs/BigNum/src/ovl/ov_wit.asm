; =====================================================================
; OV_WIT: the witnesses: for each prime q of the list at kv_rl (the factors of pv_m - 1 or + 1) one is looked
; for and put in its record. pv_t is cleared if it does not work out (the number is not a prime after all).
; N - 1: a with a**(N-1) = 1 and GCD(a**((N-1)/q) - 1, N) = 1 (modulo N).
; N + 1: with D not a square modulo N (its Jacobi symbol -1) and t = 2 (a a + D) / (a a - D): the Lucas
; sequence V (P = t, Q = 1) has V(N+1) = 2 and GCD(V((N+1)/q) - 2, N) = 1. (It is Morrison's theorem with
; P = 2 a, Q = a a - D, whose discriminant is 4 D for every a.)
; =====================================================================
        include "macros.inc"
        include "fa.inc"
        include "pv.inc"
        lastent wit

wit:    ldaa pv_t
        cmpa #PT_PLUS
        bne  .go
        bsr  disc               ; D: a small prime
        bcs  bad
.go:    ldx  kv_rl
.q:     cpx  kv_lim
        beq  .end
        stx  pv_q
        ldaa 0,x
        deca
        cmpa #1
        bhi  .n
        ldaa #1
        ldab pv_t
        cmpb #PT_PLUS
        bne  .a1
        clra
.a1:    staa pv_a
.a:     bsr  nexta
        beq  bad                ; (none of them: it cannot be a prime)
        bsr  try
        bcs  bad
        bne  .a
        ldx  pv_q
        ldab pv_a
        clra
        std  FR_W,x
.n:     ldx  pv_q
        bsr  fl_next
        bra  .q
.end:   ldaa pv_t               ; N - 1, a third: the square test
        cmpa #PT_THIRD
        bne  .x
        ovsub OV_SQT,0
        bcs  bad
.x:     rts
bad:    clr  pv_t
        ldx  pv_m
        stx  kv_wp
        rts
; nexta: the next witness to try: 2, 3, 5, 7, 11, ... (N + 1: 1, 2, 3, ...); Z: none left
nexta:  ldaa pv_t
        cmpa #PT_PLUS
        bne  .p
        inc  pv_a
        ldaa pv_a
        cmpa #200
        rts
.p:     inc  pv_a
        ldaa pv_a
        cmpa #251
        beq  .x
        ldab #3                 ; is it a prime?
        cmpa #4
        blo  .ok
        lsra
        bcc  .p
.d:     ldaa pv_a
        cba
        beq  .ok
.s:     sba
        beq  .p
        bcc  .s
        addb #2
        cmpb #17
        bne  .d
.ok:    ldaa #1
.x:     rts
; try: Z: pv_a is a witness for the prime at pv_q; carry set: the number is not prime
try:    ldaa pv_t
        cmpa #PT_PLUS
        beq  .plus
        ldab pv_a               ; r = a to the (N-1)/q
        clra
        bsr  hpush
        bsr  expo
        bsr  pushn
        ovsub OV_MEXP,0
        ldd  #1
        bsr  gcd1
        bne  .not               ; (r is 1, or the GCD is something: N is not prime)
        bsr  pushq              ; r to the q must be 1
        bsr  pushn
        ovsub OV_MEXP,0
        ldd  #1
        bra  is
.not:   bsr  hdrop
.not1:  ldaa #1
        clc
        rts
.plus:  ovsub OV_WITT,0         ; t
        bcs  .not1
        bsr  expo               ; V((N+1)/q)
        bsr  pushn
        ovsub OV_LV,0
        ldd  #2
        bsr  gcd1
        bne  .not
        bsr  pushq              ; V(N+1) from it
        bsr  pushn
        ovsub OV_LV,0
        ldd  #2
; is: Z, carry clear if the top number (dropped) is D; else carry set
is:     bsr  hpush
        bsr  i2
        ldd  kv_wp
        bsr  hcmp
        tpa
        psha
        bsr  hdrop2
        pula
        tap
        beq  .y
        sec
        rts
.y:     clra
        rts
; gcd1: Z if GCD(top - D, N) = 1 (the top number is kept)
gcd1:   pshb
        psha
        bsr  hdup
        pula
        pulb
        bsr  hpush
        bsr  hsub
        bsr  pushn
        ovsub OV_FN,0
        ldx  kv_wp
        ldd  0,x
        subd #1
        bne  .n
        ldaa 2,x
        deca
.n:     tpa
        psha
        bsr  hdrop
        pula
        tap
        rts
; expo: (N - 1) / q or (N + 1) / q pushed
expo:   bsr  pushn
        bsr  hpush1
        ldaa pv_t
        cmpa #PT_PLUS
        beq  .p
        bsr  hsub
        bra  .d
.p:     bsr  hadd
.d:     bsr  pushq
        ovsub OV_DIV,0
        rts
pushq:  ldx  pv_q
        ldab #FR_N
        abx
        bra  hcopy
pushn:  ldx  pv_m
        bra  hcopy
; disc: pv_d = the first prime whose Jacobi symbol over N is -1
disc:   ldaa #1
        staa pv_a
        ldaa pv_t               ; (nexta gives primes for N - 1)
        psha
        clr  pv_t
.l:     bsr  nexta
        beq  .no
        ldab pv_a
        stab pv_d
        clra
        bsr  hpush
        bsr  pushn
        ovsub OV_FN,2
        ldx  kv_wp
        ldaa 0,x
        psha
        bsr  hdrop
        pula
        tsta
        bpl  .l
        pula
        staa pv_t
        clc
        rts
.no:    pula
        staa pv_t
        sec
        rts
        include "flnext.inc"
