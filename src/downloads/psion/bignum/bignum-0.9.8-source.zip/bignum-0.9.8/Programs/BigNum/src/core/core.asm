; =====================================================================
; The arithmetic core: products, squares and Montgomery reduction of byte strings (highest byte
; first) anywhere in memory.
; =====================================================================

; mulp: P = A x B. ma, mal: A's first byte and length; mb, mbl: B's; mp: P's first byte (mal+mbl
; bytes; the byte before it is read and written but not changed)
mulp:   ldx  mp
        ldd  mal
        addd mbl
        bsr  clrx               ; (X ends past the last)
        stx  mpe
        ldd  mb
        addd mbl
        std  mye
        ldd  mbl
.c:     std  mrem               ; the bytes of B left
        beq  .x
        bsr  poll
        ldd  mrem
        bsr  chunkw             ; zw = the chunk's width
        bsr  chunky             ; its bytes at YZ
        bsr  chunkp             ; zp
        ldd  ma
        std  ze
        addd mal
        std  zx
        ldab zw
        bsr  mulr
        bsr  chunkd             ; D = the bytes of B left
        bra  .c
.x:     rts
; chunkw: zw = the smaller of D and the rows' width
chunkw: tsta
        bne  .w
        cmpb kv_wm
        bls  .x
.w:     ldab kv_wm
.x:     stab zw
        rts
; chunky: back over the chunk: mye its first byte, the chunk at YZ
chunky: ldd  mye
        subb zw
        sbca #0
        std  mye
        xgdx
        bra  ycl
; chunkp: zp for a chunk whose product's lowest byte ends at mpe
chunkp: ldd  mpe
chunkq: subb zw
        sbca #0
        subd #1
        std  zp
        rts
; chunkd: on past the chunk: mpe, and D = mrem less its width
chunkd: ldd  mpe
        subb zw
        sbca #0
        std  mpe
        ldd  mrem
        subb zw
        sbca #0
        rts
; clrx: D bytes at X cleared; X past them; clrxn: mn bytes
clrxn:  ldd  mn
clrx:   lsrd
        bcc  .e
        clr  0,x
        inx
.e:     std  zt
        beq  .x
        tsta
        beq  .s
        stx  zx                 ; (a long one: its pages first)
.p:     ldx  zx
        clra
        clrb
        staa zm
.pl:    std  0,x
        inx
        inx
        dec  zm
        bne  .pl
        stx  zx
        dec  zt
        bne  .p
        tst  zt+1
        beq  .x
.s:     clra
        clrb
.l:     std  0,x
        inx
        inx
        dec  zt+1
        bne  .l
.x:     rts

; sqrp: P = A squared (ma, mal; mp: 2 mal bytes)
sqrp:   ldx  mp
        ldd  mal
        asld
        bsr  clrx
        stx  mpe
        stx  mq                 ; (P's end, kept)
        ldd  ma
        addd mal
        std  mye
        ldd  mal
.c:     std  mrem
        beq  .dd
        bsr  poll
        ldd  mrem
        bsr  chunkw
        ldx  mye                ; the rows of the bytes after the chunk: all of it
        stx  ze
        ldd  ma
        addd mal
        std  zx
        bsr  chunky
        bsr  chunkp
        ldab zw
        bsr  mulr
        ldab zw                 ; the chunk with itself: one step fewer each row
.t:     decb
        beq  .d
        stab zw+1
        bsr  entryw
        std  mr_j+1
        ldx  zx
        dex
        stx  ze
        bsr  mulrx
        ldab zw+1
        bra  .t
.d:     bsr  chunkd
        bra  .c
; the cross products doubled
.dd:    ldd  mal
        tstb
        beq  .e
        inca
.e:     std  zt                 ; (the low byte counts first)
        ldx  mq
        clc
.dbl:   dex
        dex
        ldd  0,x
        rolb
        rola
        std  0,x
        dec  zt+1               ; (the carry is kept)
        bne  .dbl
        dec  zt
        bne  .dbl
; and the squares added
        ldx  mq
        stx  zp
        ldd  ma
        addd mal
        std  zx
.sq:    ldx  zx
        cpx  ma
        beq  .x
        dex
        stx  zx
        ldaa 0,x
        tab
        mul
        ldx  zp
        dex
        dex
        dex
        addd 1,x
        std  1,x
        inx
        stx  zp
        bcc  .sq
.r:     dex
        inc  0,x
        beq  .r
        bra  .sq
.x:     rts

; redc: P (2 mn bytes at mp, and a spare byte before it) reduced by Montgomery's method: the result is
; the mn bytes at mp and the spare byte (0 or 1), not yet less than N
redc:   ldx  mp
        dex
        clr  0,x
        ldd  mn
        std  mrem               ; the q's left to find
        asld
        addd mp
        std  mpe                ; P's end less the q's found
.b:     bsr  poll
        ldd  mrem
        bsr  chunkw
        ldab zw
        stab mwq                ; the q's of this block
        ldd  mne
        std  mye
        ldd  mn                 ; N's lowest chunk
        bsr  chunkw
        bsr  chunky
        ldaa mk
        staa zk
        bsr  chunkp
        subb mwq
        sbca #0
        std  ze
        ldx  mpe
        ldaa 0,x                ; the q of the last block (or the byte after P)
        staa zm
        ldab zw
        bsr  redr
; the q's times the rest of N
        ldd  mpe
        std  mpc
        ldd  mn
.r:     subb zw
        sbca #0
        std  mr2
        beq  .n
        ldd  mpc                ; on past the chunk done
        subb zw
        sbca #0
        std  mpc
        ldd  mr2
        bsr  chunkw
        bsr  chunky
        ldd  mpc
        bsr  chunkq
        ldd  mpe
        std  zx
        subb mwq
        sbca #0
        std  ze
        ldab zw
        bsr  mulr
        ldd  mr2
        bra  .r
.n:     ldd  mpe                ; the next block
        subb mwq
        sbca #0
        std  mpe
        ldd  mrem
        subb mwq
        sbca #0
        std  mrem
        bne  .b
        rts

; ---- strings of mn bytes -----------------------------------------------
; add3: R = A + B, sub3: R = A - B: zx, zp, ze = A's, B's and R's ends (one past the last byte): the
; carry (borrow) out. (One routine, its three instructions put in each time.)
add3:   ldd  #$E9A9             ; adcb, adca
        bra  as
sub3:   ldd  #$E2A2             ; sbcb, sbca
as:     staa as_o
        staa as_b
        stab as_a
        ldd  mn
        lsrd
        tstb
        beq  as_e
        inca
as_e:   std  zt                 ; the pairs (the low byte counts first)
        ldab mn+1
        lsrb                    ; an odd byte first
        bcc  as_p
        ldx  zx
        dex
        stx  zx
        ldab 0,x
        ldx  zp
        dex
        stx  zp
        clc
as_o:   adcb 0,x
        ldx  ze
        dex
        stx  ze
        stab 0,x
        bra  as_n
as_p:   clc
as_n:   ldx  zt                 ; (does not touch the carry)
        beq  as_x
as_l:   ldx  zx
        dex
        dex
        stx  zx
        ldd  0,x
        ldx  zp
        dex
        dex
        stx  zp
as_b:   adcb 1,x
as_a:   adca 0,x
        ldx  ze
        dex
        dex
        stx  ze
        std  0,x
        dec  zt+1
        bne  as_l
        dec  zt
        bne  as_l
as_x:   rts
; cmpn: the mn bytes at X and at D compared (carry set: X's are fewer; Z: equal)
cmpn:   std  zp
        stx  zx
        ldd  mn
        std  zt
.l:     ldx  zx
        ldaa 0,x
        inx
        stx  zx
        ldx  zp
        cmpa 0,x
        bne  .x
        inx
        stx  zp
        ldx  zt
        dex
        stx  zt
        bne  .l
.x:     rts
; ---- Montgomery arithmetic --------------------------------------------
; The numbers (mn bytes each) are in slots, one after another at ms; N at mnp (mne its end), the
; product's room at mp (2 mn bytes and a spare one before).
; mrun: the operations that follow the call (the macros mo and, the last one, mol): 2 bytes each: the code (bit 7 set
; in the last) and the result, then a and b, 4 bits each
M_MUL   = 1                     ; r = a b / R
M_SQR   = 2                     ; r = a a / R
M_ADD   = 3                     ; r = a + b
M_SUB   = 4                     ; r = a - b
M_CPY   = 5                     ; r = a
mrun:   pulx
.n:     ldd  0,x
        inx
        inx
        pshx
        psha
        pshb
        tab
        andb #15
        stab mi
        ldab #16
        mul
        anda #7
        pulb
        psha
        tba
        andb #15
        stab mi+2
        ldab #16
        mul
        staa mi+1
        pulb
        bsr  mop
        pula
        pulx
        tsta
        bpl  .n
        jmp  0,x
; mop: B = the operation, on the slots mi (result), mi+1, mi+2
mop:    pshb
        ldab mi
        bsr  mslot
        std  mrs
        ldab mi+2
        bsr  mslot
        std  mb
        ldab mi+1
        bsr  mslot
        std  ma
        ldd  mn
        std  mal
        std  mbl
        pulb
        decb
        beq  op_mul
        decb
        beq  op_sqr
        decb
        beq  op_add
        decb
        beq  op_sub
        ldx  ma                 ; copy
        ldd  mrs
cpn:    std  zp
        stx  zx
        ldd  mn
        bra  cpb
op_mul:   bsr  mulp
        bra  op_red
op_sqr:   bsr  sqrp
op_red:   bsr  redc
; the result (mp, spare byte before) less N if it must be, into mrs
mfin:   ldx  mp
        dex
        tst  0,x
        bne  op_s
        inx
        ldd  mnp
        bsr  cmpn
        bcc  op_s
        ldx  mp
        ldd  mrs
        bra  cpn
op_s:     ldd  mp
        bsr  ends
        bra  sub3
; R = A + B, less N if it is N or more
op_add:   ldd  mb
        addd mn
        std  zp
        ldd  mrs
        addd mn
        std  ze
        ldd  ma
        addd mn
        std  zx
        bsr  add3
        bcs  op_an
        ldx  mrs
        ldd  mnp
        bsr  cmpn
        bcs  op_x
op_an:    ldd  mrs
        bsr  ends
        bra  sub3
op_sub:   ldd  mb
        addd mn
        std  zp
        ldd  mrs
        addd mn
        std  ze
        ldd  ma
        addd mn
        std  zx
        bsr  sub3
        bcc  op_x
        ldd  mrs
        bsr  ends
        bra  add3
op_x:     rts
; ends: zx = D's end, zp = N's, ze = mrs's
ends:   addd mn
        std  zx
        ldx  mne
        stx  zp
        ldd  mrs
        addd mn
        std  ze
        rts
; mslot: B = a slot: D = its address
mslot:  pshb
        ldaa mn+1
        mul
        std  zt
        pulb
        ldaa mn
        mul
        tba
        clrb
        addd zt
        addd ms
        rts
; cpb: D bytes from zx to zp, rising
cpb:    std  zt
        lsr  zt                 ; (pairs)
        ror  zt+1
        bcc  .e
        ldx  zx                 ; an odd byte first
        ldaa 0,x
        inx
        stx  zx
        ldx  zp
        staa 0,x
        inx
        stx  zp
.e:     ldd  zt
        beq  .x
        tstb
        beq  .g
        inca
.g:     std  zt
.l:     ldx  zx
        ldd  0,x
        inx
        inx
        stx  zx
        ldx  zp
        std  0,x
        inx
        inx
        stx  zp
        dec  zt+1
        bne  .l
        dec  zt
        bne  .l
.x:     rts
