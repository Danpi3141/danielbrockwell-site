// Random lines with everything in them - functions inside functions, variables, odd spacing, the sizes where things change -
// against BigInt; then garbage lines, which must give an answer or an error and do no harm.
//   node tests/t_fuzz.js [model] [seed] [lines]
'use strict';
const { BN, rng } = require('./lib');
const model = process.argv[2] || 'lz64', seed = +process.argv[3] || 1, N = +process.argv[4] || 600;
const R = rng(seed), pick = (a) => a[R.int(a.length)];
const g = new BN(model, process.env.BB ? { build: process.env.BB } : {}).start();
const cap = BigInt(g.peekw('kv_cap') * 8), LIM = 1n << cap, lmax = g.peek('kv_lmax');
class E extends Error { constructor(c) { super('E' + c); this.c = c; } }
const abs = (x) => (x < 0n ? -x : x), mod = (a, m) => ((a % m) + m) % m;
const big = (v) => { if (abs(v) >= LIM) throw new E(2); return v; };
const gcd = (a, b) => { a = abs(a); b = abs(b); while (b) [a, b] = [b, a % b]; return a; };
const powm = (b, e, m) => { let r = 1n % m; b = mod(b, m); while (e) { if (e & 1n) r = r * b % m; b = b * b % m; e >>= 1n; } return r; };
const inv = (a, m) => { let [r0, r1, s0, s1] = [m, mod(a, m), 0n, 1n]; while (r1) { const q = r0 / r1; [r0, r1] = [r1, r0 - q * r1]; [s0, s1] = [s1, s0 - q * s1]; } return r0 === 1n ? mod(s0, m) : null; };
const jac = (a, n) => { a = mod(a, n); let t = 1n; while (a) { while (!(a & 1n)) { a >>= 1n; if ((n & 7n) === 3n || (n & 7n) === 5n) t = -t; } [a, n] = [n, a]; if ((a & 3n) === 3n && (n & 3n) === 3n) t = -t; a %= n; } return n === 1n ? t : 0n; };
const root = (a, k) => { if (a < 0n) { const v = -a; let r = root(v, k); if (r ** k < v) r++; return -r; } let lo = 0n, hi = 1n; while (hi ** k <= a) hi *= 2n; while (hi - lo > 1n) { const m = (lo + hi) / 2n; if (m ** k <= a) lo = m; else hi = m; } return lo; };
const isp = (n) => { if (n < 2n) return false; for (const p of [2n, 3n, 5n, 7n, 11n, 13n, 17n, 19n, 23n, 29n, 31n, 37n]) { if (n % p === 0n) return n === p; } let d = n - 1n, s = 0; while (!(d & 1n)) { d >>= 1n; s++; } next: for (const a of [2n, 3n, 5n, 7n, 11n, 13n, 17n, 19n, 23n, 29n, 31n, 37n]) { let x = powm(a, d, n); if (x === 1n || x === n - 1n) continue; for (let i = 1; i < s; i++) { x = x * x % n; if (x === n - 1n) continue next; } return false; } return true; };
const fac = (n) => { const f = []; for (let d = 2n; d * d <= n; d += d === 2n ? 1n : 2n) while (n % d === 0n) { f.push(d); n /= d; } if (n > 1n) f.push(n); return f; };
const div = (a, b) => { if (b === 0n) throw new E(3); let r = a % b; if (r < 0n) r += abs(b); return [(a - r) / b, r]; };
const pow = (a, b) => { if (b < 0n) throw new E(0); if (b === 0n) return 1n; if (a === 0n || a === 1n) return a; if (a === -1n) return b & 1n ? a : 1n; if (b > cap * 2n) throw new E(2); if (BigInt(abs(a).toString(2).length - 1) * b > cap) throw new E(2); return big(a ** b); };
// a number of one of the sizes where things change
const odd = [0n, 1n, 2n, 3n, 127n, 128n, 255n, 256n, 257n, 32767n, 32768n, 65535n, 65536n, 65537n, 99999999n, 100000000n, 2n ** 32n - 1n, 2n ** 32n, 2n ** 63n, 2n ** 64n - 1n, 2n ** 64n, 2n ** 64n + 1n, 10n ** 15n, 10n ** 16n - 1n, 10n ** 19n, 10n ** 20n - 1n];
const num = (mx = 200) => { const k = R.int(10); if (k < 3) return pick(odd); if (k === 3) { const b = BigInt(8 * (1 + R.int(Math.max(1, mx >> 3)))); return (1n << b) + BigInt(R.int(3) - 1); } return R.bits(1 + R.int(mx)); };
const vars = {};                                    // what the variables should hold
// expressions: [text, value, strength]; an error is thrown
let budget = 0;
const lit = (v) => [String(v), v, 9];
const B = () => ['f', [pick(['GCD', 'LCM', 'MOD', 'ABS', 'SIZE', 'SQRT', 'NROOT', 'MODEXP', 'MODINV', 'CRT', 'JACOBI', 'FACT', 'PRIMORIAL', 'FIB', 'LUC', 'BINOM', 'ISPRIME', 'NEXTPRIME', 'PREVPRIME', 'PHI', 'TAU', 'SIGMA', 'FACTOR', 'TRIAL', 'MODSQRT'])]];
const small = (n) => lit(BigInt(R.int(n)));
const F = {
  GCD: (d) => { const a = gen(d), b = gen(d); return [[a, b], () => gcd(a[1], b[1])]; },
  LCM: (d) => { const a = gen(d), b = gen(d); return [[a, b], () => (a[1] && b[1] ? big(abs(a[1] * b[1]) / gcd(a[1], b[1])) : 0n)]; },
  MOD: (d) => { const a = gen(d), b = gen(d); return [[a, b], () => div(a[1], b[1])[1]]; },
  ABS: (d) => { const a = gen(d); return [[a], () => abs(a[1])]; },
  SIZE: (d) => { const a = gen(d); return [[a], () => BigInt(abs(a[1]).toString().length)]; },
  SQRT: (d) => { const a = gen(d); return [[a], () => { if (a[1] < 0n) throw new E(5); return root(a[1], 2n); }]; },
  NROOT: (d) => { const a = gen(d), b = small(12); return [[a, b], () => { if (b[1] < 1n || (a[1] < 0n && !(b[1] & 1n))) throw new E(5); return root(a[1], b[1]); }]; },
  MODEXP: () => { const a = lit(num(100)), e = lit(num(40)), m = lit(num(100)); return [[a, e, m], () => { if (m[1] < 1n) throw new E(5); return powm(a[1], e[1], m[1]); }]; },
  MODINV: (d) => { const a = gen(d), m = gen(d); return [[a, m], () => { if (m[1] < 1n) throw new E(5); const v = inv(a[1], m[1]); if (v === null) throw new E(4); return v; }]; },
  CRT: () => { const a = lit(num(60)), m = lit(num(60)), b = lit(num(60)), n = lit(num(60)); return [[a, m, b, n], () => { if (m[1] < 1n || n[1] < 1n) throw new E(5); if (gcd(m[1], n[1]) !== 1n) throw new E(4); return mod(a[1] + m[1] * (mod(b[1] - a[1], n[1]) * (inv(m[1], n[1]) || 0n) % n[1]), m[1] * n[1]); }]; },
  JACOBI: (d) => { const a = gen(d), n = gen(d); return [[a, n], () => { if (n[1] < 1n || !(n[1] & 1n)) throw new E(5); return jac(a[1], n[1]); }]; },
  FACT: () => { const a = small(cap > 4000n ? 400 : 300); return [[a], () => { let p = 1n; for (let i = 2n; i <= a[1]; i++) p *= i; return big(p); }]; },
  PRIMORIAL: () => { const a = small(700); return [[a], () => { let p = 1n; for (let i = 2n; i <= a[1]; i++) if (isp(i)) p *= i; return big(p); }]; },
  FIB: () => { const a = small(1200); return [[a], () => { let x = 0n, y = 1n; for (let i = 0n; i < a[1]; i++) [x, y] = [y, x + y]; return x; }]; },
  LUC: () => { const a = small(1200); return [[a], () => { let x = 2n, y = 1n; for (let i = 0n; i < a[1]; i++) [x, y] = [y, x + y]; return x; }]; },
  BINOM: () => { const a = R.int(3) ? small(300) : lit(num(40)), b = small(a[1] > 5000n ? 8 : 60); return [[a, b], () => { if (b[1] > a[1]) return 0n; let p = 1n; const k = a[1] - b[1] < b[1] ? a[1] - b[1] : b[1]; for (let i = 0n; i < k; i++) p = p * (a[1] - i) / (i + 1n); return big(p); }]; },
  ISPRIME: () => { const a = lit(num(64)); return [[a], () => (isp(a[1]) ? 1n : 0n)]; },
  NEXTPRIME: () => { const a = lit(num(40)); return [[a], () => { let v = a[1] + 1n; if (v < 2n) v = 2n; while (!isp(v)) v++; return v; }]; },
  PREVPRIME: () => { const a = lit(num(40)); return [[a], () => { if (a[1] < 3n) throw new E(5); let v = a[1] - 1n; while (!isp(v)) v--; return v; }]; },
  PHI: () => { const a = lit(R.bits(1 + R.int(30))); return [[a], () => { if (a[1] < 1n) throw new E(5); const f = fac(a[1]); let r = a[1]; for (const p of new Set(f)) r = r / p * (p - 1n); return r; }]; },
  TAU: () => { const a = lit(R.bits(1 + R.int(30))); return [[a], () => { if (a[1] < 1n) throw new E(5); const f = fac(a[1]); let r = 1n; for (const p of new Set(f)) r *= BigInt(f.filter((x) => x === p).length + 1); return r; }]; },
  SIGMA: () => { const a = lit(R.bits(1 + R.int(30))); return [[a], () => { if (a[1] < 1n) throw new E(5); const f = fac(a[1]); let r = 1n; for (const p of new Set(f)) { const e = BigInt(f.filter((x) => x === p).length); r *= (p ** (e + 1n) - 1n) / (p - 1n); } return r; }]; },
  FACTOR: () => { const a = lit(R.bits(1 + R.int(32))); return [[a], () => { if (a[1] < 1n) throw new E(5); return a[1] === 1n ? 1n : fac(a[1])[0]; }]; },
};
const join = (args) => args.map((a) => a[0]).join(pick([',', ',', ',', ' ,', ', ']));
const gen = (d) => {
  const k = d <= 0 ? 0 : R.int(12);
  if (k < 2) { if (R.int(5) === 0) { const n = pick(Object.keys(vars).concat(['ANS'])); if (vars[n] !== undefined) return [n, vars[n], 9]; } return lit(num()); }
  if (k === 2) { const a = gen(d - 1); return [a[2] < 4 ? `-(${a[0]})` : `-${a[0]}`, -a[1], 3]; }
  if (k === 3) { const b = R.int(4) ? R.bits(10) : num(30), e = BigInt(R.int(R.int(3) ? 12 : 80)); return [`${b}**${e}`, pow(b, e), 4]; }
  if (k < 7) { const n = pick(Object.keys(F)); const [args, f] = F[n](d - 1); return [`${R.int(6) ? n : n.toLowerCase()}(${join(args)})`, f(), 9]; }
  const a = gen(d - 1), b = gen(d - 1), sh = (x, m) => (x[2] < m || R.int(12) === 0 ? `(${x[0]})` : x[0]), sp = pick(['', '', '', ' ']);
  if (k === 7) return [sh(a, 1) + sp + '+' + sp + sh(b, 2), big(a[1] + b[1]), 1];
  if (k === 8) return [sh(a, 1) + sp + '-' + sp + sh(b, 2), big(a[1] - b[1]), 1];
  if (k === 9) return [sh(a, 2) + sp + '*' + sp + sh(b, 3), big(a[1] * b[1]), 2];
  return k === 10 ? [sh(a, 2) + '/' + sh(b, 3), div(a[1], b[1])[0], 2] : [sh(a, 2) + '%' + sh(b, 3), div(a[1], b[1])[1], 2];
};
let fails = 0, vals = 0, errs = 0, mem = 0, junk = 0;
const fail = (s) => { console.log(`FAIL ${model} seed ${seed}: ${s}`); if (++fails > 10) process.exit(1); };
const sane = (what) => {
  const [lo, lim, wp, vb, hi] = ['kv_lo', 'kv_lim', 'kv_wp', 'kv_vb', 'kv_hi'].map((n) => g.peekw(n));
  if (!(lo <= lim && lim <= wp && wp <= vb && vb <= hi)) fail(`${what}: pointers ${[lo, lim, wp, vb, hi].map((x) => x.toString(16))}`);
  if (/TRAP/.test(g.text())) { fail(`${what}: ${g.text()}`); process.exit(1); }
  for (const n of Object.keys(vars)) { const v = g.vars()[n === 'ANS' ? '@' : n]; if (v !== vars[n]) { fail(`${what}: ${n} is ${v}, not ${vars[n]}`); vars[n] = v; if (v === undefined) delete vars[n]; } }
};
for (let i = 0; i < N; i++) {
  if (i % 60 === 59) { g.line('CLR'); for (const n of Object.keys(vars)) delete vars[n]; const a = g.vars()['@']; if (a !== undefined) vars.ANS = a; }
  let e = null, t, v;
  // a line whose text is known even if it is an error: generated again until there is one
  let x; try { x = gen(1 + R.int(4)); } catch (q) { if (!(q instanceof E)) throw q; x = null; }
  if (!x) { i--; continue; }
  t = x[0]; v = x[1]; let dst = null; if (R.int(4) === 0) { dst = pick('ABCXYZ'.split('')); t = `${R.int(5) ? dst : dst.toLowerCase()}=${t}`; }
  if (t.length > lmax) { i--; continue; }
  const r = g.line(t, 4000);
  if (r.err === 7) { mem++; continue; }
  if (r.err || r.val !== v) { if (!(r.err === 2 && v.toString(2).length * 2 > Number(cap) / 2)) fail(`${t}: got ${r.err ? 'error ' + r.err + ' at ' + r.pos : r.val} want ${v}`); } else { vals++; vars.ANS = v; if (dst) vars[dst] = v; }
  if (r.err) { const a = g.vars()['@']; if (a !== vars.ANS) fail(`${t}: ANS changed by an error`); }
  if (i % 5 === 0) sane(t);
}
// lines of one thing that must be an error
const errline = () => { for (;;) { const save = []; let text = null; try { const n = pick(Object.keys(F)); const [args, f] = F[n](0); text = `${n}(${args.map((a) => a[0]).join(',')})`; f(); } catch (q) { if (!(q instanceof E)) throw q; if (text) return [text, q.c]; } } };
for (let i = 0; i < N / 10; i++) { const [t, c] = errline(); if (t.length > lmax) continue; const r = g.line(t, 4000); errs++; if (r.err !== c && r.err !== 7) fail(`${t}: got ${r.err ? 'error ' + r.err : r.val}, want error ${c}`); }
// garbage
const bits = ['(', ')', ',', '+', '-', '*', '/', '%', '**', '=', '"', '$', '.', ';', ':', '<', '>', ' ', '1', '0', '999', 'A', 'ANS', 'GCD', 'GCD(', 'FACT(', 'x', 'SET ', 'CLR ', 'VARS', 'SIZE(', 'ABS', '12345678901234567890', 'AB', 'LOAD ', 'SAVE ', 'TDIV', '"A:X"', 'Z=', 'RHO(', 'TRIAL(', '!', '#', '&', '\x7f', '@', '[', '_', '~'];
for (let i = 0; i < N / 2; i++) {
  let t = ''; const n = 1 + R.int(R.int(4) ? 8 : 60); for (let j = 0; j < n; j++) t += pick(bits);
  if (R.int(10) === 0) t = pick(['(', '-', 'ABS(', '1+(', '2**', 'GCD(1,', '((((1+', '+']).repeat(1 + R.int(120));
  t = t.slice(0, lmax);
  let r; try { r = g.line(t, 900); } catch (q) { if (/Paused|left|Working|Kept|Replace|Clear|digits|stage|Curve|Step|Keep/i.test(g.text())) { for (let k = 0; k < 8 && !g.atLine(); k++) { g.m.poke(0x76, k % 2 ? 65 : 1); g.run(3); } continue; } fail(`${JSON.stringify(t)}: ${q.message}`); break; }
  junk++; for (const n2 of Object.keys(vars)) delete vars[n2];
  for (let k = 0; k < 6 && !g.atLine(); k++) { g.inject('ON'); g.wait(); }
  if (!g.atLine()) { fail(`${JSON.stringify(t)}: not back at the line: ${g.text()}`); break; }
  sane(JSON.stringify(t));
  if (i % 12 === 0) { const q = g.line('12345*6789'); if (q.val !== 83810205n) { fail(`after ${JSON.stringify(t)}: 12345*6789 = ${q.err} ${q.val}`); break; } }
}
console.log(fails ? `${fails} FAILED` : `t_fuzz ${model} seed ${seed} ok (${vals} values, ${errs} errors, ${junk} of garbage, ${mem} out of memory)`);
process.exit(fails ? 1 : 0);
