#!/bin/bash
# factor base, sieve size, large prime and slack from 24 to 49 digits (tier 1: up to 240 primes)
{
for d in 24 26 28 30; do for f in 64 96 128 160; do for M in 1024 2048; do for s in 18 20 22; do echo $d $f $M $s 0 7 16 20 40 150 1e10; done; done; done; done
for d in 30 32 34 36 38 40; do for f in 96 128 160 192 224 240; do for M in 2048 4096; do for s in 20 22 24; do echo $d $f $M $s 0 7 10 20 40 150 1e11; done; for lp in 4 10 25; do for s in 14 16 18; do echo $d $f $M $s $lp 7 10 20 40 150 1e11; done; done; done; done; done
} | xargs -P 15 -L 1 ./Qs.exe | sort -V
