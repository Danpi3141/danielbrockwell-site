# BigNum: a big-number calculator for the Psion Organiser II

An expression line, number theory, primality proofs and factoring, modelled on YAFU, for every Organiser II from the 8K CM to the LZ64. All machine code (OPL only launches it), from *Psion big-number calculator: design spec* (`docs/spec.docx`, `docs/spec.md`, 24 Nov 2026). Daniel+Claude.

## Status (26 Nov 2026): version 0.9.9

0.9.9: quicker, mostly by reading fewer overlays and reading them faster (see *Faster*): PROVE(2\*\*127-1) 18 s on an LZ64 (32 s), FACTOR(2\*\*168-1) 35 s (55; a CM 102 s, 111), the sieve 13 to 22% quicker from 20 to 30 digits, and long squares by Karatsuba's way on all but the smallest tier: LLT(4423) 42% quicker, a 4,096-bit primality test 13%. Trial division reads its primes from a table on the pack. New command TIER: the memory tier you are on (1 to 4, see *Limits*), shown as a result and kept in ANS. The faster overlay reading takes 25 bytes on every model: a CM has 2,203 bytes for numbers (2,228), still room for its largest test.

0.9.8: a power stands after its prime (`P1  3^2`; it was `P1^2 3`); S on the factors' screen saves them; rho's time left is right for small numbers and rho is only tried where it pays; and **the sieve no longer stalls on some numbers of about 14 to 17 digits**, which it could in 0.9.5 to 0.9.7 (see *Small numbers*).

0.9.7: LLT(p) tests p before it looks at the size, so a composite p gives 0 at once however large (to 65,535); a prime past the cap is still TOO BIG. On a CM LLT(8190) was TOO BIG.

0.9.6: less memory needed (see *Less memory*): 93 bytes on every model, and a large prime test needs one length of its number less, so it starts from 5,612 bytes free on a CM (5,961 before).

0.9.5: the sieve is much quicker on its largest numbers: six of 48 digits take 7 to 21 hours on an LZ64 (24 hours to over 8 days in 0.9.4), and 40 digits on an XP about half the time (see *The choice of a*). A sieve kept by an older version is started again by RESUME.

0.9.4: rho keeps to its limit (see *Time left*), and no display goes past 100%.

0.9.3: a pack of another version put in while it runs is noticed (PACK CHANGED), and a round of hard testing with odd lines, files and events (see *The hard-testing round*), which found six small faults; all are put right.

0.9.2: the time left and FACTOR's Job are right now (see *Time left* below), and the sieve fills the room there is with primes (113 on an XP for 38 digits; 107 in 0.9). It has been seen to run on a real LZ64 (the sieve of FACTOR(2\*\*137-1)); all the tests are still in the emulator.

0.9.1, since 0.9: the HELP screen is right to its end (the two lines with quotation marks in them were missing and what followed was garbled, with beeps), the pack is 7.3K smaller (54,691 bytes; 62,015 before) and the CM has 106 more bytes for numbers, with nothing taken away (see *Made smaller* below).

Everything in the spec is built, and four of its stretch goals. **Tested in the emulator** (Jape's sources under Node with the real ROMs), on all 29 ROMs.

## Run

In Jape (https://www.jaapsch.net/psion/jape/jape.htm): **Select OPK file** → `build/game/BIGNUM.opk` → **Create** → **Slot B**, then **Prog → Run → B:BIGNUM**.

On a real Organiser: every `python tools/build.py` also writes `psion/`, made from the pack it has just built (`tests/t_psion.js` checks the two are the same; until 0.9.9 it was only written with `--psion`, and the committed folder could be a version behind) (BIGNUM, BNK and BNL as .OB3, RPLOAD's list and RPBOOT) for a **64K Datapak** through a Comms Link. The pack must stay in while the program runs: most of it is read from there as it is wanted.

## Using it

Type a line, press EXE. `2**127-1`, `FACTOR(2**64+1)`, `P=NEXTPRIME(10**30)`, `MODEXP(3,P-1,P)`, `SET TDIV 50000`. Operators: `**` (from the right), unary `-`, `* / %` (the remainder is never negative), `+ -`; brackets; variables A to Z and ANS.

| Functions | |
|---|---|
| Arithmetic | GCD LCM MOD SQRT NROOT ABS SIZE |
| Modular | MODEXP MODINV MODSQRT CRT JACOBI |
| Primes | ISPRIME PROVE NEXTPRIME PREVPRIME LLT |
| Factoring | FACTOR TRIAL RHO PM1 PP1 ECM QS; PHI TAU SIGMA |
| Sequences | FACT PRIMORIAL FIB LUC BINOM |
| Commands | SET VARS CLR SAVE LOAD RESUME BENCH LOG HELP TIER |

| Where | Key | |
|---|---|---|
| Entry line | EXE, arrows, DEL, ON/CLEAR | run; move, recall; delete; clear, and on an empty line leave |
| | MODE | the menu: Insert, Vars, Set, Resume, Bench, Log, Quit |
| Results | UP DOWN | the next or previous page or factor |
| | EXE | a number too long for its line in the pager; else back |
| | P, C | prove the first probable prime; the certificate of a proved prime |
| | V and a letter | keep what is shown in a variable |
| | M | how the factor shown was found (with ECM's sigma) |
| Factors | S, then A, B or C | add the result (the line, each factor and how it was found, the time) to the log BIGLOG on that device; any other key: no. Not on tier 4. LOG shows it (with the setting LOG off it asks which device) |
| Running | ON/CLEAR | pause: C continue, S skip, K keep and stop, A abandon |
| | S | skip to the next method |

## Limits

The free memory at the start decides, not the model. The thresholds are what each tier's largest job was measured to need.

| Tier | Free at the Prog menu | Largest number | Sieve | Usually |
|---|---|---|---|---|
| 1 | 17,460 or more | 8,192 bits | up to 240 primes, 184 bits (55 digits) | LA, LZ, LZ64 (22,250 to 22,900 free: 240 primes at the cap) |
| 2 | 13,260 | 8,192 bits | 168 bits (50 digits) | XP (14,700 free) |
| 3 | 11,400 | 2,048 bits | 148 bits (44 digits) | a full XP or LZ |
| 4 | 5,640 | 2,048 bits | none | CM (6,530 free) |

Below that it says how much more it needs. The command TIER gives the tier you are on. Tier 4 has no SAVE, LOAD, RESUME, log or checkpoints, a 128-character line and one line of recall. P+1 is in, as you asked.

**The CM.** With 6,533 bytes free at the menu, BigNum has 2,203 for numbers (all five CM ROMs: 2,201 to 2,237). That is room for a 2,048-bit primality test with the number also kept in a variable and in ANS (1,801 needed). The full test of the 617-digit 2\*\*2047+1919 ran on the emulated CM (0.9.6): probably prime, 7 h 16 min with the least free memory, then 5,612 bytes, now 5,637 (the spec's estimate was 10.6 h). While a small calculation is on the screen nearly all of the 2,203 is free for variables.

## Where this differs from the spec

- **All machine code.** The shell, evaluator and drivers too, as agreed: overlays read from the pack into one slot (921 bytes on the CM, 1,392 elsewhere).
- **Numbers are held highest byte first**: the rows of the multiply run with the carry that way, in code generated in RAM at 26 to 29 cycles a byte pair (the spec reckoned with 50).
- **Pack: 64K** (56.5K used), agreed if needed. Two data files, because RPLOAD takes none over 32K.
- **The sieve is self-initialising with one large prime and a multiplier** (stretch goals 1, 4 and 7), with up to 240 primes (goal 2's 224, and more). See below for what that did to the times. A single relation is never stored twice, every relation is checked when it is combined, and if all the sets turn out trivial (one run in a thousand) the sieve starts again.
- **Sieve caps 184, 168 and 148 bits** (the spec's 160, 150, 120 were provisional): about four weeks or less, from runs on the emulator to 48 digits and the PC twin beyond (ref/twin/QsP.cs: 55 digits 11 to 15 days in tier 1, 50 digits 2 to 5 weeks in tier 2, 44 digits 2 to 5 days in tier 3; two digits more would be five to ten times as long), and below the point where ECM would be as quick. In tier 3 the number of different polynomials a small base gives also sets a limit.
- **ECM levels 500 × 5, 2,000 × 30, 11,000 × 70, 50,000 × 900**, from the measured chance of a curve with this second stage (below).
- **Line editor, recall**: on the CM the line before is left in the entry buffer (the spec's own saving): UP brings it back until something is typed.
- **The factor and proof screens show what is inside the brackets** (`2**64+1 =`), as the sketches do.
- **A composite that is given up** shows how far ECM got: `1 factor ECM L2 9`, or on two lines beside its label.
- **The log's answer to PROVE** has the whole certificate; on the screen its lines are `P31 by N-1 third` (the spec's `P31 by N-1 (one third)` is 22 characters).
- **PROVE tries the cheap routes first**: trial division of N-1 and N+1, then the chain on N-1 (half or a third), then on N+1. The chain stops as soon as enough is found, and does not go past ECM's second level. N+1's witnesses: with D a small prime whose Jacobi symbol is -1 and t = 2(a²+D)/(a²-D), V(N+1) = 2 and GCD(V((N+1)/q)-2, N) = 1 for the sequence P = t, Q = 1. That is Morrison's theorem with P = 2a, Q = a²-D, whose discriminant is 4D for every a.
- **PROVE(10\*\*30+57)** gives the spec's certificate's lines in part: which factors of N-1 come up first depends on rho, so it may prove it by a half instead of a third.
- **A run given up inside a longer expression** (`1+FACTOR(...)`) shows the factors so far and returns to the line; nothing is put in ANS's place but the smallest prime known.
- **Checkpoints** are one file, BIGKEEP, with the line, the variables the line uses, FACTOR's list and the method's state in hex, and a checksum. K may take a moment: it waits for a safe place (a bit, a batch, a prime, a polynomial group). With KEEP off, K asks for the device. A finished job deletes its file.
- **RESUME puts back the variables the kept line uses.** The line is then run again and the kept state is picked up when its method comes.
- **KEEP on A:** uses the memory numbers would have on all but the LZ64; if it does not fit, the Organiser's own error shows and the run goes on.
- **The display on the CM** is brought up to date every fourth second (each time costs two overlays).
- **Two-line FACTOR screens** show the job for two seconds as each step starts, as sketched. The first line of a job says days or weeks when hours would be silly.
- **A number over the sieve's cap inside PROVE** is not given endless ECM.

## Stretch goals

| Goal | |
|---|---|
| Many polynomials from one set-up | in |
| 224 primes in tier 1 | in: up to 240 |
| A tiny sieve on the CM | not in. The twin gives 24 digits in about 70 s and 28 in 5 min with 32 primes, but it needs about 2,500 bytes of working memory and overlays of 1,200; the CM has 2,203 and 921 |
| A multiplier for N | in |
| Karatsuba above 512 bits | not in: it would save about a quarter of a plain multiply at 8,192 bits and nothing in the reduction, so about an eighth of a primality test, for a few hundred bytes that the pack does not have |
| Combined N-1 and N+1 proofs | not in (pack space) |
| One large prime | in: half the time from 38 digits up, and worth having from 22 |
| RAND, RSA numbers; hex and binary | not in |

## Measurements

Everything below was measured on the emulator at 921,600 cycles a second, or (marked *twin*) on the PC twin, whose costs were set from those measurements.

### Arithmetic (BENCH)

A modular product: 64 bits 6.3 ms, 128 bits 18.5, 256 bits 69, 512 bits 256, 1,024 bits 1,025 (the spec's table: 9, 31, 116, 500, 1,800).

### The sieve

| Digits | Tier 1 (LZ64) | Tier 2 (XP) | Tier 3 (72 to 78 primes) | Spec, tier 1 |
|---|---|---|---|---|
| 18 | 19 to 26 s | | | |
| 20 | 28 to 35 s | | | |
| 24 | 59 to 82 s | | | |
| 28 | 110 to 160 s | | | 4 min (128 primes) |
| 30 | 170 to 290 s | 3 min to 3 min 20 s | | |
| 32 | 300 to 330 s | | | 33 min (128) |
| 34 | 7 to 8 min | 7 min | 14 min | |
| 36 | 11 to 14 min | 14 to 17 min | 35 min | 2.3 h |
| 38 | 14 to 21 min | 23 to 34 min | 50 min | 6 h |
| 40 | 34 to 47 min | 66 to 71 min | 4.1 h | 14.5 h |
| 42 | 50 to 67 min | 3.2 h | 10 to 34 h *twin* | |
| 44 | 2.5 to 3.3 h | 14.7 h | 2 to 5 days *twin* | 2 to 3 days |
| 46 | 3.5 to 6.6 h | 35 h | | 10 to 12 days |
| 48 | 7.1 to 20.7 h (six numbers) | 3 to 8 days *twin* | | 3 to 4 weeks |
| 50 | 1 to 2 days *twin* | 2 to 5 weeks *twin* | | 1 to 3 months |
| 52 | 1.5 to 3 days *twin* | | | |
| 55 | 11 to 15 days *twin* | | | |

Whole jobs on the emulator (`QS(n)` from the line, random numbers of two primes of the same length), 68 of them, every one right; *twin*: `ref/twin/QsP.cs`, whose times agree with the emulator's (44 digits on an XP: 11 to 15 h against 14.7; 48 digits on an LZ64: 6.5 to 15 h against 7.1 to 21). The estimate on the screen is the mean of these (`t1` in `ov_qest.asm`); some numbers take half of it, or twice.

FACTOR(2\*\*101-1) takes about 4 min (spec: a 31-digit sieve job), FACTOR(2\*\*128+1) 33 to 36 min (0.9.8), FACTOR(2\*\*168-1) 35 s on an LZ64 (0.9.8: 55). The sweeps are in `ref/twin/sweep*.txt`, `ref/twin/best.py` tabulates them.

### ECM: one factor in how many curves (`ref/ecmcount.js`)

| Digits | B1 500 | 2,000 | 11,000 | 50,000 |
|---|---|---|---|---|
| 10 | 3.7 | | | |
| 12 | 14.5 | 5.1 | | |
| 15 | 140 | 28 | 9.5 | |
| 18 | | 240 | | |
| 20 | | 480 | 69 | 22 |
| 23 | | | 900 | |
| 25 | | | | 960 (3 in 2,880 curves, so uncertain) |

The model is the program's own curve for curve (`tests/t_meth.js` checks that each factor comes up on the curve the model says).

### Primality, whole tests

| | LZ64 | CM |
|---|---|---|
| 2\*\*127-1 | 5 s | 5 s |
| 2\*\*521-1 | 170 s | 209 s |
| 2\*\*2047+1919 (617 digits) | 6 h 13 min (0.9.5) | 7 h 16 min |
| LLT(521), LLT(1279) | 48 s, 10 min | 55 s, 11 min |

### Response

ON/CLEAR was pressed at random moments of 25 kinds of work (`tests/t_pause.js`): the pause screen always came within two seconds, usually within one, and the result after Continue was the same. The first estimate of a run was within about 20% of the time it took (`tests/m_eta.js`), except for Mersenne numbers in ISPRIME, whose Lucas test is half as long as usual. After 15 seconds the time left comes from the time taken.

## Tests

`node tests/run_all.js` runs everything (69 runs, 11 minutes; all pass on this build); each test can be run by itself.

| | |
|---|---|
| `t_short` | 68 lines on all 29 ROMs: every function, the composites chosen to break a test, the errors, each tier's refusals, SAVE and LOAD, the memory given back |
| `t_known` | the spec's known answers on five models, then random numbers factored |
| `t_core`, `t_eval`, `t_func`, `t_prime`, `t_meth` | the arithmetic, the parser, the functions, the prime tests (with A217719), each method, against BigInt |
| `t_qs1`, `t_qs2` | the sieve from inside: every relation, every set of relations |
| `t_prove` | every certificate read out of memory and checked from scratch |
| `t_keep` | every method stopped with K and resumed, more than once |
| `t_tiers` | memory taken away to force each tier: its limits, and its largest jobs |
| `t_factors` | the factors' screen line by line, powers and cut primes, on four lines and two; S: what cancels it, the records, a late S, no pack, hardly any memory |
| `t_small` | 9 to 22 digits through the sieve against a time limit, with less and less room; FACTOR; rho's estimate |
| `t_psion` | `psion/`, what RPLOAD sends, is byte for byte what `build/game`'s pack holds |
| `t_ksq` | Karatsuba's squares where they are used: LLT's numbers against BigInt step by step, a pause between; MODEXP at lengths about 1,536 bits and past them; a smaller and smaller block (OV_KSQ, then sqrp, then NO MEMORY) |
| `t_tight` | the prime tests where there is too little memory for more than two slots, primes of every size of top byte and composites that pass base 2, the least memory, and one kept there and resumed with room |
| `t_pause`, `t_leave`, `t_alarm`, `t_power`, `t_help`, `t_left`, `t_stress`, `t_events` | response; leaving in every way, the zero page as it was; an alarm ringing during work and at a key wait, on every model; switched off by itself and by a low battery, at the line and in a run, on all 29 ROMs; every line of HELP; the time left (it never goes up while nothing is done, it is near the truth, Job agrees with it); random lines and keys with the kernel, pointers and variables checked after each; the same with packs put in, taken out and full, low batteries, the clock set, keys held, typed ahead and together |
| `t_fuzz`, `t_odd`, `t_edit`, `t_files`, `t_version` | lines of functions in functions with numbers of the sizes where things change, then garbage; the methods given 0, 1, negative numbers, squares, pseudoprimes, silly bounds; the editor against a model; LOAD, LOG and RESUME of files that are not as they should be, odd names, full packs, impossible settings; two versions in the slots, mixed on a pack, and the pack changed or pulled at every moment of a load |
| `t_carry` | a number over the cap that loses a factor to ECM and then fits the sieve: which methods start, and that no curve runs twice (hours of Organiser time; run by hand. In tier 3, 50 digits: rho, P-1, P+1 and five curves once, a factor, then two curves of level 2, which was the fifth, and the sieve) |
| `m_*` | measurements: the sieve, its phases, the estimates, the CM's largest job |

## How it is made

`python tools/build.py` assembles everything (the assembler is `tools/asm.py`) and writes the pack, listings and `build/game/budget.txt`. The launcher runs a bootstrap that lies in its own translated text; it takes all the memory under OPL's stack but 56 bytes, reads the kernel into the top of it and hands over. Two files on the pack hold the rest: BNK (kernel and half the overlays) and BNL. Both carry the build's number, so another version's files on another pack are passed over. On the CM the kernel's multiply rows lie in the OS's buffer for files (the program uses none there but to save the settings), the entry line where the bootstrap was, and the progress display is itself an overlay.

| Folder | |
|---|---|
| `src/launch`, `src/kernel`, `src/core`, `src/ovl` | the bootstrap; the kernel; the multiply; 87 overlays and their shared pieces |
| `ref` | the models: ECM curve for curve, the PC twin of the sieve (C#) |
| `docs/parked-ram-savings.md`, `docs/parked` | savings not made yet: what they are, the evidence, what to check, the scripts |
| `docs/report.html` | the report: screens, how it works, where every byte of RAM and pack goes (`tools/report_probe.js` measures, `tools/report.py` puts the figures in) |
| `tests`, `tools`, `docs`, `data` | (`data/sieve_times.csv`: the 68 whole sieve jobs) |

## The choice of a (0.9.5)

A polynomial's a is a product of s primes of the base. Its size should be near sqrt(2kN)/M: as the twin (`QsP.cs`) showed, 48-digit numbers took 24 to 200 hours or more because it could not be.

- **s was the fewest for which log2(a)/s is below 7.64, but the pool of primes for a's was 32 of them from 20 up** (average 6.6 to 6.9 bits, 10 at most), so from about 46 digits no a was near enough: it found the same few again and again, and the duplicates were thrown away. Now the pool is up to 48 primes from 40 up (below 1,024, so the modular arithmetic has 10-bit multipliers and 16-bit products), and s is the fewest with log2(a)/s below 8.6: 4 at 24 digits, 5 at 30, 9 at 48. 48 digits (the twin, the mean of eight numbers): 96.6 h before, 23.7 h now, and less again with the threshold below; six numbers on the emulator took 24 hours to over 8 days, now 7 to 21 hours.
- **The multiplier** is any of 46 (every square-free k to 73, with half of log2 k as its penalty); before, odd ones to 47.
- **The sieve's threshold adapts.** If fewer than one cell was looked at for every four polynomials of an a, the next a's are sieved 2 bits more loosely (16 at most). That finds 15 to 35% more from 40 digits, and nothing is lost below.
- **Tried, and not worth it** (the twin): never the same a twice, a wider tolerance, other bases and sieve lengths for the same memory.
- **KEEP now has the multiplier and s** with the relations (RESUME with less memory could have picked another s, for which the relations made no sense). A sieve kept by 0.9.4 is not taken up: it starts again.
- The time estimates and the progress curve (`share.inc`: r of n relations take about r + (n - r)/9 of the time, 1.6 r while that is less, instead of /18 and 1.7) are from the new jobs.
- At 34 digits and less it takes about the same time as 0.9.4 (a size's mean within 12%); the same numbers on 0.9.4 and 0.9.5: LZ64 36 to 40 digits 0.9 of the time, XP 34 digits 0.73, 38 digits 0.75, 40 digits 0.52.

## Faster (0.9.9)

Small and middle-sized jobs spent a third to a half of their time reading overlays (FACTOR(2\*\*168-1): 487 of them, 40% of 50 s; PROVE(2\*\*127-1): 442, 46%). Each change was measured on the emulator against 0.9.8:

| | Change | Measured | Cost |
|---|---|---|---|
| A | Trial division divides out what it finds itself, in place (the remainder test run again with each multiple kept: N + p S = p 256\*\*n, so N / p = 256\*\*n - S), not with OV_DIV (two overlays each time) | with B and F below: PROVE(2\*\*127-1) 31.8 to 18.4 s | OV_TRF +233 bytes of pack, no RAM |
| B | An overlay's fix-ups read 16 at a time onto the stack (one call for them, not one a byte) | an overlay read about 30% quicker; FACTOR(2\*\*168-1) 55.1 to 44.5 s by itself | 25 bytes of the kernel, on every model |
| C | The sieve keeps the relations of a polynomial in the part of its block already looked at and hands them to OV_QSP at the end (two overlays for them all, not for each) | with D: 21 digits 13%, 30 digits 14% quicker (the mean of 12 and 6 numbers), overlays read halved | none |
| D | OV_QSA and OV_QSR (a new a, its roots) are part of OV_QS | (with C) | none (1,322 bytes, within the large slot) |
| E | Rho's GCD in OV_RHO (one without Jacobi's sign, for an odd number) | rho 5 to 6% quicker | pack +335 |
| F | The primes for trial division from a table on the pack (BNK, after its index: a byte for each 30, a bit for each of the 8 numbers there prime to 30; 2,185 bytes to 65,535), not sieved by OV_PS | TRIAL to 65,535 24.2 to 11.4 s | pack +2,185 |
| G | Squares from 192 bytes (1,536 bits) by Karatsuba's way (OV_KSQ, three squares of half the length while they are 96 bytes or more), on tiers 1 to 3 | a modular square: 2,048 bits 5.5%, 3,072 10%, 4,096 13%, 6,144 16% quicker; LLT(2203) 23%, LLT(4423) 42% quicker; nothing below 1,536 bits | 38 bytes on tiers 1 to 3 (none on the CM); its work, 3 n + 64 bytes, only while it runs, and only if there is room (sqrp otherwise) |

**Trial division's limit** stays 10,000. Measured on random numbers with TDIV from 3,000 to 65,535: 20 digits (16 numbers) 179 s in all at 10,000, 224 at 5,000, 209 at 65,535; 30 digits (10 numbers) 914 s at 10,000, flat from 5,000 to 15,000, 992 at 65,535. For numbers with a prime factor between 10,000 and 65,535 a limit of 65,535 is far quicker (rho takes up to minutes for them), but only about one number in five has one, and trial division to 65,535 costs every number 4 to 13 s.

**G, the memory.** OV_KSQ is an overlay: OV_INIT puts a jump to a stub kept with the progress code (OV_PROG, in RAM on tiers 1 to 3) in sqrp's first 3 bytes. The stub sends a square there only when it is long enough to pay for the two overlays read and there is room for the work below the stack of numbers, so the sieve's base and every other limit are what they were. On the CM nothing is changed. The display is brought up to date before each such square (none is shown while OV_KSQ is in). A multiply (ECM, P-1) is still done the long way.

## Small numbers (0.9.8)

- **The sieve could stall** (0.9.5 to 0.9.7): one in about twelve numbers of 16 digits, and some of 14 and 15, took minutes or did not end; FACTOR of longer numbers met it when that much was left over (20 random numbers of 24 digits took up to 27 minutes). It was never wrong, only slow. The rule for how many primes are in an a, new in 0.9.5, took no account of a small base: with 36 primes it asked for larger ones than there are, so the same few a's came again and nothing new with them. With a base below 56 primes an a is now made as it was in 0.9.4 (from 20 up, log2(a)/s below 7.64). 480 random numbers of 9 to 24 digits, 30 of each length: 16 to 23 s up to 13 digits, then 18 (14 digits), 19 (16), 24 (18), 32 (20), 49 (22), 66 s (24), and none over three times the middle one.
- **Rho's estimate** left out the GCDs (about 0.35 s each, whatever the size, most of it overlays) and the smaller half of a step: 3 s for what took 8. Now it is within 15% from 254 steps on, 18 to 77 digits (within 5% to 48 digits). The sieve's time in the plan has its base, combining and roots.
- **Rho is tried where it pays.** Trial division to 10,000 has been there first, so a few hundred steps find little. As simulated from the measured times on random numbers with no factor below 10,000, and then measured: to the end up to 13 digits (13 digits: 15 s where it was 21); not at all from 14 to 21 digits (a fifth of the sieve's time is under 500 steps; 15 digits: 23 s where it was 30 or more); then within its fifth.
- The sieve's 2 to 3 tries at the square root are as many as they should be.

## Less memory (0.9.6)

| | CM | Others | |
|---|---|---|---|
| One routine for adding and taking (`add3`, `sub3`), its three instructions put in each time | 63 | 63 | some 20 cycles a call |
| The chunk copied for a row: 8 bytes in the kernel, the rest made with the rows | 30 | -3 | a modular square 2% quicker on a CM (it copied 24 bytes for its 8) |
| The prime tests in two slots | a length of the number at the peak: 256 bytes for 2,048 bits | the same when memory is short | pack +227; Lucas 2% slower, only with no room for five slots |

**The two slots.** Base 2 compares with 1 by itself, and with -1 by adding 1 in the product's room. Lucas has to take P and 2 off its numbers at every step, which are R modulo N times P and 2: they were slots of their own, or one slot of R modulo N when there was little room. Now with little room there is none: R modulo N is R - q N with q = R / N below 256, so taking 1 off is adding q N, one byte's multiply a byte, and dropping the carry (and N once more if there is none). A number goes the other way round its negative. A run kept in one way can be resumed in the other.

The first try at the copying had all of it made with the rows. On a CM that went 2 bytes into what the OS uses of its file buffer (to $219C) and the program hung after the menu: `t_stress` found it.

Two more ideas, 383 bytes on every model, are parked in `docs/parked-ram-savings.md`.

## The hard-testing round (0.9.3)

Asked for after Chess loaded another version's files from the other slot. BigNum did not have that fault (its files carry the build's number, and 24 starts with 0.9, 0.9.1 and 0.9.2 in B: and C: each ran the right one), but:

- **A pack changed while it runs** for another version's was not seen: the code of the wrong version could be run. The build's number now stands before and after every overlay (PACK CHANGED; FILE NOT FOUND if there is none of this build at the start), so a pack pulled out in the middle of a load is seen as well, at any moment of it (it could TRAP). Fix-ups never go past the block.
- **A line of exactly 255 characters** was always a SYNTAX error. The longest is 254 now.
- **LOAD** could make a number up to 13 bits over the cap, when its last few digits took it there: TOO BIG now. It also took a minus sign anywhere (`12-34`, `5-`, `--5`): BAD ARG.
- **LOG** of a file that is not its own printed control codes (beeps, a cleared screen): spaces now.
- **SET EVERY** past 1,092 minutes came round to a short time: 18 hours at most.
- **Screens that ran past the edge:** the pager's place on four lines (`Digits 121-180 of 57`, for 573: the word is left out where it would not fit), SIZE's `bits`, ECM's stage with many curves (`Curve 100/1000 s1`), `QS combining  99%` on two lines, the texts of FACTOR's quick steps when paused.

Nothing else turned up in 27,000 random lines against BigInt and 14,000 of garbage on 10 models, 1,476 odd arguments, numbers at the cap with memory full, 112 FACTOR jobs with S, ON, C, K and RESUME at random moments, 60 hours of Organiser time of random keys and events, 7,000 keys of the editor, a spoiled BIGKEEP 42 ways on three models, and being run from a program with variables, an open file, ESCAPE OFF and ONERR.

## Time left (0.9.2)

As seen on a real LZ64 (photo of FACTOR(2\*\*137-1): `left 3:54:00` creeping up between relations, `Job: up to 75 min`), the figures were wrong in several ways:

- **It crept up** between units and dropped at the next one: it was the time so far, scaled, worked out afresh each second. Now it is worked out when a unit is done and counted down from there. The first three units of a part are not enough to go by: until the fourth it is the estimate.
- **The sieve's relations do not come evenly**: slowly at first, then faster as the partial ones pair off. r of n of them take about r + (n - r)/9 of the time (1.6 r while that is less): `share.inc`, from fifty logged jobs of 24 to 48 digits; within 8% on average from a fifth of the way on.
- **Until there are eight relations** it is an estimate for the number; it was whatever the last method had left behind (2 seconds, at the start of a 33-digit sieve).
- **The estimate took the memory tier's usual base**, not the one there is room for. OV_QEST asks OV_QS0 how many primes fit, and adds 13/8 (n - F)/F to log2 of the time for F of the n the number should have (which gives the old tables of tiers 2 and 3 as well). Some numbers still take half of it, or twice.
- **Job** was fixed at the start. During the sieve (the last step) it is the time so far and the time left, brought up to date for each a: `Job: about 197 min`. Minutes up to 200, to the nearest; on two lines `C42 job 97 min` (with `to` it did not fit).
- **After RESUME** the time left was far too short; the part is taken to have begun when its estimate says.
- MODEXP's display said `0 digits`.
- **0.9.4: rho ran past its limit** (`Step 3151/2473 127% left 0:23:19` in FACTOR(2\*\*101-1)) when the limit fell in a run's first r steps, which find nothing and were not checked: up to r + 100 steps too many, and the time left wrapped round. Now a run whose steps that count would lie past the limit is not begun (`Step .../2046` for a limit of 2,473: the rest could find nothing), and the last batch ends at the limit. With more units done than were thought (P-1 and P+1 pass their bound by a prime), it is 100% and nothing left.

FACTOR(2\*\*137-1) in the emulator takes 1 h 8 min on an empty LZ64 (base 234); in 0.9.2 it was 1 h 29 min, and 3 h 17 min with 4,600 bytes less (base 158).

## Made smaller (0.9.1)

| | Pack | CM RAM |
|---|---|---|
| The 50 busiest bytes of variables in the zero page ($A7-$C4, $CC-$DF: OPL's and the calculator's, not read or written by the OS while machine code runs; kept in the launcher's code that has run, put back on leaving) | −3,783 | −143 |
| Dead routines of shared files left out (`ifused`), and entries of the overlays' tables that need no jump (`entry`, `lastent`) | −772 | −5 |
| The progress code stored once (it runs in two places) | −464 | |
| Montgomery operation lists: 2 bytes each, not 4 | −657 | +13 |
| Far calls by way of a jump nearby (the assembler does it: `share`) | −924 | −32 |
| Kernel entries that load their own argument (`ilenw`, `hpush1`, `ln0`...) and other small things | −750 | +49 |
| HELP's two missing lines, the version | +14 | |
| A low battery while an overlay is read | +12 | +12 |

In all 7,324 bytes of pack, 106 of RAM on the CM, 119 elsewhere, and it is 0 to 10% quicker (ISPRIME(2\*\*521-1) on the CM 0.6%, a 33-digit sieve 3%, PROVE(2\*\*107-1) 8%, a key press 10%). The OS's use of the zero page was logged on 13 ROMs under random keys, and on all 29 through a low battery and switching off and on. `KB$BREK` reads OPL's escape flag ($B0), so leaving puts the zero page back before it; switching on writes $F6-$FE, so nothing that lasts is there. A label of an overlay that is also the kernel's is refused by the build.

## Bugs the tests found that are worth knowing about

- **HELP's end was garbled in 0.9** (found by Daniel): the assembler took a line with a single quotation mark that does not close for a comment, so two texts were left out and their length bytes stayed. It refuses such a line now, `t_help` reads every line, and `t_stress` looks for control codes on the screen.
- **A battery going low just as an overlay was read** (PK$SETP refuses, error 194) ended the program with NO PACK, and the run and the variables were lost (0.9, all ROMs but 2.4's). Now the OS says BATTERY TOO LOW and switches off, and the work goes on when it is on again; `t_power`.

- **An alarm ringing on an LZ64** runs inside the tick interrupt and writes $E1. The multiply kept its chunk at $E0 to $F7, so an alarm during a long run gave a wrong answer without a word. The chunk is at $E2 to $F9 now (no interrupt on any ROM looked at writes there); `t_alarm`.
- **The sieve could stall** on an XP when its store of relations filled up, one short of the end: a relation made of two partial ones takes two entries, and room for one and a half was kept. Room for two now.
- **The sieve's random choice of polynomials came round again** after some 65,000 steps, and choosing the best of four sets of primes came up with the same few thousand sets over and over, so a long job on a small base slowed to a crawl (a run of 38 digits in tier 3 showed both). The period is four thousand million now, and any set within a tolerance will do.
- **All ten sets of relations trivial** (one run in a thousand): it starts again.
- **Saving the settings from the menu** emptied the entry line but not its cursor, and the next key overwrote memory.

## Still to do on real hardware

Timing (BENCH and a real primality test), key response, checkpoint writes to a Datapak and a Rampak, batteries, and the low-battery warning during a long run. Nothing here depends on how the emulator times things, but none of it has been seen on a machine.
