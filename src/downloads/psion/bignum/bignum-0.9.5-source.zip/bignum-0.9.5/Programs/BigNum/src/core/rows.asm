; =====================================================================
; The multiply rows. A number is held highest byte first. One row adds (a chunk of the multiplicand,
; up to kv_wm bytes at YZ) x (the byte zm) into the product, with X one byte above the chunk's top
; product byte: the step for the chunk's byte t (0 the highest) is
;       ldab YZ+t / ldaa zm / mul / [inca] / addd t+1,x / std t+1,x / bcs or bcc
; in two copies, N (no carry into it) and C (a carry into it: inca), that branch to each other, so a
; carry is never stored: 26 or 27 cycles a byte pair. The code is made in RAM by rowgen (rowgen.inc).
; kv_et is a table: where to enter for a chunk of w bytes. A row leaves by a jmp whose address is
; patched (kv_rx points at it).
; =====================================================================

; ycl: the chunk of WMAX bytes at X into YZ (bytes past the chunk's own do no harm)
ycl:    ldd  0,x
        std  YZ
        ldd  2,x
        std  YZ+2
        ldd  4,x
        std  YZ+4
        ldd  6,x
        std  YZ+6
        ldd  8,x
        std  YZ+8
        ldd  10,x
        std  YZ+10
        ldd  12,x
        std  YZ+12
        ldd  14,x
        std  YZ+14
        ldd  16,x
        std  YZ+16
        ldd  18,x
        std  YZ+18
        ldd  20,x
        std  YZ+20
        ldd  22,x
        std  YZ+22
        rts
; entryw: B = a chunk's width: D = where to enter the rows for it
entryw: aslb
        ldx  kv_et
        abx
        ldd  0,x
        rts

; mulr: rows for the multiplier bytes from zx down to ze, the product pointer zp one above the first
; row's X; B = the chunk's width. mulrx: the same with the entry already set
mulr:   bsr  entryw
        std  mr_j+1
mulrx:  ldx  kv_rx
        ldd  #mr
        std  0,x
mr:     ldx  zx
        cpx  ze
        beq  mr_x
        dex
        stx  zx
        ldab 0,x
        beq  mr_z
        stab zm
        ldx  zp
        dex
        stx  zp
mr_j:   jmp  mr
mr_z:     ldx  zp
        dex
        stx  zp
        bra  mr
mr_x:     rts

; redr: Montgomery rows: as mulr, but each multiplier is made from the product's lowest byte, which
; it clears, and is then kept there; zp ends at ze; B = the chunk's width; zm = the byte to put
; below the first row
redr:   pshb
        bsr  entryw
        std  rr_j+1
        pulb
        incb
        stab rr_l+1
        stab rr_s+1
        ldx  kv_rx
        ldd  #rr
        std  0,x
rr:     ldx  zp
        ldaa zm
rr_s:   staa 1,x                ; the one before, kept
        cpx  ze
        beq  rr_x
        dex
        stx  zp
rr_l:   ldab 1,x                ; the lowest byte
        ldaa zk
        mul
        stab zm
rr_j:   jmp  rr
rr_x:     rts
