; =====================================================================
; OV_LLT: LLT(p): the Lucas-Lehmer test of 2**p - 1. The squares are kept modulo 2**p - 1 but not below it:
; with n bytes and k = 8 n - p, 2 to the 8 n is 2 to the k, so the product's top half times 2 to the k is
; added to its bottom half.
; =====================================================================
        include "macros.inc"
        include "ckn.inc"
        lastent llt

ll_p    = kv_fs                 ; p
ll_k    = kv_fs+2               ; 2 to the k
ll_i    = kv_fs+4               ; steps left
ll_e    = kv_fs+6               ; the argument's end
llt:    ldx  kv_wp
        ldd  0,x
        bmi  .arg
        beq  .arg
        bsr  inext
        stx  ll_e
        ldx  kv_wp
        ldd  0,x
        subd #2
        bhi  .big
        beq  .w
        ldab 2,x
        clra
        bra  .p
.w:     ldd  2,x
.p:     std  ll_p
        subd #1
        beq  .no                ; 1: no
        subd #1
        beq  .yes               ; 2: 3 is prime
        ldd  kv_cap             ; not past the cap
        asld
        asld
        asld
        subd ll_p
        bcs  .big
        bsr  isp                ; p must be prime
        bcs  .no
        ldd  ll_p
        addd #7
        lsrd
        lsrd
        lsrd
        std  mn
        ldab ll_p+1             ; 2 to the k
        negb
        andb #7
        ldaa #1
.k:     decb
        bmi  .kd
        asla
        bra  .k
.kd:    staa ll_k
        ldd  mn                 ; room: the product and a byte before it, the number
        asld
        addd mn
        addd #2
        bsr  walloc
        inx
        stx  mp
        ldd  mn
        asld
        addd mp
        std  ma
        std  kv_fs+8
        xgdx                    ; 4
        bsr  clrxn
        dex
        ldaa #4
        staa 0,x
        ldd  ll_p               ; the digits, for the display
        std  kv_bits
        ldx  #$4D10             ; p log10(2)
        os   UT$UMUL
        addd #1
        std  kv_digs
        ldd  ll_p
        subd #2
        std  ll_i
        bsr  part
        ovsub OV_EST,4
        ldx  #hook
        bsr  hookx
        ldaa #CK_LLT
        bsr  ckset
        bra  .loop
.arg:   bra  errarg
.big:   bra  errbig
.no:    clra
        clrb
        bra  .res
.yes:   ldd  #1
.res:   pshb
        psha
        bsr  hook0
        pula
        pulb
        bsr  hpush
        ldx  ll_e
        bra  hslx
.loop:  bsr  safe
        ldx  kv_fs+8
        stx  ma
        ldd  mn
        std  mal
        bsr  sqrp
        ldx  mp                 ; the top half copied into the number's place, its lowest byte cleared
        ldd  kv_fs+8            ; (it takes the carry)
        bsr  cpn
        ldd  mp
        addd mn
        std  mpe                ; the bottom half
        xgdx
        dex
        clr  0,x
        ldd  kv_fs+8            ; + the top half x 2 to the k
        addd mn
        std  mye
        ldd  mpe
        addd mn
        std  mpe
        ldd  mn
.r:     std  mrem
        bsr  chunkw
        bsr  chunky
        bsr  chunkp
        ldx  #ll_k
        stx  ze
        inx
        stx  zx
        ldab zw
        bsr  mulr
        bsr  chunkd
        bne  .r
        tstb
        bne  .r
.f:     ldd  mp                 ; what went over, again
        addd mn
        xgdx
        dex
        ldaa 0,x
        beq  .sub
        clr  0,x
        ldab ll_k
        mul
        std  zt
        ldd  mp
        addd mn
        addd mn
        xgdx
        dex
        dex
        ldd  0,x
        addd zt
        std  0,x
        bcc  .f
.cy:    dex
        inc  0,x
        beq  .cy
        bra  .f
.sub:   ldd  mp                 ; less 2
        addd mn
        addd mn
        xgdx
        dex
        dex
        ldd  0,x
        subd #2
        std  0,x
        bcc  .st
        ldd  mn                 ; a borrow: up to the bottom half's top; past it, 2 to the k less
        subd #2
        std  zt
.bw:    ldd  zt
        beq  .past
        subd #1
        std  zt
        dex
        ldaa 0,x
        dec  0,x
        tsta
        beq  .bw
        bra  .st
.past:  ldd  mp
        addd mn
        addd mn
        xgdx
        dex
        ldaa 0,x
        suba ll_k
        staa 0,x
.st:    ldd  mp                 ; back to its place
        addd mn
        xgdx
        ldd  kv_fs+8
        bsr  cpn
        ldx  kv_done
        inx
        stx  kv_done
        ldx  ll_i
        dex
        stx  ll_i
        bne  .loop
; the number modulo 2**p - 1: zero?
        ldd  mn                 ; as a number
        addd #2
        bsr  walloc
        ldd  mn
        std  0,x
        inx
        inx
        xgdx
        ldx  kv_fs+8
        bsr  cpn
        bsr  hnorm
        ldd  #2                 ; 2**p - 1
        bsr  hpush
        ldd  ll_p
        bsr  hpush
        ldd  ll_p
        pshb
        psha
        ldd  kv_cap
        addd #1                 ; (2**p may be a byte past the cap)
        std  kv_cap
        ovsub OV_POW,0
        pula
        pulb
        bsr  hpush1
        bsr  hsub
        ovsub OV_DIV,1
        ldx  kv_wp
        ldd  0,x
        beq  .yes
        bra  .no
; isp: carry clear if ll_p is prime
isp:    ldd  ll_p
        lsrb
        bcc  .no
        ldd  #3
        std  kv_al
.l:     ldd  ll_p               ; modulo d
        std  zx
        clra
        clrb
        ldx  #16
.b:     asl  zx+1
        rol  zx
        rolb
        rola
        subd kv_al
        bcc  .q
        addd kv_al
        bra  .n
.q:     inc  zx+1
.n:     dex
        bne  .b
        subd #0
        beq  .z
        ldd  zx                 ; the quotient below d: prime
        subd kv_al
        bcs  .y
        ldd  kv_al
        addd #2
        std  kv_al
        bra  .l
.z:     ldd  ll_p               ; a divisor: p itself?
        subd kv_al
        beq  .y
.no:    sec
        rts
.y:     clc
        rts
hk_t:   fcl  "LLT  "
hk_p:   fcl  "Step "
hk_q:   fcl  "LLT "
        include "bhook.inc"
        include "ckset.inc"
        include "cksafe.inc"
