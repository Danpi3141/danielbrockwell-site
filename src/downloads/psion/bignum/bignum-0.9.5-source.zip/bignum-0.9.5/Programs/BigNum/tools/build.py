#!/usr/bin/env python3
"""Builds BigNum: the machine code, the launcher and the pack.

    python tools/build.py [--out build/game] [--psion]

Pack (Datapak, runs on every model): BIGNUM (OPL: checks the free memory, then runs the bootstrap that
lies in its own translated text, src/launch/boot.asm) and BNK (a data block: the resident size, the
length of the kernel's part, the kernel's code, its start-up code, the fixer and the fix-ups, then the
overlay area: src/kernel/kov.asm). No OPL array: the bootstrap takes the memory from under OPL's stack.
"""
import argparse
import json
import os
import sys
import zlib

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import asm   # noqa: E402
import pack  # noqa: E402

VERSION = '0.9.5'
NEED = 5740                     # what the launcher asks for (FREE in BIGNUM): a 2,048-bit primality test
PACK_K = 64
BOOT_MIN = 131                  # the smallest tier's entry line lies in the bootstrap's place
OVL = ['ov_init', 'ov_edit', 'ov_eval', 'ov_show', 'ov_pause', 'ov_div', 'ov_menu', 'ov_cmd', 'ov_pow', 'ov_fn', 'ov_digs', 'ov_root', 'ov_seq', 'ov_binom', 'ov_mexp', 'ov_meven', 'ov_est', 'ov_page', 'ov_names', 'ov_minv', 'ov_msqr', 'ov_prp', 'ov_luc', 'ov_pshow', 'ov_base2', 'ov_lucp', 'ov_next', 'ov_llt', 'ov_rho', 'ov_meth', 'ov_pm1', 'ov_mset', 'ov_head', 'ov_ps', 'ov_ps2', 'ov_ecm', 'ov_ecs', 'ov_ec2', 'ov_qs', 'ov_qs0', 'ov_qs1', 'ov_qsa', 'ov_qsr', 'ov_qsv', 'ov_qsp', 'ov_qsl', 'ov_qsx', 'ov_fact', 'ov_trial', 'ov_ppow', 'ov_plan', 'ov_qest', 'ov_fshow', 'ov_keep', 'ov_prove', 'ov_prvm', 'ov_pchk', 'ov_wit', 'ov_witt', 'ov_sqt', 'ov_lv', 'ov_cert', 'ov_vshow', 'ov_cshow', 'ov_phi', 'ov_ins', 'ov_vars', 'ov_set', 'ov_setf', 'ov_help', 'ov_file', 'ov_res', 'ov_bench', 'ov_logv', 'ov_fsav', 'ov_log', 'ov_logc', 'ov_ecma', 'ov_ec2a', 'ov_ps2a', 'ov_pm1a', 'ov_trf', 'ov_fline', 'ov_setl', 'ov_fspl', 'ov_prog', 'ov_pre', 'ov_ckl']

OV_2 = OVL.index('ov_qs0') + 1                  # the first overlay of the second file, BNL

# not loaded on the smallest tier (the sieve, files): these may be longer
BIG = [u for u in OVL if u.startswith('ov_qs') or u in ('ov_qest', 'ov_keep', 'ov_file', 'ov_res', 'ov_logv', 'ov_fsav', 'ov_log', 'ov_logc', 'ov_ckl')]


class BuildError(Exception):
    pass


def encode_fixups(fix):
    """Steps, two a byte (the high nibble first): 1-15 on that far and fix the word there,
    0 on 15 without a fix-up (also the pad). (src/launch/fixer.asm, kov.asm.)"""
    nib = []
    prev = 0
    for f in sorted(fix):
        d = f - prev
        if d < 1:
            raise BuildError('a fix-up at %d: steps start at 1' % f)
        while d > 15:
            nib.append(0)
            d -= 15
        nib.append(d)
        prev = f
    if len(nib) % 2:
        nib.append(0)
    return bytes(nib[i] << 4 | nib[i + 1] for i in range(0, len(nib), 2))


def launcher_lines(need, k, blen):
    return ['BIGNUM:', 'IF FREE<%d :PRINT "BIGNUM NEEDS" :PRINT %d-FREE;" MORE BYTES" :GET :RETURN :ENDIF' % (need, need),
            'USR(PEEKW($A9)+%d,0)' % k, 'RETURN', 'PRINT "%s"' % ('Q' * blen)]


def opl_record(path):
    class A:
        no_translate = False
        target = 'cm'
        strip_indent = True
        encoding = 'latin-1'
    _, rec, _ = pack.opl2opk.opl_procedure(path, A, quiet=True)
    return bytes(pack.strip_source(rec))


def launcher(out, boot, keep):
    """The launcher's records, the bootstrap put where its string of Qs is."""
    boot = bytes(boot) + bytes(max(0, BOOT_MIN - len(boot)))
    if len(boot) > 250:
        raise BuildError('the bootstrap no longer fits one string')
    path = os.path.join(out, 'BIGNUM.opl')

    def make(k):
        with open(path, 'w', encoding='latin-1', newline='\n') as f:
            f.write('\n'.join(launcher_lines(NEED, k, len(boot))) + '\n')
        return opl_record(path)
    rec = make(12345)
    q = rec.find(b'Q' * len(boot))
    w = rec.find(bytes([0x22, 0x00, 0xA9]))
    if q < 0 or w < 0 or rec.find(bytes([0x22, 0x00, 0xA9]), w + 1) >= 0:
        raise BuildError('the launcher is not as expected')
    k = q - (w + 3)
    # kinit keeps the zero page in the code that has run before the bootstrap, up to the USR's operands
    code = rec.find(bytes([0x22]) + NEED.to_bytes(2, 'big')) - 1          # FREE, the first thing done
    if rec[q - 8:q - 2] != bytes([0x22, 0, 0, 0x9F, 0x83, 0x7B]) or code < 0 or rec[code] != 0x90 or code > q - 6 - keep:
        raise BuildError('no room in the launcher for the zero page (%d)' % keep)
    rec2 = make(k)
    if len(rec2) != len(rec) or rec2.find(b'Q' * len(boot)) != q:
        raise BuildError('the launcher changed shape')
    return rec2[:q] + bytes(boot) + rec2[q + len(boot):]


def build(out, pad=0, build_id=None):
    if build_id is None:        # (twice: the build's number is made of everything else)
        return build(out, pad, (build(out, pad, 0)[1] ^ zlib.crc32(VERSION.encode())) & 0xFFFF or 1)
    src = os.path.join(ROOT, 'src')
    incdirs = [src] + [os.path.join(src, d) for d in ('kernel', 'core', 'ovl')]

    def assemble(path, origin=0, imports=None, what='', defines=None, share=None):
        try:
            return asm.assemble(path, origin=origin, imports=imports or {}, defines=defines or {}, incdirs=incdirs, share=share)
        except asm.AsmError as e:
            raise BuildError('%s: %s' % (what or path, e))

    nums = ''.join('%-8s= %d%s' % (u.upper(), i + 1, chr(10)) for i, u in enumerate(OVL))      # the overlays' numbers
    np = os.path.join(src, 'ovnums.inc')
    if not os.path.exists(np) or open(np).read() != nums:
        with open(np, 'w', newline=chr(10)) as f:
            f.write(nums)
    ov_size, ov_small, prg = 16, 16, 16
    for _ in range(60):
        k = assemble(os.path.join(src, 'kernel', 'kernel.asm'), what='kernel', defines={'OV_SIZE': ov_size, 'PRG_SIZE': prg, 'OV_2': OV_2, 'BUILD': build_id}, share=('core.asm', 'rows.asm'))
        ksym = {n: v for n, v in k.sym.items() if not n.startswith('.') and '.' not in n}
        slot = k.sym['ov_slot'][0]
        ki = assemble(os.path.join(src, 'kernel', 'kinit.asm'), origin=slot, imports=ksym, what='kinit', defines={'BUILD': build_id})
        units = [(u, assemble(os.path.join(src, 'ovl', u + '.asm'), origin=slot, imports=ksym, what=u, share=())) for u in OVL]
        n = max([len(o.out) for u, o in units] + [len(ki.out)])
        np = [len(o.out) for u, o in units if u == 'ov_prog'][0]
        ov_small = max([len(o.out) for u, o in units if u not in BIG] + [len(ki.out)])
        if n == ov_size and np == prg:
            break
        ov_size, prg = n, np
    else:
        raise BuildError('the sizes did not settle')
    for u, o in units:
        if o.entries != [3 * e for e in range(len(o.entries))] or not o.entries:
            raise BuildError('%s does not start with its entries' % u)
    for u, o in units:
        own = [n for n, v in o.sym.items() if v[1] == 'rel' and n in ksym]
        if own:
            raise BuildError('%s: the kernel has these names too: %s' % (u, ' '.join(own)))
        if u == 'ov_prog' and any(o.out[f] << 8 | o.out[f + 1] >= slot for f in o.fix):
            raise BuildError('ov_prog refers to itself (it runs in two places)')
    for i, u in enumerate(OVL):
        s = k.sym.get(u.upper())
        if not s or s[0] != i + 1:
            raise BuildError('src/macros.inc: %s should be %d' % (u.upper(), i + 1))
    res = slot + ov_small
    big = k.sym['kv_big'][0]
    code = k.sym['kv_vars'][0]
    if bytes(k.out[3:7]) != b'BNK1':
        raise BuildError('the kernel does not start with jmp + its tag BNK1')
    image = bytes(k.out)
    if any(image[code:]) or any(f >= code for f in k.fix):
        raise BuildError('the kernel variables are not all zero')
    kimg = image[:slot] + bytes(ki.out)
    kfix = list(k.fix) + [slot + f for f in ki.fix]
    imp = {'KLEN': (len(kimg), 'abs'), 'BUILD': (build_id, 'abs')}
    b = assemble(os.path.join(src, 'launch', 'boot.asm'), what='boot', imports=imp)
    fx = assemble(os.path.join(src, 'launch', 'fixer.asm'), what='fixer', imports=imp)
    if b.fix or fx.fix:
        raise BuildError('the bootstrap and the fixer must be position independent')
    allk = kimg + bytes(fx.out) + encode_fixups(kfix)
    if len(allk) > res:
        raise BuildError('the kernel, fixer and fix-ups (%d) do not fit the resident part (%d)' % (len(allk), res))

    areas, report = [], []
    for part in (units[:OV_2 - 1], units[OV_2 - 1:]):
      index, body = bytearray(), bytearray()
      for u, o in part:
          enc = encode_fixups(o.fix)
          if len(enc) > 255:
              raise BuildError('%s: %d bytes of fix-ups' % (u, len(enc)))
          blob = build_id.to_bytes(2, 'big') + len(o.out).to_bytes(2, 'big') + bytes(o.out) + bytes([len(enc)]) + enc + build_id.to_bytes(2, 'big')
          index += (2 * len(part) + len(body)).to_bytes(2, 'big')
          body += blob
          report.append('  %-10s %5d %5d' % (u.upper(), len(o.out), len(blob)))
          with open(os.path.join(out, u + '.lst'), 'w') as f:
              f.write(o.listing_text())
      areas.append(bytes(index) + bytes(body))
    idb = build_id.to_bytes(2, 'big')
    bnk = idb + res.to_bytes(2, 'big') + big.to_bytes(2, 'big') + len(allk).to_bytes(2, 'big') + allk + areas[0]
    bnl = idb + areas[1]
    crc = zlib.crc32(bnk[2:] + bnl[2:]) & 0xFFFF
    img = pack.PackImage('datapak', PACK_K, target='cm')
    img.body += launcher(out, bytes(b.out), k.sym['ZP_N'][0])
    img.add_data('BNK', bnk)
    img.add_data('BNL', bnl)
    if pad:                     # a test pack: PAD takes 2 bytes a word and runs BIGNUM
        pf = os.path.join(out, 'PAD.opl')
        with open(pf, 'w', encoding='latin-1', newline='\n') as f:
            f.write('PAD:\nLOCAL p%%(%d)\nBIGNUM:\n' % pad)
        img.add_opl(pf, source=False)
    opk = os.path.join(out, 'BIGNUM.opk')
    size_k, used = img.write(opk)
    for tag, o in (('kernel', k), ('kinit', ki), ('boot', b)):
        with open(os.path.join(out, tag + '.lst'), 'w') as f:
            f.write(o.listing_text())
    with open(os.path.join(out, 'kernel.sym.json'), 'w') as f:
        json.dump(ksym, f, indent=0)
    osyms = {u: {n: v for n, v in o.sym.items() if n not in ksym and '$' not in n} for u, o in units}
    with open(os.path.join(out, 'ovl.sym.json'), 'w') as f:
        json.dump(osyms, f, indent=0)
    text = ['BigNum %s' % VERSION,
            'Pack (%dK Datapak): %d bytes used of %d' % (size_k, used, size_k * 1024),
            '  BNK %d (resident code %d, fixer %d, fix-ups %d), BNL %d; build %04X' % (len(bnk), code, len(fx.out), len(allk) - len(kimg) - len(fx.out), len(bnl), build_id),
            'RAM: code %d, variables %d, overlay slot %d: %d; or slot %d, the progress code and the sieve variables %d: %d; bootstrap %d' % (code, slot - code, ov_small, res, ov_size, big - slot - ov_size, big, len(b.out)),
            'Overlays: code, bytes on the pack'] + report
    text = '\n'.join(text)
    with open(os.path.join(out, 'budget.txt'), 'w') as f:
        f.write(text + '\n')
    meta = {'res': res, 'big': big, 'slot': ov_size, 'small': ov_small, 'need': NEED, 'ovl': OVL}
    with open(os.path.join(out, 'build.json'), 'w') as f:
        json.dump(meta, f, indent=1)
    for f in (bnk, bnl):
        if len(f) > 32600:
            raise BuildError('a file of %d bytes: over 32K (OV_2)' % len(f))
    return text, crc


def psion_folder(opk, folder):
    """The pack's files as .OB3 procedures for RPLOAD (a real Organiser through a Comms Link)."""
    import shutil
    import subprocess
    tools = os.path.join(ROOT, '..', '..', 'Tools')
    tmp = folder + '_tmp'
    if os.path.isdir(tmp):
        shutil.rmtree(tmp)
    subprocess.run([sys.executable, os.path.join(tools, 'opk2files.py'), '-o', tmp, opk], check=True, capture_output=True)
    for f in os.listdir(tmp):
        if f.lower().endswith('.opl'):
            os.remove(os.path.join(tmp, f))
    subprocess.run([sys.executable, os.path.join(tools, 'mkrpdata.py'), tmp, '--title', 'BIGNUM', '--run', 'BIGNUM'],
                   check=True, capture_output=True)
    os.makedirs(folder, exist_ok=True)
    for f in os.listdir(tmp):
        shutil.copyfile(os.path.join(tmp, f), os.path.join(folder, f))
    shutil.rmtree(tmp)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=None)
    ap.add_argument('--pad', type=int, default=0)
    ap.add_argument('--psion', action='store_true')
    ap.add_argument('--ver', default=None)      # (a test: a build with another number)
    a = ap.parse_args()
    global VERSION
    VERSION = a.ver or VERSION
    out = os.path.abspath(a.out) if a.out else os.path.join(ROOT, 'build', 'game')
    os.makedirs(out, exist_ok=True)
    try:
        text = build(out, a.pad)[0]
    except (BuildError, pack.opl2opk.PackError) as e:
        sys.exit('build failed: %s' % e)
    print(text)
    if a.psion:
        psion_folder(os.path.join(out, 'BIGNUM.opk'), os.path.join(ROOT, 'psion'))
        print('psion/: the files for RPLOAD')


if __name__ == '__main__':
    main()
