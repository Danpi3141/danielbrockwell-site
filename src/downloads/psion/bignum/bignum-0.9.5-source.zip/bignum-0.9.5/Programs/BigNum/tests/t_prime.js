// Primality: the base-2 and extra strong Lucas tests by themselves against a JS model (every odd number in
// some ranges, all the base-2 pseudoprimes and extra strong Lucas pseudoprimes below 1,000,000), ISPRIME on
// random and awkward numbers, NEXTPRIME, PREVPRIME, LLT.
//   node tests/t_prime.js [model] [seed] [--quick]
'use strict';
const { BN, rng } = require('./lib');
const model = process.argv[2] || 'lz64';
const R = rng(+process.argv[3] || 1);
const quick = process.argv.includes('--quick');
const g = new BN(model).start();
let fails = 0, n = 0;
const fail = (s) => { console.log('FAIL', s); if (++fails > 12) process.exit(1); };
const mod = (a, m) => ((a % m) + m) % m;
const powm = (b, e, m) => { let r = 1n % m; b = mod(b, m); while (e) { if (e & 1n) r = r * b % m; b = b * b % m; e >>= 1n; } return r; };
const jac = (a, m) => { a = mod(a, m); let t = 1; while (a) { while (!(a & 1n)) { a >>= 1n; const r = m & 7n; if (r === 3n || r === 5n) t = -t; } [a, m] = [m, a]; if ((a & 3n) === 3n && (m & 3n) === 3n) t = -t; a %= m; } return m === 1n ? t : 0; };
function sprp2(v) { let d = v - 1n, s = 0; while (!(d & 1n)) { d >>= 1n; s++; } let x = powm(2n, d, v); if (x === 1n || x === v - 1n) return true; while (--s > 0) { x = x * x % v; if (x === v - 1n) return true; } return false; }
function isSq(v) { let x = BigInt(Math.floor(Math.sqrt(Number(v)))); while (x * x > v) x--; while ((x + 1n) * (x + 1n) <= v) x++; return x * x === v; }
// the extra strong Lucas test as Grantham's 2000 paper, theorem 2.3; Q = 1, P from 3 until (P*P-4 | n) = -1
function xslprp(v) {
  let P = 3n;
  for (;;) { const j = jac(P * P - 4n, v); if (j === 0) return false; if (j === -1) break; if (P === 12n && isSq(v)) return false; P++; }
  let d = v + 1n, s = 0; while (!(d & 1n)) { d >>= 1n; s++; }
  // U, V by the definition (matrix doubling)
  let U = 0n, V = 2n; const D = P * P - 4n, half = (x) => { x = mod(x, v); return x & 1n ? (x + v) >> 1n : x >> 1n; };
  for (const b of d.toString(2)) { U = U * V % v; V = mod(V * V - 2n, v); if (b === '1') { const u2 = half(P * U + V); V = half(D * U + P * V); U = u2; } }
  if (U === 0n && (V === 2n % v || V === v - 2n)) return true;
  for (let r = 0; r <= s - 2; r++) { if (V === 0n) return true; V = mod(V * V - 2n, v); }
  return false;
}
const prime = (v) => { if (v < 2n) return false; for (const p of [2n, 3n, 5n, 7n, 11n, 13n, 17n, 19n, 23n, 29n, 31n, 37n]) if (v % p === 0n) return v === p; let d = v - 1n, s = 0; while (!(d & 1n)) { d >>= 1n; s++; }
  next: for (const a of [2n, 3n, 5n, 7n, 11n, 13n, 17n, 19n, 23n, 29n, 31n, 37n]) { let x = powm(a, d, v); if (x === 1n || x === v - 1n) continue; for (let i = 1; i < s; i++) { x = x * x % v; if (x === v - 1n) continue next; } return false; } return true; };
const OV = (o) => g.meta.ovl.indexOf(o) + 1;
const raw = (o, e, v) => { n++; g.clear(); g.push(v); g.call('ov_call', { a: OV(o), b: e }); return g.peek('kv_pk') !== 0; };
// ---- the tests by themselves
const psp = [], lps = [];
for (let i = 3; i < (quick ? 100000 : 1000000); i += 2) { const v = BigInt(i); const p = i < 1000 ? prime(v) : prime(v); if (p) continue; if (sprp2(v)) psp.push(v); if (i > 100 && xslprp(v)) lps.push(v); }
console.log(`strong base-2 pseudoprimes: ${psp.length} (${psp.slice(0, 5)}), extra strong Lucas pseudoprimes: ${lps.length} (${lps.slice(0, 6)})`);
if (psp.slice(0, 5).join() !== '2047,3277,4033,4681,8321') fail('the model: base 2');
if (lps.slice(0, 8).join() !== '989,3239,5777,10877,27971,29681,30739,31631') fail('the model: Lucas (OEIS A217719)');
for (const v of psp) { if (!raw('ov_base2', 1, v)) fail(`base 2 of ${v}`); if (raw('ov_lucp', 0, v) !== xslprp(v)) fail(`Lucas of ${v}`); }
for (const v of lps) { if (!raw('ov_lucp', 0, v)) fail(`Lucas of ${v}`); if (raw('ov_base2', 1, v) !== sprp2(v)) fail(`base 2 of ${v}`); if (sprp2(v)) fail(`${v} passes both`); }
const some = (lo, k) => { for (let v = lo | 1n, c = 0; c < k; c++, v += 2n) { if (raw('ov_base2', 1, v) !== sprp2(v)) fail(`base 2 of ${v}`); if (raw('ov_lucp', 0, v) !== xslprp(v)) fail(`Lucas of ${v}: want ${xslprp(v)}`); } };
some(10001n, quick ? 30 : 200); some(1n << 32n, 20); some((1n << 64n) - 20n, 20); some((1n << 128n) - 30n, 15); some(10n ** 30n + 40n, 12);
for (const k of [8, 13, 31, 61, 89, 107, 127, 192, 200, 256]) { const v = (1n << BigInt(k)) - 1n; if (v < 10000n) continue; if (raw('ov_lucp', 0, v) !== xslprp(v)) fail(`Lucas of 2**${k}-1`); if (raw('ov_base2', 1, v) !== sprp2(v)) fail(`base 2 of 2**${k}-1`); const w = (1n << BigInt(k)) + 1n; if (raw('ov_lucp', 0, w) !== xslprp(w)) fail(`Lucas of 2**${k}+1`); if (raw('ov_base2', 1, w) !== sprp2(w)) fail(`base 2 of 2**${k}+1`); }
for (let i = 0; i < (quick ? 10 : 60); i++) { const b = 20 + R.int(180); let v = R.bits(b) | 1n | (1n << BigInt(b - 1)); if (R.int(2)) while (!prime(v)) v += 2n; if (raw('ov_lucp', 0, v) !== xslprp(v)) fail(`Lucas of ${v}`); if (raw('ov_base2', 1, v) !== sprp2(v)) fail(`base 2 of ${v}`); }
for (const r of [101n, 65537n, 10n ** 9n + 7n, 10n ** 20n + 39n]) if (raw('ov_lucp', 0, r * r)) fail(`Lucas of ${r} squared`); else if (g.peek('kv_pw') !== 4) fail(`${r} squared not seen as a square`);
g.back();
// ---- ISPRIME
const line = (t) => { n++; return g.line(t, 100000); };
const isp = (v) => { const r = line(`ISPRIME(${v})`); const want = prime(v) ? 1n : 0n; if (r.err || r.val !== want) fail(`ISPRIME(${v}): ${r.err} ${r.val}`); if (want && g.peek('kv_pk') !== (v < (1n << 64n) ? 1 : 2)) fail(`ISPRIME(${v}): kind ${g.peek('kv_pk')}`); };
for (let i = -3; i < 40; i++) isp(BigInt(i));
for (const v of [561n, 1105n, 1729n, 2047n, 3277n, 3215031751n, 3825123056546413051n, 997n * 1009n, 9973n * 9973n, 9973n * 10007n, 10007n * 10009n, 99999989n, 100000007n, 100000000n - 1n, (1n << 64n) - 59n, (1n << 64n) + 13n, 2n ** 61n - 1n, 2n ** 89n - 1n, 341550071728321n, 10n ** 50n + 151n]) isp(v);
for (let i = 0; i < (quick ? 10 : 40); i++) { const b = 4 + R.int(120); let v = R.bits(b) | 1n; if (R.int(2)) while (!prime(v)) v += 2n; isp(v); }
// ---- NEXTPRIME, PREVPRIME
const next = (v) => { v = v < 2n ? 2n : v + 1n; while (!prime(v)) v++; return v; }, prev = (v) => { v--; while (!prime(v)) v--; return v; };
const chk = (t, w) => { const r = line(t); if (r.err || r.val !== w) fail(`${t}: ${r.err} ${r.val} want ${w}`); else if (/10\*\*/.test(t)) console.log(`  ${t}: ${(r.cycles / 921600).toFixed(1)} s`); };
const bad = (t, e) => { const r = line(t); if (r.err !== e) fail(`${t}: error ${r.err} ${r.val}`); };
for (const v of [-5n, 0n, 1n, 2n, 3n, 4n, 13n, 113n, 1327n, 9972n, 10006n, 31397n, 65520n, 65521n, 65536n, 99999988n, 370261n, 20831323n]) { chk(`NEXTPRIME(${v})`, next(v)); if (v > 2n) chk(`PREVPRIME(${v})`, prev(v)); }
bad('PREVPRIME(2)', 5); bad('PREVPRIME(-1)', 5); chk('PREVPRIME(3)', 2n);
chk('NEXTPRIME(10**20)', 100000000000000000039n); chk('NEXTPRIME(10**30)', 1000000000000000000000000000057n); chk('PREVPRIME(10**30)', prev(10n ** 30n)); chk('NEXTPRIME(2**64-60)', next(2n ** 64n - 60n)); chk('NEXTPRIME(1425172824437699411)', next(1425172824437699411n)); chk('PREVPRIME(1425172824437700887)', prev(1425172824437700887n));
for (let i = 0; i < (quick ? 4 : 12); i++) { const v = R.bits(17 + R.int(90)) + 65536n; chk(`NEXTPRIME(${v})`, next(v)); chk(`PREVPRIME(${v})`, prev(v)); }
// ---- LLT
for (const p of [1, 2, 3, 4, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 61, 67, 89, 91, 107, 127, 131, 257].concat(quick ? [] : [521, 607, 1279])) { const r = line(`LLT(${p})`); const w = [2, 3, 5, 7, 13, 17, 19, 31, 61, 89, 107, 127, 521, 607, 1279].includes(p) ? 1n : 0n; if (r.err || r.val !== w) fail(`LLT(${p}): ${r.err} ${r.val}`); else if (p > 500) console.log(`  LLT(${p}): ${(r.cycles / 921600).toFixed(1)} s`); }
bad('LLT(0)', 5); bad('LLT(-7)', 5); bad('LLT(9973)', 2);
console.log(fails ? `${fails} FAILED` : `t_prime ${model} ok (${n} checks)`);
process.exit(fails ? 1 : 0);
