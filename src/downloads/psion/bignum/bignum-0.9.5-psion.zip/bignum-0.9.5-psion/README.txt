BigNum 0.9.5 for the Psion Organiser II (CM (reduced), XP, LA (XP 32K), LZ and LZ64)
MIT licence: see LICENSE.

These are the program's files, ready for an Organiser: translated procedures (.OB3)
and the loader that copies them onto a pack over a Comms Link.

Loading them
  1. Unzip this folder on the PC.
  2. In Psi2Win, set Folder to this folder and click Start!.
  3. If RPBOOT is not on the Organiser yet: COMMS > RECEIVE > PROCEDURE, type RPBOOT,
     EXE. Then PROG > EDIT RPBOOT, MODE > TRAN.
  4. PROG > RUN RPBOOT. Choose the pack to copy the program to (B: or C: is best) and
     wait until it says NOW RUN B:BIGNUM (or whichever pack you chose).
  5. PROG > RUN BIGNUM on that pack.
  RPBOOT uses RPLOAD on an LZ or LZ64 and RPLOADCM on a CM, XP or LA. Delete A:RPLOAD
  afterwards to free its memory.

Files
  BIGNUM.ob3
  BNK.ob3
  BNL.ob3
  RPBOOT.OPL
  RPDATA.ODB
  RPLOAD.OB3
  RPLOADCM.OB3

More: https://danielbrockwell.uk/psion/getting-started/
