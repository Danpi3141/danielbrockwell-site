# Screens, game layer and build: report

Everything except the engine: the launcher and kernel, the screens, the game rules around the
engine, saving, the book reader, the king-and-pawn slices, the build and the delivery folder.
It is standalone: launcher, kernel and tools were copied from Drakeloft's and adapted, and
nothing outside `Programs/Chess` is used at run time.

## What is built

**Layout.** One OPL array holds the kernel and engine (code, tables, variables), then slot A,
then the transposition table. Slot A holds one overlay screen at a time and, while the engine
works, the engine's scratch (`ENG_SCRATCH_EXT`): every engine call may overwrite it, so the
kernel copies `e_lm` after `eng_legal` and reloads the overlay it needs after any engine call.
Only the code that must run while the engine thinks is resident: the main loop, the engine
calls, `think_poll` (depth and seconds in the strip, any key stops), the screen driver, keys,
sound, the pack reader. Overlays: OV_BOARD (drawing, move entry, blinking, clocks), OV_GAME
(save file, book reader, notation, the move's facts, the checking piece), OV_MENU, OV_SET,
OV_LIST, OV_RESULT, OV_SETUP.

**Board screen.** The default layout puts four ranks in letters (capitals White, lower case
Black, the diamond 250 on empty dark squares, rank numbers in column 9), the last move in the
strip (who / where / what happened, short parts one column in, the turn or the clock on row 4)
and the 8-glyph map of all 64 squares. The split board and real-board mode are settings. The
letter view follows the last move or the cursor, MODE flips it, and the board turns when you
play Black.

**Move entry.** Typed (E2E4 without SHIFT), pointing (arrows and EXE), and stepping through a
picked piece's legal squares. Promotion asks Q R B N (EXE = queen). Illegal entries buzz and give
a reason on row 4 (NOT YOUR PIECE, THAT PIECE CANNOT MOVE, YOUR OWN PIECE IS THERE, ILLEGAL:
IN CHECK, ILLEGAL: BLOCKED) and keep what was typed, so only the last square needs retyping.
The last move, its square and any checking piece blink (about a second for the computer's
move, half that for yours; a key stops it).

**Game.** Levels 1–8 (1, 1, 2, 3, 3, 10, 30, 255 s; levels 1–4 pass evaluation noise
k = 100, 53, 25, 14 to the engine; until 17 Nov the margins 300, 150, 70, 30) and Auto; clocks with all the presets and custom (each side's minutes and
increment), increments, flag fall, levels capped by the clock, an even share of the clock with
the natural pace (book moves in 2–4 s, others half to one and a half shares); the book (one
pointer into data/book.bin, a random preferred move); take back by replaying from the start;
hint; draw offers (accepted when the engine judges itself level or worse); resigning (the
player, and the engine after 3 moves in a row below −9 pawns, switchable); results for mate,
stalemate, 50 moves, repetition, too little material, resignation, time, agreement, a full record;
the move list (four moves a screen); game review (below); set-up with the engine checking the position; two-player
mode; sound (blip, check, end phrase, buzz, clock tick; all / blips / off).

**King and pawn against king** (since 16 Nov). The computer's move and the hint come from a
distance table (`tools/kpk/kpkd.js`: for each position with the pawn's side to move, its moves to
a safe promotion, 0 for a draw; 48K), stored compressed on the pack (`data/kpkdz.bin`, 11,930
bytes in block 2, `tools/kpk/kpkd_pack.js`: 96 blocks of 1,024 entries, each a list of runs in
one canonical Huffman code; positions that can't occur filled to lengthen the runs). The overlay
OV_KPK (`ov_kpk.asm`, reference `ref/kpkroot.js`) decodes a block as it is read from the pack into
one of two 512-byte buffers (2 decodes a decision on average, at most 6; a hint in that ending
takes 0.5-1.5 s in the emulator) and plays at the root only: the pawn's side takes the move whose position needs fewest moves to
promote (looking one ply further, at the defender's replies), the defender the first move that
keeps the draw or else the slowest loss. No search runs, unless the pawn's side is to move in a
draw. Nothing is lent from the TT any more. (Before: the old 24K win/draw table's slices were
copied into the TT's RAM and used in the search, which still missed wins by shuffling.)

**Game review** (19 Nov, `src/screens/ov_review.asm`, the kernel's `review` in `kcore.asm`,
test `tests/ui/t_review.js`). The overlay does the keys, the text and the snapshots; the kernel
loop does what needs the engine (its scratch is slot A): set up a snapshot (`eng_setup`), play the
record's plies to the ply shown (`rp_loop`, the replay's loop, which a step enters at a snapshot),
the strip, the board. While reviewing, `g_n` is the ply shown (the game's own is kept and put
back). Snapshots: at each record chunk's first ply (0, 10, 20 ...), 35 bytes (the board 4 bits a
square, castling and side, en passant, half-moves), 25 of them after 5 bytes of state, in the
transposition table's RAM from `TTBASE`: 880 bytes, which the build checks fit the 128-entry table
and, beside a 128-entry table, the 256-entry one. Entering replays the game once, keeping them
(the replay's `RVF_SNAP`); a step reads no file when its chunk is the one in `rp_buf`
(`RVF_HELD`) and works out only whether the side is in check (`RVF_STEP`; the legal moves and the
status come back when review ends). Analysis is `look2` with the table above the snapshots at
half its size; play-from-here is a take back to the ply (replay, clocks from the record, save).
Measured in the emulator: 53 plies entered in 3.9 s, a step 0.35 s (0.8 s at a new chunk), leaving
3.3 s, analysis 4.6 s in the 25...Rd2 position (2 s and the fail-low extension). Cost: 152 bytes of
kernel code and 1 variable (`rv_on`); the overlay is 1,060 bytes on the pack.

**Saving.** `A:CHESSAV` holds the settings and the whole game record, and is the only copy of the
record (RAM keeps the last move). It has a fixed size: 25 chunk records of 10 plies and a header
with a checksum, each replaced by erasing it and writing it again. On the LZ64 the file does not
reduce FREE (A: is in the other RAM banks: measured). Each record also keeps the mover's clock after
the move, so take back restores both clocks. If A: has no room for the file (the banks and the
main RAM full), the game says CANNOT SAVE: NO ROOM and goes on unsaved, without take back.

**Switching off.** The Organiser switches itself off after its usual idle time while it waits for
you. That is done by the game (BT$SWOF), because the OS would restore its own copy of the screen,
not the board; switching on brings the board back. Auto-off is held off while it thinks and while
a clock runs. A blinking cursor (a typed square, pointing, set-up) stops blinking after about
77 s so that the Organiser can still switch itself off.

## Tests (all pass: `node tests/ui/run_all.js`; the audit's tests are described in [audit-ui.md](audit-ui.md))

| File | What it checks |
|---|---|
| t_ui | the board as text and glyphs, a refused square, a typed move and the reply, take back, pointing, the menu (and its wrap round), the split layout, save, leave and resume |
| t_game | fool's mate and the result screen, the strip's notation (Q h4 #), take back after mate, an under-promotion with capture (a xb8 =N), disambiguation (Nfd2), level 1 thinking and moving |
| t_feat | a book reply without thinking, hint, the move list, a draw offer, resigning, a 5\|5 clock running, the increment, flag fall |
| t_setup | a refused set-up and its reason, cancelling, a K+P v K set-up, the computer answering it from the distance table (the reference's move), the TT keeping its size |
| t_kpkd | 40 random and critical K+P v K positions and two rook promotions: the computer's move or the hint is ref/kpkroot.js's every time (`node tests/ui/t_kpkd.js [n]`, not in run_all) |
| t_real | real-board mode: the move in words, the typed reply, both clocks |
| t_off | auto switch-off while waiting, ON, the board back, the game goes on |
| t_sound | the blip after the engine's move, the low buzz |
| t_mem | the TT size the launcher gets on an empty LZ64, before and after the save file exists |
| t_auto | the Auto level: up after a win (mate, the computer resigning), down after a loss (resigning, on time), not after a draw, within 1-8; choosing it starts from the level in force (17 Nov) |
| t_flag | a flag falling: a draw when the side with time has only its king, else a win on time (17 Nov) |
| t_resign | the computer's resignation: below -900 - 8k three moves in a row (k = levels 1-4's noise), each edge for every k (17 Nov) |
| t_back, t_notat, t_screen, t_sleep, t_leave | the audit (audit-ui.md): take back, notation, the screen read back, switching off, leaving nothing behind (short forms in run_all) |
| t_clock, t_lowmem, t_soak | the audit's long runs: an hour of clock, low memory, whole games |
| t_review | game review: every ply of a 53-ply game back and forth against the positions when reached, jumps, analysis (and its table at each size), play from here, leaving unchanged, timings |
| t_faillow | the fail-low extension in the game: level 5 plays 25...Rf8 (not Rd2??) in the user's position, within twice the time; the clock's cap |

Also checked once in the browser's Jape (LZ64, `.claude/launch.json` entry `jape-chess`):
launch from B:, 1.e4 answered from the book (…e5), letters, strip and map glyphs on the LCD.

## Budget (build/game/budget.txt)

Updated 16 Nov after the audits and the RAM changes (see *RAM changes, 16 Nov* below).

| RAM (the array) | bytes |
|---|---|
| kernel + engine code and tables | 11,741 (engine about 8,538) |
| variables (kernel + engine; the legal list is 254 of them) | 1,105 |
| slot A (largest screen 2,600, the king-and-pawn overlay; engine scratch 2,536, shared) | 2,600 |
| before the TT | 15,446 |
| TT 512 entries of 7 bytes | 3,584 |
| **array** | **19,030** (19 Nov: game review +153; 18 Nov: the fail-low time extension +203, docs/strength.md s.15; 17 Nov: the second round of engine speed-ups +395, docs/engine.md; memory savings -1,062, the coverage sweep -8, the pack scan by FL$BOPN -71, the loader's fix-up buffer in slot A -18 the key history sized to its bound -28, the ROM's utility routines -144, the start-up code run from the TT's RAM -239, search frames of 43 bytes -40 (the fix-up buffer back in the variables: +18 of that) and two rarely run routines tightened -40, docs/engine.md; the engine speed-ups +147; PGN export and import, the position book's reader, the king-and-pawn distance table, the same-colour bishops draw and the fifty-move mate check); the largest that fits an empty LZ64 is about 21,542 (t_lowmem, 17 Nov: the launcher's overhead is 581) |

CHESS falls back to 256 or 128 entries when there is less free RAM. The draft's figure was about
21K with a 3K table; this is about 20K with a 3.5K table.

**RAM changes, 16 Nov.** Each was made and tested on its own:
1. CHESS's free-RAM check relaxed by 40 bytes (`LAUNCH_OVERHEAD` 520 → 480): t_lowmem had measured
   it 44 bytes stricter than the real limit; 4 bytes kept as margin (2-4 measured since).
2. No 16-byte rounding of the kernel and the screen slot (`align` in build.py): 11 bytes, and
   each byte of code now costs one byte of RAM.
3. 7-byte TT entries (depth and flag share a byte: `depth<<2 | flag`; the index is ×8 − ×1):
   −512 bytes of table, +9 of code. The search is unchanged (node-for-node parity holds).
   The king-and-pawn ending lends the table as 64 entries + slices, as 128 + slices no longer
   fits a 256-entry table.
4. Legal-move list 80 → 127 (`LM_MAX`): +94 bytes. The 127-move limit is the most an 8-bit
   doubled index allows; a position with more legal moves keeps the first 127 (t_many).
5. Zobrist keys from one key a square, rotated by piece type (77 keys, 231 bytes, not 397 and
   1,191): −944 bytes; about 1.5% slower; −4 to −14 Elo measured, all intervals including 0
   (docs/strength.md section 9). Symmetric piece-square tables (−310 bytes) were measured too and
   dropped: about −30 Elo.
- Looked at and not done: dead kernel code (a coverage run of the whole UI suite, `tools/cover/`,
  found none: the resident kernel is ~3.4K, the Drakeloft board/game code is already in overlays);
  moving engine-calling routines into overlays (unsafe: the engine's scratch is the overlay slot);
  moving "DRAW DECLINED" out (~12 bytes at best); rook-on-open-file and king-shield terms
  (prototyped in JS: rook file +17 at equal nodes but +1 with a 5% speed cost, king shield −11;
  docs/strength.md).

| Pack (256K Flashpak) | bytes |
|---|---|
| kernel + engine | 13,732 |
| screens (10 overlays) | 16,537 |
| opening book (the position book, 16 Nov) | 15,363 |
| king-and-pawn distance table (compressed) | 11,930 |
| launchers and records | 3,705 |
| **total** | **61,267** of the 256K budget |

**The launcher (17 Nov).** The bootstrap that CHGn pokes into the array and runs (src/launch/boot.asm)
now finds CHK with the OS's FL$BOPN (open a block file by name: `B:CHK`, then `C:`, then `A:`;
the pack address is left at its data) instead of reading the packs' directories itself: 151 bytes,
was 253, and three poke loops, was four. The free RAM the game needs to start falls by 152 bytes:
the launcher's overhead is 581 bytes beyond the array, was 733 (`LAUNCH_OVERHEAD` 480 -> 430, again
measured by t_lowmem to 4 bytes of the real limit). The 512-entry table now needs 19,440 free
(was 19,592). Tested: from B: (every UI test), from C:, falling back from B: to C:, and "GAME FILES
NOT FOUND" with CHK missing; from A: not tested (the files can't be put there in the emulator).
FL$FFND, also looked at, only matches names by prefix on the current device and does not give the
file's data. Each launcher is 152 bytes smaller on the pack, `psion/` 456 bytes smaller.

**The kernel's pack scan (17 Nov)** (`pk_scan`, run once at start to find CHB0..CHB3 on the device the
kernel came from) now asks FL$BOPN for each block ("B:CHB0"...) instead of walking the device's
records: -71 bytes of resident code (`pk_adv` went too), so -71 RAM and 19,369 free needed for the
512-entry table. Tested: the block addresses equal the pack image's, from B: and C:, CHB0 missing
("GAME FILES DAMAGED"), CHB1 missing (the game runs without the book), and the whole UI suite.

**Variable lifetimes (17 Nov).** Every kernel variable was mapped to the files (and so the overlays)
that use it. Nine bytes' worth are used by one overlay only, but none can move into it: an overlay's
own variables last only one call (every engine call reuses the slot, `ecall` clears `kv_res`, and
the next call reloads the overlay from the pack), and these must last longer: the cursor square
(across a hint), the import's file and record (across the engine playing each move), the book flag
(the whole game), the save header (`gs_ver`, `gs_len`, `gs_sum`: written as one block) and the
increments (saved; the board overlay reads them at g_clk+4). Two moves by lifetime were looked at:
the screens' legal list (254 bytes) in the TT's first 36 entries during the player's turn measured
0 Elo at 512 entries but -6 [-10, -1] at 128, so it was left; the overlay loader's fix-up buffer
(`kv_fix`, `kv_fo`, 18 bytes, used only inside `ov_load`) now lives in slot A's last 18 bytes, which
the build keeps free of overlay code (`FIXBUF`): -18 RAM, 19,351 free needed for the 512-entry table.

**The ROM's utility routines (17 Nov).** The kernel's own number and copy routines gave way to the
ROM's (docs: jaapsch.net/psion/tech13.htm), each checked in the emulator first (results, the zero
page it uses: UTW_S0..S4 = $41-$4A, which no kernel or screen code keeps anything in; and cycles):
`num_str` -> UT$UTOB (229-1,000 cycles; ours 278-973), `udiv` -> UT$UDIV (about 800 either way;
it never returns for a 0 divisor: every caller divides by a constant or by 10..40), the legal
list's copy in `pos_update` -> UT$CPYB (3,346 cycles for 254 bytes, our loop about 7,600), the
fills in `scr_cls`, `set_defaults` and `spos_copy` -> UT$FILL, and the overlays' `mul16` ->
UT$UMUL (316 cycles; ours about 70, used only by the random numbers and the clock's set-up).
-144 bytes of kernel (RAM), -108 in the overlays (pack only). The engine calls none of them; the
speed test's 1,000-position search through the kernel (34 depth and time displays) took
8,990,400 cycles against 8,988,219 before: 2.4 ms more in 9.75 s (0.02%). 19,179 free needed for
the 512-entry table. `mul16x` (saturating) stays ours.

**Start-up code in the TT's RAM (17 Nov).** The kernel's start-up (setting up the machine, finding
the blocks, sizing the TT: 239 bytes, `src/kernel/kinit.asm`) is assembled at the TT's base and
stored after the kernel's code; the bootstrap loads and relocates it with the kernel, the kernel's
entry copies it up (UT$CPYB), it runs there once and comes back to `kinit_done`, where `eng_init`
clears the table. The build checks it fits the smallest table (896 bytes) and can't overlap it
while copied. Tested: starts from B: and C:, the missing-file and missing-block messages, every
TT size (t_lowmem), and the table all zero after start-up.

**Search frames and slot A (17 Nov).** The frame's fields only the switched-off searches use
(`F_NUL`, `F_PV`: null move; `F_MS`: LMR, its store now under E_LMR; `F_RED`: PVS) and a gap went
to the end and count only when switched on: 43 bytes a frame, was 48; the engine's scratch is
2,527 and slot A is now the king-and-pawn overlay's 2,600 (was 2,652). The overlay loader's 18-byte
fix-up buffer went back into the kernel's variables: in slot A's last 18 bytes (the earlier
saving) a take back to the start of a clock game came out wrong (the clock's minute tick and 32
frames charged; t_back) once the slot shrank to 2,600, for a reason not found, so it was undone.
Moving the king-and-pawn overlay's two 512-byte buffers into the TT was not done: at 128 entries
the TT has only 896 bytes.

**Two rarely run routines (17 Nov):** `do_menu` dispatches by a jump table (was a compare for each
command; -26), `msg_set` fills and copies with UT$FILL and UT$CPYB (-14). `strip_cells`, which
the search's depth display calls, was left as it is.

## Deviations from the draft

- Real-board mode is a third value of the BOARD setting rather than a separate screen.
- In the default layout the half shown is told by the rank numbers; the arrows 169/170 aren't used.
- The clock in the strip is minutes rounded up (5', 4') and seconds under a minute (45"),
  since the strip has three columns; real-board mode shows both clocks as mm:ss.
- The game record is kept in the save file, not RAM (saves 750 bytes of RAM); the screens keep
  at most 127 legal moves (a position with more keeps the first 127; real games stay far below).
  The list was 64 at first, then 80, and 127 since the 7-byte TT entries freed RAM (16 Nov).
- Take back replays the game from the start (about a second per 10 moves).
- The set-up screen gives castling rights from where kings and rooks stand, and no en passant.
- Each move costs about 1 s of overlay and file work besides the blinks: 15 overlay loads at
  about 36 ms each, and about 0.17 s per legal-move update.

## What's left

- Phase 4 items not built: saved games by name (10), blunder check, thinking on your time (the
  settings for these two aren't shown), opening names. Sending a game to the PC as PGN was added on
  16 Nov: the menu's EXPORT PGN, in the move list's overlay (entry 1, about 1,500 bytes of pack;
  11 bytes of resident kernel for the menu's dispatch); test `tests/ui/t_pgn.js`. And IMPORT GAME:
  a new overlay OV_IMPORT (1,384 bytes: the chooser, reading `A:GAMEn` made by
  `tools/pgn2psion.py`) and a resident loop `im_game` that plays each move as a typed one (the
  engine's scratch is the overlay slot, so the overlay gives one move a call); while importing the
  record is saved a chunk at a time from a copy in the TT's RAM (`sv_bulk`), which cut a 28-ply
  import from 46 to 20 s. Resident cost about 200 bytes (code 12,486, variables 1,205); test
  `tests/ui/t_import.js`.
- The draft's empty-map marks (158/46) for the dark square of a cell are not drawn.
- Milestone 7 needs the real Organiser: true speed, whether hollow and solid map blocks can be
  told apart on the LCD, the pack read speed (overlay loads), and a battery test. The list is
  [hardware-test-plan.md](hardware-test-plan.md); the menu's SPEED TEST (now off: `SPEEDTEST = 0` in
  `src/defs.inc`; test `tests/ui/t_speedtest.js`) gave on the Organiser what the emulator gives:
  98 positions a second, 15 ms an overlay load and a book look-up.
- The array is about 2,510 bytes inside the measured limit (19 Nov, after game review); past it CHESS drops the TT to
  256 entries automatically.
