# Chess for the Psion Organiser II LZ64

A chess game for the LZ64, built from *Chess for the Psion LZ64: design draft* (15 Nov 2026).
The engine is 6303 assembler matched node for node against a JavaScript reference engine
([docs/engine.md](docs/engine.md)); its strength is measured in [docs/strength.md](docs/strength.md).
The screens, the game layer and the build are described in [docs/ui-report.md](docs/ui-report.md).

## Status (16 Nov 2026, afternoon)

- **Milestones 0-6:** done, in the emulator.
  - **Engine:** matches the reference node for node.
  - **Book:** a position book (16 Nov): 4,887 positions where the Psion is to move, 15.4K, found by the position's key, so transpositions are recognised; as White the Psion's 6th move is still from the book in 59% of games against club players (the tree book: 16%), as Black 29% (5%). Levels 1-4 use it for the computer's first n moves only (n = the level).
  - **King and pawn v king:** played perfectly from a distance table on the pack (48K, compressed to 12K), at the root (no search).
  - **Game:** the board screen with its map, all three ways to enter moves, levels, clocks, take back, hint, save and resume, move list, set-up, real-board mode, two-player mode and sound.
- **Audited (16 Nov)** against a checklist of book, rules, engine, endgame, screen, clock and Organiser checks: see [docs/test-audit.md](docs/test-audit.md). The audits fixed 10 screen/kernel bugs, 8 engine problems and the book's exits.
- **Strength:** about 1680 at 30 s a move (level 7) on Stockfish's limited-strength scale; levels 1-8 (1, 1, 2, 3, 3, 10, 30 and 255 s a move) measured at about 450, 650, 950, 1200, 1450, 1550, 1700 and 1950 with the book (the level menu shows these; docs/strength.md sections 11-12).
  - The engine searches ~70-100 positions a second, not the guessed 150-300.
- **Size:** 54.7K of the 256K pack budget. With a 512-entry table the game takes 17,744 bytes and needs 18,120 free at the menu (19,566 until the save file exists), 4,118 less than an empty LZ64 has (until 24 Nov: 60K, a 19,030-byte array, 19,744 free). How: *Memory savings, 24 November* in docs/ui-report.md.
- **Coverage sweep (17 Nov):** the table's score cut-offs had hardly ever been taken (a PVS-only test); now at every node except with a bare king (where they cost bishop-and-knight mates): +2, +9, +8 Elo at levels 5, 7, 8, for 19 bytes. `eng_find` (never called) removed; the Auto level now also moves after the computer resigns and after a loss on time, and starts from the level you had; a flag falling against a bare king is a draw (docs/engine.md, *Coverage sweep*).
- **Memory savings (17 Nov):** 1,062 bytes of RAM and 985 of pack: a smaller castling generator, the null move removed (it was never tried with plain alpha-beta), levels 1-4 weakened by evaluation noise instead of a second search, and a smaller shared screen/engine slot. No strength lost: levels 5-8 play the same moves, levels 1-4 measured within +1 to +14 Elo of before (docs/engine.md, *Memory savings*; docs/strength.md section 13).
- **Engine speed-ups (17 Nov):** the same search, about 7% faster (the moving piece's totals updated by the difference only; the parent frame kept in a variable): 147 bytes of RAM, worth about +8 Elo at levels 5-8 by the node-count slope (too small for a match to show). See docs/engine.md, *Speed-ups*.
- **Rules added 16 Nov:** bishops only, all on squares of one colour (any number, either side), is a draw by too little material; a mate given on the 100th half-move counts as mate, not a fifty-move draw (both engines; `tests/engine/t_fifty.js`).
- **Real Organiser (16 Nov):** a temporary SPEED TEST gave 98 positions a second, an overlay load 15 ms and a book look-up 15 ms, the same as the emulator, so the measured levels hold. A second run (20 Nov) gave 71 positions a second, search 14,000 ms, overlay 20 ms, book 40 ms: the emulator gives 71 and 13,950 ms at ply 30 of the Pgn1 game (the test runs from the position on the board; 49 to 124 across that game, overlay 15 to 20 ms, book 15 to 35 ms), so it still matches. It is now switched off (`SPEEDTEST = 0` in `src/defs.inc`; 1 puts it back). The rest of the checklist: [docs/hardware-test-plan.md](docs/hardware-test-plan.md).
- **PGN export and import (16 Nov):** EXPORT PGN writes the game to `A:PGN1`, `A:PGN2`, ...; IMPORT GAME loads a game converted on the PC by `tools/pgn2psion.py` (see *Exporting a game as PGN* and *Importing games*).
- **Not done:** saved games by name, blunder check, thinking on your time and opening names.
- **Weak spot:** bishop + knight mates succeed in about 80% of random starts.
- **Milestone 7:** needs the real Organiser.

## Build

```bash
python tools/build.py
```

This writes `build/game/CHESS.opk` (a 256K Flashpak image) and `build/game/budget.txt`.
`--engine stub` builds with a stand-in engine (for screen work); the default uses `src/engine`.
The opening book (`data/book.bin`) and the compressed king-and-pawn distance table (`data/kpkdz.bin`) go onto the pack
when they are there.

## Run in the emulator

In Jape choose **LZ64**, load `build/game/CHESS.opk` into slot B, then **Prog → Run → B:CHESS**.
CHESS picks the largest table the free RAM allows: on an empty LZ64 the game takes
17,744 bytes with a 512-entry transposition table. If there is too little RAM it says how
many bytes are missing.

Until the save file `A:CHESSAV` exists, CHESS also keeps room for it (1,445 bytes, `SAVE_RESERVE` in
`tools/build.py`): on the 32K LZ, and on an LZ64 whose other RAM banks are full, the file shares the
game's RAM. Measured at the menu to the byte (24 Nov 2026, the same on the LZ and LZ64): 15,430 bytes free start
the game (unsaved, CANNOT SAVE: NO ROOM), 16,872 play and save with the 128-entry table, 17,774 the
256-entry table and 19,566 the 512-entry table, all saving. Once the save file exists 512 entries need 18,120. Until 22 Nov the launcher kept no room,
so from 19,712 to 21,086 free it chose the 512-entry table and could not save.

## Keys

| On your move | |
|---|---|
| A–H then 1–8 | type the move, e.g. E2E4. No SHIFT: the key under each digit counts (U V W O P Q I J = 1–8). Castling is the king's move (E1G1). |
| Arrows, EXE | point: the arrows move a cursor, EXE picks the piece up; then the arrows step through its legal squares and EXE puts it down |
| DEL | rub out a typed square; with nothing typed, take back your last move and the reply |
| MODE | show the other half of the board |
| SPACE | hint (a 2-second look; "HINT E2E4" on the bottom line) |
| ON/CLEAR | clear what you typed, or open the menu |

While it thinks, any key makes it move now. The menu (UP and DOWN wrap round from the last item to the first) has new game, level, take back, hint, flip
(play the other colour), move list, game review, export as PGN, import a game, set up a position, settings, offer a draw, resign, and save
and leave. Settings: board layout (letters with the map, split board, real-board mode), level 1–8
or Auto, clock (none, 5|5, 10|5, 15|10, 30|30, custom), pace, your colour, move text (standard
notation or plain squares), sound, custom clock minutes and increments, whether it resigns, and a
two-player mode.

The game is saved to `A:CHESSAV` after every move and resumes where it was.

## Game review

**GAME REVIEW** in the menu (G) steps through the game's positions, during a game or after it,
and through imported games.

| Key | |
|---|---|
| RIGHT or EXE | the next move |
| LEFT or DEL | the move before |
| DOWN / UP | ten plies on / back |
| MODE | the other half of the board |
| SPACE | analyse: the engine's best move and score from White's side, e.g. `BEST D8F8 +0.42` (`+M1` = mate in one), a 2-second look |
| P | play on from here: asks `PLAY FROM HERE? EXE`; EXE takes the game back to this position (clocks too) |
| ON/CLEAR | leave review: the game as it was |

The bottom line shows `MOVE 12 OF 31`. Entering reads the game once (about 0.6 s for each 10
plies; `READING THE GAME`), then a step takes about 0.35 s (0.8 s when it reads the next 10
plies from A:). Snapshots of the position every 10 plies are kept in the transposition table's
RAM, which nothing uses while reviewing, so review costs 153 bytes of RAM. Analysis puts a table
of half the size above them (512 entries: 256; 256: 128); with a 128-entry table there is no
room and SPACE says `MORE RAM TO ANALYSE`.

## Exporting a game as PGN

Menu → **EXPORT PGN** writes the game so far to a new data file on A:, `A:PGN1` (then `A:PGN2`, and so
on up to 99; the screen says which). Each record is one line of PGN: the tags Event, Site, Date (the
Organiser's date), Round, White, Black ("Player" or "Psion LZ64 level N") and Result, plus SetUp and
FEN for a game from a set-up position; a blank line (a record holding one space); then the moves in
standard notation, wrapped at 79 characters, ending with the result (`*` while the game goes on).
The move-text setting doesn't matter: the file is always standard notation.

To get it to the PC, send it as a data file with the Comms Link (its COMMS menu, with Psi2Win or
Psion's CL on the PC). A data file travels as text, one line a record, as `RPDATA.ODB` does the
other way, so renaming it to `.pgn` should be all that is needed. (Tested in the emulator only:
Jape has no Comms Link, so the transfer itself still needs trying on the Organiser.)

If A: is too full the file isn't made, or is deleted again ("CANNOT EXPORT: NO ROOM ON A:"), and
if the game itself couldn't be saved there is no record to export ("GAME NOT SAVED").

## Importing games

On the PC, convert PGN games with

```bash
python -E -P tools/pgn2psion.py games.pgn --out import --start 1
```

Each game becomes `GAMEn.ODB` (`--games 1-5,8` picks games from a big PGN). Send them to the
Organiser as data files with the Comms Link, named `A:GAME1` to `A:GAME99` (as `RPDATA.ODB` travels:
plain text, one line a record; or list them for `RPLOAD` with `Tools/mkrpdata.py`).

Menu → **IMPORT GAME** shows the first `A:GAMEn` there is and its title ("Kasparov v Deep Blue
1997"); UP and DOWN go through the others, EXE loads one, ON/CLEAR cancels. Loading replaces the
current game: the moves are played one by one ("IMPORTING", the ply count), about half a second a
ply, so a 40-move game takes about 40 s. Then the game is as if it had been played on the Organiser:
the move list shows it, DEL takes moves back, EXPORT PGN writes it out again, and you take over the
side to move (against the computer, or in two-player mode). A set-up start is kept (the file holds
the position). The record holds 250 plies, so the converter cuts a longer game there and says so.

What a game file holds (one line a record): `CHESSGAME`; the title; `START` or `S` and the
position (64 squares a1..h8, side, castling as a hex digit, en passant, half-move clock); then the
moves as squares (`e2e4 e7e8q`). Messages: NO GAMES TO IMPORT, NOT A GAME FILE: A:GAMEn,
ILLEGAL MOVE IN FILE (the import stops before it), BAD POSITION IN FILE. (Tested in the emulator,
with the files made by an OPL procedure: Jape has no Comms Link.)

## Load onto the Organiser (RPBOOT)

```bash
python tools/psion.py
```

This makes the `psion/` folder: the kernel and data blocks as object-only procedures, the
launcher CHESS, and RPBOOT's `RPDATA.ODB`, `RPBOOT.OPL` and `RPLOAD.OB3`
(see `../../Tools/README.md`). It is about 54.6K in 5 files, so load it onto a pack in B: or C: of
64K or more (Rampak/Flashpak), not A:. In Psi2Win set the folder to `psion`, run `RPBOOT` on
the Organiser, then run `B:CHESS` (or `C:CHESS`). Delete `A:RPLOAD` afterwards to free its RAM.

## Tests

```bash
node tests/ui/run_all.js
```

runs the screen and game tests in a headless LZ64 (`tools/emu.js`, the Jape sources
under Node), including short forms of the UI audit's tests; the audit's long runs (take back,
screen read-back, notation, an hour of clock, switching off, leaving, low memory, soak) and
their results are in [docs/audit-ui.md](docs/audit-ui.md). The engine's own tests are in
`tests/engine` (see [docs/engine.md](docs/engine.md)).

## About this repository

One of the Psion Organiser II projects on Forgejo (`Daniel/Psion-*`). The build and test scripts expect the PsionII workspace layout:

```
PsionII/
  Emulator/          Jape, Jaap Scherphuis's emulator, with its ROM images (not in any repo:
                     https://www.jaapsch.net/psion/jape/jape.htm)
  Tools/             Daniel/Psion-Tools (opltran, opl2opk, RPBOOT/RPLOAD, ...)
  Programs/NAME/     this repository
```

`build/` is not committed: the build scripts recreate it.

Also kept out of the repository (large, downloaded or third-party):

- `ext/lichess/` - the Lichess game database for January 2016 (`lichess_2016-01.pgn.zst`, https://database.lichess.org/).
- `ext/openings/` - the Lichess opening names (https://github.com/lichess-org/chess-openings).
- `ext/stockfish/` - Stockfish for Windows (https://stockfishchess.org/download/), used by the match and audit tools.
- `tools/book/cache/` and `tools/book/audit/cache/` - caches the book tools rebuild from the Lichess file and Stockfish (about 500 MB).
- `tools/match/results/` - the raw match records (about 340 MB); the `tools/match/logs_*.txt` summaries are committed.
