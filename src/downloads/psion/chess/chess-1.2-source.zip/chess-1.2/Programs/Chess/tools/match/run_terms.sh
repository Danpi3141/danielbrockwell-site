#!/bin/sh
# 16 Nov: rook-on-open-file and king-shield prototypes v the audited engine, equal nodes
python -E -P match.py rf_v4_2120 snap_rf:Nodes=2120 snap_v4:Nodes=2120 --openings 0:242 --workers 6 > logs_rf_v4_2120.txt 2>&1 &
python -E -P match.py ks_v4_2120 snap_ks:Nodes=2120 snap_v4:Nodes=2120 --openings 0:242 --workers 6 > logs_ks_v4_2120.txt 2>&1 &
wait
python -E -P analyze.py rf_v4_2120 ks_v4_2120 | grep -v histogram
