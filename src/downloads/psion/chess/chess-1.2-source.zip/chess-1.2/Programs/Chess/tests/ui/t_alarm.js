'use strict';
// An alarm rings during a game (24 Nov): an alarm set in the OS's Alarm screen and one from its diary, while the game
// waits for a move and while it thinks. The OS rings it, shows its own screen and goes back: the game's screen must come
// back as it was, the game must go on, and what the game keeps in memory borrowed from the OS must not have been written
// (by the alarm's code or any interrupt: every write from outside the game and its own ROM calls is logged).
//   node tests/ui/t_alarm.js [rom...]
const fs = require('fs');
const path = require('path');
const L = require('./lib.js');
const G = require('./glib.js');
const { Machine } = require('../../tools/emu.js');
const ROMS = { '42-lz.rom': 32, '45-lz.rom': 32, '46-lz.rom': 32, '43-lz64.rom': 64, '46a-lz64.rom': 64 };
const meta = JSON.parse(fs.readFileSync(path.join(L.BUILD, 'build.json'), 'utf8'));
let fails = 0;
function ok(c, msg) { if (!c) { fails++; console.log('FAIL ' + msg); } else console.log('ok   ' + msg); }
// ZP1 ($4D-$5A) is not here: the OS uses it and puts it back, which the game going on shows
const AREAS = [['ZP3', 0x7F, 0x8B], ['ZP2', 0xCC, 0xE1], ['ZP2', 0xE2, 0xF6], ['RTT_BF', 0x2188, 0x2288], ['ZSAVE', 0x2292, 0x22C8], ['MENUBUF', 0x2513, 0x25DC]];

function clock(m, t) {
  m.poke(0x5B, 1);
  for (let i = 0; i < 40 && m.peek(0x5B); i++) m.runSeconds(0.02);
  m.write(0x20C5, t);
}
function off(m) { for (let i = 0; i < 5; i++) m.press('ON', 3, 10); }
for (const rom of process.argv.slice(2).length ? process.argv.slice(2) : Object.keys(ROMS)) {
  for (const kind of ['alarm', 'diary']) {
    for (const phase of ['waiting', 'thinking']) {
      const tag = `${rom} ${kind} ${phase}:`;
      try {
        const m = new Machine({ rom, ram: ROMS[rom] });
        m.boot();
        if (kind === 'alarm') {                          // the first free alarm: Sunday 12:00 am
          m.press('A', 3, 12); m.runSeconds(1);
          for (let i = 0; i < 3; i++) { m.press('EXE', 3, 12); m.runSeconds(0.3); }
          off(m);
          clock(m, [126, 10, 27, 23, 59, phase === 'waiting' ? 46 : 36]);      // Saturday 28 November 2026
        } else {                                         // a diary entry at 10:45 pm today, its alarm 15 minutes before
          clock(m, [126, 10, 27, 22, 20, 0]); m.runSeconds(1);
          m.press('D', 3, 12); m.runSeconds(1);
          for (let i = 0; i < 2; i++) { m.press('EXE', 3, 12); m.runSeconds(1); }
          m.type('TEST', 3, 3);
          for (let i = 0; i < 2; i++) { m.press('EXE', 3, 12); m.runSeconds(1); }
          m.press('MODE', 3, 12); m.press('A', 3, 12); m.runSeconds(0.7);
          const t = m.screenText();
          m.press('EXE', 3, 12); m.runSeconds(0.7);
          if (!/Alarm/.test(t)) throw new Error('no diary alarm: ' + t);
          off(m); m.runSeconds(1);
          // the entry's time is the diary's next quarter: ring 15 minutes before it
          const e = /(\d+):(\d\d)([ap]).TEST/.exec(t) || /(\d+):(\d\d)([ap]) TEST/.exec(t);
          let mins = (+e[1] % 12) * 60 + +e[2] + (e[3] === 'p' ? 720 : 0) - 15 - 1;
          clock(m, [126, 10, 27, Math.floor(mins / 60), mins % 60, phase === 'waiting' ? 46 : 36]);
        }
        for (let i = 0; i < 8 && !/Find|Save/.test(m.screenText()); i++) { m.press('ON', 3, 10); m.runSeconds(0.3); }
        m.insertPack(path.join(L.BUILD, 'CHESS.opk'), 0);
        m.runProc('CHESS', 'B'); m.runSeconds(4); m._base = null; L.idle(m);
        const base = L.base(m), end = base + meta.ktotal;
        const log = {};
        let pc = 0, on = false;
        const w0 = m.mem.write.bind(m.mem);
        m.dbg.setTrace((p) => { pc = p; });
        m.mem.write = (a, v) => {
          if (on && !(pc >= base && pc < end)) for (const [n, lo, hi] of AREAS) if (a >= lo && a < hi) (log[n] = log[n] || new Set()).add(a.toString(16));
          return w0(a, v);
        };
        const fen0 = G.engFen(m);
        const scr0 = m.screenText(), udg0 = JSON.stringify(m.udgs());
        if (phase === 'thinking') { G.typeUci(m, 'b1a3'); m.runSeconds(2); }
        let i = 0;
        for (; i < 1200 && !/ALARM|TEST/.test(m.screenText()); i++) {
          const t = m.read(0x20C5, 6);
          on = t[5] >= 59 || t[5] < 30 && /ALARM|TEST/.test(m.screenText());   // (a save or an overlay load is not the alarm's)
          m.runTicks(1);
        }
        const rang = /ALARM|TEST/.test(m.screenText()), scr = m.screenText().replace(/\n/g, '|');
        on = true;
        m.runSeconds(2);
        for (let k = 0; k < 10 && /ALARM|TEST|ON\/CLEAR/.test(m.screenText()); k++) { m.press('ON', 20, 4); m.runSeconds(0.4); }
        on = false;
        ok(rang && !/ALARM|TEST|ON\/CLEAR/.test(m.screenText()), `${tag} rang (${scr.replace(/ +/g, ' ').slice(0, 50)}), dismissed`);
        ok(!Object.keys(log).length, `${tag} nothing the game keeps was written` + Object.entries(log).map(([n, s]) => ` ${n}: ${[...s].slice(0, 8)}`).join(';'));
        if (phase === 'waiting') {
          m.runSeconds(0.5);
          ok(m.screenText() === scr0 && JSON.stringify(m.udgs()) === udg0 && G.engFen(m) === fen0, `${tag} the screen, its glyphs and the game as they were (blank until a key, before 24 Nov)`);
          G.typeUci(m, 'b1a3');
        }
        const done = G.waitPly(m, 2, 120);
        L.idle(m);
        ok(done && L.peekSym(m, 'g_n')[0] === 2 && /^[A-H1-8RNBQKPrnbqkp? ]/.test(m.screenText()), `${tag} the engine answers, the game goes on: ${G.engFen(m).slice(0, 44)}`);
        m.dbg.setTrace(null); m.mem.write = w0;
        L.keys(m, ['ON']); m.runSeconds(1); L.keys(m, ['S', 'S', 'S', 'EXE']); m.runSeconds(3);
        ok(/Edit|Find/.test(m.screenText()), `${tag} left`);
      } catch (e) { ok(false, tag + ' ' + e.message.split('\n').slice(0, 6).join(' | ')); }
    }
  }
}
console.log(fails ? fails + ' failures' : 'all alarm tests passed');
process.exit(fails ? 1 : 0);
