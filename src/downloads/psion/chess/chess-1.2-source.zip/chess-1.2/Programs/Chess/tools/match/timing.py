"""Average completed depth and PC time per move of the reference engine at given node caps,
on positions sampled from recorded games (run on an idle machine; single process).

    python timing.py [results_name=n6k_sf1700] [n_positions=600] [nodes=6000,36000]
"""
import json
import os
import random
import statistics
import subprocess
import sys
import time

import chess

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    name = sys.argv[1] if len(sys.argv) > 1 else 'n6k_sf1700'
    npos = int(sys.argv[2]) if len(sys.argv) > 2 else 600
    caps = [int(x) for x in (sys.argv[3] if len(sys.argv) > 3 else '6000,36000').split(',')]
    with open(os.path.join(HERE, 'results', name + '.jsonl')) as f:
        games = [json.loads(l) for l in f]
    pos = []
    for g in games:
        mv = g['moves'].split()
        b = chess.Board()
        for i, u in enumerate(mv):
            if i >= 8 and not b.is_game_over():
                pos.append((i, ' '.join(mv[:i])))
            b.push_uci(u)
    random.Random(1).shuffle(pos)
    pos = pos[:npos]
    p = subprocess.Popen(['node', os.path.join(HERE, 'uci_wrap.js'), os.path.join(HERE, 'snap_v2')],
                         stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, bufsize=1)

    def send(s):
        p.stdin.write(s + '\n')
        p.stdin.flush()

    def until(prefix):
        lines = []
        while True:
            l = p.stdout.readline().strip()
            lines.append(l)
            if l.startswith(prefix):
                return lines
    send('uci'); until('uciok')
    for cap in caps:
        res = {'open': [], 'mid': [], 'end': []}
        for ply, moves in pos:
            send('ucinewgame')
            send('position startpos moves ' + moves)
            send('isready'); until('readyok')
            t0 = time.perf_counter()
            send(f'go nodes {cap}')
            lines = until('bestmove')
            dt = time.perf_counter() - t0
            d = None
            for l in lines:
                if l.startswith('info depth'):
                    d = int(l.split()[2])
            ph = 'open' if ply < 30 else ('mid' if ply < 70 else 'end')
            res[ph].append((d, dt))
        allr = [x for v in res.values() for x in v]
        print(f'Nodes={cap}: {len(allr)} positions, mean depth {statistics.mean(x[0] for x in allr):.2f}, '
              f'median {statistics.median(x[0] for x in allr)}, mean PC time {1000 * statistics.mean(x[1] for x in allr):.1f} ms')
        for k, v in res.items():
            if v:
                print(f'   {k:4s} (ply {"<30" if k == "open" else "30-69" if k == "mid" else ">=70"}): n={len(v)} '
                      f'depth {statistics.mean(x[0] for x in v):.2f}, time {1000 * statistics.mean(x[1] for x in v):.1f} ms')
    send('quit')


if __name__ == '__main__':
    main()
