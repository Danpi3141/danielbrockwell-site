'use strict';
// The rules through the UI's routines (eng_setup, eng_legal, eng_play, eng_check, eng_status)
// against python-chess as an independent oracle (tools/audit/gen_rules.py -> data/rules_oracle.json):
//  - hand-made special cases: castling out of/through/into check, rook missing or attacked, rights lost;
//    en passant pins (horizontal, diagonal, file), en passant out of check; all promotions with and
//    without capture; mate, stalemate; the fifty-move rule (and mate on the 100th half-move);
//    threefold repetition (castling rights, en passant chances); too little material;
//  - random games biased towards special moves and repetitions: at every ply the legal list (count and
//    FNV-1a hash of the sorted UCI list), check and status must agree.
// Usage: node t_rules.js [maxGames]
const path = require('path');
const { Harness } = require('./harness.js');
const data = require(path.join(__dirname, 'data', 'rules_oracle.json'));
const MAXG = +(process.argv[2] || 1e9);

const h = new Harness();
let bad = 0;
const fail = (m) => { bad++; if (bad < 40) console.log('FAIL', m); };
const sqn = (s) => 'abcdefgh'[s & 7] + (1 + (s >> 4));
const sqi = (s) => (s.charCodeAt(1) - 49) * 16 + (s.charCodeAt(0) - 97);
function toEng(u) {
  const pr = u[4] ? 'qrbn'.indexOf(u[4]) : 0;
  return [sqi(u.slice(0, 2)), sqi(u.slice(2, 4)) | ((pr & 1) << 3) | ((pr & 2) << 6)];
}
function uci(f, t) {
  const pc = h.peek('e_board', f), promo = (pc & 7) === 1 && ((t & 0x70) === 0x70 || (t & 0x70) === 0);
  return sqn(f) + sqn(t & 0x77) + (promo ? 'qrbn'[((t >> 3) & 1) | ((t >> 6) & 2)] : '');
}
function asmLegal() {
  const n = h.call('eng_legal').b, lm = h.bytes('e_lm', n * 2), out = [];
  for (let i = 0; i < n; i++) out.push(uci(lm[i * 2], lm[i * 2 + 1]));
  return out.sort();
}
function fnv(s) {
  let x = 0x811C9DC5;
  for (let i = 0; i < s.length; i++) { x ^= s.charCodeAt(i); x = Math.imul(x, 0x01000193) >>> 0; }
  return x >>> 0;
}
function boardFen() {
  const b = h.bytes('e_board', 128);
  let s = '';
  for (let r = 7; r >= 0; r--) {
    let e = 0;
    for (let c = 0; c < 8; c++) {
      const p = b[r * 16 + c];
      if (!p) { e++; continue; }
      if (e) { s += e; e = 0; }
      const ch = ' pnbrqk'[p & 7];
      s += p & 8 ? ch : ch.toUpperCase();
    }
    if (e) s += e;
    if (r) s += '/';
  }
  return s;
}
// castling rights as python-chess reports them (a right without its king and rook at home is dropped)
function castleStr() {
  const c = h.peek('e_castle'), b = h.bytes('e_board', 128);
  let s = '';
  if (c & 1 && b[4] === 6 && b[7] === 4) s += 'K';
  if (c & 2 && b[4] === 6 && b[0] === 4) s += 'Q';
  if (c & 4 && b[0x74] === 14 && b[0x77] === 12) s += 'k';
  if (c & 8 && b[0x74] === 14 && b[0x70] === 12) s += 'q';
  return s || '-';
}
function play(u, where) {
  const [f, t] = toEng(u);
  if (!h.hasMove(f, t)) { fail(`${where}: not in the legal list: ${u}`); return false; }
  h.call('eng_play', f, t);
  return true;
}

// ---- special cases
let cases = 0;
const statusCount = {};
for (const c of data.cases) {
  const r = h.setFen(c.fen);
  if (r.c) { fail(`${c.name}: set-up refused (${r.a})`); continue; }
  let ok = true;
  for (const u of c.moves) if (!play(u, c.name)) { ok = false; break; }
  if (!ok) continue;
  const w = c.want, before = bad;
  const lg = asmLegal();
  if (lg.join(' ') !== w.legal.join(' ')) {
    const extra = lg.filter(m => !w.legal.includes(m)), missing = w.legal.filter(m => !lg.includes(m));
    fail(`${c.name}: legal list differs; extra [${extra}] missing [${missing}]`);
  }
  for (const u of c.has) { const [f, t] = toEng(u); if (!h.hasMove(f, t)) fail(`${c.name}: ${u} refused`); }
  for (const u of c.hasnot) { const [f, t] = toEng(u); if (h.hasMove(f, t)) fail(`${c.name}: ${u} accepted`); }
  const chk = h.call('eng_check').a !== 0;
  if (chk !== w.check) fail(`${c.name}: check ${chk}, want ${w.check}`);
  const st = h.call('eng_status').a;
  if (st !== w.status) fail(`${c.name}: status ${st}, want ${w.status}`);
  if (boardFen() !== w.board) fail(`${c.name}: board ${boardFen()}, want ${w.board}`);
  if ((h.peek('e_side') ? 'b' : 'w') !== w.turn) fail(`${c.name}: side to move`);
  if (castleStr() !== w.castle) fail(`${c.name}: castling ${castleStr()}, want ${w.castle}`);
  const ep = h.peek('e_ep');
  if (w.ep !== '-' && (ep === 0xFF || sqn(ep) !== w.ep)) fail(`${c.name}: en passant square ${ep === 0xFF ? '-' : sqn(ep)}, want ${w.ep}`);
  if (h.peek('e_half') !== w.half) fail(`${c.name}: half-move clock ${h.peek('e_half')}, want ${w.half}`);
  statusCount[st] = (statusCount[st] || 0) + 1;
  cases++;
  if (bad === before && process.env.VERBOSE) console.log('ok  ', c.name);
}
console.log(`${cases} special cases (end statuses ${JSON.stringify(statusCount)})`);

// ---- random games
let positions = 0, games = 0;
const ends = {};
for (const g of data.games.slice(0, MAXG)) {
  h.call('eng_reset');
  for (let i = 0; i < g.length; i++) {
    const [mv, n, hash, st, chk] = g[i];
    const where = `game ${games} ply ${i}`;
    const lg = asmLegal();
    positions++;
    if (lg.length !== n || fnv(lg.join(' ')) !== hash) { fail(`${where}: legal list differs (${lg.length} v ${n}) board ${boardFen()}`); break; }
    if ((h.call('eng_check').a !== 0) !== chk) { fail(`${where}: check differs`); break; }
    const s = h.call('eng_status').a;
    if (s !== st) { fail(`${where}: status ${s}, want ${st} board ${boardFen()}`); break; }
    if (mv === null) { ends[s] = (ends[s] || 0) + 1; break; }
    if (!play(mv, where)) break;
  }
  games++;
}
console.log(`${games} random games, ${positions} positions (end statuses ${JSON.stringify(ends)})`);
console.log(bad ? `${bad} FAILED` : 'rules match python-chess');
process.exit(bad ? 1 : 0);
