// First-order estimate of the error from ignoring en passant in KPvKP: for every position where
// the side to move has a double pawn push that lands beside the enemy pawn, re-score that push
// allowing the e.p. capture (opponent's best of: table value, e.p. capture -> KPK), recompute the
// position's value and count changes.  (Not propagated further back: an estimate, not a fix.)
'use strict';
const L = require('./lib');
const S = require('./solve');
const T = L.loadTable('KPvKP');
const ctx = S.makeCtx('KPvKP'), c2 = S.makeCtx('KPvKP');
const S4 = 64 ** 4;
let withEp = 0, changed = 0, legalN = 0;
const wdl = v => v === 0 ? 'D' : ((v - 1) & 1) ? 'W' : 'L';
for (let i = 0; i < 2 * S4; i++) {
  if (T.val[i] === 255) continue;
  legalN++;
  const stm = S.decode(ctx, i); S.setOcc(ctx);
  const myP = stm === 0 ? 2 : 3, opP = 5 - myP;
  const ps = ctx.sqs[myP], os = ctx.sqs[opP];
  const startR = stm === 0 ? 1 : 6, d = stm === 0 ? 8 : -8;
  if ((ps >> 3) !== startR) continue;
  const to = ps + 2 * d;
  if ((os >> 3) !== (to >> 3) || Math.abs((os & 7) - (to & 7)) !== 1) continue;
  // is the double push legal?  (find it among the generated moves)
  const succIdx = i + (stm ? -S4 : S4) + 2 * d * ctx.mult[myP];
  let best = -1e9, bestNoEp = -1e9, found = false, epBetter = false;
  S.genMoves(ctx, i, stm, (kind, a) => {
    let s = kind === 0 ? L.backScore(T.val[a]) : L.backScore(a);
    if (kind === 0 && a === succIdx) {
      found = true;
      // opponent may capture e.p.: pawn os takes to the square behind `to`
      S.decode(c2, a); S.setOcc(c2);
      const epTo = to - d;
      const list = [[0, L.K, c2.sqs[0]], [1, L.K, c2.sqs[1]], [stm ^ 1, L.P, epTo]];
      // legality of the e.p. capture: opponent king not attacked afterwards
      c2.occ[os] = -1; c2.occ[to] = -1; c2.occ[epTo] = opP; const so = c2.sqs[opP]; c2.sqs[opP] = epTo; c2.alive[myP] = 0;
      const ok = !S.attacked(c2, c2.sqs[stm ^ 1], stm);
      c2.sqs[opP] = so; c2.alive[myP] = 1;
      if (ok) {
        const vOppEp = L.backScore(L.probe(list, stm));     // opponent's score after e.p. (stm to move)
        const vOppTab = L.score(T.val[a]);
        if (vOppEp > vOppTab) { epBetter = true; s = -vOppEp + (vOppEp > 0 ? 1 : vOppEp < 0 ? -1 : 0); }
      }
    }
    if (s > best) best = s;
  });
  if (!found) continue;
  withEp++;
  if (epBetter) {
    const nv = L.valOfScore(best);
    if (wdl(nv) !== wdl(T.val[i])) changed++;
  }
}
console.log(JSON.stringify({ legalPositions: legalN, withEpPossibleDoublePush: withEp, wdlChangedFirstOrder: changed }));
