'use strict';
// King and pawn v king from the distance table on the pack (OV_KPK), against ref/kpkroot.js:
// positions set up through the set-up screen (random ones, and ones where a wrong move changes
// the result), each side to move; the computer's move (its side to move) or the hint (the
// player's side to move) must be the reference's choice. Also: how long a choice takes.
//   node tests/ui/t_kpkd.js [positions=40] [seed=3]
const fs = require('fs');
const path = require('path');
const L = require('./lib.js');
const G = require('./glib.js');
const { check } = L;
const { Engine, legalMoves } = require('../../ref/search.js');
const { kpkRoot, look } = require('../../ref/kpkroot.js');
const kpk = require('../../tools/kpk/probe.js');

const TAB = fs.readFileSync(path.join(L.ROOT, 'data', 'kpkd.bin'));
const N = +(process.argv[2] || 40);
let rng = +(process.argv[3] || 3);
const rnd = (k) => { rng ^= rng << 13; rng >>>= 0; rng ^= rng >>> 17; rng ^= rng << 5; rng >>>= 0; return rng % k; };
const nm = (q) => 'abcdefgh'[q & 7] + ((q >> 4) + 1);
function fenOf(wk, bk, p, pc, stm) {
  const b = Array(64).fill('');
  b[wk] = 'K'; b[bk] = 'k'; b[p] = pc ? 'p' : 'P';
  const rows = [];
  for (let r = 7; r >= 0; r--) { let s = '', n = 0; for (let f = 0; f < 8; f++) { const c = b[r * 8 + f]; if (!c) n++; else { if (n) s += n; n = 0; s += c; } } if (n) s += n; rows.push(s); }
  return rows.join('/') + (stm ? ' b' : ' w') + ' - - 0 1';
}
// starts: legal, the reference decides (not a pawn-side draw), half of them critical (some
// legal move changes the old table's result)
const starts = [];
const seen = new Set();
while (starts.length < N) {
  const pc = rnd(2), stm = rnd(2), p = 8 + rnd(48), wk = rnd(64), bk = rnd(64);
  if (new Set([p, wk, bk]).size < 3) continue;
  if (Math.max(Math.abs((wk & 7) - (bk & 7)), Math.abs((wk >> 3) - (bk >> 3))) < 2) continue;
  const fen = fenOf(wk, bk, p, pc, stm);
  if (seen.has(fen)) continue;
  const e = new Engine(); e.setFen(fen); e.ply = 0;
  if (e.attacked(e.ksq[(e.side ^ 8) >> 3], e.side) || !legalMoves(e).length) continue;
  const mv = kpkRoot(e, TAB);
  if (!mv) continue;
  if (starts.length % 2 === 0) {                          // critical
    const v0 = kpk.probe(kpk.load(), wk, bk, p, stm, pc);
    let flips = false;
    for (const [f, t] of legalMoves(e)) {
      e.make(f, t);
      let pp = -1; for (let s = 0; s < 128; s++) { if (s & 0x88) { s += 7; continue; } if ((e.b[s] & 7) === 1) pp = s; }
      const s64 = (s) => (s >> 4) * 8 + (s & 7);
      const v = pp < 0 ? 0 : kpk.probe(kpk.load(), s64(e.ksq[0]), s64(e.ksq[1]), s64(pp), e.side >> 3, pc);
      e.unmake();
      if (v !== v0) { flips = true; break; }
    }
    if (!flips) continue;
  }
  seen.add(fen);
  starts.push({ fen, mv });
}

// and two where a queen would stalemate, so the computer (Black) must promote to a rook
for (const fen of ['5k1K/8/8/8/8/8/1p6/8 b - - 0 1', '8/8/8/k7/8/K7/1p6/8 b - - 0 1']) {
  const e = new Engine(); e.setFen(fen); e.ply = 0;
  const mv = kpkRoot(e, TAB);
  if (!mv || (mv[1] & 0x88) !== 0x08) throw new Error('expected a rook promotion in ' + fen);
  starts.push({ fen, mv });
}

let comp = 0, hints = 0, maxSecs = 0;
for (const st of starts) {
  const m = G.start();
  G.setting(m, G.SET.LEVEL, ['LEFT', 'LEFT', 'LEFT', 'LEFT', 'LEFT', 'LEFT']);   // (no long thinks if it searched)
  G.setupFen(m, st.fen);
  const want = nm(st.mv[0]) + nm(st.mv[1] & 0x77) + ({ 0x08: 'r', 0x80: 'b', 0x88: 'n' }[st.mv[1] & 0x88] || '');
  // (setupFen waits for the player's turn: when the computer had the move it has played)
  if (L.peekSym(m, 'g_n')[0] === 1 || L.peekSym(m, 'e_side')[0] !== L.peekSym(m, 'g_human')[0]) {
    const c0 = m.cycles();
    G.waitPly(m, 1, 60);
    const secs = (m.cycles() - c0) / 921600;
    maxSecs = Math.max(maxSecs, secs);
    const last = L.peekSym(m, 'g_last', 2);
    const got = nm(last[0]) + nm(last[1] & 0x77) + ({ 0x08: 'r', 0x80: 'b', 0x88: 'n' }[last[1] & 0x88] || '');
    check(got === want, `${st.fen}: the computer plays ${got}, the reference ${want} `, m);
    comp++;
  } else {
    const c0 = m.cycles();
    L.keys(m, ['SPACE']);
    L.waitFor(m, () => /HINT [A-H][1-8][A-H][1-8]/.test(m.screen()[3]), 30);   // (the whole hint, not the line half drawn)
    const secs = (m.cycles() - c0) / 921600;
    const h = (m.screen()[3].match(/HINT ([A-H][1-8][A-H][1-8])/) || [])[1] || '';
    check(h.toLowerCase() === want.slice(0, 4), `${st.fen}: the hint is ${h}, the reference ${want} (${secs.toFixed(1)} s)`, m);
    hints++;
  }
}
console.log(`     ${comp} computer moves and ${hints} hints, all the reference's`);
console.log('all UI tests passed');
