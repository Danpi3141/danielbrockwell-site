; =====================================================================
; Engine: the routines the kernel and screens call (see API.md).
; =====================================================================

; one-time set-up: e_tt and e_ttn must be set
eng_init:
        ldd  e_rnd
        bne  .r
        ldd  #$ACE1
        std  e_rnd
.r:     bsr  eng_ttinit
        bra  eng_reset

; (re)size the table from e_tt / e_ttn and clear it; the position is kept
eng_ttinit:
        ldd  e_ttn
        subd #1
        std  e_ttmask
        jmp  e_clrtt

eng_reset:
        ldx  #e_board
        ldab #128
.z:     clr  0,x
        inx
        decb
        bne  .z
        ldx  #e_start
        clrb
.s:     ldaa 0,x                ; rank 1, then rank 8
        pshx
        ldx  #e_board
        abx
        staa 0,x
        oraa #8
        staa $70,x
        ldaa #1
        staa $10,x
        ldaa #9
        staa $60,x
        pulx
        inx
        incb
        cmpb #8
        bne  .s
        clr  e_side
        ldaa #15
        staa e_castle
        ldaa #$FF
        staa e_ep
        clr  e_half
        ; fall into eng_setup

; derived state from e_board/e_side/e_castle/e_ep/e_half; C=1 if illegal (A = reason)
eng_setup:
        bsr  e_ply0
        clr  e_pcv
        jsr  e_recalc
        clr  e_kn
        ldaa e_cnt+6
        cmpa #1
        bne  .bad1
        ldaa e_cnt+14
        cmpa #1
        bne  .bad1
        ldx  #e_pm              ; no pawn on rank 1 or 8
        ldab #20
.p:     ldaa 0,x
        bita #$81
        bne  .bad2
        inx
        decb
        bne  .p
        ldab e_side             ; the side not to move must not be in check
        eorb #8
        lsrb
        lsrb
        lsrb
        ldx  #e_ksq
        abx
        ldab 0,x
        ldaa e_side
        jsr  e_att
        bcs  .bad3
        clc
        rts
.bad1:  ldaa #1
        sec
        rts
.bad2:  ldaa #2
        sec
        rts
.bad3:  ldaa #3
        sec
        rts

e_start: fcb 4,2,3,5,6,3,2,4

; clear the transposition table
e_clrtt: ldx e_tt
        ldd  e_ttn
        std  e_t
.c:     clr  0,x
        clr  1,x
        clr  2,x
        clr  3,x
        clr  4,x
        clr  5,x
        clr  6,x
        ldab #7                 ; 7-byte entries
        abx
        ldd  e_t
        subd #1
        std  e_t
        bne  .c
        rts

; ply 0, first frame, move stack base
e_ply0: clr  e_ply
        ldx  #e_frames
        stx  e_fp
        ldx  #e_frames-E_FR
        stx  e_ofp
        ldx  #e_mvs
        stx  e_mvtop
        rts

; legal moves into e_lm, B = e_lmn = count
eng_legal:
        bsr  e_ply0
        bsr  e_inchk
        tpa
        anda #1
        staa e_inck
        clr  e_caps
        jsr  e_gen
        ldd  e_wp
        std  e_mvtop+2
        ldx  #e_lm
        stx  e_t+2              ; write pointer
        clr  e_lmn
        ldx  #e_mvs
.l:     stx  e_t+4
        cpx  e_mvtop+2
        beq  .d
        ldaa 0,x
        ldab 1,x
        jsr  e_make
        bcs  .il
        ldx  e_t+4
        ldd  0,x
        ldx  e_t+2
        std  0,x
        inx
        inx
        stx  e_t+2
        inc  e_lmn
.il:    jsr  e_unmake
        ldx  e_t+4
        inx
        inx
        inx
        bra  .l
.d:     ldab e_lmn
        rts

; A = from, B = to: play it on the game board
eng_play:
        psha
        pshb
        clr  e_pcv
        bsr  e_ply0
        pulb
        pula
        jsr  e_make
        bsr  e_ply0             ; keep the move: drop the frame
        ldaa e_half
        beq  .irr
        ldaa e_kn               ; (a game past the fifty-move mark, as an imported one can be:
        cmpa #E_KCAP            ; over by then; the history is bounded all the same)
        bcs  .r
.irr:   clr  e_kn               ; nothing before an irreversible move can repeat
.r:     rts

; A != 0 if the side to move is in check
eng_check:
        bsr  e_inchk
        tpa
        anda #1
        rts

; C=1 if the side to move is in check
e_inchk: ldab e_side
        lsrb
        lsrb
        lsrb
        ldx  #e_ksq
        abx
        ldab 0,x
        ldaa e_side
        eora #8
        jmp  e_att

; A = 0 playing, 1 mate, 2 stalemate, 3 fifty moves, 4 threefold, 5 too little material
eng_status:
        jsr  eng_legal
        tstb
        bne  .some
        bsr  e_inchk
        ldaa #2
        sbca #0                 ; in check: 1
        rts
.some:  ldaa e_half
        cmpa #100
        bcs  .rep
        ldaa #3
        rts
.rep:   clr  e_t                ; earlier occurrences of this position
        ldab e_kn
        subb #2
        bcs  .ins
.r1:    stab e_t+1
        aslb
        ldx  #e_khist
        abx
        ldd  0,x
        subd e_key
        bne  .r2
        inc  e_t
.r2:    ldab e_t+1
        subb #2
        bcc  .r1
        ldaa e_t
        cmpa #2
        bcs  .ins
        ldaa #4
        rts
.ins:   bsr  e_insuf
        bcc  .ok
        ldaa #5
        rts
.ok:    clra
        rts

; C=1 if neither side can mate: no pawns, rooks or queens, and at most one
; minor piece, or (16 Nov) only bishops, all on one colour of square
e_insuf: ldaa e_cnt+1
        adda e_cnt+9
        adda e_cnt+4
        adda e_cnt+12
        adda e_cnt+5
        adda e_cnt+13
        bne  .no
        ldaa e_cnt+2
        adda e_cnt+3
        adda e_cnt+10
        adda e_cnt+11
        cmpa #2
        bcs  .yes               ; at most one minor piece
        ldaa e_cnt+2            ; two or more: bishops only?
        adda e_cnt+10
        bne  .no
        ldaa #$FF               ; then each bishop's colour, (rank + square) & 1
        staa e_bcol
        ldx  #e_board
        clrb
.sq:    ldaa 0,x
        anda #7
        cmpa #3
        bne  .nx
        tba
        lsra
        lsra
        lsra
        lsra
        aba
        anda #1
        tst  e_bcol
        bpl  .cmp
        staa e_bcol             ; the first one
        bra  .nx
.cmp:   cmpa e_bcol
        bne  .no
.nx:    inx
        incb
        bpl  .sq
.yes:   sec
        rts
.no:    clc
        rts
