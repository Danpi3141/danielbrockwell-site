# UI audit (16 Nov 2026)

Seven checks of the screens, the kernel and the launchers, plus a soak, all in the headless LZ64
(`tools/emu.js`: the Jape sources under Node, `46a-lz64.rom`, 64K). Every test boots its own
machine, loads `build/game/CHESS.opk` into B: and drives the game with key presses only. The
independent model is python-chess (`tests/ui/gen_games.py` makes the games, `tests/ui/model.py`
answers the soak); the screen is read back from the emulated LCD (text cells and the glyph
bitmaps it holds), never from the game's variables.

Helpers: `tests/ui/glib.js` (playing games through the keys, reading the engine state, decoding
the screen), `tests/ui/help.js` (a pack for slot C: with small OPL procedures: FREE, the files on
A:, filling RAM or A:, a procedure that calls CHESS with less free RAM).

Short forms of five tests are now in `node tests/ui/run_all.js` (13 files, 894 checks, all pass; 12.5 minutes on a machine busy with another agent's matches, the eight older files about a minute of it). The long
runs are listed under each check.

## Summary of what was found and changed

| # | Found | Fixed in |
|---|---|---|
| 1 | Take back did not restore the clocks: both kept the time used since (7 of 7 clock take-backs wrong) | `ksave.asm`, `ov_game.asm`, `kcore.asm` |
| 2 | After a game ended, the board's turn line still showed the side that made the last move | `kentry.asm` |
| 3 | Queen-side castling was written `Kc1` / `Kc8` (strip, move list, real-board mode) | `kfmt.asm` |
| 3 | In a set-up game where Black moves first, move numbers were one short (move list, real-board mode, result screen) | `ov_list.asm`, `kboard.asm`, `ov_result.asm` |
| 4 | A custom clock of more than 54 minutes wrapped round (90 min became 35.4 min): a clock is a 16-bit count of 50 ms frames | `ov_set.asm` (limit 54) |
| 5 | With a blinking cursor (a square typed, the pointing cursor, a piece picked up, the set-up screen) the Organiser never switched itself off | `kentry.asm`, `ov_setup.asm` |
| 5 | With the pack taken out, the next screen load read zeros and ran whatever code was left in slot A (here the board; it could have been anything) | `kpack.asm` |
| 7 | When A: had no room for A:CHESSAV the game said nothing, and take back then replayed an empty record (the game went back to the start); a save after a failed write could leave half a file | `ksave.asm`, `kentry.asm`, `kcore.asm`, `kvars.inc` |
| 7 | "CHESS NEEDS4BYTES MORE RAM": no spaces | `tools/build.py` |
| soak | The computer used the opening book in set-up positions (its moves are checked legal, but they are opening moves) | `kbook.asm` |
| soak | At level 1 the engine sometimes thinks for minutes at depth 1 (engine; reported, not changed) | — |

All the code changes are listed under "Changes" at the end, with the RAM and pack sizes.

## 1. Take back across special moves

`node tests/ui/t_back.js` (about 2 minutes; `--quick` in run_all).

- **Games** (two players, typed on the keys): the 19 crafted games of `gen_games.py --crafted`:
  castling O-O and O-O-O for both colours (and with check), en passant by both colours (also
  from a set-up position), promotion to Q and N with capture and check, to R, under-promotion to
  B with capture, a capture, checks, fool's and scholar's mate, Loyd's stalemate, a threefold
  repetition, too little material, file, rank and double disambiguation, and a set-up position
  with Black to move first and both castlings.
- **Compared** after every ply: the engine's FEN (board, side, castling, en passant, half-moves)
  against python-chess. Kept for every position: the whole persistent engine state (`e_board` to
  `e_key`: board, side, castling rights, en passant square, half-move clock, king squares,
  material and PST sums, phase, piece counts, pawn masks, the position key, and the key history
  `e_khist` up to `e_kn`), the record length and last ply, the result, the clocks and the whole
  screen. Then every ply is taken back with DEL one at a time (from the result screen where
  the game ended: EXE, then DEL), and each state and screen must equal the one kept when that
  position was first reached.
- Against the computer (level 1): three moves and replies, then DEL (two plies), the menu's TAKE
  BACK, DEL to the start, DEL with no moves.
- With a 5|5 clock: 7 plies with 3-9 s between them, then 7 take backs; the clocks must be what
  they were when each position was first reached.

**Found:** everything matched except the clocks: after a take back both clocks kept the time
used since (e.g. back to ply 0: 5632/5645 frames instead of 6000/6000).

**Fix:** each chunk record of A:CHESSAV now also holds, for each of its 10 plies, the mover's
clock after the move (2 bytes; records grow from 31 to 51 bytes, the file by 500 bytes on A:).
`sv_ply` writes it; a new OV_GAME entry `clk_back` (G_CLKBACK) sets each side's clock from its
last ply after a take back (the starting time if it has none) and starts the side to move's
clock; `take_back` calls B_CLKNEW then G_CLKBACK. The save file version went from 2 to 3, so a
file from before is treated as damaged (settings back to defaults, a new game).

**Result:** 156 take backs compared, 0 failures (state, screen and clocks). (The record's last
ply `g_last` is stale once the record is empty; nothing reads it then, so it is not compared at
ply 0.)

## 2. Screen round trip

`node tests/ui/t_screen.js` (about 10 minutes; `--smoke` in run_all).

- **Read back:** the rank numbers in column 8 give the ranks and whether the board is turned
  (then the files run h to a); each letter cell gives the piece (capitals White), an empty
  square must show the diamond (250) if dark and a space if light; the map's eight glyphs are
  decoded from the bitmaps in the LCD's CGRAM (hollow 5x3 block White, solid Black, blank
  empty; upper square rows 0-2, lower rows 4-6), so a wrong glyph definition would show. In the
  default layout MODE shows the other half, so all 64 squares are read as letters and again as
  map colours. In the split layout all 64 are letters. The strip's turn line (W/B) is checked too.
- **Games:** 12 random games (up to 120 plies, leaning to promotions, castling, en passant,
  captures and checks) and three crafted ones (promotions, Black first, three queens), played
  in four runs: letters and map, the same turned (FLIP), split, split turned. Both sides to move
  occur in every run.
- Real-board mode shows no board; its text is checked under 3.

**Found:** after a game ended, the turn line kept showing the side that made the last move (the
mated side was shown as "W" after a White mate, for example).
**Fix:** `human_look` (the board after the game) calls `set_turn` first.
**Result:** 6,101 checks, 0 failures: 1,489 positions read back (letters and map 400, turned 401,
split 287, split turned 401), each one all 64 squares by letter and, in the default layout, by
map colour, plus the turn line. The empty squares' shading was right everywhere.

## 3. Notation

`node tests/ui/t_notat.js` (about 25 minutes; `--smoke` in run_all).

- **Compared:** the strip after every ply, cell for cell (who / where / what, a part shorter
  than three cells one column in) against python-chess SAN cut into those parts; then the whole
  move list, scrolled from the first line to the last, row for row against the SAN list
  (`N.white` from column 0, black from column 11, `1....` when Black began); the plain-squares
  option on the strip (`e2`/`e4`, `h4x`, `e8Q`, then `+`/`#`); real-board mode in both notations
  (`WHITE PLAYED`, `12... Qh4xe1+`, the move number from the FEN).
- **Games:** the crafted ones (including `Qh4e1+` with three queens, `R1a3`, `Raa1`, `Rhd1`,
  `Nge5`, `Nc2e3`, `Nbd2`, `Ndf3`, `axb8=Q`, `gxh1=R`, `exd8=N+`, `cxb8=B`, `exd6` en passant,
  `O-O-O+`, `O-O+` by Black, `Qh4#`, `axb8=Q#`) and 8 random games, and a 250-ply random game
  (the longest record): its move list has 125 lines, and `100.` + a 7-character move fits
  exactly in the 11 columns before Black's move. A 251st move ends the game with THE RECORD IS
  FULL and is not played.

**Found:**
- Queen-side castling came out as `Kc1` / `Kc8` everywhere. The castling test was
  `(from xor to) & 7 == 2`: that is e to g (4 xor 6), but e to c is 4 xor 2 = 6. Fixed: 2 or 6
  (a king moves two files only when it castles).
- When Black moved first (a set-up position) the move list printed Black's first move as White's
  move 1 and every later number one short; real-board mode and the result screen's "AFTER n
  MOVES" were one short too. Fixed: the list shows `1....` then Black's move and counts from
  there; the other two add one when the set-up had Black to move.

**Result:** 6,394 checks, 0 failures: 27 games (1,642 plies) on the strip in both notations and
in real-board mode in both, 28 move lists read to the end (the longest 125 lines), and the 251st move.

The list shows four moves a screen and reads each ply from A:CHESSAV, so scrolling a long game
takes about 0.2 s a line; 80 legal moves at most are kept for the screens (a known limit:
disambiguation and entry look only at those), and the random games stop before a position with
more.

## 4. Clock drift over an hour

`node tests/ui/t_clock.js 60` (about 4 minutes; `--profile` adds a trace of every instruction).

- **Run:** against the computer, 30|30, level 7, natural pace, sound on; the player's moves are
  random legal moves after 5-40 s. 60.6 emulated minutes: 4 games (the random player is mated),
  59 player moves, 112 timed turns. A breakpoint on the kernel's `board` catches each B_CLKSTART
  and B_CLKMOVED, so each turn is measured three ways: emulated time (cycles / 921,600), the OS's
  frame counter TMW_FRAM (which the clocks run on) and what was charged to the clock.
- **Results:**
  - The frame counter ran at 20.0167 a second while idle (+3.0 s an hour: the OS's own tick
    period, OCR = kbw_tdel less a latency allowance) and at 19.9927 a second over the hour of play:
    **-1.3 s per hour** against emulated time.
  - The clocks against the frame counter: 14.1 s more over 112 turns (0.13 s a turn, at most 3
    frames): the clock stops when the move has been processed, about two overlay loads after the
    move is entered. There is no drift between the clocks and the frame counter.
  - Between turns no clock runs for 2.33 s a move (the move is made, saved and blinked; the
    player's clock starts after the computer's move has blinked). By design; it is about 4% of
    the hour in this game.
- **What masks interrupts** (`--profile`, 5 minutes of play, and a king-and-pawn think with the
  slices read from the pack):
  - `scr_flush` (kernel, `kscreen.asm`): `sei` around sending the 80 cells, 5.4-5.8 ms each
    time; 529 times in 5 minutes (about 3 a second while the engine thinks: the strip).
  - BZ$TONE (ROM, $D893: `tpa / psha / sei`) masks for the whole note: blip 40 ms, check 40 +
    50 ms, buzz 150 ms, end phrase 90 + 90 + 90 + 180 ms, clock tick 4 ms.
  - The OS's own tick handler takes up to 3.5 ms (it is the tick, nothing is lost).
  - Reading the pack (overlays, the book, the KPK slices: 4 x 512 bytes) and writing A:CHESSAV
    never masked for 1 ms or more. Nothing else in the kernel or screens uses `sei`; `tpa/tap`
    elsewhere only save flags.
- **Hardware estimate:** the OS restarts its tick counter from the moment it services the tick
  (the handler at $CC3C clears FRC and reloads OCR), so a masked period does not lose a whole
  50 ms tick: it delays that one tick by however long the mask still had to run. A period of L ms
  (L < 50) loses L*L/100 ms on average, at most L; a longer one loses about L - 25 ms. From the
  profile: about 2.8 s per hour of play (flushes 0.3 ms each on average, about 3.3 s an hour
  while the engine thinks all the time; blips 16 ms each). Most sounds fall between turns, so
  they do not touch the clocks; the buzz for a refused entry falls in the player's own time and
  gives the player about 0.12 s each time. Worst case for the clocks: a few seconds an hour
  slow, plus whatever error the real crystal and the OS's tick constant have, which only the
  real Organiser can show (the emulator's +3 s an hour idle rate depends on its own interrupt
  latency). The emulator models the deferred tick the same way (`deferOCI` in `tools/emu.js`).

**Found:** custom clock minutes went up to 90, but a clock is a 16-bit count of 50 ms frames
(54.6 minutes at most): 90 minutes became 108,000 mod 65,536 frames = 35.4 minutes.
**Fix:** the custom minutes stop at 54 (`ov_set.asm`). (0 minutes is still allowed: the flag falls
at once.)

## 5. Switching off at every moment

`node tests/ui/t_sleep.js` (about 1 minute; in run_all). The auto-off time is set to 20 s.

In each state the game is left alone; it must switch itself off, stay off a minute, and after ON
show the same screen (text and glyphs) with the same game state, then go on:

| State | Before the fix | After |
|---|---|---|
| board waiting for a move | off after 23 s | same |
| a square typed (D2), its cursor blinking | never off | off after 99 s, cursor shown |
| the pointing cursor | never off | off after 99 s |
| a piece picked up by pointing | never off | off after 96 s |
| menu, settings, move list | off after 20-23 s | same |
| set-up screen (blinking cursor) | never off | off after 99 s |
| promotion prompt | off after 23 s; then N makes a knight | same |
| result screen; the board after the game (then DEL takes back) | off after 23 s | same |
| a clock game, board waiting | stays on (by design: the clock runs; the flag falls in the end) | same |
| a clock game, menu | off after 23 s; the clock keeps running in the menu (charged) but not while off (TMW_FRAM stops) | same |
| thinking (level 8, 104 s, auto-off 20 s) | stays on, then moves | same |

**Fix:** a timed wait never switches off (a clock may be running), and the cursor blinks with a
timed wait, so it stayed on until a key. Now, with no clock, the cursor (and the set-up screen's)
blinks 256 times (about 77 s) after the last key, then stays shown and the wait sleeps, so the
Organiser switches off after its usual time. In a clock game the board still keeps it on.

**The pack taken out** while the game waits, then ON (the menu must be loaded): before, the read
gave zeros without an error, `ov_load` marked the menu loaded and called slot A, which still held
the board's code; it carried on by luck. **Fix:** `ov_load` refuses a screen whose length is 0 or
past slot A and leaves with GAME FILES NOT FOUND. The game was saved after the last move, so with
the pack back CHESS resumes it (checked). (If ON is still held when the game leaves, OPL takes it
as ON/CLEAR and waits for a key before the message; harmless.)

Not feasible here: a real battery failure (RAM is lost; A:CHESSAV with it) and a low-battery
switch-off, which the OS does the same way as auto-off.

## 6. Leaves nothing behind

`node tests/ui/t_leave.js` (about 2 minutes; in run_all).

- **Compared** at the top-level menu before and after each way out: FREE (an OPL procedure prints
  it), the data files on A: (DIR$), the system variables $40-$FF and $2000-$21FF, the eight
  glyphs, and the real-time clock against emulated time. Before the first run the key settings
  are set to unusual values (repeat delay 20, rate 5, key click 1, auto-off 123 s, CAPS and NUM
  on) to see that they come back.
- **Ways out:** SAVE AND LEAVE (first run, A:CHESSAV made), after a finished game, ON/CLEAR then Q
  in the launcher (OPL: ERROR ESCAPE), ON and Q pressed many times while it starts, too little
  RAM, damaged game files (block CHB0 renamed: GAME FILES DAMAGED), the pack taken out (GAME
  FILES NOT FOUND).
- **System variables:** bytes that change in any program (found by running a procedure that does
  what the launchers do, without the game, twice) and the OS's working storage (named from
  jaapsch.net's list of system variables: utw_s/utw_r scratch, the key buffer's pointers and
  repeat count, the auto-off count-down, the pack and file services' current device, address and
  record, OPL's run-time variables, the SWI scratch, the NMI count, the type-ahead buffer, the
  run-time buffer rtt_bf at $2188) are left out; kbb_dlay, kbb_rept, kbb_stat (CAPS, NUM),
  tmb_swof, bzb_mute (the beep), kbb_clik, kbb_pkof, tmw_tcnt, the display mode and cursor
  variables and kbw_tdel must be exactly as before.
- Also the exact difference between the moment the kernel is entered and its last instruction
  (the RTS in `quit`), with a move played in between.

**What the kernel writes** (scanned in `src/kernel` and `src/screens`): KBB_DLAY, KBB_REPT,
KBB_CLIK, KBB_PKOF, KBB_STAT (saved at the start, put back in `quit`), TMW_TOUT (reloaded so the
OS doesn't switch off; it is the OS's own count-down), T0-T11 (scratch), the LCD registers, and
through OS calls DP$MSET (4-line mode: OPL is in it already), DP$CSET $80 (dpb_clok $2095: 255 ->
128, both mean "no clock"; the top level sets it again), DP$STAT (cursor off, as OPL has it) and
the file services (current device A:).

**Result:** 57 checks, all pass. FREE 22238 before and after every way out; only A:CHESSAV is new (on the
first run). Kernel entry to exit: only dpb_clok changes. The top line's clock redefines the glyphs
itself, so none of the game's are left at the top level; a program that calls CHESS and uses its
own glyphs would have to define them again. The clock moved with emulated time within 1 s.

**Found and fixed:** the launcher's message read "CHESS NEEDS4BYTES MORE RAM"; now "CHESS NEEDS 4
BYTES MORE RAM" (commas, same size).

## 7. Low memory

`node tests/ui/t_lowmem.js` (about 10 minutes).

- **Thresholds:** CHESS is run from a procedure holding a LOCAL array of n words; each change of
  outcome is found by bisection (FREE at the top level 22238):
  - up to 10 words held (20 bytes less): 512 entries (array 21,328); 11 words: 256
  - up to 1033 words (2066 bytes less): 256 (array 19,280); 1034: 128
  - up to 1545 words (3090 bytes less): 128 (array 18,256); 1546: "CHESS NEEDS 4 BYTES MORE RAM"
  - At the last n of each outcome the game was played (a move out of the book, the engine thinks)
    and left: FREE at the top level was 22238 again each time. No other outcome (no OPL error,
    no crash) anywhere.
- **The real ceiling for the 512-entry table:** CHESX, a copy of CHESS of the same size whose
  first test always passes, runs CHG3 holding up to 32 words (64 bytes less) and gives OUT OF
  MEMORY at 33. So CHESS's check is 44 bytes stricter than it needs to be, and the largest array
  that still fits an empty LZ64 is about **21,392 bytes**: the 512-entry array (21,328 now)
  has 64 bytes of headroom. (LAUNCH_OVERHEAD in `tools/build.py` could be lowered by about 40.)
- **A: full** (filled with a data file until FREE is just above a launcher's need; A: uses the
  other RAM banks first and then the main RAM):

| FREE at the top level after filling | TT entries | A:CHESSAV | DEL | CHESS run again |
|---|---|---|---|---|
| 22232 (A: banks full, main RAM free) | 512 | not made: CANNOT SAVE: NO ROOM on row 3 | CANNOT TAKE BACK, game unchanged | a new game (nothing kept) |
| 21750 | 256 | made | takes back one ply exactly | resumes |
| 20398 | 256 | not made: CANNOT SAVE: NO ROOM | CANNOT TAKE BACK | a new game |
| 19380 | 128 | not made: CANNOT SAVE: NO ROOM | CANNOT TAKE BACK | a new game |

(`node tests/ui/t_lowmem.js`; in each case three plies were played in two-player mode, DEL
pressed, the game left and CHESS run again. On an empty A: the file goes into the other RAM
banks and FREE does not change; it costs main RAM only when the banks are full.)

**Found:** with no room for the save file the game said nothing; it played on without a record,
so take back replayed an empty record and the game went back to the start position, and the next
CHESS started a new game. A failed write after an erase would also have left half a file.
**Fix:** a record is only ever replaced by one of the same size, so in practice only making the
file can fail. Now any failed create or write deletes the file, sets `g_nosv` (a new kernel
byte), and the message line says CANNOT SAVE: NO ROOM; with `g_nosv` nothing more is written,
take back says CANNOT TAKE BACK (and the kernel's `take_back` refuses), and the game goes on.

## Soak

`node tests/ui/t_soak.js 6` (about 15 minutes).

- Against the computer at level 1, the player's moves random legal moves typed on the keys:
  6 games, 32-88 plies each, all ended in mate with reason 1, the engine's position equal to
  python-chess's after every ply (the computer's moves read from the record) and the game's end
  reason equal to python-chess's under the engine's rules.
- Two players: 6 random games of 250 plies (uniform random moves), every position compared.
- **1,878 plies checked in 33 minutes, 0 failures**; nothing hung (each ply within 2 emulated
  minutes, else a key is pressed and the position noted).

**Found:** in a set-up game the computer took moves from the opening book (`bk_reset` didn't look
at `g_setup`; the moves are checked legal, so no harm beyond playing an opening move in, say, a
king-and-pawn ending). Fixed: no book after a set-up.

**For the engine owner:** in an earlier soak run (07:15, with the engine as it was then) three of
four games at level 1 (1 s, margin 300) stalled at depth 1 for more than 2 minutes (the strip
showed `D 1` and 117 s; e.g. after 1.h4 b6 ... at ply 27). A key made it move. The final run,
with the engine of 08:00, had no think over 2 minutes in 6 games. The UI side is fine either
way (any key moves at once); the soak now records such positions instead of failing.

## What only the real Organiser can show

- The frame counter's true rate (the crystal and the OS's tick constant), so the clocks' drift
  per hour; the emulator gives -1.3 s an hour in play and +3 s idle, the masked periods about
  -3 s an hour.
- How long BZ$TONE really masks, and whether `scr_flush` needs to mask at all.
- Whether the ON key that switches the Organiser on reaches the game (it does not in Jape).
- Pack removal while running: the hardware may notice a missing or changed pack differently from
  Jape (which reads zeros).
- Battery: a low-battery switch-off, and the battery life with the game sleeping.

## Changes

| File | What changed |
|---|---|
| `src/kernel/kcore.asm` | `take_back`: refuses when `g_nosv`; after replaying sets the clocks (B_CLKNEW, then G_CLKBACK, which also starts the clock); SV_VER 3; G_CLKBACK = 11 |
| `src/kernel/kpack.asm` | `ov_load`: a screen of length 0 or past slot A means the pack is gone: leave with GAME FILES NOT FOUND |
| `src/kernel/kernel.asm` | the key settings saved and put back with word moves (18 bytes smaller); comment on DP$CSET |
| `src/kernel/kvars.inc` | `g_nosv` (1 byte) |
| `src/screens/ksave.asm` | the chunk records hold each ply's clock; `sv_ckfind`, `clk_back`; `sv_fail` (delete, `g_nosv`, CANNOT SAVE: NO ROOM) on any failed create or write; no saving with `g_nosv` |
| `src/screens/ov_game.asm` | entry 11 `clk_back`; `sv_k`, `sv_p` |
| `src/screens/kentry.asm` | the cursor stops blinking after 256 blinks with no clock (`hu_idle`); `human_look` shows the side to move; DEL with `g_nosv`: CANNOT TAKE BACK |
| `src/screens/ovars_b.inc` | `hu_idle` |
| `src/screens/ov_setup.asm` | the set-up cursor stops blinking after 256 blinks (`su_idle`) |
| `src/screens/kfmt.asm` | queen-side castling recognised (file difference 2 or 6) |
| `src/screens/ov_list.asm` | `1....` and numbering when Black began (`ls_off`, `ls_end`, `san_v`) |
| `src/screens/kboard.asm`, `ov_result.asm` | move numbers when Black began |
| `src/screens/ov_set.asm` | custom minutes 0-54 |
| `src/screens/kbook.asm` | no book after a set-up |
| `tools/build.py` | the launcher's message has spaces |
| `tests/ui/` | new: `glib.js`, `help.js`, `gen_games.py`, `model.py`, `t_back.js`, `t_screen.js`, `t_notat.js`, `t_clock.js`, `t_sleep.js`, `t_leave.js`, `t_lowmem.js`, `t_soak.js`; `lib.js` reads the symbols once per run; `run_all.js` runs the short forms |

**Sizes.** The engine changed during the audit (its code grew by about 100 bytes), so the
comparison is with the backup's kernel and screens built with the same engine:

| | before (backup UI) | after |
|---|---|---|
| kernel image end | 14,314 | 14,318 (+4 bytes) |
| RAM before the TT (16-byte steps) | 17,232 | 17,232 (no change) |
| array with 512 entries (budget.txt) | 21,328 | 21,328 (no change; 21,232 at the start of the audit, the difference is the engine's) |
| slot A | 2,912 | 2,912; largest screen OV_BOARD 2,804 -> 2,874 (38 bytes left before slot A grows) |
| OV_GAME / OV_LIST / OV_RESULT / OV_SETUP | 2,071 / 837 / 296 / 641 | 2,256 / 876 / 307 / 663 |
| screens block on the pack | 8,936 | 9,321 (+385) |
| A:CHESSAV | 26 records, 31-byte chunks | 51-byte chunks (+500 bytes on A:) |

The kernel is 2 bytes short of the next 16-byte step: 3 more bytes of kernel or engine code put
16 bytes on the array.
