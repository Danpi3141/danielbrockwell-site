"""Check 3: safe exits. Where the book ends and the Psion must think, the capped engine
(ref/uci.js, 2,500 nodes = the Psion's level 7, TT cleared) picks its first own move and
Stockfish judges it.

Exit positions:
  (a) a leaf reached by an opponent move: the Psion is to move;
  (b) a leaf reached by a Psion P move, followed by each of the opponent's most common club
      replies there (up to 3 replies with >= 10% of the club games in the position, >= 10 games).
Only paths the Psion can follow with that colour (all its moves P moves) are used.
A move is flagged when it is >= 100 cp worse than Stockfish's best (depth 22 screen from >= 85,
confirmed by restricted root searches at depth 26) and the Psion is then no better than +200.
Each exit is weighted by the probability of a game reaching it (the Psion picks uniformly among
P moves, the opponent moves by club frequency).

    python -E -P tools/book/audit/check3_exits.py [--book data/book.bin] [--out result.json]
"""
import argparse
import json
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import chess  # noqa: E402
from common import (Tree, SF, BOOK, CACHE, P, confirm, san_path, ref_moves, load_stats,  # noqa: E402
                    reach_prob, log)

DROP = 100
SCREEN = 85
STILL_OK = 200
REPLY_SHARE = 0.10
REPLY_MIN = 10
REPLY_MAX = 3


def exits(t, stats):
    out = []
    for g, mv in t.groups.items():
        b = t.board(g)
        mover = b.turn
        for u, fl, r in mv:
            if r:
                continue
            leaf = g + (u,)
            b.push_uci(u)
            if not b.is_game_over():
                if t.reach(leaf, not mover):
                    out.append({'kind': 'a', 'path': list(leaf), 'psion': 'w' if not mover else 'b'})
                if fl & P and t.reach(g, mover):
                    n, rep = stats['club'].get(b.epd(), (0, {}))
                    top = sorted(rep.items(), key=lambda kv: -kv[1])[:REPLY_MAX]
                    for ru, c in top:
                        if c >= REPLY_MIN and c >= REPLY_SHARE * n:
                            mvr = chess.Move.from_uci(ru)
                            if b.is_legal(mvr):
                                b.push(mvr)
                                if not b.is_game_over():
                                    out.append({'kind': 'b', 'path': list(leaf) + [ru], 'psion': 'w' if mover else 'b'})
                                b.pop()
            b.pop()
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--book', default=BOOK)
    ap.add_argument('--out', default=os.path.join(CACHE, 'check3.json'))
    a = ap.parse_args()
    t = Tree(a.book)
    stats = load_stats()
    ex = exits(t, stats)
    log('check3: %d exits (%d leaf/Psion to move, %d leaf+club reply)'
        % (len(ex), sum(e['kind'] == 'a' for e in ex), sum(e['kind'] == 'b' for e in ex)))
    for e in ex:
        e['prob'] = reach_prob(t, stats, e['path'], chess.WHITE if e['psion'] == 'w' else chess.BLACK)
    rm = ref_moves([e['path'] for e in ex])
    sf = SF()
    try:
        fens = []
        for e in ex:
            e['move'], e['refscore'] = rm[tuple(e['path'])]
            b = t.board(e['path'])
            fens.append(b.fen())
            b.push_uci(e['move'])
            fens.append(b.fen())
        evs = sf.evals(fens, label='exits')
        for e in ex:
            b = t.board(e['path'])
            pre = evs[b.epd()]
            b.push_uci(e['move'])
            post = -evs[b.epd()]['cp']
            e['best22'], e['post22'] = pre['best'], post
            e['screen'] = max(pre['cp'], post) - post
        cand = [e for e in ex if e['screen'] >= SCREEN]
        log('check3: %d exits over %d cp in the screen' % (len(cand), SCREEN))
        res = confirm(sf, [(t.board(e['path']).fen(), e['move']) for e in cand])
        for e, (bm, bcp, mine) in zip(cand, res):
            e['best26'], e['loss26'], e['post26'] = bm, bcp - mine, mine
    finally:
        sf.close()
    drops = [e for e in cand if e['loss26'] >= DROP]
    bad = [e for e in drops if e['post26'] <= STILL_OK]
    tot = sum(e['prob'] for e in ex) or 1
    for k in 'ab':
        es = [e for e in ex if e['kind'] == k]
        print('exits (%s): %d; capped-engine move >= %d cp below best: %d; of those flagged (Psion then <= +%d): %d'
              % (k, len(es), DROP, sum(e in drops for e in es), STILL_OK, sum(e in bad for e in es)))
    print('probability mass of flagged exits: %.2f%% of all exit mass (White %.2f%%, Black %.2f%%)' % (
        100 * sum(e['prob'] for e in bad) / tot,
        100 * sum(e['prob'] for e in bad if e['psion'] == 'w') / (sum(e['prob'] for e in ex if e['psion'] == 'w') or 1),
        100 * sum(e['prob'] for e in bad if e['psion'] == 'b') / (sum(e['prob'] for e in ex if e['psion'] == 'b') or 1)))
    for e in sorted(bad, key=lambda e: -e['prob'])[:25]:
        b = t.board(e['path'])
        print('  p=%.5f %s %-62s engine %-6s -%d (then %+d)  SF %s' % (
            e['prob'], e['psion'], san_path(e['path']), b.san(chess.Move.from_uci(e['move'])), e['loss26'], e['post26'],
            b.san(chess.Move.from_uci(e['best26'])) if e['best26'] else '-'))
    json.dump({'exits': ex, 'bad': bad, 'drops': drops}, open(a.out, 'w', encoding='utf-8'))
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main())
