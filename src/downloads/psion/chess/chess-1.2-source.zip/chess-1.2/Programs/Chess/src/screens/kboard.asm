; ---------------------------------------------------------------------
; Board screen drawing (into kv_cells; scr_flush sends it).
;
; Default layout (st_layout 0), 20 columns:
;   0-7   letter view: four ranks, one square per cell
;   8     the rank numbers
;   9-11  the strip: the last move in three parts, row 3 the turn/clock
;   12-19 the map: all 64 squares, two stacked in each cell (8 glyphs)
; Split layout (st_layout 1): 0-7 one rank, 8 its number, 9-16 the rank
; four lower, 17-19 the strip.
; v_flip = 1 turns the board for Black. v_half = 1 shows the far half.
; ---------------------------------------------------------------------

; (top state * 3 + bottom state) -> character; states 0 empty, 1 white, 2 black
gtab:   fcb  ' ',7,6,5,4,3,2,1,0
bchars: fcc  " PNBRQK  pnbrqk "


; B = square: A = its character in the letter view
sq_char:
        bsr  sq_piece           ; A = piece (0 if hidden by a blink)
        cmpb cur_sq
        bne  .nc
        tst  cur_on
        beq  .nc
        ldaa #CH_BLOCK
        rts
.nc:    tsta
        bne  .pc
        tba                     ; empty: dark squares carry the diamond
        lsra
        lsra
        lsra
        lsra
        aba
        anda #1
        bne  .light
        ldaa #CH_DIAM
        rts
.light: ldaa #' '
        rts
.pc:    ldx  #bchars
        tab
        abx
        ldaa 0,x
        rts

; B = square: A = piece there, or 0 if it is blinked out just now. B kept.
sq_piece:
        ldx  #e_board
        abx
        ldaa 0,x
        tst  bk_on
        beq  .x
        cmpb bk_sq
        beq  .z
        cmpb bk_sq+1
        beq  .z
        cmpb bk_sq+2
        bne  .x
.z:     clra
.x:     rts

; B = square: A = 0 empty, 1 white, 2 black
sq_state:
        bsr  sq_piece
        tsta
        beq  .x
        anda #8
        beq  .w
        ldaa #2
        rts
.w:     ldaa #1
.x:     rts

; A = row 0..3, B = column 0..7 of a four-rank block whose top rank (from
; White's side) is dr_top: B = square, turned for v_flip
blk_sq: tst  v_flip
        bne  .bl
        nega
        adda dr_top             ; rank = top - row
        bra  .mk
.bl:    pshb
        ldab #7
        subb dr_top
        aba                     ; rank = (7 - top) + row
        pulb
        negb
        addb #7                 ; file = 7 - column
.mk:    asla
        asla
        asla
        asla
        aba
        tab
        rts

; ---------------------------------------------------------------------
; draw: the board screen into kv_cells
; ---------------------------------------------------------------------
draw:   ldaa st_layout          ; (the map's glyphs are the kernel's kv_glyph, fixed since 17 Nov)
        beq  .map
        cmpa #2
        bne  .sp
        jmp  draw_real
.sp:    jmp  draw_split
.map:   ; the letter view: top rank 7 (far half) or 3 (near half), as seen
        ldaa #3
        tst  v_half
        beq  .h
        ldaa #7                 ; (the same when turned: blk_sq turns it)
.h:     staa dr_top
        clr  dr_c               ; cell index
        clr  dr_r
.lr:    clrb
.lc:    stab dr_col
        ldaa dr_r
        bsr  blk_sq
        jsr  sq_char
        jsr  dr_put
        ldab dr_col
        incb
        cmpb #8
        bne  .lc
        ; the rank number
        ldaa dr_r
        clrb
        bsr  blk_sq
        tba
        lsra
        lsra
        lsra
        lsra
        adda #'1'
        bsr  dr_put
        ldab dr_c               ; past the strip
        addb #3
        stab dr_c
        ; the map: two ranks a cell
        clrb
.mc:    stab dr_col
        bsr  map_cell
        bsr  dr_put
        ldab dr_col
        incb
        cmpb #8
        bne  .mc
        inc  dr_r
        ldaa dr_r
        cmpa #4
        bne  .lr
        jsr  strip_cells
        jmp  draw_msg

; map cell (dr_r, column B) -> A = character
map_cell:
        tst  v_flip
        bne  .bl
        ldaa #7                 ; top rank = 7 - 2r, file = column
        suba dr_r
        suba dr_r
        bra  .mk
.bl:    ldaa dr_r               ; top rank = 2r, file = 7 - column
        asla
        negb
        addb #7
.mk:    asla
        asla
        asla
        asla
        aba
        tab                     ; B = top square
        stab dr_sq
        jsr  sq_state
        ldab #3
        mul
        stab dr_t
        ldab dr_sq              ; the square below it on screen
        tst  v_flip
        bne  .b2
        subb #16
        bra  .b3
.b2:    addb #16
.b3:    jsr  sq_state
        adda dr_t
        tab
        ldx  #gtab
        abx
        ldaa 0,x
        rts

; A = character to cell dr_c, then dr_c + 1
dr_put: ldab dr_c
        ldx  #kv_cells
        abx
        staa 0,x
        inc  dr_c
        rts

; the split layout: ranks 8-5 on the left, 4-1 on the right
draw_split:
        clr  dr_c
        clr  dr_r
.lr:    ldaa #7                 ; left block (blk_sq turns it for Black)
        staa dr_top
        bsr  .half
        ldaa dr_r               ; the left rank's number
        clrb
        jsr  blk_sq
        tba
        lsra
        lsra
        lsra
        lsra
        adda #'1'
        bsr  dr_put
        ldaa #3
        staa dr_top
        bsr  .half
        ldab dr_c
        addb #3
        stab dr_c
        inc  dr_r
        ldaa dr_r
        cmpa #4
        bne  .lr
        jsr  strip_cells
        bra  draw_msg
.half:  clrb
.hc:    stab dr_col
        ldaa dr_r
        jsr  blk_sq
        jsr  sq_char
        bsr  dr_put
        ldab dr_col
        incb
        cmpb #8
        bne  .hc
        rts

; the message line: while msg_on, row 3 shows the 20 characters at msg_t
draw_msg:
        tst  msg_on
        beq  .x
        ldx  #msg_t
        ldab #60
.c:     ldaa 0,x
        pshx
        ldx  #kv_cells
        abx
        staa 0,x
        pulx
        inx
        incb
        cmpb #80
        bne  .c
.x:     rts

; draw and send
bshow:  jsr  draw
        jmp  scr_flush


; ---------------------------------------------------------------------
; Real-board mode (st_layout 2): for playing on a physical set. No board:
;   Black played
;   12... Qh4xe1+
;   Your move: E2_
;   W 04:31   B 05:02
; ---------------------------------------------------------------------
draw_real:
        jsr  scr_cls
        tst  g_n
        bne  .mv
        jsr  scr_pri
        fcl  "NEW GAME"
        bra  .you
.mv:    ldx  #rl_w              ; who played the last move
        tst  e_side
        bne  .wh
        ldx  #rl_b
.wh:    jsr  scr_puts
        jsr  scr_pri
        fcl  " PLAYED"
        ldaa #1
        clrb
        jsr  scr_at
        ldab g_n                ; its number: (plies + 1) / 2, one more if Black began
        tst  g_setup
        beq  .wb
        tst  g_spos+64
        beq  .wb
        incb
.wb:    incb
        lsrb
        clra
        jsr  num_str
        ldx  #kv_nbuf
        jsr  scr_puts
        ldx  #rl_dot1
        tst  e_side
        bne  .d
        ldx  #rl_dot3
.d:     jsr  scr_puts
        ldx  #st_p              ; the move: the strip's three parts
        jsr  scr_puts
        ldx  #st_p+4
        jsr  scr_puts
        ldx  #st_p3
        jsr  scr_puts
.you:   ldaa #2
        clrb
        jsr  scr_at
        tst  g_result
        bne  .clk
        jsr  scr_pri
        fcl  "YOUR MOVE: "
        ldx  #in_buf
        ldab in_n
        beq  .u
.t:     ldaa 0,x
        inx
        pshb
        pshx
        jsr  scr_putc
        pulx
        pulb
        decb
        bne  .t
.u:     ldaa in_n
        cmpa #4
        bhs  .clk
        ldaa #'_'
        jsr  scr_putc
.clk:   ldaa #3
        clrb
        jsr  scr_at
        tst  st_timing
        bne  .two
        jsr  scr_pri
        fcl  "NO CLOCK"
        jmp  draw_msg
.two:   ldaa #'W'
        ldx  #g_clk
        bsr  rl_clock
        ldaa #3
        ldab #10
        jsr  scr_at
        ldaa #'B'
        ldx  #g_clk+2
        bsr  rl_clock
        jmp  draw_msg

; A = 'W' or 'B', X = its clock: "W 04:31"
rl_clock:
        pshx
        jsr  scr_putc
        ldaa #' '
        jsr  scr_putc
        pulx
        ldd  0,x
        ldx  #20
        jsr  udiv               ; seconds
        ldx  #60
        jsr  udiv               ; minutes, kv_m3 = seconds
        ldx  #rl_buf
        bsr  num_2
        ldaa #':'
        staa 0,x
        inx
        ldd  kv_m3
        bsr  num_2
        ldaa #5
        staa rl_len
        ldx  #rl_len
        jmp  scr_puts

rl_w:   fcl  "WHITE"
rl_b:   fcl  "BLACK"
rl_dot1: fcl ". "
rl_dot3: fcl "... "
rl_len    = ZP2+29  
rl_buf    = ZP2+30  

; D -> two digits at X, X += 2 (D < 100)
num_2:  pshx
        jsr  num_str
        pulx
        ldaa kv_nbuf
        cmpa #2
        beq  .two
        ldaa #'0'
        staa 0,x
        ldaa kv_nbuf+1
        staa 1,x
        bra  .x
.two:   ldd  kv_nbuf+1
        std  0,x
.x:     inx
        inx
        rts
