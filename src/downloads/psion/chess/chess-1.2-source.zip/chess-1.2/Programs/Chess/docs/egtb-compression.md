# Endgame tables beyond KPK: can they be compressed enough for the pack?

Experiment, 16 Nov 2026. Code in `tools/egtb/`. Numbers in `tools/egtb/results/`. Nothing under
`src/`, `ref/`, `data/`, `tests/` or `build/` was changed.

## Short answer

- **Yes for the rook/queen-against-pawn and rook-against-minor endings, if only the strong side's
  table is stored.** At the root, the other side to move is worked out with a 1-ply search.
- **KQKP + KRKP + KRKB fits in about 133 KB.** KQKP + KRKP alone is 113 KB.
- **KPKP is too big alongside anything else.** It needs 107 KB even as a win/not-win bit.
- **KBNK distance-to-mate does not fit.** It needs about 520 KB, and even 8-move bands of DTM
  need 148 KB.

| ending | raw WDL, both sides (2 bits/pos) | best stored form | bytes on pack | avg probe | fits in 140K? |
|---|---|---|---|---|---|
| KQKP | 3,145,728 | WTM table + BTM pawn-on-7th slice, rest of BTM by 1-ply | **40.4K** (9.2K + 31.3K) | 8 ms (WTM), 69 ms (slice) | yes |
| KQKP | | both sides stored | 55.6K (9.2K + 46.4K) | 8 / 16 ms | yes |
| KRKP | 3,145,728 | WTM + BTM pawn-on-7th slice, rest by 1-ply | **72.8K** (40.5K + 32.3K) | 15 ms / 63 ms | yes |
| KRKP | | both sides stored | 132.0K (40.5K + 91.5K) | 15 / 39 ms | only alone |
| KRKB | 946,176 | WTM only, BTM by 1-ply | **19.8K** | 17-28 ms | yes |
| KRKB | | both sides | 42.4K | 17 ms | yes |
| KRKN | 946,176 | WTM only, BTM by 1-ply | **47.0K** | 34 ms | yes |
| KRKN | | both sides | 115.3K | 34 / 55 ms | only alone |
| KPKP | 1,179,648 (one table: BTM is the colour flip) | win/not-win bit; D vs L by 1-ply | **107.4K** | 54 ms | only alone, or with KRKB |
| KPKP | | full WDL | 243.8K | 81 ms | no |
| KBNK (DTM) | 2,838,528 (6 bits, both sides) | BTM DTM only (the strong side probes successors) | **522K** | 79 ms | no |

"WTM" means the side with the extra material (White in the table) is to move. "BTM" means the
other side is to move. "1-ply" means the probe generates the side to move's moves and probes
each successor in the stored table (details below). The block size is 4,096 entries (1 KB of
2-bit decoded data), and the totals include the block index and the Huffman tables.

**Combinations that fit in about 140K** (4,096-entry blocks; KPK's existing 24.5K `kpk.bin` is
assumed to be present already, because the 1-ply rules use it):

| combination | total |
|---|---|
| KQKP (WTM+slice) + KRKP (WTM+slice) + KRKB (WTM) | **133.0K** |
| KQKP + KRKP | 113.2K |
| KQKP (both sides) + KRKP (WTM+slice) | 128.4K |
| KQKP + KRKB + KRKN (all WTM-style) | 107.2K; adding KRKB BTM makes it 129.8K |
| KPKP win-bit + KRKB | 127.2K |
| everything except KBNK, WTM-style | 287K: does not fit |

With 8,192-entry blocks the first combination drops to about 121K. The cost is probes that take
about twice as long, and a 2K RAM buffer for the LZH-coded slices.

**Recommendation.** If the space is spent on tables, store **KQKP + KRKP (+ KRKB)**, WTM-style,
using HRLEc for the WTM tables and LZH for the pawn-on-7th slices. Those are common endings where
a 70-100 nodes/s engine misjudges races and fortresses. The expected root cost is about 1-1.5 s
when the engine has the strong side and under 0.1 s when it defends. Leave out KPKP and KBNK.
WDL only stops the engine throwing away a result; it does not by itself make the engine win
(see "Limits").

## 1. Generation (task 1)

`tools/egtb/solve.js` is a generic retrograde solver for up to 4 men. It works on an
unsymmetrised index (2 x 64^N entries, side to move x one square per piece) and computes
**distance-to-mate in plies**, which gives WDL. Its parts:

- **Initialisation.** Every legal position counts its in-table moves. Moves that leave the table
  (captures and promotions) are scored by probing the already-solved sub-table, flipping colours
  where needed.
- **Propagation.** Plies are processed level by level, using un-move generation (no
  un-captures or un-promotions are needed inside one table).
- **Promotions.** All four promotion pieces are generated. Every sub-ending is solved exactly by
  the same program: KQK, KRK, KBK, KNK, KPK, KQKQ, KQKR, KQKB, KQKN, KRKR, KRKB, KRKN, KBKB,
  KBKN, KNKN, KBKP, KNKP, KQKP, KRKP, KPKP and KBNK, 21 tables in all. There are no shortcut
  rules, and under-promotion and stalemate are handled.
- **Not modelled.** En passant, castling and the 50-move rule are ignored. The en passant
  effect is measured below.

Run time is about 1 minute per 4-man table including the check pass. The raw tables (about 35 MB
each, about 600 MB in all) live in a scratch folder (`EGTB_DIR`), not in the project.
`tools/egtb/run_all.sh` regenerates them.

**Statistics** (legal positions counted over the unsymmetrised index):

| ending | WTM win / draw / loss | BTM win / draw / loss | longest mate |
|---|---|---|---|
| KQKP | 99.37% / 0.63% / 40 pos | 7.7% / 12.1% / 80.2% | WTM win 28, BTM win 29 (via promotion) |
| KRKP | 91.4% / 8.4% / 0.17% | 16.4% / 17.5% / 66.1% | WTM win 26, BTM (pawn side) win 43 (promotes into KQKR) |
| KPKP | 43.2% / 33.5% / 23.4% | same (colour flip) | 33 |
| KRKB | 35.1% / 64.9% / 0 | 0 / 96.8% / 3.2% | 29 |
| KRKN | 48.3% / 51.7% / 8 pos | 32 pos / 89.1% / 10.9% | 40 |
| KBNK | 99.5% / 0.5% / 0 | 0 / 18.1% / 81.9% | 33 |

### Raw sizes (symmetry-reduced index, bytes)

| ending | entries per side to move | 1 bit (win / not), per side | 2 bits (WDL), per side | both sides, WDL |
|---|---|---|---|---|
| KRKB, KRKN | 1,892,352 (462 king pairs x 64 x 64) | 236,544 | 473,088 | 946,176 |
| KBNK | 1,892,352 | 236,544 | DTM 6 bits (0-33 moves + draw): 1,419,264 | DTM: 2,838,528 |
| KQKP, KRKP | 6,291,456 (pawn a-d x 64^3) | 786,432 | 1,572,864 | 3,145,728 |
| KPKP | 4,718,592 (24 x 48 x 64 x 64) | 589,824 | 1,179,648 | 1,179,648 (BTM is the colour flip) |

Losses for the side to move exist in every table on one side or the other (KRKB, KRKN and KBNK
only with the weaker side to move, apart from a handful of KRKN positions), so WDL needs 2 bits
unless the loss information is derived by 1 ply.

### Validation

- **Known longest mates all match:** KQK 10, KRK 16, KPK 28, KQKQ 13, KQKR 35, KQKB 17, KQKN 21,
  KRKB 29, KRKN 40, KBNK 33. The KRKB (35%/3%) and KRKN (48%/11%) win shares also match the
  figures usually quoted.
- **Bellman re-check, every table.** Every legal position of every table (about 18-25 million
  each) was re-scored from its successors after solving: 0 mismatches in all 21 tables
  (`results/run_all.log`). This uses the solver's own move generator.
- **Independent move generator.** `xcheck.py bellman` (python-chess) checked 20,000 random
  positions per table. The stored value must equal the best over python-chess's legal moves,
  with successors probed in our tables and mate/stalemate taken from python-chess. Result:
  0 mismatches in 19 tables (`results/bellman.log`).
- **KPK against the project's bitbase.** All 165,676 legal positions of `data/kpk.bin` (read
  only) agree with our KPvK: 0 disagreements.
- **Symmetry.** Before re-indexing, the raw tables were checked against all 8 board symmetries
  (pawnless) or the left-right mirror (pawn endings). There were 0 mismatches over 235M and 34M
  comparisons.
- **Stockfish spot checks.** 250 random positions per ending were checked. Positions with a
  capture or promotion available were excluded as trivial. Stockfish 19 had 0.4 s per position
  and reached an average depth of 27-75. A Stockfish result counts as W/L when it reports mate
  or |eval| ≥ 3.00, D when |eval| ≤ 1.00, and "unclear" in between.
  (`results/sfreport.txt`, `results/sf_*.json`)

  | ending | agree | unclear | disagree |
  |---|---|---|---|
  | KRKP | 250 | 0 | 0 |
  | KQKP | 250 | 0 | 0 |
  | KRKB | 250 | 0 | 0 |
  | KRKN | 247 | 3 | 0 |
  | KBNK | 241 | 9 | 0 |
  | KPKP | 249 | 0 | 1 |

  The KPKP disagreement (`8/8/8/8/2K3p1/8/2k4P/8 w`) is the en passant simplification: the
  table's win starts with h2-h4, which in real chess allows gxh3 e.p. Stockfish is right.
- **Mate distances against Stockfish.** In all 288 positions where Stockfish reported a mate, it
  was never shorter than the table's DTM, and 76% were equal.
- **En passant (KPKP only), estimated first-order impact.** 84,732 of 14.9M legal KPKP positions
  have a double push that lands beside the enemy pawn. Re-scoring that push with the e.p. reply
  allowed changes the WDL of 2,020 positions (0.014%). This is not propagated further, and the
  tables are not corrected.

## 2. Compression (task 2)

### Re-indexing

`norm.js` re-indexes each table per side to move:

- **Pawnless:** the White king goes into the 10-square a1-d1-d4 triangle, then Black king and the
  two pieces take 64 squares each, giving 2.6M entries. When the White king is on the diagonal and
  the Black king is above it, the entry is a duplicate and marked "free".
- **One pawn:** the pawn is mirrored to files a-d (24 squares), and the other three pieces take
  64 squares each, giving 6.3M entries.
- **KPKP:** the White pawn goes to files a-d (24), the Black pawn takes 48 squares and the kings
  64 each, giving 4.7M entries.

The 2.6M pawnless layout includes about 0.7M redundant or don't-care entries compared with the
462-king-pair index; they cost almost nothing after run-length coding.

### Freedom ("don't care") classes, filled to minimise the number of runs

Free entries are filled by a Viterbi pass over the alphabet that minimises runs, with a forced
break at each block start. The classes are:

1. **Illegal.** Overlapping pieces, adjacent kings, the side not to move in check, or a pawn on
   the 1st or 8th rank.
2. **Symmetric duplicates.**
3. **"Cheap capture decides".** The side to move has a capture that leaves 3 men or fewer and is
   at least as good as the true value. If that capture wins, the entry may hold any value. If it
   draws and the position is a draw, the entry may hold draw or loss. The probe then returns
   max(table value, best cheap capture). Cheap captures are scored by rule:
   - KQK/KRK: a win for the side with the piece if it is to move. Otherwise a loss for the bare
     king unless it can take the piece or is stalemated.
   - KPK: probed from the existing bitbase.
   - KBK, KNK, KK: draws.

   This class matters a lot for the strong side: KRKB WTM drops from 158K to 25K, KRKN WTM from
   145K to 56K and KQKP BTM from 136K to 54K (HRLE).

### Index orderings

All 24 orders of the four dimensions were tried, with rank-major and snake (boustrophedon)
square order. The Hilbert curve was tried once and was worse than snake. Snake saves 2-13%; the
choice of order matters up to 8x. Best orders found (outermost first):

| table | order |
|---|---|
| KQKP WTM | P, BK, Q, WK |
| KQKP BTM | P, Q, BK, WK |
| KRKP WTM | P, WK, BK, R |
| KRKP BTM | P, BK, R, WK |
| KRKB WTM | B, BK, WK, R |
| KRKB BTM | BK, R, B, WK |
| KRKN WTM | WK, N, BK, R |
| KRKN BTM | N, WK, BK, R |
| KPKP | WP, BP, BK, WK |
| KBNK BTM | B, N, WK, BK |

Full sweep: `results/perms_*.txt`, `results/best.json`.

### Schemes

Each block is decoded independently, and each block has a 2- or 3-byte offset in an index on the
pack.

- **HRLE.** Runs of equal values. Each run is one static-Huffman symbol (value, length class)
  plus extra bits. There are 4 direct length classes, then 2 classes per doubling.
- **HRLEc.** HRLE with one Huffman table per previous value (3-4 small tables). This is the best
  block-local scheme for most tables.
- **BRLE.** One byte per run (2-bit value, 6-bit length, with an escape). This is the simplest
  decoder, and the output is about 1.5-2x HRLEc.
- **LZSS.** Byte LZ77 on the 2-bit packed data, with the window limited to the block.
- **LZH.** LZ77 on the packed data with one static Huffman code per table for literals/lengths
  and one for distances (deflate-like, but with no per-block tables). It is best for the pawn
  slices and KRKP BTM, but it must rebuild the block in RAM (a 1 KB buffer at 4,096 entries).
- **HBYTE.** Static Huffman over the packed bytes. Poor (2-20x worse).

Totals in bytes (data + index + Huffman tables), 4,096-entry blocks, cheap-capture freedom on.
Other block sizes are in `results/summary.txt`.

| table | HRLE | HRLEc | BRLE | LZSS | LZH | HBYTE |
|---|---|---|---|---|---|---|
| KQKP WTM | 9,997 | **9,161** | 12,900 | 27,048 | - | 206,433 |
| KQKP BTM | 53,879 | **46,414** | 76,929 | 76,752 | 46,956 | 244,200 |
| KQKP BTM slice (pawn on 7th) | 43,268 | 36,664 | 62,045 | 47,838 | **31,273** | 66,843 |
| KRKP WTM | 45,354 | **40,516** | 63,062 | 84,335 | 51,534 | 242,120 |
| KRKP BTM | 171,785 | 150,105 | 224,817 | 136,206 | **91,468** | 349,867 |
| KRKP BTM slice | 61,039 | 53,295 | 85,839 | 46,253 | **32,288** | 89,779 |
| KRKB WTM | 24,771 | 20,790 | 36,980 | 33,313 | **19,769** | 99,925 |
| KRKB BTM | 26,591 | **22,639** | 38,434 | 44,846 | - | 97,009 |
| KRKN WTM | 56,489 | **47,000** | 86,988 | 87,022 | 54,133 | 128,238 |
| KRKN BTM | 84,919 | **68,270** | 142,142 | 122,553 | - | 127,709 |
| KPKP WDL | 281,420 | **243,827** | 394,445 | 269,281 | - | 436,213 |
| KPKP win-bit | 135,997 | 113,590 | 197,662 | 167,141 | **107,402** | 259,499 |
| KBNK BTM DTM (1,024-entry blocks) | **522,482** | - | - | 894,561 | - | 1,282,113 |

Notes on block size:

- 1,024-entry blocks cost 10-40% more than 4,096 (mostly the index).
- 8,192-entry blocks save 3-10% (KQKP WTM: 6.1K).

### Storing one side to move

The strong side's WTM table is always the smaller one (KQKP 9K against 46K, KRKN 47K against 68K).

**KRKB and KRKN.** BTM values come from a 1-ply search over Black's moves into the WTM table.
Black's captures of the rook become KBK/KNK draws.

**KQKP and KRKP.** The same works, except that a Black promotion leads into KQKQ/KRKQ etc., which
are not stored. The BTM entries with the pawn on its 7th rank (1/6 of the table) are therefore
kept as a separate "slice". Unfortunately the slice is the hard part: 31-32K, against 47K and 91K
for the whole BTM table.

**KPKP.** One table serves both sides, because BTM is the colour flip of WTM. Storing only "side
to move wins" halves the size. D and L are then told apart by 1 ply: the side to move loses iff
every move leads to a position whose flipped W-bit is set.

### Other attempts (not worth it)

| attempt | result |
|---|---|
| Piece-relative square order (e.g. knight sorted by distance from its king) | ±0% (KRKN) |
| Predicting each entry from the entry 1, 8 or 64 back, and run-coding the residual | worse: KRKN 67K against 47K; KPKP 250K against 244K |
| Every other slice along one dimension stored as "same as neighbour" residuals (2 probes) | worse in all 8 variants tried on KRKP WTM (47-89K against 40.5K) |
| DTM in coarse bands for KBNK | 4-move bands 250K, 8-move bands 148K |
| zlib deflate as a reference | whole table, no blocks: KRKN WTM 46.5K, KRKP WTM 30.3K, KRKP slice 24.5K, KPKP win-bit 85K |

The deflate figures show some long-range redundancy that block-local coders cannot reach.
Per-block deflate, with its own block headers, was worse than HRLEc.

## 3. Probe cost on the Psion (task 3)

Probe path:

1. Normalise by symmetry and compute the entry number.
2. Block = entry / 4096. Read the block's offset (2-3 bytes) from the index on the pack.
3. Stream the block from the pack and decode runs (HRLE) or tokens (LZH) until the entry is
   reached.
4. With the cheap-capture freedom, also generate the side to move's captures and score them by
   rule.

The reference decoder (`codec.js`) was checked end to end:

- **Decode check.** Every entry decodes to the filled value (0 mismatches).
- **Probe check.** 100-200K random legal raw positions per table were probed, through
  symmetry, decoder and capture rule, against the solved table: **0 mismatches** for all 13
  HRLE configurations run (`results/codec.jsonl`).
- **LZH.** The LZH token streams reproduce the same filled data exactly (0 mismatches), so LZH
  probes return the same values.

`codec.js` and `lzh.js` count the work up to the wanted entry: code bits, extra bits, runs or
tokens, and bytes consumed.

**Assumptions (not measured on the Organiser):**

- **Pack reads:** 1 ms per access (2 per probe) plus 30 µs per byte; the brief gave
  10-50 µs/byte.
- **CPU:** 0.92 MHz.
- **HRLE decoding:**
  - about 70 cycles per Huffman code bit. A canonical decoder costs about 50-78 cycles per bit
    (ASL/DEC/BNE bit fetch, ROL of a 16-bit code, SUBD/CMPB against the count for that length,
    then the first/index update).
  - 30 cycles per extra bit.
  - 80 cycles per run (symbol to value and class, base length, 16-bit add, compare).
- **LZH decoding:** 70 cycles per coded bit, 100 per token and 15 per output byte.
- **Fixed per probe:** 4,000 cycles (symmetry, 24-bit index arithmetic, capture test).
- **Accuracy:** treat all of these as ±50%.

Per-probe figures (`results/costs.md`, averages over random legal positions):

| table, scheme @4,096 | avg bytes read | avg cycles | avg ms | worst ms |
|---|---|---|---|---|
| KQKP WTM, HRLEc | 6 | 4,900 | 8 | 108 |
| KQKP BTM, HRLEc | 19 | 12,800 | 16 | 223 |
| KQKP BTM slice, LZH | 75 | 59,500 | 69 | 187 |
| KRKP WTM, HRLEc | 17 | 11,500 | 15 | 209 |
| KRKP BTM slice, LZH | 68 | 54,400 | 63 | 206 |
| KRKP BTM, LZH | 34 | 32,800 | 39 | 215 |
| KRKB WTM, HRLEc | 20 | 13,400 | 17 | 205 |
| KRKN WTM, HRLEc | 44 | 28,500 | 34 | 194 |
| KRKN BTM, HRLEc | 70 | 46,600 | 55 | 366 |
| KPKP win-bit, LZH | 55 | 46,500 | 54 | 194 |
| KPKP WDL, HRLEc | 108 | 69,400 | 81 | 556 |
| KBNK BTM DTM, HRLE @1,024 | 105 | 67,700 | 79 | 251 |

### Probes per root decision

`rootcost.js`, 3,000 random positions. The probe classifies every legal move. When the strong
side is to move with only WTM stored, each Black reply is probed and the probe stops at the first
reply that saves Black.

| ending | strong side to move: probes (avg / p90 / max) | ≈ time | defending side to move: probes | ≈ time |
|---|---|---|---|---|
| KRKB (WTM only) | 36 / 73 / 210 | 0.6 s (max ~3.6 s) | 13 | 0.2 s |
| KRKN (WTM only) | 53 / 112 / 213 | 1.8 s (max ~7 s) | 10 | 0.3 s |
| KQKP (WTM + slice) | 109 (4 of them slice) / 172 / 238 | 1.1 s (max ~2.5 s) | 5 | <0.1 s |
| KRKP (WTM + slice) | 82 (3 slice) / 141 / 202 | 1.4 s (max ~3.5 s) | 6 | <0.1 s |
| KPKP (WDL, flip) | 7 / 9 / 10 | 0.6 s | 7 | 0.6 s |
| KPKP win-bit | up to ~7 + 7x7 | ~1-3 s | same | |

The strong-side figure is cheaper in practice:

- One probe of the root (WTM) gives the root's value.
- Only the move the engine wants to play needs verifying (one Black-reply fan-out, about 5-15
  probes), falling back to the next move if that one gives the win away.
- Successive probes often hit the same block, and one cached block (1 KB) would remove many pack
  reads. Caching was not modelled.

### Decoder size (estimate, not written)

| part | estimate |
|---|---|
| HRLEc decoder: bit fetch, canonical Huffman, length classes, run loop, context switch | ~250 bytes |
| LZH extra: second Huffman table, copy loop | ~150 bytes |
| Symmetry/index glue | ~100 bytes, mostly shared between endings |
| Cheap-capture rule (KQK/KRK rule + `kpk.bin` probe, using the engine's attack and move generators) | ~150 bytes |
| 1-ply driver | ~100 bytes |
| **Total** | **~600-800 bytes of 6303 code** |

RAM needs:

- **Huffman tables:** 200-300 bytes while probing. They can be re-read from the pack instead.
- **Read buffer:** HRLE streams with a small buffer (32-64 bytes).
- **LZH output buffer:** the decoded block, 1 KB at 4,096 entries.

## Limits / what was not done

- **No 6303 code.** No decoder was written, assembled or timed on the emulator or the real
  Organiser. The cycle and pack-speed figures are the stated assumptions, and the decoder sizes
  are estimates.
- **WDL does not make the engine win.** WDL tables (all except KBNK) tell the root which moves
  keep the result. They do not say how to make progress. KRKN wins can take 40 moves and KRKP
  needs exact technique, so with WDL alone the engine can still shuffle, or run into the 50-move
  rule (also ignored by the tables). Turning wins into results needs DTM/DTZ or good evaluation
  inside the "winning moves only" set, and that was not measured.
- **KBNK DTM:** no scheme came near the budget. Not tried: storing a best move instead of a
  distance, or a dedicated KBNK mating procedure.
- **En passant** is ignored, and that is wrong in a measured 0.014% of KPKP positions. Castling
  and the 50-move rule are also ignored.
- **Space-saving ideas not explored:**
  - grammar/pair coding (Syzygy-style);
  - arithmetic coding;
  - a shared dictionary to exploit the long-range redundancy shown by whole-table deflate
    (about 25-35% possible on KRKP);
  - block caching;
  - fixed-compressed-size blocks.
- **Huffman table bytes.** The `codec.js` totals in `results/costs.md` leave out the Huffman
  table bytes (100-200 bytes); the scheme tables above include them.
- **Not integrated.** The tables are not built into the game or the engine, and no file format
  for the pack was fixed.

## Files

All files are in `tools/egtb/`.

| file | what it does |
|---|---|
| `lib.js` | geometry, material keys, raw layout, probing with colour flips |
| `solve.js` | retrograde DTM solver and Bellman re-check (`node solve.js KRvKP verify`) |
| `run_all.sh` | the 21 tables in dependency order; set `EGTB_DIR` to a scratch folder |
| `norm.js` | symmetry re-indexing, symmetry check, freedom classes |
| `compress.js` | ordering sweep (`perms`) and scheme comparison (`full`); env `SQORDER`, `PSLICE`, `BINARY`, `DTMDIV`, `REL` |
| `lzh.js`, `predict.js`, `xordiff.js`, `deflate_test.js` | other coders and reference figures |
| `codec.js` | HRLE encoder, reference decoder with operation counts, end-to-end probe check |
| `rootcost.js` | probes per root decision |
| `costs.py` | Psion cost model |
| `xcheck.py` | python-chess Bellman check and Stockfish spot checks |
| `xcheck_kpk.js` | comparison with `data/kpk.bin` |
| `epcheck.js` | en passant estimate |
| `sfreport.py`, `summary.py`, `best.py` | summaries |
| `sweep.sh`, `full_all.sh` | batch runs |
| `results/` | all logs and JSON behind the numbers above |
