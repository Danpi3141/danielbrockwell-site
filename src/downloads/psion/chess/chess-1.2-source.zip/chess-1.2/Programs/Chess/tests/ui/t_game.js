'use strict';
// Games through the screens with the real engine.
//   node tests/ui/t_game.js
const L = require('./lib.js');
const { check, keys } = L;
const DIG = { 1: 'U', 2: 'V', 3: 'W', 4: 'O', 5: 'P', 6: 'Q', 7: 'I', 8: 'J' };
const typeMove = (m, mv) => keys(m, [mv[0], DIG[mv[1]], mv[2], DIG[mv[3]]]);
const row = (m, r) => m.screen()[r];
const board = (m) => L.peekSym(m, 'e_board', 128);
const sq = (s) => (s.charCodeAt(1) - 49) * 16 + (s.charCodeAt(0) - 97);
const strip = (m) => [0, 1, 2].map((r) => row(m, r).slice(9, 12)).join('|');

function settingsLine(m, n, presses) {
  keys(m, ['ON']); m.runSeconds(1);
  keys(m, ['S', 'S', 'EXE']); m.runSeconds(1);
  for (let i = 0; i < n; i++) keys(m, ['DOWN']);
  for (const k of presses) keys(m, [k]);
  keys(m, ['ON']); L.idle(m);
}

// ---- two players: fool's mate and the result screen
let m = L.start();
L.idle(m);
settingsLine(m, 12, ['RIGHT']);           // TWO PLAYERS: ON
check(L.peekSym(m, 'g_mode')[0] === 1, 'two-player mode on', m);
for (const mv of ['F2F3', 'E7E5', 'G2G4']) { typeMove(m, mv); L.idle(m); }
typeMove(m, 'D8H4');
m.runSeconds(4);
check(L.peekSym(m, 'g_result')[0] === 2 && L.peekSym(m, 'g_reason')[0] === 1, "fool's mate: Black wins by checkmate", m);
check(m.screenText().includes('BLACK WINS') && m.screenText().includes('CHECKMATE'), 'result screen', m);
check(m.screenText().includes('AFTER 2 MOVES'), 'result screen: 2 moves', m);
keys(m, ['EXE']); m.runSeconds(2);                   // look at the board
check(strip(m) === ' Q | h4| # ', 'strip: Q h4 # (standard notation) [' + strip(m) + ']', m);
keys(m, ['DEL']); L.idle(m);                          // take back (one ply in two-player mode)
check(L.peekSym(m, 'g_n')[0] === 3 && L.peekSym(m, 'g_result')[0] === 0, 'take back after mate: 3 plies, game on', m);

// ---- under-promotion with capture: 1.a4 b5 2.axb5 a6 3.bxa6 Bb7 4.a7 Nf6 5.axb8=N
keys(m, ['ON']); m.runSeconds(1); keys(m, ['EXE']); L.idle(m);   // NEW GAME (two players kept)
for (const mv of ['A2A4', 'B7B5', 'A4B5', 'A7A6', 'B5A6', 'C8B7', 'A6A7', 'G8F6']) { typeMove(m, mv); L.idle(m); }
typeMove(m, 'A7B8');
m.runSeconds(2);
check(row(m, 3).includes('PROMOTE'), 'promotion asks Q R B N', m);
keys(m, ['N']); L.idle(m);
check(board(m)[sq('b8')] === 2, 'a7xb8 became a white knight', m);
check(strip(m) === ' a |xb8| =N', 'strip: a xb8 =N [' + strip(m) + ']', m);

// ---- ambiguity: knights on b1 and f3 can both go to d2 after ... (two players)
keys(m, ['ON']); m.runSeconds(1); keys(m, ['EXE']); L.idle(m);
for (const mv of ['G1F3', 'A7A6', 'D2D3', 'A6A5']) { typeMove(m, mv); L.idle(m); }
typeMove(m, 'F3D2'); L.idle(m);
check(strip(m) === ' Nf| d2|   ', 'disambiguation: Nfd2 [' + strip(m) + ']', m);

// ---- the computer: level 1, out of book, it thinks and answers
settingsLine(m, 12, ['LEFT']);            // TWO PLAYERS: OFF
settingsLine(m, 1, ['LEFT', 'LEFT', 'LEFT', 'LEFT', 'LEFT', 'LEFT']);  // level 7 -> 1
check(L.peekSym(m, 'st_level')[0] === 1, 'level 1 set', m);
keys(m, ['ON']); m.runSeconds(1); keys(m, ['EXE']); L.idle(m);   // new game
typeMove(m, 'H2H4');
let sawThink = false;
for (let i = 0; i < 200 && !sawThink; i++) { m.runTicks(2); if (/D ?\d/.test(row(m, 0).slice(9, 12))) sawThink = true; }
L.idle(m);
check(L.peekSym(m, 'g_n')[0] === 2, 'the computer answered 1.h4', m);
console.log('    (it showed', sawThink ? 'the thinking strip' : 'no thinking strip: a book move', '; depth', L.peekSym(m, 'e_depth')[0], ')');
console.log('all game tests passed');
