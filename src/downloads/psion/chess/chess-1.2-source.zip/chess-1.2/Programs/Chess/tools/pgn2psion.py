"""Convert PGN games into game files the Organiser's IMPORT GAME reads.

    python -E -P tools/pgn2psion.py games.pgn [--out folder] [--start 1] [--games 1-5,8]

Each game becomes GAMEn.ODB (n from --start, at most 99): plain text, CR LF line ends, one line a
record, which is how the Comms Link carries a data file (as RPDATA.ODB already travels). Receive
it on the Organiser as A:GAMEn. The lines:

    CHESSGAME
    <title: White v Black, year, up to 40 characters>
    START          or  S + 64 squares a1..h8 ('.' empty) + side (w/b) + castling (hex digit:
                   1 K, 2 Q, 4 k, 8 q) + en-passant square or -- + half-move clock (2 digits)
    e2e4 e7e5 ...  the main line as squares (promotions e7e8q), lines of up to 120 characters

Only the main line is kept (comments and variations are dropped). The game record on the
Organiser holds 250 plies, so a longer game is cut there (and the converter says so). Every move
is checked with python-chess, so a file it writes is always legal from its start.
"""
import argparse
import io
import os
import sys

import chess
import chess.pgn

MAX_PLIES = 250
LINE = 120
TITLE = 40


def title_of(g):
    h = g.headers
    def name(s):
        s = (s or '?').split(',')[0].strip()      # "Carlsen, Magnus" -> "Carlsen"
        return s if s and s != '?' else '?'
    t = '%s v %s' % (name(h.get('White')), name(h.get('Black')))
    year = (h.get('Date') or '????')[:4]
    if year.isdigit():
        t += ' ' + year
    t = ''.join(c for c in t if 32 <= ord(c) < 127 and c not in '"\t')
    return t[:TITLE]


def start_line(board):
    if board.fen() == chess.STARTING_FEN:
        return 'START'
    sq = ''
    for s in range(64):
        p = board.piece_at(s)
        sq += p.symbol() if p else '.'
    side = 'w' if board.turn == chess.WHITE else 'b'
    cas = 0
    if board.has_kingside_castling_rights(chess.WHITE):
        cas |= 1
    if board.has_queenside_castling_rights(chess.WHITE):
        cas |= 2
    if board.has_kingside_castling_rights(chess.BLACK):
        cas |= 4
    if board.has_queenside_castling_rights(chess.BLACK):
        cas |= 8
    ep = chess.square_name(board.ep_square) if board.ep_square is not None and board.has_legal_en_passant() else '--'
    half = min(board.halfmove_clock, 99)
    return 'S' + sq + side + '%X' % cas + ep + '%02d' % half


def convert(g):
    """-> (lines, plies, cut)"""
    board = g.board()
    if board.chess960:
        raise ValueError('Chess960 games are not supported')
    lines = ['CHESSGAME', title_of(g), start_line(board)]
    moves = []
    for m in g.mainline_moves():
        if len(moves) == MAX_PLIES:
            break
        moves.append(m.uci())
        board.push(m)
    cut = len(list(g.mainline_moves())) > MAX_PLIES
    cur = ''
    for u in moves:
        if cur and len(cur) + 1 + len(u) > LINE:
            lines.append(cur)
            cur = ''
        cur = (cur + ' ' + u) if cur else u
    if cur:
        lines.append(cur)
    return lines, len(moves), cut


def pick(spec, n):
    if not spec:
        return list(range(1, n + 1))
    out = []
    for part in spec.split(','):
        if '-' in part:
            a, b = part.split('-')
            out += range(int(a), int(b) + 1)
        else:
            out.append(int(part))
    return [i for i in out if 1 <= i <= n]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('pgn')
    ap.add_argument('--out', default='.')
    ap.add_argument('--start', type=int, default=1, help='first game file number (GAMEn), 1-99')
    ap.add_argument('--games', default='', help='which games of the PGN, e.g. 1-5,8 (default all)')
    a = ap.parse_args()
    text = open(a.pgn, encoding='utf-8', errors='replace').read()
    games = []
    f = io.StringIO(text)
    while True:
        g = chess.pgn.read_game(f)
        if g is None:
            break
        games.append(g)
    if not games:
        sys.exit('no games in ' + a.pgn)
    os.makedirs(a.out, exist_ok=True)
    num = a.start
    for i in pick(a.games, len(games)):
        g = games[i - 1]
        if g.errors:
            print('game %d: skipped, python-chess found errors: %s' % (i, g.errors[0]))
            continue
        if num > 99:
            print('game %d: skipped, GAME99 is the last name' % i)
            continue
        try:
            lines, plies, cut = convert(g)
        except ValueError as e:
            print('game %d: skipped, %s' % (i, e))
            continue
        path = os.path.join(a.out, 'GAME%d.ODB' % num)
        with open(path, 'w', encoding='ascii', newline='\r\n') as o:
            o.write('\n'.join(lines) + '\n')
        print('game %d -> %s  "%s"  %d plies%s' % (i, path, lines[1], plies,
              ' (cut at %d: the record holds no more)' % MAX_PLIES if cut else ''))
        num += 1


if __name__ == '__main__':
    main()
