#!/usr/bin/env python3
"""python-chess as a model for the UI soak test. Reads JSON on stdin:
    {"start": FEN or null, "moves": [uci, ...], "seed": n}
and prints JSON: whether every move was legal (and the first that was not), the FEN after
them (en passant square after every double step, as the engine keeps it), the game's status
under the engine's rules, SAN of the last move, and a random legal move for the next player.
"""
import json
import random
import sys

import chess

sys.path.insert(0, __file__.rsplit('\\', 1)[0].rsplit('/', 1)[0])
from gen_games import status  # noqa: E402


def main():
    q = json.load(sys.stdin)
    b = chess.Board(q.get('start') or chess.STARTING_FEN)
    san = ''
    for i, u in enumerate(q['moves']):
        mv = chess.Move.from_uci(u)
        if mv not in b.legal_moves:
            print(json.dumps({'legal': False, 'bad': i, 'fen': b.fen(en_passant='fen')}))
            return
        san = b.san(mv)
        b.push(mv)
    moves = list(b.legal_moves)
    rnd = random.Random(q.get('seed', 0))
    print(json.dumps({'legal': True, 'fen': b.fen(en_passant='fen'), 'fenl': b.fen(), 'status': status(b), 'san': san,
                      'next': rnd.choice(moves).uci() if moves else None, 'nlegal': len(moves)}))


if __name__ == '__main__':
    main()
