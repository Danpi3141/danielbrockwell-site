#!/bin/sh
# Solve every table needed, in dependency order, with the Bellman re-check.
# EGTB_DIR must point at a scratch folder (~35 MB per 4-man table).
cd "$(dirname "$0")"
for k in KQvK KRvK KBvK KNvK KPvK \
         KQvKQ KQvKR KQvKB KQvKN KRvKR KRvKB KRvKN KBvKB KBvKN KNvKN KBNvK \
         KQvKP KRvKP KBvKP KNvKP KPvKP; do
  node --max-old-space-size=4096 solve.js $k verify || exit 1
done
echo ALLDONE
