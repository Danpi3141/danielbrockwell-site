'use strict';
// Reading the position book (data/book.bin, tools/book/build_pbook.py) as the Psion does
// (src/screens/kbook.asm): by the engine's 24-bit key, the moves as indices into the legal list.
//   const P = require('./pbook.js'); P.moves(blob, engine) -> [[from, to], ...] (0x88) or []
const { legalMoves } = require('../../ref/search.js');

function entries(blob, key) {
  const b = key & 0xFF;
  let at = blob.readUInt16BE(2 * b);
  const end = blob.readUInt16BE(2 * b + 2);
  while (at + 3 <= end) {
    const chk = blob.readUInt16BE(at);
    at += 2;
    const idx = [];
    for (;;) { const m = blob[at++]; idx.push(m & 0x7F); if (!(m & 0x80)) break; }
    if (chk === key >>> 8) return idx;
  }
  return null;
}
function moves(blob, e) {
  const idx = entries(blob, e.key >>> 0);
  if (!idx) return [];
  const lm = legalMoves(e);
  return idx.filter((i) => i < lm.length).map((i) => lm[i]);
}
module.exports = { entries, moves };
