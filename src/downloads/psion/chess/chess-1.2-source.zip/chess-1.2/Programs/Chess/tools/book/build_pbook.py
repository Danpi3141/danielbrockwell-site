"""Position book: the opening book as positions where the Psion is to move, each with its move(s).

    python -E -P tools/book/build_pbook.py [--budget 15800] [--out data/book.bin]

Unlike the tree book (build_book.py, kept as data/book_v2_tree.bin), nothing is stored for the
opponent: after any reply the game looks the new position up by its key, so transpositions come
free and the space goes on the Psion's own moves. Format (block BK_BLOCK on the pack):

    0     257 big-endian words: the offset of each of 256 buckets' data, and of the end
    then  the buckets. A bucket holds the positions whose 24-bit key (the engine's e_key, the
          Psion's position key) has that low byte; each is 2 bytes, the key's high 16 bits, then
          its moves, one byte each: the move's index in the legal-move list (eng_legal's order,
          the game's lm_buf), bit 7 set when another move follows.

Which positions: best first by the chance a game reaches the position with the Psion to move
(the Psion picks among its book moves evenly; club players, 1200-1900, reply as often as they do
in the 2016-01 Lichess games, merged by position, so transpositions add up), until the budget.
The Psion's moves: as the tree book chose them (strong players' choices within 35 cp of
Stockfish at depth 16, else Stockfish's), with variety only early on: up to P_BY_MOVE[n] moves
at its n-th move, one after that. Then a post-pass: every book move is checked by Stockfish at
depth 22 (more than 50 cp worse than its best: replaced), and the likeliest positions just past
the book are played by the capped engine (ref/uci.js at the game's level 7): where its move loses
a pawn or more, the position goes into the book with Stockfish's move.
"""
import argparse
import heapq
import json
import os
import pickle
import subprocess
import sys
from collections import defaultdict

import chess

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, HERE)
import build_book as bb  # noqa: E402


def shown(p):
    """p for the report: relative to the repo, or just its name outside it (no home folder)."""
    p = os.path.abspath(p)
    if p.startswith(REPO + os.sep):
        return os.path.relpath(p, REPO).replace(os.sep, '/')
    return os.path.basename(p)


CHESS = bb.CHESS
BUDGET = 15800                    # bytes, the index included
RESERVE = 900                     # kept back for the post-pass's additions
P_BY_MOVE = {1: 3, 2: 2}          # the Psion's moves per position at its n-th move (else 1)
MIN_CLUB = 20                     # an opponent position needs this many club games to be followed
P22_LOSS = 50                     # a book move more than this below Stockfish's best (depth 22): replaced
EXIT_N = 2500                     # positions just past the book checked with the capped engine
EXIT_LOSS = 100                   # its move this much below Stockfish's best ...
EXIT_STILL_OK = 200               # ... unless the Psion is still this far ahead after it
REF_NODES = 2120                  # the game's level 7 (30 s) after the audit's 18% slow-down


def log(*a):
    bb.log(*a)


def p_moves(board, path, stats, sf, kmax):
    """The Psion's moves here: [uci], best first; [] if there is nothing to go on."""
    cands = bb.candidates(board, path, stats)
    if sf is None:
        passing = list(cands)
        if not passing:
            return []
    else:
        ent = sf.get(board.fen(), [u for u, _ in cands])
        best_u, best_cp = ent['best']
        passing = [(u, w) for u, w in cands if ent['moves'][u] >= best_cp - bb.SF_MARGIN]
        if not passing:
            return [best_u]
    passing.sort(key=lambda x: -x[1])
    top = passing[0][1]
    return [u for u, w in passing if w >= bb.P_REL * top][:kmax]


class Book:
    def __init__(self, stats, sf, budget):
        self.stats, self.sf, self.budget = stats, sf, budget
        self.w = defaultdict(float)            # epd -> chance of reaching it, the Psion to move
        self.path = {}                         # epd -> a move path from the start (uci)
        self.san = {}                          # epd -> the same in SAN (build_book's PREFER uses it)
        self.sel = {}                          # epd -> [uci] chosen
        self.heap, self.tick, self.used = [], 0, 514

    def reach(self, board, path, san, w):
        epd = board.epd()
        if epd not in self.path:
            self.path[epd] = list(path)
            self.san[epd] = list(san)
        self.w[epd] += w
        if epd not in self.sel:
            heapq.heappush(self.heap, (-self.w[epd], self.tick, epd))
            self.tick += 1

    def opponent(self, board, path, san, w):
        """The opponent to move: its club replies carry w on."""
        st = self.stats['club'].get(board.epd())
        if not st or st[0] < MIN_CLUB:
            return
        n, moves = st
        for u, c in moves.items():
            mv = chess.Move.from_uci(u)
            if mv not in board.legal_moves:
                continue
            s = board.san(mv)
            board.push(mv)
            self.reach(board, path + [u], san + [s], w * c / n)
            board.pop()

    def add(self, epd, moves):
        board = chess.Board(self.fen(epd))
        self.sel[epd] = moves
        self.used += 2 + len(moves)
        for u in moves:
            mv = chess.Move.from_uci(u)
            s = board.san(mv)
            board.push(mv)
            self.opponent(board, self.path[epd] + [u], self.san[epd] + [s], self.w[epd] / len(moves))
            board.pop()

    def fen(self, epd):
        b = chess.Board()
        for u in self.path[epd]:
            b.push(chess.Move.from_uci(u))
        return b.fen()

    def grow(self, limit):
        root = chess.Board()
        self.reach(root, [], [], 1.0)                  # the Psion White: its first move
        self.opponent(root, [], [], 1.0)               # the Psion Black: White's first moves
        while self.heap:
            negw, _, epd = heapq.heappop(self.heap)
            if epd in self.sel or -negw < self.w[epd] - 1e-12:
                continue                               # (a stale entry: a fresher one is queued)
            board = chess.Board(self.fen(epd))
            if board.is_game_over():
                continue
            kmax = P_BY_MOVE.get(board.fullmove_number, 1)
            moves = p_moves(board, self.san[epd], self.stats, self.sf, kmax)
            if not moves:
                continue
            if self.used + 2 + len(moves) > limit:
                heapq.heappush(self.heap, (negw, 0, epd))
                break
            self.add(epd, moves)

    def frontier(self, n):
        """The likeliest positions with the Psion to move that are not in the book."""
        seen, out = set(), []
        for negw, _, epd in sorted(self.heap):
            if epd in self.sel or epd in seen:
                continue
            seen.add(epd)
            out.append(epd)
            if len(out) == n:
                break
        return out

    def coverage(self):
        """Chance the Psion's n-th move comes from the book, as White and as Black."""
        cov = {True: defaultdict(float), False: defaultdict(float)}
        for epd in self.sel:
            b = chess.Board(self.fen(epd))
            cov[b.turn][b.fullmove_number] += self.w[epd]
        return cov


def keys_and_indices(book):
    """Run pbook_keys.js: {epd: (key, [idx])}."""
    epds = list(book.sel)
    lines = '\n'.join(json.dumps({'path': book.path[e], 'moves': book.sel[e]}) for e in epds) + '\n'
    p = subprocess.run(['node', os.path.join(HERE, 'pbook_keys.js')], input=lines, capture_output=True, text=True, check=True)
    res = [json.loads(l) for l in p.stdout.split('\n') if l.strip()]
    return {e: (r['key'], r['idx'], r['n']) for e, r in zip(epds, res)}


def write(book, ki, out):
    buckets = defaultdict(list)
    seen = {}
    dropped = 0
    for epd, moves in sorted(book.sel.items(), key=lambda kv: -book.w[kv[0]]):
        key, idx, n = ki[epd]
        if any(i < 0 or i > 126 for i in idx):
            dropped += 1
            continue
        if key in seen:                                # two positions, one key: the likelier stays
            dropped += 1
            continue
        seen[key] = epd
        body = bytes([(i | 0x80) if j < len(idx) - 1 else i for j, i in enumerate(idx)])
        buckets[key & 0xFF].append(bytes([key >> 16, (key >> 8) & 0xFF]) + body)
    data = bytearray()
    offs = []
    for b in range(256):
        offs.append(514 + len(data))
        for ent in buckets[b]:
            data += ent
    offs.append(514 + len(data))
    blob = b''.join(o.to_bytes(2, 'big') for o in offs) + bytes(data)
    tmp = out + '.tmp'
    with open(tmp, 'wb') as f:
        f.write(blob)
    os.replace(tmp, out)
    return blob, seen, dropped


def read_back(blob, key):
    """The moves stored for a key (as the Psion reads them), or None."""
    b = key & 0xFF
    at, end = int.from_bytes(blob[2 * b:2 * b + 2], 'big'), int.from_bytes(blob[2 * b + 2:2 * b + 4], 'big')
    while at < end:
        chk = (blob[at] << 8) | blob[at + 1]
        at += 2
        moves = []
        while True:
            m = blob[at]
            at += 1
            moves.append(m & 0x7F)
            if not m & 0x80:
                break
        if chk == key >> 8:
            return moves
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--budget', type=int, default=BUDGET)
    ap.add_argument('--out', default=os.path.join(bb.DATA, 'book.bin'))
    ap.add_argument('--no-post', action='store_true')
    a = ap.parse_args()
    stats = pickle.load(open(bb.STATS, 'rb'))
    log('stats: %d club positions, %d strong' % (len(stats['club']), len(stats['strong'])))
    limit = a.budget - (0 if a.no_post else RESERVE)
    # pass 1 (popularity only) finds the positions; Stockfish checks their candidates; pass 2 chooses
    b1 = Book(stats, None, limit)
    b1.grow(int(limit * 1.3))
    sf = bb.Stockfish()
    jobs = []
    for epd in b1.sel:
        board = chess.Board(b1.fen(epd))
        jobs.append((board.fen(), [u for u, _ in bb.candidates(board, b1.san[epd], stats)]))
    sf.batch(jobs)
    book = Book(stats, sf, limit)
    book.grow(limit)
    log('pass 2: %d positions, %d bytes' % (len(book.sel), book.used))
    post = defaultdict(int)
    if not a.no_post:
        sf22 = bb.Stockfish(depth=22, path=os.path.join(bb.CACHE, 'sf22.json'))
        sf22.batch([(book.fen(e), list(m)) for e, m in book.sel.items()])
        for epd, moves in list(book.sel.items()):
            ent = sf22.get(book.fen(epd), list(moves))
            best_u, best_cp = ent['best']
            keep = [u for u in moves if ent['moves'][u] >= best_cp - P22_LOSS]
            if len(keep) < len(moves):
                post['book moves replaced or dropped'] += len(moves) - len(keep)
            if not keep:
                keep = [best_u]
            book.used += len(keep) - len(moves)
            book.sel[epd] = keep
        # exits: the capped engine's move in the likeliest positions just past the book
        bb.REF_NODES = REF_NODES
        front = book.frontier(EXIT_N)
        ref = bb.RefPool()
        engine = ref.moves([tuple(book.path[e]) for e in front])
        ref.close()
        sf22.batch([(book.fen(e), [engine[tuple(book.path[e])]]) for e in front])
        bad = []
        for e in front:
            mv = engine[tuple(book.path[e])]
            ent = sf22.get(book.fen(e), [mv])
            best_u, best_cp = ent['best']
            loss = best_cp - ent['moves'][mv]
            post['exits checked'] += 1
            if loss >= EXIT_LOSS and ent['moves'][mv] <= EXIT_STILL_OK:
                bad.append((book.w[e], e, best_u))
        post['bad exits'] = len(bad)
        for w, e, u in sorted(bad, reverse=True):
            if book.used + 3 > a.budget:
                break
            book.sel[e] = [u]
            book.used += 3
            post['bad exits fixed (Stockfish move added)'] += 1
        sf22.close()
    sf.close()
    if a.out == os.path.join(bb.DATA, 'book.bin') and os.path.exists(a.out) and not os.path.exists(os.path.join(bb.DATA, 'book_v2_tree.bin')):
        import shutil
        shutil.copyfile(a.out, os.path.join(bb.DATA, 'book_v2_tree.bin'))   # the tree book, kept
    ki = keys_and_indices(book)
    blob, seen, dropped = write(book, ki, a.out)
    # check: every stored position reads back as written
    bad = sum(1 for k, e in seen.items() if read_back(blob, k) != ki[e][1])
    cov = book.coverage()
    lines = ['Position book report', '', 'file: %s' % shown(a.out), 'bytes: %d (budget %d)' % (len(blob), a.budget),
             'positions: %d (White to move %d, Black %d); moves %d; dropped (key clash or index) %d; read-back errors %d' % (
                 len(seen), sum(1 for e in seen.values() if ' w ' in e), sum(1 for e in seen.values() if ' b ' in e),
                 sum(len(book.sel[e]) for e in seen.values()), dropped, bad),
             'post-pass: ' + ', '.join('%s %d' % kv for kv in post.items()), '',
             'Chance the Psion\'s n-th move comes from the book (club opponents; tree book from docs/audit-book.md):']
    for colour, name, old in ((True, 'White', {4: 68.8, 6: 15.7, 8: 1.8}), (False, 'Black', {4: 33.1, 6: 4.6, 8: 1.0})):
        lines.append('  %s: ' % name + '  '.join('move %d %.1f%%' % (n, 100 * cov[colour][n]) + (' (tree %.1f%%)' % old[n] if n in old else '')
                                                 for n in range(1, 13) if cov[colour][n] > 0))
    open(os.path.join(os.path.dirname(a.out), 'book_report.txt') if a.out.endswith('book.bin') else a.out + '.txt', 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
    print('\n'.join(lines))
    if bad:
        sys.exit(1)


if __name__ == '__main__':
    main()
