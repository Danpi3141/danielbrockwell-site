# Engine audit (16 Nov 2026)

The user asked for seven checks. They ran on the JS reference (`ref/`) and on the 6303 engine
(`src/engine/`), the latter on the emulated LZ64 through `tests/engine/harness.js`. Every engine
change went into both. The parity tests (`t_search`, `t_fuzz`, `t_eval`, `t_api`, `t_game`, plus
the new ones below) match node for node after each change.

Where the tools are:
- `tools/audit/`: the audit's tools.
- `tools/audit/snap_before/`: a copy of `ref/` before the audit, used for the before/after numbers.
- `tools/match/snap_audit/`: a snapshot of the final `ref/`.
- `tests/engine/`: the new engine tests.

**Overall result.**
- **Bugs found and fixed:**
  - a missed threefold repetition;
  - a 1 cp colour asymmetry;
  - levels 1-4 allowing mate in one and stalemating won endings;
  - an unlimited level 1-4 "margin pass" that could hang;
  - depth 1, which always finishes, running for minutes in rare positions;
  - a 256-node delay before the first clock read.
- Bishop + knight mates rose from about 46% to about 80% of random starts. K+Q v K mates went from 87-90% to 100%.
- **Strength at 2,500 nodes:** +42 Elo [+15, +69] against the pre-audit engine. With nodes scaled to equal time it is −11 [−39, +15], which rules out a big loss.
- **Engine size:** +103 bytes of code and tables; RAM array 21,328 bytes with the 512-entry TT (see *Sizes*).

## Engine changes

Each change is listed with its own byte cost. The cost was measured by assembling the final engine
with only that change reverted (`percost.py` in the audit's scratch folder). It is listed with its own
measured effect. The costs add up to 132; the total is 103, because two dead tables (−21) were
removed and the costs interact by 8 bytes.

| # | Change | Bytes | Effect (measured) | Files |
|---|---|---|---|---|
| 1 | **En passant square only when an enemy pawn stands beside** the pawn that moved two squares. The key no longer differs between the position right after a double push and the same position later. | +26 | Threefold now detected as FIDE and python-chess do: 1 hand-made case and 4 of 300 random games failed before, 0 after (check 2) | `ref/engine.js` make; `emove.asm` `.sep` |
| 2 | **Taper rounds towards zero** instead of down | +5 | Colour-flipped twins: 7,784 of 13,708 pairs differed by 1 cp before, 0 after (check 3) | `ref/search.js` evaluate; `eeval.asm` `.tz` |
| 3 | **Margin pass, depth 0: a probe** (a depth-1 search of the reply with the window mate bound to infinity) gives each root move its score when it is a mate either way or a draw (stalemate, repetition) | +34 | Levels 1-4 allowing mate in one: 189/169/159/156 of 1,200 → 0/0/0/0 (check 5). Stalemating won endings at levels 1-4: seen before, 0 after (check 7) | `ref/search.js` think; `esearch.asm` `e_marg` |
| 4 | **Margin pass budget:** it was unlimited, and it hung after the TT let the deepening reach depth 17 in 50 nodes. Now it gets a fresh budget of 8× the level's time or nodes (`eng_think` multiplies `e_tlim`/`e_nlim` in place). When the budget runs out or a key is pressed it picks among the moves scored so far. Before, a key left the rest of the moves scored 0, and they could be chosen. | +29 | No hang. Pass time ≤ 8× the level's (worst seen 26.9 s at level 4, 3 s). Before: median 3×, 90th percentile 20×, maximum 225× at level 1, and unbounded | same |
| 5 | **Margin pass window** (best so far − margin, ∞): a move that cannot become a candidate needs no exact score | +10 | Pass cost at level 4: median 1.9× → 1.2× of the level's budget, 90th percentile 7.2× → 3.5× | same |
| 6 | **Mop-up weights:** edge 20 → 16, king proximity 6 → 20, B+N corner 5 → 7 | 0 | KBNK 46/100 → 80/100 and 20/50 → 38/50; KQK 87/100 → 100/100 (check 7) | `ref/search.js` mopup; `eeval.asm` `ev_mop` |
| 7 | **First clock read after 32 nodes, not 256** | +2 | A 1 s limit with a slow depth 2 went from 2.53 s to 1.09 s (check 6). No effect on node counts | `esearch.asm` `eng_think` |
| 8 | **Quiescence: a capture by a higher piece type onto a square the opponent defends is not tried** (tested after the capture is made) | +26 | Depth 1, which always finishes, needed up to 44,176 nodes (minutes on the Psion); now at most 1,494. At 99.9% of positions it needed 2,852 and now 549. Strength at 2,500 nodes: +42 [+15, +69]. Nodes per second drop by ~18%: on t_search's 16 positions, 104 → 85 on the bare CPU. At equal time: −11 [−39, +15] | `ref/search.js` qsearch; `esearch.asm` `e_qs` |
| 9 | **Dead code removed:** `ev_above` and `ev_below` (16 bytes) and `ev_tab` (5 bytes) were never referenced. Found by the coordinator's hint and an engine coverage run (`tools/audit/engcover.js` with `CHESS_COVER`). | −21 | No behaviour change; parity tests pass | `eeval.asm` |

**Development order.** Changes 1, 2, 3, 6, 5, 4, 7, 8 and 9 were made in that order. The parity
suite (`tools/audit/parity.sh`) was run after each step, except that 6 and 7 were folded into the
next run. A few intermediate variants were measured and reverted:
- **pass budget 1×:** it made levels 1-2 play their depth-1 best move, and L2 v L1 fell to 52%;
- **running the pass also at margin 0 when only depth 1 finished:** it cost level 5 twelve points on the mate-in-2 set;
- **a quiescence early return at the mate bound:** it gave no measurable gain.

`think()` in `ref/search.js` also got an optional `soft` argument: stop deepening once half the
node limit is used. This is the Psion's half-time rule, with nodes standing in for time. It is off
by default and only tools use it. `src/engine/API.md` documents the pass budget, and that
`e_tlim`/`e_nlim` must be set before each call.

## Sizes

| | Before | After |
|---|---|---|
| Engine test image (code + tables + test drivers; vars not included) | 13,251 | 13,354 (+103) |
| Persistent engine variables | 484 | 484 |
| Scratch | 2,908 | 2,908 (limit 2,912) |
| `python tools/build.py --out <scratch>`: RAM array with the 512-entry TT | 21,232 | **21,328** (kernel+engine code 13,219, variables 1,105, slot A 2,908) |

The array figure also includes the kernel/screen changes other agents made during the audit, so
only the engine row is the engine's own growth. The coordinator gives the measured ceiling for the
512-entry TT as about 21,392 bytes.

## 1. Move counts on awkward positions

**Commands.**
```
python -E -P tools/audit/gen_perft.py          # python-chess counts -> tests/engine/data/perft_extra.json
node tests/engine/t_perft2.js [asmLimit=2000] [jsLimit=3e6]
```
**Positions (58).** The expected counts come from python-chess, an independent generator, never from memory or from the engine. The positions are:
- en passant that would expose the king: horizontal, diagonal, on the file, with the rook on either side;
- en passant out of check, taking the checking pawn, or blocking a check;
- castling that gives check, with rights for a missing rook, rook moved or captured, path attacked or occupied;
- promotions with capture, out of check, giving check, under-promotion;
- discovered checks, stalemate traps, knight endings;
- the 218-move position;
- the perft-suite middlegames.

**Results: no failures.**
- JS: 285 depths, counts up to 3 million (11 million in a run without the limit).
- Assembler: 202 depths, 752,455 leaves.
- With `asmLimit` 20,000 the assembler also matched 233 depths and 3.09 M leaves. Five walks hit the harness's 600 s emulated cap, a test limit, not an engine fault.
- `eng_legal` gives the right count in all 58 positions, including the 218-move one (its list holds 220).
- The 218-move position is walked only to depth 2: deeper, the 400-entry move stack is cut short by design. JS and assembler agree on the cut count at depth 3 (16,637, against the true 19,073).

`run_all.js` runs `t_perft2.js 2000` (300 in `--quick`).

## 2. Special cases through the engine API, against python-chess

**Commands.**
```
python -E -P tools/audit/gen_rules.py 300 1    # oracle -> tests/engine/data/rules_oracle.json
node tests/engine/t_rules.js [maxGames]
```
The test drives the UI's routines: `eng_setup`, `eng_find`, `eng_play`, `eng_legal`, `eng_check` and `eng_status`.

**76 special cases.** Each compares with python-chess:
- the full legal list;
- named moves that must be allowed or refused, through `eng_find`;
- check and status;
- after the moves: board, side to move, castling rights, en-passant square and half-move clock.

The cases:
- **Castling:**
  - both ways;
  - refused out of, through and into check;
  - allowed with b1 attacked, and with both rooks attacked;
  - refused with b1 occupied, with the rook missing (right still set), and with an enemy rook on the corner;
  - rights lost by capture of the rook, or by the king or rook going away and back;
  - the rook moves with the king (White short, Black long).
- **En passant:**
  - allowed, and only immediately;
  - refused for a horizontal pin (both sides), a diagonal pin, and a pawn pinned on the file;
  - allowed out of check, taking the checking pawn or blocking;
  - not out of a piece's check;
  - White en passant out of check.
- **Promotion:** all four pieces with and without capture, for both colours; promotion out of check.
- **Mate and stalemate:** back rank, smothered, several stalemates, a pinned rook that can still move.
- **Fifty-move rule:**
  - 99 half-moves is still playing; the 100th half-move ends it;
  - **mate on the 100th half-move is mate**, and stalemate on it is stalemate;
  - a capture or pawn move on the 100th resets the clock; 120 half-moves.
- **Threefold:**
  - knight shuffles; only twice; the other side to move;
  - lost castling rights: earlier positions don't count, threefold from then on;
  - a capture in between;
  - after a double push with no en passant possible;
  - when the first occurrence had en passant possible, and after that chance has gone.
- **Too little material:** K v K, K+N v K, K+B v K, a capture leaving these; K+N+N v K and B v N play on; K+P v K.

**Random games:** 300 games, 39,470 positions. They are biased towards castling (142), en passant (95), promotions (539) and checks, and towards repetition. At every ply the legal list (count and an FNV hash of the sorted UCI list), check and status must match.

**Failure found and fixed (change 1).**
- **Threefold after a double pawn push.** The key included the en-passant square whenever a pawn moved two squares, so the position right after e.g. `e2e4` never matched the identical later positions.
- Before: the hand-made case and 4 random games gave status 0 where python-chess says threefold.
- After: all 76 cases and all 39,470 positions match, with the final engine.

**Not changed (reported).**
- **Bishops on one colour only** (a dead position under FIDE rules and for python-chess) is not called a draw. "Too little material" is no pawns, rooks or queens and at most one minor in all. Such games end by the fifty-move rule. In the 7,744 soak games no game reached such a position.
- **In the search,** the fifty-move test comes before mate detection, so a mate delivered on the 100th half-move is scored as a draw while searching. `eng_status` gets it right.
- **En passant with a pinned capturer:** when an enemy pawn stands beside but the capture would be illegal (pinned), the key keeps the en-passant square while python-chess's does not. No test position hit this.
- **Set-up positions** keep a castling right for a missing rook. Castling is still refused, because generation checks for the rook.

`run_all.js` runs `t_rules.js 100` (20 in `--quick`).

## 3. Mirror test

**Command.** `node tests/engine/t_mirror.js [games=60]`
- 13,708 positions: random games, plus 1,500 random bare-king and pawn endings.
- Each is compared with its colour-flipped twin: ranks mirrored, colours and side to move swapped, castling and en passant flipped. The evaluation is from the side to move's view, in JS and in the assembler.

**Failure found and fixed (change 2).**
- **7,784 pairs differed, all by exactly ±1 cp:** the blend `(mg·ph + eg·(16−ph)) >> 4` floored.
- After the fix, 0 differ in JS, 0 in the assembler, and the assembler equals the JS on all of them.
- Pawn structure, bishop pair, endgame rules, mop-up and the B+N corner were already symmetric.

**Left-right flip** (positions without castling rights): 8,873 of 11,813 differ, by up to 219 cp. This
is intended: PeSTO's piece-square tables, in particular for kings and pawns, are not left-right
symmetric, and the engine uses them as published.

`run_all.js` runs `t_mirror.js 60` (15 in `--quick`).

## 4. Tactics

**Commands.**
```
python -E -P tools/audit/make_tactics.py 100 4      # -> tools/audit/tactics.json (Stockfish 19)
node tools/audit/tactics.js [engineDir|-] [seeds=3] [asmPositions]
```
**Problem set.** Built with Stockfish: a depth-10 MultiPV 2 screen, confirmed at depth 18.
- **100 win-a-piece positions,** from 6,875 Lichess game-cache positions (`tools/book/cache/games.txt`, plies 8-24). One move is ≥ 300 cp better than every other, with a score of 200-2,000 cp.
- **100 mate-in-2 positions,** taken from the 2-6 plies before mates in low-level self-play games. Real games' first 24 plies had none in 1,300 positions. A position counts as solved when the move played is any move that mates in ≤ 2 (MultiPV 8).

**Levels.** As in `src/kernel/kcore.asm`, reproduced in `tools/audit/levels.js`:
- 1, 1, 2, 3, 5, 10, 30 and 100 s for levels 1-8, at 100 nodes a second;
- the engine stops at the limit after depth 1, and starts no new depth after half of it;
- margins of 300, 150, 70 and 30 cp for levels 1-4;
- levels 1-4 are tried with 3 random seeds per position.

| Level | Nodes | Margin | Mate in 2: before → after | Win a piece: before → after |
|---|---|---|---|---|
| 1 | 100 | 300 | 26% → 24% | 62% → 61% |
| 2 | 100 | 150 | 32% → 32% | 75% → 74% |
| 3 | 200 | 70 | 37% → 39% | 84% → 83% |
| 4 | 300 | 30 | 44% → 43% | 87% → 88% |
| 5 | 500 | 0 | 78% → 80% | 89% → 93% |
| 6 | 1,000 | 0 | 84% → 87% | 92% → 96% |
| 7 | 3,000 | 0 | 97% → 97% | 99% → 99% |
| 8 | 10,000 | 0 | 98% → 98% | 100% → 100% |

**Assembler spot check.** `tactics.js - 1 8` ran 8 positions × 8 levels = 64 thinks on the assembler. Each used the level's node count and margin with a hard node limit, because the half-time rule needs the clock. All 64 matched the JS in move, score, depth and nodes, on the final engine.

## 5. Level order, and mate in one at the random-margin levels

**Matches.**
```
node tools/audit/match_levels.js NAME L<a> L<b> --workers 5
```
- JS self-play over the 242 openings of `tools/match/openings.txt`, each with both colours: 484 games a match.
- Adjudicated drawn at 300 plies. The TT is kept for the whole game, and each game has its own seed.
- The 95% interval is pentanomial: an opening's two games are taken as a pair.
- Final engine:

| Match | Higher level's score | Elo [95%] |
|---|---|---|
| L2 v L1 | 85.2% (+381 =63 −40) | +304 [+271, +343] |
| L3 v L2 | 86.0% (+394 =44 −46) | +315 [+277, +359] |
| L4 v L3 | 86.0% (+400 =32 −52) | +315 [+276, +360] |
| L5 v L4 | 92.8% (+438 =22 −24) | +443 [+394, +508] |
| L6 v L5 | 67.3% (+292 =67 −125) | +125 [+95, +157] |
| L7 v L6 | 84.0% (+385 =43 −56) | +288 [+253, +328] |
| L8 v L7 | 74.9% (+321 =83 −80) | +190 [+160, +223] |

**Every level beats the one below,** with the whole interval above zero. Self-play exaggerates the gaps.

**Mate in one.** `node tools/audit/mate1.js [engineDir|-] 300 4 1,2,3,4,5,6`
- 300 positions from low-level self-play, always generated with the pre-audit engine, so both engines see the same set.
- In each, some legal moves allow a mate in one and some don't. Each level plays each position with 4 seeds.

| Level | Before | After |
|---|---|---|
| 1 | 189 of 1,200 moves (97 positions) | 0 |
| 2 | 169 (89) | 0 |
| 3 | 159 (72) | 0 |
| 4 | 156 (63) | 0 |
| 5 (no margin) | 16 (4) | 4 (1) |
| 6 (no margin) | 4 (1) | 0 |

**Cause.** Levels 1-4 pick at random among root moves scored one ply shallower than the deepening. At 100-300 nodes the deepening usually finishes depth 1 only, so the scoring is at depth 0 (quiescence), which cannot see a reply's mate. Change 3 adds the probe at depth 0; at depth ≥ 1 the check extension already sees it.

**What remains.**
- **Level 5:** one position where only depth 1 finished, and depth 1 cannot see a reply's mate.
- **Levels 1-2:** after change 4, a cut-off pass can in principle pick among scored moves that are all mated while an unscored move is safe. This was seen once (1 position, 4 seeds) in an intermediate run and not in the final one.

**The hang (change 4).** With the old engine, a level-2 game reached K+Q+B v K. The TT let the deepening reach depth 17 in 50 nodes, and the margin pass then searched depth 16 with no limit and never finished. `tools/audit/passcost.js` shows the old pass cost, as multiples of the level's budget at level 1: median 3×, 90th percentile 20×, maximum 225×. On the Psion that is time on top of the level's.

## 6. Soak

**JS.** `tools/audit/soak.sh`:
- **Games:** self-play with mixed node limits and margins: N1 v N2500, N30M300 v N600M30, N5000 v N800M70, N150 v N150M150, N60M70 v N3000.
- **Check:** `check_games.py` replays every game with python-chess, including the level matches' games.
- It verifies that:
  - every move is legal;
  - no move is played after the game has ended;
  - the end and its reason are right (mate, stalemate, 100 half-moves, threefold, too little material).
- **Result before change 8:** 7,744 games, 871,143 moves: **0 bad, 0 engine errors, 0 crashes.** Ends: checkmate 7,092, threefold 241, stalemate 95, adjudicated 178, fifty 69, too little material 69.
- **The final run** is in *Final state*.

**Assembler.** `node tests/engine/t_soak_asm.js 16 3 160`:
- Whole games, the assembler against itself, from the match openings, with node limits of 60-800 and margins of 0 or 30-300.
- They are compared with the JS move by move: move, score, depth, nodes, and `eng_status` and `eng_check` every ply.
- **Result:** 16 games, 1,795 engine moves, 3.6 emulated hours of thinking; all match (14 mates, 2 reached the 160-ply cap). This was the engine with change 8; change 9 only removed dead code.
- `run_all.js` runs 4 shorter games.

**Time limits with the OS running.** `node tests/engine/t_time2.js 12 10`:
- 96 timed thinks at the levels' limits (1, 2, 3, 5, 10 s), with and without the levels 1-4 margin, interrupts on.
- **Found:** the first clock read came only after 256 nodes. A 1 s limit, with a depth 2 of 200 nodes, ran to 2.53 s. Change 7 brings it to 1.09 s.
- **Final worst overruns:**
  - **once depth 1 had finished:** 0.62 s (10 s limit). The clock is read every 32 nodes.
  - **while depth 1 finishes (by design):** 1.81 s (1 s limit, Kiwipete; 4.73 s before change 8).
  - **with a margin (levels 1-4):** the pass adds up to 8× the limit, worst 23.9 s at level 4 (3 s) in Kiwipete. Before change 4 it was unbounded.

**Depth 1 cannot run long any more (change 8).** `node tools/audit/depth1.js 30000` measures depth-1 nodes over 30,000 positions from the audit's games:

| | Median | 99% | 99.9% | Maximum |
|---|---|---|---|---|
| Before | 50 | 932 | 2,852 | 44,176 |
| After | 39 | 229 | 549 | 1,494 |

The UI agent saw level 1 stay at depth 1 for more than 2 minutes. That fits these maxima, which came from quiescence explosions, or the old unlimited pass. Both are now bounded: about 15 s at most for depth 1 at ~100 nodes a second, and 8× the level's time for the pass.

## 7. Endgames

**Mates.** `node tools/audit/endgames.js mates [engineDir|-] 50 2500`
- Random legal starts, the strong side to move, both sides played by the engine at 2,500 nodes.
- Success means mate within the fifty-move rule (and 200 plies).

| Ending | Before | After |
|---|---|---|
| KQK, 50 starts | 45/50 | 50/50 (7.3 moves on average) |
| KRK | 50/50 | 50/50 |
| KBBK | 50/50 | 50/50 |
| KBNK | 20/50 | 38/50 |
| KBNK, 100 starts on another seed | 46/100 | 80/100 |
| KQK, 100 starts | 87/100 | 100/100 |

**Tuning.** `tools/audit/tune_mop.js` searched the weights:
- KBNK success was 80-85% for king proximity 14-20, corner 6-7 and edge 16-20, over three seeds of 100 starts.
- A corner weight of 10 was much worse: the bonus hits the ±3,000 clamp and loses its gradient.
- An extra knight-proximity term was worse.

KQK had failed before for the same reason: proximity 6 was too weak at depth 2-3. `ref/mates.js` (three fixed starts) still mates KBNK in 1 of 3; two of its starts need about 50 moves. It is the one failing step of `run_all.js`, as before the audit.

**No stalemating.** `node tools/audit/endgames.js stale [engineDir|-] 100 2500`
- Endings: KQK, KRK, KQPK, KRPK, KPK, KQPPK, KRPPK.
- The king-and-pawn table is loaded as the kernel loads it.
- Counted: strong-side moves that stalemate in a won position (K+P v K judged by the table) when another move existed.

| Limit | Before | After |
|---|---|---|
| 2,500 nodes (level 7), 700 games | 0 | 0 |
| Level 1, 280 games | at least 10 (KQK 4, KRPK 2, KPK 4); the run did not finish (the unlimited pass) | 0 |
| Levels 2 / 3 / 4 / 5 | 32 / 21 / 16 / – in an earlier run without the "won" filter | 0 / 0 / 0 / 0 |

- **Cause:** the depth-0 pass could not see a stalemate. Change 3's probe returns 0 for it, and 0 becomes the move's score.
- **Levels 1-3 still often fail to mate with K+Q or K+R within 50 moves** (e.g. level 1: KQK 3 of 40). The random choice within 70-300 cp makes them weak levels by design.

**King-and-pawn table.** `python -E tools/kpk/xcheck_chess.py 300 9`, re-run:
- python-chess retrograde: 0 legality mismatches and 0 differing bytes against `data/kpk.bin`;
- forward search on 300 positions: 0 disagreements;
- XCHECK PASSED.

All 196,608 entries had already been checked against two independent solvers.

## Strength sanity check

`tools/match` with `snap_audit` (the final `ref/`) against `snap_v3` (pre-audit), 484 games, through
`uci_wrap.js`, which advertises the real option defaults. Changes 3-5 only act at levels 1-4, so the
engine at margin 0 is the same.

| Match | Result |
|---|---|
| Before change 8, both at 2,500 nodes | 49.9%, −1 [−16, +15] |
| Final, both at 2,500 nodes | 56.0% (+231 =80 −173), **+42 [+15, +69]**, average depth 2.73 → 2.94 |
| Final at 2,050 nodes (the measured 18% speed loss) v old at 2,500 | 48.3%, −11 [−39, +15] |

## What was not checked

- **No real Organiser.** Times come from the emulator: the emulated clock in `t_time2`, and 100 nodes a second for the JS level model. The engine runs at 75-140 a second, and about 18% fewer after change 8, so real level strengths differ somewhat.
- **The large statistical runs are JS only:** matches, tactics, mates, stalemates and the 13,552-game soak. The assembler is checked against the JS with the parity tests, a 64-think tactics spot check, and 16 + 4 whole games (1,795 + moves compared).
- **No outside opponents for levels 1-4:** only their order was measured.
- **The UI's handling of game ends** (kernel, screens) is the UI agent's and was not tested here.
- **Known, not fixed:**
  - bishops of one colour not called a draw;
  - in the search, a mate on the 100th half-move scored as a draw;
  - a pinned en-passant capturer still keyed;
  - the residual level-5 mate in one at depth 1;
  - KBNK about 80%, not 100%.

## Final state

All of the following ran on the final engine (test image 13,354 bytes):

- **`node tests/engine/run_all.js` (full, ~47 min on a loaded machine).** Every step passed except `ref/mates.js`, which still mates KBNK in only 1 of its 3 fixed starts. That is the known weak spot above; the same step failed before the audit.
  - The passing steps: JS perft, assembler perft, UI routines, evaluation, search (16 positions; with margin), king-and-pawn table, time limits, perft on awkward positions, rules v python-chess, colour-flip symmetry, random positions, the rook ending move by move, assembler games v JS (4 games) and time overruns.
- **`tools/audit/parity.sh`** (perft, perft2, api, eval, mirror, search ×2, fuzz ×2 (80 positions), rules 100) passed after change 9.
- **`t_rules.js`, all 300 games:** 76 cases and 39,470 positions match python-chess.
- **`t_time2.js 12 10`:** see check 6; it passes with the 1 s threshold.
- **JS soak:** 5,808 games (five mixed-limit matches plus the seven level matches), 607,379 moves checked with python-chess: 0 bad, 0 engine errors. Ends: checkmate 5,445, threefold 161, adjudicated 102, fifty 47, too little material 43, stalemate 10. No dead position was played on. Together with the earlier 7,744-game run, 13,552 games without an illegal move, crash or wrong game end.
- **RAM:** `python tools/build.py --out <scratch>`, built after the coordinator's 07:40 change to build.py, gives an array of **21,328 bytes** with the 512-entry TT. Since that change one engine byte costs one array byte, so the pre-audit engine would give about 21,225 with today's kernel.
