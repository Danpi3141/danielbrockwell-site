// LZH: LZ77 on the 2-bit packed entries (window = the block decoded so far) with ONE static
// Huffman code per table for literal/length symbols and one for distance classes
// (deflate-like, but no per-block tables).  Reports sizes and decode work per probe.
//   node lzh.js KEY STM PERM BLKS [verify]
// Symbols: 0..255 literal byte; 256+c match length class c (lengths 3..; classes as HRLE's
// length classes applied to len-2); distance classes: same scheme on distance (1..blockBytes).
'use strict';
const fs = require('fs'), path = require('path');
const L = require('./lib');
const { SPECS, layout } = require('./norm');
const C = require('./compress');

const MAXLEN = 258;
function parse(buf) {
  // lazy-greedy parse with hash chains; returns tokens [lit] or [len, dist]
  const n = buf.length, head = new Map(), prev = new Int32Array(n).fill(-1), toks = [];
  const h = p => (buf[p] << 16) | (buf[p + 1] << 8) | buf[p + 2];
  const ins = p => { if (p + 2 < n) { const k = h(p); prev[p] = head.has(k) ? head.get(k) : -1; head.set(k, p); } };
  const best = p => {
    let bl = 0, bd = 0;
    if (p + 2 >= n) return [0, 0];
    let c = head.has(h(p)) ? head.get(h(p)) : -1, t = 0;
    while (c >= 0 && t < 512) {
      let l = 0; while (p + l < n && buf[c + l] === buf[p + l] && l < MAXLEN) l++;
      if (l > bl) { bl = l; bd = p - c; }
      c = prev[c]; t++;
    }
    // run of the previous byte (distance 1) even when the hash chain missed it
    if (p > 0) { let l = 0; while (p + l < n && buf[p - 1 + l] === buf[p + l] && l < MAXLEN) l++; if (l > bl) { bl = l; bd = 1; } }
    return [bl, bd];
  };
  let p = 0;
  while (p < n) {
    let [l, dd] = best(p);
    if (l >= 3 && p + 1 < n) {               // lazy: prefer a longer match one byte later
      ins(p);
      const [l2] = best(p + 1);
      if (l2 > l + 1) { toks.push([buf[p]]); p++; continue; }
      toks.push([l, dd]); for (let k = 1; k < l; k++) ins(p + k); p += l; continue;
    }
    if (l >= 3) { toks.push([l, dd]); for (let k = 0; k < l; k++) ins(p + k); p += l; }
    else { toks.push([buf[p]]); ins(p); p++; }
  }
  return toks;
}

function run(key, stm, perm, blk, verify) {
  const spec = SPECS[key], lay = layout(spec), dtm = !!spec.dtm;
  const src = C.loadNorm(key, stm);
  if (process.env.BINARY) for (let i = 0; i < src.sym.length; i++) { if (src.sym[i] === 2) src.sym[i] = 0; if (src.kind[i] === 4) src.kind[i] = 0; }
  const alphabet = dtm ? [...new Set(src.sym)].sort((a, b) => a - b) : [0, 1, 2];
  const d = C.permute(src, lay.dims, perm, process.env.SQORDER || 'rank');
  const vals = C.fill(d, alphabet, C.allowedFn(dtm, 1), blk);
  const bb = blk / 4;
  const pack = new Uint8Array(Math.ceil(vals.length / 4));
  for (let i = 0; i < vals.length; i++) pack[i >> 2] |= vals[i] << (2 * (i & 3));
  const blocks = [];
  for (let s = 0; s < pack.length; s += bb) blocks.push(parse(pack.subarray(s, s + bb)));
  const fl = new Map(), fd = new Map();
  for (const t of blocks) for (const k of t) {
    if (k.length === 1) fl.set(k[0], (fl.get(k[0]) || 0) + 1);
    else { const a = 256 + C.lclass(k[0] - 2), b = C.lclass(k[1]); fl.set(a, (fl.get(a) || 0) + 1); fd.set(b, (fd.get(b) || 0) + 1); }
  }
  const ll = C.huffLens(fl), dl = fd.size ? C.huffLens(fd) : new Map();
  let maxL = 0; for (const [, x] of ll) maxL = Math.max(maxL, x); for (const [, x] of dl) maxL = Math.max(maxL, x);
  const bytes = []; let probeTok = 0, probeOut = 0, probeBits = 0, probes = 0;
  blocks.forEach((t, bi) => {
    let bits = 0, out = 0, ntok = 0;
    const s0 = bi * bb;
    for (const k of t) {
      ntok++;
      let len;
      if (k.length === 1) { bits += ll.get(k[0]); len = 1; }
      else { const a = C.lclass(k[0] - 2), b = C.lclass(k[1]); bits += ll.get(256 + a) + C.LCLASS[a].extra + dl.get(b) + C.LCLASS[b].extra; len = k[0]; }
      // probe statistics: entries (4 per byte) that become available with this token
      let cnt = 0;
      for (let q = out; q < out + len; q++) for (let e = 0; e < 4; e++) { const idx = (s0 + q) * 4 + e; if (idx < vals.length && d.kind[idx] === 0) cnt++; }
      probes += cnt; probeTok += cnt * ntok; probeOut += cnt * (out + len); probeBits += cnt * bits;
      out += len;
    }
    bytes.push(Math.min(Math.ceil(bits / 8), bb));
  });
  const data = bytes.reduce((a, b) => a + b, 0);
  const ib = data < 65536 ? 2 : 3;
  const table = Math.ceil((ll.size + dl.size) * 1.5);
  const res = { key, stm, perm: perm.map(k => spec.names[k]).join('-'), order: process.env.SQORDER || 'rank', pslice: process.env.PSLICE || null,
    binary: !!process.env.BINARY, scheme: 'LZH', blkEntries: blk, decodedBytes: bb, blocks: bytes.length, data, index: bytes.length * ib, table,
    total: data + bytes.length * ib + table, maxBlock: Math.max(...bytes), avgBlock: +(data / bytes.length).toFixed(1),
    avgTokens: +(probeTok / probes).toFixed(1), avgOutBytes: +(probeOut / probes).toFixed(0), avgBits: +(probeBits / probes).toFixed(0),
    nsym: ll.size + dl.size, maxCode: maxL };
  console.log(JSON.stringify(res));
  fs.appendFileSync(path.join(L.DATA_DIR, 'lzh.jsonl'), JSON.stringify(res) + '\n', 'utf8');
  if (verify) {   // decode every block from the token lists and compare
    let bad = 0;
    blocks.forEach((t, bi) => {
      const out = [];
      for (const k of t) { if (k.length === 1) out.push(k[0]); else for (let q = 0; q < k[0]; q++) out.push(out[out.length - k[1]]); }
      for (let q = 0; q < out.length; q++) if (out[q] !== pack[bi * bb + q]) bad++;
    });
    console.log('LZ token round trip mismatches:', bad);
  }
}

if (require.main === module) {
  const [key, stm, permS, blksS, ver] = process.argv.slice(2);
  for (const blk of blksS.split(',').map(Number)) run(key, stm, permS.split('').map(Number), blk, ver === 'verify');
}
