'use strict';
// Runs every headless UI test (each boots its own LZ64) and reports.
//   node tests/ui/run_all.js
// The audit's longer runs are not here (docs/audit-ui.md): t_notat and t_screen without
// --smoke, t_back without --quick, t_lowmem, t_clock, t_soak.
const { spawnSync } = require('child_process');
const path = require('path');
const tests = ['t_ui', 't_game', 't_feat', 't_setup', 't_real', 't_off', 't_sound', 't_mem', 't_many', 't_pgn', 't_import --quick', 't_pbook 2', 't_speedtest', 't_resign', 't_auto', 't_flag', 't_faillow', 't_review',
  't_back --quick', 't_notat --smoke', 't_screen --smoke', 't_sleep', 't_leave', 't_hole', 't_alarm'];
let bad = 0;
for (const t of tests) {
  const t0 = Date.now();
  const [name, ...args] = t.split(' ');
  const r = spawnSync(process.execPath, [path.join(__dirname, name + '.js')].concat(args), { encoding: 'utf8' });
  const out = (r.stdout || '') + (r.stderr || '');
  // the audit tests count their own checks ("606 checks, 0 failures"); the others print "ok" lines
  const own = /^(\d+) checks, \d+ failures/m.exec(out);
  const oks = own ? +own[1] : (out.match(/^ok /gm) || []).length;
  const fail = r.status !== 0;
  if (fail) bad++;
  console.log(`${fail ? 'FAIL' : 'pass'}  ${t.padEnd(16)} ${String(oks).padStart(4)} checks  ${((Date.now() - t0) / 1000).toFixed(0)} s`);
  if (fail) console.log(out.split('\n').filter((l) => /FAIL|Error/.test(l)).slice(0, 3).join('\n'));
}
console.log(bad ? `${bad} test file(s) failed` : 'all UI tests passed');
process.exit(bad ? 1 : 0);
