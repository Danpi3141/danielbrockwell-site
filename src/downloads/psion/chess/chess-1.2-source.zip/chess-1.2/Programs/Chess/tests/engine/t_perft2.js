'use strict';
// Perft on awkward positions (en-passant pins, castling edge cases, promotions, discovered checks,
// the 218-move position, the perft-suite middlegames). Expected counts come from python-chess
// (tools/audit/gen_perft.py -> data/perft_extra.json), not from the engine's own generator.
// The JS reference runs every listed depth; the assembler runs depths up to ASM_LIMIT leaves.
// Usage: node t_perft2.js [asmLimit] [jsLimit] [js]   (js: skip the assembler)
const path = require('path');
const { Engine } = require('../../ref/search.js');
const { perft } = require('../../ref/perft.js');
const CASES = require(path.join(__dirname, 'data', 'perft_extra.json'));
const ASM_LIMIT = +(process.argv[2] || 40000);
const JS_LIMIT = +(process.argv[3] || 3e6);
const jsOnly = process.argv[4] === 'js';

let bad = 0, jsN = 0, asmN = 0, leaves = 0;
const e = new Engine();
for (const [fen, counts] of CASES) {
  e.setFen(fen); e.mvTop[0] = 0;
  // (the move stack holds 400 moves: deeper than that the lists are cut short by design, so the
  // 218-move position is walked to depth 2 only)
  const maxD = counts[0] > 100 ? 2 : counts.length;
  for (let d = 1; d <= maxD && counts[d - 1] <= JS_LIMIT; d++) {
    const n = perft(e, d, 0);
    jsN++;
    if (n !== counts[d - 1]) { bad++; console.log(`FAIL js d${d} ${n} (want ${counts[d - 1]})  ${fen}`); }
  }
}
console.log(`js: ${CASES.length} positions, ${jsN} depths checked (counts up to ${JS_LIMIT})`);
if (!jsOnly) {
  const { Harness } = require('./harness.js');
  const h = new Harness();
  for (const [fen, counts] of CASES) {
    const r = h.setFen(fen);
    if (r.c) { bad++; console.log('FAIL asm set-up refused', r.a, fen); continue; }
    e.setFen(fen);
    const k0 = h.key();
    if (k0 !== e.key) { bad++; console.log('FAIL asm key after set-up', fen); }
    const maxD = counts[0] > 100 ? 2 : counts.length;
    for (let d = 1; d <= maxD && (d === 1 || counts[d - 2] <= ASM_LIMIT); d++) {
      let p;
      try { p = h.perft(d); } catch (x) { bad++; console.log(`FAIL asm d${d} ${String(x.message).slice(0, 120)}  ${fen}`); break; }
      asmN++; leaves += p.n;
      if (p.n !== counts[d - 1]) { bad++; console.log(`FAIL asm d${d} ${p.n} (want ${counts[d - 1]})  ${fen}`); }
      if (h.key() !== k0) { bad++; console.log('FAIL asm state not restored', fen); }
    }
    // eng_legal agrees with perft 1 (the UI's list; the 218-move position tests its capacity)
    const nl = h.call('eng_legal').b;
    if (nl !== counts[0]) { bad++; console.log(`FAIL eng_legal ${nl} (want ${counts[0]})  ${fen}`); }
  }
  console.log(`asm: ${asmN} depths checked, ${leaves} leaves`);
}
console.log(bad ? `${bad} FAILED` : 'all extra perft counts match');
process.exit(bad ? 1 : 0);
