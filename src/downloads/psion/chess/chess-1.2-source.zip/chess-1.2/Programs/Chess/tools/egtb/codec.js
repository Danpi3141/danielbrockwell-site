// Reference encoder / decoder / probe for the HRLE block format, with an end-to-end check
// and operation counts for the 6303 cost model.
//   node codec.js KEY STM PERM POLICY BLK [CTX] [SAMPLES]
//     PERM like 1230 (canonical dim numbers, outermost first), POLICY 0|1, BLK entries per block,
//     CTX 0|1 (Huffman table per previous value), SAMPLES random probes from the raw table.
// Format (per table): canonical Huffman table(s) for symbols (value, length class);
//   block stream = codes MSB first, each followed by the class's extra bits (MSB first);
//   index = byte offset of each block (2 bytes if the data are < 64K, else 3).
// The probe: normalise by symmetry -> entry number -> block, offset -> decode runs until the
//   offset is covered.  With POLICY 1 the probe also generates the side to move's captures
//   that leave <= 3 men, scores them by rule (KQK/KRK: rule; KPK: bitbase; KBK/KNK/KK: draw)
//   and returns max(table value, best capture).
'use strict';
const fs = require('fs'), path = require('path');
const L = require('./lib');
const S = require('./solve');
const { SPECS, layout, TRI } = require('./norm');
const C = require('./compress');
const INV = {};
for (const [name, o] of Object.entries(C.ORDERS)) { INV[name] = new Array(64); o.forEach((sq, k) => { INV[name][sq] = k; }); }

function canonCodes(lens) {
  // lens: Map sym -> len. returns { cnt[len], syms[] in canonical order, code Map sym -> [code,len] }
  const arr = [...lens].sort((a, b) => a[1] - b[1] || a[0] - b[0]);
  const maxL = arr.length ? arr[arr.length - 1][1] : 0;
  const cnt = new Array(maxL + 1).fill(0);
  for (const [, l] of arr) cnt[l]++;
  const code = new Map(); let c = 0, prevL = 0;
  for (const [s, l] of arr) { c <<= (l - prevL); prevL = l; code.set(s, [c, l]); c++; }
  return { cnt, syms: arr.map(a => a[0]), code, maxL };
}

class BitW { constructor() { this.bytes = []; this.cur = 0; this.n = 0; }
  put(v, l) { for (let i = l - 1; i >= 0; i--) { this.cur = (this.cur << 1) | ((v >> i) & 1); if (++this.n === 8) { this.bytes.push(this.cur); this.cur = 0; this.n = 0; } } }
  flush() { if (this.n) { this.bytes.push(this.cur << (8 - this.n)); this.cur = 0; this.n = 0; } return this.bytes; } }

function encode(vals, blk, ctx) {
  const blocks = C.runsOf(vals, blk);
  const h = C.hrle(blocks, ctx);
  const ctxOf = k => ctx ? Math.floor(k / 65536) : 0;
  const tabs = new Map();
  const byCtx = new Map();
  for (const [k, l] of h.lens) { const c = ctxOf(k); if (!byCtx.has(c)) byCtx.set(c, new Map()); byCtx.get(c).set(k % 65536, l); }
  for (const [c, m] of byCtx) tabs.set(c, canonCodes(m));
  const data = [], offs = [];
  for (const runs of blocks) {
    offs.push(data.length);
    const w = new BitW(); let prev = 255;
    for (const [v, l] of runs) {
      const cl = C.lclass(l), t = tabs.get(ctx ? prev : 0);
      const [code, len] = t.code.get(v * 256 + cl);
      w.put(code, len);
      if (C.LCLASS[cl].extra) w.put(l - C.LCLASS[cl].base, C.LCLASS[cl].extra);
      prev = v;
    }
    for (const b of w.flush()) data.push(b);
  }
  return { data: Uint8Array.from(data), offs, tabs, blk, ctx, n: vals.length };
}

// decode entry e; returns value and operation counts
function decodeEntry(T, e) {
  const b = Math.floor(e / T.blk), target = e - b * T.blk;
  let byte = T.offs[b], bit = 0;
  const ops = { codeBits: 0, extraBits: 0, runs: 0, bytes: 0 };
  const getBit = () => { const v = (T.data[byte] >> (7 - bit)) & 1; if (++bit === 8) { bit = 0; byte++; } return v; };
  let pos = 0, prev = 255;
  for (;;) {
    const t = T.tabs.get(T.ctx ? prev : 0);
    let code = 0, first = 0, index = 0, sym = -1;
    for (let len = 1; len <= t.maxL; len++) {
      code |= getBit(); ops.codeBits++;
      const count = t.cnt[len];
      if (code - first < count) { sym = t.syms[index + code - first]; break; }
      index += count; first += count; first <<= 1; code <<= 1;
    }
    if (sym < 0) throw new Error('bad code');
    const v = sym >> 8, cl = sym & 255;
    let l = C.LCLASS[cl].base;
    if (C.LCLASS[cl].extra) { let x = 0; for (let k = 0; k < C.LCLASS[cl].extra; k++) x = (x << 1) | getBit(); ops.extraBits += C.LCLASS[cl].extra; l += x; }
    ops.runs++;
    pos += l;
    if (pos > target) { ops.bytes = byte - T.offs[b] + (bit ? 1 : 0); return { v, ops }; }
    prev = v;
  }
}

// ---------------------------------------------------------------- normalisation for probing
function normIndex(spec, lay, perm, sqIn) {
  let sq = sqIn.slice();
  const d = [0, 0, 0, 0];
  if (spec.type === 'pawnless') {
    const tf = (s, fh, rh, tr) => { let f = s & 7, r = s >> 3; if (fh) f ^= 7; if (rh) r ^= 7; if (tr) { const t = f; f = r; r = t; } return r * 8 + f; };
    let w = sq[0]; const fh = (w & 7) > 3, rh = (w >> 3) > 3;
    sq = sq.map(s => tf(s, fh, rh, false)); w = sq[0];
    if ((w >> 3) > (w & 7)) sq = sq.map(s => tf(s, false, false, true));
    w = sq[0];
    if ((w >> 3) === (w & 7) && (sq[1] >> 3) > (sq[1] & 7)) sq = sq.map(s => tf(s, false, false, true));
    d[0] = TRI.indexOf(sq[0]); d[1] = sq[1]; d[2] = sq[2]; d[3] = sq[3];
  } else if (spec.type === 'bpawn') {
    if ((sq[3] & 7) > 3) sq = sq.map(s => s ^ 7);
    d[0] = ((sq[3] >> 3) - 1) * 4 + (sq[3] & 7); d[1] = sq[0]; d[2] = sq[1]; d[3] = sq[2];
  } else {
    if ((sq[2] & 7) > 3) sq = sq.map(s => s ^ 7);
    d[0] = ((sq[2] >> 3) - 1) * 4 + (sq[2] & 7); d[1] = sq[3] - 8; d[2] = sq[0]; d[3] = sq[1];
  }
  let idx = 0;
  const inv = INV[process.env.SQORDER || 'rank'];
  for (const k of perm) idx = idx * lay.dims[k] + (lay.dims[k] === 64 ? inv[d[k]] : d[k]);
  return idx;
}

// value of a <= 3-man position by the cheap rules the Psion would use (WDL, stm view: 1 W, 0 D, 2 L)
function cheap3(list, stm) {
  const nk = list.filter(p => p[1] !== L.K);
  if (nk.length === 0) return 0;
  const [c, t] = nk[0];
  if (t === L.B || t === L.N) return 0;
  if (t === L.P) { const v = L.probe(list, stm); return v === 0 ? 0 : ((v - 1) & 1) ? 1 : 2; } // = kpk.bin
  // KQK / KRK
  if (c === stm) return 1;
  // weak side to move: draw if it can take the piece or is stalemated, else loss
  const strongK = list.find(p => p[1] === L.K && p[0] === c)[2];
  const weakK = list.find(p => p[1] === L.K && p[0] !== c)[2];
  const pc = nk[0][2];
  const dirs = t === L.Q ? [0, 1, 2, 3, 4, 5, 6, 7] : [0, 1, 2, 3];
  const att = new Set();
  for (const dd of dirs) for (const s of L.RAYS[pc][dd]) { att.add(s); if (s === strongK) break; }
  let moves = 0;
  for (const to of L.KING_N[weakK]) {
    if (L.KADJ[strongK * 64 + to]) continue;
    if (to === pc) return 0;
    if (!att.has(to)) moves++;
  }
  if (moves) return 2;
  return att.has(weakK) ? 2 : 0;
}

if (require.main === module) {
  const [key, stmS, permS, polS, blkS, ctxS, sampS] = process.argv.slice(2);
  const spec = SPECS[key], lay = layout(spec), dtm = !!spec.dtm;
  const perm = permS.split('').map(Number), policy = +polS, blk = +blkS, ctx = ctxS === '1', samples = +(sampS || 200000);
  const src = C.loadNorm(key, stmS);
  const BIN = !!process.env.BINARY;
  if (BIN) for (let i = 0; i < src.sym.length; i++) { if (src.sym[i] === 2) src.sym[i] = 0; if (src.kind[i] === 4) src.kind[i] = 0; }
  const alphabet = dtm ? [...new Set(src.sym)].sort((a, b) => a - b) : [0, 1, 2];
  const d = C.permute(src, lay.dims, perm, process.env.SQORDER || 'rank');
  const vals = C.fill(d, alphabet, C.allowedFn(dtm, policy), blk);
  const T = encode(vals, blk, ctx);
  // 1. every entry decodes to the filled value
  let bad = 0;
  for (let e = 0; e < vals.length; e += (vals.length > 3e6 ? 7 : 1)) if (decodeEntry(T, e).v !== vals[e]) bad++;
  // 2. probes from random raw positions agree with the raw table
  const R = L.loadTable(key), ctxS2 = S.makeCtx(key), stm = stmS === 'b' ? 1 : 0;
  let nP = 0, badP = 0; const agg = { codeBits: 0, extraBits: 0, runs: 0, bytes: 0 };
  let maxOps = { codeBits: 0, runs: 0, bytes: 0 };
  let seed = 12345; const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x80000000;
  const S4 = 64 ** 4;
  while (nP < samples) {
    const idx = stm * S4 + Math.floor(rnd() * S4);
    const v = R.val[idx]; if (v === 255) continue;
    nP++;
    S.decode(ctxS2, idx); S.setOcc(ctxS2);
    const sq = Array.from(ctxS2.sqs);
    const e = normIndex(spec, lay, perm, sq);
    if (e >= vals.length) { nP--; continue; }   // outside PSLICE
    const r = decodeEntry(T, e);
    for (const k in r.ops) agg[k] += r.ops[k];
    for (const k in maxOps) if (r.ops[k] > maxOps[k]) maxOps[k] = r.ops[k];
    let got = r.v;
    let truth = dtm ? v : (v === 0 ? 0 : ((v - 1) & 1) ? 1 : 2);
    if (BIN && truth === 2) truth = 0;
    if (policy === 1) {
      // best cheap capture by rule
      let best = null;
      best = bestCaptureByRule(ctxS2, stm);
      if (best !== null) {
        if (dtm) { if (best === 0 && L.score(got) < 0) got = 0; }
        else if (BIN) { if (best === 1) got = 1; }
        else { const sc = x => x === 1 ? 1 : x === 0 ? 0 : -1; if (sc(best) > sc(got)) got = best; }
      }
    }
    if (got !== truth) { badP++; if (badP < 5) console.log('probe mismatch', idx, sq, truth, got, r.v); }
  }
  const total = T.data.length + T.offs.length * (T.data.length < 65536 ? 2 : 3);
  const res = { key, stm: stmS, binary: BIN, pslice: process.env.PSLICE || null, perm: perm.map(k => spec.names[k]).join('-'), order: process.env.SQORDER || 'rank', policy, blk, ctx, dataBytes: T.data.length,
    blocks: T.offs.length, totalWithIndex: total, decodeMismatches: bad, probes: nP, probeMismatches: badP,
    avg: Object.fromEntries(Object.entries(agg).map(([k, x]) => [k, +(x / nP).toFixed(1)])), max: maxOps,
    tables: [...T.tabs].map(([c, t]) => ({ ctx: c, nsym: t.syms.length, maxLen: t.maxL })) };
  console.log(JSON.stringify(res));
  const rf = path.join(L.DATA_DIR, 'codec.jsonl');
  fs.appendFileSync(rf, JSON.stringify(res) + '\n', 'utf8');
}

// enumerate captures leaving <= 3 men from the decoded position and score them with cheap3
function bestCaptureByRule(ctx, stm) {
  const { n, C: col, T: typ, sqs } = ctx;
  let best = null; const rank = x => x === 1 ? 2 : x === 0 ? 1 : 0;
  // generate pseudo moves of stm that capture, test legality with attacked()
  const occ = new Int8Array(64).fill(-1); for (let k = 0; k < n; k++) occ[sqs[k]] = k;
  for (let k = 0; k < n; k++) {
    if (col[k] !== stm) continue;
    const s = sqs[k], t = typ[k];
    const targets = [];
    if (t === L.K) targets.push(...L.KING_N[s]);
    else if (t === L.N) targets.push(...L.KNIGHT_N[s]);
    else if (t === L.P) { const one = s + (stm ? -8 : 8); for (const df of [-1, 1]) { const f = (s & 7) + df; if (f >= 0 && f < 8) targets.push(one + df); } }
    else { const d0 = t === L.B ? 4 : 0, d1 = t === L.R ? 4 : 8; for (let dd = d0; dd < d1; dd++) for (const to of L.RAYS[s][dd]) { targets.push(to); if (occ[to] >= 0) break; } }
    for (const to of targets) {
      const cap = occ[to]; if (cap < 0 || col[cap] === stm || typ[cap] === L.K) continue;
      // make, test, score
      ctx.occ.fill(-1); for (let j = 0; j < n; j++) ctx.occ[sqs[j]] = j;
      ctx.occ[s] = -1; ctx.occ[to] = k; sqs[k] = to; ctx.alive[cap] = 0;
      const legal = !S.attacked(ctx, sqs[stm], 1 - stm);
      const promo = t === L.P && ((to >> 3) === 0 || (to >> 3) === 7);
      const lists = [];
      for (const pt of promo ? [L.Q, L.R] : [typ[k]]) {   // B/N promotions give KBK/KNK: draws
        const list = []; for (let j = 0; j < n; j++) if (ctx.alive[j]) list.push([col[j], j === k ? pt : typ[j], sqs[j]]);
        lists.push(list);
      }
      sqs[k] = s; ctx.alive[cap] = 1; ctx.occ.fill(-1); for (let j = 0; j < n; j++) ctx.occ[sqs[j]] = j;
      if (!legal || lists[0].length > 3) continue;
      for (const list of lists) {
        const r = cheap3(list, 1 - stm);
        const mine = r === 1 ? 2 : r === 2 ? 1 : 0;   // invert: opponent's W is my L
        if (best === null || rank(mine) > rank(best)) best = mine;
      }
      if (promo && (best === null || rank(best) < 1)) best = 0;   // B/N promotion: draw
    }
  }
  return best;
}
module.exports = { encode, decodeEntry, normIndex, cheap3, canonCodes };
