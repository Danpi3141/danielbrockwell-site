'use strict';
// Debug: count calls of a routine by caller during a search. Usage: node t_calls.js routine [nodes]
const { Harness } = require('./harness.js');
const fs = require('fs'), path = require('path');
const h = new Harness();
const meta = JSON.parse(fs.readFileSync(path.join(__dirname, 'out', 'etest.json')));
const nameOf = require('./labels.js').namer(0x3000);
const target = h.a(process.argv[2] || 'e_att');
h.setFen('r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3'); h.call('e_clrtt');
const N = +(process.argv[3] || 600);
h.m.write(h.a('e_nlim'), [0, (N >> 8) & 255, N & 255]);
const by = {};
h.m.dbg.setTrace(pc => { if (pc === target) { const sp = h.m.dbg.sp(); const ret = h.m.peekw(sp + 1); const n = nameOf(ret - 3); by[n] = (by[n] || 0) + 1; } });
h.call('eng_think', 0, 0, 921600 * 3600);
h.m.dbg.setTrace(null);
console.log(by);
