#!/bin/sh
# Ordering sweep: HRLE size at 4096-entry blocks for all 24 dimension orders,
# both don't-care policies, rank-major and snake square order.
cd "$(dirname "$0")"
for job in "KRvKP w" "KRvKP b" "KPvKP w" "KRvKB w" "KRvKB b" "KRvKN w" "KRvKN b" "KBNvK b" "KBNvK w"; do
  set -- $job
  for o in rank snake; do
    f="$EGTB_DIR/perms_$1_$2_$o.txt"
    [ -s "$f" ] || SQORDER=$o node compress.js $1 $2 perms > "$f"
  done
done
echo SWEEPDONE
