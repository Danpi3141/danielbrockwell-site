"""Reader / validator / encoder for the Psion chess opening book (data/book.bin).

Format (all big-endian):
  move word (16 bit) = from<<10 | to<<4 | flags ; sq = rank*8 + file (a1=0, h8=63)
  castling = king's two-square move (e1g1); no promotions.
  flags: 8 L last move of its group, 4 R reply group follows,
         2 J 3-byte length of the reply group follows the word (set iff that group > 256 bytes),
         1 P preferred (engine may choose it).
  entry = word [len24 if J] [reply group if R]; the file is the root group (White to move).

Commands:
  python -E -P book.py selftest [book.bin]        validate the whole file and print counts
  python -E -P book.py group e4 e5 Nf3 [--file f]  show the group after these moves (SAN or UCI)
  python -E -P book.py pmoves e4 e5 [--file f]     list P moves for the position
"""
import os
import sys
from collections import Counter

import chess

L, R, J, P = 8, 4, 2, 1
DEFAULT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data', 'book.bin'))


class BookError(Exception):
    pass


# ------------------------------------------------------------------ encoding
def word(move, flags):
    return (move.from_square << 10) | (move.to_square << 4) | flags


def encode_group(entries):
    """entries: non-empty list of (chess.Move, preferred: bool, children entries or None)."""
    if not entries:
        raise BookError('empty group')
    out = bytearray()
    for i, (mv, pref, kids) in enumerate(entries):
        if mv.promotion:
            raise BookError('promotion in book')
        flags = (L if i == len(entries) - 1 else 0) | (P if pref else 0)
        sub = b''
        if kids:
            sub = encode_group(kids)
            flags |= R
            if len(sub) > 256:
                flags |= J
        out += word(mv, flags).to_bytes(2, 'big')
        if flags & J:
            out += len(sub).to_bytes(3, 'big')
        out += sub
    return bytes(out)


# ------------------------------------------------------------------ reading
def decode(w):
    return (w >> 10) & 63, (w >> 4) & 63, w & 15


def read_entry(data, pos):
    """-> (from, to, flags, length or None, pos of reply group / next entry)."""
    if pos + 2 > len(data):
        raise BookError('truncated at %d' % pos)
    fr, to, fl = decode(int.from_bytes(data[pos:pos + 2], 'big'))
    pos += 2
    ln = None
    if fl & J:
        if pos + 3 > len(data):
            raise BookError('truncated length at %d' % pos)
        ln = int.from_bytes(data[pos:pos + 3], 'big')
        pos += 3
    return fr, to, fl, ln, pos


def skip_group(data, pos):
    """Scan past a group the way the Psion reader does (recursing into small branches)."""
    while True:
        fr, to, fl, ln, pos = read_entry(data, pos)
        if fl & R:
            pos = pos + ln if fl & J else skip_group(data, pos)
        if fl & L:
            return pos


def read_group(data, pos):
    """-> (list of (chess.Move, flags), start offsets of reply groups, pos after group)."""
    out = []
    while True:
        fr, to, fl, ln, p2 = read_entry(data, pos)
        sub = p2 if fl & R else None
        if fl & R:
            p2 = p2 + ln if fl & J else skip_group(data, p2)
        out.append((chess.Move(fr, to), fl, sub))
        pos = p2
        if fl & L:
            return out, pos


def to_move(board, m):
    if isinstance(m, chess.Move):
        return m
    try:
        return board.parse_san(m)
    except ValueError:
        return board.parse_uci(m)


def find_group(data, moves):
    """moves: list of SAN/UCI strings or chess.Move from the start position.
    Returns (board, [(chess.Move, flags), ...]) for the current group, or None if out of book."""
    board = chess.Board()
    pos = 0
    for m in moves:
        mv = to_move(board, m)
        group, _ = read_group(data, pos)
        hit = [g for g in group if g[0] == mv]
        if not hit or hit[0][2] is None:
            return None
        pos = hit[0][2]
        board.push(mv)
    group, _ = read_group(data, pos)
    return board, [(mv, fl) for mv, fl, _ in group]


def p_moves(data, moves):
    r = find_group(data, moves)
    if r is None:
        return None
    board, group = r
    return [mv for mv, fl in group if fl & P]


# ------------------------------------------------------------------ validation
def validate(data):
    """Walk the whole tree; raise BookError on any problem. Returns stats dict."""
    st = Counter()
    depth_moves = Counter()
    leaf_depths = Counter()
    board = chess.Board()

    def walk(pos, depth):
        st['groups'] += 1
        seen = set()
        n = 0
        while True:
            start = pos
            fr, to, fl, ln, pos = read_entry(data, pos)
            mv = chess.Move(fr, to)
            if not board.is_legal(mv):
                raise BookError('illegal move %s at offset %d in %s' % (mv.uci(), start, board.fen()))
            if mv in seen:
                raise BookError('duplicate move %s at offset %d' % (mv.uci(), start))
            seen.add(mv)
            n += 1
            st['moves'] += 1
            depth_moves[depth + 1] += 1
            if fl & P:
                st['P'] += 1
            if fl & J:
                st['J'] += 1
                if not fl & R:
                    raise BookError('J without R at offset %d' % start)
            if fl & R:
                board.push(mv)
                end = walk(pos, depth + 1)
                board.pop()
                size = end - pos
                if fl & J and size != ln:
                    raise BookError('length %d != actual %d at offset %d' % (ln, size, start))
                if bool(fl & J) != (size > 256):
                    raise BookError('J flag wrong for %d-byte group at offset %d' % (size, start))
                pos = end
            else:
                leaf_depths[depth + 1] += 1
            if fl & L:
                break
        return pos

    end = walk(0, 0)
    if end != len(data):
        raise BookError('file not fully consumed: tree ends at %d of %d bytes' % (end, len(data)))
    st['bytes'] = len(data)
    st['max_depth'] = max(depth_moves)
    return st, depth_moves, leaf_depths


def selftest(path):
    data = open(path, 'rb').read()
    st, dm, ld = validate(data)
    # every group must offer at least one P move, and find_group must agree with the walk
    groups_without_p = 0
    board = chess.Board()

    def walk(pos, path):
        nonlocal groups_without_p
        group, _ = read_group(data, pos)
        if not any(fl & P for _, fl, _ in group):
            groups_without_p += 1
        # lookup from the start position (skipping siblings by J length / recursive scan) must agree
        found = find_group(data, path)
        if found is None or [m for m, _ in found[1]] != [m for m, _, _ in group]:
            raise BookError('find_group disagrees with tree walk after %s' % ' '.join(m.uci() for m in path))
        for mv, fl, sub in group:
            if sub is not None:
                walk(sub, path + [mv])
    walk(0, [])
    probe = find_group(data, [])
    assert probe is not None and len(probe[1]) > 0
    print('book: %s' % path)
    print('OK: %d bytes, %d moves, %d groups, %d P moves, %d J lengths, max depth %d plies'
          % (st['bytes'], st['moves'], st['groups'], st['P'], st['J'], st['max_depth']))
    print('groups without a P move: %d' % groups_without_p)
    print('moves per ply:', ' '.join('%d:%d' % (d, dm[d]) for d in sorted(dm)))
    print('leaf depths  :', ' '.join('%d:%d' % (d, ld[d]) for d in sorted(ld)))
    return st


def main(argv):
    if not argv or argv[0] in ('-h', '--help'):
        print(__doc__)
        return 0
    cmd, args = argv[0], argv[1:]
    path = DEFAULT
    if '--file' in args:
        i = args.index('--file')
        path = args[i + 1]
        del args[i:i + 2]
    if cmd == 'selftest':
        if args:
            path = args[0]
        try:
            selftest(path)
        except BookError as e:
            print('INVALID:', e)
            return 1
        return 0
    data = open(path, 'rb').read()
    r = find_group(data, args)
    if r is None:
        print('out of book')
        return 0
    board, group = r
    if cmd == 'group':
        for mv, fl in group:
            print('%-7s %s%s%s%s' % (board.san(mv), 'P' if fl & P else '-', 'R' if fl & R else '-',
                                    'J' if fl & J else '-', 'L' if fl & L else '-'))
    elif cmd == 'pmoves':
        print(' '.join(board.san(mv) for mv, fl in group if fl & P))
    else:
        print('unknown command', cmd)
        return 2
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
