'use strict';
// Features through the screens with the real engine: book replies, hint, move list,
// draw offer, resign, clocks (5|5) and the clock's display, flag fall.
//   node tests/ui/t_feat.js
const L = require('./lib.js');
const { check, keys } = L;
const DIG = { 1: 'U', 2: 'V', 3: 'W', 4: 'O', 5: 'P', 6: 'Q', 7: 'I', 8: 'J' };
const typeMove = (m, mv) => keys(m, [mv[0], DIG[mv[1]], mv[2], DIG[mv[3]]]);
const row = (m, r) => m.screen()[r];

function menu(m, letters) { keys(m, ['ON']); m.runSeconds(1); keys(m, letters.concat(['EXE'])); }
function settingsLine(m, n, presses) {
  menu(m, ['S', 'S']); m.runSeconds(1);
  for (let i = 0; i < n; i++) keys(m, ['DOWN']);
  for (const k of presses) keys(m, [k]);
  keys(m, ['ON']); L.idle(m);
}

let m = L.start();
L.idle(m);

// ---- book: 1.e4 is answered at once (no thinking strip), by a book move
const c0 = m.cycles();
typeMove(m, 'E2E4');
let thought = false;
for (let i = 0; i < 100; i++) { m.runTicks(2); if (/D ?\d/.test(row(m, 0).slice(9, 12))) thought = true; if (L.peekSym(m, 'g_n')[0] === 2) break; }
L.idle(m);
const secs = (m.cycles() - c0) / 921600;
check(!thought && L.peekSym(m, 'g_n')[0] === 2, 'book reply to 1.e4 without thinking (' + secs.toFixed(1) + ' s)', m);
check(L.peekSym(m, 'bk_in')[0] === 1, 'still in the book', m);

// ---- hint (SPACE): a 2-second look, "HINT E2E4" on row 3
keys(m, ['SPACE']);
L.idle(m);
check(/HINT [A-H][1-8][A-H][1-8]/.test(row(m, 3)), 'hint shown: ' + row(m, 3).trim(), m);
keys(m, ['MODE']); L.idle(m);                         // any key clears the message (MODE flips the view)

// ---- the move list
menu(m, ['M']); m.runSeconds(2);
check(/^1\.[a-hNBRQKO]/.test(row(m, 0)) && row(m, 0).includes('e4'), 'move list: ' + row(m, 0).trim(), m);
keys(m, ['ON']); L.idle(m);

// ---- draw offer: declined or accepted, the game answers (read from the screen: during a save
// the OS pages another RAM bank in at $4000, so memory reads at random moments can mislead)
menu(m, ['O']); m.runSeconds(1);
let ans = '';
for (let i = 0; i < 100 && !ans; i++) { m.runSeconds(0.25); const t = m.screenText(); ans = t.includes('DECLINED') ? 'declined' : t.includes('AGREEMENT') ? 'accepted' : ''; }
check(ans !== '', 'draw offer answered: ' + ans, m);
if (ans === 'accepted') { keys(m, ['EXE']); m.runSeconds(1); keys(m, ['DEL']); }   // take the last move back: the game goes on
L.idle(m);

// ---- resign
menu(m, ['R']); m.runSeconds(2);
check(L.peekSym(m, 'g_result')[0] === 2 && L.peekSym(m, 'g_reason')[0] === 6, 'resign: Black wins by resignation', m);
check(m.screenText().includes('BY RESIGNATION'), 'result screen says resignation', m);
keys(m, ['ON']); m.runSeconds(1);                     // the menu
keys(m, ['EXE']); L.idle(m);                          // NEW GAME

// ---- clocks: 5|5, the player's clock shows and runs
settingsLine(m, 2, ['RIGHT']);                        // CLOCK: 5|5
keys(m, ['ON']); m.runSeconds(1); keys(m, ['EXE']); L.idle(m);   // new game takes the clock
check(row(m, 3).slice(9, 12).trim() === "5'", 'clock shows 5\' for White: [' + row(m, 3).slice(9, 12) + ']', m);
const t0 = m.peekw(L.sym(m, 'g_clk'));
m.runSeconds(65);
const t1 = m.peekw(L.sym(m, 'g_clk'));
check(t0 - t1 >= 1200 && t0 - t1 < 1400, 'White\'s clock ran for a minute (' + (t0 - t1) + ' frames)', m);
check(row(m, 3).slice(9, 12).trim() === "4'", 'clock shows 4\' (rounded up) after 65 s: [' + row(m, 3).slice(9, 12) + ']', m);
typeMove(m, 'D2D4'); L.idle(m);
const tw = m.peekw(L.sym(m, 'g_clk'));
check(tw > t1, 'the increment was added after the move (' + t1 + ' -> ' + tw + ')', m);
// flag fall: wait out White's clock
m.runSeconds(Math.ceil(tw / 20) + 15);
if (!m.isOn()) { m.press('ON', 3, 10); m.runSeconds(2); }   // it switched itself off on the result screen
L.idle(m);
check(L.peekSym(m, 'g_result')[0] === 2 && L.peekSym(m, 'g_reason')[0] === 7, 'White lost on time', m);
check(m.screenText().includes('ON TIME'), 'result screen says on time', m);
console.log('all feature tests passed');
