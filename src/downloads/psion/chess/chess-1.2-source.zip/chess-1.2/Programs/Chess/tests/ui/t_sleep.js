'use strict';
// Switching off at every moment (audit check 5).
//   node tests/ui/t_sleep.js [--quick]
// The Organiser's auto-off time (TMW_TCNT) is set to 20 s to keep the test short. In each
// state where the game waits for a key, it is left alone: it must switch itself off (except
// where a clock runs or it thinks), stay off a minute, and after ON show exactly the same
// screen (text and glyphs) with the same game state, and then carry on from there.
// Also: the clock while switched off, thinking past the auto-off time, the pack taken out
// while the game waits, and A:CHESSAV afterwards.
const L = require('./lib.js');
const G = require('./glib.js');
const { check, keys } = L;
const quick = process.argv.includes('--quick');
const TCNT = 0x20CD;

let fails = 0;
function soft(cond, msg, m) { if (!cond) { fails++; console.log('FAIL ' + msg + (m ? '\n' + m.screenText() : '')); } else console.log('ok   ' + msg); return cond; }
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);

let m = G.start();
m.pokew(TCNT, 20);

// wait (without keys) up to s seconds for it to switch off; returns the seconds it took, or -1
let lastOn = null;
function offWithin(s) {
  const c0 = m.cycles();
  for (let i = 0; i < s * 20; i++) {
    if (!m.isOn()) return (m.cycles() - c0) / 921600;
    const sn = snap();                              // the screen as it was before it went off
    if (sn.scr.replace(/\s/g, '')) lastOn = sn;      // (switching off blanks it first)
    m.runTicks(1);
  }
  return m.isOn() ? -1 : s;
}
function snap() { return { scr: m.screenText(), udg: m.udgs(), st: G.engState(m) }; }
// the state now must survive switching off and on
function offOn(name, limit) {
  const t = offWithin(limit);
  const before = lastOn;
  name += ' [' + before.scr.split(String.fromCharCode(10))[0].trim() + ' / ' + before.scr.split(String.fromCharCode(10))[3].trim() + ']';
  if (!soft(t >= 0, name + ': switched itself off' + (t >= 0 ? ' after ' + t.toFixed(0) + ' s' : ' (still on after ' + limit + ' s)'), m)) return false;
  m.runSeconds(60);
  m.press('ON', 3, 10);
  m.runSeconds(1);
  const after = snap();
  soft(m.isOn() && after.scr === before.scr && same(after.udg, before.udg), name + ': ON brings the same screen back', m);
  soft(same(after.st, before.st), name + ': and the same game state');
  return true;
}

// 1. the board, waiting for a move
G.waitInput(m, 5);
offOn('board waiting', 40);
G.typeUci(m, 'e2e4'); G.waitPly(m, 2);
soft(L.peekSym(m, 'g_n')[0] === 2, 'then e2e4 is played and answered', m);

// 2. half a move typed (the piece's square chosen: its cursor blinks)
keys(m, ['D', 'V']); G.waitInput(m, 5);
offOn('half a move typed (D2)', 130);
keys(m, ['D', 'O']); G.waitPly(m, 4);
soft(L.peekSym(m, 'g_n')[0] === 4, 'then D4 completes the move', m);

// 3. pointing: the cursor, then a piece picked up
keys(m, ['UP']); G.waitInput(m, 5);
offOn('the pointing cursor shown', 130);
keys(m, ['RIGHT', 'RIGHT', 'DOWN', 'EXE']); G.waitInput(m, 5);      // the cursor to g1, pick the knight up
soft(m.screen()[2].includes('G1'), 'the knight on g1 picked up', m);
offOn('a piece picked up by pointing', 130);
keys(m, ['ON']); G.waitInput(m, 5);              // put it back (ON clears)

// 4. the menu, the settings, the move list
keys(m, ['ON']); G.waitInput(m, 5);
offOn('the menu', 40);
keys(m, ['S', 'S', 'EXE']); G.waitInput(m, 5);
offOn('the settings', 40);
keys(m, ['ON']); G.waitInput(m, 5);
G.menu(m, ['M']); G.waitInput(m, 5);
offOn('the move list', 40);
keys(m, ['ON']); G.waitInput(m, 5);

// 5. set-up
G.menu(m, ['S']); G.waitInput(m, 5);
offOn('the set-up screen', 130);
keys(m, ['ON']); G.waitInput(m, 10);
soft(L.peekSym(m, 'g_n')[0] === 4, 'set-up given up: the game as it was', m);

// 6. two players: the promotion prompt, the result screen, the board after the game
G.twoPlayers(m);
G.setupFen(m, '4k3/P7/8/8/8/8/8/4K3 w - - 0 1');
keys(m, ['A', 'I', 'A', 'J']); G.waitInput(m, 5);
soft(m.screen()[3].includes('PROMOTE'), 'the promotion prompt', m);
offOn('the promotion prompt', 40);
keys(m, ['N']); G.waitPly(m, 1);
soft(G.engFen(m).startsWith('N3k3'), 'then N makes a knight', m);
G.menu(m, ['N']); G.waitInput(m, 10);
for (const u of ['f2f3', 'e7e5', 'g2g4', 'd8h4']) G.typeUci(m, u);
G.waitPly(m, 4);
soft(m.screenText().includes('CHECKMATE'), 'the result screen', m);
offOn('the result screen', 40);
keys(m, ['EXE']); G.waitInput(m, 5);
offOn('the board after the game', 40);
keys(m, ['DEL']); G.waitPly(m, 3);
soft(L.peekSym(m, 'g_n')[0] === 3, 'then DEL takes the mate back', m);

// 7. a clock (5|5, two players): it runs while the board waits, so no switching off
G.setting(m, G.SET.CLOCK, ['RIGHT']);
G.menu(m, ['N']); G.waitInput(m, 10);
const clk0 = G.engState(m).clk.slice();
const t1 = offWithin(60);
const clk1 = G.engState(m).clk.slice();
soft(t1 < 0 && clk1[0] < clk0[0] - 1100, 'clock game, board waiting: stays on for 60 s (3 x the auto-off time) and White\'s clock runs: ' + clk0 + ' -> ' + clk1, m);
// the menu during a clock game: it may switch off; the time off is not charged
keys(m, ['ON']); G.waitInput(m, 5);
const ta = m.cycles();
const off = offWithin(40);
const tOffStart = m.cycles();
m.runSeconds(120);
m.press('ON', 3, 10); m.runSeconds(1);
const tb = m.cycles();
keys(m, ['ON']); G.waitInput(m, 5);              // back to the board: the clock catches up
m.runSeconds(1.5);
const clk2 = G.engState(m).clk.slice();
const charged = (clk1[0] - clk2[0]) / 20, wall = (m.cycles() - ta) / 921600 + 0, offS = (tb - tOffStart) / 921600;
console.log(`     clock game menu: switched off after ${off.toFixed(0)} s, off ${offS.toFixed(0)} s; White charged ${charged.toFixed(1)} s of ${wall.toFixed(1)} s since the menu opened`);
soft(off >= 0 && Math.abs(charged - (wall - offS)) < 3, 'clock game, menu: switches off; the clock keeps running in the menu but not while switched off', m);
G.setting(m, G.SET.CLOCK, ['LEFT']);

// 8. thinking longer than the auto-off time: no switching off, the move comes
G.setting(m, G.SET.TWO, ['LEFT']);
G.setting(m, G.SET.LEVEL, ['RIGHT']);           // level 8: 255 s
G.menu(m, ['N']); G.waitInput(m, 10);
G.typeUci(m, 'b1a3');                            // out of the book (the only first move it has no answer to)
const c0 = m.cycles();
let wasOff = false;
for (let i = 0; i < 560 && L.peekSym(m, 'g_n')[0] !== 2; i++) { m.runSeconds(0.5); if (!m.isOn()) wasOff = true; }
const think = (m.cycles() - c0) / 921600;
soft(!wasOff && L.peekSym(m, 'g_n')[0] === 2 && think > 25, 'thinking ' + think.toFixed(0) + ' s (auto-off 20 s): stays on and moves', m);
G.waitInput(m, 10);
offOn('the board after the computer moved', 40);
G.setting(m, G.SET.LEVEL, ['LEFT']);

// 9. the pack taken out while the game waits, then a key that needs a screen from it
const pk = m.bus.getPacks()[0];
const before = G.engState(m);
m.emptyPack(0, 0, 0);                            // nothing in B:
keys(m, ['ON']); m.runSeconds(3);
// (ON was still down when the game left: OPL takes it as ON/CLEAR and pauses until a key)
if (!m.screenText().trim()) { keys(m, ['EXE']); m.runSeconds(2); }
const scr = m.screenText();
console.log('     pack out, ON pressed:\n' + scr.split('\n').map((l) => '     | ' + l).join('\n') + '\n     on=' + m.isOn() + ' pc=$' + m.dbg.pc().toString(16));
soft(scr.includes('GAME FILES NOT FOUND'), 'pack out: the game leaves with "GAME FILES NOT FOUND" (the game is saved)', m);
// whatever happened, A:CHESSAV must still hold the game: back on the pack and run CHESS again
m.bus.setPack(pk, 0);
for (let i = 0; i < 4 && !m.screenText().includes('Find'); i++) { m.press('ON', 3, 10); m.runSeconds(1); }
if (m.screenText().includes('Find')) {
  m.runProc('CHESS', 'B'); m._base = null; G.waitInput(m, 20);
  const st = G.engState(m);
  soft(same(st.pos, before.pos) && st.g_n === before.g_n, 'A:CHESSAV survives: CHESS resumes the same game (' + st.g_n + ' plies)', m);
} else soft(false, 'could not get back to the top-level menu after the pack came out', m);

if (fails) { console.log(fails + ' failures'); process.exit(1); }
console.log('all switch-off tests passed');
