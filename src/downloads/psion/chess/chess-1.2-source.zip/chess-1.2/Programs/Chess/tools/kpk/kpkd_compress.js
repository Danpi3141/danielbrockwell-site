// How small can the king-and-pawn distance table (data/kpkd.bin, 48K) get? A measurement only.
// Entries are 4-bit distances (0 = draw), index (p * 64 + sk) * 64 + wk (see kpkd.js).
// "Don't care": positions that can't occur (kings on the same or next squares, a king on the
// pawn, the defender in check with the pawn's side to move) take whatever value suits the coder.
// Coders, each by blocks of N entries with a 2-byte index per block:
//   rle-huff: runs of one value, coded as Huffman(value, length class) + extra bits (as in
//             tools/egtb/codec.js, the HRLE format), one code table for the whole file
//   deflate:  zlib level 9 per block (a bound: too big a decoder for the 6303)
//   node tools/kpk/kpkd_compress.js
'use strict';
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const TAB = fs.readFileSync(path.join(__dirname, '..', '..', 'data', 'kpkd.bin'));
const N = 24 * 64 * 64;
const get = (i) => (i & 1 ? TAB[i >> 1] >> 4 : TAB[i >> 1] & 15);
const dist = (a, b) => Math.max(Math.abs((a & 7) - (b & 7)), Math.abs((a >> 3) - (b >> 3)));
function legal(i) {
  const wk = i & 63, sk = (i >> 6) & 63, pi = i >> 12;
  const p = ((pi >> 2) + 1) * 8 + (pi & 3);
  if (wk === sk || wk === p || sk === p || dist(wk, sk) < 2) return false;
  if ((wk >> 3) === (p >> 3) + 1 && Math.abs((wk & 7) - (p & 7)) === 1) return false;   // defender in check
  return true;
}
// orderings of the three coordinates (outermost first)
const ORD = {
  'p sk wk': (p, s, w) => (p * 64 + s) * 64 + w,
  'p wk sk': (p, s, w) => (p * 64 + w) * 64 + s,
};
function seq(order, fill) {
  const out = new Uint8Array(N), care = new Uint8Array(N);
  for (let p = 0; p < 24; p++) for (let s = 0; s < 64; s++) for (let w = 0; w < 64; w++) {
    const i = (p * 64 + s) * 64 + w, j = ORD[order](p, s, w);
    out[j] = get(i); care[j] = legal(i) ? 1 : 0;
  }
  if (fill) { let last = 0; for (let j = 0; j < N; j++) { if (!care[j]) out[j] = last; else last = out[j]; } }
  return out;
}
// Huffman code lengths for symbol counts
function huffLens(counts) {
  const nodes = [...counts].filter(([, c]) => c > 0).map(([s, c]) => ({ c, syms: [s] }));
  const len = new Map(nodes.map((n) => [n.syms[0], 0]));
  if (nodes.length === 1) { len.set(nodes[0].syms[0], 1); return len; }
  while (nodes.length > 1) {
    nodes.sort((a, b) => a.c - b.c);
    const a = nodes.shift(), b = nodes.shift();
    for (const s of a.syms.concat(b.syms)) len.set(s, len.get(s) + 1);
    nodes.push({ c: a.c + b.c, syms: a.syms.concat(b.syms) });
  }
  return len;
}
const CLASS = (n) => { let k = 0; while ((1 << (k + 1)) <= n) k++; return k; };   // run length n >= 1: class k = floor(log2 n), k extra bits
function rleHuff(a, blk) {
  const runs = [];
  for (let b0 = 0; b0 < a.length; b0 += blk) {
    const end = Math.min(a.length, b0 + blk);
    const br = [];
    for (let j = b0; j < end;) { let k = j; while (k < end && a[k] === a[j]) k++; br.push([a[j], k - j]); j = k; }
    runs.push(br);
  }
  const counts = new Map();
  for (const br of runs) for (const [v, n] of br) { const s = v * 32 + CLASS(n); counts.set(s, (counts.get(s) || 0) + 1); }
  const len = huffLens(counts);
  let bytes = 0;
  for (const br of runs) { let bits = 0; for (const [v, n] of br) bits += len.get(v * 32 + CLASS(n)) + CLASS(n); bytes += Math.ceil(bits / 8); }
  const table = len.size * 2;
  return bytes + 2 * runs.length + table;
}
function deflate(a, blk) {
  let bytes = 0, blocks = 0;
  for (let b0 = 0; b0 < a.length; b0 += blk) {
    const packed = Buffer.alloc(Math.ceil(Math.min(blk, a.length - b0) / 2));
    for (let j = 0; j < packed.length * 2 && b0 + j < a.length; j++) packed[j >> 1] |= a[b0 + j] << ((j & 1) * 4);
    bytes += zlib.deflateRawSync(packed, { level: 9 }).length; blocks++;
  }
  return bytes + 2 * blocks;
}
console.log('raw: 49,152 bytes (98,304 entries of 4 bits)');
for (const order of Object.keys(ORD)) for (const fill of [false, true]) {
  const a = seq(order, fill);
  const row = [];
  for (const blk of [1024, 2048, 4096]) row.push(`${blk}: rle-huff ${(rleHuff(a, blk) / 1024).toFixed(1)}K, deflate ${(deflate(a, blk) / 1024).toFixed(1)}K`);
  console.log(`order ${order}, don't-care ${fill ? 'filled' : 'as stored'}: ` + row.join(' | '));
}
