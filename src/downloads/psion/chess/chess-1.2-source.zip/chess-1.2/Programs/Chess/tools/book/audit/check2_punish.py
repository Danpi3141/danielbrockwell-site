"""Check 2: mistakes get punished. Wherever the book holds an opponent move that is a real mistake
(loses >= 90 cp against Stockfish's best, confirmed at depth 26), the Psion's next move must be a
refutation: every P move in the reply group within 30 cp of Stockfish's best there (depth 26).
If the mistake is a leaf (no reply group), the Psion thinks for itself: the capped engine's move
(ref/uci.js, 2,500 nodes) is judged the same way.

Screening uses the depth-22 evals of the tree (a move's loss = position eval + eval after it);
anything within 15 cp of a threshold is re-checked at depth 26.
Only positions the Psion can reach with the colour that is not to move are considered.

    python -E -P tools/book/audit/check2_punish.py [--book data/book.bin] [--out result.json]
"""
import argparse
import json
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import chess  # noqa: E402
from common import Tree, SF, BOOK, CACHE, P, tree_evals, confirm, san_path, ref_moves, log  # noqa: E402

MISTAKE = 90
KEEP = 30
MARGIN = 15


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--book', default=BOOK)
    ap.add_argument('--out', default=os.path.join(CACHE, 'check2.json'))
    a = ap.parse_args()
    t = Tree(a.book)
    sf = SF()
    try:
        ev, _ = tree_evals(t, sf)
        cands = []
        n_opp = 0
        for g, mv in t.groups.items():
            b = t.board(g)
            psion = not b.turn
            if not t.reach(g, psion):
                continue
            best = max([ev[g]] + [-ev[g + (u,)] for u, fl, r in mv])
            for u, fl, r in mv:
                n_opp += 1
                loss = best - (-ev[g + (u,)])
                if loss >= MISTAKE - MARGIN:
                    cands.append({'path': list(g), 'move': u, 'p': bool(fl & P), 'screen': loss, 'leaf': not r})
        log('check2: %d opponent moves in reachable positions, %d mistake candidates' % (n_opp, len(cands)))
        res = confirm(sf, [(t.board(c['path']).fen(), c['move']) for c in cands])
        for c, (bm, bcp, mine) in zip(cands, res):
            c['loss26'], c['best26'] = bcp - mine, bm
        mistakes = [c for c in cands if c['loss26'] >= MISTAKE]
        # the Psion's answers
        leafpaths = [tuple(c['path'] + [c['move']]) for c in mistakes if c['leaf']]
        refm = ref_moves(leafpaths) if leafpaths else {}
        items = []
        for c in mistakes:
            cp = tuple(c['path'] + [c['move']])
            fen = t.board(cp).fen()
            if c['leaf']:
                c['answers'] = [{'move': refm[cp][0], 'by': 'engine'}]
            else:
                c['answers'] = [{'move': u, 'by': 'book'} for u, fl, r in t.groups[cp] if fl & P]
            for x in c['answers']:
                items.append((fen, x['move']))
        res = confirm(sf, items)
        k = 0
        for c in mistakes:
            for x in c['answers']:
                bm, bcp, mine = res[k]
                k += 1
                x['gap26'], x['best26'] = bcp - mine, bm
    finally:
        sf.close()
    bad = [c for c in mistakes if any(x['gap26'] > KEEP for x in c['answers'])]
    nb = sum(1 for c in mistakes if not c['leaf'])
    print('opponent moves in positions the Psion reaches: %d; mistakes (>= %d cp at depth 26): %d '
          '(%d with a book reply group, %d leaves)' % (n_opp, MISTAKE, len(mistakes), nb, len(mistakes) - nb))
    print('not refuted (an answer more than %d cp below best): %d book, %d engine'
          % (KEEP, sum(1 for c in bad if not c['leaf']), sum(1 for c in bad if c['leaf'])))
    for c in sorted(bad, key=lambda c: -max(x['gap26'] for x in c['answers']))[:25]:
        cp = c['path'] + [c['move']]
        b = t.board(cp)
        ans = ', '.join('%s %s -%d' % (x['by'], b.san(chess.Move.from_uci(x['move'])), x['gap26']) for x in c['answers'])
        print('  %-62s mistake -%d; answers: %s; SF best %s' % (san_path(cp), c['loss26'], ans,
              b.san(chess.Move.from_uci(c['answers'][0]['best26'])) if c['answers'][0]['best26'] else '-'))
    json.dump({'mistakes': mistakes, 'bad': bad}, open(a.out, 'w', encoding='utf-8'))
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main())
