; ---------------------------------------------------------------------
; Numbers: num_str D (unsigned) -> kv_nbuf as a length-prefixed decimal
; string without leading zeros. X kept; kv_nbuf+6.. untouched.
; ---------------------------------------------------------------------
num_str:                        ; (the ROM's UT$UTOB since 17 Nov: was 70 bytes of our own)
        pshx
        ldx  #kv_nbuf+1
        os   UT$UTOB            ; the digits at X, B = how many
        stab kv_nbuf
        pulx
        rts
