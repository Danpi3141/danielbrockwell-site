"""Shared helpers for the book audit scripts (tools/book/audit/*.py).

Does not use tools/book/book.py: the tree comes from the independent JavaScript decoder
(decode.js, legality from ref/), positions and SAN from python-chess, scores from Stockfish 19.
Stockfish results are cached in tools/book/audit/cache/sf_eval.json (keyed by EPD and depth).
"""
import json
import os
import pickle
import queue
import subprocess
import sys
import tempfile
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import chess
import chess.engine

HERE = os.path.dirname(os.path.abspath(__file__))
CHESS = os.path.normpath(os.path.join(HERE, '..', '..', '..'))
BOOK = os.path.join(CHESS, 'data', 'book.bin')
STOCKFISH = os.path.join(CHESS, 'ext', 'stockfish', 'stockfish', 'stockfish-windows-x86-64-universal.exe')
STATS = os.path.join(CHESS, 'tools', 'book', 'cache', 'stats.pkl')
GAMES = os.path.join(CHESS, 'tools', 'book', 'cache', 'games.txt')
CACHE = os.path.join(HERE, 'cache')
SFCACHE = os.path.join(CACHE, 'sf_eval.json')
REF_UCI = os.path.join(CHESS, 'ref', 'uci.js')

DEPTH = 22          # Stockfish depth for the audit (the build used 16)
WORKERS = 12
HASH = 128
CLAMP = 3000        # mate scores are clamped to +-CLAMP cp


def limit(depth):
    """Search limit: the depth, with a node cap so that one pathological position cannot stall a run
    (depth 22 typically needs 1-3 M nodes, depth 26 5-15 M)."""
    return chess.engine.Limit(depth=depth, nodes=2_000_000 * max(1, depth - 16) ** 2 // 4)
P = 1


def log(*a):
    print(time.strftime('%H:%M:%S'), *a, flush=True)


# ------------------------------------------------------------------ the tree
class Tree:
    """groups: {path tuple of uci: [(uci, flags, has_replies)]}."""

    def __init__(self, path=BOOK):
        self.file = path
        fd, tmp = tempfile.mkstemp(suffix='.json')
        os.close(fd)
        try:
            r = subprocess.run(['node', os.path.join(HERE, 'decode.js'), path, '--json', tmp],
                               capture_output=True, text=True)
            self.decoder_output = r.stdout
            if r.returncode != 0:
                raise RuntimeError('decoder rejected the book:\n' + r.stdout + r.stderr)
            j = json.load(open(tmp, encoding='utf-8'))
        finally:
            os.remove(tmp)
        self.bytes = j['bytes']
        self.groups = {}
        self.offset = {}
        for g in j['groups']:
            k = tuple(g['path'])
            self.groups[k] = [(m['uci'], m['fl'], m['sub'] is not None) for m in g['moves']]
            self.offset[k] = g['off']
        self.nmoves = sum(len(v) for v in self.groups.values())

    def board(self, path):
        b = chess.Board()
        for u in path:
            b.push_uci(u)
        return b

    def flags(self, path, u):
        for m, fl, _ in self.groups[tuple(path)]:
            if m == u:
                return fl
        return None

    def reach(self, path, colour):
        """True if the Psion playing `colour` can arrive at `path` (all its own moves on the way are P)."""
        for i, u in enumerate(path):
            mover = chess.WHITE if i % 2 == 0 else chess.BLACK
            if mover == colour and not (self.flags(path[:i], u) & P):
                return False
        return True

    def leaves(self):
        """-> [(path of the leaf position)] for every move without replies."""
        out = []
        for g, mv in self.groups.items():
            for u, fl, r in mv:
                if not r:
                    out.append(g + (u,))
        return out


# ------------------------------------------------------------------ Stockfish
def score_cp(info, turn):
    s = info['score'].pov(turn).score(mate_score=100000)
    return max(-CLAMP, min(CLAMP, s))


class SF:
    """Pool of single-thread Stockfish engines with a JSON cache of position evals."""

    def __init__(self, workers=WORKERS, depth=DEPTH):
        self.workers, self.depth = workers, depth
        self.lock = threading.Lock()
        self.cache = {}
        os.makedirs(CACHE, exist_ok=True)
        if os.path.exists(SFCACHE):
            self.cache = json.load(open(SFCACHE, encoding='utf-8'))
        self.q = None
        self.engines = []
        self.dirty = 0

    def _engines(self):
        if self.q is None:
            self.q = queue.Queue()
            for _ in range(self.workers):
                e = chess.engine.SimpleEngine.popen_uci(STOCKFISH)
                e.configure({'Threads': 1, 'Hash': HASH})
                self.engines.append(e)
                self.q.put(e)
        return self.q

    def key(self, board, depth, extra=''):
        return '%s|%d%s' % (board.epd(), depth, extra)

    def _eval(self, fen, depth):
        b = chess.Board(fen)
        k = self.key(b, depth)
        with self.lock:
            if k in self.cache:
                return self.cache[k]
        if b.is_checkmate():
            ent = {'cp': -CLAMP, 'best': None, 'pv': []}
        elif b.is_game_over():
            ent = {'cp': 0, 'best': None, 'pv': []}
        else:
            q = self._engines()
            e = q.get()
            try:
                info = e.analyse(b, limit(depth))
            finally:
                q.put(e)
            pv = [m.uci() for m in info.get('pv', [])][:8]
            ent = {'cp': score_cp(info, b.turn), 'best': pv[0] if pv else None, 'pv': pv}
        with self.lock:
            self.cache[k] = ent
            self.dirty += 1
        return ent

    def _move(self, fen, uci, depth):
        """Score of one root move (restricted search), side-to-move POV."""
        b = chess.Board(fen)
        k = self.key(b, depth, '|' + uci)
        with self.lock:
            if k in self.cache:
                return self.cache[k]
        q = self._engines()
        e = q.get()
        try:
            info = e.analyse(b, limit(depth), root_moves=[chess.Move.from_uci(uci)])
        finally:
            q.put(e)
        ent = {'cp': score_cp(info, b.turn)}
        with self.lock:
            self.cache[k] = ent
            self.dirty += 1
        return ent

    def evals(self, fens, depth=None, label='eval'):
        """Evaluate many positions in parallel; returns {epd: entry}."""
        depth = depth or self.depth
        todo = []
        seen = set()
        for f in fens:
            b = chess.Board(f)
            k = self.key(b, depth)
            if k not in self.cache and k not in seen:
                seen.add(k)
                todo.append(f)
        if todo:
            log('%s: %d positions to search at depth %d (%d workers)' % (label, len(todo), depth, self.workers))
        self._run(lambda f: self._eval(f, depth), todo, label)
        return {chess.Board(f).epd(): self.cache[self.key(chess.Board(f), depth)] for f in fens}

    def moves(self, jobs, depth=None, label='moves'):
        """jobs: [(fen, uci)] -> {(epd, uci): cp} via restricted root searches."""
        depth = depth or self.depth
        todo = [(f, u) for f, u in jobs if self.key(chess.Board(f), depth, '|' + u) not in self.cache]
        if todo:
            log('%s: %d root-move searches at depth %d' % (label, len(todo), depth))
        self._run(lambda j: self._move(j[0], j[1], depth), todo, label)
        return {(chess.Board(f).epd(), u): self.cache[self.key(chess.Board(f), depth, '|' + u)]['cp'] for f, u in jobs}

    def _run(self, fn, items, label):
        if not items:
            return
        done = 0
        with ThreadPoolExecutor(self.workers) as ex:
            for _ in ex.map(fn, items):
                done += 1
                if done % 200 == 0:
                    log('%s: %d/%d' % (label, done, len(items)))
                    self.save()
        self.save()

    def save(self):
        with self.lock:
            if not self.dirty:
                return
            tmp = SFCACHE + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(self.cache, f)
            os.replace(tmp, SFCACHE)
            self.dirty = 0

    def close(self):
        self.save()
        for e in self.engines:
            try:
                e.quit()
            except Exception:
                pass


# ------------------------------------------------------------------ the capped Psion engine
class RefEngine:
    """ref/uci.js with Nodes 2500 (the Psion's level 7); TT cleared before each position."""

    def __init__(self, nodes=2500):
        self.p = subprocess.Popen(['node', REF_UCI], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                  text=True, bufsize=1)
        self._send('uci')
        self._wait('uciok')
        self._send('setoption name Nodes value %d' % nodes)

    def _send(self, s):
        self.p.stdin.write(s + '\n')
        self.p.stdin.flush()

    def _wait(self, tok):
        lines = []
        while True:
            line = self.p.stdout.readline()
            if not line:
                raise RuntimeError('ref engine died')
            lines.append(line.strip())
            if line.startswith(tok):
                return lines

    def best(self, path):
        self._send('ucinewgame')
        self._send('position startpos moves ' + ' '.join(path) if path else 'position startpos')
        self._send('go')
        lines = self._wait('bestmove')
        mv = lines[-1].split()[1]
        sc = None
        for l in lines:
            if l.startswith('info') and ' score cp ' in l:
                sc = int(l.split(' score cp ')[1].split()[0])
        return mv, sc

    def close(self):
        try:
            self._send('quit')
            self.p.wait(5)
        except Exception:
            self.p.kill()


def ref_moves(paths, workers=8):
    """Capped-engine first move for many move paths, in parallel processes. -> {tuple(path): (uci, score)}"""
    paths = [tuple(p) for p in paths]
    out = {}
    pool = queue.Queue()
    engs = [RefEngine() for _ in range(workers)]
    for e in engs:
        pool.put(e)

    def one(p):
        e = pool.get()
        try:
            return p, e.best(list(p))
        finally:
            pool.put(e)
    with ThreadPoolExecutor(workers) as ex:
        for p, r in ex.map(one, paths):
            out[p] = r
    for e in engs:
        e.close()
    return out


def load_stats():
    return pickle.load(open(STATS, 'rb'))


def san_path(path):
    b = chess.Board()
    out = []
    for i, u in enumerate(path):
        m = chess.Move.from_uci(u)
        s = b.san(m)
        out.append(('%d.' % (i // 2 + 1) if i % 2 == 0 else '') + s)
        b.push(m)
    return ' '.join(out)


def tree_evals(t, sf, label='tree'):
    """Stockfish eval (side-to-move POV) of every group and leaf position: {path tuple: cp}."""
    fens = {}
    for g, mv in t.groups.items():
        b = t.board(g)
        fens[g] = b.fen()
        for u, fl, r in mv:
            b.push_uci(u)
            fens[g + (u,)] = b.fen()
            b.pop()
    ev = sf.evals(list(fens.values()), label=label)
    return {p: ev[chess.Board(f).epd()]['cp'] for p, f in fens.items()}, \
        {p: ev[chess.Board(f).epd()] for p, f in fens.items()}


def confirm(sf, items, depth=26, label='confirm'):
    """Deeper check of moves: items [(fen, uci)] -> [(best move, best cp, this move's cp)] from
    restricted root searches at `depth` for the move and for Stockfish's own best move there
    (found by a full search at that depth)."""
    fens = sorted(set(f for f, _ in items))
    best = sf.evals(fens, depth=depth, label=label)
    jobs = set(items)
    for f in fens:
        bm = best[chess.Board(f).epd()]['best']
        if bm:
            jobs.add((f, bm))
    r = sf.moves(sorted(jobs), depth=depth, label=label)
    out = []
    for f, u in items:
        epd = chess.Board(f).epd()
        bm = best[epd]['best']
        mine = r[(epd, u)]
        # best = Stockfish's depth-26 move searched the same way (restricted root search), so a move
        # that is the best scores a loss of 0 (the full search's own score differs by a few cp)
        bcp = max(r[(epd, bm)] if bm else -CLAMP, mine)
        out.append((bm, bcp, mine))
    return out


def reach_prob(t, stats, path, colour):
    """Probability that a game with the Psion playing `colour` follows `path`: the Psion picks
    uniformly among the group's P moves; the opponent's moves have their club frequency."""
    pr = 1.0
    b = chess.Board()
    for i, u in enumerate(path):
        if b.turn == colour:
            g = t.groups[tuple(path[:i])]
            np_ = sum(1 for _, fl, _ in g if fl & P)
            pr *= 1.0 / np_
        else:
            n, mv = stats['club'].get(b.epd(), (0, {}))
            pr *= mv.get(u, 0) / n if n else 0.0
        b.push_uci(u)
    return pr
