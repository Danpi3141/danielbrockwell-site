'use strict';
// Mirror test: a position and its colour-flipped twin (ranks mirrored, colours swapped, side to move
// swapped, castling rights and en passant flipped) must get the same evaluation from the side to
// move's point of view, in the JS reference and in the assembler. Also reports the left-right flip
// (files mirrored, only for positions without castling rights), which the PeSTO tables do not keep.
// Usage: node t_mirror.js [games] [js]
const { Engine, legalMoves } = require('../../ref/search.js');
const GAMES = +(process.argv[2] || 60);
const jsOnly = process.argv[3] === 'js';

function fenOf(b, side, castle, ep, half) {
  let s = '';
  for (let r = 7; r >= 0; r--) {
    let e = 0;
    for (let c = 0; c < 8; c++) {
      const p = b[r * 16 + c];
      if (!p) { e++; continue; }
      if (e) { s += e; e = 0; }
      const ch = ' pnbrqk'[p & 7];
      s += p & 8 ? ch : ch.toUpperCase();
    }
    if (e) s += e;
    if (r) s += '/';
  }
  let cs = '';
  if (castle & 1) cs += 'K'; if (castle & 2) cs += 'Q'; if (castle & 4) cs += 'k'; if (castle & 8) cs += 'q';
  const eps = ep === 0xFF ? '-' : 'abcdefgh'[ep & 7] + (1 + (ep >> 4));
  return `${s} ${side ? 'b' : 'w'} ${cs || '-'} ${eps} ${half} 1`;
}
function colourFlip(e) {
  const b = new Uint8Array(128);
  for (let s = 0; s < 128; s++) if (!(s & 0x88) && e.b[s]) b[s ^ 0x70] = e.b[s] ^ 8;
  const c = e.castle, nc = ((c & 3) << 2) | ((c >> 2) & 3);
  return fenOf(b, e.side ^ 8, nc, e.ep === 0xFF ? 0xFF : e.ep ^ 0x70, e.half);
}
function fileFlip(e) {
  const b = new Uint8Array(128);
  for (let s = 0; s < 128; s++) if (!(s & 0x88) && e.b[s]) b[s ^ 7] = e.b[s];
  return fenOf(b, e.side, 0, e.ep === 0xFF ? 0xFF : e.ep ^ 7, e.half);
}

// positions: random games (captures preferred, so endgames appear) and endgame set-ups
const fens = [];
let rng = 4242;
const rnd = (k) => { rng = (Math.imul(rng, 1103515245) + 12345) & 0x7fffffff; return (rng >>> 8) % k; };
const e = new Engine();
for (let g = 0; g < GAMES; g++) {
  e.setFen('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
  for (let ply = 0; ply < 220; ply++) {
    fens.push(fenOf(e.b, e.side, e.castle, e.ep, e.half));
    const ms = legalMoves(e);
    if (!ms.length) break;
    const caps = ms.filter(([f, t]) => e.b[t & 0x77]);
    const pool = caps.length && rnd(3) ? caps : ms;
    const [f, t] = pool[rnd(pool.length)];
    e.make(f, t); e.ply = 0;
  }
}
// bare-king endings (mop-up, B+N corner) and K+P endings, random placements
const SETS = ['KQ', 'KR', 'KBN', 'KBB', 'KNN', 'KB', 'KN', 'KP', 'KPP', 'KRP', 'KQP'];
for (let i = 0; i < 1500; i++) {
  const set = SETS[i % SETS.length], b = new Uint8Array(128), white = rnd(2) === 0;
  const put = (p) => { for (;;) { const s = rnd(8) * 16 + rnd(8); if (b[s]) continue; if ((p & 7) === 1 && ((s >> 4) === 0 || (s >> 4) === 7)) continue; b[s] = p; return s; } };
  put(6 | (white ? 0 : 8)); put(6 | (white ? 8 : 0));
  for (const ch of set.slice(1)) put('PNBRQK'.indexOf(ch) + 1 | (white ? 0 : 8));
  const fen = fenOf(b, rnd(2) ? 8 : 0, 0, 0xFF, 0);
  e.setFen(fen);
  // keep only legal set-ups: the side not to move must not be in check, kings apart
  const them = e.side ^ 8;
  if (e.attacked(e.ksq[them >> 3], e.side)) continue;
  fens.push(fen);
}

let bad = 0, n = 0, lrDiff = 0, lrN = 0, lrMax = 0;
const diffs = {};
const hist = (d) => { diffs[d] = (diffs[d] || 0) + 1; };
const ev = (fen) => { e.setFen(fen); return e.evaluate(); };
let asm = null;
if (!jsOnly) { const { Harness } = require('./harness.js'); asm = new Harness(); }
const aev = (fen) => {
  asm.setFen(fen);
  const r = asm.call('e_eval');
  let v = (r.a << 8) | r.b; if (v & 0x8000) v -= 0x10000;
  return v;
};
let asmBad = 0;
for (const fen of fens) {
  e.setFen(fen);
  const cf = colourFlip(e), ff = e.castle === 0 ? fileFlip(e) : null;
  const a = ev(fen), b = ev(cf);
  n++;
  if (a !== b) { bad++; hist(a - b); if (bad <= 10) console.log(`FAIL js ${a} v ${b}: ${fen}  |  ${cf}`); }
  if (ff) { const c = ev(ff); lrN++; if (c !== a) { lrDiff++; lrMax = Math.max(lrMax, Math.abs(c - a)); } }
  if (asm) {
    const aa = aev(fen), ab = aev(cf);
    if (aa !== a || ab !== b) { asmBad++; if (asmBad <= 10) console.log(`FAIL asm ${aa}/${ab} v js ${a}/${b}: ${fen}`); }
  }
}
console.log(`${n} positions and their colour-flipped twins${asm ? ' (JS and assembler)' : ' (JS)'}`);
console.log(`colour flip: ${bad} differ${bad ? ' ' + JSON.stringify(diffs) : ''}; assembler v JS: ${asm ? asmBad + ' differ' : 'not run'}`);
console.log(`left-right flip (no castling rights): ${lrDiff} of ${lrN} differ, largest ${lrMax} cp (PeSTO tables are not left-right symmetric)`);
console.log(bad + asmBad ? `${bad + asmBad} FAILED` : 'mirror ok');
process.exit(bad + asmBad ? 1 : 0);
