'use strict';
// e_eval against the JS evaluate() on positions from random games and on endgame set-ups.
const { Harness } = require('./harness.js');
const { Engine, legalMoves } = require('../../ref/search.js');

const h = new Harness();
const e = new Engine();
let bad = 0, n = 0;
function cmp(label) {
  const r = h.call('e_eval');
  let v = (r.a << 8) | r.b; if (v & 0x8000) v -= 0x10000;
  const j = e.evaluate();
  n++;
  if (v !== j) { bad++; if (bad < 15) console.log('FAIL', label, 'asm', v, 'js', j); }
}
const FENS = [
  '8/8/8/4k3/8/8/8/R3K3 w - - 0 1', '8/8/8/4k3/8/8/8/Q3K3 b - - 0 1', '8/8/2k5/8/8/8/8/1BN1K3 w - - 0 1',
  '8/8/2k5/8/8/8/8/2B1KN2 b - - 0 1', '8/8/8/4k3/8/8/8/1N2K3 w - - 0 1', '8/8/8/4k3/8/8/8/NN2K3 w - - 0 1',
  '8/8/8/4k3/8/8/2b5/4K3 w - - 0 1', '8/8/8/4k3/8/8/4q3/4K3 w - - 0 1', '7k/8/8/8/8/8/8/rb2K3 w - - 0 1',
  '8/5k2/8/8/8/8/1PP5/4K3 w - - 0 1', '8/p4k2/8/8/8/8/1PP5/4K3 w - - 0 1', '4k3/pppppppp/8/8/8/8/PPPPPPPP/4K3 w - - 0 1',
  '4k3/p1p1p1p1/8/8/8/8/1P1P1P1P/4K3 b - - 0 1', '4k3/8/8/3P4/8/8/8/4K3 w - - 0 1', 'k7/8/8/8/8/8/2B5/K1B5 w - - 0 1',
  'k7/8/8/8/8/8/2b5/K1n5 b - - 0 1', '8/8/8/8/8/8/1k6/K1B1N3 w - - 0 1', '8/8/8/8/8/2k5/8/KB4N1 b - - 0 1',
];
for (const f of FENS) { h.setFen(f); e.setFen(f); cmp(f); }
let rng = 777;
const rnd = (k) => { rng = (rng * 1103515245 + 12345) & 0x7fffffff; return rng % k; };
for (let g = 0; g < 40; g++) {
  const start = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
  h.call('eng_reset'); e.setFen(start);
  for (let ply = 0; ply < 200; ply++) {
    cmp(`g${g} p${ply}`);
    const ms = legalMoves(e);
    if (!ms.length) break;
    // prefer captures so games reach endgames
    const caps = ms.filter(([f, t]) => e.b[t & 0x77]);
    const pool = caps.length && rnd(3) ? caps : ms;
    const [f, t] = pool[rnd(pool.length)];
    h.call('eng_play', f, t); e.make(f, t); e.ply = 0;
  }
}
console.log(`${n} positions`);
console.log(bad ? `${bad} FAILED` : 'eval ok');
process.exit(bad ? 1 : 0);
