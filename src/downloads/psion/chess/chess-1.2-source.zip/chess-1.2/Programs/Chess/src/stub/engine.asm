; =====================================================================
; STUB engine (for building and testing the screens before the real
; engine). Implements src/engine/API.md loosely: eng_legal lists pawn,
; knight and king moves only, with no check test; eng_think plays the
; first of them. Not chess, just enough to drive the screens.
; =====================================================================
backrank:
        fcb  PC_R,PC_N,PC_B,PC_Q,PC_K,PC_B,PC_N,PC_R
st_kn:  fcb  -33,-31,-18,-14,14,18,31,33
st_kg:  fcb  -17,-16,-15,-1,1,15,16,17

eng_init:
        rts

eng_reset:
        ldx  #e_board
.z:     clr  0,x
        inx
        cpx  #e_board+128
        bne  .z
        clrb
.f:     ldx  #backrank
        abx
        ldaa 0,x
        ldx  #e_board
        abx
        staa 0,x
        oraa #PC_BLACK
        staa $70,x
        ldaa #PC_P
        staa $10,x
        ldaa #PC_P+PC_BLACK
        staa $60,x
        incb
        cmpb #8
        bne  .f
        clr  e_side
        ldaa #15
        staa e_castle
        ldaa #$FF
        staa e_ep
        clr  e_half
        rts

eng_setup:
        clc
        rts

eng_check:
        clra
        rts

eng_status:
        clra
        tst  e_lmn
        bne  .x
        ldaa #2
.x:     rts

; A = from, B = to: add to e_lm if B is on the board and not our own
; piece. C=0 if the square was empty (a slider could go on).
es_add: bitb #$88
        bne  .no
        stab es_t+1
        ldx  #e_board
        abx
        ldab 0,x
        beq  .put
        andb #8
        cmpb e_side
        beq  .no
.put:   ldab e_lmn
        cmpb #120
        bhs  .no
        aslb
        ldx  #e_lm
        abx
        staa 0,x
        ldab es_t+1
        stab 1,x
        inc  e_lmn
        clc
        rts
.no:    sec
        rts

eng_legal:
        clr  e_lmn
        clrb
.sq:    stab es_s
        bitb #$88
        bne  .nx
        ldx  #e_board
        abx
        ldaa 0,x
        beq  .nx
        tab
        andb #8
        cmpb e_side
        bne  .nx
        anda #7
        cmpa #PC_P
        beq  .pawn
        ldx  #st_kn
        cmpa #PC_N
        beq  .steps
        ldx  #st_kg
        cmpa #PC_K
        bne  .nx
.steps: ldab #8
.s:     pshb
        pshx
        ldab es_s
        addb 0,x
        ldaa es_s
        jsr  es_add
        pulx
        pulb
        inx
        decb
        bne  .s
        bra  .nx
.pawn:  ldaa #16
        tst  e_side
        beq  .pw
        ldaa #-16
.pw:    staa es_d
        adda es_s               ; one forward, if empty
        tab
        ldx  #e_board
        abx
        tst  0,x
        bne  .nx
        ldaa es_s
        jsr  es_add
        ldaa es_s
        anda #$70
        cmpa #$10
        beq  .two
        cmpa #$60
        bne  .nx
.two:   ldab es_t+1
        addb es_d
        ldx  #e_board
        abx
        tst  0,x
        bne  .nx
        ldaa es_s
        jsr  es_add
.nx:    ldab es_s
        incb
        cmpb #$78
        bne  .sq
        ldab e_lmn
        rts

; A = from, B = to
eng_play:
        staa es_s
        andb #$77
        stab es_t+1
        tab
        ldx  #e_board
        abx
        ldaa 0,x
        clr  0,x
        ldab es_t+1
        ldx  #e_board
        abx
        staa 0,x
        ldaa e_side
        eora #8
        staa e_side
        rts

eng_think:
        ldaa #1
        jsr  think_poll
        jsr  eng_legal
        ldd  e_lm
        staa e_bestf
        stab e_bestt
        ldd  #0
        std  e_score
        ldaa #1
        staa e_depth
        rts
