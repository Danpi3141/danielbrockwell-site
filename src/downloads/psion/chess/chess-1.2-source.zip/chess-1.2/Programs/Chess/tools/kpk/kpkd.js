// King and pawn v king: a distance table (data/kpkd.bin), replacing the win/draw bitbase.
//
// For every position with the pawn's side (the "strong" side) to move: the number of its
// moves to a safe promotion (a queen or rook that can't be taken at once and doesn't
// stalemate; KQK/KRK are then always won), or 0 for a draw: at most 19 moves. Stored as 4 bits:
// a distance d over 15 as d - 15, read back as d - 15 + 15 when that is less than the pawn
// moves still needed (minPushes), which a real distance never is.
// Only the strong-side-to-move half is stored: a position with the defender to move is
// valued by looking one ply further (the defender's replies), as the game's root probe does.
//
// Layout (as kpk.bin's): the pawn is White, on files a-d (a position with the pawn on e-h is
// mirrored, a Black pawn's position is flipped), ranks 2-7. Index = (p * 64 + sk) * 64 + wk,
// p = (rank - 2) * 4 + file, sk = the pawn side's king, wk = the other king (squares 0-63,
// a1 = 0). Entry i is the low nibble of byte i >> 1 when i is even, the high nibble when odd.
// 24 * 64 * 64 entries = 49,152 bytes.
//
//   node tools/kpk/kpkd.js [out=data/kpkd.bin]   (also checks it against data/kpk.bin)
'use strict';
const fs = require('fs');
const path = require('path');
const kpk = require('./probe.js');

const OUT = process.argv[2] || path.join(__dirname, '..', '..', 'data', 'kpkd.bin');
const F = (s) => s & 7, R = (s) => s >> 3, SQ = (f, r) => r * 8 + f;
const onB = (f, r) => f >= 0 && f < 8 && r >= 0 && r < 8;
const dist = (a, b) => Math.max(Math.abs(F(a) - F(b)), Math.abs(R(a) - R(b)));
const KD = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
const kingTo = (s) => KD.map(([df, dr]) => [F(s) + df, R(s) + dr]).filter(([f, r]) => onB(f, r)).map(([f, r]) => SQ(f, r));
const pawnHits = (p, s) => R(s) === R(p) + 1 && Math.abs(F(s) - F(p)) === 1;   // White pawn on p attacks s

// all 8 files are solved (mirror symmetry is then checked, not assumed)
// S[sk][wk][p] strong to move, D[...] defender to move; -1 = not legal, 0 = undecided/draw
const N = 64 * 64 * 64;
const id = (sk, wk, p) => (sk * 64 + wk) * 64 + p;
const S = new Int16Array(N).fill(-1), D = new Int16Array(N).fill(-1);
for (let sk = 0; sk < 64; sk++) for (let wk = 0; wk < 64; wk++) for (let p = 8; p < 56; p++) {
  if (sk === wk || sk === p || wk === p || dist(sk, wk) < 2) continue;
  if (!pawnHits(p, wk)) S[id(sk, wk, p)] = 0;   // strong to move: the defender may not be in check
  D[id(sk, wk, p)] = 0;                          // defender to move (it may be in check)
}

// strong side's moves from (sk, wk, p): [{to: 'D' index} | {promo: true}]
function strongMoves(sk, wk, p) {
  const out = [];
  for (const t of kingTo(sk)) {
    if (t === p || dist(t, wk) < 2) continue;
    out.push({ i: id(t, wk, p) });
  }
  const f = F(p), r = R(p);
  const one = SQ(f, r + 1);
  if (one !== sk && one !== wk) {
    if (r + 1 === 7) out.push({ promo: one });
    else {
      out.push({ i: id(sk, wk, one) });
      const two = SQ(f, r + 2);
      if (r === 1 && two !== sk && two !== wk) out.push({ i: id(sk, wk, two) });
    }
  }
  return out;
}
// defender's moves: [{i: 'S' index} | {draw: true}] (taking the pawn draws)
function weakMoves(sk, wk, p) {
  const out = [];
  for (const t of kingTo(wk)) {
    if (dist(t, sk) < 2 || pawnHits(p, t)) continue;
    if (t === p) out.push({ draw: true });       // (not next to sk, checked above)
    else out.push({ i: id(sk, t, p) });
  }
  return out;
}
// a promotion on q (pawn gone, defender to move): won if the new queen (or, failing that, a
// rook: a queen that stalemates) can't be taken and the defender isn't stalemated
function promoWins(sk, wk, q) {
  const attacked = (s, piece) => {             // by the new piece on q (sk may block)
    if (dist(s, sk) < 2) return true;
    const dirs = piece === 'Q' ? KD : KD.slice(0, 4);
    for (const [df, dr] of dirs) {
      let f = F(q) + df, r = R(q) + dr;
      while (onB(f, r)) { const x = SQ(f, r); if (x === s) return true; if (x === sk) break; f += df; r += dr; }
    }
    return false;
  };
  for (const piece of ['Q', 'R']) {
    if (dist(wk, q) === 1 && dist(sk, q) > 1) return false;            // it is taken
    const moves = kingTo(wk).filter((t) => t !== sk && !(t !== q && attacked(t, piece)) && dist(t, sk) > 1);
    const inCheck = attacked(wk, piece);
    if (moves.length || inCheck) return true;                            // not stalemate
  }
  return false;
}

// retrograde by distance: S value n = n moves to a safe promotion
for (let n = 1; n <= 99; n++) {
  let changed = 0;
  for (let sk = 0; sk < 64; sk++) for (let wk = 0; wk < 64; wk++) for (let p = 8; p < 56; p++) {
    const i = id(sk, wk, p);
    if (S[i] !== 0) continue;
    for (const m of strongMoves(sk, wk, p)) {
      if (m.promo !== undefined ? (n === 1 && promoWins(sk, wk, m.promo)) : D[m.i] === n - 1 && n > 1) { S[i] = n; changed++; break; }
    }
  }
  for (let sk = 0; sk < 64; sk++) for (let wk = 0; wk < 64; wk++) for (let p = 8; p < 56; p++) {
    const i = id(sk, wk, p);
    if (D[i] !== 0) continue;
    const ms = weakMoves(sk, wk, p);
    if (!ms.length) continue;                     // stalemate (or mate: impossible here): a draw
    let worst = 0, ok = true;
    for (const m of ms) { if (m.draw || S[m.i] <= 0) { ok = false; break; } worst = Math.max(worst, S[m.i]); }
    if (ok && worst === n) { D[i] = n; changed++; }
  }
  if (!changed && n > 2) { console.log('solved: longest win', n - 1, 'moves to promote'); break; }
}

// checks: mirror symmetry; agreement with kpk.bin (win <=> distance > 0), both sides to move
const T = kpk.load();
let bad = 0, wins = 0, max = 0;
const hist = new Array(40).fill(0);
for (let sk = 0; sk < 64; sk++) for (let wk = 0; wk < 64; wk++) for (let p = 8; p < 56; p++) {
  const i = id(sk, wk, p);
  const m = id(SQ(7 - F(sk), R(sk)), SQ(7 - F(wk), R(wk)), SQ(7 - F(p), R(p)));
  if (S[i] !== S[m] || D[i] !== D[m]) bad++;
  if (S[i] >= 0) {
    const w = kpk.probe(T, sk, wk, p, 0, 0);
    if ((S[i] > 0) !== (w === 1)) bad++;
    if (S[i] > 0) { wins++; hist[S[i]]++; max = Math.max(max, S[i]); }
  }
  if (D[i] >= 0 && !(pawnHits(p, sk) && false)) {
    const w = kpk.probe(T, sk, wk, p, 1, 0);
    if ((D[i] > 0) !== (w === 1)) bad++;
  }
}
console.log('disagreements with kpk.bin or the mirror:', bad);
console.log('strong-to-move wins:', wins, 'longest:', max, 'moves; how many at each distance:', hist.slice(1, max + 1).join(' '));
if (bad) process.exit(1);

// distances over 15 are stored as d - 15 (1-4). That can be told from a real 1-4 because a
// real distance is never less than the pawn moves still needed (minPushes: 7 - rank, one less
// from rank 2's double step): check that every long win has its pawn far enough back
const minPushes = (r) => (r === 1 ? 5 : 7 - r);
let clash = 0;
for (let sk = 0; sk < 64; sk++) for (let wk = 0; wk < 64; wk++) for (let p = 8; p < 56; p++) {
  const v = S[id(sk, wk, p)];
  if (v > 0 && v < minPushes(R(p))) clash++;                        // a real distance below the pushes
  if (v > 15 && !(v - 15 < minPushes(R(p)))) clash++;               // a long one that would read as real
}
console.log('distance encoding clashes:', clash);
if (clash) process.exit(1);

// pack files a-d, strong to move
const out = Buffer.alloc(24 * 64 * 64 / 2);
let capped = 0;
for (let pr = 1; pr <= 6; pr++) for (let pf = 0; pf < 4; pf++) for (let sk = 0; sk < 64; sk++) for (let wk = 0; wk < 64; wk++) {
  const e = ((((pr - 1) * 4 + pf) * 64 + sk) * 64 + wk);
  let v = S[id(sk, wk, SQ(pf, pr))];
  if (v < 0) v = 0;
  if (v > 15) { v -= 15; capped++; }
  out[e >> 1] |= (e & 1) ? v << 4 : v;
}
fs.writeFileSync(OUT, out);
console.log('wrote', OUT, out.length, 'bytes;', capped, 'entries over 15 stored as d - 15');
