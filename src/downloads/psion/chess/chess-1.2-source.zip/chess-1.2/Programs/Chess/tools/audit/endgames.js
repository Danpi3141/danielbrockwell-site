'use strict';
// Basic mates and stalemate avoidance, both sides played by the JS reference.
//   node endgames.js mates [engineDir|-] [starts] [nodes] [sets]     e.g. mates - 50 2500 KQK,KRK,KBBK,KBNK
//   node endgames.js stale [engineDir|-] [starts] [nodes|L1..L8]     winning endings: never a stalemating move
// Random starts: the strong side to move, legal, not in check. A game is a success when it ends in
// mate within the fifty-move rule (and 200 plies). The TT is kept between moves, as on the Psion.
const path = require('path');
const L = require('./levels.js');
const mode = process.argv[2] || 'mates';
const dir = process.argv[3] && process.argv[3] !== '-' ? path.resolve(process.argv[3]) : null;
const { Engine, legalMoves, uciStr } = L.loadEngine(dir);
const STARTS = +(process.argv[4] || 50);
const LIM = process.argv[5] || '2500';
const SETS = (process.argv[6] || (mode === 'mates' ? 'KQK,KRK,KBBK,KBNK' : 'KQK,KRK,KQPK,KRPK,KPK,KQPPK,KRPPK')).split(',');

let rng = +(process.env.EG_SEED || 20261116);
const rnd = (k) => { rng = (Math.imul(rng, 1103515245) + 12345) & 0x7fffffff; return (rng >>> 8) % k; };
function fenOf(b, side) {
  let s = '';
  for (let r = 7; r >= 0; r--) {
    let k = 0;
    for (let c = 0; c < 8; c++) {
      const p = b[r * 16 + c];
      if (!p) { k++; continue; }
      if (k) { s += k; k = 0; }
      const ch = ' pnbrqk'[p & 7];
      s += p & 8 ? ch : ch.toUpperCase();
    }
    if (k) s += k;
    if (r) s += '/';
  }
  return `${s} ${side ? 'b' : 'w'} - - 0 1`;
}
// a random legal start: White has the set (K + pieces), Black a bare king; White to move
function start(set, e) {
  for (;;) {
    const b = new Uint8Array(128);
    const put = (p) => { for (;;) { const s = rnd(8) * 16 + rnd(8); if (b[s]) continue; if ((p & 7) === 1 && ((s >> 4) < 1 || (s >> 4) > 6)) continue; b[s] = p; return s; } };
    put(6); put(14);
    for (const ch of set.slice(1, -1)) put('PNBRQK'.indexOf(ch) + 1);
    if (set === 'KBBK') { // bishops on both colours
      const bs = []; for (let s = 0; s < 128; s++) if (b[s] === 3) bs.push(s);
      if ((((bs[0] & 7) + (bs[0] >> 4)) & 1) === (((bs[1] & 7) + (bs[1] >> 4)) & 1)) continue;
    }
    const fen = fenOf(b, 0);
    e.setFen(fen);
    if (e.attacked(e.ksq[1], 0)) continue;          // Black in check with White to move: illegal
    if (e.inCheck()) continue;
    if (!legalMoves(e).length) continue;
    return fen;
  }
}
// king and pawn v king: since 16 Nov the game plays it from the distance table at the root
// (ref/kpkroot.js, the Psion's OV_KPK), searching only when the pawn's side is to move in a draw
const KPKD = require('fs').readFileSync(path.join(__dirname, '..', '..', 'data', 'kpkd.bin'));
const { kpkRoot, look } = require('../../ref/kpkroot.js');
function kpkWon(e) {             // the side to move is the strong side
  let p = -1;
  for (let s = 0; s < 128; s++) { if (s & 0x88) { s += 7; continue; } if ((e.b[s] & 7) === 1) p = s; }
  if (p < 0) return true;
  const pc = e.b[p] & 8;
  return look(KPKD, e.ksq[pc >> 3], e.ksq[(pc >> 3) ^ 1], p, pc) > 0;
}
function think(e, lim) {
  const mv = kpkRoot(e, KPKD);
  if (mv) return { f: mv[0], t: mv[1], score: 0, depth: 0, nodes: 0 };
  if (lim[0] === 'L') return L.levelThink(e, +lim.slice(1));
  return e.think(+lim);
}
function stalemates(e, f, t) {
  e.make(f, t);
  const r = legalMoves(e).length === 0 && !e.inCheck();
  e.unmake();
  return r;
}
function play(fen, lim, watch) {
  const e = new Engine(); e.ttInit(9); e.setFen(fen); e.rnd = 1 + rnd(65000);
  let ply = 0, result = 'unfinished', staleMoves = 0, avoidable = 0;
  for (; ply < 200; ply++) {
    const ms = legalMoves(e);
    if (!ms.length) { result = e.inCheck() ? 'mate' : 'stalemate'; break; }
    if (e.half >= 100) { result = 'fifty moves'; break; }
    if (e.insufficient()) { result = 'insufficient'; break; }
    const r = think(e, lim);
    if (watch && e.side === 0 && stalemates(e, r.f, r.t)) {
      staleMoves++;
      if (kpkWon(e) && ms.some(([f, t]) => !stalemates(e, f, t))) avoidable++;
    }
    e.make(r.f, r.t); e.ply = 0;
    if (e.half === 0) e.keys.length = 0;
  }
  return { result, moves: Math.ceil(ply / 2), staleMoves, avoidable };
}

const g = new Engine();
let total = 0, fails = 0;
for (const set of SETS) {
  const tally = {}; let mates = 0, mv = 0, worst = 0, av = 0;
  const failFens = [];
  for (let i = 0; i < STARTS; i++) {
    const fen = start(set, g);
    const r = play(fen, LIM, mode === 'stale');
    tally[r.result] = (tally[r.result] || 0) + 1;
    if (r.result === 'mate') { mates++; mv += r.moves; worst = Math.max(worst, r.moves); } else if (failFens.length < 3) failFens.push(fen);
    av += r.avoidable;
  }
  total += STARTS;
  if (mode === 'mates') {
    fails += STARTS - mates;
    console.log(`${set.padEnd(6)} ${mates}/${STARTS} mated (average ${mates ? (mv / mates).toFixed(1) : '-'} moves, longest ${worst}) ${JSON.stringify(tally)}${failFens.length ? '  e.g. ' + failFens[0] : ''}`);
  } else {
    fails += av;
    console.log(`${set.padEnd(6)} ${STARTS} games ${JSON.stringify(tally)}; stalemating moves by the strong side in a won position with another move available: ${av}`);
  }
}
console.log(`engine ${dir || 'ref'}, limit ${LIM}: ${mode === 'mates' ? fails + ' of ' + total + ' starts not mated' : fails + ' avoidable stalemating moves'}`);
