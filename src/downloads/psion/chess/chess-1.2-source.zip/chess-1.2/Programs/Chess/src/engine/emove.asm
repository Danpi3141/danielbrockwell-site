; =====================================================================
; Engine: attacks, move generation, make and unmake.
; Mirrors ref/engine.js; the order of generation must stay identical.
; =====================================================================

; frame fields (E_FR bytes per ply): the undo record of the move made at this ply
F_F     = 0
F_T     = 1
F_CAP   = 2
F_CAS   = 3
F_EP    = 4
F_HALF  = 5
F_KEY   = 6                     ; 3 bytes
F_MG    = 9                     ; 8 bytes: e_mg (4) and e_eg (4)
F_PH    = 17
F_PC    = 18
F_NP    = 19
F_EPC   = 20
; and the search's locals for the node at this ply
F_DEP   = 21
F_AL    = 22                    ; word
F_BE    = 24                    ; word
F_CHK   = 26
F_STAT  = 27                    ; word
F_LEG   = 29
F_BF    = 30
F_BT    = 31
F_OA    = 32                    ; word
F_I     = 34                    ; word: current move
F_END   = 36                    ; word: end of this ply's moves
F_TTF   = 38
F_TTT   = 39
F_TTX   = 40                    ; word: table entry
F_Q     = 42
; fields only the switched-off searches use, after the rest (E_FR in evars.inc counts them;
; 17 Nov: the frame was 48 bytes with all of them and a gap at 9)
F_X     = 43
F_NUL   = F_X                   ; E_NULL: null move allowed
F_PV    = F_X+1                 ; E_NULL: a zero window
F_MS    = F_X+2*E_NULL          ; E_LMR: the move's ordering score
F_RED   = F_X+2*E_NULL+E_LMR    ; E_PVS: the reduction

; direction tables
e_ndir: fcb  -33,-31,-18,-14,14,18,31,33
e_kdir: fcb  -17,-16,-15,-1,1,15,16,17
e_bdir: fcb  -17,-15,15,17
e_rdir: fcb  -16,-1,1,16
e_phw:  fcb  0,0,1,1,2,4,0      ; phase weight by type
e_bit:  fcb  1,2,4,8,16,32,64,128
e_prom: fcb  5,4,3,2            ; promotion code -> type: Q R B N

; ---------------------------------------------------------------------
; e_att: is square B attacked by colour A (0/8)?  C=1 yes.
; Unrolled; piece kinds the attacker doesn't have are skipped. Uses T0..T4.
; ---------------------------------------------------------------------
att_j   macro off               ; one step: piece T2 there?
        ldab T0
        addb #\off
        bitb #$88
        bne  .j\@
        ldx  #e_board
        abx
        ldaa 0,x
        cmpa T2
        beq  .yes
.j\@:
        endm
att_r   macro dir               ; one ray: piece T2 or T3 first in line?
        ldab T0
.r\@:   addb #\dir
        bitb #$88
        bne  .e\@
        ldx  #e_board
        abx
        ldaa 0,x
        beq  .r\@
        cmpa T2
        beq  .yes
        cmpa T3
        beq  .yes
.e\@:
        endm

e_att:  stab T0
        staa T1
        tab
        ldx  #e_cnt
        abx
        stx  T4                 ; T4,T5 -> the attacker's counts
        tsta
        bne  .bp
        tst  1,x                ; White pawns attack from s-15 and s-17
        beq  .kn
        ldaa #1
        staa T2
        att_j -15
        att_j -17
        bra  .kn
.bp:    tst  1,x                ; Black pawns from s+15 and s+17
        beq  .kn
        ldaa #9
        staa T2
        att_j 15
        att_j 17
.kn:    ldx  T4
        tst  2,x
        beq  .kg
        ldaa #2
        oraa T1
        staa T2
        att_j -33
        att_j -31
        att_j -18
        att_j -14
        att_j 14
        att_j 18
        att_j 31
        att_j 33
.kg:    ldab T1                 ; the attacker's king next to the square?
        lsrb
        lsrb
        lsrb
        ldx  #e_ksq
        abx
        ldaa 0,x
        suba T0                 ; rank and file differences in -1..1 <=> diff+$11 in
        adda #$11               ; $00..$22 with neither nibble above 2
        tab
        andb #$0F
        cmpb #3
        bcc  .nk
        anda #$F0
        cmpa #$30
        bcs  .yes
.nk:    ldaa #5                 ; queens count for both kinds of line
        oraa T1
        staa T3
        ldx  T4
        ldaa 3,x
        adda 5,x
        beq  .rk
        ldaa #3
        oraa T1
        staa T2
        att_r -17
        att_r -15
        att_r 15
        att_r 17
.rk:    ldx  T4
        ldaa 4,x
        adda 5,x
        beq  .no
        ldaa #4
        oraa T1
        staa T2
        att_r -16
        att_r -1
        att_r 1
        att_r 16
.no:    clc
        rts
.yes:   sec
        rts

; ---------------------------------------------------------------------
; e_dir: A = square 1, B = square 2 -> A = the step from 1 towards 2 when they
; share a rank, file or diagonal (B = 4 straight, 3 diagonal: the slider that
; moves so), else A = 0 (Z=1). Uses T7..T10.
; ---------------------------------------------------------------------
e_dir:  staa T7
        stab T8
        tba
        anda #7
        ldab T7
        andb #7
        sba                     ; A = file difference
        staa T9
        ldaa T8
        anda #$70
        ldab T7
        andb #$70
        sba                     ; A = 16 * rank difference
        staa T10
        ldab T9
        bne  .d1
        tsta                    ; the same file
        beq  .no
        bmi  .dn
        ldaa #16
        bra  .st
.dn:    ldaa #-16
.st:    ldab #4
        rts
.d1:    tsta
        bne  .d2
        ldaa #1                 ; the same rank
        tstb
        bpl  .st
        ldaa #-1
        bra  .st
.d2:    bpl  .a1                ; a diagonal: |16 * rank difference| = 16 * |file difference|
        nega
.a1:    tstb
        bpl  .a2
        negb
.a2:    aslb
        aslb
        aslb
        aslb
        cba
        bne  .no
        ldaa #16
        tst  T10
        bpl  .a3
        ldaa #-16
.a3:    inca
        tst  T9
        bpl  .a4
        deca
        deca
.a4:    ldab #3
        rts
.no:    clra
        rts

; ---------------------------------------------------------------------
; e_line: C=1 if a bishop, rook or queen of colour A (0/8), as the line allows,
; is the first piece met from the square T6 on the line through square B.
; Uses T5..T11.
; ---------------------------------------------------------------------
e_line: staa T5
        ldaa T6
        bsr  e_dir
        beq  .no
        staa T11
        orab T5
        stab T9                 ; the slider of that line
        ldaa #5
        oraa T5
        staa T10                ; the queen
        ldab T6
.w:     addb T11
        bitb #$88
        bne  .no
        ldx  #e_board
        abx
        ldaa 0,x
        beq  .w
        cmpa T9
        beq  .yes
        cmpa T10
        beq  .yes
.no:    clc
        rts
.yes:   sec
        rts

; ---------------------------------------------------------------------
; e_gchk: C=1 if the side to move is in check, worked out from the move that
; led here (in the frame before e_fp; 17 Nov): the piece on its to-square
; giving check, or a line through its from-square opened. The answer is
; e_inchk's whenever the position before that move was legal: from ply 2 on it
; always is (the root's could have the side not to move in check, which set-up
; refuses but the tests use). En passant, castling, promotions and plies 0 and
; 1: e_inchk. Uses T0..T11.
; ---------------------------------------------------------------------
e_gchk:
        if   E_NULL
        bra  e_inchk            ; (a null move leaves no move in its frame)
        else
        ldaa e_ply
        cmpa #2
        bcs  .full
        ldd  e_fp
        subd #E_FR
        xgdx
        tst  F_EPC,x
        bne  .full
        ldaa F_NP,x
        cmpa F_PC,x
        bne  .full              ; a promotion
        anda #7
        staa T3                 ; the mover's type
        ldab F_T,x
        andb #$77
        stab T4                 ; to
        ldab F_F,x
        stab T2                 ; from
        ldab e_side
        lsrb
        lsrb
        lsrb
        ldx  #e_ksq
        abx
        ldab 0,x
        stab T6                 ; the king in question
        cmpa #6
        beq  .king
        cmpa #2
        bcs  .pawn
        beq  .kn
        ldaa T4                 ; a slider: on a line of its kind to the king, nothing between?
        jsr  e_dir
        beq  .disc
        staa T11
        ldaa T3
        cmpa #5
        beq  .sl
        cba
        bne  .disc
.sl:    ldab T4
.sw:    addb T11
        cmpb T6
        beq  .yes
        ldx  #e_board
        abx
        tst  0,x
        beq  .sw
        bra  .disc
.king:  ldaa T4
        suba T2
        cmpa #2
        beq  .full              ; castling
        cmpa #-2
        beq  .full
        bra  .disc
.pawn:  ldaa T6                 ; king - pawn: 15 or 17 for a White pawn, -15 or -17 for a Black
        suba T4
        tst  e_side
        bne  .pw
        nega
.pw:    cmpa #15
        beq  .yes
        cmpa #17
        beq  .yes
        bra  .disc
.kn:    ldaa T6
        suba T4
        ldx  #e_ndir
        ldab #8
.kl:    cmpa 0,x
        beq  .yes
        inx
        decb
        bne  .kl
.disc:  ldaa e_side             ; the mover's line pieces behind the from-square
        eora #8
        ldab T2
        jmp  e_line
.yes:   sec
        rts
.full:  jmp  e_inchk
        endif

; ---------------------------------------------------------------------
; Zobrist helpers: XOR the key at X into e_key.
; ---------------------------------------------------------------------
zx_x:   ldaa 0,x
        eora e_key
        staa e_key
        ldaa 1,x
        eora e_key+1
        staa e_key+1
        ldaa 2,x
        eora e_key+2
        staa e_key+2
        rts
; the same for a Black piece: key bytes rotated (abc -> bca)
zx_xb:  ldaa 1,x
        eora e_key
        staa e_key
        ldaa 2,x
        eora e_key+1
        staa e_key+1
        ldaa 0,x
        eora e_key+2
        staa e_key+2
        rts
zx_side: ldx #t_zob+64*3
        bra  zx_x
zx_ep:  andb #7                 ; B = square (or file)
        ldx  #t_zob+69*3
zx_3:   tba                     ; X += 3 * B
        asla
        aba
        tab
        abx
        bra  zx_x
zx_cas: ldx  #t_zob+65*3        ; B = right number 0..3
        bra  zx_3

; ---------------------------------------------------------------------
; e_add / e_rem: put piece A on square B or take it off, keeping the
; totals, counts, pawn masks, king squares and key. The board itself is
; not touched.
; ---------------------------------------------------------------------
e_add:  clr  e_pv
        bra  e_pc0
e_rem:  psha
        ldaa #1
        staa e_pv
        pula
e_pc0:  staa e_ppc
        stab e_psq
        jsr  pc_key
        std  e_pix
        ; middlegame: value + PST
        addd #t_pmg
        xgdx
        ldab 0,x
        clra
        tstb
        bpl  .p1
        deca
.p1:    std  e_pval
        ldab e_ppc
        andb #7
        aslb
        ldx  #t_vmg
        abx
        ldd  0,x
        addd e_pval
        ldx  #e_mg
        bsr  .apply
        ; endgame
        ldd  e_pix
        addd #t_peg
        xgdx
        ldab 0,x
        clra
        tstb
        bpl  .p2
        deca
.p2:    std  e_pval
        ldab e_ppc
        andb #7
        aslb
        ldx  #t_veg
        abx
        ldd  0,x
        addd e_pval
        ldx  #e_eg
        bsr  .apply
        ; phase
        ldab e_ppc
        andb #7
        ldx  #e_phw
        abx
        ldab 0,x
        tst  e_pv
        bne  .ph1
        addb e_phase
        bra  .ph2
.ph1:   negb
        addb e_phase
.ph2:   stab e_phase
        ; count (index = the piece byte itself)
        ldab e_ppc
        ldx  #e_cnt
        abx
        tst  e_pv
        bne  .c1
        inc  0,x
        bra  .c2
.c1:    dec  0,x
.c2:    ldaa e_ppc
        anda #7
        cmpa #1
        bne  .notp
        jmp  u_pm               ; pawn mask
.notp:  cmpa #6
        bne  .done
        tst  e_pv
        bne  .done
        ldab e_ppc              ; king arriving: remember its square
        lsrb
        lsrb
        lsrb
        ldx  #e_ksq
        abx
        ldaa e_psq
        staa 0,x
.done:  rts

; colour word at X (+2 for Black) += D (add) or -= D (remove)
.apply: tst  e_ppc
        pshb
        ldab e_ppc
        bitb #8
        pulb
        beq  .a1
        inx
        inx
.a1:    tst  e_pv
        bne  .a2
        addd 0,x
        std  0,x
        rts
.a2:    std  e_pval
        ldd  0,x
        subd e_pval
        std  0,x
        rts

; pc_key: piece e_ppc on square B: XOR its key (the square's key rotated
; left by type-1 bits, bytes rotated for Black) into e_key; D = its PST
; index (type-1)*64 + (s6 ^ (black ? 56 : 0))
pc_key:
        tba                     ; s6 = (s + (s & 7)) >> 1
        anda #7
        aba
        lsra
        staa T0                 ; s6
        ; key: the square's key (t_zob + 3*s6) rotated left by type-1 bits
        ; (ref engine.js ZROT), into T1..T3; bytes rotated for Black
        ldab e_ppc
        andb #7
        decb
        pshb                    ; the count
        ldaa T0                 ; 3 * s6
        tab
        asla
        aba
        tab
        ldx  #t_zob
        abx
        ldaa 0,x
        staa T1                 ; the top byte
        ldd  1,x                ; the other two
        tsx
        tst  0,x
        beq  .kd
.kl:    asld                    ; T1:A:B left, the top bit round to the bottom
        rol  T1
        adcb #0
        dec  0,x
        bne  .kl
.kd:    std  T2
        ins
        ldx  #T1
        ldaa e_ppc
        bita #8
        bne  .kb
        jsr  zx_x
        bra  .k2
.kb:    jsr  zx_xb
.k2:
        ; PST index (type-1)*64 + (s6 ^ (black ? 56 : 0))
        ldab T0
        ldaa e_ppc
        bita #8
        beq  .w
        eorb #56
.w:     stab T2
        ldab e_ppc
        andb #7
        decb
        ldaa #64
        mul
        addb T2
        adca #0
        rts

; e_mvpc: the mover e_mpc (not promoting) goes from e_mf to e_mt, as e_rem
; then e_add would do it: value, phase and count don't change, so the
; totals take only the PST difference (17 Nov, speed)
e_mvpc: ldaa e_mpc
        staa e_ppc
        ldab e_mf
        bsr  pc_key
        std  e_pval             ; the from square's PST index
        ldab e_mt
        bsr  pc_key
        std  e_pix              ; the to square's
        ldx  #t_pmg
        stx  T4
        ldx  #e_mg
        bsr  pc_dif
        ldx  #t_peg
        stx  T4
        ldx  #e_eg
        bsr  pc_dif
        ldaa e_ppc
        anda #7
        cmpa #1
        bne  .np
        ldaa #1                 ; a pawn: off the from square's mask, onto the to square's
        staa e_pv
        ldab e_mf
        stab e_psq
        jsr  u_pm
        clr  e_pv
        ldab e_mt
        stab e_psq
        jmp  u_pm
.np:    cmpa #6
        bne  .done
        ldab e_ppc              ; a king: its square
        lsrb
        lsrb
        lsrb
        ldx  #e_ksq
        abx
        ldaa e_mt
        staa 0,x
.done:  rts

; colour word at X (+2 for Black) += table T4[e_pix] - T4[e_pval] (signed bytes)
pc_dif: ldab e_ppc
        bitb #8
        beq  .w
        inx
        inx
.w:     stx  T6
        ldd  T4
        addd e_pval
        xgdx
        ldab 0,x
        clra
        tstb
        bpl  .f
        deca
.f:     std  T8                 ; from
        ldd  T4
        addd e_pix
        xgdx
        ldab 0,x
        clra
        tstb
        bpl  .t
        deca
.t:     subd T8                 ; to - from
        ldx  T6
        addd 0,x
        std  0,x
        rts

; ---------------------------------------------------------------------
; e_recalc: rebuild totals, counts, masks, king squares and key from the
; board, side, castling and en passant square (ref recompute()).
; ---------------------------------------------------------------------
e_recalc:
        ldx  #e_mg
        ldab #e_key+3-e_mg      ; mg, eg, phase, cnt, pm, key are contiguous
.z:     clr  0,x
        inx
        decb
        bne  .z
        clrb
.sq:    stab e_gs
        ldx  #e_board
        abx
        ldaa 0,x
        beq  .nx
        jsr  e_add
.nx:    ldab e_gs
        incb
        bitb #8
        beq  .n2
        addb #8
.n2:    tstb
        bpl  .sq
        tst  e_side
        beq  .s1
        jsr  zx_side
.s1:    clrb
.cs:    stab e_gs
        ldx  #e_bit
        abx
        ldaa 0,x
        bita e_castle
        beq  .cn
        jsr  zx_cas
.cn:    ldab e_gs
        incb
        cmpb #4
        bne  .cs
        ldab e_ep
        cmpb #$FF
        beq  .r
        jsr  zx_ep
.r:     rts

; ---------------------------------------------------------------------
; e_gen: moves for the side to move, written from e_mvtop[e_ply] on.
; e_caps = 1: captures and promotions only. Ends with e_wp after the
; last move. Each move is from, to, ordering score (ref gen()).
; ---------------------------------------------------------------------
e_gen:  ldaa e_side
        staa e_us
        eora #8
        staa e_them
        ldab e_ply
        aslb
        ldx  #e_mvtop
        abx
        ldx  0,x
        stx  e_wp
        ldab e_ply
        aslb
        aslb
        ldx  #e_killer
        abx
        ldd  0,x
        std  T8                 ; T8,T9 killer 1
        ldd  2,x
        std  T10                ; T10,T11 killer 2
        ldx  #e_board           ; scan: X walks the board, B is the square
        clrb
.sq:    ldaa 0,x
        bne  .pc
.nx:    inx
        incb
        bitb #8
        beq  .sq
        addb #8                 ; next rank
        bmi  .end
        ldx  #e_board
        abx
        bra  .sq
.end:   rts
.pc:    stab e_gs
        tab
        andb #8
        cmpb e_us
        bne  .back
        staa e_gpc
        ldaa e_gpc
        anda #7
        cmpa #1
        bne  .np
        jsr  g_pawn
        bra  .back
.np:    cmpa #2
        bne  .nn
        ldx  #e_ndir
        jsr  g_step
        bra  .back
.nn:    cmpa #6
        bne  .nk
        ldx  #e_kdir
        jsr  g_step
        tst  e_caps
        bne  .back
        jsr  g_castle
        bra  .back
.nk:    cmpa #3
        bne  .nb
        ldx  #e_bdir
        ldaa #4
        bra  .sl
.nb:    cmpa #4
        bne  .nr
        ldx  #e_rdir
        ldaa #4
        bra  .sl
.nr:    ldx  #e_kdir            ; queen
        ldaa #8
.sl:    jsr  g_slide
.back:  ldab e_gs
        ldx  #e_board
        abx
        bra  .nx

; put A = from, B = to with score T7 (A, B not kept: 17 Nov)
g_put:  ldx  e_wp
        cpx  #e_mvs+3*E_MVMAX   ; the stack is full: the list is cut short
        bcc  .full
        staa 0,x
        stab 1,x
        ldaa T7
        staa 2,x
        inx
        inx
        inx
        stx  e_wp
.full:  rts

; quiet move A = from, B = to: the killers 150 and 149, any other E_QUNS (unscored: e_pick
; scores them with e_qsc when it first reaches one; 17 Nov, as most nodes cut off before)
g_quiet: staa T5
        stab T6
        cmpa T8
        bne  .k2
        cmpb T9
        bne  .k2
        ldaa #150
        bra  .put
.k2:    cmpa T10
        bne  .ps
        cmpb T11
        bne  .ps
        ldaa #149
        bra  .put
.ps:    ldaa #E_QUNS
.put:   staa T7
        ldaa T5
        ldab T6
        bra  g_put

; capture A = from, B = to, victim T4: score 160 + victim*8 - piece
g_cap:  psha
        ldaa T4
        anda #7
        asla
        asla
        asla
        adda #160
        psha
        ldaa e_gpc
        anda #7
        staa T7
        pula
        suba T7
        staa T7
        pula
        bra  g_put

; promotions A = from, B = to, victim T4 (0 if none): Q, N, R, B
g_promo: staa T5
        stab T6
        ldaa T4
        anda #7
        adda #210
        staa T7
        ldaa T5
        bsr  g_put
        ldaa #120
        staa T7
        ldaa T5
        ldab T6
        orab #$88
        bsr  g_put
        ldaa #20
        staa T7
        ldaa T5
        ldab T6
        orab #$08
        bsr  g_put
        ldaa #19
        staa T7
        ldaa T5
        ldab T6
        orab #$80
        jmp  g_put

; knight or king steps by the 8 offsets at X
g_step: stx  e_gptr
        ldaa #8
        staa e_gcnt
.s1:    ldx  e_gptr
        ldab 0,x
        inx
        stx  e_gptr
        addb e_gs
        bitb #$88
        bne  .s3
        ldx  #e_board
        abx
        ldaa 0,x
        bne  .s2
        tst  e_caps
        bne  .s3
        ldaa e_gs
        jsr  g_quiet
        bra  .s3
.s2:    staa T4
        anda #8
        cmpa e_them
        bne  .s3
        ldaa e_gs
        jsr  g_cap
.s3:    dec  e_gcnt
        bne  .s1
        rts

; slider: A directions from the table at X
g_slide: stx e_gptr
        staa e_gcnt
.d1:    ldx  e_gptr
        ldaa 0,x
        inx
        stx  e_gptr
        staa T1                 ; direction
        ldab e_gs
        tst  e_caps
        bne  .c2
.d2:    addb T1                 ; every move
        bitb #$88
        bne  .d4
        ldx  #e_board
        abx
        ldaa 0,x
        bne  .d3
        stab T0
        ldaa e_gs
        jsr  g_quiet
        ldab T0
        bra  .d2
.c2:    addb T1                 ; captures only: past the empty squares (17 Nov)
        bitb #$88
        bne  .d4
        ldx  #e_board
        abx
        ldaa 0,x
        beq  .c2
.d3:    staa T4                 ; B = the square
        anda #8
        cmpa e_them
        bne  .d4
        ldaa e_gs
        jsr  g_cap
.d4:    dec  e_gcnt
        bne  .d1
        rts

; pawn moves from e_gs
g_pawn: ldab e_gs
        tst  e_us
        bne  .b1
        addb #16
        bra  .b2
.b1:    subb #16
.b2:    stab T0                 ; t = s + fwd
        andb #$70
        tst  e_us
        bne  .b3
        cmpb #$70
        bra  .b4
.b3:    cmpb #$00
.b4:    tpa
        anda #4                 ; Z flag -> promo
        staa T1                 ; T1 != 0: promotion
        ; captures toward the a-file side, then the h-file side
        ldab T0
        decb
        bsr  .cap
        ldab T0
        incb
        bsr  .cap
        ; pushes
        ldab T0
        ldx  #e_board
        abx
        tst  0,x
        bne  .r
        tst  T1
        beq  .q
        clr  T4
        ldaa e_gs
        ldab T0
        jmp  g_promo
.q:     tst  e_caps
        bne  .r
        ldaa e_gs
        ldab T0
        jsr  g_quiet
        ldaa e_gs               ; double step from the start rank
        anda #$70
        tst  e_us
        bne  .d1
        cmpa #$10
        bra  .d2
.d1:    cmpa #$60
.d2:    bne  .r
        ldab T0
        tst  e_us
        bne  .d3
        addb #16
        bra  .d4
.d3:    subb #16
.d4:    stab T2
        ldx  #e_board
        abx
        tst  0,x
        bne  .r
        ldaa e_gs
        ldab T2
        jmp  g_quiet
.r:     rts

; capture onto square B if there is something to take (or it is the ep square)
.cap:   bitb #$88
        bne  .r
        stab T2
        ldx  #e_board
        abx
        ldaa 0,x
        beq  .ep
        staa T4
        anda #8
        cmpa e_them
        bne  .r
        tst  T1
        beq  .c1
        ldaa e_gs
        ldab T2
        jmp  g_promo
.c1:    ldaa e_gs
        ldab T2
        jmp  g_cap
.ep:    cmpb e_ep
        bne  .r
        ldaa #167
        staa T7
        ldaa e_gs
        jmp  g_put

; castling (king on its home square, rights, empty squares, no attack)
g_castle:
        ldab e_us               ; one routine for both sides (17 Nov, -110 bytes)
        beq  .w
        ldab #$70
.w:     orab #4                 ; the king's square e1/e8
        cmpb e_gs
        bne  .r
        andb #$70
        ldx  #e_board
        abx                     ; X = the back rank
        ldaa e_castle
        tst  e_us
        beq  .w2
        lsra
        lsra
.w2:    psha                    ; our rights: bit 0 short, bit 1 long
        ldab e_us
        orab #4                 ; our rook
        bita #1
        beq  .q
        tst  5,x
        bne  .q
        tst  6,x
        bne  .q
        cmpb 7,x
        bne  .q
        pshx
        pshb
        ldaa e_gs
        inca
        bsr  .try
        pulb
        pulx
.q:     pula
        bita #2
        beq  .r
        tst  3,x
        bne  .r
        tst  2,x
        bne  .r
        tst  1,x
        bne  .r
        cmpb 0,x
        bne  .r
        ldaa e_gs
        deca
        bra  .try
.r:     rts
; A = the square the king passes: neither it nor the king's square attacked,
; then the king's two-square move
.try:   psha
        ldaa e_us
        eora #8
        psha                    ; the attacker
        ldab e_gs
        jsr  e_att
        bcs  .t9
        tsx
        ldaa 0,x
        ldab 1,x
        jsr  e_att
        bcs  .t9
        tsx
        ldab 1,x                ; to = 2 * passed - from
        aslb
        subb e_gs
        ldaa e_gs
        ins
        ins
        jmp  g_quiet
.t9:    ins
        ins
        rts

; ---------------------------------------------------------------------
; e_make: A = from, B = to (with promotion bits). Makes the move at ply
; e_ply and moves to the next ply. C=1 if it leaves the mover's king
; attacked (the move is made all the same; unmake it).
; ---------------------------------------------------------------------
e_make: staa e_mf
        stab e_mtc
        andb #$77
        stab e_mt
        ldaa e_side
        staa e_mus
        ldx  #e_board
        abx
        ldaa 0,x
        staa e_mcap
        ldx  e_fp
        staa F_CAP,x
        ldaa e_mf
        staa F_F,x
        ldaa e_mtc
        staa F_T,x
        ldaa e_castle
        staa F_CAS,x
        ldaa e_ep
        staa F_EP,x
        ldaa e_half
        staa F_HALF,x
        ldd  e_key
        std  F_KEY,x
        ldaa e_key+2
        staa F_KEY+2,x
        ldd  e_mg
        std  F_MG,x
        ldd  e_mg+2
        std  F_MG+2,x
        ldd  e_eg
        std  F_MG+4,x
        ldd  e_eg+2
        std  F_MG+6,x
        ldaa e_phase
        staa F_PH,x
        clr  F_EPC,x
        clr  e_mep
        jsr  e_kpush
        ldab e_ep
        cmpb #$FF
        beq  .noep
        jsr  zx_ep
.noep:  ldaa #$FF
        staa e_ep
        inc  e_half
        ldaa e_mcap
        beq  .nocap
        ldab e_mt
        jsr  e_rem
        clr  e_half
.nocap: ldab e_mf
        ldx  #e_board
        abx
        ldaa 0,x
        staa e_mpc
        staa e_mnp
        clr  0,x
        ldaa e_mpc
        anda #7
        cmpa #1
        bne  .notp
        clr  e_half
        ldab e_mt
        andb #$70
        beq  .promo
        cmpb #$70
        beq  .promo
        ldab e_mt               ; en passant capture?
        ldx  e_fp
        cmpb F_EP,x
        bne  .dbl
        tst  e_mcap
        bne  .dbl
        tst  e_mus
        bne  .e1
        subb #16
        bra  .e2
.e1:    addb #16
.e2:    stab e_mcs
        ldx  #e_board
        abx
        ldaa 0,x
        clr  0,x
        ldx  e_fp
        staa F_EPC,x
        inc  e_mep
        jsr  e_rem
        jmp  .place
.dbl:   ldaa e_mt
        suba e_mf
        cmpa #32
        beq  .sep
        cmpa #-32
        bne  .place
.sep:   ldab e_mt               ; an en passant square only with an enemy pawn beside
        ldx  #e_board-1         ; (the off-board half of the 0x88 board is always empty)
        abx                     ; X = the square to the left
        ldaa e_mus
        eora #9                 ; the enemy pawn
        cmpa 0,x
        beq  .s2
        cmpa 2,x
        bne  .place
.s2:    ldaa e_mt
        adda e_mf
        lsra
        staa e_ep
        tab
        jsr  zx_ep
        bra  .place
.promo: ldab e_mtc
        clra
        bitb #8
        beq  .q1
        inca
.q1:    bitb #$80
        beq  .q2
        adda #2
.q2:    tab
        ldx  #e_prom
        abx
        ldaa 0,x
        oraa e_mus
        staa e_mnp
        bra  .place
.notp:  cmpa #6
        bne  .place
        ldaa e_mt
        suba e_mf
        cmpa #2
        beq  .ks
        cmpa #-2
        bne  .place
        ldaa e_mf               ; long castling: rook a -> d
        suba #4
        ldab e_mf
        decb
        bra  .rook
.ks:    ldaa e_mf               ; short castling: rook h -> f
        adda #3
        ldab e_mf
        incb
.rook:  staa e_mrf
        stab e_mrt
        tab
        ldx  #e_board
        abx
        ldaa 0,x
        staa e_mrk
        clr  0,x
        jsr  e_rem
        ldab e_mrt
        ldx  #e_board
        abx
        ldaa e_mrk
        staa 0,x
        jsr  e_add
.place: ldab e_mt
        ldx  #e_board
        abx
        ldaa e_mnp
        staa 0,x
        cmpa e_mpc
        bne  .pro
        jsr  e_mvpc             ; the mover from e_mf to e_mt
        bra  .pl2
.pro:   ldaa e_mpc              ; a promotion: the pawn off, the new piece on
        ldab e_mf
        jsr  e_rem
        ldaa e_mnp
        ldab e_mt
        jsr  e_add
.pl2:
        ldx  e_fp
        ldaa e_mpc
        staa F_PC,x
        ldaa e_mnp
        staa F_NP,x
        ldaa e_castle
        beq  .nocas
        ldab e_mf
        jsr  e_cmask
        ldab e_mt
        jsr  e_cmask
        tab
        eorb e_castle
        beq  .nocas
        staa e_castle
        stab T0                 ; rights that changed
        clrb
.cb:    stab T1
        lsr  T0
        bcc  .cb2
        jsr  zx_cas
.cb2:   ldab T1
        incb
        cmpb #4
        bne  .cb
.nocas: ldaa e_side
        eora #8
        staa e_side
        jsr  zx_side
        inc  e_ply
        ldd  e_fp
        std  e_ofp
        addd #E_FR
        std  e_fp
        ldab e_mus              ; is the mover's king attacked?
        lsrb
        lsrb
        lsrb
        ldx  #e_ksq
        abx
        ldab 0,x
        ldaa e_inck             ; in check, a king move or en passant: full test
        oraa e_mep
        bne  .full
        ldaa e_mpc
        anda #7
        cmpa #6
        beq  .full
        stab T0                 ; otherwise only a piece leaving the king's line
        ldaa e_mf               ; can expose it: same file, rank or diagonal?
        anda #7
        andb #7
        sba
        beq  .full2             ; same file
        bcc  .f1
        nega
.f1:    staa T1                 ; |file difference|
        ldaa e_mf
        lsra
        lsra
        lsra
        lsra
        ldab T0
        lsrb
        lsrb
        lsrb
        lsrb
        sba
        beq  .full2             ; same rank
        bcc  .f2
        nega
.f2:    cmpa T1
        beq  .full2             ; same diagonal
        clc
        rts
.full2: ldab T0                 ; only that line can open: scan it from the king (17 Nov)
        stab T6
        ldaa e_mus
        eora #8
        ldab e_mf
        jmp  e_line
.full:  ldaa e_mus
        eora #8
        jmp  e_att

; push the key onto the history
e_kpush: ldab e_kn
        aslb
        ldx  #e_khist
        abx
        ldd  e_key
        std  0,x
        inc  e_kn
        rts

; A &= castling mask of square B
e_cmask: cmpb #$00
        bne  .m1
        anda #$FD
        rts
.m1:    cmpb #$04
        bne  .m2
        anda #$FC
        rts
.m2:    cmpb #$07
        bne  .m3
        anda #$FE
        rts
.m3:    cmpb #$70
        bne  .m4
        anda #$F7
        rts
.m4:    cmpb #$74
        bne  .m5
        anda #$F3
        rts
.m5:    cmpb #$77
        bne  .m6
        anda #$FB
.m6:    rts

; ---------------------------------------------------------------------
; e_unmake: takes back the move made at the previous ply.
; ---------------------------------------------------------------------
e_unmake:
        dec  e_ply
        ldd  e_ofp
        std  e_fp
        subd #E_FR
        std  e_ofp
        dec  e_kn
        ldaa e_side
        eora #8
        staa e_side
        staa e_mus
        ldx  e_fp
        ldaa F_T,x
        anda #$77
        staa e_mt
        ldaa F_F,x
        staa e_mf
        ldaa F_PC,x
        staa e_mpc
        ldaa F_NP,x
        staa e_mnp
        ldaa F_CAP,x
        staa e_mcap
        ldab e_mf
        ldx  #e_board
        abx
        ldaa e_mpc
        staa 0,x
        ldab e_mt
        ldx  #e_board
        abx
        ldaa e_mcap
        staa 0,x
        ldaa e_mpc
        anda #7
        cmpa #6
        bne  .nk
        ldab e_mus
        lsrb
        lsrb
        lsrb
        ldx  #e_ksq
        abx
        ldaa e_mf
        staa 0,x
        ldaa e_mt
        suba e_mf
        cmpa #2
        beq  .ks
        cmpa #-2
        bne  .nk
        ldaa e_mf               ; long: rook back d -> a
        suba #4
        ldab e_mf
        decb
        bra  .rk
.ks:    ldaa e_mf
        adda #3
        ldab e_mf
        incb
.rk:    staa e_mrf              ; board[rf] = board[rt], board[rt] = 0
        ldx  #e_board
        abx
        ldaa 0,x
        clr  0,x
        ldab e_mrf
        ldx  #e_board
        abx
        staa 0,x
.nk:    ldx  e_fp
        ldaa F_EPC,x
        beq  .cnt
        staa e_mrk
        ldab e_mt
        tst  e_mus
        bne  .e1
        subb #16
        bra  .e2
.e1:    addb #16
.e2:    stab e_mcs
        ldx  #e_board
        abx
        staa 0,x
        ldaa e_mrk              ; its count and pawn mask
        ldab e_mcs
        bsr  u_inc
.cnt:   ldaa e_mnp              ; the same piece, not a pawn: no count or mask changes
        cmpa e_mpc
        bne  .cn2
        anda #7
        cmpa #1
        bne  .cn3
.cn2:   ldaa e_mnp              ; the arrived piece leaves the counts...
        ldab e_mt
        bsr  u_dec
        ldaa e_mpc              ; ...the mover is back...
        ldab e_mf
        bsr  u_inc
.cn3:   ldaa e_mcap             ; ...and so is the captured piece
        beq  .rest
        ldab e_mt
        bsr  u_inc
.rest:  ldx  e_fp
        ldaa F_CAS,x
        staa e_castle
        ldaa F_EP,x
        staa e_ep
        ldaa F_HALF,x
        staa e_half
        ldd  F_KEY,x
        std  e_key
        ldaa F_KEY+2,x
        staa e_key+2
        ldd  F_MG,x
        std  e_mg
        ldd  F_MG+2,x
        std  e_mg+2
        ldd  F_MG+4,x
        std  e_eg
        ldd  F_MG+6,x
        std  e_eg+2
        ldaa F_PH,x
        staa e_phase
        rts

; count and pawn mask of piece A on square B: u_inc adds, u_dec removes
u_inc:  clr  e_pv
        bra  u_c
u_dec:  psha
        ldaa #1
        staa e_pv
        pula
u_c:    staa e_ppc
        stab e_psq
        tab
        ldx  #e_cnt
        abx
        tst  e_pv
        bne  .d
        inc  0,x
        bra  .p
.d:     dec  0,x
.p:     ldaa e_ppc
        anda #7
        cmpa #1
        beq  u_pm
        rts
; pawn mask of pawn e_ppc on square e_psq: e_pv 0 sets its bit, 1 clears it
u_pm:   ldab e_psq
        andb #7
        incb
        ldaa e_ppc
        bita #8
        beq  .w
        addb #10
.w:     ldx  #e_pm
        abx
        ldab e_psq
        lsrb
        lsrb
        lsrb
        lsrb
        pshx
        ldx  #e_bit
        abx
        ldaa 0,x
        pulx
        tst  e_pv
        bne  .c
        oraa 0,x
        staa 0,x
.r:     rts
.c:     coma
        anda 0,x
        staa 0,x
        rts

; ---------------------------------------------------------------------
; null move (ref makeNull / unmakeNull)
; ---------------------------------------------------------------------
        if   E_NULL
e_mnull: ldx e_fp
        ldaa e_ep
        staa F_EP,x
        ldaa e_half
        staa F_HALF,x
        ldd  e_key
        std  F_KEY,x
        ldaa e_key+2
        staa F_KEY+2,x
        bsr  e_kpush
        ldab e_ep
        cmpb #$FF
        beq  .n1
        bsr  zx_ep
.n1:    ldaa #$FF
        staa e_ep
        ldaa e_side
        eora #8
        staa e_side
        bsr  zx_side
        inc  e_half
        inc  e_ply
        ldd  e_fp
        std  e_ofp
        addd #E_FR
        std  e_fp
        rts

e_unull: dec e_ply
        ldd  e_ofp
        std  e_fp
        subd #E_FR
        std  e_ofp
        dec  e_kn
        ldaa e_side
        eora #8
        staa e_side
        ldx  e_fp
        ldaa F_EP,x
        staa e_ep
        ldaa F_HALF,x
        staa e_half
        ldd  F_KEY,x
        std  e_key
        ldaa F_KEY+2,x
        staa e_key+2
        rts
        endif
