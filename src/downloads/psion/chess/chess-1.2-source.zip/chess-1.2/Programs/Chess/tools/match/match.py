"""Parallel match runner: reference engine (ref/uci.js) vs Stockfish or vs itself.

    python match.py NAME A B [--openings 0:80] [--workers 6] [--maxply 200]

Engine specs:
    ref                      snapshot snap_v2 of ref/ (2026-11-16 00:25: 24-bit keys, MAXPLY 24, a1 and
                             null-move fixes in ref) via uci_wrap.js; defaults Nodes=6000, HashBits=9,
                             all features on; extra wrapper options Margin (levels 1-4) and Seed
    v1                       first snapshot with my a1 + null-move patches (snap_fixed)
    asis                     first snapshot unpatched (snap_asis)
    snap_<x>                 any snapshot folder snap_<x> here (e.g. diagnostic variants)
    orig                     ref/uci.js itself (live files, overflows after ~MAXPLY game moves)
    ref:Nodes=36000          ...with UCI options (comma separated), e.g. ref:NullMove=false
    sf:1500                  Stockfish 19, UCI_LimitStrength, UCI_Elo=1500, movetime 100 ms
    sf:1500:50               ...movetime 50 ms

Each opening (line of openings.txt) is played twice, A as White then A as Black.
Games reaching --maxply plies (opening included) are adjudicated drawn.
Results go to results/NAME.jsonl (one JSON object per game, appended; already-played
(opening, colour) pairs are skipped, so a run can be extended or resumed).
Illegal / missing moves and engine crashes are caught, logged with FEN and move list,
and the game is scored as a loss for the offending engine (flagged 'error').
"""
import argparse
import json
import multiprocessing as mp
import os
import sys
import time
import traceback

import chess
import chess.engine


def nohome(s):
    """s with the home folder (it names the user) shortened to ~, for the logs."""
    return s.replace(os.path.expanduser('~'), '~')


HERE = os.path.dirname(os.path.abspath(__file__))
CHESS = os.path.normpath(os.path.join(HERE, '..', '..'))
REF = os.path.join(CHESS, 'ref', 'uci.js')
WRAP = os.path.join(HERE, 'uci_wrap.js')
SF = os.path.join(CHESS, 'ext', 'stockfish', 'stockfish', 'stockfish-windows-x86-64-universal.exe')


def parse_spec(spec):
    parts = spec.split(':')
    if parts[0] in ('ref', 'v1', 'asis', 'orig') or parts[0].startswith('snap_'):
        opts = {}
        if len(parts) > 1 and parts[1]:
            for kv in parts[1].split(','):
                k, v = kv.split('=')
                opts[k] = v
        return {'kind': 'ref', 'which': parts[0], 'opts': opts, 'nodes': int(opts.get('Nodes', 6000))}
    if parts[0] == 'sf':
        return {'kind': 'sf', 'elo': int(parts[1]), 'ms': int(parts[2]) if len(parts) > 2 else 100}
    raise ValueError(spec)


class Player:
    def __init__(self, spec):
        self.spec = parse_spec(spec)
        self.eng = None
        self.start()

    def start(self):
        s = self.spec
        if s['kind'] == 'ref':
            cmd = ['node', WRAP, os.path.join(HERE, s['which'])] if s['which'].startswith('snap_') else {'orig': ['node', REF],
                   'asis': ['node', WRAP, os.path.join(HERE, 'snap_asis')],
                   'v1': ['node', WRAP, os.path.join(HERE, 'snap_fixed')],
                   'ref': ['node', WRAP, os.path.join(HERE, 'snap_v2')]}[s['which']]
            self.eng = chess.engine.SimpleEngine.popen_uci(cmd)
            for k, v in s['opts'].items():
                if k == 'Nodes':
                    continue          # passed per move as 'go nodes N'
                # python-chess validates against the declared option types
                val = (v.lower() == 'true') if v.lower() in ('true', 'false') else int(v)
                self.eng.configure({k: val})
            self.limit = chess.engine.Limit(nodes=s['nodes'])
        else:
            self.eng = chess.engine.SimpleEngine.popen_uci(SF)
            self.eng.configure({'Threads': 1, 'Hash': 16, 'UCI_LimitStrength': True, 'UCI_Elo': s['elo']})
            self.limit = chess.engine.Limit(time=s['ms'] / 1000)

    def restart(self):
        try:
            self.eng.quit()
        except Exception:
            try:
                self.eng.close()
            except Exception:
                pass
        self.start()

    def play(self, board, game):
        t0 = time.perf_counter()
        r = self.eng.play(board, self.limit, game=game, info=chess.engine.INFO_BASIC)
        dt = time.perf_counter() - t0
        return r, dt


_players = None


def _init(spec_a, spec_b):
    global _players
    _players = (Player(spec_a), Player(spec_b))


def play_game(job):
    oi, opening, a_white, maxply = job
    pa, pb = _players
    board = chess.Board()
    for u in opening.split():
        board.push_uci(u)
    game = object()
    stats = {'a': [], 'b': []}
    rec = {'opening': oi, 'a_white': a_white, 'error': None}
    result = None
    reason = None
    while True:
        if board.is_game_over(claim_draw=True):
            out = board.outcome(claim_draw=True)
            result = out.result()
            reason = out.termination.name.lower()
            break
        if board.ply() >= maxply:
            result, reason = '1/2-1/2', 'adjudicated_maxply'
            break
        a_to_move = (board.turn == chess.WHITE) == a_white
        who, p = ('a', pa) if a_to_move else ('b', pb)
        fen = board.fen()
        try:
            r, dt = p.play(board, game)
            mv = r.move
            if mv is None or mv not in board.legal_moves:
                raise chess.engine.EngineError(f'illegal or null move {mv}')
        except Exception as ex:   # illegal move, crash, timeout
            rec['error'] = {'engine': who, 'spec': p.spec, 'fen': fen,
                            'moves': ' '.join(m.uci() for m in board.move_stack),
                            'exc': nohome(repr(ex)), 'trace': nohome(traceback.format_exc())[-1500:]}
            p.restart()
            loser_white = board.turn == chess.WHITE
            result = '0-1' if loser_white else '1-0'
            reason = 'error'
            break
        info = r.info or {}
        stats[who].append([info.get('depth'), info.get('nodes'), round(dt, 4)])
        board.push(mv)
    score_white = {'1-0': 1.0, '0-1': 0.0, '1/2-1/2': 0.5}[result]
    rec.update(result=result, reason=reason, plies=board.ply(),
               score_a=score_white if a_white else 1 - score_white,
               moves=' '.join(m.uci() for m in board.move_stack),
               stats_a=stats['a'], stats_b=stats['b'])
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('name')
    ap.add_argument('a')
    ap.add_argument('b')
    ap.add_argument('--openings', default='0:80')
    ap.add_argument('--workers', type=int, default=6)
    ap.add_argument('--maxply', type=int, default=200)
    ap.add_argument('--opfile', default='openings.txt', help='opening file in this folder (openings_big.txt: 1,242 openings)')
    ap.add_argument('--start', type=int, default=0, help='instead of openings.txt: N games from the start position (each colour), for engines with their own book')
    args = ap.parse_args()

    if args.start:
        ops = [''] * args.start
    else:
        with open(os.path.join(HERE, args.opfile)) as f:
            ops = [l.strip() for l in f if l.strip()]
    lo, hi = (int(x) for x in args.openings.split(':'))
    os.makedirs(os.path.join(HERE, 'results'), exist_ok=True)
    path = os.path.join(HERE, 'results', args.name + '.jsonl')
    done = set()
    if os.path.exists(path):
        with open(path) as f:
            for l in f:
                d = json.loads(l)
                done.add((d['opening'], d['a_white']))
    jobs = [(i, ops[i], aw, args.maxply) for i in range(lo, min(hi, len(ops)))
            for aw in (True, False) if (i, aw) not in done]
    meta = {'a': args.a, 'b': args.b}
    print(f'{args.name}: {args.a} vs {args.b}, {len(jobs)} games to play', flush=True)
    t0 = time.time()
    tot = [0, 0, 0]
    n = 0
    with mp.Pool(args.workers, initializer=_init, initargs=(args.a, args.b)) as pool, open(path, 'a') as f:
        for rec in pool.imap_unordered(play_game, jobs):
            rec.update(meta)
            f.write(json.dumps(rec) + '\n')
            f.flush()
            n += 1
            tot[{1.0: 0, 0.5: 1, 0.0: 2}[rec['score_a']]] += 1
            if rec['error']:
                print('ERROR:', json.dumps(rec['error'])[:600], flush=True)
            if n % 20 == 0 or n == len(jobs):
                print(f'  {n}/{len(jobs)}  A +{tot[0]} ={tot[1]} -{tot[2]}  {time.time() - t0:.0f}s', flush=True)


if __name__ == '__main__':
    main()
