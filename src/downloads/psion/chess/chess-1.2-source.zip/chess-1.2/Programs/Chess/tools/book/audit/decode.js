'use strict';
// Independent decoder and structure check for data/book.bin (does not use tools/book/book.py).
// Legality comes from the reference engine (ref/search.js), not python-chess.
//
//   node tools/book/audit/decode.js [book.bin]            check, print counts; exit 1 on any error
//   node tools/book/audit/decode.js [book.bin] --json out  also write the decoded tree as JSON:
//        {groups: [{off, path: [uci...], moves: [{uci, fl, sub}]}]}   sub = offset of reply group or null
//
// Checks: every move legal in its position (and no pawn move to the last rank, the format has no
// promotions); no duplicate move in a group; J set exactly when the reply group is > 256 bytes and
// its 3-byte length exact; J only with R; every group ends with an L entry before its parent's end
// (the parent's J length when there is one, else the end of the file); the file consumed exactly;
// every group has a P move; P moves come before the others (format rule, reported as a warning).
const fs = require('fs');
const path = require('path');
const { Engine, legalMoves, sqName } = require('../../../ref/search.js');

const ROOT = path.resolve(__dirname, '..', '..', '..');
const args = process.argv.slice(2);
let jsonOut = null;
const ji = args.indexOf('--json');
if (ji >= 0) { jsonOut = args[ji + 1]; args.splice(ji, 2); }
const file = args[0] || path.join(ROOT, 'data', 'book.bin');
const data = fs.readFileSync(file);

const L = 8, R = 4, J = 2, P = 1;
const errors = [], warnings = [];
const groups = [];
const st = { moves: 0, groups: 0, P: 0, J: 0, leaves: 0, maxDepth: 0, noP: 0 };
const perPly = {};
const e = new Engine();
const sq88 = s => ((s >> 3) << 4) | (s & 7);
const err = (m) => { errors.push(m); if (errors.length > 50) { report(); process.exit(1); } };

// walk the group at pos; limit = first byte the group may not touch. Returns the end offset.
function walk(pos, limit, pathU) {
  st.groups++;
  const g = { off: pos, path: pathU.slice(), moves: [] };
  groups.push(g);
  const legal = legalMoves(e);
  const seen = new Set();
  let sawNonP = false, anyP = false;
  for (;;) {
    if (pos + 2 > limit) { err(`group at ${g.off} (${pathU.join(' ')}) runs past ${limit} without an L entry`); return limit; }
    const start = pos;
    const w = (data[pos] << 8) | data[pos + 1];
    pos += 2;
    const fr = (w >> 10) & 63, to = (w >> 4) & 63, fl = w & 15;
    const u = sqName(sq88(fr)) + sqName(sq88(to));
    let len = null;
    if (fl & J) {
      if (pos + 3 > limit) { err(`length at ${pos} runs past ${limit}`); return limit; }
      len = (data[pos] << 16) | (data[pos + 1] << 8) | data[pos + 2];
      pos += 3;
      st.J++;
      if (!(fl & R)) err(`J without R at ${start}`);
    }
    const f88 = sq88(fr), t88 = sq88(to);
    const lm = legal.find(m => m[0] === f88 && (m[1] & 0x77) === t88);
    const pawn = (e.b[f88] & 7) === 1;
    if (!lm) err(`illegal move ${u} at offset ${start} after [${pathU.join(' ')}]`);
    else if (pawn && ((t88 >> 4) === 7 || (t88 >> 4) === 0)) err(`promotion ${u} at ${start} (format has none)`);
    if (seen.has(u)) err(`duplicate move ${u} at ${start}`);
    seen.add(u);
    st.moves++;
    const ply = pathU.length + 1;
    perPly[ply] = (perPly[ply] || 0) + 1;
    st.maxDepth = Math.max(st.maxDepth, ply);
    if (fl & P) { st.P++; anyP = true; if (sawNonP) warnings.push(`P move ${u} after a non-P move at ${start}`); }
    else sawNonP = true;
    const mv = { uci: u, fl, sub: null };
    g.moves.push(mv);
    if (fl & R) {
      mv.sub = pos;
      const childLimit = len !== null ? Math.min(pos + len, limit) : limit;
      if (len !== null && pos + len > limit) err(`J length ${len} at ${start} runs past the parent's end ${limit}`);
      if (lm) {
        e.make(lm[0], lm[1]);
        const end = walk(pos, childLimit, pathU.concat([u]));
        e.unmake();
        const size = end - pos;
        if (len !== null && size !== len) err(`J length ${len} != actual ${size} at ${start}`);
        if ((len !== null) !== (size > 256)) err(`J flag ${len !== null} wrong for a ${size}-byte group at ${start}`);
        pos = len !== null ? pos + len : end;
      } else {
        if (len === null) return limit;   // cannot continue without a position
        pos += len;
      }
    } else st.leaves++;
    if (fl & L) break;
  }
  if (!anyP) { st.noP++; err(`group at ${g.off} (${pathU.join(' ') || 'start'}) has no P move`); }
  return pos;
}

function report() {
  console.log(`book: ${file}`);
  console.log(`bytes ${data.length}, moves ${st.moves}, groups ${st.groups}, P ${st.P}, J ${st.J}, leaves ${st.leaves}, max depth ${st.maxDepth}`);
  console.log('moves per ply: ' + Object.keys(perPly).map(k => k + ':' + perPly[k]).join(' '));
  console.log(`groups without a P move: ${st.noP}`);
  console.log(`warnings: ${warnings.length}` + (warnings.length ? '  e.g. ' + warnings.slice(0, 3).join('; ') : ''));
  console.log(errors.length ? `ERRORS: ${errors.length}\n  ` + errors.slice(0, 20).join('\n  ') : 'structure OK: 0 errors');
}

const end = walk(0, data.length, []);
if (end !== data.length) err(`file not consumed exactly: root group ends at ${end} of ${data.length}`);
report();
if (jsonOut) fs.writeFileSync(jsonOut, JSON.stringify({ file, bytes: data.length, groups }), 'utf8');
process.exit(errors.length ? 1 : 0);
