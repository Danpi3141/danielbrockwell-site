'use strict';
// Headless UI tests (work with the stub or the real engine).
//   node tests/ui/t_ui.js
const L = require('./lib.js');
const { check, keys } = L;

// keys under the digits (no SHIFT): 1 U, 2 V, 3 W, 4 O, 5 P, 6 Q, 7 I, 8 J
const DIG = { 1: 'U', 2: 'V', 3: 'W', 4: 'O', 5: 'P', 6: 'Q', 7: 'I', 8: 'J' };
function typeMove(m, mv) {
  keys(m, [mv[0], DIG[mv[1]], mv[2], DIG[mv[3]]]);
}
const row = (m, r) => m.screen()[r];
const board = (m) => L.peekSym(m, 'e_board', 128);

// 1. launch
let m = L.start();
check(row(m, 3).startsWith('RNBQKBNR1 W'), 'start: rank 1 and the turn', m);
check(row(m, 2).startsWith('PPPPPPPP2'), 'start: rank 2', m);
check(m.cells().slice(12, 20).every((c) => c === 0) && m.cells().slice(72, 80).every((c) => c === 4), 'start: map rows 8/7 and 2/1', m);
check(JSON.stringify(m.udg(5)) === JSON.stringify([31, 17, 31, 0, 0, 0, 0, 0]), 'glyph 5 = white over empty', m);

// 2. a refused first square: a black pawn
keys(m, ['E', 'I']);
check(row(m, 3).includes('NOT YOUR PIECE'), 'e7 refused: NOT YOUR PIECE', m);
keys(m, ['DEL']);             // back to nothing typed

// 3. typed move
keys(m, ['E']);
typeMove(m, 'E2E4'.slice(0));   // (the first E is ignored: a rank is due)
L.idle(m);
let b = board(m);
check(b[0x34] === 1 && b[0x14] === 0, 'e2e4 played (pawn on e4)', m);
check(b.filter((x) => x === 9).length === 8, 'the reply kept 8 black pawns', m);

// 4. take back
keys(m, ['DEL']);
L.idle(m);
b = board(m);
check(b[0x14] === 1 && b[0x34] === 0, 'DEL took back the move and the reply', m);
check(L.peekSym(m, 'g_n')[0] === 0, 'record empty after take back', m);

// 5. pointing: arrows then EXE picks up e2 (cursor starts there), UP steps to a destination, EXE puts down
keys(m, ['UP']);              // cursor appears on e2
keys(m, ['EXE']);             // pick up e2
check(row(m, 2).slice(9, 12).includes('E2'), 'pointing: E2 picked up', m);
keys(m, ['RIGHT']);           // first destination (e3 or e4)
keys(m, ['EXE']);
L.idle(m);
b = board(m);
check(b[0x14] === 0 && (b[0x24] === 1 || b[0x34] === 1), 'pointing: e-pawn moved', m);

// 6. menu and the split layout
keys(m, ['ON']);
m.runSeconds(1);
check(row(m, 0).includes('NEW GAME'), 'menu shows', m);
keys(m, ['UP']);              // the menu wraps round: UP at the top to the last item, DOWN back
m.runSeconds(1);
check(row(m, 3).startsWith('>SAVE AND LEAVE') && row(m, 0).includes('SETTINGS'), 'menu: UP at the top goes to the bottom', m);
keys(m, ['DOWN']);
m.runSeconds(1);
check(row(m, 0).startsWith('>NEW GAME'), 'menu: DOWN at the bottom goes to the top', m);
keys(m, ['S', 'S']);          // SET UP, then SETTINGS
keys(m, ['EXE']);
m.runSeconds(1);
check(row(m, 0).includes('BOARD') && row(m, 0).includes('MAP'), 'settings: board line', m);
keys(m, ['RIGHT']);
check(row(m, 0).includes('SPLIT'), 'settings: board -> SPLIT', m);
keys(m, ['ON']);
m.runSeconds(2);
check(row(m, 0).startsWith('rnbqkbnr8'), 'split board drawn (rank 8 number in column 9)', m);
check(row(m, 3)[8] === '5', 'split board: rank 5 on the last row', m);

// 7. save, leave, resume
const before = board(m).slice();
keys(m, ['ON']);
m.runSeconds(1);
keys(m, ['S', 'S', 'S']);     // SET UP, SETTINGS, SAVE AND LEAVE
keys(m, ['EXE']);
m.runSeconds(3);
check(m.screenText().includes('Prog') || m.screenText().includes('Run') || m.screenText().includes('Edit'), 'left the game', m);
keys(m, ['ON']);
m.runSeconds(1);
m.press('ON', 3, 10);
m.runSeconds(1);
m.runProc('CHESS', 'B');
m._base = null;
m.runSeconds(5);
const after = board(m);
check(JSON.stringify(before) === JSON.stringify(after), 'resumed on the same position', m);
check(row(m, 0)[8] === '8', 'resumed with the split layout (settings kept)', m);
console.log('all UI tests passed');
