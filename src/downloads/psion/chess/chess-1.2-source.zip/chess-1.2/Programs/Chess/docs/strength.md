# Playing strength of the reference engine

Measured 2026-11-15/16 by playing the PC reference (`ref/`) against Stockfish 19 with limited
strength, and against itself. Scripts and raw results are in `tools/match/`. Each result file is
`tools/match/results/<name>.jsonl`, with one game per line: moves, result, and depth, nodes and time
for every engine move.

## Summary

| Node cap (Psion time at ~83 nodes/s) | Elo (Stockfish UCI_Elo scale) | 95% CI (statistical) | Games |
|---|---|---|---|
| **2,500 (30 s, level 7)** | **~1625** | 1609-1643 | 1,452 |
| 6,000 (72 s) | ~1705 | 1684-1724 | 968 |
| 15,000 (3 min) | ~1840 | 1821-1859 (extrapolated, see below) | 968 |

These figures are for the current engine: snapshot v2, with MVCAP 180, MAXPLY 24 and 24-bit keys.
v3, the ref/ as of 00:30, plays the same within noise (see "Engine versions").

**The biggest single finding is MVCAP = 180.** It costs **~135 Elo at 6,000 nodes and ~43 Elo at
2,500 nodes** compared with MVCAP = 280 (self-play, 484 games each). With MVCAP 280 the engine
measured ~1800 at 6,000 nodes.

**Feature recommendations at 2,500 nodes** (self-play, 484 games each):
- Turn off LMR: +40 Elo.
- Turn off PVS as well: about +30 Elo more.
- Keep Futility: slight gain.
- NullMove is neutral.
- CheckExt is neutral at 2,500 nodes and helps at 6,000.
- 512 TT entries (HashBits 9) is worth ~20 Elo over 256 entries.

**Bugs found** (the first two are already fixed in ref/; the third is not):
- In the first snapshot (before 23:42), a best move from a1 was never returned.
- In the same snapshot, the null-move child used a stale `mvTop[ply+1]`, which corrupted ancestor
  move lists. The engine then crashed in `make()`, or could play garbage.
- **ref/uci.js still overflows** in `position ... moves` once the game passes ~MAXPLY moves. The
  details are in "Bugs found".

## Method

**Openings.** `tools/match/openings.txt` holds 242 openings:
- 42 hand-picked common openings of 4-8 plies.
- 200 balanced 8-ply lines generated with Stockfish. Each is a random walk over moves within 25 cp
  of the best at depth 10, kept only if |eval| ≤ 50 cp at depth 12.

Every opening is played with both colours, so each match is 484 games. The engines are
deterministic, so all self-play games are distinct.

**Rules.**
- Games end on mate, stalemate, insufficient material, threefold repetition or the 50-move rule.
  A game is adjudicated drawn at 200 plies, opening included. This happened in 4-15% of games;
  the number is listed per match in `analyze.py` output as `adj`.
- 6 workers per match, sometimes 2 matches at once. The machine has 16 logical cores.
- The opponent was Stockfish 19 with `UCI_LimitStrength=true`, `UCI_Elo=N`, Threads=1, Hash=16 and
  a movetime of 50 ms; the first probes used 100 ms.

**Stockfish's strength scale.** UCI_Elo is calibrated at 120 s + 1 s against CCRL 40/4, according
to the Stockfish wiki. It works by choosing a weakened move at depth `1 + skill level`, which is 1-4
in the range used here. Stockfish reaches that depth in a few ms, so the 50 ms movetime does not
change its strength. But that also means "1600" here is not a FIDE or human rating.

The scale is also coarse in this range:
- At 2,500 nodes the engine scored the same against SF 1600 and SF 1700 (48.5% and 48.3%).
- In the first series it scored the same against SF 1800 and SF 1900.

So treat every Elo as ±50 on top of the statistical CI.

**Elo calculation.**
- Elo difference = -400·log10(1/s - 1).
- The 95% CI comes from the pentanomial variance of game pairs (the same opening with both colours).
- The combined Elo against several SF levels is a maximum-likelihood fit, with SE from Fisher
  information × dispersion.

**Self-play caveat.** Self-play exaggerates Elo differences compared with play against other
opponents. Also, at a fixed node cap every node costs the same, but on the Psion a qsearch node and
a full node do not cost the same time.

**Wrapper.** All runs go through `tools/match/uci_wrap.js`, not `ref/uci.js`, because of the overflow
bug described below. It loads a frozen snapshot of `engine.js`, `search.js` and `tables.js` and
speaks the same UCI. It adds three options: `Margin` and `Seed` (for levels 1-4) and `NullFallback`.

## 1. Elo at 2,500 nodes (30 s a move, headline)

| Opponent | N | +/=/- | Score | Elo diff [95% CI] |
|---|---|---|---|---|
| SF 1500 | 484 | 270/79/135 | 63.9% | +100 [+73, +128] |
| SF 1600 | 484 | 183/103/198 | 48.5% | -11 [-40, +18] |
| SF 1700 | 484 | 179/110/195 | 48.3% | -11 [-39, +16] |

The fit gives **1626 ± 17**. The flat result between 1600 and 1700 means the honest range is
1600-1690.

## 2. Elo at 6,000 nodes

Current engine (v2):

| Opponent | N | +/=/- | Score | Elo diff [95% CI] |
|---|---|---|---|---|
| SF 1700 | 484 | 172/106/206 | 46.5% | -24 [-52, +3] |
| SF 1800 | 484 | 135/123/226 | 40.6% | -66 [-95, -38] |

The fit gives **1704 ± 20**.

First series, run with my patched first snapshot (v1: MVCAP 280, MAXPLY 32, 32-bit keys):

| Opponent | N | Score | Elo diff [95% CI] |
|---|---|---|---|
| SF 1600 | 484 | 65.9% | +115 [+85, +145] |
| SF 1700 | 484 | 61.9% | +84 [+55, +114] |
| SF 1800 | 484 | 48.2% | -12 [-40, +15] |
| SF 1900 | 484 | 49.7% | -2 [-28, +24] |

The fit gives 1800 ± 15. Head to head, v2 against v1 at 6,000 nodes scored -133 [-161, -107]. All of
that gap is MVCAP (section 6).

## 3. Elo at 15,000 nodes (3 min a move)

| Opponent | N | +/=/- | Score | Elo diff [95% CI] |
|---|---|---|---|---|
| SF 1900 | 484 | 104/155/225 | 37.5% | -89 [-115, -63] |
| SF 2000 | 484 | 73/168/243 | 32.4% | -127 [-154, -102] |

The fit gives **1840 ± 19**. Both levels are above the engine, so this estimate is extrapolated from
one side. Each step of about ×2.4 in nodes is worth roughly +80 to +135 Elo.

## Depth and time per move

Measured on an idle PC with `timing.py`, over 400 positions sampled from games (opening excluded).
"Depth" is the last completed iteration.

| Nodes | Mean depth | Median | Opening (<30 plies) | Middlegame (30-69) | Endgame (≥70) | PC time/move |
|---|---|---|---|---|---|---|
| 2,500 | 3.15 | 3 | 2.80 | 2.79 | 3.63 | 1.9 ms |
| 6,000 | 4.01 | 4 | 3.58 | 3.66 | 4.53 | 3.6 ms |
| 15,000 | 4.92 | 5 | 4.50 | 4.64 | 5.37 | 8.5 ms |

Depth distribution in games at 6,000 nodes (v1): depth 3 = 31%, depth 4 = 41%, depth 5 = 13%, ≤2 = 9%.

## 4. Feature tests (self-play, 484 games each)

Each row is the default engine against the same engine with one option off. A positive Elo means
the feature helps; a negative Elo means the engine is stronger without it.

| Feature | 2,500 nodes (v2) | 6,000 nodes (v1) |
|---|---|---|
| NullMove | -5 [-20, +10] | 0 [-18, +18] |
| LMR | **-40 [-66, -15]** | **-43 [-69, -18]** |
| Futility | +22 [-1, +44] | +8 [-13, +29] |
| CheckExt | -17 [-42, +9] | **+40 [+18, +63]** |
| PVS (off also disables LMR, see `search.js`) | **-53 [-80, -26]** | **-71 [-97, -45]** |

With LMR off, I also tested PVS on against PVS off at 2,500 nodes: PVS on scored **-31 [-56, -7]**.
So plain alpha-beta beats PVS here, probably because zero-window re-searches waste nodes when the
budget is this small.

Recommendations:
- **Turn LMR off.** It is clearly harmful at both node counts.
- **Turn PVS off too** at Psion budgets. That takes LMR with it, since the code only does LMR
  inside PVS.
- **Keep Futility.** The gain is small but positive and it costs nothing.
- **NullMove makes no difference.** Keep it, or drop it if code or RAM is tight.
- **Keep CheckExt.** It is neutral at 2,500 nodes and clearly positive at 6,000.

These are self-play numbers and the true gains are probably smaller. One more 2-minute run would
confirm the combination: `python match.py x ref:Nodes=2500,LMR=false,PVS=false ref:Nodes=2500`.

## 5. Hash size (2,500 nodes, self-play against HashBits 9)

| HashBits | Elo against 9 |
|---|---|
| 8 (256 entries, the LZ64 size per ISSUES.txt) | -22 [-43, 0] |
| 10 (1,024 entries) | +20 [+2, +38] |

That is about 20 Elo per doubling.

## 6. Engine versions and MVCAP

| Comparison (self-play) | 2,500 nodes | 6,000 nodes |
|---|---|---|
| v2 against v1 | -43 [-65, -22] | -133 [-161, -107] |
| v2 with MVCAP 280 against v2 (MVCAP 180) | **+43 [+22, +64]** | **+135 [+109, +162]** |
| v2 with MAXPLY 32 against v2 (MAXPLY 24) | not run | 0 (identical games) |
| v3 (ref/ at 00:30) against v2 | -14 [-36, +8] | +11 [-14, +36] |

MVCAP turns any node with more than 180 moves stacked below it into a leaf, which takes a static
eval with no qsearch. In middlegames that is only about 5 plies of move lists. Search plus qsearch
hits it often, and more often at higher node counts. In v1 at 6,000 nodes the stack peaked at
about 285-320 entries.

If the 400-entry stack can't grow, there are cheaper ways to stay inside it than a fixed 180 cap
(400 minus a worst-case 218-move node):
- **Separate caps for full and capture-only generation.** A qsearch generation is small, so it can
  safely go much higher.
- **A bounds check in `gen`.**

The 24-bit keys and MAXPLY 24 cost nothing measurable.

Snapshot hashes (`tools/match/make_snap.py`):

| Snapshot | engine.js | search.js | tables.js |
|---|---|---|---|
| v1 (`snap_asis`; `snap_fixed` is the patched copy) | 58e70287… | b1fcc848… | 3938b403… |
| v2 (`snap_v2`, 00:25) | 5897ff84… | 39921649… | 020a3825… |
| v3 (`snap_v3`, 00:30) | 549cac04… | a5d18c7c… | 46046f0b… |

## 7. Levels 1-4 (margin), rough

The settings below come from `src/kernel/kcore.asm`: `lv_secs` = 1, 1, 2, 3, 5, 10, 30, 100 s and
`lv_marg` = 300, 150, 70, 30 cp for levels 1-4. Seconds are converted to nodes at 83 nodes/s. The
runs used v2 plus `NullFallback`, which plays the first legal move when nothing was searched; that
is the same as the assembler's `.fall` and as v3's `think`.

| Level | Time / nodes / margin | Rough Elo | Basis |
|---|---|---|---|
| 1 | 1 s / 83 / 300 | ~200-400 | L1 against L2: 20.1% (-239) |
| 2 | 1 s / 83 / 150 | ~450-650 | L2 against L3: 14.5% (-309) |
| 3 | 2 s / 167 / 70 | ~750-950 | L3 against L4: 16.3% (-284) |
| 4 | 3 s / 250 / 30 | ~1000-1150 | 24.6% against SF 1320 (1125 [1090, 1155]); 4.2% against L6 (implies ~960) |
| 5 | 5 s / 420 / none | ~1300-1400 | interpolated (not run) |
| 6 | 10 s / 830 / none | ~1500 | 74.0% against SF 1320 (+181 [+149, +217]) |
| 7 | 30 s / 2,500 / none | ~1625 | section 1 |
| 8 | 100 s / 8,300 / none | ~1750 | interpolated between 6,000 and 15,000 nodes |

How these were estimated:
- 1320 is Stockfish's minimum UCI_Elo, so levels 1-3 come from a self-play chain hanging off level 4.
- Self-play inflates the gaps, so the true spread between levels is probably smaller.
- In the margin pass the JS uses no node limit; on the Psion that pass adds time on top of the
  level's time.

**Problem at low levels:** with 83-250 nodes, depth 1 often doesn't finish.

| Level | Moves that never finish depth 1 | Moves where no root move was scored (first legal move played) |
|---|---|---|
| 1-2 | ~35% | ~6-7% |
| 3 | ~16-19% | ~1-2% |
| 4 | ~12-18% | ~1% |

When no root move was scored, the engine plays the first generated legal move. That is a
deterministic, often absurd move rather than a "weak but plausible" one. Before the fallback was
added, the unpatched v2 returned `bestmove 0000` (a forfeit) in 83-90% of games at levels 1-2. Suggestion: always
let depth 1 finish (ignore the time limit until it does), and let the margin alone set the strength.

## Bugs found

1. **a1 sentinel (v1, fixed in ref/ since).** `rootF = 0` meant "no move", but 0 is square a1.
   - A best move from a1 was dropped. The engine played the previous iteration's move, or sent
     `bestmove 0000` if every iteration chose an a1 move.
   - The same test meant a TT best move from a1 was never stored or used.
   - In 84 games against SF 1320, the unpatched engine returned 0000 in 34 games.
   - Example: `r1b2r2/1p3pk1/p4p1p/4p3/1pP1P3/8/1P1N1PPP/R4RK1 w - - 0 18` gave 0000; patched, it
     plays a1a4.
2. **Null move with a stale `mvTop[ply+1]` (v1, fixed in ref/ since).** The null child generated
   its moves on top of an ancestor's move list.
   - This crashed with `TypeError` in `remPiece` from `make()`: 12 crashes in 84 games.
   - Example: `r1bqkb1r/ppp2ppp/2p2n2/8/4P3/8/PPP2PPP/RNBQKB1R w KQkq - 0 6` at 6,000 nodes.
3. **ref/uci.js position overflow (still present, uci.js unchanged).**
   - `setPosition` applies the game moves with `make()`, so `e.ply` grows with game length.
     `parseUci` → `legalMoves` then indexes `mvTop` (size MAXPLY + 2) out of range.
   - With MAXPLY 24, after ~25 moves a legal move is reported as `info string illegal move`. The
     search then runs on the truncated position and returns an illegal move.
   - Verified with the current ref/uci.js: the 60-ply game from `n6k_sf1700` reports
     "illegal move d1h5".
   - Fix: set `e.ply = 0` after each `e.make()` in `setPosition`, as `tools/match/uci_wrap.js` does.
4. With v2 and v3 through the wrapper, **there were no illegal moves and no crashes** in more than
   10,000 games.

## Reproducing

```
cd tools/match
python make_snap.py v2                                    # snapshot ref/ (or v3, ...)
python match.py NAME ref:Nodes=2500 sf:1600:50 --openings 0:242 --workers 6
python match.py NAME ref:Nodes=2500 ref:Nodes=2500,LMR=false --openings 0:242
python analyze.py NAME [NAME ...]                         # W/D/L, Elo, CI, depth, errors (FEN)
python analyze.py --fit NAME1 NAME2 ...                   # combined Elo against several SF levels
python timing.py n2500_sf1600 400 2500,6000,15000         # depth / PC time per move
```

`ref` in a match spec means `snap_v2`. Other specs are `v1` (`snap_fixed`), `asis` (`snap_asis`),
`snap_<x>` and `orig` (the live `ref/uci.js`). `make_snap.py v3` writes `snap_v3`; point `ref` at the
newest snapshot in `match.py` to re-measure.


## Addendum (engine author, 01:55): after this report

Applied to `ref/` and the 6303 engine together (parity tests pass):
- the move-stack cap is now 360, with lists cut short at 400;
- PVS and LMR are off;
- depth 1 always finishes;
- the `ref/uci.js` ply bug is fixed.

`tools/match/uci_wrap.js` now advertises the engine's real option defaults. Before, python-chess
skipped any option equal to the advertised default, which only matters once an engine's own
defaults are off. Measured with the snapshot `snap_v3` at 2,500 nodes:

| Match | Result |
|---|---|
| v3 v SF 1500 / 1600 / 1700 | 67.7% / 53.2% / 49.1%, **fit 1649 ± 17** (1,452 games) |
| v3 v snap_v2 (the version above) | −14 [−36, +8] |
| v3 with LMR + PVS on, v off | −10 [−36, +16] |
| v3 with PVS on, v off | −17 [−43, +10] |

The level figures above were measured before depth 1 always finished. Levels 1-2 no longer play
an unsearched first legal move, so they should now be somewhat stronger than listed.

## 8. All levels after the audit (16 Nov, engine `snap_v4`)

The audit (`docs/audit-engine.md`) changed the engine: levels 1-4 no longer allow mate in one,
their random pick has a budget, and the quiescence search skips losing captures (about 18% fewer
positions a second). So every level was measured again with a snapshot of the audited reference
(`tools/match/snap_v4`). Seconds are converted to positions at about 70 a second (83 before the
audit, less 18%). Each match is 484 games: 242 openings played with both colours. Script:
`tools/match/run_levels_v4.sh`.

| Level | Time / positions / margin | Match | Result | Elo |
|---|---|---|---|---|
| 1 | 1 s / 70 / 300 | v level 2 | 25.0%, −191 [−218, −166] | ~440 (chain) |
| 2 | 1 s / 70 / 150 | v level 3 | 16.0%, −288 [−322, −258] | ~630 (chain) |
| 3 | 2 s / 140 / 70 | v level 4 | 17.3%, −272 [−309, −240] | ~920 (chain) |
| 4 | 3 s / 210 / 30 | v SF 1320 | 32.2%, −129 [−158, −102] | **~1190** [1160, 1220] |
| 5 | 5 s / 350 | v SF 1320 | 71.1%, +156 [+128, +187] | **~1475** [1450, 1505] |
| 6 | 10 s / 700 | v SF 1320, 1500 | 78.5%, 53.1% | **1531 ± 22** (fit) |
| 7 | 30 s / 2,120 | v SF 1600 | 56.6%, +46 [+19, +74] | **~1646** |
| 7 | (equal time) | v the pre-audit engine at 2,500 | 49.6%, −3 [−30, +24] | no change |
| 8 | 100 s / 7,000 | v SF 1700, 1800 | 67.0%, 61.3% | **1853 ± 20** (fit) |

- Levels 1-3 hang off level 4 through a self-play chain, because 1320 is Stockfish's lowest
  UCI_Elo. Self-play exaggerates gaps between versions of one engine, so the real spread of
  levels 1-4 is probably smaller and levels 1-3 are probably somewhat stronger than listed.
- The level menu (`src/screens/ov_set.asm`) now shows these figures rounded to 50: 450, 650, 900,
  1200, 1500, 1550, 1650, 1850.
- Levels 1-4's random pick may now take up to 8 times the level's time (typically 1.2× at level 4;
  the worst seen in the audit was 26.9 s at level 4). The Elo above includes that.
- Level 5 and level 6 are only ~55 apart: level 6 doubles the positions but mostly reaches depth 2
  either way (depth histograms in the logs: level 5 32% depth 1, 64% depth 2; level 6 8% / 78%).

## 9. RAM savings measured (16 Nov): Zobrist keys and symmetric tables

Both measured against `snap_v4` (the audited engine), 484 games a match, in JS; speed from the
assembler's cycle profile (`tests/engine/t_prof.js`, 3 positions, 600 nodes).

| Change | Saves | Speed | Match | Elo |
|---|---|---|---|---|
| Zobrist from 64 square keys, rotated by type (used) | 944 bytes | +0.8%, +1.5%, +2.3% cycles | equal nodes 2,120 | −6 [−24, +11] |
| | | | equal nodes 6,000 | −4 [−26, +18] |
| | | | equal time (2,090 v 2,120) | −14 [−31, +3] |
| Symmetric piece-square tables (not used) | ~310 bytes | ~0.8% | equal nodes 2,120 | −24 [−54, +6] |
| | | | equal nodes 2,000 | −39 [−69, −10] |

Key quality (`tools/zobtest.js`): same-key pairs within 3-ply search trees, three samples, total
4,297 ideal for random keys; the old keys 4,104; rotations of 0-5 bits 3,939 (used); rotations of
±1, ±2, +3 bits (cheaper on the 6303) 4,657, about 8% above ideal, so not used.

## 10. Transposition-table size (16 Nov, an idea for saving RAM; nothing changed)

Self-play against the same engine with 512 entries (`snap_z64c`), 484 games each:

| Entries (RAM saved) | Level 7 (2,120 nodes) | Level 8 (7,000 nodes) |
|---|---|---|
| 256 (1,792 bytes) | −15 [−31, 0] | −11 [−32, +10] |
| 128 (2,688 bytes) | −17 [−39, +4] | +6 [−17, +30] |

In normal play the table is worth little at these node counts (the earlier measurement, section 5,
gave 256 entries −22 and 1,024 entries +20). But the king-and-pawn ending depends on it: the slices
of the exact table are lent from the TT's RAM, all four with 512 entries, only the pawn's square
with 256, none with 128. `tools/kpk/play_kpk.js` plays king and pawn v king out with the engine on
both sides at 2,120 nodes and judges each start by the table:

| Entries | Random starts (600): wins missed / draws lost | Critical starts (400, a wrong move changes the result): wins missed / draws lost |
|---|---|---|
| 512 | 0.5% / 1.0% | 2.6% / 0% |
| 256 | 2.9% / 5.2% | 10.8% / 3.4% |
| 128 | 3.9% / 15.1% | 12.4% / 16.5% |

So 128 entries would make the ending exploitable (a player can trade into it and win a drawn one
one time in six), and 256 is clearly weaker there than 512. Even 512 misses some wins: the exact
scores stop two pawn moves ahead, and among equal "win" scores the engine can shuffle into a
repetition. (The critical-start variant is a filter on the same script: keep a start only if some
legal move changes the table's result.)

## 11. All levels as the Psion now plays (16 Nov, evening)

What changed since section 8: the 64-key Zobrist (section 9), the king-and-pawn distance table at
the root, and the position book, which levels 1-4 use for the computer's first n moves only (n =
the level) and levels 5-8 throughout. To measure the book too, the games start from the normal
starting position (`match.py --start 242 --openings 0:242`: 484 games a match, 242 with each
colour; every game differed within its first 12 plies), and the reference engine plays with the
same book, rule and table (`uci_wrap.js` options `Book`, `BookMoves`, `KPK`; snapshot
`snap_z64c`). Nodes = the level's seconds x ~69 a second. Script: `tools/match/run_levels_v5.sh`.

| Level | Match (484 games each) | Result | Elo | Section 8 |
|---|---|---|---|---|
| 1 | v level 2 | 25.2%, -189 [-213, -166] | ~447 (chain) | ~440 |
| 2 | v level 3 | 15.6%, -293 [-329, -262] | ~636 (chain) | ~630 |
| 3 | v level 4 | 17.3%, -272 [-308, -241] | ~929 (chain) | ~920 |
| 4 | v SF 1320 | 33.5%, -119 [-151, -90] | **1201** [1169, 1230] | ~1190 |
| 5 | v SF 1320 | 76.2%, +203 [+170, +238] | **1523 +- 34** | ~1475 |
| 6 | v SF 1320, 1500 | 81.9%, 56.5% | **1560 +- 22** | 1531 |
| 7 | v SF 1500, 1600, 1700 | 73.0%, 56.0%, 52.2% | **1677 +- 17** | ~1646 |
| 8 | v SF 1700, 1800 | 62.9%, 55.1% | **1814 +- 20** | 1853 |

The level menu now shows 450, 650, 950, 1200, 1500, 1550, 1700, 1800.

The two methods differ (balanced openings without a book before; the start position with the book
now), so the change per level mixes the book's effect with the method's: the middle levels gained
about 30-50, level 8 measured about 40 lower. Levels 1-3 still hang off level 4 through self-play,
which exaggerates gaps between versions of one engine.

## 12. Level 5 at 3 s and level 8 at 255 s (16 Nov)

To even the steps, level 5 now thinks 3 s (was 5) and level 8 255 s (was 100; `lv_secs` in
`src/kernel/kcore.asm`; 255 is the most a byte holds). Measured as section 11 (the start position,
the book, 484 games a match; `tools/match/run_levels_v6.sh`):

| Level | Match | Result | Elo |
|---|---|---|---|
| 5 (3 s, 207 nodes) | v SF 1320 | 67.8%, +129 [+100, +160] | **1449 +- 31** |
| 5 | v level 4 (also 3 s, with its random margin) | 88.8%, +360 [+319, +412] | (order holds) |
| 8 (255 s, 17,600 nodes) | v SF 1800, 1900, 2000 | 61.7%, 60.8%, 50.2% | **1956** [1938, 1974] (fitted by maximum likelihood; analyze.py's fit did not converge) |

At 255 s level 8 typically reaches depth 4 (3.4 at 100 s). Its search may end well before 255 s
(it starts no new depth after half the time): 183 s in t_sleep's test position.

The levels and the menu now: 450, 650, 950, 1200, **1450**, 1550, 1700, **1950** (levels 1-3 from
the self-play chain of section 11).

## 13. RAM savings (17 Nov): what each cost in strength

Four changes made one at a time (sizes from rebuilding each stage: `docs/engine.md`, *Memory
savings*). Self-play matches over `tools/match/openings_big.txt` (the 242 openings plus 1,000 more
generated the same way by `openings_big.py`): 1,242 openings with both colours, 2,484 games a
match, at each level's nodes at 73.8 nodes a second (the speed after the 17 Nov speed-ups).

**A. Null move removed.** With plain alpha-beta (PVS off since 16 Nov) every node has an open
window, and the null move is only tried with a zero window: in 105,000 nodes at level 7 and level
8 node counts it was tried **0 times**, and every move was the same. So it had been dead code since
16 Nov. Matches (null move off v on): level 5 (221 nodes) +959 =566 -959, level 7 (2,214 nodes)
+985 =514 -985: exactly level, as identical play must be. **0 Elo** (the level 8 match was stopped).

**D. Levels 1-4: evaluation noise instead of the margin pass.** The pass (after deepening, every
root move searched again and a random one played within a margin of the best) is replaced by noise
in the evaluation: ((h - 128) * k) / 16 centipawns, h = the key's low byte xor a seed drawn for
each search, so a position keeps its noise through one search (the table stays consistent) and
games vary. k was calibrated against the old levels (484-game sweeps with evenly spread masks
63 to 2047, then interpolated) and set to 100, 53, 25, 14 (noise within +-800, +-424, +-200,
+-112 cp). Each new level against the old one at the same nodes:

| Level | Nodes | Old (margin) | New (k) | Result | Elo, new v old |
|---|---|---|---|---|---|
| 1 | 74 | 300 cp | 100 | +840 =813 -831, 50.2% | +1 [-10, +13] |
| 2 | 74 | 150 cp | 53 | +885 =760 -839, 50.9% | +6 [-5, +18] |
| 3 | 148 | 70 cp | 25 | +957 =670 -857, 52.0% | +14 [+2, +26] |
| 4 | 221 | 30 cp | 14 | +996 =578 -910, 51.7% | +12 [+0, +24] |

So levels 1-4 keep their strength (about 450, 650, 950, 1200; the menu's figures are rounded to 50
and stay). They now answer within their time: the pass had a budget of 8 times the level's on top.

**The resignation test** now allows for the noise (below -900 - 8k three moves in a row; 17 Nov
review): at level 1 the noisy score fell below -9 pawns in 0.65% of looks at positions not lost;
with the allowance never, at any level (docs/engine.md, *Review*).

**E (castling generator) and C (the shared screen/engine slot)** don't change a single move (the
engine's parity tests match move, score, depth and node count): **0 Elo**. Levels 5-8 play exactly
as before: **0 Elo**.

## 14. Table cut-offs at every node (17 Nov)

The coverage sweep found the table's score cut-off never ran in a game: it was allowed only with
a zero window (`!pv`, a test made for PVS), and with plain alpha-beta (PVS off since 16 Nov) a
window is hardly ever that narrow. Counted in the JS over 60 opening positions and 6 moves each:
at level 7's nodes 22,463 entries were deep enough for a cut-off and 77 were taken; at level 8's,
116,475 and 772.

Allowed at every node but the root (`snap_ttall` v `snap_m17e`, self-play over
`openings_big.txt`, 2,484 games each): +3 [-1, +7], +10 [+2, +17], +9 [+1, +16] at levels 5, 7,
8. But the mates with bishop and knight (`tools/audit/endgames.js mates`, 800 random starts, 2,500
nodes a move) came off: 636 -> 584 mated, and 4 stalemates (about 3 standard errors). Variants:

| Variant | KBNK mated (of 800) | Stalemates | Level 7 |
|---|---|---|---|
| Before (zero window only) | 636 | 0 | |
| At every node | 584 | 4 | +10 [+2, +17] |
| ... not on a stored score of 0 | 583 | 4 | +10 [+2, +17] |
| ... not past half-move 80 (the fifty-move limit) | 597 | 0 | +10 [+2, +17] |
| ... not while a side has a bare king (`snap_ttk`) | 636 | 0 | +9 [+1, +16] |

The last is what both engines now do (the flag is worked out once a search). Measured again with
the final engine (`snap_m17f` v `snap_m17e`, 2,484 games each): KBNK 641/800 mated, no stalemates;
KQK, KRK, KBBK 200/200 each; 0 avoidable stalemating moves in the stalemate test's winning endings.

| Level | Nodes | Result | Elo |
|---|---|---|---|
| 5 | 221 | +977 =547 -960, 50.3% | +2 [-1, +6] |
| 7 | 2,214 | +1026 =493 -965, 51.2% | +9 [+1, +16] |
| 8 | 18,800 | +944 =652 -888, 51.1% | +8 [+0, +15] |

It costs 19 bytes (17 saved by the simpler probe, 36 for the bare-king test). The menu's figures
(rounded to 50) stay.

## 15. Fail-low time extension and root ordering (18 Nov)

Prompted by a level-5 game on the Organiser (`pgn/Pgn1.odb`): after 25.Qc7 the engine played
25...Rd2?? and was mated in two (26.Qc8+ Rd8 27.Qxd8#). In that position (two queens, open board)
it searches only 45-52 positions a second, so level 5's 3 s is about 130 positions: depth 1
finishes at 61 positions and chooses Rd2 (+96: the capture search does not see Qc8+); depth 2
searches Rd2 first and finds it losing (-446), but reaches the saving move Rf8 (+42) only at 164
positions. Both engines play it node for node.

Two changes were made in both engines, each behind a switch (`opts.failLow`/`E_FAILLOW`,
`opts.rootOrder`/`E_ROOTORD`):

- **Fail-low extension.** From depth 2, when the first root move (the last depth's best) scores
  100 or more below the last depth's score (neither a mate), the search may run past its limit,
  to twice the node limit (in the game: the time limit plus `e_tadd`, which the kernel sets to the
  level's time, at most an eighth of the side to move's clock), until a root move scores within
  the 100 again or that depth ends. At most once a search, so a move can be extended once and
  never past twice its budget; not while a side has a bare king (see KBNK below).
- **Root ordering.** The root's moves are generated once a search and kept; the move that becomes
  the best gets 255, the one before it 254, earlier ones 253, so each depth starts with the last
  depth's best and then the moves that were best during it.

**Matches** (self-play over `openings_big.txt`, each configuration against the same snapshot
`snap_fl17` with both off; 2,484 games, 800 at level 8):

| Configuration | Level 5 (221 positions) | Level 7 (2,214) | Level 8 (18,800) |
|---|---|---|---|
| Fail-low | **+36 [+28, +43]** | **+12 [+7, +17]** | **+11 [+5, +17]** |
| Root ordering | +2 [-6, +10] | +6 [-3, +15] | |
| Both | +39 [+30, +49] | +17 [+8, +27] | +23 [+7, +39] |
| Both v fail-low | +6 [-1, +14] | +4 [-5, +13] | |

**Time** (positions a move, as the Psion's time at 73.8 positions a second): the averages rise
by 1% at level 5 (218 against 216), 0.5% at level 7 (2,151 against 2,141) and 0.2% at level 8
(18,147 against 18,104); the 95th percentiles are unchanged (221, 2,214, 18,800: 3 s, 30 s,
255 s). The extension runs past the limit in 1.8% of moves at level 5 (2.22% against the 0.43%
by which depth 1 overruns anyway), 0.87% at level 7 and 0.37% at level 8, by 1.5 times on average
when it does; the longest moves are exactly twice the limit. The completed depth is unchanged
(averages 1.44, 2.91, 4.21).

**KBNK** (`tools/audit/endgames.js mates`, 2,500 positions a move): baseline 641/800, fail-low
627/800, both **547/800** with 5 stalemates (each at half-move 98, where every non-mating move
draws by the fifty-move rule). On 1,600 more starts (`EG_SEED=777`): baseline 1283/1600,
fail-low 1256/1600: together 80.2% against 78.5% of 2,400, about 1.5 standard errors but the same
way in both samples. So fail-low is now off while a side has a bare king, as the table's
cut-offs are (s.14): KBNK is then exactly the baseline's (641/800), and the matches with it
(`snap_fl17_flb`, the final engine) are unchanged: **+36 [+28, +43]** at level 5 and
**+12 [+7, +17]** at level 7, with the same times.

**Taken: the fail-low extension only.** Root ordering's middlegame gain is small (pooled over the
four matches about +4.5 [+0.4, +8.7]) and it costs a measurable regression in the bishop-and-knight
mates (627 -> 547 of 800): with the last best always first, ties among the many equal moves of a
mop-up ending keep going the same way, and the fifty-move rule comes first. It stays in both
engines, switched off. The 25...Rd2 position: fail-low plays Rf8 from a budget of about 100
positions (3.93 s at level 5 on the emulated Organiser, `tests/ui/t_faillow.js`); root ordering
alone does not change it. Cost: 201 bytes of code (173 in the engine, 28 in the kernel's
`think`) and 2 of variables (`e_tadd`); the engine's scratch grew by 9 (within slot A).

