'use strict';
// King and pawn v king, played from the distance table (data/kpkd.bin, tools/kpk/kpkd.js) at the
// root, without a search. The Psion does the same in its OV_KPK overlay
// (src/screens/ov_kpk.asm), move for move: same candidate order, same ties (the first best).
//
// kpkRoot(e, tab) -> [from, to] (0x88 squares; to carries promotion bits) or null when the
// position isn't K+P v K, or the pawn's side is to move in a draw (the search then plays).
//   The pawn's side to move: of its moves that keep the win, the one whose position needs the
//     fewest moves to promote (looking at each of the defender's replies, which it takes the
//     worst of); a promotion when the table says 1.
//   The defender to move: the first move that keeps the draw, else the one that loses slowest.
const KDIR = [1, -1, 16, -16, 17, 15, -15, -17];   // king steps, in this order (0x88)
const P = 1, K = 6;

const s64 = (s) => (s >> 4) * 8 + (s & 7);
const dist = (a, b) => Math.max(Math.abs((a & 7) - (b & 7)), Math.abs((a >> 4) - (b >> 4)));

// The compressed table (data/kpkdz.bin, tools/kpk/kpkd_pack.js): entry (p * 64 + wk) * 64 + sk,
// blocks of 1024 entries, each a run list in one canonical Huffman code. The Psion decodes a
// block the same way into a buffer and keeps the last one (as this cache does).
const lookZ = {
  cache: { blob: null, b: -1, out: null },
  block(blob, b) {
    const c = lookZ.cache;
    if (c.blob === blob && c.b === b) return c.out;
    const cnt = blob.slice(194, 210), out = new Uint8Array(1024);
    let at = blob.readUInt16BE(2 * b) * 8;                       // the bit position
    const bit = () => { const v = (blob[at >> 3] >> (7 - (at & 7))) & 1; at++; return v; };
    for (let pos = 0; pos < 1024;) {
      let code = 0, first = 0, index = 0, sym = -1;
      for (let l = 1; l <= 16; l++) {
        code |= bit();
        const n = cnt[l - 1];
        if (code - first < n) { sym = blob[210 + index + code - first]; break; }
        index += n; first = (first + n) << 1; code <<= 1;
      }
      const v = sym >> 4, k = sym & 15;
      let n = 1;
      if (k) { n = 1 << k; let x = 0; for (let i = 0; i < k; i++) x = (x << 1) | bit(); n += x; }
      out.fill(v, pos, pos + n); pos += n;
    }
    c.blob = blob; c.b = b; c.out = out;
    return out;
  },
  entry(blob, p6, sk, wk) { const e = (p6 * 64 + wk) * 64 + sk; return lookZ.block(blob, e >> 10)[e & 1023]; },
};

// the table: sk = the pawn side's king, wk = the other king, p = the pawn (0x88), pc = its colour
// (0 White, 8 Black), with the pawn's side to move: moves to promote, 0 = draw. tab is kpkd.bin
// (49,152 bytes) or the compressed kpkdz.bin.
function look(tab, sk, wk, p, pc) {
  let a = s64(sk), b = s64(wk), q = s64(p);
  if (pc) { a ^= 56; b ^= 56; q ^= 56; }
  if ((q & 7) >= 4) { a ^= 7; b ^= 7; q ^= 7; }
  const r = q >> 3, f = q & 7;
  let v;
  if (tab.length !== 49152) v = lookZ.entry(tab, (r - 1) * 4 + f, a, b);
  else { const i = (((r - 1) * 4 + f) * 64 + a) * 64 + b; v = tab[i >> 1]; v = (i & 1) ? v >> 4 : v & 15; }
  const minPushes = r === 1 ? 5 : 7 - r;
  if (v > 0 && v < minPushes) v += 15;               // a distance over 15, stored as d - 15
  return v;
}
// the defender to move (pawn's side's king sk, pawn p): the worst of its replies for the pawn's
// side, 0 if any reply draws (taking the pawn, or a drawn position) or it is stalemated
function defend(tab, sk, wk, p, pc) {
  const fwd = pc ? -16 : 16;
  let worst = 0, any = false;
  for (const d of KDIR) {
    const u = wk + d;
    if (u & 0x88) continue;
    if (dist(u, sk) < 2) continue;
    if (u === p + fwd + 1 || u === p + fwd - 1) continue;   // the pawn guards it
    if (u === p) return 0;                                    // takes the pawn
    any = true;
    const v = look(tab, sk, u, p, pc);
    if (v === 0) return 0;
    if (v > worst) worst = v;
  }
  return any ? worst : 0;                                     // no move: stalemate
}
// a promotion on q: a queen, or a rook when the queen would stalemate (as the table assumes)
function promoPiece(sk, wk, q) {
  const attacked = (s, rook) => {
    if (dist(s, sk) < 2) return true;
    for (const d of rook ? [1, -1, 16, -16] : KDIR) {
      for (let x = q + d; !(x & 0x88); x += d) { if (x === s) return true; if (x === sk) break; }
    }
    return false;
  };
  for (const rook of [false, true]) {
    let moves = 0;
    for (const d of KDIR) {
      const t = wk + d;
      if ((t & 0x88) || t === sk) continue;
      if (dist(t, sk) < 2) continue;
      if (t !== q && attacked(t, rook)) continue;
      moves++;
    }
    if (moves || attacked(wk, rook)) return rook ? 0x08 : 0;
  }
  return 0;
}

function kpkRoot(e, tab) {
  const c = e.cnt;
  for (let t = 2; t <= 5; t++) if (c[t] || c[8 + t]) return null;
  if (c[P] + c[8 + P] !== 1) return null;
  let p = -1;
  for (let s = 0; s < 128; s++) { if (s & 0x88) { s += 7; continue; } if ((e.b[s] & 7) === P) { p = s; break; } }
  const pc = e.b[p] & 8;
  const sk = e.ksq[pc >> 3], wk = e.ksq[(pc >> 3) ^ 1];
  const fwd = pc ? -16 : 16;
  if (e.side === pc) {                                        // the pawn's side
    const v0 = look(tab, sk, wk, p, pc);
    if (v0 === 0) return null;
    if (v0 === 1) { const q = p + fwd; return [p, q | promoPiece(sk, wk, q)]; }
    let best = 99, mv = null;
    const consider = (f, t, nsk, np) => {
      const v = defend(tab, nsk, wk, np, pc);
      if (v > 0 && v < best) { best = v; mv = [f, t]; }
    };
    for (const d of KDIR) {
      const t = sk + d;
      if ((t & 0x88) || t === p || dist(t, wk) < 2) continue;
      consider(sk, t, t, p);
    }
    const one = p + fwd;
    const last = pc ? 0 : 7;
    if (one !== sk && one !== wk && (one >> 4) !== last) {
      consider(p, one, sk, one);
      const two = one + fwd;
      if ((p >> 4) === (pc ? 6 : 1) && two !== sk && two !== wk) consider(p, two, sk, two);
    }
    return mv;
  }
  let best = -1, mv = null;                                   // the defender
  for (const d of KDIR) {
    const u = wk + d;
    if (u & 0x88) continue;
    if (dist(u, sk) < 2) continue;
    if (u === p + fwd + 1 || u === p + fwd - 1) continue;
    const v = u === p ? 0 : look(tab, sk, u, p, pc);
    if (v === 0) return [wk, u];
    if (v > best) { best = v; mv = [wk, u]; }
  }
  return mv;
}

module.exports = { kpkRoot, look, defend, KDIR, lookZ };
