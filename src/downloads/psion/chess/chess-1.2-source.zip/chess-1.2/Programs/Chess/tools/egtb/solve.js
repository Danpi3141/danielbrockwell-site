// Retrograde solver for small endgames (DTM in plies, hence also WDL).
//   node solve.js KEY [verify]       e.g.  node solve.js KRvKP verify
// Needs every table reachable by a capture or promotion to be solved first
// (see run_all.sh for the order).  Writes <EGTB_DIR>/KEY.bin (raw layout, lib.js).
// No symmetry is used while solving (2*64^N entries); symmetry is applied later
// when the tables are re-indexed for compression (index.js), and is checked there.
// En passant is ignored (a double pawn push never allows an e.p. capture).
'use strict';
const fs = require('fs');
const L = require('./lib');
const { K, Q, R, B, N, P, KING_N, KNIGHT_N, KADJ, NADJ, RAYS, LINE, STEP, RK, F } = L;

function makeCtx(key) {
  const pcs = L.parseKey(key);
  const n = pcs.length;
  const C = pcs.map(p => p[0]), T = pcs.map(p => p[1]);
  const mult = []; for (let k = 0; k < n; k++) mult.push(64 ** (n - 1 - k));
  const S = 64 ** n;
  return { key, pcs, n, C, T, mult, S, size: 2 * S,
    sqs: new Int32Array(n), occ: new Int8Array(64).fill(-1), alive: new Uint8Array(n).fill(1) };
}

function decode(ctx, i) {
  const { n, sqs, occ } = ctx;
  for (let k = n - 1; k >= 0; k--) { sqs[k] = i & 63; i >>= 6; }
  return i;  // stm
}

// is square sq attacked by colour col (current sqs/occ/alive)
function attacked(ctx, sq, col) {
  const { n, C, T, sqs, occ, alive } = ctx;
  for (let k = 0; k < n; k++) {
    if (C[k] !== col || !alive[k]) continue;
    const s = sqs[k], t = T[k];
    if (t === K) { if (KADJ[s * 64 + sq]) return true; continue; }
    if (t === N) { if (NADJ[s * 64 + sq]) return true; continue; }
    if (t === P) {
      if (col === 0) { if (RK(sq) === RK(s) + 1 && Math.abs(F(sq) - F(s)) === 1) return true; }
      else { if (RK(sq) === RK(s) - 1 && Math.abs(F(sq) - F(s)) === 1) return true; }
      continue;
    }
    const ln = LINE[s * 64 + sq];
    if (!ln) continue;
    if (t === R && ln !== 1) continue;
    if (t === B && ln !== 2) continue;
    const st = STEP[s * 64 + sq];
    let x = s + st, ok = true;
    while (x !== sq) { if (occ[x] >= 0) { ok = false; break; } x += st; }
    if (ok) return true;
  }
  return false;
}

// legality of the decoded position with side stm to move
function legalPos(ctx, stm) {
  const { n, T, sqs, occ } = ctx;
  occ.fill(-1);
  for (let k = 0; k < n; k++) {
    const s = sqs[k];
    if (occ[s] >= 0) return false;
    occ[s] = k;
    if (T[k] === P && (s < 8 || s >= 56)) return false;
  }
  if (KADJ[sqs[0] * 64 + sqs[1]]) return false;
  return !attacked(ctx, sqs[1 - stm], stm);   // side not to move must not be in check
}

// Generate legal moves for stm. cb(kind, a, b): kind 0 = in-table move, a = successor index;
// kind 1 = exit, a = successor value byte from the opponent's view.
function genMoves(ctx, i, stm, cb) {
  const { n, C, T, sqs, occ, alive, mult, S } = ctx;
  const base = i + (stm ? -S : S);   // same squares, other side to move
  let count = 0;
  const tryMove = (k, from, to, promo) => {
    const cap = occ[to];
    if (cap >= 0 && C[cap] === stm) return;
    if (cap >= 0 && T[cap] === K) return;
    occ[from] = -1; occ[to] = k; sqs[k] = to; if (cap >= 0) alive[cap] = 0;
    const ok = !attacked(ctx, sqs[stm], 1 - stm);
    if (ok) {
      if (cap < 0 && !promo) { count++; cb(0, base + (to - from) * mult[k]); }
      else {
        const types = promo ? [Q, R, B, N] : [T[k]];
        for (const pt of types) {
          const list = [];
          for (let j = 0; j < n; j++) if (alive[j]) list.push([C[j], j === k ? pt : T[j], sqs[j]]);
          count++; cb(1, L.probe(list, 1 - stm), list.length);  // 3rd arg: pieces left
        }
      }
    }
    sqs[k] = from; occ[from] = k; occ[to] = cap; if (cap >= 0) alive[cap] = 1;
  };
  for (let k = 0; k < n; k++) {
    if (C[k] !== stm) continue;
    const s = sqs[k], t = T[k];
    if (t === K) { for (const to of KING_N[s]) tryMove(k, s, to, false); }
    else if (t === N) { for (const to of KNIGHT_N[s]) tryMove(k, s, to, false); }
    else if (t === P) {
      const d = stm ? -8 : 8, r = RK(s);
      const lastR = stm ? 1 : 6, startR = stm ? 6 : 1;
      const one = s + d;
      if (occ[one] < 0) {
        tryMove(k, s, one, r === lastR);
        if (r === startR && occ[one + d] < 0) tryMove(k, s, one + d, false);
      }
      for (const df of [-1, 1]) {
        const f = F(s) + df; if (f < 0 || f > 7) continue;
        const to = one + df;
        if (occ[to] >= 0 && C[occ[to]] !== stm) tryMove(k, s, to, r === lastR);
      }
    } else {
      const d0 = t === B ? 4 : 0, d1 = t === R ? 4 : 8;
      for (let d = d0; d < d1; d++) for (const to of RAYS[s][d]) {
        tryMove(k, s, to, false);
        if (occ[to] >= 0) break;
      }
    }
  }
  return count;
}

// predecessors (non-capture, non-promotion un-moves of the side that just moved)
function genPreds(ctx, i, stm, cb) {
  const { n, C, T, sqs, occ, mult, S } = ctx;
  const m = 1 - stm;
  const base = i + (stm ? -S : S);
  for (let k = 0; k < n; k++) {
    if (C[k] !== m) continue;
    const s = sqs[k], t = T[k];
    if (t === K || t === N) {
      for (const fr of (t === K ? KING_N[s] : KNIGHT_N[s])) if (occ[fr] < 0) cb(base + (fr - s) * mult[k]);
    } else if (t === P) {
      const d = m ? 8 : -8, r = RK(s);
      if (m === 0 ? r >= 2 : r <= 5) {
        const one = s + d;
        if (occ[one] < 0) {
          cb(base + d * mult[k]);
          if ((m === 0 ? r === 3 : r === 4) && occ[one + d] < 0) cb(base + 2 * d * mult[k]);
        }
      }
    } else {
      const d0 = t === B ? 4 : 0, d1 = t === R ? 4 : 8;
      for (let d = d0; d < d1; d++) for (const fr of RAYS[s][d]) {
        if (occ[fr] >= 0) break;
        cb(base + (fr - s) * mult[k]);
      }
    }
  }
}

function setOcc(ctx) {
  const { n, sqs, occ } = ctx;
  occ.fill(-1);
  for (let k = 0; k < n; k++) occ[sqs[k]] = k;
}

function solve(key) {
  const ctx = makeCtx(key);
  const { size } = ctx;
  const val = new Uint8Array(size), cnt = new Uint8Array(size), floor = new Uint8Array(size);
  const noLose = new Uint8Array(size);
  let maxPly = 0;
  const t0 = Date.now();
  for (let i = 0; i < size; i++) {
    const stm = decode(ctx, i);
    if (!legalPos(ctx, stm)) { val[i] = 255; continue; }
    let c = 0, best = -100000, any = 0;
    genMoves(ctx, i, stm, (kind, a) => {
      any++;
      if (kind === 0) c++;
      else { const s = L.backScore(a); if (s > best) best = s; }
    });
    cnt[i] = c;
    if (!any) {
      if (attacked(ctx, ctx.sqs[stm], 1 - stm)) val[i] = 1;  // mated; else stalemate (0)
      continue;
    }
    if (best >= 0) noLose[i] = 1;
    if (best > 0) { const p = 1000 - best; val[i] = p + 1; if (p > maxPly) maxPly = p; }
    else if (best < 0 && best > -100000) {
      const p = best + 1000;
      if (c === 0) { val[i] = p + 1; if (p > maxPly) maxPly = p; }
      else floor[i] = p;
    }
  }
  const tInit = Date.now();
  let processed = 0;
  for (let lev = 0; lev <= maxPly; lev++) {
    const target = lev + 1;
    const win = lev & 1;
    for (let i = 0; i < size; i++) {
      if (val[i] !== target) continue;
      processed++;
      const stm = decode(ctx, i); setOcc(ctx);
      if (win) {
        genPreds(ctx, i, stm, j => {
          if (val[j] !== 0) return;
          if (--cnt[j] === 0 && !noLose[j]) {
            const p = Math.max(lev + 1, floor[j]);
            val[j] = p + 1; if (p > maxPly) maxPly = p;
          }
        });
      } else {
        genPreds(ctx, i, stm, j => {
          const v = val[j];
          if (v === 255) return;
          if (v === 0 || (((v - 1) & 1) && v - 1 > lev + 1)) {
            val[j] = lev + 2; if (lev + 1 > maxPly) maxPly = lev + 1;
          }
        });
      }
    }
    if (maxPly > 250) throw new Error('ply overflow');
  }
  const tEnd = Date.now();
  console.log(`${key}: init ${(tInit - t0) / 1000}s, retro ${(tEnd - tInit) / 1000}s, max ply ${maxPly}, decided ${processed}`);
  return { ctx, val };
}

function verify(ctx, val) {
  let bad = 0, checked = 0;
  for (let i = 0; i < ctx.size; i++) {
    if (val[i] === 255) continue;
    const stm = decode(ctx, i); setOcc(ctx);
    let best = -100000, any = 0;
    genMoves(ctx, i, stm, (kind, a) => {
      any++;
      const s = kind === 0 ? L.backScore(val[a]) : L.backScore(a);
      if (kind === 0 && val[a] === 255) throw new Error('move to illegal position');
      if (s > best) best = s;
    });
    let expect;
    if (!any) expect = attacked(ctx, ctx.sqs[stm], 1 - stm) ? 1 : 0;
    else expect = L.valOfScore(best);
    checked++;
    if (expect !== val[i]) { if (bad < 5) console.log('verify mismatch', i, val[i], expect); bad++; }
  }
  console.log(`${ctx.key}: verify ${checked} legal positions, ${bad} mismatches`);
  return bad;
}

function stats(ctx, val) {
  const out = {};
  for (let stm = 0; stm < 2; stm++) {
    let legal = 0, w = 0, d = 0, l = 0, maxW = 0, maxL = 0;
    const off = stm * ctx.S;
    for (let i = off; i < off + ctx.S; i++) {
      const v = val[i]; if (v === 255) continue;
      legal++;
      if (v === 0) d++;
      else { const p = v - 1; if (p & 1) { w++; if (p > maxW) maxW = p; } else { l++; if (p > maxL) maxL = p; } }
    }
    out[stm ? 'btm' : 'wtm'] = { legal, win: w, draw: d, loss: l, maxWinMoves: (maxW + 1) / 2, maxLossMoves: maxL / 2 };
  }
  return out;
}

if (require.main === module) {
  const key = process.argv[2];
  const { ctx, val } = solve(key);
  fs.mkdirSync(L.DATA_DIR, { recursive: true });
  fs.writeFileSync(L.tablePath(key), val);
  L.cache.set(key, { key, pcs: ctx.pcs, N: ctx.n, val });
  const st = stats(ctx, val);
  console.log(JSON.stringify(st));
  let bad = 0;
  if (process.argv[3] === 'verify') bad = verify(ctx, val);
  const sf = require('path').join(L.DATA_DIR, 'stats.json');
  let all = {}; try { all = JSON.parse(fs.readFileSync(sf, 'utf8')); } catch (e) {}
  all[key] = Object.assign(st, { verifyMismatches: process.argv[3] === 'verify' ? bad : null });
  fs.writeFileSync(sf, JSON.stringify(all, null, 1), 'utf8');
}
module.exports = { makeCtx, decode, legalPos, genMoves, genPreds, attacked, setOcc, solve, verify, stats };
