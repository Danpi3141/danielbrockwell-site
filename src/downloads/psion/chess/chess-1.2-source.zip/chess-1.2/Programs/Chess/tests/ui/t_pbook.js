'use strict';
// The position book (data/book.bin) as the Psion reads it (kbook.asm), against tools/book/pbook.js:
// games against the computer where the player (this test) answers so the game stays in the book;
// every computer move must be one of the book's moves for its position, and come without a search.
// The computer plays White in some games and Black in others. Then a transposition: a book
// position reached by another move order (set up in two-player mode) still gets a book move.
//   node tests/ui/t_pbook.js [games=6]
const fs = require('fs');
const path = require('path');
const L = require('./lib.js');
const G = require('./glib.js');
const { check } = L;
const { Engine, legalMoves } = require('../../ref/search.js');
const PB = require('../../tools/book/pbook.js');

const BOOK = fs.readFileSync(path.join(L.ROOT, 'data', 'book.bin'));
const N = +(process.argv[2] || 6);
const nm = (q) => 'abcdefgh'[q & 7] + ((q >> 4) + 1);
const uci = (m) => nm(m[0]) + nm(m[1] & 0x77);
let rng = 99;
const rnd = (k) => { rng ^= rng << 13; rng >>>= 0; rng ^= rng >>> 17; rng ^= rng << 5; rng >>>= 0; return rng % k; };
const START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

let compMoves = 0, deepest = 0;
for (let g = 0; g < N; g++) {
  const compWhite = g % 2 === 0;
  const m = G.start();
  if (compWhite) { G.menu(m, ['F']); G.waitInput(m, 20); }       // FLIP: the computer takes White and moves
  const e = new Engine(); e.setFen(START); e.ply = 0;
  const played = [];
  for (let ply = 0; ply < 30; ply++) {
    const compTurn = (e.side === 0) === compWhite;
    if (compTurn) {
      const want = PB.moves(BOOK, e);
      if (!want.length) break;                                     // out of the book: done
      const c0 = m.cycles();
      if (!G.waitPly(m, played.length + 1, 60)) { check(false, 'the computer moved', m); }
      const last = L.peekSym(m, 'g_last', 2);
      const got = [last[0], last[1]];
      check(want.some((w) => w[0] === got[0] && w[1] === got[1]), `game ${g + 1} ply ${ply + 1}: ${uci(got)} is a book move (${want.map(uci).join(' ')})`, m);
      e.make(got[0], got[1]); e.ply = 0; played.push(uci(got)); compMoves++;
    } else {
      // the player: a legal move after which the computer still has a book move (at random)
      const ok = legalMoves(e).filter(([f, t]) => { e.make(f, t); const k = PB.moves(BOOK, e).length > 0; e.unmake(); return k; });
      if (!ok.length) break;
      const mv = ok[rnd(ok.length)];
      G.typeUci(m, uci(mv));
      if (!G.waitInput(m, 30, () => L.peekSym(m, 'g_n')[0] >= played.length + 1)) { check(false, 'the move ' + uci(mv) + ' was taken', m); }   // (the computer may have answered already)
      e.make(mv[0], mv[1]); e.ply = 0; played.push(uci(mv));
    }
  }
  deepest = Math.max(deepest, played.length);
  console.log(`     game ${g + 1} (computer ${compWhite ? 'White' : 'Black'}): ${played.join(' ')}`);
}

// a transposition: find a book position (Black to move) whose White moves can be played in
// another order; reach it that way in two-player mode, then let the computer move
{
  const e = new Engine();
  let found = null;
  for (let tries = 0; tries < 3000 && !found; tries++) {
    e.setFen(START); e.ply = 0;
    const p = [];
    let dead = false;
    for (let ply = 0; ply < 5 && !dead; ply++) {   // Black (the Psion) from the book, White staying in it
      const ms = ply % 2 ? PB.moves(BOOK, e)
        : legalMoves(e).filter(([f, t]) => { e.make(f, t); const k = PB.moves(BOOK, e).length > 0; e.unmake(); return k; });
      if (!ms.length) { dead = true; break; }
      const mv = ms[rnd(ms.length)];
      e.make(mv[0], mv[1]); e.ply = 0; p.push(mv);
    }
    if (dead) continue;
    if (e.side !== 8 || !PB.moves(BOOK, e).length) continue;
    // swap White's 1st and 2nd moves (plies 0 and 2) when that is legal and lands on the same key
    const key = e.key >>> 0;
    const alt = [p[2], p[1], p[0], p[3], p[4]];
    const f = new Engine(); f.setFen(START); f.ply = 0;
    let ok = true;
    for (const mv of alt) { if (!legalMoves(f).some((x) => x[0] === mv[0] && x[1] === mv[1])) { ok = false; break; } f.make(mv[0], mv[1]); f.ply = 0; }
    if (ok && (f.key >>> 0) === key && uci(p[0]) !== uci(p[2])) found = { alt, want: PB.moves(BOOK, e) };
  }
  check(!!found, 'a transposed book position found', null);
  const m = G.start();
  G.twoPlayers(m);
  found.alt.forEach((mv, i) => { G.typeUci(m, uci(mv)); G.waitPly(m, i + 1, 30); });
  G.setting(m, G.SET.TWO, ['RIGHT']);                             // two players off: the computer is Black, to move
  G.waitPly(m, 6, 60);
  const last = L.peekSym(m, 'g_last', 2);
  check(L.peekSym(m, 'g_n')[0] === 6 && found.want.some((w) => w[0] === last[0] && w[1] === last[1]),
    `transposition (${found.alt.map(uci).join(' ')}): the computer plays ${uci(last)}, a book move (${found.want.map(uci).join(' ')})`, m);
}
// the level rule: levels 1-4 use the book for the computer's first n moves (n = the level),
// levels 5-8 for all. The computer plays White; the player stays in the book; each computer move
// is seen to search (eng_think runs) or not.
for (const [level, presses] of [[2, ['LEFT', 'LEFT', 'LEFT', 'LEFT', 'LEFT']], [5, ['LEFT', 'LEFT']]]) {
  const m = G.start();
  G.setting(m, G.SET.LEVEL, presses);
  check(L.peekSym(m, 'st_level')[0] === level, 'level ' + level + ' set', m);
  const thinkAt = L.sym(m, 'eng_think');
  let thinks = 0;
  m.dbg.setTrace((pc) => { if (pc === thinkAt) thinks++; });
  let t0 = thinks;                                                // (searches since the last computer move)
  G.menu(m, ['F']);                                               // the computer takes White
  const e = new Engine(); e.setFen(START); e.ply = 0;
  const searched = [];
  for (let mv = 1; mv <= 5; mv++) {
    const inBook = PB.moves(BOOK, e).length > 0;
    G.waitInput(m, 120, () => L.peekSym(m, 'g_n')[0] === 2 * mv - 1);
    const last = L.peekSym(m, 'g_last', 2);
    e.make(last[0], last[1]); e.ply = 0;
    searched.push((thinks > t0 ? 'S' : 'B') + (inBook ? '' : '-'));
    t0 = thinks;
    const ok = legalMoves(e).filter(([f, t]) => { e.make(f, t); const k = PB.moves(BOOK, e).length > 0; e.unmake(); return k; });
    if (!ok.length) break;
    const r = ok[rnd(ok.length)];
    G.typeUci(m, uci(r));
    G.waitInput(m, 120, () => L.peekSym(m, 'g_n')[0] >= 2 * mv);
    e.make(r[0], r[1]); e.ply = 0;
  }
  m.dbg.setTrace(null);
  // B = from the book, S = searched; '-' = the position was not in the book anyway
  const want = searched.map((x, i) => (x.endsWith('-') ? x : (level <= 4 && i >= level ? 'S' : 'B')));
  check(searched.join(' ') === want.join(' '), `level ${level}: the computer's moves ${searched.join(' ')} (B book, S searched; expected ${want.join(' ')})`, null);
}
console.log(`     ${compMoves} computer book moves checked; the longest game in book ${deepest} plies`);
console.log('all UI tests passed');
