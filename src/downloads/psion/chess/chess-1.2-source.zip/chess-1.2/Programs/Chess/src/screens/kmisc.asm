; ---------------------------------------------------------------------
; Small board-overlay entries: the turn line.
; ---------------------------------------------------------------------

; the turn (no clock) or the side to move's clock into the strip's row 3
set_turn:
        ldx  #st_p+12
        tst  st_timing
        bne  .clk
        ldaa #1
        staa 0,x
        ldaa #'W'
        tst  e_side
        beq  .s
        ldaa #'B'
.s:     staa 1,x
        rts
.clk:   jmp  clk_text

; (the hint's text moved to OV_GAME, khint.asm, 17 Nov)
