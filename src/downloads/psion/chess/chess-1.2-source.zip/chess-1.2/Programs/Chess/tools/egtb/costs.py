"""Probe-cost estimates for the Psion from the decoder operation counts.

Inputs: codec.jsonl (HRLE: measured code bits, extra bits, runs, bytes consumed up to the entry,
averaged over random legal positions) and lzh.jsonl (LZH: tokens, output bytes and coded bits up
to the entry).  Cost model (assumptions, see docs/egtb-compression.md):
  CPU 0.92 MHz.  HRLE: 70 cycles per Huffman code bit, 30 per extra bit, 80 per run.
  LZH: 70 cycles per coded bit, 100 per token, 15 per output byte (literal store / match copy).
  Fixed per probe: 2,500 cycles (symmetry, index arithmetic, setup) + 1,500 (capture test).
  Pack: 1 ms per access (2 per probe: index entry, block) + 30 us per byte read.
  HRLE streams the block only up to the wanted entry; LZH likewise (it decodes into RAM).
"""
import json, os, sys
DIR = os.environ['EGTB_DIR']
MHZ = 0.92
FIX = 2500 + 1500


def hrle(r):
    a = r['avg']
    cyc = 70 * a['codeBits'] + 30 * a['extraBits'] + 80 * a['runs'] + FIX
    m = r['max']
    cmax = 70 * m['codeBits'] + 30 * m['codeBits'] * 0.4 + 80 * m['runs'] + FIX   # extra bits not kept for max: ~0.4/code bit
    rd = a['bytes'] + 3
    return cyc, cmax, rd, m['bytes'] + 3


def lzh(r):
    cyc = 70 * r['avgBits'] + 100 * r['avgTokens'] + 15 * r['avgOutBytes'] + FIX
    rd = r['avgBits'] / 8 + 3
    cmax = 70 * r['maxBlock'] * 8 + 100 * r['maxBlock'] * 1.2 + 15 * r['decodedBytes'] + FIX   # whole worst block
    return cyc, cmax, rd, r['maxBlock'] + 3


def ms(cyc, rd):
    return cyc / MHZ / 1000 + 2 * 1.0 + rd * 0.030


rows = []
for l in open(os.path.join(DIR, 'codec.jsonl'), encoding='utf-8'):
    r = json.loads(l)
    cyc, cmax, rd, rdmax = hrle(r)
    name = '%s %s%s%s' % (r['key'], 'WTM' if r['stm'] == 'w' else 'BTM', ' pawn-7th slice' if r.get('pslice') else '', ' W-bit' if r.get('binary') else '')
    rows.append((name, 'HRLE%s @%d' % ('c' if r['ctx'] else '', r['blk']), r['totalWithIndex'], rd, cyc, ms(cyc, rd), rdmax, cmax, ms(cmax, rdmax)))
for l in open(os.path.join(DIR, 'lzh.jsonl'), encoding='utf-8'):
    r = json.loads(l)
    if r['blkEntries'] != 4096: continue
    cyc, cmax, rd, rdmax = lzh(r)
    name = '%s %s%s%s' % (r['key'], 'WTM' if r['stm'] == 'w' else 'BTM', ' pawn-7th slice' if r.get('pslice') else '', ' W-bit' if r.get('binary') else '')
    rows.append((name, 'LZH @%d' % r['blkEntries'], r['total'], rd, cyc, ms(cyc, rd), rdmax, cmax, ms(cmax, rdmax)))
rows.sort()
print('| table | scheme @ entries/block | bytes on pack | avg bytes read | avg 6303 cycles | avg ms/probe | worst bytes read | worst cycles | worst ms |')
print('|---|---|---|---|---|---|---|---|---|')
for n, s, tot, rd, cyc, t, rdm, cm, tm in rows:
    print('| %s | %s | %d | %.0f | %.0f | %.0f | %.0f | %.0f | %.0f |' % (n, s, tot, rd, cyc, t, rdm, cm, tm))
