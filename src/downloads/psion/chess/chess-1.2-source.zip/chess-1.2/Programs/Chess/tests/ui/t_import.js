'use strict';
// Importing games (menu: IMPORT GAME). PGN games are converted by tools/pgn2psion.py; the game
// files are then made on the emulated A: by an OPL procedure (standing in for the Comms Link,
// which Jape hasn't got), imported through the menu and checked against python-chess: the final
// position, the number of plies, the side the player takes over, take back, and a round trip
// back out through EXPORT PGN. Also: the chooser (UP/DOWN, ON), a set-up start, a game longer
// than the record, a file with an illegal move, and a file that isn't a game.
//   node tests/ui/t_import.js [--quick]
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const L = require('./lib.js');
const G = require('./glib.js');
const H = require('./help.js');
const { Machine } = require('../../tools/emu.js');
const { check } = L;

const WORK = path.join(L.ROOT, 'build', 'test', 'import');
fs.rmSync(WORK, { recursive: true, force: true });
fs.mkdirSync(WORK, { recursive: true });
const py = (code, input) => {
  const r = spawnSync('python', ['-E', '-P', '-c', code], { input: input || '', encoding: 'utf8' });
  if (r.status !== 0) throw new Error(r.stderr);
  return r.stdout;
};

// ---- the PGN games
const RANDOM = (seed, n, fen) => py([
  'import chess, chess.pgn, random', 'random.seed(' + seed + ')',
  fen ? 'b = chess.Board("' + fen + '")' : 'b = chess.Board()',
  'g = chess.pgn.Game()', fen ? 'g.setup(b)' : '', 'node = g',
  'g.headers["White"] = "Random, A"', 'g.headers["Black"] = "Random, B"', 'g.headers["Date"] = "2026.11.16"',
  'for i in range(' + n + '):',
  '    ms = list(b.legal_moves)',
  '    if not ms or b.is_game_over(claim_draw=True): break',
  '    caps = [m for m in ms if b.is_capture(m) or m.promotion]',
  '    m = random.choice(caps if caps and random.random() < 0.5 else ms)',
  '    node = node.add_variation(m); b.push(m)',
  'print(g)'].join('\n'));
const games = [
  // 1: a real-looking game: both castlings, checks, disambiguation (from t_pgn)
  '[White "Kasparov, G"]\n[Black "Deep Blue"]\n[Date "1997.05.11"]\n\n1. e4 d5 2. exd5 Nf6 3. d4 Qxd5 4. Nc3 Qa5 5. Bd2 c6 6. Qe2 Bf5 7. O-O-O e6 8. Nf3 Bb4 9. h3 O-O 10. g4 Bg6 11. Ne5 Nbd7 12. Nxg6 hxg6 13. Ne4 Rfe8 14. Nxf6+ Nxf6 *\n',
  // 2: random, captures and promotions favoured (en passant and under-promotions turn up)
  RANDOM(7, 160),
  // 3: a set-up start with Black to move
  RANDOM(11, 40, '4k3/1P4p1/8/3pP3/8/8/6p1/4K2R b K d6 0 30'),
  // 4: longer than the record (cut at 250): no repeated position or game end, few captures, a
  // pawn move whenever the fifty-move count passes 60, so it runs to 300 plies
  py([
    'import chess, chess.pgn, random', 'random.seed(1)', 'b = chess.Board()', 'g = chess.pgn.Game(); node = g',
    'g.headers["White"] = "Long"', 'g.headers["Black"] = "Game"',
    'while len(b.move_stack) < 300:',
    '    ok = []',
    '    for m in b.legal_moves:',
    '        b.push(m); bad = b.is_repetition(2) or b.is_game_over(claim_draw=True); b.pop()',
    '        if not bad: ok.append(m)',
    '    if not ok: break',
    '    caps = [m for m in ok if b.is_capture(m)]',
    '    pawns = [m for m in ok if b.piece_type_at(m.from_square) == chess.PAWN]',
    '    r = random.random()',
    '    if pawns and b.halfmove_clock > 60: m = random.choice(pawns)',
    '    elif caps and r < 0.08: m = random.choice(caps)',
    '    else: m = random.choice(ok)',
    '    node = node.add_variation(m); b.push(m)',
    'print(g)'].join(String.fromCharCode(10))),
];
fs.writeFileSync(path.join(WORK, 'in.pgn'), games.join('\n'));
const conv = spawnSync('python', ['-E', '-P', path.join(L.ROOT, 'tools', 'pgn2psion.py'), path.join(WORK, 'in.pgn'), '--out', WORK], { encoding: 'utf8' });
console.log(conv.stdout.trim().split('\n').map((l) => '     ' + l).join('\n'));
check(conv.status === 0 && fs.existsSync(path.join(WORK, 'GAME4.ODB')), 'converted 4 games', null);
const files = [1, 2, 3, 4].map((n) => fs.readFileSync(path.join(WORK, 'GAME' + n + '.ODB'), 'latin1').split('\r\n').filter((l) => l !== ''));
// 5: GAME1 with one move made illegal (the 9th ply)
const bad = files[0].slice();
bad[3] = bad[3].split(' ').map((u, i) => (i === 8 ? 'e1e5' : u)).join(' ');
files.push(bad);
// 6: not a game file
files.push(['HELLO', 'THIS IS NOT A GAME']);

// the expected end of each: python-chess replaying the file's own lines
const expect = files.slice(0, 5).map((lines) => JSON.parse(py([
  'import chess, json, sys', 'ls = sys.stdin.read().split("\\n")',
  'st = ls[2]',
  'if st == "START": b = chess.Board()',
  'else:',
  '    b = chess.Board(None); [b.set_piece_at(i, chess.Piece.from_symbol(st[1 + i])) for i in range(64) if st[1 + i] != "."]',
  '    b.turn = st[65] == "w"; c = int(st[66], 16)',
  '    b.castling_rights = (chess.BB_H1 if c & 1 else 0) | (chess.BB_A1 if c & 2 else 0) | (chess.BB_H8 if c & 4 else 0) | (chess.BB_A8 if c & 8 else 0)',
  '    b.ep_square = None if st[67] == "-" else chess.parse_square(st[67:69]); b.halfmove_clock = int(st[69:71])',
  'start = b.fen(); n = 0; legal = True',
  'for u in " ".join(ls[3:]).split():',
  '    m = chess.Move.from_uci(u)',
  '    if m not in b.legal_moves: legal = False; break',
  '    b.push(m); n += 1',
  'print(json.dumps({"start": start, "fen": b.fen(), "plies": n, "legal": legal, "moves": [m.uci() for m in b.move_stack], "turn": "w" if b.turn else "b"}))',
].join('\n'), lines.join('\n'))));

// ---- the files on A:, made by an OPL procedure
const q = (s) => '"' + s.replace(/"/g, '') + '"';
const mk = ['MKGAMES:'];
files.forEach((lines, i) => {
  mk.push('CREATE "A:GAME' + (i + 1) + '",A,L$');
  for (const l of lines) mk.push('A.L$=' + q(l), 'APPEND');
  mk.push('CLOSE');
});
const pk = H.make({ MKGAMES: mk }, 'import');
function machine() {
  const m = new Machine({ rom: '46a-lz64.rom', ram: 64 });
  m.boot();
  m.insertPack(path.join(L.BUILD, 'CHESS.opk'), 0);
  m.insertPack(pk, 1);
  H.run(m, 'MKGAMES', 30); H.top(m);
  m.runProc('CHESS', 'B'); m.runSeconds(6); G.waitInput(m, 10);
  return m;
}
// choose A:GAMEn in the chooser (DOWN from GAME1) and load it; wait for the import to end
function importGame(m, n) {
  G.menu(m, ['I']);
  check(L.waitFor(m, 'IMPORT A:GAME1', 20), 'the chooser shows A:GAME1: "' + m.screen()[1].trim() + '"', m);
  for (let i = 1; i < n; i++) { m.press('DOWN', 3, 10); m.runSeconds(1); }
  check(m.screen()[0].trim() === 'IMPORT A:GAME' + n, 'chosen: ' + m.screen()[0].trim(), m);
  m.press('EXE', 3, 10);
  for (let i = 0; i < 600; i++) { m.runSeconds(1); if (!m.screenText().includes('IMPORTING') && G.waitInput(m, 1)) break; }
}

let m = machine();
// the chooser: DOWN, UP, ON
G.menu(m, ['I']);
check(L.waitFor(m, 'IMPORT A:GAME1', 20) && m.screen()[1].startsWith('Kasparov v Deep Blue'), 'chooser: A:GAME1 "' + m.screen()[1].trim() + '"', m);
m.press('DOWN', 3, 10); m.runSeconds(1);
check(m.screen()[0].trim() === 'IMPORT A:GAME2', 'DOWN: A:GAME2', m);
m.press('UP', 3, 10); m.runSeconds(1); m.press('UP', 3, 10);
{ const c0 = m.cycles(); const ok = L.waitFor(m, 'IMPORT A:GAME6', 20);
  check(ok, 'UP twice: round to A:GAME6 (' + ((m.cycles() - c0) / 921600).toFixed(1) + ' s to look through 99..7)', m); }
m.press('ON', 3, 10); G.waitInput(m, 10);
check(L.peekSym(m, 'g_n')[0] === 0 && G.engFen(m).startsWith('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w'), 'ON: cancelled, the game as it was', m);

const QUICK = process.argv.includes('--quick');   // (run_all: the two long games are left out)
for (const n of (QUICK ? [1, 3] : [1, 2, 3, 4])) {
  if (n > 1) m = machine();
  const t0 = m.cycles();
  importGame(m, n);
  const secs = (m.cycles() - t0) / 921600;
  const e = expect[n - 1];
  const want = n === 4 ? Math.min(e.plies, 250) : e.plies;
  const gn = L.peekSym(m, 'g_n')[0];
  const f3 = (s) => s.split(' ').slice(0, 3).join(' ');
  check(gn === want, `GAME${n}: ${gn} plies imported (${want} in the file) in ${secs.toFixed(0)} s`, m);
  if (n !== 4) check(f3(G.engFen(m)) === f3(e.fen), `GAME${n}: the final position is python-chess's: ${f3(e.fen)}`, m);
  check((L.peekSym(m, 'g_human')[0] ? 'b' : 'w') === G.engFen(m).split(' ')[1], `GAME${n}: the player has the side to move`, m);
  // still the player's move a few seconds later (the computer doesn't start)
  m.runSeconds(5);
  check(L.peekSym(m, 'g_n')[0] === gn, `GAME${n}: the computer waits for the player`, m);
  // a round trip: EXPORT PGN gives the same moves
  G.menu(m, ['E']);
  { const c0 = m.cycles(); check(L.waitFor(m, 'PGN SAVED AS', 120), `GAME${n}: exported in ${((m.cycles() - c0) / 921600).toFixed(0)} s`, m); }
  m.press('EXE', 3, 10); G.waitInput(m, 10);
  const r = (() => { const a = []; m.mem.getSnapshotData(a); return Buffer.from(a); })();
  const i = r.indexOf('[Event ', 0, 'latin1');
  let p = i - 2; const lines = []; const ty = r[p + 1];
  while (r[p] > 0 && r[p] < 255 && r[p + 1] === ty) { lines.push(r.slice(p + 2, p + 2 + r[p]).toString('latin1')); p += 2 + r[p]; }
  const back = JSON.parse(py('import io, json, sys, chess.pgn\ng = chess.pgn.read_game(io.StringIO(sys.stdin.read()))\nprint(json.dumps([m.uci() for m in g.mainline_moves()]))', lines.join('\n') + '\n'));
  check(JSON.stringify(back) === JSON.stringify(e.moves.slice(0, want)), `GAME${n}: exported again, the same ${back.length} moves`, m);
  // take back: DEL steps back (when the game is still on: an ended game shows its result first)
  if (L.peekSym(m, 'g_result')[0] === 0 && L.peekSym(m, 'g_stat')[0] === 0) {
    m.press('DEL', 3, 10); G.waitInput(m, 30);
    check(L.peekSym(m, 'g_n')[0] < gn, `GAME${n}: DEL takes back (${gn} -> ${L.peekSym(m, 'g_n')[0]})`, m);
  } else console.log(`     GAME${n}: the game ended in the file (result ${L.peekSym(m, 'g_result')[0]}): no take-back check`);
}

// no game files at all
{
  const m0 = new Machine({ rom: '46a-lz64.rom', ram: 64 }); m0.boot();
  m0.insertPack(path.join(L.BUILD, 'CHESS.opk'), 0);
  m0.runProc('CHESS', 'B'); m0.runSeconds(6); G.waitInput(m0, 10);
  G.menu(m0, ['I']);
  check(L.waitFor(m0, 'NO GAMES TO IMPORT', 20), 'no files: "NO GAMES TO IMPORT"', m0);
  m0.press('EXE', 3, 10); G.waitInput(m0, 10);
  check(L.peekSym(m0, 'g_n')[0] === 0, 'and back to the game', m0);
}

// 5: an illegal move stops the import at it, with a message
m = machine();
importGame(m, 5);
check(L.peekSym(m, 'g_n')[0] === 8 && m.screenText().includes('ILLEGAL MOVE IN FILE'), 'GAME5: stopped before the illegal 9th ply, "ILLEGAL MOVE IN FILE" (' + L.peekSym(m, 'g_n')[0] + ' plies)', m);
// 6: not a game file
G.menu(m, ['I']); L.waitFor(m, 'IMPORT A:GAME1', 20);
for (let i = 1; i < 6; i++) { m.press('DOWN', 3, 10); m.runSeconds(1); }
m.press('EXE', 3, 10); m.runSeconds(3);
check(m.screenText().includes('NOT A GAME FILE') && m.screenText().includes('A:GAME6'), 'GAME6: "NOT A GAME FILE: A:GAME6"', m);
m.press('EXE', 3, 10); G.waitInput(m, 10);
check(L.peekSym(m, 'g_n')[0] === 8, 'and the game is as it was', m);
console.log('all UI tests passed');
