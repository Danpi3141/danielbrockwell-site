"""Summarise match results.

    python analyze.py NAME [NAME ...]          per-match W/D/L, score, Elo diff (95% CI), depth/time
    python analyze.py --fit NAME [NAME ...]    combined Elo of A from games vs several Stockfish levels

Elo diff = -400 log10(1/s - 1).  95% CI from the pentanomial variance of game pairs (each opening
played with both colours); unpaired games fall back to per-game (trinomial) variance.
--fit: maximum-likelihood rating x with E = 1/(1+10^((R_sf - x)/400)) per game, SE from the
Fisher information scaled by the observed dispersion (accounts for draws).
"""
import json
import math
import os
import statistics
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))


def load(name):
    with open(os.path.join(HERE, 'results', name + '.jsonl')) as f:
        return [json.loads(l) for l in f if l.strip()]


def elo(s):
    s = min(max(s, 1e-6), 1 - 1e-6)
    return -400 * math.log10(1 / s - 1)


def score_ci(games):
    n = len(games)
    s = sum(g['score_a'] for g in games) / n
    pairs = defaultdict(list)
    for g in games:
        pairs[g['opening']].append(g['score_a'])
    units = []
    for v in pairs.values():
        if len(v) == 2:
            units.append(((v[0] + v[1]) / 2, 2))
        else:
            units.extend((x, 1) for x in v)
    # variance of the mean, each unit weighted by its game count
    var = sum(w * w * (u - s) ** 2 for u, w in units) / (n * n)
    se = math.sqrt(var)
    return s, se


def summary(name):
    g = load(name)
    w = sum(1 for x in g if x['score_a'] == 1)
    d = sum(1 for x in g if x['score_a'] == 0.5)
    l = sum(1 for x in g if x['score_a'] == 0)
    s, se = score_ci(g)
    e, lo, hi = elo(s), elo(s - 1.96 * se), elo(s + 1.96 * se)
    errs = [x for x in g if x['error']]
    adj = sum(1 for x in g if x['reason'] == 'adjudicated_maxply')
    st = [m for x in g for m in x['stats_a'] if m[0] is not None]
    dep = statistics.mean(m[0] for m in st) if st else float('nan')
    tm = statistics.mean(m[2] for m in st) if st else float('nan')
    plies = statistics.mean(x['plies'] for x in g)
    print(f"{name:24s} {g[0]['a']} vs {g[0]['b']}: N={len(g)} +{w} ={d} -{l}  score {100 * s:.1f}%  "
          f"Elo {e:+.0f} [{lo:+.0f}, {hi:+.0f}]  errors={len(errs)} adj={adj} plies={plies:.0f} "
          f"A depth={dep:.2f} t/move={1000 * tm:.0f}ms")
    for x in errs:
        print('   ERROR', x['error']['engine'], x['error']['exc'][:120], '| fen', x['error']['fen'])
    return g


def depth_profile(g, key='stats_a'):
    """Depth histogram (% of moves at each completed depth)."""
    hist = defaultdict(int)
    for x in g:
        for m in x[key]:
            if m[0] is not None:
                hist[m[0]] += 1
    tot = sum(hist.values())
    return {k: round(100 * v / tot, 1) for k, v in sorted(hist.items())}


def fit(names):
    games = []
    for n in names:
        for x in load(n):
            b = x['b']
            assert b.startswith('sf:'), b
            games.append((int(b.split(':')[1]), x['score_a']))
    k = math.log(10) / 400
    x = 1500.0
    for _ in range(100):
        g1 = g2 = 0.0
        for r, s in games:
            e = 1 / (1 + 10 ** ((r - x) / 400))
            g1 += k * (s - e)
            g2 -= k * k * e * (1 - e)
        step = -g1 / g2
        x += step
        if abs(step) < 1e-6:
            break
    info = 0.0
    disp = 0.0
    for r, s in games:
        e = 1 / (1 + 10 ** ((r - x) / 400))
        info += k * k * e * (1 - e)
        disp += (s - e) ** 2 / (e * (1 - e))
    disp /= max(1, len(games) - 1)
    se = math.sqrt(disp / info)
    print(f"fit over {len(games)} games ({', '.join(names)}): Elo {x:.0f} +- {1.96 * se:.0f} (95%), dispersion {disp:.2f}")


def main():
    args = sys.argv[1:]
    if args and args[0] == '--fit':
        fit(args[1:])
        return
    for n in args:
        g = summary(n)
        print('   depth histogram (% of A moves):', depth_profile(g))


if __name__ == '__main__':
    main()
