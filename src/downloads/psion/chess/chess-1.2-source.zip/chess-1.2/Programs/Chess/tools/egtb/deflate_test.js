// How far are we from a general LZ77+Huffman coder?  zlib raw deflate (level 9) on the same
// filled, 2-bit packed data: per block (with deflate's own per-block Huffman headers) and whole.
//   node deflate_test.js KEY STM PERM [BLKS]
'use strict';
const zlib = require('zlib');
const { SPECS, layout } = require('./norm');
const C = require('./compress');
const [key, stm, permS, blksS] = process.argv.slice(2);
const spec = SPECS[key], lay = layout(spec), dtm = !!spec.dtm;
const src = C.loadNorm(key, stm);
if (process.env.BINARY) for (let i = 0; i < src.sym.length; i++) { if (src.sym[i] === 2) src.sym[i] = 0; if (src.kind[i] === 4) src.kind[i] = 0; }
const alphabet = dtm ? [...new Set(src.sym)].sort((a, b) => a - b) : [0, 1, 2];
const d = C.permute(src, lay.dims, permS.split('').map(Number), process.env.SQORDER || 'rank');
for (const blk of (blksS || '4096,16384').split(',').map(Number)) {
  const vals = C.fill(d, alphabet, C.allowedFn(dtm, 1), blk);
  const pack = new Uint8Array(Math.ceil(vals.length / 4));
  for (let i = 0; i < vals.length; i++) pack[i >> 2] |= vals[i] << (2 * (i & 3));
  let tot = 0; const bb = blk / 4;
  for (let s = 0; s < pack.length; s += bb) tot += Math.min(bb, zlib.deflateRawSync(pack.subarray(s, s + bb), { level: 9 }).length);
  const nb = Math.ceil(pack.length / bb);
  console.log(JSON.stringify({ key, stm, blk, deflatePerBlock: tot, withIndex: tot + nb * (tot < 65536 ? 2 : 3), wholeTable: zlib.deflateRawSync(pack, { level: 9 }).length }));
}
