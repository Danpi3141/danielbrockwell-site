'use strict';
// A mate on the 100th half-move counts (the fifty-move rule gives way to mate). With the
// half-move clock at 99, the side to move has a mate in one; both engines must find it and score
// it as mate (before 16 Nov the search scored the mated position as a fifty-move draw). Also
// positions at 99 with no mate: the clock's draw stays a draw. Assembler against JS, node for node.
const { Harness } = require('./harness.js');
const { Engine, uciStr } = require('../../ref/search.js');
const h = new Harness();
const e = new Engine();
e.ttInit(8);
const CASES = [
  ['7k/8/6K1/8/8/8/8/Q7 w - - 99 120', 'a1a8 a1g7', true], // Qa8# or Qg7#
  ['k7/8/1K6/8/8/8/8/7R w - - 99 150', 'h1h8', true],      // Rh8#
  ['6k1/5ppp/8/8/8/8/8/K3R3 w - - 99 90', 'e1e8', true],   // Re8# (back rank)
  ['8/8/8/4k3/8/8/8/R3K3 w - - 99 80', null, false],       // no mate: every move draws at once
];
let bad = 0;
for (const [fen, want, mate] of CASES) {
  h.setFen(fen); e.setFen(fen);
  h.call('e_clrtt'); e.ttInit(8);
  h.pokew('e_rnd', 0x1234); e.rnd = 0x1234;
  const N = 600;
  h.m.write(h.a('e_nlim'), [0, (N >> 8) & 255, N & 255]);
  h.pokew('e_tlim', 0); h.poke('e_maxd', 0); h.pokew('e_margin', 0);
  h.call('eng_think', 0, 0, 921600 * 600);
  const af = h.peek('e_bestf'), at = h.peek('e_bestt'), as = h.sw('e_score');
  const nb = h.bytes('e_nodes', 3), an = (nb[0] << 16) | (nb[1] << 8) | nb[2];
  const j = e.think(N);
  const am = uciStr(e, af, at), jm = uciStr(e, j.f, j.t);
  const ok = am === jm && as === j.score && an === j.nodes && (mate ? want.split(' ').includes(am) && as > 29000 : as === 0);
  console.log(`${ok ? 'ok  ' : 'FAIL'} ${fen}: asm ${am} ${as} (${an} nodes), js ${jm} ${j.score} (${j.nodes})${mate ? ', want ' + want + ' as mate' : ', want a draw score'}`);
  if (!ok) bad++;
}
console.log(bad ? bad + ' FAILED' : 'fifty-move mates ok');
process.exit(bad ? 1 : 0);
