'use strict';
// Helpers for the audit tests: drive whole games through the keys, read the engine's state,
// decode the screen back into a position, and run the python-chess model (gen_games.py).
const path = require('path');
const fs = require('fs');
const { spawnSync } = require('child_process');
const L = require('./lib.js');
const { keys } = L;

const DIG = { 1: 'U', 2: 'V', 3: 'W', 4: 'O', 5: 'P', 6: 'Q', 7: 'I', 8: 'J' };
const OUT = path.join(L.ROOT, 'build', 'test');

// python-chess games (gen_games.py), cached in build/test
function games(name, args) {
  fs.mkdirSync(OUT, { recursive: true });
  const f = path.join(OUT, name + '.json');
  const r = spawnSync('python', ['-E', '-P', path.join(__dirname, 'gen_games.py'), f].concat(args), { encoding: 'utf8' });
  if (r.status !== 0) throw new Error('gen_games.py failed: ' + r.stdout + r.stderr);
  return JSON.parse(fs.readFileSync(f, 'utf8')).games;
}

// run until the game waits for a key: the processor asleep inside key_wait (its timed loop or
// kw_sleep) with no key waiting. Up to s seconds; true if it does.
function waitInput(m, s, cond) {
  const a = L.sym(m, 'key_wait'), b = L.sym(m, 'key_upper');
  const n = Math.round((s || 30) * 20);
  for (let i = 0; i < n; i++) {
    const pc = m.dbg.pc();
    if (pc >= a && pc < b && m.dbg.sleeping() && (!cond || cond())) return true;
    m.runTicks(1);
  }
  return false;
}

// ... and the record has n plies
function waitPly(m, n, s) { return waitInput(m, s || 120, () => m.peek(L.sym(m, 'g_n')) === n); }

function menu(m, letters) { keys(m, ['ON']); waitInput(m, 5); keys(m, letters.concat(['EXE'])); }
// settings line n (0-based), then the keys, then ON back to the board
function setting(m, n, presses) {
  menu(m, ['S', 'S']); waitInput(m, 5);
  for (let i = 0; i < n; i++) keys(m, ['DOWN']);
  for (const k of presses) keys(m, [k]);
  keys(m, ['ON']); waitInput(m, 10);
}
const SET = { BOARD: 0, LEVEL: 1, CLOCK: 2, PACE: 3, COLOUR: 4, MOVES: 5, SOUND: 6, YMIN: 7, YINC: 8, CMIN: 9, CINC: 10, RESIGN: 11, TWO: 12 };

function start(opts) {
  const m = L.start(opts);
  if (!waitInput(m, 20)) throw new Error('the game did not start\n' + m.screenText());
  return m;
}
function twoPlayers(m) { setting(m, SET.TWO, ['RIGHT']); if (L.peekSym(m, 'g_mode')[0] !== 1) throw new Error('two-player mode not set'); }

// type a move (uci), with the promotion letter
function typeUci(m, u) {
  keys(m, [u[0], DIG[u[1]], u[2], DIG[u[3]]]);
  if (u.length > 4) { waitInput(m, 5); keys(m, [u[4].toUpperCase()]); }
}

// set a position up through the SET UP screen (FEN placement and side)
function setupFen(m, fen) {
  menu(m, ['S']); waitInput(m, 5);
  keys(m, ['C']);
  const [place, side] = fen.split(' ');
  let cur = 12;                                  // the cursor starts on e2 (rank * 8 + file)
  const rows = place.split('/');
  for (let r = 0; r < 8; r++) {
    let f = 0;
    for (const ch of rows[r]) {
      if (/\d/.test(ch)) { f += +ch; continue; }
      const n = (7 - r) * 8 + f;
      while ((cur >> 3) < (n >> 3)) { keys(m, ['UP']); cur += 8; }
      while ((cur >> 3) > (n >> 3)) { keys(m, ['DOWN']); cur -= 8; }
      while ((cur & 7) < (n & 7)) { keys(m, ['RIGHT']); cur++; }
      while ((cur & 7) > (n & 7)) { keys(m, ['LEFT']); cur--; }
      const up = ch.toUpperCase();
      keys(m, ch === up ? [up] : [up, up]);
      f++;
    }
  }
  if ((m.screen()[0][18] === 'B') !== (side === 'b')) keys(m, ['MODE']);   // the side shown (it starts as the game's)
  keys(m, ['EXE']);
  waitInput(m, 20);
}

// ---- the engine's and the game's state
const sq88 = (s) => (s.charCodeAt(1) - 49) * 16 + (s.charCodeAt(0) - 97);
const sqName = (q) => 'abcdefgh'[q & 7] + (((q >> 4) & 7) + 1);
// the persistent engine state: position, derived values, key, and the game's key history
function engState(m) {
  const b = L.sym(m, 'e_board');
  const kn = m.peek(L.sym(m, 'e_kn'));
  return {
    pos: m.read(b, L.sym(m, 'e_key') + 3 - b),     // e_board .. e_key: board, side, castle, ep, half, ksq, mg, eg, phase, cnt, pm, key
    kn, khist: m.read(L.sym(m, 'e_khist'), 2 * kn),
    g_n: m.peek(L.sym(m, 'g_n')),
    g_last: m.peek(L.sym(m, 'g_n')) ? L.peekSym(m, 'g_last', 3) : 'none',   // (not used with no moves)
    clk: [m.peekw(L.sym(m, 'g_clk')), m.peekw(L.sym(m, 'g_clk') + 2)],
    result: m.peek(L.sym(m, 'g_result')), reason: m.peek(L.sym(m, 'g_reason')),
  };
}
const PCH = ' PNBRQK  pnbrqk ';
// the engine's position in FEN terms
function engFen(m) {
  const b = L.peekSym(m, 'e_board', 128);
  const rows = [];
  for (let r = 7; r >= 0; r--) {
    let s = '', e = 0;
    for (let f = 0; f < 8; f++) {
      const p = b[r * 16 + f];
      if (!p) { e++; continue; }
      if (e) { s += e; e = 0; }
      s += PCH[p];
    }
    if (e) s += e;
    rows.push(s);
  }
  const side = L.peekSym(m, 'e_side')[0] ? 'b' : 'w';
  const c = L.peekSym(m, 'e_castle')[0];
  const cs = (c & 1 ? 'K' : '') + (c & 2 ? 'Q' : '') + (c & 4 ? 'k' : '') + (c & 8 ? 'q' : '') || '-';
  const ep = L.peekSym(m, 'e_ep')[0];
  return [rows.join('/'), side, cs, ep === 0xff ? '-' : sqName(ep), L.peekSym(m, 'e_half')[0]].join(' ');
}
// a FEN's board as 64 characters, a1..h8 ('.' empty)
function fenSquares(fen) {
  const out = new Array(64).fill('.');
  const rows = fen.split(' ')[0].split('/');
  for (let r = 0; r < 8; r++) {
    let f = 0;
    for (const ch of rows[r]) { if (/\d/.test(ch)) f += +ch; else out[(7 - r) * 8 + f++] = ch; }
  }
  return out.join('');
}

// ---- the screen, decoded with no knowledge of the game's variables
const CH_DIAM = 250;
// a map glyph's half (rows 0-2 or 4-6): 'w' hollow block, 'b' solid block, '.' empty, '?' else
function glyphHalf(rows) {
  const k = rows.join(',');
  if (k === '31,31,31') return 'b';
  if (k === '31,17,31') return 'w';
  if (k === '0,0,0') return '.';
  return '?';
}
function letter(c, sqIndex) {
  // c = cell code; returns piece char, '.' for an empty square (checking its shading), or '?'
  const dark = ((sqIndex >> 3) + (sqIndex & 7)) % 2 === 0;
  if (c === CH_DIAM) return dark ? '.' : '?';
  if (c === 32) return dark ? '?' : '.';
  const ch = String.fromCharCode(c);
  return 'PNBRQKpnbrqk'.includes(ch) ? ch : '?';
}
// The default layout: the letter view's four ranks (types) and the map (colours of all 64).
// Returns { letters: {sq: ch}, map: 64 chars w/b/., flipped, errors: [] }
function decodeMapLayout(m) {
  const c = m.cells();
  const udg = m.udgs();
  const errors = [];
  const ranks = [0, 1, 2, 3].map((r) => c[r * 20 + 8] - 49);
  if (ranks.some((x) => x < 0 || x > 7)) errors.push('rank numbers ' + ranks);
  const flipped = ranks[1] > ranks[0];
  const letters = {};
  for (let r = 0; r < 4; r++) {
    for (let col = 0; col < 8; col++) {
      const f = flipped ? 7 - col : col;
      const n = ranks[r] * 8 + f;
      letters[n] = letter(c[r * 20 + col], n);
    }
  }
  // the map: cell (r, col): two squares, the upper one on screen in rows 0-2
  const map = new Array(64).fill('?');
  for (let r = 0; r < 4; r++) {
    for (let col = 0; col < 8; col++) {
      const ch = c[r * 20 + 12 + col];
      let top, bot;
      if (ch === 32) { top = '.'; bot = '.'; } else if (ch < 8) { top = glyphHalf(udg[ch].slice(0, 3)); bot = glyphHalf(udg[ch].slice(4, 7)); } else { top = bot = '?'; }
      const f = flipped ? 7 - col : col;
      const rt = flipped ? 2 * r : 7 - 2 * r;
      const rb = flipped ? rt + 1 : rt - 1;
      map[rt * 8 + f] = top; map[rb * 8 + f] = bot;
    }
  }
  return { letters, map: map.join(''), flipped, errors };
}
// the split layout: all 64 squares as letters
function decodeSplit(m) {
  const c = m.cells();
  const errors = [];
  const left = [0, 1, 2, 3].map((r) => c[r * 20 + 8] - 49);
  const flipped = left[1] > left[0];
  const sq = new Array(64).fill('?');
  for (let r = 0; r < 4; r++) {
    const rl = left[r], rr = flipped ? rl + 4 : rl - 4;
    if (rl < 0 || rl > 7 || rr < 0 || rr > 7) { errors.push('rank numbers ' + left); continue; }
    for (let col = 0; col < 8; col++) {
      const f = flipped ? 7 - col : col;
      sq[rl * 8 + f] = letter(c[r * 20 + col], rl * 8 + f);
      sq[rr * 8 + f] = letter(c[r * 20 + 9 + col], rr * 8 + f);
    }
  }
  return { squares: sq.join(''), flipped, errors };
}
// the strip's three parts joined (columns 9-11, or 17-19 in the split layout), spaces dropped
function stripText(m, col) {
  const s = m.screen();
  return [0, 1, 2].map((r) => s[r].slice(col, col + 3).replace(/ /g, '')).join('');
}
// Play a model game through the keys (two-player mode): a new game or its set-up, then each
// ply, waiting until it is on the board; at the end of a game the result screen is left with
// EXE (the board). each(i, ply, ended) after every ply. Returns false if a ply was refused.
function playGame(m, g, each, opts) {
  opts = opts || {};
  if (g.start) G_setup(m, g.start);
  else { menu(m, ['N']); waitInput(m, 10); }
  const n0 = m.peek(L.sym(m, 'g_n'));
  if (opts.begin) opts.begin();
  for (let i = 0; i < g.plies.length; i++) {
    const p = g.plies[i];
    typeUci(m, p.uci);
    if (!waitPly(m, n0 + i + 1, 60)) return false;
    const ended = m.peek(L.sym(m, 'g_result')) !== 0;
    if (ended) { keys(m, ['EXE']); waitInput(m, 10); }
    if (each) each(i, p, ended);
  }
  return true;
}
function G_setup(m, fen) { setupFen(m, fen); }
// SAN cut into the strip's three parts: who, where, what happened
function sanParts(san) {
  let mm = /^(O-O(?:-O)?)([+#]?)$/.exec(san);
  if (mm) return mm[1] === 'O-O' ? ['O-O', '', mm[2]] : ['O-O', '-O', mm[2]];
  mm = /^([NBRQK][a-h]?[1-8]?|[a-h](?=x))?(x?[a-h][1-8])(=[NBRQ])?([+#]?)$/.exec(san);
  if (!mm) throw new Error('cannot cut ' + san);
  return [mm[1] || '', mm[2], (mm[3] || '') + mm[4]];
}
// a part as the strip shows it: three cells, a shorter part one column in
const partCells = (p) => (p.length >= 3 ? p.slice(0, 3) : (' ' + p).padEnd(3));
const stripCells = (m, col) => [0, 1, 2].map((r) => m.screen()[r].slice(col, col + 3));
// the engine's FEN (board, side, castling, en passant, half-moves) against python-chess's: the
// en passant square may be kept after every double step or only when it can be taken
const fen5 = (f) => f.split(' ').slice(0, 5).join(' ');
const fenMatch = (ef, p) => fen5(ef) === fen5(p.fen) || (p.fenl && fen5(ef) === fen5(p.fenl));
const colourOf = (ch) => (ch === '.' ? '.' : ch === ch.toUpperCase() ? 'w' : 'b');

module.exports = { fenMatch, playGame, sanParts, partCells, stripCells, DIG, OUT, games, waitInput, waitPly, menu, setting, SET, start, twoPlayers, typeUci, setupFen, sq88, sqName,
  engState, engFen, fenSquares, decodeMapLayout, decodeSplit, stripText, colourOf, PCH };
