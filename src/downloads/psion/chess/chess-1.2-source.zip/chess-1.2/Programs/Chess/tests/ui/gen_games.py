#!/usr/bin/env python3
"""The independent model for the UI audit tests: games made with python-chess.

    python -E -P tests/ui/gen_games.py OUT.json [--random N] [--seed S] [--maxply P] [--crafted] [--uniform] [--minply P]

Writes, for each game, its start (None = the standard position, else a FEN set up through the
game's SET UP screen, so its castling rights follow the set-up rule and it has no en passant)
and, for every ply: the move (uci), python-chess's SAN, the plain-squares text the game should
show (three parts), the FEN after it (fen: the en passant square after every double step; fenl: only when a capture is possible), the number of legal moves before it, and the game's
status after it under the engine's rules (mate, stalemate, fifty, rep, material or '').
"""
import argparse
import json
import random
import sys

import chess


def setup_castling(board):
    """the SET UP screen gives castling rights from where the kings and rooks stand"""
    r = ''
    if board.piece_at(chess.E1) == chess.Piece(chess.KING, chess.WHITE):
        if board.piece_at(chess.H1) == chess.Piece(chess.ROOK, chess.WHITE):
            r += 'K'
        if board.piece_at(chess.A1) == chess.Piece(chess.ROOK, chess.WHITE):
            r += 'Q'
    if board.piece_at(chess.E8) == chess.Piece(chess.KING, chess.BLACK):
        if board.piece_at(chess.H8) == chess.Piece(chess.ROOK, chess.BLACK):
            r += 'k'
        if board.piece_at(chess.A8) == chess.Piece(chess.ROOK, chess.BLACK):
            r += 'q'
    return r or '-'


def setup_fen(placement, side):
    b = chess.Board(placement + ' ' + side + ' - - 0 1')
    b.set_castling_fen(setup_castling(b))
    return b.fen()


def status(board):
    """the engine's eng_status rules"""
    if not any(board.generate_legal_moves()):
        return 'mate' if board.is_check() else 'stalemate'
    if board.halfmove_clock >= 100:
        return 'fifty'
    if board.is_repetition(3):
        return 'rep'
    pcs = board.occupied & ~board.kings
    if not (board.pawns | board.rooks | board.queens) and chess.popcount(pcs) <= 1:
        return 'material'
    return ''


def plain(board, mv):
    """plain squares: "e2"/"e4" ; a capture "h4x"; a promotion "e8Q"; then + or #"""
    p1 = chess.square_name(mv.from_square) + ('x' if board.is_capture(mv) else '')
    p2 = chess.square_name(mv.to_square)
    p3 = ''
    board.push(mv)
    suf = '#' if board.is_checkmate() else ('+' if board.is_check() else '')
    board.pop()
    if mv.promotion:
        p2 += chess.piece_symbol(mv.promotion).upper()
        p3 = suf
    else:
        p2 += suf
    return [p1, p2, p3]


def record(board, moves):
    plies = []
    for mv in moves:
        n = board.legal_moves.count()
        san = board.san(mv)
        pl = plain(board, mv)
        board.push(mv)
        plies.append({'uci': mv.uci(), 'san': san, 'plain': pl, 'fen': board.fen(en_passant='fen'), 'fenl': board.fen(), 'nlegal': n,
                      'status': status(board)})
        if plies[-1]['status']:
            break
    return plies


def pick(board, rnd):
    """a random legal move, leaning towards the interesting ones"""
    moves = list(board.legal_moves)
    special = [m for m in moves if m.promotion or board.is_castling(m) or board.is_en_passant(m)]
    if special and rnd.random() < 0.7:
        return rnd.choice(special)
    caps = [m for m in moves if board.is_capture(m) or board.gives_check(m)]
    if caps and rnd.random() < 0.35:
        return rnd.choice(caps)
    pawns = [m for m in moves if board.piece_type_at(m.from_square) == chess.PAWN]
    if pawns and rnd.random() < 0.3:
        return rnd.choice(pawns)
    return rnd.choice(moves)


def random_game(seed, maxply, lmmax=80, uniform=False):
    rnd = random.Random(seed)
    board = chess.Board()
    moves = []
    while len(moves) < maxply:
        if status(board):
            break
        if board.legal_moves.count() > lmmax:      # the screens keep 80 legal moves (a documented limit)
            break
        mv = rnd.choice(list(board.legal_moves)) if uniform else pick(board, rnd)
        moves.append(mv)
        board.push(mv)
    return {'name': ('uniform %d' if uniform else 'random %d') % seed, 'start': None, 'plies': record(chess.Board(), moves)}


def uci_game(name, ucis, start=None):
    board = chess.Board(start) if start else chess.Board()
    moves = [chess.Move.from_uci(u) for u in ucis.split()]
    for mv in moves:
        if mv not in board.legal_moves:
            raise SystemExit('%s: %s is not legal in %s' % (name, mv, board.fen()))
        board.push(mv)
    b0 = chess.Board(start) if start else chess.Board()
    return {'name': name, 'start': start, 'plies': record(b0, moves)}


CRAFTED = [
    ('castle white O-O, black O-O', 'e2e4 e7e5 g1f3 g8f6 f1c4 f8c5 e1g1 e8g8 d2d3 d7d6'),
    ('castle white O-O-O, black O-O-O', 'd2d4 d7d5 b1c3 b8c6 c1f4 c8f5 d1d2 d8d7 e1c1 e8c8 h2h3'),
    ('en passant white', 'e2e4 a7a6 e4e5 d7d5 e5d6 c7d6'),
    ('en passant black', 'a2a3 e7e5 a3a4 e5e4 d2d4 e4d3 c2d3'),
    ('promotion =Q, capture =N+, =R', 'a2a4 b7b5 a4b5 a7a6 b5a6 c8b7 a6a7 g8f6 a7b8q a8b8 h2h4 g7g5 h4g5 h7h6 g5f6 h6h5 f6e7 h5h4 e7d8n e8d8 b2b4 h4h3 b4b5 h3g2 b5b6 g2h1r'),
    ('under-promotion to bishop with capture', 'b2b4 a7a5 b4a5 b7b6 a5b6 c8b7 b6c7 b7c6 c7b8b'),
    ("fool's mate", 'f2f3 e7e5 g2g4 d8h4'),
    ("scholar's mate", 'e2e4 e7e5 f1c4 b8c6 d1h5 g8f6 h5f7'),
    ('stalemate (Loyd)', 'e2e3 a7a5 d1h5 a8a6 h5a5 h7h5 h2h4 a6h6 a5c7 f7f6 c7d7 e8f7 d7b7 d8d3 b7b8 d3h7 b8c8 f7g6 c8e6'),
    ('threefold repetition', 'g1f3 g8f6 f3g1 f6g8 g1f3 g8f6 f3g1 f6g8'),
    ('knights: file disambiguation Nbd2', 'g1f3 a7a6 d2d3 a6a5 b1d2 h7h6 f3h4 h6h5 d2f3 a5a4 f3d4 a4a3 h4f3 a3b2 f3d2'),
]
# set-up positions (placement, side to move, moves)
SETUP = [
    ('O-O-O with check', '3k4/8/8/8/8/8/8/R3K3', 'w', 'e1c1'),
    ('black O-O with check', '4k2r/8/8/8/8/8/8/5K2', 'b', 'e8g8'),
    ('three queens: Qh4e1', '1k6/8/8/8/4Q2Q/8/8/K6Q', 'w', 'h4e1'),
    ('rooks: rank disambiguation R1a3, then file Rhd1', '2k4K/8/8/R7/8/8/8/R6R', 'w', 'a1a3 c8b8 a3a1 b8c8 h1d1'),
    ('knights both: Ng4e5 style (four knights)', 'k7/8/8/8/2N3N1/8/2N3N1/K7', 'w', 'g4e5 a8b8 c2e3'),
    ('promotion capture with mate', '1n1k4/P7/3K4/8/8/8/8/8', 'w', 'a7b8q'),
    ('black to move first', 'r3k2r/pppppppp/8/8/8/8/PPPPPPPP/R3K2R', 'b', 'e8c8 e1g1 h7h6 d2d4'),
    ('pawn captures and en passant from set-up', '4k3/3p4/8/4P3/8/8/8/4K3', 'b', 'd7d5 e5d6 e8d8 e1e2 d8d7 e2e3 d7d6'),
]


def crafted():
    games = [uci_game(n, u) for n, u in CRAFTED]
    for n, pl, side, u in SETUP:
        games.append(uci_game(n, u, setup_fen(pl, side)))
    return games


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('out')
    ap.add_argument('--random', type=int, default=0)
    ap.add_argument('--seed', type=int, default=1)
    ap.add_argument('--maxply', type=int, default=120)
    ap.add_argument('--crafted', action='store_true')
    ap.add_argument('--uniform', action='store_true', help='plain random moves (long games)')
    ap.add_argument('--minply', type=int, default=0, help='keep only games at least this long')
    a = ap.parse_args()
    games = crafted() if a.crafted else []
    seed = a.seed
    while sum(1 for g in games if g['name'].startswith(('random', 'uniform'))) < a.random:
        g = random_game(seed, a.maxply, uniform=a.uniform)
        seed += 1
        if len(g['plies']) >= a.minply:
            games.append(g)
    with open(a.out, 'w', encoding='utf-8') as f:
        json.dump({'games': games}, f, indent=0)
    print('%d games, %d plies' % (len(games), sum(len(g['plies']) for g in games)))


if __name__ == '__main__':
    sys.exit(main())
