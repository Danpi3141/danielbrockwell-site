; =====================================================================
; Chess kernel start-up (17 Nov): assembled at the table's base (TTBASE) and
; stored after the kernel's code; the kernel's entry copies it up there and
; jumps to its first byte with D = ADDR(v%()). It runs once, before the
; engine is set up (eng_init clears the table after it), so it takes no
; array space of its own. Everything it calls is in the kernel.
; =====================================================================
        include "../defs.inc"

kinit:  ldx  #kv_first           ; the variables are not on the pack: clear them
.z:     clr  0,x
        inx
        cpx  #kernel_end
        bne  .z
        psha
        pshb
        ldx  #MENUBUF           ; (the variables there too)
        ldd  #201
        os   UT$FILL
        ldd  #14                ; what the OS has in the zero page the game borrows: aside
        std  T0
        ldx  #ZP1
        ldd  #MENUBUF+MB_USED
        os   UT$CPYB
        ldd  #42
        std  T0
        ldx  #ZP2
        ldd  #ZSAVE
        os   UT$CPYB
        ldd  #12
        std  T0
        ldx  #ZP3
        ldd  #ZSAVE+42
        os   UT$CPYB
        ldx  #ZP1               ; and cleared, like the other variables
        ldd  #14
        os   UT$FILL
        ldx  #ZP2
        ldd  #42
        os   UT$FILL
        ldx  #ZP3
        ldd  #12
        os   UT$FILL
        pulb
        pula
        sts  kv_sp              ; the launcher's stack, for exit from any depth
        std  kv_vars
        xgdx
        ldd  0,x
        std  kv_base
        ldd  2,x
        std  kv_size
        ldaa 4,x
        staa kv_dev
        ldaa KBB_DLAY           ; (DLAY, REPT and CLIK, PKOF are next to each other)
        ldab KBB_REPT
        std  kv_ksav
        ldd  KBB_CLIK
        std  kv_ksav+2
        ldaa KBB_STAT
        staa kv_ksav+4
        clr  KBB_CLIK           ; the game makes its own key ticks
        clr  KBB_PKOF           ; the kernel switches the packs off itself (key_wait)
        ldaa #KEY_DELAY
        staa KBB_DLAY
        ldaa #KEY_RATE
        staa KBB_REPT
        ldaa #1
        os   DP$MSET            ; 4-line mode
        ldab #$80
        os   DP$CSET            ; the clock leaves the glyphs alone (dpb_clok: not put
                                ; back, OPL has it off too and the top level sets it)
        clra
        clrb
        os   DP$STAT            ; cursor off
        ldaa #12
        os   DP$EMIT            ; clear the screen
        os   KB$FLSH
        jsr  scr_init
        bsr  pk_scan            ; find the blocks CHB0..
        bcc  .found
        ldab #E_FILES
        jmp  quit
.found: ; the transposition table, below the kernel: a power of two of 7-byte entries
        ldd  kv_base
        subd kv_size
        std  e_tt
        ldd  kv_size
        ldx  #7
        jsr  udiv               ; entries that fit
        std  kv_t0
        ldd  #128
.p2:    std  e_ttn
        asld
        bcs  .p2x
        xgdx
        cpx  kv_t0
        xgdx
        bls  .p2
.p2x:   ldd  TMW_FRAM
        std  kv_rnd
        orab #1                 ; the engine's generator: never 0
        std  e_rnd
        jmp  kinit_done         ; (the kernel sets up the engine: it clears the table, and this)


; find each block CHBn on the game's device with the OS's FL$BOPN (open a
; block file by name; until 17 Nov this walked the device's records itself,
; 170 bytes): kv_dir gets where its data starts, past the object length and
; the RETURN stub, or $FF. Carry set if block 0 is missing.
pk_scan:
        clr  kv_pkok            ; (the OS's file services select the device: pk_seek selects again)
        ldx  #kv_dir
        ldab #N_BLOCKS*3
        ldaa #$FF
.f:     staa 0,x
        inx
        decb
        bne  .f
        ldx  #kv_nbuf           ; the name "D:CHBn" (a leading count)
        ldaa #6
        staa 0,x
        ldaa kv_dev             ; 0 A:, 1 B:, 2 C:
        adda #'A'
        staa 1,x
        ldd  #$3A43             ; ":C"
        std  2,x
        ldd  #$4842             ; "HB"
        std  4,x
        clr  kv_t0              ; n
.b:     ldaa kv_t0
        adda #'0'
        staa kv_nbuf+6
        ldx  #kv_nbuf
        ldab #$83               ; a procedure
        os   FL$BOPN            ; found: the pack address is at its data
        bcs  .n
        os   PK$QADD            ; B:X = that address
        pshx
        pshb
        ldaa kv_t0
        ldab #3
        mul
        addd #kv_dir
        xgdx                    ; X = its entry
        pula
        staa 0,x
        pula
        pulb
        addd #18                ; past the object length (2) and the stub (16)
        std  1,x
        bcc  .n
        inc  0,x
.n:     inc  kv_t0
        ldaa kv_t0
        cmpa #N_BLOCKS
        bne  .b
        os   PK$PKOF
        ldaa kv_dir             ; CHB0 is needed
        cmpa #$FF
        beq  .bad
        clc
        rts
.bad:   sec
        rts

