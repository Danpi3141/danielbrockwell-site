// Two-stream variant: along one dimension of the chosen order, every other group of slices is
// stored as "same as the neighbouring slice?" residuals instead of values.
//   node xordiff.js KEY STM PERM POS STEP [BLK]
//     POS = position (0 outermost .. 3 innermost) of the dimension in PERM; STEP = slice step.
//   Slices with floor(c / STEP) odd are residual slices, predicted by slice c - STEP.
//   Residual: 0 = same value as the reference entry, else 1 + value.
//   A probe of a residual slice costs two decodes (residual entry, and if it is 0 the reference
//   entry); reference slices cost one.
'use strict';
const fs = require('fs'), path = require('path');
const L = require('./lib');
const { SPECS, layout } = require('./norm');
const C = require('./compress');

const [key, stm, permS, posS, stepS, blkS] = process.argv.slice(2);
const spec = SPECS[key], lay = layout(spec), dtm = !!spec.dtm;
const perm = permS.split('').map(Number), pos = +posS, step = +stepS, blk = +(blkS || 4096);
const src = C.loadNorm(key, stm);
if (process.env.BINARY) for (let i = 0; i < src.sym.length; i++) { if (src.sym[i] === 2) src.sym[i] = 0; if (src.kind[i] === 4) src.kind[i] = 0; }
const alphabet = dtm ? [...new Set(src.sym)].sort((a, b) => a - b) : [0, 1, 2];
const d = C.permute(src, lay.dims, perm, process.env.SQORDER || 'rank');
const n = d.sym.length;
const pd = perm.map(k => lay.dims[k]);
let stride = 1; for (let k = 3; k > pos; k--) stride *= pd[k];
const coord = i => Math.floor(i / stride) % pd[pos];
const isRes = i => (Math.floor(coord(i) / step) & 1) === 1;
const allowed = C.allowedFn(dtm, 1);
// reference stream: fill by the run-minimising DP
const refIdx = [], resIdx = [];
for (let i = 0; i < n; i++) (isRes(i) ? resIdx : refIdx).push(i);
const sub = (idx) => ({ sym: Uint8Array.from(idx, i => d.sym[i]), kind: Uint8Array.from(idx, i => d.kind[i]) });
const refD = sub(refIdx);
const refVals = C.fill(refD, alphabet, allowed, blk);
const full = new Int16Array(n).fill(-1);
refIdx.forEach((i, k) => { full[i] = refVals[k]; });
// residual stream: free entries copy the reference value when allowed
const res = new Uint8Array(resIdx.length), resKind = new Uint8Array(resIdx.length);
resIdx.forEach((i, k) => {
  const r = full[i - step * stride];
  if (allowed(d.kind[i], d.sym[i], r)) { res[k] = 0; full[i] = r; }
  else { let v = d.sym[i]; if (!allowed(d.kind[i], d.sym[i], v)) for (const a of alphabet) if (allowed(d.kind[i], d.sym[i], a)) { v = a; break; } res[k] = v + 1; full[i] = v; }
});
function size(vals, b) {
  const blocks = C.runsOf(vals, b), h = C.hrle(blocks, true);
  const data = h.blockBytes.reduce((a, x) => a + x, 0);
  return { data, index: h.blockBytes.length * (data < 65536 ? 2 : 3), table: h.table, total: data + h.blockBytes.length * (data < 65536 ? 2 : 3) + h.table };
}
const a = size(refVals, blk), b = size(res, blk);
const out = { key, stm, perm: perm.map(k => spec.names[k]).join('-'), order: process.env.SQORDER || 'rank', binary: !!process.env.BINARY,
  scheme: 'XDIFF+HRLEc', dimPos: pos, step, blk, refEntries: refIdx.length, resEntries: resIdx.length,
  ref: a, res: b, total: a.total + b.total };
console.log(JSON.stringify(out));
fs.appendFileSync(path.join(L.DATA_DIR, 'xordiff.jsonl'), JSON.stringify(out) + '\n', 'utf8');
