'use strict';
// Milestone 6 check: the engine mates with queen, rook, and bishop + knight against a bare king
// (both sides played by the engine at the Psion's budget), within the fifty-move rule.
// Usage: node mates.js [nodes per move]
const { Engine, uciStr, legalMoves } = require('./search.js');
const NODES = +(process.argv[2] || 2500);
const CASES = [
  ['KQK', '8/8/8/4k3/8/8/8/3QK3 w - - 0 1'], ['KQK', '7k/8/8/8/8/8/8/K2Q4 w - - 0 1'], ['KQK', '8/8/3k4/8/8/2Q5/8/7K w - - 0 1'],
  ['KRK', '8/8/8/4k3/8/8/8/R3K3 w - - 0 1'], ['KRK', '8/3k4/8/8/8/8/8/4K2R w - - 0 1'], ['KRK', '8/8/8/8/3k4/8/8/K6R b - - 0 1'],
  ['KBNK', '8/8/8/4k3/8/8/8/2B1KN2 w - - 0 1'], ['KBNK', '8/8/3k4/8/8/8/8/1B2K1N1 w - - 0 1'], ['KBNK', '4k3/8/8/8/8/8/8/2BNK3 w - - 0 1'],
];
let bad = 0;
for (const [name, fen] of CASES) {
  const e = new Engine();
  e.ttInit(8);
  e.setFen(fen);
  let result = 'unfinished', ply = 0;
  const line = [];
  for (; ply < 200; ply++) {
    const ms = legalMoves(e);
    if (!ms.length) { result = e.inCheck() ? 'mate' : 'stalemate'; break; }
    if (e.half >= 100) { result = 'fifty moves'; break; }
    if (e.insufficient()) { result = 'insufficient'; break; }
    const r = e.think(NODES);
    line.push(uciStr(e, r.f, r.t));
    e.make(r.f, r.t); e.ply = 0;
    if (e.half === 0) e.keys.length = 0;
  }
  const ok = result === 'mate';
  if (!ok) bad++;
  console.log(`${ok ? 'ok  ' : 'FAIL'} ${name.padEnd(5)} ${result} after ${Math.ceil(ply / 2)} moves  ${fen}`);
  if (!ok) console.log('     ' + line.join(' '));
}
console.log(bad ? `${bad} FAILED` : 'all mates found');
process.exit(bad ? 1 : 0);
