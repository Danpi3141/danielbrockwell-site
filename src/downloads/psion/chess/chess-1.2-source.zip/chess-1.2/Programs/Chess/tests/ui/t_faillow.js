'use strict';
// The fail-low extension in the real game (17 Nov): level 5 (3 s), the position before 25...Rd2??
// of the user's game (pgn/Pgn1.odb). Without the extension the computer plays Rd2 (mate in 2);
// with it the first depth-2 move fails low and the search runs on to find Rf8, within twice the
// time. With a clock, the extra time is at most an eighth of the clock left.
//   node tests/ui/t_faillow.js
const L = require('./lib.js');
const G = require('./glib.js');
const { check } = L;

const FEN = '3r2k1/2Q2ppp/4p3/8/8/1P2q3/P5PP/5R1K b - - 3 25';
const FR = 46080;                                   // cycles a frame (50 ms at 921,600 Hz)

function run(clockFrames) {
  const m = G.start();
  G.setting(m, G.SET.LEVEL, ['LEFT', 'LEFT']);      // level 7 -> 5
  if (clockFrames) G.setting(m, G.SET.CLOCK, ['RIGHT']);   // 5|5
  const think = L.sym(m, 'eng_think'), kthink = L.sym(m, 'think');
  let t0 = 0, t1 = 0, sp = 0, tadd = -1;
  m.dbg.setTrace((pc) => {
    if (pc === kthink && clockFrames) { const c = L.sym(m, 'g_clk'); m.pokew(c + 2, clockFrames); }   // Black's clock
    if (pc === think && !t0) { t0 = m.cycles(); sp = m.dbg.sp(); tadd = m.peekw(L.sym(m, 'e_tadd')); }
    else if (t0 && !t1 && m.dbg.sp() > sp + 1) t1 = m.cycles();
  });
  G.setupFen(m, FEN);
  G.waitInput(m, 30, () => t1 > 0);
  m.dbg.setTrace(null);
  const nb = L.peekSym(m, 'e_nodes', 3);
  const r = {
    lv: L.peekSym(m, 'st_level')[0], tlim: m.peekw(L.sym(m, 'e_tlim')), tadd,
    mv: G.sqName(L.peekSym(m, 'e_bestf')[0]) + G.sqName(L.peekSym(m, 'e_bestt')[0]),
    depth: L.peekSym(m, 'e_depth')[0], nodes: (nb[0] << 16) | (nb[1] << 8) | nb[2], s: (t1 - t0) / FR / 20,
  };
  console.log(`     level ${r.lv}, e_tlim ${r.tlim} frames, e_tadd ${r.tadd}: ${r.mv} after ${r.s.toFixed(2)} s, ${r.nodes} positions, depth ${r.depth}`);
  return r;
}

const a = run(0);
check(a.lv === 5 && a.mv === 'd8f8', 'level 5, no clock: Rf8 (not Rd2??)');
check(a.tadd === a.tlim && a.s <= 2 * a.tlim / 20 + 0.5, `no clock: at most twice the level's time (${a.s.toFixed(2)} s)`);
const b = run(160);                                 // Black's clock at 8 s: the extra time at most 1 s
check(b.tadd === 20, `clock 8 s left: extra time an eighth of it, 20 frames (got ${b.tadd})`);
check(b.s <= (b.tlim + 20) / 20 + 0.5, `clock: within the level's time and the extra (${b.s.toFixed(2)} s)`);
console.log('all UI tests passed');
