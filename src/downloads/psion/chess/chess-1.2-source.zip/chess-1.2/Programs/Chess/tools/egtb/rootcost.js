// Root-probe cost when only the strong side's (White's) table is stored and Black-to-move
// values are derived by a 1-ply search at the root.
//   node rootcost.js KEY N
// For N random legal White-to-move positions (no cheap winning capture), classify every legal
// White move as the strong-side engine would: the successor (Black to move) is
//   - a cheap exit (capture to <= 3 men): rule, no probe
//   - pawn endings, Black pawn on its 7th rank: 1 probe of the stored Black-to-move slice
//   - otherwise: expand Black's replies, 1 WTM probe each (cheap captures by rule), stopping at
//     the first reply that is not a White win (the move is then known not to win).
// Also reports the weak side's cost (Black to move at the root): 1 WTM probe per Black move.
'use strict';
const L = require('./lib');
const S = require('./solve');

const key = process.argv[2], N = +(process.argv[3] || 2000);
const T = L.loadTable(key);
const A = S.makeCtx(key), B = S.makeCtx(key);
const pawnKey = /P/.test(key);
const S4 = 64 ** 4;
let seed = 99; const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x80000000;
const isWin = v => v !== 0 && ((v - 1) & 1) === 1;

let sliceProbes = 0, roots = 0, sumProbes = 0, maxProbes = 0, sumMoves = 0, sumWeak = 0, sumWeakMoves = 0, weakRoots = 0;
const hist = [];
while (roots < N) {
  const i = Math.floor(rnd() * S4);
  if (T.val[i] === 255) continue;
  roots++;
  S.decode(A, i); S.setOcc(A);
  let probes = 0, moves = 0;
  S.genMoves(A, i, 0, (kind, j, men) => {
    moves++;
    if (kind === 1) return;                       // exit: cheap rule (or a promotion: other table)
    S.decode(B, j); S.setOcc(B);
    if (key === 'KPvKP') { probes++; return; }                                    // BTM = colour flip
    if (pawnKey && B.T[3] === L.P && (B.sqs[3] >> 3) === 1) { probes++; sliceProbes++; return; }   // stored slice
    let stillWin = true;
    S.genMoves(B, j, 1, (k2, j2, men2) => {
      if (!stillWin) return;
      if (k2 === 1) { if (L.score(j2) <= 0) stillWin = false; return; }   // cheap exit by rule
      probes++;
      if (!isWin(T.val[j2])) stillWin = false;
    });
  });
  sumProbes += probes; sumMoves += moves; if (probes > maxProbes) maxProbes = probes;
  hist.push(probes);
  // weak side: a Black-to-move root, one probe per Black move into the WTM table
  const ib = i + S4;
  if (T.val[ib] !== 255) {
    weakRoots++;
    S.decode(B, ib); S.setOcc(B);
    let wm = 0; S.genMoves(B, ib, 1, (k2) => { wm++; if (k2 === 0) sumWeak++; });
    sumWeakMoves += wm;
  }
}
hist.sort((a, b) => a - b);
console.log(JSON.stringify({ key, roots, avgWhiteMoves: +(sumMoves / roots).toFixed(1),
  strongSideProbes: { avg: +(sumProbes / roots).toFixed(1), avgOfWhichSlice: +(sliceProbes / roots).toFixed(1), median: hist[hist.length >> 1], p90: hist[Math.floor(hist.length * 0.9)], max: maxProbes },
  weakSideProbes: { avg: +(sumWeak / weakRoots).toFixed(1), avgMoves: +(sumWeakMoves / weakRoots).toFixed(1) } }));
