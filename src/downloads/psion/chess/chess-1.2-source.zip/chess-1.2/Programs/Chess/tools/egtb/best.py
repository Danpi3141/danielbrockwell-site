"""Best dimension order per table from the ordering sweep (perms_KEY_STM_ORDER.txt)."""
import glob, json, os, sys
DIR = os.environ['EGTB_DIR']
NAMES = {'KRvKB': ['WK', 'BK', 'R', 'B'], 'KRvKN': ['WK', 'BK', 'R', 'N'], 'KBNvK': ['WK', 'BK', 'B', 'N'],
         'KRvKP': ['P', 'WK', 'BK', 'R'], 'KQvKP': ['P', 'WK', 'BK', 'Q'], 'KPvKP': ['WP', 'BP', 'WK', 'BK']}
res = {}
for f in sorted(glob.glob(os.path.join(DIR, 'perms_*_*_*.txt'))):
    _, key, stm, order = os.path.basename(f)[:-4].split('_')
    rows = [json.loads(l) for l in open(f, encoding='utf-8') if l.startswith('{')]
    if not rows: continue
    for r in rows:
        r['order'] = order
        r['digits'] = ''.join(str(NAMES[key].index(x)) for x in r['perm'].split('-'))
    k = key + '_' + stm
    res.setdefault(k, []).extend(rows)
summary = {}
for k, rows in res.items():
    rows.sort(key=lambda r: r['total'])
    b = rows[0]
    p0 = min((r for r in rows if r['policy'] == 0), key=lambda r: r['total'])
    worst = rows[-1]
    rank_best = min((r for r in rows if r['order'] == 'rank'), key=lambda r: r['total'])
    summary[k] = {'best': b, 'bestPolicy0': p0, 'bestRankOrder': rank_best, 'worst': worst}
    print(k, 'best', b['perm'], b['order'], 'pol', b['policy'], b['total'], '| pol0', p0['total'],
          '| rank-order best', rank_best['total'], '| worst', worst['perm'], worst['order'], worst['total'], '| digits', b['digits'])
json.dump(summary, open(os.path.join(DIR, 'best.json'), 'w', encoding='utf-8'), indent=1)
