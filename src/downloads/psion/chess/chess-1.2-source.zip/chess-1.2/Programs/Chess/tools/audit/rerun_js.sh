#!/bin/sh
# The audit's JS runs, in order (final numbers): level matches, tactics, mate in one, mates,
# stalemates, soak. Usage: rerun_js.sh OUTDIR   (logs go there; game files to results/)
cd "$(dirname "$0")" || exit 1
O="$1"
mkdir -p results/old
for f in results/lvg_*.jsonl results/lvh_*.jsonl results/soak_*.jsonl; do
  [ -f "$f" ] && mv "$f" results/old/
done
for p in "L2 L1" "L3 L2" "L4 L3" "L5 L4" "L6 L5" "L7 L6" "L8 L7"; do
  set -- $p
  node match_levels.js lvh_$1_$2 $1 $2 --workers 5 | tail -1
done > "$O/levels_final.log" 2>&1
node tactics.js - 3 0 > "$O/tactics_final.log" 2>&1
node mate1.js - 300 4 1,2,3,4,5,6 > "$O/mate1_final.log" 2>&1
node endgames.js mates - 50 2500 > "$O/eg_final.log" 2>&1
node endgames.js mates - 100 2500 KBNK,KQK >> "$O/eg_final.log" 2>&1
{
  echo "-- 2500"; node endgames.js stale - 100 2500
  for l in L1 L2 L3 L4 L5; do echo "-- $l"; node endgames.js stale - 40 $l; done
} > "$O/stale_final.log" 2>&1
W=5 ./soak.sh > "$O/soak_final.log" 2>&1
echo done > "$O/js_done"
