; =====================================================================
; The result (slot A): who won, why, after how many moves.
; Returns A = 0 (EXE: look at the board, DEL takes back) or 1 (ON: menu).
; =====================================================================
        include "../defs.inc"
        include "ids.inc"

        jmp  result

r_txt:  fcl  "WHITE WINS"
        fcl  "BLACK WINS"
        fcl  "DRAWN GAME"
y_txt:  fcl  "BY CHECKMATE"
        fcl  "BY STALEMATE"
        fcl  "BY THE 50-MOVE RULE"
        fcl  "BY REPETITION"
        fcl  "NO MATING MATERIAL"
        fcl  "BY RESIGNATION"
        fcl  "ON TIME"
        fcl  "BY AGREEMENT"
        fcl  "THE RECORD IS FULL"

; X = list, A = 1-based index: X = that entry
nth:    deca
        beq  .x
        ldab 0,x
        abx
        inx
        bra  nth
.x:     rts

result: jsr  scr_cls
        ldaa g_result
        ldx  #r_txt
        bsr  nth
        jsr  scr_puts
        clra
        ldab #20
        jsr  scr_at
        ldaa g_reason
        ldx  #y_txt
        bsr  nth
        jsr  scr_puts
        ldaa #2
        clrb
        jsr  scr_at
        jsr  scr_pri
        fcl  "AFTER "
        ldab g_n                ; (plies + 1) / 2, one more if Black began
        tst  g_setup
        beq  .wb
        tst  g_spos+64
        beq  .wb
        incb
.wb:    incb
        lsrb
        clra
        jsr  num_str
        ldx  #kv_nbuf
        jsr  scr_puts
        jsr  scr_pri
        fcl  " MOVES"
        ldaa #3
        clrb
        jsr  scr_at
        jsr  scr_pri
        fcl  "EXE:BOARD  ON:MENU"
        jsr  scr_flush
        clra
        jsr  key_wait
        cmpb #K_ON
        beq  .m
        clra
        rts
.m:     ldaa #1
        rts
