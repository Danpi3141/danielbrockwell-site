'use strict';
// Time-limit overruns with the OS running (interrupts on), as the game calls eng_think: e_tlim in
// 50 ms frames, no node limit. Positions from random games; limits of the levels (1, 2, 3, 5, 10 s)
// with and without the levels 1-4 margin (the margin pass runs after the limit, without one).
// Reports the worst overrun (time taken minus the limit).
// Usage: node t_time2.js [positions] [maxSecs]
const { Harness } = require('./harness.js');
const { Engine, legalMoves } = require('../../ref/search.js');
const NPOS = +(process.argv[2] || 12), MAXS = +(process.argv[3] || 10);
const h = new Harness({ ints: true });
const e = new Engine();
let rng = 555;
const rnd = (k) => { rng = (Math.imul(rng, 1103515245) + 12345) & 0x7fffffff; return (rng >>> 8) % k; };
const fens = ['rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', 'r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1', '8/8/8/4k3/8/8/8/R3K3 w - - 0 1', '8/8/2k5/8/8/8/8/1BN1K3 w - - 0 1'];
while (fens.length < NPOS) {
  e.setFen('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
  const n = 6 + rnd(70);
  let ok = true;
  for (let p = 0; p < n; p++) { const ms = legalMoves(e); if (!ms.length) { ok = false; break; } const [f, t] = ms[rnd(ms.length)]; e.make(f, t); e.ply = 0; }
  if (!ok || !legalMoves(e).length) continue;
  let s = ''; // FEN of e
  for (let r = 7; r >= 0; r--) { let k = 0; for (let c = 0; c < 8; c++) { const pc = e.b[r * 16 + c]; if (!pc) { k++; continue; } if (k) { s += k; k = 0; } const ch = ' pnbrqk'[pc & 7]; s += pc & 8 ? ch : ch.toUpperCase(); } if (k) s += k; if (r) s += '/'; }
  let cs = ''; if (e.castle & 1) cs += 'K'; if (e.castle & 2) cs += 'Q'; if (e.castle & 4) cs += 'k'; if (e.castle & 8) cs += 'q';
  fens.push(`${s} ${e.side ? 'b' : 'w'} ${cs || '-'} - ${e.half} 1`);
}
let worst = -1e9, worstWhat = '', worstM = -1e9, worstMWhat = '', worst1 = -1e9, worst1What = '', n = 0, bad = 0;
const LIMITS = [1, 2, 3, 5, 10].filter(x => x <= MAXS);
for (const fen of fens) {
  for (const secs of LIMITS) {
    for (const margin of secs <= 3 ? [0, [300, 150, 70, 30][LIMITS.indexOf(secs) + (secs === 1 ? 0 : 1)]] : [0]) {
      if (h.setFen(fen).c) continue;
      h.call('e_clrtt');
      h.m.write(h.a('e_nlim'), [0, 0, 0]); h.pokew('e_tlim', secs * 20); h.poke('e_maxd', 0); h.pokew('e_margin', margin);
      const r = h.call('eng_think', 0, 0, 921600 * 600);
      const took = r.cycles / 921600, over = took - secs;
      const moved = h.peek('e_bestf') || h.peek('e_bestt');
      if (!moved) { bad++; console.log('FAIL no move', fen); }
      n++;
      const what = `${secs}s margin ${margin}: took ${took.toFixed(2)}s, depth ${h.peek('e_depth')}  ${fen}`;
      // depth 1 always finishes, whatever the limit: overruns then are by design and listed apart
      if (margin) { if (over > worstM) { worstM = over; worstMWhat = what; } }
      else if (h.peek('e_depth') <= 1) { if (over > worst1) { worst1 = over; worst1What = what; } }
      else if (over > worst) { worst = over; worstWhat = what; }
    }
  }
}
console.log(`${n} timed thinks with the OS running`);
console.log(`worst overrun without a margin, once depth 1 had finished: ${worst.toFixed(2)} s (${worstWhat})`);
console.log(`worst overrun while depth 1 finished (by design): ${worst1.toFixed(2)} s (${worst1What})`);
console.log(`worst overrun with a levels 1-4 margin (pass after the limit): ${worstM.toFixed(2)} s (${worstMWhat})`);
const fail = worst > 1.0 || bad;            // the clock is read every 32 nodes (0.3-0.6 s)
console.log(fail ? 'FAILED (overrun > 1 s after depth 1, or no move)' : 'time limits ok');
process.exit(fail ? 1 : 0);
