; ---------------------------------------------------------------------
; The player's move. Three ways in:
;   type it: file letter, rank digit, file letter, rank digit (E2E4).
;     The rank keys work without SHIFT: the key under the digit counts as
;     the digit (U 1, V 2, W 3, O 4, P 5, Q 6, I 7, J 8).
;   point at it: arrows move a cursor, EXE picks a piece up.
;   step through it: once a piece is chosen the arrows step through its
;     legal destinations; EXE puts it down.
; human_turn returns A = 0 when a move has been played (or taken back),
; 1 for the menu.
; ---------------------------------------------------------------------

human_turn:
        jsr  set_turn
        clr  in_n
        ldaa #$FF
        staa sel
        staa cur_sq
        clr  cur_on
        clr  hu_idle
        jsr  clk_start0         ; (only if not running yet)
.loop:  jsr  hu_text
        jsr  bshow
        ldaa #6                 ; blink the cursor; tick the clock
        ldab cur_sq
        cmpb #$FF
        beq  .nc
        tst  st_timing
        bne  .w
        inc  hu_idle            ; no clock: the cursor blinks for about 77 s, then
        bne  .w                 ; stays and the wait sleeps (so the Organiser can
        ldaa #1                 ; switch itself off)
        staa cur_on
        jsr  bshow
        clra
        bra  .w
.nc:    ldaa #20
        tst  st_timing
        bne  .w
        clra                    ; nothing to animate: sleep until a key
.w:     jsr  key_wait
        tstb
        bne  .key
        ldaa cur_on             ; time out: blink, clock
        eora #1
        staa cur_on
        jsr  clk_tick           ; C=1: the player's flag fell
        bcs  .flag
        jsr  set_turn
        bra  .loop
.flag:
        ldaa #H_FLAG
        rts
.key:   clr  msg_on
        clr  hu_idle
        ldaa #1
        staa cur_on
        jsr  key_upper
        cmpb #K_ON
        bne  .k1
        tst  in_n
        bne  .clr
        ldaa sel
        cmpa #$FF
        bne  .clr
        ldaa #H_MENU
        rts
.clr:   jsr  hu_clear
        bra  .loop
.k1:    cmpb #K_MODE
        bne  .k2
        ldaa v_half
        eora #1
        staa v_half
        bra  .loop
.k2:    cmpb #K_SPACE
        bne  .k3
        jsr  bshow
        ldaa #H_HINT
        rts
.k3:    cmpb #K_DEL
        bne  .k4
        tst  in_n
        beq  .d1
        dec  in_n
        ldaa in_n
        cmpa #2
        bhs  .loop
        jsr  hu_unsel
        jmp  .loop
.d1:    ldaa sel
        cmpa #$FF
        beq  .d2
        bsr  hu_unsel
        jmp  .loop
.d2:    tst  g_nosv
        beq  .d3
        jsr  msg_pri            ; (the game isn't saved: there is no record)
        fcl  "CANNOT TAKE BACK"
        jmp  .loop
.d3:    ldaa #H_BACK
        rts
.k4:    cmpb #K_EXE
        bne  .k5
        jsr  hu_exe             ; C=0: a move was chosen
        bcs  .loop
        ldaa #H_MOVE
        rts
.k5:    cmpb #K_UP
        blo  .k6
        cmpb #K_RIGHT
        bhi  .k6
        jsr  hu_arrow
        jmp  .loop
.k6:    bsr  hu_char            ; C=0: a move was chosen
        bcs  .loop
        ldaa #H_MOVE
        rts

; after the game is over: look at the board, take back. A as human_turn.
human_look:
        jsr  set_turn           ; the side to move (the turn line was the mover's)
        ldaa #$FF
        staa cur_sq
        staa sel
        clr  in_n
        jsr  bshow
        clra
        jsr  key_wait
        cmpb #K_MODE
        bne  .d
        ldaa v_half
        eora #1
        staa v_half
        bra  human_look
.d:     cmpb #K_DEL
        bne  .m
        ldaa #H_BACK
        rts
.m:     ldaa #H_MENU
        rts

hu_clear:
        clr  in_n
hu_unsel:
        ldaa #$FF
        staa sel
        staa cur_sq
        rts

; the typed text in the strip's row 2: "E2E" etc. with a "_"
hu_text:
        ldx  #st_p+8
        ldab in_n
        beq  .none
        cmpb #3
        bls  .ok
        ldab #3
.ok:    stab 0,x
        ldaa in_buf
        staa 1,x
        ldaa in_buf+1
        staa 2,x
        ldaa in_buf+2
        staa 3,x
        cmpb #3
        beq  .x
        incb                    ; the "_"
        stab 0,x
        abx
        ldaa #'_'
        staa 0,x
.x:     rts
.none:  ldd  st_p3              ; nothing typed: the last move's third part
        std  st_p+8
        ldd  st_p3+2
        std  st_p+10
        rts

; a typed key (upper case in B)
hu_char:
        ldaa in_n
        cmpa #4
        bhs  .no
        bita #1
        bne  .digit
        cmpb #'A'               ; a file letter is due
        blo  .no
        cmpb #'H'
        bhi  .no
        tsta
        bne  .st
        pshb
        bsr  hu_unsel           ; typing takes over from pointing
        pulb
        bra  .st
.digit: cmpb #'1'               ; a rank: 1-8, or the letter key under it
        blo  .map
        cmpb #'8'
        bls  .st
.map:   ldx  #dmap
.m:     ldaa 0,x
        beq  .no
        cba
        beq  .mf
        inx
        inx
        bra  .m
.mf:    ldab 1,x
.st:    ldx  #in_buf
        pshb
        ldab in_n
        abx
        pulb
        stab 0,x
        inc  in_n
        ldaa in_n
        cmpa #2
        beq  .from
        cmpa #4
        beq  .to
        sec
        rts
.no:    sec
        rts
.from:  ldaa in_buf
        ldab in_buf+1
        bsr  in_sq              ; B = square
        bsr  hu_pick            ; C=1: refused (reason shown)
        bcc  .fok
        dec  in_n
.fok:   sec
        rts
.to:    ldaa in_buf+2
        ldab in_buf+3
        bsr  in_sq
        ldaa sel
        jsr  try_move           ; C=0 played
        bcc  .x
        dec  in_n               ; correct the last square
.x:     rts

; key under each digit (no SHIFT): key, digit
dmap:   fcb  'U','1','V','2','W','3','O','4','P','5','Q','6','I','7','J','8',0

; A = file letter, B = rank digit: B = square
in_sq:  suba #'A'
        subb #'1'
        aslb
        aslb
        aslb
        aslb
        aba
        tab
        rts

; B = square: choose it as the piece to move. C=1 (and a reason) if not.
hu_pick:
        stab hu_s
        ldx  #e_board
        abx
        ldaa 0,x
        beq  .notyours
        anda #8
        cmpa e_side
        bne  .notyours
        ldaa hu_s               ; does it have a legal move?
        jsr  lm_from
        bcs  .stuck
        ldab hu_s
        stab sel
        stab cur_sq
        jsr  half_of
        ldaa #$FF
        staa hu_step
        clc
        rts
.notyours:
        jsr  msg_pri
        fcl  "NOT YOUR PIECE"
        bra  buzz
.stuck: jsr  msg_pri
        fcl  "THAT PIECE CANNOT MOVE"
buzz:   ldx  #snd_buzz
        jsr  snd_play
        sec
        rts

; A = from, B = to square: play it if legal (asking for the promotion
; piece). C=0 played; C=1 refused with a reason, or cancelled.
try_move:
        staa hu_f
        stab hu_t
        jsr  lm_find            ; C=0 found (any promotion code)
        bcc  .legal
        ldab hu_t               ; why not?
        ldx  #e_board
        abx
        ldaa 0,x
        beq  .chk
        anda #8
        cmpa e_side
        bne  .chk
        jsr  msg_pri
        fcl  "YOUR OWN PIECE IS THERE"
        bra  buzz
.chk:   tst  g_chk
        beq  .blk
        jsr  msg_pri
        fcl  "ILLEGAL: IN CHECK"
        bra  buzz
.blk:   jsr  msg_pri
        fcl  "ILLEGAL: BLOCKED"
        bra  buzz
.legal: ; a promotion?
        ldab hu_f
        ldx  #e_board
        abx
        ldaa 0,x
        anda #7
        cmpa #PC_P
        bne  .play
        ldaa hu_t
        anda #$70
        beq  .promo
        cmpa #$70
        bne  .play
.promo: jsr  msg_pri
        fcl  "PROMOTE TO: Q R B N"
        jsr  bshow
        clra
        jsr  key_wait
        clr  msg_on
        jsr  key_upper
        cmpb #K_ON
        bne  .p1
        sec
        rts
.p1:    ldaa #0
        cmpb #'R'
        bne  .p2
        ldaa #$08
.p2:    cmpb #'B'
        bne  .p3
        ldaa #$80
.p3:    cmpb #'N'
        bne  .p4
        ldaa #$88
.p4:    oraa hu_t
        staa hu_t
.play:  clc                     ; chosen: hu_f, hu_t
        rts

; EXE: pick the piece under the cursor up, or put it down
hu_exe: ldaa sel
        cmpa #$FF
        bne  .down
        ldab cur_sq
        cmpb #$FF
        beq  .no
        jsr  hu_pick
        bcs  .no
        ldaa sel                ; show it as typed
        bsr  .typed
        ldaa #2
        staa in_n
        sec
        rts
.down:  ldab cur_sq
        cmpb sel
        bne  .try
        jsr  hu_clear           ; on itself: put it back
.no:    sec
        rts
.try:   ldaa sel
        jmp  try_move
; A = square -> in_buf[0..1] as "E2"
.typed: tab
        andb #7
        addb #'A'
        stab in_buf
        anda #$70
        lsra
        lsra
        lsra
        lsra
        adda #'1'
        staa in_buf+1
        rts

; arrows (B = key). With a piece chosen they step through its legal
; destinations; otherwise they move the cursor over the board.
hu_arrow:
        ldaa sel
        cmpa #$FF
        bne  hu_stepk
        ldaa cur_sq
        cmpa #$FF
        bne  .mv
        ldaa #$14               ; the cursor starts on e2 (e7 for Black)
        tst  e_side
        beq  .st
        ldaa #$64
.st:    staa cur_sq
        tab
        jmp  half_of
.mv:    ; up/down along the files, left/right along the ranks, as seen
        ldaa #16
        cmpb #K_UP
        beq  .d
        ldaa #-16
        cmpb #K_DOWN
        beq  .d
        ldaa #-1
        cmpb #K_LEFT
        beq  .d
        ldaa #1
.d:     tst  v_flip
        beq  .n
        nega
.n:     adda cur_sq
        bita #$88
        bne  .x                 ; off the board: stay
        staa cur_sq
        tab
        jmp  half_of
.x:     rts

hu_stepk:
        cmpb #K_RIGHT
        beq  .fw
        cmpb #K_UP
        beq  .fw
        ; backwards: the previous destination
        ldab hu_step
        cmpb #$FF
        bne  .b1
        ldab lm_n
.b1:    tstb
        beq  .bw0
        decb
        bsr  lm_dest
        bcs  .b1
        bra  .got
.bw0:   ldab lm_n
        bra  .b1
.fw:    ldab hu_step
.f1:    incb
        cmpb lm_n
        blo  .f2
        clrb
.f2:    bsr  lm_dest
        bcs  .f1
.got:   stab hu_step
        ldab hu_s
        stab cur_sq
        jmp  half_of

; B = index into e_lm: C=0 if that move is from sel and not a repeat
; promotion (only the queen's is stepped to); hu_s = its destination.
; B kept.
lm_dest:
        pshb
        aslb
        ldx  #lm_buf
        abx
        ldaa 0,x
        cmpa sel
        bne  .no
        ldaa 1,x
        bita #$88
        bne  .no                ; an under-promotion: the queen's stands for it
        staa hu_s
        pulb
        clc
        rts
.no:    pulb
        sec
        rts

; A = square: C=0 if some legal move starts there
lm_from:
        ldab lm_n
        beq  .no
        ldx  #lm_buf
.l:     cmpa 0,x
        beq  .yes
        inx
        inx
        decb
        bne  .l
.no:    sec
        rts
.yes:   clc
        rts

; ---------------------------------------------------------------------
; blink_move: the last move's squares and any checking piece blink for
; about a second on the letters and the map. A key stops it (and stays).
; ---------------------------------------------------------------------
blink_move:
        tst  g_n
        beq  .x
        ldx  #g_last
        ldaa 0,x
        staa bk_sq
        ldaa 1,x
        anda #$77
        staa bk_sq+1
        ldaa #$FF
        staa bk_sq+2
        tst  g_chk
        beq  .go
        ldab g_ckr              ; the checking piece (found by the game overlay)
        stab bk_sq+2
.go:    ldaa #8                 ; about a second; the player's own move half that
        ldab e_side
        cmpb g_human
        bne  .n
        ldaa #4
.n:     staa bk_n
.l:     ldaa bk_on
        eora #1
        staa bk_on
        jsr  bshow
        ldaa TMW_FRAM+1
        adda #3
        staa bk_t
.w:     os   KB$TEST
        tstb
        bne  .stop
        ldaa TMW_FRAM+1
        cmpa bk_t
        beq  .nx
        slp
        bra  .w
.nx:    dec  bk_n
        bne  .l
.stop:  clr  bk_on
        jsr  bshow
.x:     rts

