; =====================================================================
; Chess engine for the Psion LZ64 (HD6303). Resident; see API.md.
; The kernel provides T0..T11, ZP1..ZP3 (zero page), TMW_FRAM and think_poll.
; =====================================================================
; search features (each must match ref/search.js opts: nullMove, lmr, futility, checkExt, pvs)
E_NULL   = 0                    ; null move (off since 17 Nov: saves 264+ bytes; measured in docs/strength.md s.13)
E_LMR    = 0                    ; late-move reductions (measured: -40 Elo at 2,500 nodes)
E_PVS    = 0                    ; null-window search after the first move (measured: -53 Elo; off = plain alpha-beta)
E_FUT    = 1                    ; futility cut at the last ply
E_CHKEXT = 1                    ; check extension
E_FAILLOW = 1                   ; a failing-low iteration may run past the limit, to twice it (17 Nov; failLow)
E_ROOTORD = 0                   ; the root's list kept and ordered by the last iteration's bests (17 Nov; rootOrder)

        include "eapi.asm"
        include "emove.asm"
        include "eeval.asm"
        include "esearch.asm"
        include "etab.inc"
; (evars.inc goes in the kernel's variable block)
