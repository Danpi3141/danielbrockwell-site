'use strict';
// Profile: cycles spent per routine (by nearest preceding global label) during a search.
const { Harness } = require('./harness.js');
const fs = require('fs'), path = require('path');
const h = new Harness();
const meta = JSON.parse(fs.readFileSync(path.join(__dirname, 'out', 'etest.json')));
const nameOf = require('./labels.js').namer(0x3000);
const fen = process.argv[2] || 'r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3';
h.setFen(fen); h.call('e_clrtt');
const N = +(process.argv[3] || 600);
h.m.write(h.a('e_nlim'), [0, (N >> 8) & 255, N & 255]);
const counts = {};
let last = 0, lastName = '';
h.m.dbg.setTrace(pc => { const c = h.m.cycles(); if (lastName) counts[lastName] = (counts[lastName] || 0) + (c - last); last = c; lastName = (pc >= 0x3000 && pc < 0x6FE0) ? nameOf(pc) : 'ROM/other'; });
const r = h.call('eng_think', 0, 0, 921600 * 3600);
h.m.dbg.setTrace(null);
const tot = Object.values(counts).reduce((a, b) => a + b, 0);
Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 25).forEach(([k, v]) => console.log(k.padEnd(14), (100 * v / tot).toFixed(1) + '%'));
console.log('total cycles', tot, 'nodes', N);
