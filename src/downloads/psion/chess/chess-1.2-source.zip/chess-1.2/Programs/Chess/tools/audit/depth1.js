'use strict';
// How long can depth 1 run (it always finishes, whatever the limit)? Depth-1 node counts (search +
// quiescence) over positions from the audit's game files. Usage: node depth1.js [positions] [files...]
const fs = require('fs');
const path = require('path');
const { Engine, parseUci } = require('../../ref/search.js');
const NP = +(process.argv[2] || 20000);
const files = process.argv.slice(3).length ? process.argv.slice(3) : fs.readdirSync(path.join(__dirname, 'results')).filter(f => /^(lvh|lvg|soak)_/.test(f)).map(f => path.join(__dirname, 'results', f));
const g = new Engine(), e = new Engine();
const counts = []; let worst = [];
let n = 0;
outer: for (const f of files) {
  for (const line of fs.readFileSync(f, 'utf8').trim().split('\n')) {
    const gm = JSON.parse(line);
    g.setFen('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
    const ms = gm.moves.split(' ');
    for (let i = 0; i < ms.length; i++) {
      if (i % 5 === 2) {
        e.b.set(g.b); e.side = g.side; e.castle = g.castle; e.ep = g.ep; e.half = 0; e.recompute(); e.hist.length = 0; e.keys.length = 0; e.ply = 0;
        e.ttInit(9);
        const r = e.think(0, 1);
        if (r) { counts.push(r.nodes); worst.push([r.nodes, gm.moves.split(' ').slice(0, i).join(' ')]); worst.sort((a, b) => b[0] - a[0]); worst = worst.slice(0, 3); }
        if (++n >= NP) break outer;
      }
      const m = parseUci(g, ms[i]); g.make(m[0], m[1]); g.ply = 0;
    }
  }
}
counts.sort((a, b) => a - b);
const q = (p) => counts[Math.min(counts.length - 1, Math.floor(p * counts.length))];
console.log(`${counts.length} positions: depth-1 nodes median ${q(0.5)}, 99% ${q(0.99)}, 99.9% ${q(0.999)}, max ${counts[counts.length - 1]}`);
for (const [k, mv] of worst) console.log(`  ${k} nodes after: ${mv}`);
