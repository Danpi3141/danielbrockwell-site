'use strict';
// Real-board mode: the move in words, the typed reply, both clocks.
const L = require('./lib.js');
const { check, keys } = L;
let m = L.start(); L.idle(m);
keys(m, ['ON']); m.runSeconds(1); keys(m, ['S', 'S', 'EXE']); m.runSeconds(1);
keys(m, ['RIGHT', 'RIGHT', 'DOWN', 'DOWN', 'RIGHT', 'ON']); L.idle(m);   // BOARD: REAL BOARD, CLOCK: 5|5
keys(m, ['ON']); m.runSeconds(1); keys(m, ['EXE']); L.idle(m);           // new game (the clock applies)
check(m.screen()[0].startsWith('NEW GAME') && m.screen()[2].startsWith('YOUR MOVE: _'), 'real-board mode: new game, your move', m);
check(/^W 0[45]:\d\d +B 05:00/.test(m.screen()[3]), 'both clocks: ' + m.screen()[3].trim(), m);
keys(m, ['E', 'V']);
check(m.screen()[2].startsWith('YOUR MOVE: E2_'), 'typed reply shows: ' + m.screen()[2].trim(), m);
keys(m, ['E', 'O']); L.idle(m);
check(m.screen()[0].startsWith('BLACK PLAYED') && /^1\.\.\. [a-hNBRQKO]/.test(m.screen()[1]), 'the reply in words: ' + m.screen()[1].trim(), m);
console.log('all real-board tests passed');
