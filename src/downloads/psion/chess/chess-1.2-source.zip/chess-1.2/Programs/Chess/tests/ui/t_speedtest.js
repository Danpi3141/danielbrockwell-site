'use strict';
// The TEMPORARY speed test (SPEEDTEST in src/defs.inc): from the start position, menu SPEED TEST
// (the 4th S); the results screen; the game is as it was afterwards.
//   node tests/ui/t_speedtest.js   (skipped when the build has no speed test)
const L = require('./lib.js');
const G = require('./glib.js');
const { check } = L;
if (!L.syms().sp_test) { console.log('ok   no speed test in this build (SPEEDTEST = 0)'); console.log('all UI tests passed'); process.exit(0); }
const m = G.start();
const before = G.engFen(m);
G.menu(m, ['S', 'S', 'S', 'S']);
check(L.waitFor(m, 'POSITIONS/S', 120), 'speed test results shown', m);
const scr = m.screen();
console.log(scr.map((l) => '     | ' + l).join('\n'));
const nps = +(scr[0].match(/POSITIONS\/S (\d+)/) || [])[1];
check(nps > 30 && nps < 300, 'positions a second ' + nps, m);
check(/SEARCH \d+ MS/.test(scr[1]) && /OVERLAY \d+ MS/.test(scr[2]) && /BOOK \d+ MS/.test(scr[3]), 'search, overlay and book times shown', m);
m.press('EXE', 3, 10); G.waitInput(m, 10);
check(G.engFen(m) === before && L.peekSym(m, 'g_n')[0] === 0, 'back to the game as it was', m);
console.log('all UI tests passed');
