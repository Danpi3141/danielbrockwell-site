#!/bin/sh
# 16 Nov: every level as the Psion now plays: the engine with the 64-key Zobrist (snap_z64c), the
# position book (levels 1-4: the first n moves, n = the level; 5-8: all of it) and the
# king-and-pawn distance table; games from the start position (--start 242: 484 games a match,
# each colour 242 times). Nodes = level seconds x ~69 nodes/s (70 less the Zobrist change's 1.5%).
M="python -E -P match.py"
O="--start 242 --openings 0:242 --workers 12"
E="snap_z64c"
K="Book=true,KPK=true"
$M lv5_L4_sf1320 $E:Nodes=207,Margin=30,BookMoves=4,$K sf:1320 $O > logs_lv5_L4_sf1320.txt 2>&1
$M lv5_L5_sf1320 $E:Nodes=345,$K sf:1320 $O > logs_lv5_L5_sf1320.txt 2>&1
$M lv5_L6_sf1320 $E:Nodes=690,$K sf:1320 $O > logs_lv5_L6_sf1320.txt 2>&1
$M lv5_L6_sf1500 $E:Nodes=690,$K sf:1500 $O > logs_lv5_L6_sf1500.txt 2>&1
$M lv5_L7_sf1500 $E:Nodes=2090,$K sf:1500 $O > logs_lv5_L7_sf1500.txt 2>&1
$M lv5_L7_sf1600 $E:Nodes=2090,$K sf:1600 $O > logs_lv5_L7_sf1600.txt 2>&1
$M lv5_L7_sf1700 $E:Nodes=2090,$K sf:1700 $O > logs_lv5_L7_sf1700.txt 2>&1
$M lv5_L8_sf1700 $E:Nodes=6900,$K sf:1700 $O > logs_lv5_L8_sf1700.txt 2>&1
$M lv5_L8_sf1800 $E:Nodes=6900,$K sf:1800 $O > logs_lv5_L8_sf1800.txt 2>&1
$M lv5_L3_L4 $E:Nodes=138,Margin=70,BookMoves=3,$K $E:Nodes=207,Margin=30,BookMoves=4,$K $O > logs_lv5_L3_L4.txt 2>&1
$M lv5_L2_L3 $E:Nodes=69,Margin=150,BookMoves=2,$K $E:Nodes=138,Margin=70,BookMoves=3,$K $O > logs_lv5_L2_L3.txt 2>&1
$M lv5_L1_L2 $E:Nodes=69,Margin=300,BookMoves=1,$K $E:Nodes=69,Margin=150,BookMoves=2,$K $O > logs_lv5_L1_L2.txt 2>&1
for f in logs_lv5_*.txt; do echo "$f: $(tail -1 $f)"; done
