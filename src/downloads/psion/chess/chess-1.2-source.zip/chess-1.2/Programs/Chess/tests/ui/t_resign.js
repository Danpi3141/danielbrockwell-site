'use strict';
// The computer's resignation (kcore.asm resign_chk, 17 Nov): it resigns after three of its moves
// in a row scored worse than -900 - 8k (k = the level's evaluation noise, e_margin: 0 at levels
// 5-8, 100/53/25/14 at levels 1-4, whose noise moves a score by up to 8k). In real games at level
// 1, when resign_chk is entered after a searched computer move (book moves skip it), the test sets
// e_score and e_margin to a case and reads g_bad (moves in a row counted) after it; three counted
// in a row must end the game.
//   node tests/ui/t_resign.js
const L = require('./lib.js');
const G = require('./glib.js');
const { check } = L;
const { Engine, legalMoves } = require('../../ref/search.js');

const nm = (q) => 'abcdefgh'[q & 7] + ((q >> 4) + 1);
const uci = (m) => nm(m[0]) + nm(m[1] & 0x77);
// [score, k, counted?]
const CASES = [
  [-1000, 100, false], [-1699, 100, false], [-1701, 100, true],
  [-1000, 14, false], [-1012, 14, false], [-1013, 14, true],
  [-899, 0, false], [-900, 0, false], [-901, 0, true],
  [-1324, 53, false], [-1325, 53, true], [-1100, 25, false], [-1101, 25, true],
  [30000, 100, false], [-30000, 0, true], [-30000, 100, true],
];
let m, want = null, e, n;
function fresh() {
  m = G.start();
  G.setting(m, G.SET.LEVEL, ['LEFT', 'LEFT', 'LEFT', 'LEFT', 'LEFT', 'LEFT']);   // level 1: the book for one move only
  check(L.peekSym(m, 'st_level')[0] === 1, 'level 1 set', m);
  want = null;
  const rc = L.sym(m, 'resign_chk'), sc = L.sym(m, 'e_score'), mg = L.sym(m, 'e_margin');
  m.dbg.setTrace((pc) => { if (pc === rc && want) { m.pokew(sc, want[0] & 0xFFFF); m.pokew(mg, want[1]); } });
  e = new Engine(); e.setFen('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'); e.ply = 0;
  n = 0;
}
const OPEN = ['e2e4', 'd2d4', 'g1f3', 'b1c3', 'f1e2', 'c1e3'];
function playerMove() {
  const lm = legalMoves(e);
  const mv = OPEN.map((u) => lm.find((x) => uci(x) === u)).find(Boolean) || lm[0];
  OPEN.splice(OPEN.indexOf(uci(mv)), 1);
  G.typeUci(m, uci(mv));
  e.make(mv[0], mv[1]); e.ply = 0; n++;
}
function computerMove() {
  check(G.waitPly(m, n + 1, 120), 'the computer moved', m);
  const last = L.peekSym(m, 'g_last', 2);
  e.make(last[0], last[1]); e.ply = 0; n++;
}
// each case in a new game: one computer move with the case's score and k
for (const c of CASES) {
  fresh();
  OPEN.length = 0; OPEN.push('e2e4', 'd2d4', 'g1f3', 'b1c3', 'f1e2', 'c1e3');
  playerMove(); computerMove();                         // (a book move: no resign test)
  want = c;
  playerMove(); computerMove();                         // searched: resign_chk with the case
  const got = L.peekSym(m, 'g_bad')[0];
  check(got === (c[2] ? 1 : 0), `score ${c[0]}, k ${c[1]}: ${got ? 'counted' : 'not counted'} (threshold ${-900 - 8 * c[1]})`, m);
}
// three in a row at level 1's noise: the computer resigns
fresh();
OPEN.length = 0; OPEN.push('e2e4', 'd2d4', 'g1f3', 'b1c3', 'f1e2', 'c1e3');
playerMove(); computerMove();
want = [-1800, 100];
for (let i = 0; i < 3; i++) { playerMove(); if (i < 2) computerMove(); }
G.waitInput(m, 120, () => L.peekSym(m, 'g_result')[0] !== 0);
check(L.peekSym(m, 'g_result')[0] === 1 && L.peekSym(m, 'g_reason')[0] === 6, 'three in a row: the computer (Black) resigns, White wins', m);
m.dbg.setTrace(null);
console.log('all UI tests passed');
