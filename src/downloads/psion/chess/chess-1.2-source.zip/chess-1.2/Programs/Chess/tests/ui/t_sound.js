'use strict';
// Sounds: the engine's blip after its move, the low buzz for a refused square.
const L = require('./lib.js');
const { check, keys } = L;
let m = L.start(); L.idle(m);
m.buzzStart();
keys(m, ['E', 'V', 'E', 'O']); L.idle(m);
let notes = m.buzzStop();
check(notes.some((n) => n.hz > 1800 && n.hz < 2200 && n.ms >= 30 && n.ms <= 50), 'blip after the engine moved: ' + JSON.stringify(notes), m);
m.buzzStart();
keys(m, ['A', 'I']);                       // a7: not your piece
m.runSeconds(1);
notes = m.buzzStop();
check(notes.some((n) => n.hz < 200 && n.ms >= 130), 'low buzz for a refused square: ' + JSON.stringify(notes), m);
console.log('sound tests passed');
