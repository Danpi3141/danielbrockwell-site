'use strict';
// For each resident kernel routine: which source files reference it. Routines whose only
// callers are in one overlay (src/screens/ov_*.asm) could move into that overlay.
//   node tools/cover/owners.js
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(__dirname, '..', '..');
const lst = fs.readFileSync(path.join(ROOT, 'build/game/kernel.lst'), 'utf8').split(/\r?\n/);
const sym = JSON.parse(fs.readFileSync(path.join(ROOT, 'build/game/kernel.sym.json'), 'utf8'));
const codeEnd = sym.kv_first[0];
const rts = Object.entries(sym).filter(([n, v]) => v[1] === 'rel' && v[0] < codeEnd && !n.includes('.'))
  .map(([n, v]) => ({ name: n, off: v[0] })).sort((a, b) => a.off - b.off);
rts.forEach((r, i) => { r.size = (i + 1 < rts.length ? rts[i + 1].off : codeEnd) - r.off; });
const files = [];
for (const d of ['src/kernel', 'src/screens', 'src/engine']) for (const f of fs.readdirSync(path.join(ROOT, d))) if (/\.(asm|inc)$/.test(f)) files.push(d + '/' + f);
const text = files.map((f) => ({ f, t: fs.readFileSync(path.join(ROOT, f), 'latin1').split(/\r?\n/).map((l) => l.replace(/;.*$/, '')) }));
const defIn = {};
for (const s of text) s.t.forEach((l) => { const m = /^([A-Za-z_$][\w$]*):/.exec(l); if (m) defIn[m[1]] = s.f; });
for (const r of rts) {
  if (/^(e_|eng_|ev_|g_|tt_|zx_|ef_)/.test(r.name)) continue;
  const re = new RegExp('(^|[^\w.$])' + r.name.replace(/\$/g, '\$') + '($|[^\w$])');
  const by = new Set();
  for (const s of text) s.t.forEach((l) => { if (re.test(l) && !new RegExp('^' + r.name.replace(/\$/g, '\$') + ':').test(l)) by.add(path.basename(s.f)); });
  const ov = [...by].filter((f) => f.startsWith('ov_'));
  const res = [...by].filter((f) => !f.startsWith('ov_'));
  const home = path.basename(defIn[r.name] || '?');
  // only callers in its own file (internal) plus exactly one overlay
  const onlyOne = ov.length === 1 && res.every((f) => f === home);
  if (onlyOne || process.argv.includes('--all')) console.log(`${r.name.padEnd(14)} ${String(r.size).padStart(4)}  in ${home.padEnd(12)} used by ${[...by].join(' ')}`);
}
