'use strict';
// Cycle profile of eng_think by routine (non-local label in tests/engine/out/etest.lst), on the
// bare emulated CPU. Each instruction's cycles go to the routine its PC is in.
//   node tools/audit/profile.js [nodes=1500]
const fs = require('fs');
const path = require('path');
const { Harness } = require('../../tests/engine/harness.js');
const NODES = +(process.argv[2] || 1500);
const FENS = [
  'r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3',
  'r1bqkb1r/pppp1ppp/2n2n2/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4',
  'r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1',
  'r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10',
  'r1b1k2r/ppppnppp/2n2q2/2b5/3NP3/2P1B3/PP3PPP/RN1QKB1R w KQkq - 0 1',
  '2r3k1/pp3ppp/8/3q4/8/1B6/PP3PPP/3Q2K1 b - - 0 1',
  '6k1/pp4pp/2p5/8/8/2P5/PP4PP/6K1 w - - 0 1',
];
const h = new Harness();
const BASE = 0x3000;
// each PC belongs to the nearest code symbol at or below it (label-only lines are not in the listing)
const meta = JSON.parse(fs.readFileSync(path.join(__dirname, '..', '..', 'tests', 'engine', 'out', 'etest.json'), 'utf8'));
const syms = Object.entries(meta.sym).filter(([k, v]) => v >= 0 && v < h.size && !k.includes('.') && !/^[A-Z0-9_]+$/.test(k)).sort((a, b) => a[1] - b[1]);
const owner = new Array(65536).fill('?');
for (let i = 0; i < syms.length; i++) {
  const end = i + 1 < syms.length ? syms[i + 1][1] : h.size;
  for (let a = syms[i][1]; a < end; a++) owner[BASE + a] = syms[i][0];
}
const cyc = {};
let last = -1, lc = 0, total = 0, nodes = 0;
const m = h.m;
m.dbg.setTrace((pc) => {
  const c = m.cycles();
  if (last >= 0) { const r = last >= BASE && last < 0x7000 ? owner[last] : 'OS/other'; cyc[r] = (cyc[r] || 0) + (c - lc); }
  last = pc; lc = c;
});
for (const fen of FENS) {
  h.setFen(fen); h.call('e_clrtt');
  h.m.write(h.a('e_nlim'), [(NODES >> 16) & 255, (NODES >> 8) & 255, NODES & 255]);
  h.pokew('e_tlim', 0); h.poke('e_maxd', 0); h.pokew('e_margin', 0);
  last = -1;
  const r = h.call('eng_think', 0, 0, 921600 * 3600);
  total += r.cycles;
  const nb = h.bytes('e_nodes', 3); nodes += (nb[0] << 16) | (nb[1] << 8) | nb[2];
}
const sum = Object.values(cyc).reduce((a, b) => a + b, 0);
console.log(`${FENS.length} positions, ${nodes} nodes, ${(total / 921600).toFixed(1)} s at 0.92 MHz: ${(nodes / (total / 921600)).toFixed(1)} nodes/s bare, ${Math.round(total / nodes)} cycles a node`);
for (const [k, v] of Object.entries(cyc).sort((a, b) => b[1] - a[1]).slice(0, 30))
  console.log(k.padEnd(16), (100 * v / sum).toFixed(1).padStart(5) + '%', String(Math.round(v / nodes)).padStart(6), 'cycles/node');
