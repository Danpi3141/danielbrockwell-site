'use strict';
// UCI front end for the reference engine, so chess tools can play it.
// Options: Nodes (node cap per move, default 6000 = 30 s at 200 positions a second),
// HashBits (TT size 2^bits entries), and the feature switches NullMove, LMR, Futility, CheckExt, PVS.
const { Engine, uciStr, parseUci } = require('./search.js');

const e = new Engine();
let nodes = 6000;
e.ttInit(9);
const rl = require('readline').createInterface({ input: process.stdin });
const out = s => process.stdout.write(s + '\n');

function setPosition(args) {
  let i = 0;
  if (args[0] === 'startpos') { e.setFen('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'); i = 1; }
  else if (args[0] === 'fen') { e.setFen(args.slice(1, 7).join(' ')); i = 7; }
  if (args[i] === 'moves') {
    for (const m of args.slice(i + 1)) {
      const mv = parseUci(e, m);
      if (!mv) { out('info string illegal move ' + m); return; }
      e.make(mv[0], mv[1]);
      e.ply = 0;                     // (game moves don't count as search plies)
    }
  }
  e.ply = 0;
}

rl.on('line', line => {
  const w = line.trim().split(/\s+/);
  switch (w[0]) {
    case 'uci':
      out('id name PsionChess-ref');
      out('id author Psion LZ64 chess project');
      out('option name Nodes type spin default 6000 min 100 max 10000000');
      out('option name HashBits type spin default 9 min 4 max 20');
      for (const [o, k] of [['NullMove', 'nullMove'], ['LMR', 'lmr'], ['Futility', 'futility'], ['CheckExt', 'checkExt'], ['PVS', 'pvs']]) out(`option name ${o} type check default ${e.opts[k]}`);
      out('uciok');
      break;
    case 'isready': out('readyok'); break;
    case 'setoption': {
      const name = w[2], val = w[4];
      if (name === 'Nodes') nodes = +val;
      else if (name === 'HashBits') e.ttInit(+val);
      else {
        const key = { NullMove: 'nullMove', LMR: 'lmr', Futility: 'futility', CheckExt: 'checkExt', PVS: 'pvs' }[name];
        if (key) e.opts[key] = val === 'true';
      }
      break;
    }
    case 'ucinewgame': e.ttInit(e.ttBits); break;
    case 'position': setPosition(w.slice(1)); break;
    case 'go': {
      let lim = nodes;
      const ni = w.indexOf('nodes');
      if (ni >= 0) lim = +w[ni + 1];
      const r = e.think(lim);
      if (!r) { out('bestmove 0000'); break; }
      out(`info depth ${r.depth} score cp ${r.score} nodes ${r.nodes}`);
      out('bestmove ' + uciStr(e, r.f, r.t));
      break;
    }
    case 'quit': process.exit(0);
  }
});
