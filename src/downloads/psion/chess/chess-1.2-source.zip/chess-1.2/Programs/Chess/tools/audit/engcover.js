'use strict';
// Engine coverage: which instructions of the engine (tests/engine/out/etest.lst, loaded at the
// harness's BASE) never ran in engine tests run under CHESS_COVER=<dir>.
//   CHESS_COVER=<dir> node tests/engine/t_api.js ...   (several tests)
//   node tools/audit/engcover.js <dir>
const fs = require('fs');
const path = require('path');
const ROOT = path.resolve(__dirname, '..', '..');
const OUT = path.join(ROOT, 'tests', 'engine', 'out');
const BASE = 0x3000;
const dir = process.argv[2];
const ran = new Set();
for (const f of fs.readdirSync(dir).filter((f) => /^cov_.*\.json$/.test(f))) {
  for (const pc of JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8')).pcs) ran.add(pc - BASE);
}
const sym = JSON.parse(fs.readFileSync(path.join(OUT, 'etest.json'), 'utf8')).sym;
const start = sym.eng_init, end = sym.think_poll;   // the engine, before the test drivers
const lines = fs.readFileSync(path.join(OUT, 'etest.lst'), 'utf8').split(/\r?\n/);
let routine = '', dead = [], codeBytes = 0, deadBytes = 0;
for (const l of lines) {
  const m = /^([0-9A-F]{4})  ([0-9A-F]*)\s+(.*)$/.exec(l);
  if (!m) continue;
  const off = parseInt(m[1], 16), nb = m[2].length / 2;
  if (off < start || off >= end || !nb) continue;
  let rest = m[3].replace(/;.*$/, '').trim();
  const lm = /^([A-Za-z_.$][\w.$]*):\s*(.*)$/.exec(rest);
  if (lm) { if (!lm[1].startsWith('.')) routine = lm[1]; rest = lm[2]; }
  const op = (rest.split(/\s+/)[0] || '').toLowerCase();
  if (!op || /^(fcb|fdb|fcc|rmb|db|dw)$/.test(op)) continue;
  codeBytes += nb;
  if (!ran.has(off)) { deadBytes += nb; dead.push(`${routine.padEnd(10)} ${m[1]} ${rest}`); }
}
console.log(`engine code ${codeBytes} bytes, never executed ${deadBytes} bytes:`);
for (const d of dead) console.log('  ' + d);
