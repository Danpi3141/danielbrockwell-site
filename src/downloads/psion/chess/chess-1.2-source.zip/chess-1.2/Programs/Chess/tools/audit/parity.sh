#!/bin/sh
# quick parity sweep after an engine change (assembler v JS): node tests in sequence
cd "$(dirname "$0")/../../tests/engine" || exit 1
for t in "t_perft.js 2" "t_perft2.js 2000" "t_api.js" "t_eval.js" "t_mirror.js 60" "t_search.js 600" "t_search.js 400 150" "t_fuzz.js 40 3" "t_fuzz.js 40 11" "t_rules.js 100"; do
  echo "== $t"; node $t 2>&1 | grep -v "^ok " | tail -6
done
