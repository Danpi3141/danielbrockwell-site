#!/bin/sh
# JS soak: self-play with mixed node limits and margins (and the level matches' games), then every
# game re-checked with python-chess (check_games.py): legal moves, correct game ends.
cd "$(dirname "$0")" || exit 1
W=${W:-5}
for spec in "N1 N2500" "N30M300 N600M30" "N5000 N800M70" "N150 N150M150" "N60M70 N3000"; do
  set -- $spec
  node match_levels.js soak_$1_$2 $1 $2 --workers $W | tail -1
done
python -E -P check_games.py "results/soak_*.jsonl" "results/lvg_*.jsonl" "results/lvh_*.jsonl"
