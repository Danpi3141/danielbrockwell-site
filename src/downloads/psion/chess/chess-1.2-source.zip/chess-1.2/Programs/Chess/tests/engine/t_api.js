'use strict';
// The UI-facing routines: eng_legal, eng_play, eng_check, eng_status, eng_setup refusals,
// checked against the JS reference over random games.
const { Harness } = require('./harness.js');
const { Engine, legalMoves, uciStr } = require('../../ref/search.js');

const h = new Harness();
const e = new Engine();
let bad = 0;
const fail = (m) => { bad++; console.log('FAIL', m); };

function asmLegal() {
  const n = h.call('eng_legal').b;
  const lm = h.bytes('e_lm', n * 2), out = [];
  for (let i = 0; i < n; i++) out.push(lm[i * 2] * 256 + lm[i * 2 + 1]);
  return out;                       // in its own order: the opening book stores moves as indices into it
}
function jsLegal() { return legalMoves(e).map(([f, t]) => f * 256 + t); }
function jsStatus() {
  const n = legalMoves(e).length;
  if (n === 0) return e.inCheck() ? 1 : 2;
  if (e.half >= 100) return 3;
  let c = 0;
  for (let i = e.keys.length - 2; i >= Math.max(0, e.keys.length - e.half); i -= 2) if ((e.keys[i] >>> 8) === (e.key >>> 8)) c++;
  if (c >= 2) return 4;
  if (e.insufficient()) return 5;
  return 0;
}

// random games
let rng = 12345;
const rnd = (n) => { rng = (rng * 1103515245 + 12345) & 0x7fffffff; return rng % n; };
let positions = 0;
for (let g = 0; g < 30; g++) {
  h.call('eng_reset'); e.setFen('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
  for (let ply = 0; ply < 160; ply++) {
    positions++;
    const a = asmLegal(), j = jsLegal();
    if (a.join() !== j.join()) { fail(`legal list differs game ${g} ply ${ply}`); break; }
    const chk = h.call('eng_check').a !== 0;
    if (chk !== e.inCheck()) fail(`check differs g${g} p${ply}`);
    const st = h.call('eng_status').a, js = jsStatus();
    if (st !== js) { fail(`status ${st} vs ${js} g${g} p${ply}`); break; }
    if (h.key() !== e.key) { fail(`key differs g${g} p${ply}`); break; }
    if (st) break;
    // an illegal move is refused
    if (h.hasMove(0x00, 0x77) !== j.includes(0x0077)) fail('a1h8 in the legal list differs');
    const pick = j[rnd(j.length)], f = pick >> 8, t = pick & 255;
    if (!h.hasMove(f, t)) fail(`not in the legal list: ${uciStr(e, f, t)}`);
    h.call('eng_play', f, t);
    e.make(f, t); e.ply = 0;
    // the game reference forgets history before irreversible moves, like the Psion
    if (e.half === 0) e.keys.length = 0;
  }
}
// set-up refusals
const r1 = h.setFen('8/8/8/8/8/8/8/K7 w - - 0 1');
if (!(r1.c && r1.a === 1)) fail('no black king accepted');
const r2 = h.setFen('k7/8/8/8/8/8/8/K6P w - - 0 1');
if (!(r2.c && r2.a === 2)) fail('pawn on rank 1 accepted');
const r3 = h.setFen('k7/8/8/8/8/8/8/R6K w - - 0 1');
if (!(r3.c && r3.a === 3)) fail('side not to move in check accepted');
const r4 = h.setFen('k7/8/8/8/8/8/8/K6R b - - 0 1');
if (r4.c) fail('legal set-up refused');
// threefold by knight shuffles
h.call('eng_reset'); e.setFen('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
const shuffle = [[0x06, 0x25], [0x76, 0x55], [0x25, 0x06], [0x55, 0x76]];
const seq = [...shuffle, ...shuffle];
seq.forEach(([f, t]) => h.call('eng_play', f, t));
if (h.call('eng_status').a !== 4) fail('threefold not seen');
console.log(`${positions} positions compared`);
console.log(bad ? `${bad} FAILED` : 'api ok');
process.exit(bad ? 1 : 0);
