"""Check 1: no terrible P moves. Every P move (a move the Psion may choose from book) is scored by
Stockfish 19 and compared with Stockfish's best in that position.

Screening: depth-22 evals of every tree position; a P move's score is minus the eval of the
position after it; best = the position's own eval (or a better book move). Moves losing >= 30 cp
in the screen are re-checked with restricted root searches at depth 26 (the move vs Stockfish's
depth-26 best); a move is flagged if it loses more than 50 cp there.
Only groups the Psion can reach with that colour (all its earlier moves are P moves) matter;
P moves in unreachable groups are counted separately.

    python -E -P tools/book/audit/check1_pmoves.py [--book data/book.bin] [--out result.json]
"""
import argparse
import json
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import chess  # noqa: E402
from common import Tree, SF, BOOK, CACHE, P, tree_evals, confirm, san_path, log  # noqa: E402

SCREEN = 30
FLAG = 50


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--book', default=BOOK)
    ap.add_argument('--out', default=os.path.join(CACHE, 'check1.json'))
    a = ap.parse_args()
    t = Tree(a.book)
    sf = SF()
    try:
        ev, _ = tree_evals(t, sf)
        rows = []
        n_reach = n_unreach = 0
        for g, mv in t.groups.items():
            b = t.board(g)
            reach = t.reach(g, b.turn)
            best = max([ev[g]] + [-ev[g + (u,)] for u, fl, r in mv])
            for u, fl, r in mv:
                if not fl & P:
                    continue
                if reach:
                    n_reach += 1
                else:
                    n_unreach += 1
                loss = best - (-ev[g + (u,)])
                rows.append({'path': list(g), 'move': u, 'reach': reach, 'screen': loss})
        cand = [r for r in rows if r['screen'] >= SCREEN]
        log('check1: %d P moves (%d reachable, %d not), %d over %d cp in the screen'
            % (len(rows), n_reach, n_unreach, len(cand), SCREEN))
        res = confirm(sf, [(t.board(r['path']).fen(), r['move']) for r in cand])
        for r, (bm, bcp, mine) in zip(cand, res):
            r['best26'], r['best_cp26'], r['cp26'], r['loss26'] = bm, bcp, mine, bcp - mine
    finally:
        sf.close()
    flagged = sorted([r for r in cand if r['loss26'] > FLAG], key=lambda r: -r['loss26'])
    hist = {}
    for r in rows:
        if r['reach']:
            k = '<10' if r['screen'] < 10 else '10-29' if r['screen'] < 30 else '30-49' if r['screen'] < 50 else '50-99' if r['screen'] < 100 else '>=100'
            hist[k] = hist.get(k, 0) + 1
    print('P moves: %d reachable by the Psion, %d in groups it cannot reach' % (n_reach, n_unreach))
    print('screen loss (depth 22, reachable):', ', '.join('%s cp: %d' % (k, hist.get(k, 0)) for k in ['<10', '10-29', '30-49', '50-99', '>=100']))
    print('confirmed at depth 26, loss > %d cp: %d reachable, %d unreachable'
          % (FLAG, sum(r['reach'] for r in flagged), sum(not r['reach'] for r in flagged)))
    for r in flagged[:25]:
        b = t.board(r['path'])
        print('  %4d cp  %-60s P %-6s  SF best %-6s (%s)' % (r['loss26'], san_path(r['path']) or '(start)',
              b.san(chess.Move.from_uci(r['move'])),
              b.san(chess.Move.from_uci(r['best26'])) if r['best26'] else '-', 'reachable' if r['reach'] else 'unreachable'))
    json.dump({'rows': rows, 'flagged': flagged}, open(a.out, 'w', encoding='utf-8'))
    return 1 if any(r['reach'] for r in flagged) else 0


if __name__ == '__main__':
    sys.exit(main())
