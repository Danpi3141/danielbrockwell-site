#!/bin/sh
# 17 Nov: the final engine (table cut-offs at every node except with a bare king; snap_m17f) v
# before the coverage sweep (snap_m17e), self-play, 2,484 games each
M="python -E -P match.py"
O="--opfile openings_big.txt --openings 0:1242 --workers 12"
$M f_L5 snap_m17f:Nodes=221 snap_m17e:Nodes=221 $O > logs_f_L5.txt 2>&1
$M f_L7 snap_m17f:Nodes=2214 snap_m17e:Nodes=2214 $O > logs_f_L7.txt 2>&1
$M f_L8 snap_m17f:Nodes=18800 snap_m17e:Nodes=18800 $O > logs_f_L8.txt 2>&1
python -E -P analyze.py f_L5 f_L7 f_L8 | grep -v histogram > logs_f_summary.txt 2>&1
echo done >> logs_f_summary.txt
