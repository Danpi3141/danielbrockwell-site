#!/bin/sh
# 17 Nov experiment: table cut-offs at every node (snap_ttall) v only at zero-window nodes (snap_m17e)
M="python -E -P match.py"
O="--opfile openings_big.txt --openings 0:1242 --workers 12"
$M ttall_L5 snap_ttall:Nodes=221 snap_m17e:Nodes=221 $O > logs_ttall_L5.txt 2>&1
$M ttall_L7 snap_ttall:Nodes=2214 snap_m17e:Nodes=2214 $O > logs_ttall_L7.txt 2>&1
$M ttall_L8 snap_ttall:Nodes=18800 snap_m17e:Nodes=18800 $O > logs_ttall_L8.txt 2>&1
python -E -P analyze.py ttall_L5 ttall_L7 ttall_L8 | grep -v histogram > logs_ttall_summary.txt 2>&1
echo done >> logs_ttall_summary.txt
