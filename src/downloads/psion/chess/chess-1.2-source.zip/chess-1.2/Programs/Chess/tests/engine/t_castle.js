'use strict';
// Castling and make/unmake (17 Nov, after the castling generator became one routine for both
// colours and the moving piece's totals became a difference update):
//  1. tests/engine/data/castle_oracle.json (tools/audit/gen_castle.py, python-chess): positions
//     built around castling. For each: the castling rights (as python-chess reports them, see
//     castleStr) and the legal moves = python-chess's; each castling move gives python-chess's
//     board, side and rights.
//  2. For every legal move there and in random games from the start: after e_make the kept state
//     (king squares, totals, phase, counts, pawn masks, key) equals a full recompute (e_recalc)
//     from the board, and e_unmake restores everything exactly.
//   node tests/engine/t_castle.js [games=40]
const fs = require('fs');
const path = require('path');
const { Harness } = require('./harness.js');
const { Engine, legalMoves, uciStr } = require('../../ref/search.js');

const GAMES = +(process.argv[2] || 40);
const h = new Harness();
const e = new Engine();
const O = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'castle_oracle.json'), 'utf8')).positions;
let bad = 0, made = 0, castles = 0;
const fail = (m) => { bad++; if (process.env.ALLFAIL || bad < 30) console.log("FAIL", m); };

const S0 = h.a('e_board'), SLEN = h.a('e_key') + 3 - S0;          // the position and all derived state
const D0 = h.a('e_ksq'), DLEN = h.a('e_key') + 3 - D0;            // the derived part
const BCOL = h.a('e_bcol');                                        // (e_insuf's scratch byte: ignored)
const snap = (a, n) => { const b = Array.from(h.m.read(a, n)); if (BCOL >= a && BCOL < a + n) b[BCOL - a] = 0; return b; };
const diff = (x, y, base) => { for (let i = 0; i < x.length; i++) if (x[i] !== y[i]) return `byte ${i} (${(base + i).toString(16)}): ${x[i]} v ${y[i]}`; return null; };

function asmLegal() {
  const n = h.call('eng_legal').b;
  const lm = h.bytes('e_lm', n * 2), out = [];
  for (let i = 0; i < n; i++) out.push([lm[i * 2], lm[i * 2 + 1]]);
  return out;
}
// the rights as python-chess reports them: a right without its king and rook at home is dropped.
// The engine keeps such a right as set (SET UP POSITION and pgn2psion.py never give one), but it
// can never be used: castling needs the king and rook there, and any move onto e1, a1, h1 (e8, a8,
// h8) clears the rights that go with the square. So only the reported rights are compared; the
// legal lists below (where stale rights are present in about 2,000 positions) must match exactly.
const castleStr = () => {
  const c = h.peek('e_castle'), b = h.bytes('e_board', 128);
  const ok = (k, r, piece) => b[k] === (6 | piece) && b[r] === (4 | piece);
  return ((c & 1 && ok(0x04, 0x07, 0) ? 'K' : '') + (c & 2 && ok(0x04, 0x00, 0) ? 'Q' : '') +
    (c & 4 && ok(0x74, 0x77, 8) ? 'k' : '') + (c & 8 && ok(0x74, 0x70, 8) ? 'q' : '')) || '-';
};
function boardFromFen(fen) {
  const b = new Array(128).fill(0);
  let r = 7, c = 0;
  for (const ch of fen.split(' ')[0]) {
    if (ch === '/') { r--; c = 0; continue; }
    if (ch >= '1' && ch <= '8') { c += +ch; continue; }
    b[r * 16 + c] = ('pnbrqk'.indexOf(ch.toLowerCase()) + 1) | (ch === ch.toLowerCase() ? 8 : 0);
    c++;
  }
  return b;
}
// make, compare with a recompute, unmake, compare with before; returns the board after the move
function checkMove(f, t, where) {
  const before = snap(S0, SLEN);
  h.call('e_ply0');
  h.call('e_make', f, t);
  made++;
  const inc = snap(D0, DLEN);
  const after = { board: Array.from(h.bytes('e_board', 128)), side: h.peek('e_side'), castle: castleStr() };
  h.call('e_recalc');
  const full = snap(D0, DLEN);
  const d1 = diff(inc, full, D0);
  if (d1) fail(`${where}: after ${f.toString(16)}-${t.toString(16)} the kept state differs from a recompute: ${d1}`);
  h.call('e_unmake');
  const d2 = diff(before, snap(S0, SLEN), S0);
  if (d2) fail(`${where}: unmake of ${f.toString(16)}-${t.toString(16)} does not restore: ${d2}`);
  return after;
}

// 1. the oracle positions
let pi = 0;
for (const p of O) {
  pi++;
  const r = h.setFen(p.fen);
  if (r.c) { fail(`#${pi} ${p.fen}: refused (${r.a})`); continue; }
  if (castleStr() !== p.rights) fail(`#${pi} ${p.fen}: rights ${castleStr()}, python-chess ${p.rights}`);
  e.setFen(p.fen); e.ply = 0;
  const lm = asmLegal();
  const got = lm.map(([f, t]) => uciStr(e, f, t)).sort();
  if (got.join() !== p.legal.join()) {
    const miss = p.legal.filter((u) => !got.includes(u)), extra = got.filter((u) => !p.legal.includes(u));
    fail(`#${pi} ${p.fen}: legal moves differ: missing ${miss.join(' ')} extra ${extra.join(' ')}`);
  }
  for (const [f, t] of lm) {
    const u = uciStr(e, f, t);
    const a = checkMove(f, t, `#${pi} ${p.fen}`);
    if (p.after[u]) {
      castles++;
      const want = p.after[u].split(' ');
      if (a.board.join() !== boardFromFen(p.after[u]).join()) fail(`#${pi} ${p.fen} ${u}: board after differs from python-chess ${p.after[u]}`);
      if (a.side !== (want[1] === 'b' ? 8 : 0)) fail(`#${pi} ${u}: side to move`);
      if (a.castle !== want[2]) fail(`#${pi} ${p.fen} ${u}: rights after ${a.castle}, python-chess ${want[2]}`);
    }
  }
}
const oracleMade = made;

// 2. random games from the start, every legal move checked at every ply
let rng = 4242;
const rnd = (n) => { rng = (rng * 1103515245 + 12345) & 0x7fffffff; return rng % n; };
let plies = 0;
for (let g = 0; g < GAMES; g++) {
  h.call('eng_reset'); e.setFen('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'); e.ply = 0;
  for (let ply = 0; ply < 200; ply++) {
    const lm = asmLegal();
    if (!lm.length || h.call('eng_status').a) break;
    for (const [f, t] of lm) checkMove(f, t, `game ${g} ply ${ply}`);
    // prefer castling, en passant and promotions when they are there, so they come up often
    const js = legalMoves(e);
    const special = js.filter(([f, t]) => { const p = e.b[f] & 7; return (p === 6 && Math.abs((t & 7) - (f & 7)) === 2) || (p === 1 && ((t & 0x70) === 0x70 || (t & 0x70) === 0 || (t & 0x77) === e.ep)); });
    const [f, t] = special.length && rnd(2) ? special[rnd(special.length)] : js[rnd(js.length)];
    h.call('eng_play', f, t);
    e.make(f, t); e.ply = 0; plies++;
    if (e.half === 0) e.keys.length = 0;
    if (h.key() !== e.key) { fail(`game ${g} ply ${ply}: key differs from the JS after ${uciStr(e, f, t)}`); break; }
  }
}
console.log(`${O.length} oracle positions: ${castles} castling moves checked against python-chess; ${oracleMade} moves made and unmade there`);
console.log(`${GAMES} random games, ${plies} plies: ${made - oracleMade} more moves made and unmade, each checked against a full recompute`);
if (bad) { console.log(bad + ' FAILED'); process.exit(1); }
console.log('castling and make/unmake ok');
