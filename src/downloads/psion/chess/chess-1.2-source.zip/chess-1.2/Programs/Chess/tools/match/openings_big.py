"""More balanced openings for tighter self-play matches (17 Nov) -> openings_big.txt:
openings.txt plus N more generated as in openings.py (other seeds; no repeated positions).
    python openings_big.py [N=1000] [workers=12]
match.py --opfile openings_big.txt uses them.
"""
import multiprocessing as mp
import os
import sys

import chess

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import openings  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))


def job(seed):
    return openings.generate(1000 // 12 + 20, seed=seed)


def epd(line):
    b = chess.Board()
    for u in line.split():
        b.push_uci(u)
    return b.epd()


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 1000
    w = int(sys.argv[2]) if len(sys.argv) > 2 else 12
    base = [l.strip() for l in open(os.path.join(HERE, 'openings.txt')) if l.strip()]
    seen = {epd(l) for l in base}
    extra = []
    with mp.Pool(w) as pool:
        for lst in pool.imap(job, [777 + 31 * i for i in range(w)]):
            for l in lst:
                k = epd(l)
                if k not in seen and len(extra) < n:
                    seen.add(k)
                    extra.append(l)
    with open(os.path.join(HERE, 'openings_big.txt'), 'w') as f:
        for l in base + extra:
            f.write(l + '\n')
    print(f'{len(base)} + {len(extra)} -> openings_big.txt')


if __name__ == '__main__':
    main()
