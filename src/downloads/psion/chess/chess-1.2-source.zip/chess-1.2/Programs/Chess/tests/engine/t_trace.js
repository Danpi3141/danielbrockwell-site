'use strict';
// Debug: node-by-node trace of the assembler search against the JS one; prints the first difference.
// Usage: node t_trace.js "<fen>" nodes
const { Harness } = require('./harness.js');
const { Engine, uciStr } = require('../../ref/search.js');
const fen = process.argv[2] || 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
const NODES = +(process.argv[3] || 600);

const h = new Harness();
const e = new Engine();
e.ttInit(8);
// JS trace
const jt = [];
const os = e.search.bind(e), oq = e.qsearch.bind(e);
const DUMP = +(process.argv[4] || -1);
function jdump() { const idx = e.key & 255; console.log('JS tt', idx, e.ttKey[idx].toString(16), e.ttF[idx].toString(16), e.ttT[idx].toString(16), e.ttS[idx], e.ttD[idx], e.ttFlag[idx]); const n = e.mvTop[1]; const o = []; for (let i = 0; i < n; i++) o.push(e.mv[i*3].toString(16)+'-'+e.mv[i*3+1].toString(16)+':'+e.mv[i*3+2]); console.log('JS ply0 list', o.join(' ')); }
e.search = function (d, a, b, ply, n) { if (jt.length === DUMP) jdump(); jt.push(`S p${ply} d${d} a${a} b${b} k${this.key.toString(16)} n${n ? 1 : 0} r${this.hist[0] ? this.hist[0].f.toString(16)+'-'+this.hist[0].t.toString(16) : ''}`); return os(d, a, b, ply, n); };
e.qsearch = function (a, b, ply) { jt.push(`Q p${ply} a${a} b${b} k${this.key.toString(16)}`); return oq(a, b, ply); };
e.setFen(fen); e.rnd = 0x1234;
e.think(NODES, 40, 0);

h.setFen(fen); h.call('e_clrtt'); h.pokew('e_rnd', 0x1234);
h.m.write(h.a('e_nlim'), [(NODES >> 16) & 255, (NODES >> 8) & 255, NODES & 255]);
h.pokew('e_tlim', 0); h.poke('e_maxd', 0); h.pokew('e_margin', 0);
const m = h.m, d = m.dbg;
const S = h.a('e_search'), Q = h.a('e_qs');
const at = [];
const sw = (v) => (v & 0x8000 ? v - 0x10000 : v);
const fr = () => m.peekw(h.a('e_fp'));
d.setBp(S); d.setBp(Q);
// start the call by hand
m.poke(0x7D, 255);
d.setSP(h.stack); d.setX(h.a('eng_think')); d.setPC(0x6FE0); d.wake();
for (;;) {
  const hit = m.run(921600 * 600);
  if (hit === 0x6FE3) break;
  if (hit !== S && hit !== Q) { console.log('stopped at', hit.toString(16)); break; }
  const f = fr(), ply = h.peek('e_ply');
  const key = (h.bytes('e_key', 3).reduce((a, b) => a * 256 + b, 0)).toString(16);
  if (at.length === DUMP) { const k = h.bytes('e_key', 3); const idx = k[2]; console.log('AS tt', idx, m.read(0x7000 + idx * 7, 7).map(v => v.toString(16)).join(' ')); }
  if (at.length === DUMP) { const s0 = h.a('e_mvs'), s1 = m.peekw(h.a('e_mvtop') + 2); const o = []; for (let a = s0; a < s1; a += 3) o.push(m.peek(a).toString(16)+'-'+m.peek(a+1).toString(16)+':'+m.peek(a+2)); console.log('AS ply0 list', o.join(' ')); const f0 = h.a('e_frames'); console.log('mvs', s0.toString(16), 'mvtop1', s1.toString(16), 'F_I', m.peekw(f0+37).toString(16), 'F_END', m.peekw(f0+39).toString(16), 'e_pend', m.peekw(h.a('e_pend')).toString(16)); }
  if (hit === S) { let dep = m.peek(f + 22); if (dep & 128) dep -= 256; const f0 = h.a('e_frames'); at.push(`S p${ply} d${dep} a${sw(m.peekw(f + 23))} b${sw(m.peekw(f + 25))} k${key} n${m.peek(f + 27) ? 1 : 0} r${ply ? m.peek(f0).toString(16)+'-'+m.peek(f0+1).toString(16) : ''}`); }
  else at.push(`Q p${ply} a${sw(m.peekw(f + 23))} b${sw(m.peekw(f + 25))} k${key}`);
  if (at.length > jt.length + 5) break;
}
d.clearBps();
let i = 0;
while (i < jt.length && i < at.length && jt[i] === at[i]) i++;
console.log(`js ${jt.length} entries, asm ${at.length}; first difference at ${i}`);
jt.forEach((x, k) => { if (x.includes(process.env.FINDK || "zzzz")) console.log("JS has key at", k, x); });
for (let k = Math.max(0, i - 6); k < i + 3; k++) console.log(k, 'js ', jt[k], '\n   asm', at[k]);
