"""Independent check of self-play games (tools/audit/results/*.jsonl from match_levels.js / soak.js)
with python-chess: every move legal, the game ended exactly when the rules say (no move played
after an end, no end claimed early) and for the reason given.
    python -E -P tools/audit/check_games.py results/soak_*.jsonl ...
Rules as the engine applies them: mate, stalemate, 100 half-moves, threefold repetition (python-chess
is_repetition), too little material = no pawns, rooks or queens and at most one minor in all.
Positions python-chess calls insufficient but the engine plays on (e.g. bishops of one colour) are
counted separately ('dead positions played on'); that is a known engine simplification."""
import glob, json, sys
import chess

REASON = {1: 'checkmate', 2: 'stalemate', 3: 'fifty', 4: 'threefold', 5: 'insufficient'}


def eng_insuf(b):
    if b.pawns or b.rooks or b.queens:
        return False
    return chess.popcount(b.knights | b.bishops) <= 1


def status(b):
    if not any(True for _ in b.legal_moves):
        return 1 if b.is_check() else 2
    if b.halfmove_clock >= 100:
        return 3
    if b.is_repetition(3):
        return 4
    if eng_insuf(b):
        return 5
    return 0


def main(paths):
    files = [p for a in paths for p in glob.glob(a)]
    games = moves = bad = dead = errors = 0
    ends = {}
    for path in files:
        with open(path, encoding='utf-8') as f:
            for line in f:
                if not line.strip():
                    continue
                g = json.loads(line)
                games += 1
                if g.get('error'):
                    errors += 1
                    print('ERROR in game', path, g['opening'], g['error'][:300])
                b = chess.Board()
                ok = True
                ms = g['moves'].split()
                for i, u in enumerate(ms):
                    st = status(b)
                    if st:
                        print('PLAYED ON after %s: %s game %s ply %d' % (REASON[st], path, g['opening'], i))
                        ok = False
                        break
                    if b.is_insufficient_material():
                        dead += 1
                    m = chess.Move.from_uci(u)
                    if m not in b.legal_moves:
                        print('ILLEGAL %s in %s game %s ply %d: %s' % (u, path, g['opening'], i, b.fen()))
                        ok = False
                        break
                    b.push(m)
                    moves += 1
                if ok and not g.get('error'):
                    st = status(b)
                    want = REASON.get(st, 'maxply')
                    if want != g['reason']:
                        print('END %s, python says %s: %s game %s %s' % (g['reason'], want, path, g['opening'], b.fen()))
                        ok = False
                    res = b.outcome(claim_draw=True)
                    if st == 1 and g['result'] != ('1-0' if b.turn == chess.BLACK else '0-1'):
                        print('RESULT wrong', path, g['opening'])
                        ok = False
                ends[g['reason']] = ends.get(g['reason'], 0) + 1
                if not ok:
                    bad += 1
    print('%d games, %d moves checked with python-chess: %d bad, %d engine errors; ends %s; '
          'dead positions played on (python-chess insufficient, engine not): %d positions'
          % (games, moves, bad, errors, json.dumps(ends), dead))
    return 1 if bad or errors else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
