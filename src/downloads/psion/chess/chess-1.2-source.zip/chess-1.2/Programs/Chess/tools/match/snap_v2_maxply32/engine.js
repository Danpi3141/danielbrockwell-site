'use strict';
// Reference chess engine for the Psion LZ64 chess game.
// Written to mirror the 6303 assembler engine exactly: same board layout, same move order,
// same 16-bit integer evaluation, same search. Node counts must match the assembler's.
//
// Board: 0x88, 128 bytes. Piece byte: type 1..6 (P N B R Q K) | 8 for Black. Empty = 0.
// Move: from (0x88) and to (0x88). Spare bits of `to`: bits 7,3 = underpromotion (0 Q, 1 R, 2 B, 3 N)
//   coded as promo code c -> to | ((c&1)<<3) | ((c&2)<<6).

const P = 1, N = 2, B = 3, R = 4, Q = 5, K = 6, BLACK = 8;
const INF = 32000, MATE = 30000, MATE_BOUND = 29000;
const MAXPLY = 32;
const MVCAP = 180;            // a node with more than this many moves stacked below it is a leaf (assembler: 400-move stack)

const NDIR = [-33, -31, -18, -14, 14, 18, 31, 33];
const BDIR = [-17, -15, 15, 17];
const RDIR = [-16, -1, 1, 16];
const KDIR = [-17, -16, -15, -1, 1, 15, 16, 17];

// ---------- tables (shared with the assembler build: tables.js writes them out) ----------
const T = require('./tables.js');
const VAL_MG = T.VAL_MG, VAL_EG = T.VAL_EG; // index by type 1..6
const PST_MG = T.PST_MG, PST_EG = T.PST_EG;   // [type][sq64 from White's side], signed bytes
const PHASE_W = [0, 0, 1, 1, 2, 4, 0];
const PH16 = T.PH16;                          // 0..24 -> 0..16
const ZOB = T.ZOB;                            // Uint32Array: 12*64 pieces, then side, castle[4], epfile[8]
const ZSIDE = 768, ZCASTLE = 769, ZEP = 773;

function sq64(s) { return (s + (s & 7)) >> 1; }
function zpiece(pc, s) { return ZOB[(((pc & 8) ? 6 : 0) + (pc & 7) - 1) * 64 + sq64(s)]; }

const CASTLE_MASK = new Uint8Array(128).fill(15);
CASTLE_MASK[0x00] = 15 & ~2; CASTLE_MASK[0x04] = 15 & ~3; CASTLE_MASK[0x07] = 15 & ~1;
CASTLE_MASK[0x70] = 15 & ~8; CASTLE_MASK[0x74] = 15 & ~12; CASTLE_MASK[0x77] = 15 & ~4;

class Engine {
  constructor() {
    this.b = new Uint8Array(128);
    this.mv = new Uint8Array(4096 * 3);   // move stack: from,to,score
    this.mvTop = new Int32Array(MAXPLY + 2);
    this.killer = new Uint8Array(MAXPLY * 4);
    this.hist = [];                       // undo records
    this.keys = [];                       // key history (game + search) for repetition
    this.ttBits = 9;                      // 512 entries
    this.opts = { nullMove: true, lmr: true, futility: true, checkExt: true, pvs: true };
    this.setFen('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
  }

  // ---------------- position ----------------
  setFen(fen) {
    const f = fen.trim().split(/\s+/);
    this.b.fill(0);
    let r = 7, c = 0;
    for (const ch of f[0]) {
      if (ch === '/') { r--; c = 0; continue; }
      if (ch >= '1' && ch <= '8') { c += +ch; continue; }
      const t = 'pnbrqk'.indexOf(ch.toLowerCase()) + 1;
      this.b[r * 16 + c] = t | (ch === ch.toLowerCase() ? BLACK : 0);
      c++;
    }
    this.side = f[1] === 'b' ? BLACK : 0;
    this.castle = 0;
    const cs = f[2] || '-';
    if (cs.includes('K')) this.castle |= 1;
    if (cs.includes('Q')) this.castle |= 2;
    if (cs.includes('k')) this.castle |= 4;
    if (cs.includes('q')) this.castle |= 8;
    this.ep = 0xFF;
    if (f[3] && f[3] !== '-') this.ep = (f[3].charCodeAt(1) - 49) * 16 + (f[3].charCodeAt(0) - 97);
    this.half = +(f[4] || 0);
    this.fullmove = +(f[5] || 1);
    this.recompute();
    this.hist.length = 0;
    this.keys.length = 0;
    this.ply = 0;
  }

  recompute() {
    this.mg = [0, 0]; this.eg = [0, 0]; this.phase = 0;
    this.cnt = new Uint8Array(16);         // [color*8 + type] piece counts
    this.pm = new Uint8Array(16);          // pawn rank masks [color*8 + file], bit = rank
    this.ksq = [0, 0];
    this.key = 0;
    for (let s = 0; s < 128; s++) {
      if (s & 0x88) { s += 7; continue; }
      const pc = this.b[s];
      if (!pc) continue;
      this.addPiece(pc, s);
    }
    if (this.side) this.key ^= ZOB[ZSIDE];
    for (let i = 0; i < 4; i++) if (this.castle & (1 << i)) this.key ^= ZOB[ZCASTLE + i];
    if (this.ep !== 0xFF) this.key ^= ZOB[ZEP + (this.ep & 7)];
    this.key >>>= 0;
  }

  addPiece(pc, s) {
    const col = pc >> 3, t = pc & 7, s6 = sq64(s) ^ (col ? 56 : 0);
    this.mg[col] += VAL_MG[t] + PST_MG[t][s6];
    this.eg[col] += VAL_EG[t] + PST_EG[t][s6];
    this.phase += PHASE_W[t];
    this.cnt[col * 8 + t]++;
    if (t === P) this.pm[col * 8 + (s & 7)] |= 1 << (s >> 4);
    if (t === K) this.ksq[col] = s;
    this.key = (this.key ^ zpiece(pc, s)) >>> 0;
  }
  remPiece(pc, s) {
    const col = pc >> 3, t = pc & 7, s6 = sq64(s) ^ (col ? 56 : 0);
    this.mg[col] -= VAL_MG[t] + PST_MG[t][s6];
    this.eg[col] -= VAL_EG[t] + PST_EG[t][s6];
    this.phase -= PHASE_W[t];
    this.cnt[col * 8 + t]--;
    if (t === P) this.pm[col * 8 + (s & 7)] &= ~(1 << (s >> 4));
    this.key = (this.key ^ zpiece(pc, s)) >>> 0;
  }

  // Is square s attacked by colour `by` (0 or 8)?
  attacked(s, by) {
    const b = this.b;
    // pawns
    if (by === 0) {
      let t = s - 15; if (!(t & 0x88) && b[t] === P) return true;
      t = s - 17; if (!(t & 0x88) && b[t] === P) return true;
    } else {
      let t = s + 15; if (!(t & 0x88) && b[t] === (P | BLACK)) return true;
      t = s + 17; if (!(t & 0x88) && b[t] === (P | BLACK)) return true;
    }
    for (let i = 0; i < 8; i++) {
      const t = s + NDIR[i];
      if (!(t & 0x88) && b[t] === (N | by)) return true;
    }
    for (let i = 0; i < 8; i++) {
      const t = s + KDIR[i];
      if (!(t & 0x88) && b[t] === (K | by)) return true;
    }
    for (let i = 0; i < 4; i++) {
      const d = BDIR[i];
      let t = s + d;
      while (!(t & 0x88)) {
        const pc = b[t];
        if (pc) { if (pc === (B | by) || pc === (Q | by)) return true; break; }
        t += d;
      }
    }
    for (let i = 0; i < 4; i++) {
      const d = RDIR[i];
      let t = s + d;
      while (!(t & 0x88)) {
        const pc = b[t];
        if (pc) { if (pc === (R | by) || pc === (Q | by)) return true; break; }
        t += d;
      }
    }
    return false;
  }

  inCheck() { return this.attacked(this.ksq[this.side >> 3], this.side ^ BLACK); }

  // ---------------- move generation ----------------
  // Appends moves at this.mvTop[ply]..; returns count. capsOnly: captures and promotions only.
  // Each move gets an ordering score (0..255) computed here, as the assembler does.
  gen(ply, capsOnly) {
    const b = this.b, us = this.side, them = us ^ BLACK;
    let n = this.mvTop[ply] * 3;
    const start = n;
    const mv = this.mv;
    const k1 = this.killer[ply * 4], k1t = this.killer[ply * 4 + 1];
    const k2 = this.killer[ply * 4 + 2], k2t = this.killer[ply * 4 + 3];
    const add = (f, t, score) => { mv[n] = f; mv[n + 1] = t; mv[n + 2] = score; n += 3; };
    const quiet = (f, t, pc) => {
      if (f === k1 && t === k1t) return add(f, t, 150);
      if (f === k2 && t === k2t) return add(f, t, 149);
      const typ = pc & 7, flip = us ? 56 : 0;
      const d = PST_MG[typ][sq64(t) ^ flip] - PST_MG[typ][sq64(f) ^ flip];
      add(f, t, 64 + (d >> 2));
    };
    const cap = (f, t, pc, victim) => add(f, t, 160 + (victim & 7) * 8 - (pc & 7));
    for (let s = 0; s < 128; s++) {
      if (s & 0x88) { s += 7; continue; }
      const pc = b[s];
      if (!pc || (pc & 8) !== us) continue;
      const typ = pc & 7;
      if (typ === P) {
        const fwd = us ? -16 : 16;
        const lastRank = us ? 0 : 7;
        const t = s + fwd;
        const promo = (t >> 4) === lastRank;
        // captures (left then right, from White's point of view: -1 then +1)
        for (const dc of [-1, 1]) {
          const c = t + dc;
          if (c & 0x88) continue;
          const v = b[c];
          if (v && (v & 8) === them) {
            if (promo) { this.addPromos(add, s, c, 1, v); } else cap(s, c, pc, v);
          } else if (c === this.ep) {
            add(s, c, 160 + 8 - 1);
          }
        }
        if (!b[t]) {
          if (promo) this.addPromos(add, s, t, 0, 0);
          else if (!capsOnly) {
            quiet(s, t, pc);
            const startRank = us ? 6 : 1;
            if ((s >> 4) === startRank && !b[t + fwd]) quiet(s, t + fwd, pc);
          }
        }
        continue;
      }
      if (typ === N || typ === K) {
        const dirs = typ === N ? NDIR : KDIR;
        for (let i = 0; i < 8; i++) {
          const t = s + dirs[i];
          if (t & 0x88) continue;
          const v = b[t];
          if (!v) { if (!capsOnly) quiet(s, t, pc); }
          else if ((v & 8) === them) cap(s, t, pc, v);
        }
        if (typ === K && !capsOnly) this.genCastle(s, quiet, pc);
        continue;
      }
      // sliders
      const dirs = typ === B ? BDIR : typ === R ? RDIR : KDIR;
      const nd = dirs.length;
      for (let i = 0; i < nd; i++) {
        const d = dirs[i];
        let t = s + d;
        while (!(t & 0x88)) {
          const v = b[t];
          if (!v) { if (!capsOnly) quiet(s, t, pc); }
          else { if ((v & 8) === them) cap(s, t, pc, v); break; }
          t += d;
        }
      }
    }
    return (n - start) / 3;
  }

  addPromos(add, f, t, isCap, victim) {
    // queen first, then knight, rook, bishop
    add(f, t, 210 + (victim & 7));                       // Q
    add(f, t | (3 & 1) << 3 | (3 & 2) << 6, 120);        // N
    add(f, t | (1 & 1) << 3 | (1 & 2) << 6, 20);         // R
    add(f, t | (2 & 1) << 3 | (2 & 2) << 6, 19);         // B
  }

  genCastle(s, quiet, pc) {
    const b = this.b, us = this.side;
    if (us === 0) {
      if (s !== 0x04) return;
      if ((this.castle & 1) && !b[0x05] && !b[0x06] && b[0x07] === R &&
        !this.attacked(0x04, BLACK) && !this.attacked(0x05, BLACK)) quiet(0x04, 0x06, pc);
      if ((this.castle & 2) && !b[0x03] && !b[0x02] && !b[0x01] && b[0x00] === R &&
        !this.attacked(0x04, BLACK) && !this.attacked(0x03, BLACK)) quiet(0x04, 0x02, pc);
    } else {
      if (s !== 0x74) return;
      if ((this.castle & 4) && !b[0x75] && !b[0x76] && b[0x77] === (R | BLACK) &&
        !this.attacked(0x74, 0) && !this.attacked(0x75, 0)) quiet(0x74, 0x76, pc);
      if ((this.castle & 8) && !b[0x73] && !b[0x72] && !b[0x71] && b[0x70] === (R | BLACK) &&
        !this.attacked(0x74, 0) && !this.attacked(0x73, 0)) quiet(0x74, 0x72, pc);
    }
  }

  // ---------------- make / unmake ----------------
  // Returns false (and leaves the move made) if it leaves the mover's king attacked.
  make(f, tc) {
    const b = this.b, t = tc & 0x77, us = this.side;
    const pc = b[f], cap = b[t];
    const u = {
      f, t: tc, cap, castle: this.castle, ep: this.ep, half: this.half, key: this.key,
      mg0: this.mg[0], mg1: this.mg[1], eg0: this.eg[0], eg1: this.eg[1], phase: this.phase, epcap: 0
    };
    this.hist.push(u);
    this.keys.push(this.key);
    if (this.ep !== 0xFF) this.key = (this.key ^ ZOB[ZEP + (this.ep & 7)]) >>> 0;
    this.ep = 0xFF;
    this.half++;
    if (cap) { this.remPiece(cap, t); this.half = 0; }
    this.remPiece(pc, f);
    b[f] = 0;
    let np = pc;
    if ((pc & 7) === P) {
      this.half = 0;
      if ((t >> 4) === 7 || (t >> 4) === 0) {
        const code = ((tc >> 3) & 1) | ((tc >> 6) & 2);
        np = [Q, R, B, N][code] | us;
      } else if (t === u.ep && !cap) {
        const cs = us ? t + 16 : t - 16;
        u.epcap = b[cs];
        this.remPiece(b[cs], cs);
        b[cs] = 0;
      } else if (t - f === 32 || f - t === 32) {
        this.ep = (f + t) >> 1;
        this.key = (this.key ^ ZOB[ZEP + (this.ep & 7)]) >>> 0;
      }
    } else if ((pc & 7) === K && (t - f === 2 || f - t === 2)) {
      const rf = t > f ? f + 3 : f - 4, rt = t > f ? f + 1 : f - 1;
      const rk = b[rf];
      this.remPiece(rk, rf); b[rf] = 0;
      b[rt] = rk; this.addPiece(rk, rt);
    }
    b[t] = np;
    this.addPiece(np, t);
    u.pc = pc; u.np = np;
    const nc = this.castle & CASTLE_MASK[f] & CASTLE_MASK[t];
    if (nc !== this.castle) {
      for (let i = 0; i < 4; i++) if ((nc ^ this.castle) & (1 << i)) this.key ^= ZOB[ZCASTLE + i];
      this.key >>>= 0;
      this.castle = nc;
    }
    this.side ^= BLACK;
    this.key = (this.key ^ ZOB[ZSIDE]) >>> 0;
    this.ply++;
    return !this.attacked(this.ksq[us >> 3], us ^ BLACK);
  }

  unmake() {
    const u = this.hist.pop();
    this.keys.pop();
    this.ply--;
    this.side ^= BLACK;
    const b = this.b, us = this.side, t = u.t & 0x77, f = u.f;
    const pc = u.pc;                      // the piece that moved (a pawn for promotions)
    b[f] = pc;
    b[t] = u.cap;
    if (pc === (K | us)) {
      this.ksq[us >> 3] = f;
      if (t - f === 2 || f - t === 2) {
        const rf = t > f ? f + 3 : f - 4, rt = t > f ? f + 1 : f - 1;
        b[rf] = b[rt]; b[rt] = 0;
      }
    }
    if (u.epcap) { const cs = us ? t + 16 : t - 16; b[cs] = u.epcap; }
    // counts and masks: recompute incrementally by reversing (simple: re-derive from saved state)
    this.undoCounts(u, pc, us);
    this.castle = u.castle; this.ep = u.ep; this.half = u.half; this.key = u.key;
    this.mg[0] = u.mg0; this.mg[1] = u.mg1; this.eg[0] = u.eg0; this.eg[1] = u.eg1; this.phase = u.phase;
  }
  undoCounts(u, pc, us) {
    const t = u.t & 0x77, f = u.f, col = us >> 3;
    const np = u.np;
    // moved piece: remove from t (as np), add at f (as pc)
    this.cnt[col * 8 + (np & 7)]--; this.cnt[col * 8 + (pc & 7)]++;
    if ((np & 7) === P) this.pm[col * 8 + (t & 7)] &= ~(1 << (t >> 4));
    if ((pc & 7) === P) this.pm[col * 8 + (f & 7)] |= 1 << (f >> 4);
    if (u.cap) {
      const cc = u.cap >> 3;
      this.cnt[cc * 8 + (u.cap & 7)]++;
      if ((u.cap & 7) === P) this.pm[cc * 8 + (t & 7)] |= 1 << (t >> 4);
    }
    if (u.epcap) {
      const cs = us ? t + 16 : t - 16, cc = u.epcap >> 3;
      this.cnt[cc * 8 + P]++;
      this.pm[cc * 8 + (cs & 7)] |= 1 << (cs >> 4);
    }
  }

  // Null move: only side, ep and key change.
  makeNull() {
    this.hist.push({ ep: this.ep, key: this.key, half: this.half, nul: true });
    this.keys.push(this.key);
    if (this.ep !== 0xFF) this.key = (this.key ^ ZOB[ZEP + (this.ep & 7)]) >>> 0;
    this.ep = 0xFF;
    this.side ^= BLACK;
    this.key = (this.key ^ ZOB[ZSIDE]) >>> 0;
    this.half++;
    this.ply++;
  }
  unmakeNull() {
    const u = this.hist.pop();
    this.keys.pop();
    this.ply--;
    this.side ^= BLACK;
    this.ep = u.ep; this.key = u.key; this.half = u.half;
  }
}

module.exports = { Engine, P, N, B, R, Q, K, BLACK, INF, MATE, MATE_BOUND, MAXPLY, MVCAP, sq64, NDIR, BDIR, RDIR, KDIR };
