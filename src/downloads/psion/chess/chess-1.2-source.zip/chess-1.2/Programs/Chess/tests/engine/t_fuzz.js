'use strict';
// Search parity on random positions: random games, random node limits, sometimes a margin.
// Usage: node t_fuzz.js [cases] [seed]
const { Harness } = require('./harness.js');
const { Engine, legalMoves, uciStr } = require('../../ref/search.js');

const CASES = +(process.argv[2] || 40), SEED = +(process.argv[3] || 1);
const h = new Harness();
const e = new Engine();
let rng = SEED * 7919 + 13;
const rnd = (k) => { rng = (rng * 1103515245 + 12345) & 0x7fffffff; return rng % k; };
let bad = 0, done = 0;
const START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
while (done < CASES) {
  // a random game of 4..80 plies, preferring captures sometimes so endgames appear
  h.call('eng_reset'); e.setFen(START);
  const plies = 4 + rnd(77);
  let over = false;
  for (let p = 0; p < plies; p++) {
    const ms = legalMoves(e);
    if (!ms.length) { over = true; break; }
    const caps = ms.filter(([f, t]) => e.b[t & 0x77]);
    const pool = caps.length && rnd(2) ? caps : ms;
    const [f, t] = pool[rnd(pool.length)];
    h.call('eng_play', f, t); e.make(f, t); e.ply = 0;
    if (e.half === 0) e.keys.length = 0;
  }
  if (over || !legalMoves(e).length) continue;
  const nodes = 100 + rnd(1400), margin = rnd(4) === 0 ? [30, 70, 150, 300][rnd(4)] : 0, seed = 1 + rnd(60000);
  h.call('e_clrtt'); e.ttInit(8);
  h.pokew('e_rnd', seed); e.rnd = seed;
  h.m.write(h.a('e_nlim'), [(nodes >> 16) & 255, (nodes >> 8) & 255, nodes & 255]);
  h.pokew('e_tlim', 0); h.poke('e_maxd', 0); h.pokew('e_margin', margin);
  h.call('eng_think', 0, 0, 921600 * 3600);
  const af = h.peek('e_bestf'), at = h.peek('e_bestt'), as = h.sw('e_score'), ad = h.peek('e_depth');
  const nb = h.bytes('e_nodes', 3), an = (nb[0] << 16) | (nb[1] << 8) | nb[2];
  const j = e.think(nodes, 40, margin);
  const ok = j && af === j.f && at === j.t && as === j.score && ad === j.depth && an === j.nodes;
  done++;
  if (!ok) {
    bad++;
    console.log(`FAIL case ${done}: nodes ${nodes} margin ${margin} seed ${seed} asm ${uciStr(e, af, at)} ${as} d${ad} n${an} js ${j ? uciStr(e, j.f, j.t) + ' ' + j.score + ' d' + j.depth + ' n' + j.nodes : '-'}`);
    console.log('   moves to reach it: replay with the same seed');
  }
}
console.log(`${done} random positions`);
console.log(bad ? `${bad} FAILED` : 'fuzz ok');
process.exit(bad ? 1 : 0);
