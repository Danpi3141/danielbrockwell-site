'use strict';
// Take back across special moves (audit check 1).
//   node tests/ui/t_back.js [--quick]
// Every crafted game of gen_games.py (castling both ways for both colours, en passant both
// colours, promotions and under-promotions with and without capture, checks, mate, stalemate,
// repetition, set-up positions) is played through the keys in two-player mode. After each ply
// the engine's position (FEN) is compared with python-chess, and the whole persistent engine
// state (board, side, castling, en passant, half-move clock, king squares, material and PST
// sums, piece counts, pawn masks, the position key, the key history), the record (g_n, the
// last ply), the result and the screen are kept. Then every ply is taken back with DEL, one
// at a time (from the result screen where the game ended), and each state must equal the one
// kept when that position was first reached. Then the same against the computer (DEL takes
// back two plies, and the menu's TAKE BACK), and with a clock, whose times must come back too.
const L = require('./lib.js');
const G = require('./glib.js');
const { check, keys } = L;
const quick = process.argv.includes('--quick');

let fails = 0, compared = 0;
function soft(cond, msg) { if (!cond) { fails++; console.log('FAIL ' + msg); } return cond; }
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
function diff(a, b) {
  const out = [];
  for (const k of Object.keys(a)) if (!same(a[k], b[k])) out.push(k + ': ' + JSON.stringify(a[k]).slice(0, 80) + ' vs ' + JSON.stringify(b[k]).slice(0, 80));
  return out.join('; ');
}
const fenCore = (f) => f.split(' ').slice(0, 5).join(' ');

const games = G.games('crafted', ['--crafted']);
let m = G.start();
G.twoPlayers(m);
for (const g of games) {
  if (quick && !/castle|passant|promotion|stalemate|repetition|three queens/.test(g.name)) continue;
  if (g.start) G.setupFen(m, g.start);
  else { G.menu(m, ['N']); G.waitInput(m, 10); }
  const snaps = [{ st: G.engState(m), scr: m.screenText(), fen: G.engFen(m) }];
  if (g.start) soft(fenCore(snaps[0].fen) === fenCore(g.start), g.name + ': set-up position ' + snaps[0].fen + ' vs ' + g.start);
  let ok = true;
  for (let i = 0; i < g.plies.length; i++) {
    const p = g.plies[i];
    G.typeUci(m, p.uci);
    G.waitInput(m, 20);
    const st = G.engState(m);
    if (!soft(st.g_n === snaps[0].st.g_n + i + 1, g.name + ': ply ' + (i + 1) + ' ' + p.uci + ' was not played\n' + m.screenText())) { ok = false; break; }
    const ef = G.engFen(m);
    soft(G.fenMatch(ef, p), g.name + ': after ' + p.san + ' engine ' + ef + ' vs python ' + p.fen);
    snaps.push({ st, scr: m.screenText(), fen: ef });
  }
  if (!ok) { m = G.start(); G.twoPlayers(m); continue; }
  const last = g.plies[g.plies.length - 1];
  if (last.status) {
    soft(snaps[snaps.length - 1].st.result !== 0, g.name + ': the game ended (' + last.status + ')');
    keys(m, ['EXE']); G.waitInput(m, 5);        // the result screen: look at the board
  }
  // take every ply back, one at a time
  for (let k = g.plies.length - 1; k >= 0; k--) {
    keys(m, ['DEL']);
    G.waitInput(m, 30);
    const st = G.engState(m), want = snaps[k];
    compared++;
    soft(same(st, want.st), g.name + ': take back to ply ' + k + ' state differs: ' + diff(st, want.st));
    soft(m.screenText() === want.scr, g.name + ': take back to ply ' + k + ' screen differs\n' + m.screenText() + '\nvs\n' + want.scr);
  }
  console.log('ok   ' + g.name + ': ' + g.plies.length + ' plies played and taken back' + (last.status ? ' (ended: ' + last.status + ')' : ''));
}

// ---- against the computer: DEL takes back the move and the reply; the menu's TAKE BACK
G.menu(m, ['N']); G.waitInput(m, 10);         // (a new game first: the computer would move at once in a set-up position)
G.setting(m, G.SET.TWO, ['LEFT']);
G.setting(m, G.SET.LEVEL, ['LEFT', 'LEFT', 'LEFT', 'LEFT', 'LEFT', 'LEFT']);    // level 1
G.menu(m, ['N']); G.waitInput(m, 10);
const s0 = { st: G.engState(m), scr: m.screenText() };
const seq = [s0];
for (const u of ['e2e4', 'd2d4', 'g1f3']) {
  G.typeUci(m, u);
  G.waitPly(m, seq.length * 2);
  seq.push({ st: G.engState(m), scr: m.screenText() });
}
check(seq[3].st.g_n === 6, 'against the computer: three moves and three replies', m);
keys(m, ['DEL']); G.waitInput(m, 30);
soft(same(G.engState(m), seq[2].st), 'DEL against the computer: back two plies: ' + diff(G.engState(m), seq[2].st));
G.menu(m, ['T']); G.waitInput(m, 30);
soft(same(G.engState(m), seq[1].st), 'menu TAKE BACK: back two more plies: ' + diff(G.engState(m), seq[1].st));
keys(m, ['DEL']); G.waitInput(m, 30);
soft(same(G.engState(m), s0.st) && m.screenText() === s0.scr, 'DEL: back to the start: ' + diff(G.engState(m), s0.st));
keys(m, ['DEL']); G.waitInput(m, 10);
soft(same(G.engState(m), s0.st), 'DEL with no moves does nothing');
compared += 4;
console.log('ok   against the computer: DEL, menu TAKE BACK, DEL at the start');

// ---- a clock (5|5, two players): the clocks must come back with the position
G.setting(m, G.SET.TWO, ['RIGHT']);
G.setting(m, G.SET.CLOCK, ['RIGHT']);
G.menu(m, ['N']); G.waitInput(m, 10);
const cs = [{ st: G.engState(m) }];
const failsBefore = fails;
const cmoves = ['e2e4', 'e7e5', 'g1f3', 'b8c6', 'f1b5', 'a7a6', 'e1g1'];
for (let i = 0; i < cmoves.length; i++) {
  m.runSeconds(3 + i);                         // think a while
  G.typeUci(m, cmoves[i]); G.waitInput(m, 10);
  cs.push({ st: G.engState(m) });
}
console.log('     clocks after each ply (frames):', cs.map((s) => s.st.clk.join('/')).join(' '));
for (let k = cmoves.length - 1; k >= 0; k--) {
  m.runSeconds(2);
  keys(m, ['DEL']); G.waitInput(m, 30);
  const st = G.engState(m);
  compared++;
  // the side not to move: exactly as saved; the side to move's clock is running, so the two
  // samples may be up to two ticks (40 frames) apart, depending on when each was read: the take
  // back's redraw can keep key_wait busy past its first one-second tick, and the clock is then
  // charged the real time since it restarted (17 Nov, traced: restarted at frame 37,959, read at
  // 37,999, 40 charged)
  const tm = k % 2, nt = tm ^ 1;
  const okClk = st.clk[nt] === cs[k].st.clk[nt] && Math.abs(st.clk[tm] - cs[k].st.clk[tm]) <= 40;
  soft(okClk, 'clock game: take back to ply ' + k + ': clocks ' + st.clk + ' vs ' + cs[k].st.clk + ' when first reached');
  soft(same(st.pos, cs[k].st.pos), 'clock game: take back to ply ' + k + ': position');
}
console.log((fails > failsBefore ? 'FAIL ' : 'ok   ') + 'clock game: ' + cmoves.length + ' take backs, clocks compared');
G.setting(m, G.SET.CLOCK, ['LEFT']);
console.log(compared + ' checks, ' + fails + ' failures (take backs compared with the state when first reached)');
if (fails) process.exit(1);
console.log('all take-back tests passed');
