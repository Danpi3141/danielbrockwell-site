; =====================================================================
; Chess bootstrap. It lies in a string constant in CHESS's own translated text
; (tools/build.py puts it there after translating) and is run where it is:
;
;     r%=USR(PEEKW($A9)+k,ADDR(v%()))
;
; While PEEKW runs, RTA_PC ($A9) is the address of its own op-code, so k is the
; constant distance from there to `boot`. (Until 24 Nov three launchers poked a
; bootstrap into an array declared for each size of table.)
;
; It takes the game's memory from under OPL's stack by lowering RTA_SP, finds the
; kernel block CHK on B:, C: or A: with the OS's FL$BOPN, reads the kernel in,
; adds its address to every word in its fix-up list and calls it with D = ADDR(v%()).
;
;     the table (v%(2) bytes) | kernel, variables, slot A (KTOTAL) | CHESS's frame
;
; Everything up to `boot`, and CHESS's translated text before it, never runs again
; once the game has started: the kernel keeps variables there (HOLE, kvars.inc).
; `boot` on must survive: the kernel returns to it, to give the memory back.
;
; v%() (bytes): 0 the kernel's address  2 the table's size  4 device (the kernel
; reads these); then the bootstrap's own.
; Position independent: only relative branches and zero-page scratch; the OS uses
; the zero-page scratch too, so across OS calls everything is on the stack.
; Returns X = 0, E_NOPACK or the kernel's result code.
; =====================================================================
        include "../defs.inc"

RTA_SP  = $A5
V_BASE  = 0
V_TT    = 2
V_DEV   = 4
V_SP    = 6
V_KLEN  = 8
V_FIXN  = 10

load:   bsr  .find              ; (pushes the name's address)
.name:  fcb  5
        fcc  "B:CHK"
.find:  ldaa #'B'               ; B:, then C:, then A:
.dev:   pulx                    ; X = the name
        pshx
        staa 1,x                ; its device letter
        psha
        ldab #$83               ; a procedure (a block file of type $83)
        os   FL$BOPN            ; found: the pack address is at its data
        pula
        bcc  got
        suba #'B'               ; B: -> C: -> A: -> give up
        bne  .nc
        ldaa #'C'
        bra  .dev
.nc:    deca
        bne  .no
        ldaa #'A'
        bra  .dev
.no:    pulx
        ldab #E_NOPACK
        rts
hop:    bra  load               ; (boot reaches load by way of this)

; CHK's data: the object length (2) and the RETURN stub (16), then the kernel's
; length and the kernel
got:    pulx                    ; (the name)
        tsx
        ldx  2,x                ; X = v%() (boot pushed it, then its return address)
        suba #'A'               ; the device: A: 0, B: 1, C: 2
        staa V_DEV,x
        pshx
        clra
        ldab #18
        os   PK$SKIP
        os   PK$RWRD            ; D = kernel length
        pulx
        std  V_KLEN,x
        pshx
        ldx  V_BASE,x
        os   PK$READ            ; the kernel
        os   PK$RWRD            ; D = encoded length
        pulx
        std  V_FIXN,x
        pshx
        pshb
        psha
        ldd  V_KLEN,x
        addd V_BASE,x
        xgdx                    ; X = just after the kernel
        pula
        pulb
        os   PK$READ            ; the encoded list after it
        pulx
        stx  T6                 ; v%()
        ldd  V_BASE,x
        std  T0                 ; the kernel
        std  T8                 ; the last word fixed
        addd V_KLEN,x
        std  T2                 ; the next encoded byte
        addd V_FIXN,x
        std  T4                 ; the end
.fx:    ldx  T2
        cpx  T4
        beq  .go
        ldab 0,x                ; a gap: one byte, or 255 then two
        inx
        clra
        cmpb #255
        bne  .rel
        ldd  0,x
        inx
        inx
.rel:   addd T8
        std  T8
        stx  T2
        xgdx                    ; X = the word to fix
        ldd  0,x
        addd T0
        std  0,x
        bra  .fx
.go:    ldx  T0                 ; the kernel's entry is its first byte
        pshx
        ldd  T6                 ; D = v%()
        rts                     ; (into it; its rts comes back to boot)

boot:   xgdx                    ; X = v%()
        ldd  RTA_SP
        std  V_SP,x
        subd #KTOTAL
        std  V_BASE,x
        subd V_TT,x
        std  RTA_SP
        pshx
        bsr  hop
        pulx
        pshb                    ; B = the result
        ldd  V_SP,x             ; the memory given back
        std  RTA_SP
        pulb
        clra
        xgdx
        rts
