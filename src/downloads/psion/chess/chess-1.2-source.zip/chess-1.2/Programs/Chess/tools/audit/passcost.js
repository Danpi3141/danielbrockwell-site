'use strict';
// How many nodes the levels 1-4 margin pass needs, relative to the level's budget (unlimited pass).
// Positions: the games of a match file. Usage: node passcost.js results/lvf_L4_L3.jsonl [positions]
const fs = require('fs');
const L = require('./levels.js');
const { Engine, parseUci } = L.loadEngine(process.env.ENGINE ? require('path').resolve(process.env.ENGINE) : null);
const file = process.argv[2], NP = +(process.argv[3] || 1500);
const games = fs.readFileSync(file, 'utf8').trim().split('\n').map(JSON.parse);
const ratios = { 1: [], 2: [], 3: [], 4: [] };
const g = new Engine(), e = new Engine();
let n = 0;
outer: for (const gm of games) {
  g.setFen('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
  const ms = gm.moves.split(' ');
  for (let i = 0; i < ms.length; i++) {
    if (i % 7 === 3) {
      const fen = toFen(g);
      for (let lv = 1; lv <= 4; lv++) {
        e.setFen(fen); e.ttInit(9); e.passMul = 1e6; e.rnd = 1 + i;
        const r = L.levelThink(e, lv);
        ratios[lv].push(r.nodes / L.levelNodes(lv));
      }
      if (++n >= NP) break outer;
    }
    const m = parseUci(g, ms[i]); g.make(m[0], m[1]); g.ply = 0;
  }
}
function toFen(e) {
  let s = '';
  for (let r = 7; r >= 0; r--) { let k = 0; for (let c = 0; c < 8; c++) { const p = e.b[r * 16 + c]; if (!p) { k++; continue; } if (k) { s += k; k = 0; } const ch = ' pnbrqk'[p & 7]; s += p & 8 ? ch : ch.toUpperCase(); } if (k) s += k; if (r) s += '/'; }
  let cs = ''; if (e.castle & 1) cs += 'K'; if (e.castle & 2) cs += 'Q'; if (e.castle & 4) cs += 'k'; if (e.castle & 8) cs += 'q';
  return `${s} ${e.side ? 'b' : 'w'} ${cs || '-'} - ${e.half} 1`;
}
for (let lv = 1; lv <= 4; lv++) {
  const a = ratios[lv].sort((x, y) => x - y), q = (p) => a[Math.min(a.length - 1, Math.floor(p * a.length))].toFixed(2);
  console.log(`level ${lv}: pass nodes / level budget over ${a.length} positions: median ${q(0.5)}, 90% ${q(0.9)}, 99% ${q(0.99)}, max ${a[a.length - 1].toFixed(1)}; within x2 ${(100 * a.filter(x => x <= 2).length / a.length).toFixed(0)}%, x4 ${(100 * a.filter(x => x <= 4).length / a.length).toFixed(0)}%, x8 ${(100 * a.filter(x => x <= 8).length / a.length).toFixed(0)}%`);
}
