"""Tabulate compress.js 'full' results: total bytes (data + index + Huffman table) per scheme and block size."""
import json, glob, os, sys
DIR = os.environ['EGTB_DIR']
for f in sorted(glob.glob(os.path.join(DIR, 'full', '*.txt'))):
    rows = [json.loads(l) for l in open(f, encoding='utf-8') if l.startswith('{')]
    name = os.path.basename(f)[:-4]
    blks = sorted({r['blkEntries'] for r in rows if r['policy'] == 1})
    schemes = []
    for r in rows:
        if r['scheme'] not in schemes: schemes.append(r['scheme'])
    print('\n%s  (%s, %s order)' % (name, rows[0]['perm'], rows[0]['order']))
    print('| scheme | ' + ' | '.join('%d (%dB)' % (b, rows[0] and next(r['decodedBytes'] for r in rows if r['blkEntries'] == b)) for b in blks) + ' | no capture DC |')
    print('|---' * (len(blks) + 2) + '|')
    for s in schemes:
        cells = []
        for b in blks:
            r = next((r for r in rows if r['scheme'] == s and r['blkEntries'] == b and r['policy'] == 1), None)
            cells.append('%d' % r['total'] if r else '')
        r0 = next((r for r in rows if r['scheme'] == s and r['policy'] == 0), None)
        print('| %s | %s | %s |' % (s, ' | '.join(cells), ('%d @%d' % (r0['total'], r0['blkEntries'])) if r0 else ''))
    h = [r for r in rows if r['scheme'] in ('HRLE', 'HRLEc') and r['policy'] == 1]
    for r in h:
        print('   %s blk %d: avg runs to entry %s, avg code+extra bits %s, max runs/block %s, max block %d B, avg block %s B, maxCode %s, nsym %s' % (
            r['scheme'], r['blkEntries'], r['avgRuns'], r['avgBits'], r['maxRunsPerBlock'], r['maxBlock'], r['avgBlock'], r['maxCode'], r['nsym']))
