; =====================================================================
; Engine variables. The kernel includes this inside its variable block
; (cleared at start, not on the pack). See API.md.
;
; Zero page (24 Nov): the busiest variables are at fixed addresses there, where each
; access is a byte and a cycle less (the engine 462 bytes smaller and 4.9% faster, searching
; exactly the same positions). ZP1..ZP3 are in src/defs.inc, where what the OS keeps there is
; put aside at the start and put back at the end (kinit.asm, quit). ZP1 and ZP2 hold
; temporaries: any engine routine may overwrite them, like the scratch; ZP3 is kept.
;
; The rest is in two parts:
;  - the persistent block below (rmb): the position and the game's key
;    history, which must survive between engine calls;
;  - the scratch (ENG_SCRATCH_SIZE bytes at e_scratch): everything else.
;    Any engine routine may overwrite all of it. The kernel may share it
;    with an overlay slot by defining ENG_SCRATCH_EXT (an address) before
;    including this file; 0 = the engine reserves its own.
; =====================================================================
E_MAXPLY  = 24                  ; plies of search frames (must match ref/engine.js MAXPLY)
E_MVMAX   = 400                 ; move stack entries (3 bytes each)
E_MVCAP   = 360                 ; a node with more moves stacked below it is a leaf (ref MVCAP);
                                ; a list that would run past E_MVMAX is cut short
E_FR      = 43+2*E_NULL+E_LMR+E_PVS ; bytes per search frame (F_* in emove.asm; 48 until 17 Nov)
E_QUNS    = 148                 ; an unscored quiet move's score (above every quiet score, 127 at most,
                                ; below the killers' 149 and 150 and every capture, 162 at least)
E_KCAP    = 100                 ; eng_play empties the key history when it holds this many (104 until 17 Nov):
                                ; it is emptied at every irreversible move too, so it holds at most the
                                ; half-move clock, and at 100 the game is over (fifty moves)
E_KMAX    = E_KCAP+E_MAXPLY-2   ; key history entries: the game's at most E_KCAP-1, then one a ply of
                                ; search, moves being made up to ply E_MAXPLY-2 (the quiescence search
                                ; stands pat at E_MAXPLY-1): 122 (136 until 17 Nov; tests/engine/t_khist.js)

; ---- position (the UI may read these; write them only before eng_setup)
e_board:  rmb 128               ; 0x88 board
e_side    = ZP3+0                   ; 0 White, 8 Black to move
e_castle  = ZP3+1                   ; bit0 W O-O, bit1 W O-O-O, bit2 B O-O, bit3 B O-O-O
e_ep      = ZP3+2                   ; en passant square or $FF
e_half    = ZP3+3                   ; half-move clock
; ---- derived (kept up to date by make/unmake)
e_ksq:    rmb 2                 ; king squares: White, Black
e_mg:     rmb 4                 ; material + PST, middlegame: White word, Black word
e_eg:     rmb 4                 ; same, endgame
e_phase:  rmb 1                 ; N,B = 1, R = 2, Q = 4
e_cnt:    rmb 16                ; piece counts [colour*8 + type]
e_bcol:   rmb 1                 ; e_insuf: the bishops' square colour so far
e_pm:     rmb 20                ; pawn rank masks, bit n = rank n: White file f at 1+f, Black at 11+f
                                ; (bytes 0, 9, 10, 19 stay 0 so neighbouring files need no test)
e_key:    rmb 3                 ; position key (24 bits), big-endian
; ---- think interface
e_tlim    = ZP3+6                   ; time limit in 50 ms frames, 0 = none
e_nlim:   rmb 3                 ; node limit, 0 = none
e_tadd:   rmb 2                 ; fail-low: extra frames past e_tlim allowed (the kernel's think sets it)
e_maxd:   rmb 1                 ; maximum depth, 0 = 40
e_margin  = ZP3+10                  ; levels 1-4: evaluation noise k (its low byte; the levels use 14-100), within +-8k cp (0 none; until 17 Nov a margin pass's cp)
e_nseed:  rmb 1                 ;   and this search's noise seed
e_bestf:  rmb 1                 ; result
e_bestt:  rmb 1
e_score   = ZP3+8  
e_depth:  rmb 1
e_nodes:  rmb 3
e_rnd     = ZP3+4                   ; random state (xorshift16), never 0
e_tt:     rmb 2                 ; transposition table address (set by the kernel)
e_ttn:    rmb 2                 ; entries (power of two, >= 128)
e_ttmask: rmb 2                 ; e_ttn - 1
e_lmn:    rmb 1                 ; eng_legal: count
e_kn:     rmb 1                 ; keys in e_khist
e_khist:  rmb 2*E_KMAX          ; top 16 bits of the key before each move: game since the last
                                ; irreversible move, then the search

; ---- scratch layout (offsets)
; In the kernel's build three parts are elsewhere (ENG_LOW, 24 Nov): in RTT_BF, which the OS's file
; services overwrite, so for what does not outlive an engine call.
S_MVTOP   = 0                           ; move stack start for each ply (addresses)
S_KILL    = S_MVTOP+2*(E_MAXPLY+2)      ; two killers (from,to) per ply
S_TMP     = S_KILL+4*E_MAXPLY           ; temporaries (below; the margin pass's 256-byte score list went 17 Nov)
S_LOWLEN  = S_TMP+48
        if   ENG_LOW
S_MVS     = 0                           ; move stack
        else
S_MVS     = S_LOWLEN                    ; move stack
        endif
S_FRAMES  = S_MVS+3*E_MVMAX             ; search frames
ENG_SCRATCH_SIZE = S_FRAMES+E_FR*(E_MAXPLY+1)

        if   ENG_SCRATCH_EXT
e_scratch = ENG_SCRATCH_EXT
        else
e_scratch: rmb ENG_SCRATCH_SIZE
        endif

        if   ENG_LOW
e_low     = ENG_LOW
        else
e_low     = e_scratch
        endif
e_mvtop   = e_low+S_MVTOP
e_killer  = e_low+S_KILL
e_mvs     = e_scratch+S_MVS
e_frames  = e_scratch+S_FRAMES
e_lm      = e_mvs+3*E_MVMAX-440     ; eng_legal output: up to 220 moves (from,to), clear of ply 0's list

; temporaries: the busiest in zero page (24 Nov), the rest in the scratch, at S_TMP
e_ply     = ZP1+13                    ; current search ply
e_fp      = ZP2+8                      ; current frame address (2)
e_wp      = ZP2+14                    ; move generator: write pointer (2)
e_caps    = ZP2+40                    ; move generator: captures only
e_us      = ZP2+32                    ; move generator: side to move (0/8)
e_them    = ZP2+33                    
e_stop    = e_low+S_TMP+0          ; search must unwind
e_tstart  = e_low+S_TMP+1          ; TMW_FRAM at the start of the think (2)
e_tick    = e_low+S_TMP+3          ; nodes until the next poll
e_rootf   = e_low+S_TMP+4          ; best root move of the iteration in progress
e_roott   = e_low+S_TMP+5          
e_rootsc  = e_low+S_TMP+6          ; (2)
e_nleg    = e_low+S_TMP+8          ; legal root moves
e_t       = ZP2+0                      ; scratch words (8)
e_gs      = ZP2+18                    ; move generator: square
e_gpc     = ZP2+19                    ;                 piece
e_gpst    = ZP2+16                    ;                 its PST row (middlegame) (2)
e_gptr    = ZP2+22                    ;                 direction table pointer (2)
e_gcnt    = ZP2+37                    ;                 directions left
e_mf      = ZP2+20                    ; make/unmake: from
e_mt      = ZP2+24                    ;              to (square)
e_mtc     = ZP2+25                    ;              to (with promotion bits)
e_mcap    = ZP2+26                    ;              captured piece
e_mpc     = ZP2+27                    ;              moving piece
e_mnp     = ZP2+28                    ;              piece arriving (promotions)
e_mus     = ZP2+29                    ;              mover (0/8)
e_mrf     = e_low+S_TMP+9          ;              castling rook from
e_mrt     = e_low+S_TMP+10         ;              castling rook to
e_mrk     = e_low+S_TMP+11         ;              the rook
e_mcs     = e_low+S_TMP+12         ;              en passant victim's square
e_pv      = ZP2+39                    ; add/remove piece: 0 add, 1 remove
e_ppc     = ZP2+30                    ;                   piece
e_psq     = ZP2+31                    ;                   square
e_pix     = ZP1+0                     ;                   PST index (2)
e_pval    = ZP1+2                     ;                   value (2)
e_emg     = ZP1+9                     ; evaluation: middlegame total (2)
e_eeg     = ZP1+11                    ;             endgame total (2)
e_ew      = ZP1+4                     ;             pawn mask
e_eo      = ZP1+5                     ;             opposing mask
e_er      = ZP1+6                     ;             rank
e_es      = ZP1+7                     ;             score (2)
e_gives   = ZP2+41                    ; search: the move gives check
e_sc      = ZP2+34                    ;         a child's score (negated) (2)
e_ca      = e_low+S_TMP+13         ;         the child's window (2)
e_cb      = e_low+S_TMP+15         ;         (2)
e_pend    = ZP2+12                    ;         end of the list being picked from (2)
e_inck    = ZP2+36                    ; e_make: the mover is in check (full legality test)
e_mep     = ZP2+38                    ; e_make: the move took en passant
e_pcv     = e_low+S_TMP+17         ; eval's pawn cache: valid
e_pcmg    = e_low+S_TMP+18         ;   pawn score, middlegame (2)
e_pceg    = e_low+S_TMP+20         ;   pawn score, endgame (2)
e_pcm     = e_low+S_TMP+22         ;   the pawn masks it belongs to (16)
e_ofp     = ZP2+10                    ; the parent frame, e_fp - E_FR (2; kept with e_fp)
e_bare    = e_low+S_TMP+38         ; eng_think: a side has a bare king (no table cut-offs)
e_flon    = e_low+S_TMP+39         ; fail-low: this iteration is failing low (may run past the limit)
e_flused  = e_low+S_TMP+40         ;           already used in this search
e_fln     = e_low+S_TMP+41         ;           the node limit then: twice e_nlim (3)
e_tfl     = e_low+S_TMP+44         ;           the time limit then: e_tlim + e_tadd (2)
e_rootend = e_low+S_TMP+46         ; root ordering: the end of the root's kept list (2; 0 = none yet)
