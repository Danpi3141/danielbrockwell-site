// KPK bitbase probe (Node), same semantics as kpk.py probe().
//
//   const kpk = require('./probe.js');
//   const t = kpk.load();                       // reads ../../data/kpk.bin
//   kpk.probe(t, wk, bk, wp, sideToMove, pawnColour)  -> 1 pawn side wins, 0 draw/illegal
//
// Squares 0..63, a1 = 0, h8 = 63. sideToMove / pawnColour: 0 = White, 1 = Black.
// Normalisation:
//   pawn Black's -> flip ranks (sq ^ 56) of all three pieces, the black king
//                   becomes the strong ("white") king, side to move is swapped;
//   pawn on files e-h -> mirror files (sq ^ 7) of all three pieces;
//   pawn not on ranks 2..7 after that -> 0.
//   slice = stm*24 + (pawnRank-1)*4 + pawnFile; byte = slice*512 + sk*8 + (wk>>3),
//   bit = wk & 7 (sk = strong king, wk = weak king).
//
// CLI: node probe.js test [N=100000] [seed=7]  -- compares with Python probes.
//      node probe.js <wk> <bk> <wp> <w|b to move> <w|b pawn>   (algebraic squares)
'use strict';
const fs = require('fs');
const path = require('path');

const BIN = path.join(__dirname, '..', '..', 'data', 'kpk.bin');

function load(file = BIN) {
  const t = fs.readFileSync(file);
  if (t.length !== 24576) throw new Error(`kpk.bin is ${t.length} bytes, expected 24576`);
  return t;
}

function probe(t, wk, bk, wp, stm, pawnColour) {
  let sk, weak, p, side;
  if (pawnColour) { sk = bk ^ 56; weak = wk ^ 56; p = wp ^ 56; side = stm ^ 1; }
  else { sk = wk; weak = bk; p = wp; side = stm; }
  if ((p & 7) >= 4) { sk ^= 7; weak ^= 7; p ^= 7; }
  const r = p >> 3;
  if (r < 1 || r > 6) return 0;
  const slice = side * 24 + (r - 1) * 4 + (p & 7);
  return (t[slice * 512 + sk * 8 + (weak >> 3)] >> (weak & 7)) & 1;
}

module.exports = { load, probe, BIN };

if (require.main === module) {
  const a = process.argv.slice(2);
  const sq = s => (s.charCodeAt(1) - 49) * 8 + (s.charCodeAt(0) - 97);
  if (a[0] === 'test') {
    const n = parseInt(a[1] || '100000', 10), seed = a[2] || '7';
    const { execFileSync } = require('child_process');
    const py = execFileSync('python', [path.join(__dirname, 'kpk.py'), 'dumprandom', String(n), seed],
                            { maxBuffer: 1 << 28 }).toString();
    const t = load();
    let count = 0, bad = 0, wins = 0;
    for (const line of py.split(/\r?\n/)) {
      if (!line.trim()) continue;
      const [wk, bk, wp, stm, col, res] = line.split(' ').map(Number);
      const j = probe(t, wk, bk, wp, stm, col);
      count++; wins += j;
      if (j !== res) { if (bad < 10) console.log('MISMATCH', line, 'js =', j); bad++; }
    }
    console.log(`JS vs Python probe: ${count} random positions, ${wins} wins, ${bad} mismatches`);
    process.exit(bad || count !== n ? 1 : 0);
  } else if (a.length === 5) {
    const r = probe(load(), sq(a[0]), sq(a[1]), sq(a[2]), a[3] === 'w' ? 0 : 1, a[4] === 'w' ? 0 : 1);
    console.log(r ? 'win' : 'draw');
  } else {
    console.log('usage: node probe.js test [N] [seed] | node probe.js wk bk wp w|b w|b');
  }
}
