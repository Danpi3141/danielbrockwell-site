; =====================================================================
; The move list (slot A): four moves a screen, "11.Nf3     Nc6",
; scrolled with UP/DOWN. Any other key leaves. When Black moved first
; (a set-up position) the first line is "1....      e5".
; Entry 1 exports the game as PGN (below).
; =====================================================================
        include "../defs.inc"
        include "ids.inc"

        jmp  list               ; 0
        jmp  pgn                ; 1
        if   SPEEDTEST
        bra  sp_show            ; 2 the speed test's results (TEMPORARY)
        endif

list:   clr  ls_off             ; 1: Black began, so ply p is shown as p + 1
        tst  g_setup
        beq  .o
        tst  g_spos+64
        beq  .o
        inc  ls_off
.o:     ldaa g_n
        adda ls_off
        staa ls_end             ; the shown plies end here
        inca                    ; start with the last four moves showing
        lsra                    ; full moves
        suba #4
        bcc  .t
        clra
.t:     staa ls_top
.draw:  jsr  scr_cls
        clr  ls_r
.row:   ldaa ls_r
        adda ls_top
        staa ls_m               ; the move (0-based)
        asla
        cmpa ls_end
        bhs  .shown
        ldaa ls_r
        clrb
        jsr  scr_at
        ldab ls_m
        incb
        clra
        jsr  num_str
        ldx  #kv_nbuf
        jsr  scr_puts
        ldaa #'.'
        jsr  scr_putc
        ldaa ls_m               ; White's move
        asla
        bsr  san_v
        ldaa ls_r               ; Black's at column 11
        ldab #11
        jsr  scr_at
        ldaa ls_m
        asla
        inca
        cmpa ls_end
        bhs  .nb
        bsr  san_v
.nb:    inc  ls_r
        ldaa ls_r
        cmpa #4
        bne  .row
.shown: jsr  scr_flush
        clra
        jsr  key_wait
        cmpb #K_UP
        bne  .k1
        tst  ls_top
        beq  .draw
        dec  ls_top
        bra  .draw
.k1:    cmpb #K_DOWN
        bne  .x
        ldaa ls_top
        adda #4
        asla
        cmpa ls_end
        bhs  .draw
        inc  ls_top
        bra  .draw
.x:     rts

; A = shown ply: "..." before the game's first, else the ply's move
san_v:  suba ls_off
        bcc  san
        jsr  scr_pri
        fcl  "..."
        rts
; A = ply: its move in full at the cursor (the three parts joined)
san:    staa sp_i
        jsr  rd_ply
        bcs  .x
        ldx  #sp_e
        ldd  #ls_buf
        jsr  fmt_parts
        ldx  #ls_buf
        jsr  scr_puts
        ldx  #ls_buf+4
        jsr  scr_puts
        ldx  #ls_buf+8
        jmp  scr_puts
.x:     rts

; ---------------------------------------------------------------------
; Export as PGN: a new data file A:PGN1..A:PGN99, one line a record, so
; the Comms Link sends it to the PC as a text file. The seven standard
; tags (and SetUp/FEN after a set-up), then the moves in standard
; notation, wrapped at 79 characters, and the result. A failed write
; deletes the file: there is never half a game on A:.
; ---------------------------------------------------------------------
PG_W    = 79                    ; longest move-text line
PG_MAX  = 120                   ; the line buffer (a FEN tag is the longest line)
RTC_YEAR = $20C5                ; the clock: years since 1900, month 0-11, day 0-30

pgn:    sts  pg_sp              ; a failed write leaves from any depth
        ldaa st_notat
        staa pg_not
        ldx  #t_nosv            ; no save file (A: was full): no record to export
        tst  g_nosv
        beq  .sv
        jmp  pg_say
.sv:    clr  st_notat           ; standard notation, whatever the screen uses
        jsr  scr_cls
        clra
        clrb
        jsr  scr_at
        jsr  scr_pri
        fcl  "EXPORTING..."
        jsr  scr_flush
        ldaa #$FF               ; no chunk read yet
        staa pg_chk
        ldaa #1                 ; the first free name
        staa pg_n
.name:  jsr  pg_fname
        clr  kv_pkok
        ldx  #pg_fn
        os   FL$OPEN
        bcs  .free
        inc  pg_n
        ldaa pg_n
        cmpa #100
        blo  .name
        jmp  pg_many
.free:  clr  kv_pkok
        ldx  #pg_fn
        os   FL$CRET
        bcc  .made
        jmp  pg_room
.made:  staa pg_rt
        clr  pg_line
        ldx  #t_event
        jsr  pg_putf
        ldx  #t_site
        jsr  pg_putf
        ldx  #t_date
        jsr  pg_put
        ldab RTC_YEAR
        clra
        addd #1900
        jsr  pg_num
        ldaa #'.'
        jsr  pg_putc
        ldab RTC_YEAR+1
        incb
        jsr  pg_2d
        ldaa #'.'
        jsr  pg_putc
        ldab RTC_YEAR+2
        incb
        jsr  pg_2d
        jsr  pg_endf
        ldx  #t_round
        jsr  pg_putf
        ldx  #t_white
        jsr  pg_put
        clra
        jsr  pg_who
        jsr  pg_endf
        ldx  #t_black
        jsr  pg_put
        ldaa #PC_BLACK
        jsr  pg_who
        jsr  pg_endf
        ldx  #t_result
        jsr  pg_put
        jsr  pg_res
        jsr  pg_endf
        tst  g_setup
        beq  .moves
        ldx  #t_setup
        jsr  pg_putf
        ldx  #t_fen
        jsr  pg_put
        jsr  pg_fen
        jsr  pg_endf
.moves: jsr  pg_flush           ; the blank line after the tags
        clr  pg_off             ; 1: Black began, so ply p is shown as p + 1
        tst  g_setup
        beq  .o
        tst  g_spos+64
        beq  .o
        inc  pg_off
.o:     clr  pg_ply
.mv:    ldaa pg_ply
        cmpa g_n
        bhs  .end
        adda pg_off
        tab
        lsrb
        incb                    ; the move number
        anda #1
        bne  .bl
        clra                    ; White's move: "12."
        jsr  num_str
        ldaa #'.'
        bra  .num
.bl:    tst  pg_ply             ; Black's, first in the game: "1..."
        bne  .san
        clra
        jsr  num_str
        ldaa #'.'
        jsr  pg_nbc
        ldaa #'.'
        jsr  pg_nbc
        ldaa #'.'
.num:   jsr  pg_nbc
        ldx  #kv_nbuf
        jsr  pg_word
.san:   ldaa pg_ply
        staa sp_i
        bsr  pg_rd
        bcc  .rd
        ldx  #t_unrd            ; the record can't be read: no half a game
        jmp  pg_bad
.rd:    ldx  #sp_e
        ldd  #pg_parts
        jsr  fmt_parts
        clr  pg_tok             ; the three parts joined
        ldx  #pg_parts
        jsr  pg_cat
        ldx  #pg_parts+4
        jsr  pg_cat
        ldx  #pg_parts+8
        jsr  pg_cat
        ldx  #pg_tok
        jsr  pg_word
        inc  pg_ply
        bra  .mv
.end:   ldaa g_result
        jsr  pg_resx            ; X = the result's text
        jsr  pg_word
        jsr  pg_flush
        ldaa pg_not
        staa st_notat
        jsr  scr_cls            ; "PGN SAVED AS" / "A:PGN3"
        clra
        clrb
        jsr  scr_at
        jsr  scr_pri
        fcl  "PGN SAVED AS"
        ldaa #1
        clrb
        jsr  scr_at
        ldx  #pg_fn
        jsr  scr_puts
        jmp  pg_wait

; sp_i = ply: sp_e = its 3 bytes, as rd_ply, but each chunk record is
; read once (it stays in sv_buf: nothing else uses it while exporting)
pg_rd:  jsr  sp_chunk           ; A = chunk, B = 3 * its place in it
        stab pg_e
        cmpa pg_chk
        beq  .in
        psha
        jsr  sv_open
        pula
        bcs  .x
        staa pg_chk
        jsr  sv_find
        bcc  .in
        ldaa #$FF
        staa pg_chk
        sec
        rts
.in:    ldx  #sv_buf+2
        ldab pg_e
        abx
        ldd  0,x
        std  sp_e
        ldaa 2,x
        staa sp_e+2
        clc
.x:     rts

; pg_n -> pg_fn = "A:PGN" and its number
pg_fname:
        ldx  #pg_fn+1
        ldd  #$413A             ; "A:"
        std  0,x
        ldd  #$5047             ; "PG"
        std  2,x
        ldaa #'N'
        staa 4,x
        ldab pg_n
        clra
        jsr  num_str
        ldab kv_nbuf
        ldx  #pg_fn+6
        ldaa kv_nbuf+1
        staa 0,x
        ldaa kv_nbuf+2
        staa 1,x
        addb #5
        stab pg_fn
        rts

; X = a part (length-prefixed) onto pg_tok
pg_cat: ldab 0,x
        beq  .x
.l:     inx
        ldaa 0,x
        pshx
        pshb
        ldx  #pg_tok
        inc  0,x
        ldab 0,x
        abx
        staa 0,x
        pulb
        pulx
        decb
        bne  .l
.x:     rts

; A = a character onto the number in kv_nbuf
pg_nbc: ldx  #kv_nbuf
        inc  0,x
        ldab 0,x
        abx
        staa 0,x
        rts

; X = a word (length-prefixed): onto the line after a space, or on a new
; line when it would pass PG_W
pg_word:
        stx  pg_x
        ldaa pg_line
        beq  .add
        adda 0,x
        inca
        cmpa #PG_W
        bls  .sp
        bsr  pg_flush
        bra  .add
.sp:    ldaa #' '
        bsr  pg_putc
.add:   ldx  pg_x
        bra  pg_put

; X = text: the whole line, written out
pg_putf:
        bsr  pg_put
        bra  pg_flush
; '"]' and the line written out
pg_endf:
        ldx  #t_end
        bsr  pg_put
; the line as a record (an empty one as a space); a failed write leaves
pg_flush:
        tst  pg_line
        bne  .w
        ldd  #$0120
        std  pg_line
.w:     clr  kv_pkok
        clra
        clrb
        os   FL$SETP            ; A:
        ldab pg_rt
        os   FL$RECT
        ldx  #pg_line
        os   FL$WRIT
        bcs  pg_fail
        clr  pg_line
        rts

; X = text (length-prefixed) onto the line
pg_put: ldab 0,x
        beq  .x
.l:     inx
        ldaa 0,x
        pshx
        pshb
        bsr  pg_putc
        pulb
        pulx
        decb
        bne  .l
.x:     rts
; A = a character onto the line
pg_putc:
        ldab pg_line
        cmpb #PG_MAX
        bhs  .x
        incb
        stab pg_line
        ldx  #pg_line
        abx
        staa 0,x
.x:     rts

; B = 1..99: two digits
pg_2d:  cmpb #10
        bhs  .n
        ldaa #'0'
        pshb
        bsr  pg_putc
        pulb
.n:     clra
; D = a number in decimal
pg_num: jsr  num_str
        ldx  #kv_nbuf
        bra  pg_put

; A = colour: "Player", or the Organiser at its level
pg_who: tst  g_mode
        bne  .pl
        cmpa g_human
        beq  .pl
        ldx  #t_psion
        bsr  pg_put
        jsr  level_now
        adda #'0'
        bra  pg_putc
.pl:    ldx  #t_player
        bra  pg_put

; the result tag's text
pg_res: ldaa g_result
        bsr  pg_resx
        bra  pg_put
; A = g_result: X = "*", "1-0", "0-1" or "1/2-1/2"
pg_resx:
        ldx  #t_res
.l:     tsta
        beq  .x
        ldab 0,x
        abx
        inx
        deca
        bra  .l
.x:     rts

; the set-up position (g_spos) as FEN
pg_fen: ldaa #7
        staa pg_r
.rank:  clr  pg_e
        clr  pg_f
.file:  ldab pg_r
        aslb
        aslb
        aslb
        addb pg_f
        ldx  #g_spos
        abx
        ldab 0,x
        bne  .pc
        inc  pg_e
        bra  .nf
.pc:    pshb
        bsr  .emp
        pulb
        ldx  #t_pcs
        abx
        ldaa 0,x
        jsr  pg_putc
.nf:    inc  pg_f
        ldaa pg_f
        cmpa #8
        bne  .file
        bsr  .emp
        tst  pg_r
        beq  .side
        ldaa #'/'
        jsr  pg_putc
        dec  pg_r
        bra  .rank
.emp:   ldaa pg_e
        beq  .ex
        adda #'0'
        jsr  pg_putc
        clr  pg_e
.ex:    rts
.side:  ldaa #' '
        jsr  pg_putc
        ldaa #'w'
        tst  g_spos+64
        beq  .s1
        ldaa #'b'
.s1:    jsr  pg_putc
        ldaa #' '
        jsr  pg_putc
        ldab g_spos+65          ; castling: bits K Q k q
        andb #15
        bne  .c
        ldaa #'-'
        jsr  pg_putc
        bra  .ep
.c:     stab pg_e
        ldx  #t_cas
.cl:    lsr  pg_e
        bcc  .cn
        ldaa 0,x
        pshx
        jsr  pg_putc
        pulx
.cn:    inx
        tst  pg_e
        bne  .cl
.ep:    ldaa #' '
        jsr  pg_putc
        ldaa g_spos+66          ; en passant: $FF none, else a 0x88 square
        cmpa #$FF
        bne  .e1
        ldaa #'-'
        jsr  pg_putc
        bra  .hm
.e1:    psha
        anda #7
        adda #'a'
        jsr  pg_putc
        pula
        lsra
        lsra
        lsra
        lsra
        adda #'1'
        jsr  pg_putc
.hm:    ldaa #' '
        jsr  pg_putc
        ldab g_spos+67          ; the half-move clock, then move 1
        clra
        jsr  pg_num
        ldaa #' '
        jsr  pg_putc
        ldaa #'1'
        jmp  pg_putc

; a write failed (A: full): no file rather than half a game
pg_fail:
        ldx  #t_room
; X = the reason: the file deleted, "CANNOT EXPORT:" and the reason
pg_bad: lds  pg_sp
        stx  pg_x
        clr  kv_pkok
        ldx  #pg_fn
        os   FL$DELN
        ldx  pg_x
        bra  pg_say
pg_room:
        ldx  #t_room
        bra  pg_say
pg_many:
        ldx  #t_many
; X = the reason: "CANNOT EXPORT:" and it
pg_say: stx  pg_x
        ldaa pg_not
        staa st_notat
        jsr  scr_cls
        clra
        clrb
        jsr  scr_at
        jsr  scr_pri
        fcl  "CANNOT EXPORT:"
        ldaa #1
        clrb
        jsr  scr_at
        ldx  pg_x
        jsr  scr_puts
pg_wait:
        jsr  scr_flush
        clra
        jmp  key_wait

        if   SPEEDTEST
; TEMPORARY (SPEEDTEST): the speed test's results (kcore.asm sp_test)
;   POSITIONS/S nnn      the engine's 1,000 positions: nodes * 20 / frames
;   SEARCH nnnnn MS      (its time)
;   OVERLAY nnn MS       one overlay load (10 timed)
;   BOOK nnn MS          one book look-up (10 timed)
sp_show:
        bsr  scr_cls
        clra
        clrb
        bsr  scr_at
        bsr  scr_pri
        fcl  "POSITIONS/S "
        ldd  sp_nodes           ; nodes * 20 / frames
        ldx  #20
        bsr  sp_mul
        ldx  sp_eng
        bne  .d
        inx
.d:     bsr  udiv
        bsr  sp_num
        ldaa #1
        clrb
        bsr  scr_at
        bsr  scr_pri
        fcl  "SEARCH "
        ldd  sp_eng             ; frames * 50 ms
        ldx  #50
        bsr  sp_mul
        bsr  sp_num
        bsr  scr_pri
        fcl  " MS"
        ldaa #2
        clrb
        bsr  scr_at
        bsr  scr_pri
        fcl  "OVERLAY "
        ldd  sp_ov              ; frames * 50 / 10 = frames * 5 ms
        ldx  #5
        bsr  sp_mul
        bsr  sp_num
        bsr  scr_pri
        fcl  " MS"
        ldaa #3
        clrb
        bsr  scr_at
        bsr  scr_pri
        fcl  "BOOK "
        ldd  sp_bk
        ldx  #5
        bsr  sp_mul
        bsr  sp_num
        bsr  scr_pri
        fcl  " MS"
        bsr  scr_flush
        clra
        bra  key_wait
; D = D * X (X small: 5, 20 or 50; low 16 bits)
sp_mul: std  ls_buf
        ldd  #0
.l:     cpx  #0
        beq  .x
        addd ls_buf
        dex
        bra  .l
.x:     rts
; D at the cursor, in decimal
sp_num: bsr  num_str
        ldx  #kv_nbuf
        bra  scr_puts
        endif

t_event:  fcl  "[Event ",34,"Psion Organiser II game",34,"]"
t_site:   fcl  "[Site ",34,"Psion Organiser II LZ64",34,"]"
t_date:   fcl  "[Date ",34
t_round:  fcl  "[Round ",34,"-",34,"]"
t_white:  fcl  "[White ",34
t_black:  fcl  "[Black ",34
t_result: fcl  "[Result ",34
t_setup:  fcl  "[SetUp ",34,"1",34,"]"
t_fen:    fcl  "[FEN ",34
t_end:    fcl  34,"]"
t_psion:  fcl  "Psion LZ64 level "
t_player: fcl  "Player"
t_res:    fcl  "*"
          fcl  "1-0"
          fcl  "0-1"
          fcl  "1/2-1/2"
t_pcs:    fcc  "?PNBRQK??pnbrqk?"
t_cas:    fcc  "KQkq"
t_room:   fcl  "NO ROOM ON A:"
t_many:   fcl  "A:PGN1-99 ALL USED"
t_nosv:   fcl  "GAME NOT SAVED"
t_unrd:   fcl  "SAVE FILE UNREADABLE"

        include "kfmt.asm"
        include "kply.asm"
sv_tag    = ZP2+0   
sv_rt     = ZP2+1   
sv_rn     = ZP2+2   
sv_off    = ZP2+4   
sv_buf: rmb  HDR_LEN+4
ls_top    = ZP2+5   
ls_r      = ZP2+6   
ls_m      = ZP2+7   
ls_off    = ZP2+8   
ls_end    = ZP2+9   
ls_buf: rmb  12
pg_sp     = ZP2+10  
pg_x      = ZP2+12  
pg_not    = ZP2+14  
pg_n      = ZP2+15  
pg_rt     = ZP2+16  
pg_off    = ZP2+17  
pg_ply    = ZP2+18  
pg_r      = ZP2+19  
pg_f      = ZP2+20  
pg_e      = ZP2+22  
pg_chk    = ZP2+23  
pg_fn:  rmb  10
pg_parts: rmb 12
pg_tok: rmb  12
pg_line: rmb PG_MAX+1
