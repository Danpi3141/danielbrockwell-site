; =====================================================================
; The game overlay (slot A): the save file (which holds the game record)
; and the opening book. Entries (G_* in kcore.asm):
; =====================================================================
        include "../defs.inc"
        include "ids.inc"

        jmp  sv_save            ; 0  the header (settings, game state)
        jmp  sv_load            ; 1  C=0 loaded
        jmp  bk_follow          ; 2  (nothing: the position book is looked up)
        jmp  bk_pick            ; 3  C=0: A = from, B = to
        jmp  bk_reset           ; 4
        jmp  sv_new             ; 5  a new, empty file
        jmp  sv_ply             ; 6  sp_i, sp_e: one ply, then the header
        jmp  rd_ply             ; 7  sp_i -> sp_e (C=1 if it can't)
        jmp  rd_chunk           ; 8  sp_i (a chunk's first ply) -> rp_buf, book followed
        jmp  strip_last         ; 9  the last move into the strip
        jmp  g_info             ; 10 pm_i for pm_f, pm_t (before the move)
        jmp  clk_back           ; 11 after a take back: the clocks as they were
        jmp  sv_flush           ; 12 importing: the last chunk into the file
        jmp  clk_new            ; 13 the clocks from the settings (was the board overlay's)
        jmp  hint_show          ; 14 the hint's text (was the board overlay's)

        include "ksave.asm"
        include "kply.asm"
        include "kbook.asm"
        include "krnd.asm"
        include "kstrip.asm"
        include "kfmt.asm"
        include "kinfo.asm"
        include "kclknew.asm"
        include "khint.asm"
; overlay-local variables (gone when the slot is reused)
bk_key    = ZP2+10  
bk_len    = ZP2+12  
bk_cnt    = ZP2+14  
bk_t1     = ZP2+15  
bk_list:  rmb 16
ch_k      = ZP2+16  
sv_tag    = ZP2+17  
sv_rt     = ZP2+18  
sv_rn     = ZP2+19  
sv_off    = ZP2+22  
sv_k      = ZP2+23  
sv_p      = ZP2+24  
sv_buf:   rmb HDR_LEN+4
