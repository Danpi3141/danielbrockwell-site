"""Build the opening set for the strength matches -> openings.txt (one line of UCI moves per opening).

Part 1: ~40 hand-picked common openings (4-8 plies, SAN).
Part 2: extra balanced 8-ply openings generated with Stockfish (random walk over moves within
        25 cp of the best at depth 10, kept if the final |eval| <= 50 cp at depth 12), so that
        deterministic self-play matches can run a few hundred distinct games.

    python openings.py [n_generated=180]
"""
import os
import random
import sys

import chess
import chess.engine

HERE = os.path.dirname(os.path.abspath(__file__))
SF = os.path.normpath(os.path.join(HERE, '..', '..', 'ext', 'stockfish', 'stockfish',
                                   'stockfish-windows-x86-64-universal.exe'))

HAND = """
e4 e5 Nf3 Nc6 Bb5 a6
e4 e5 Nf3 Nc6 Bc4 Bc5
e4 e5 Nf3 Nc6 Bc4 Nf6
e4 e5 Nf3 Nc6 d4 exd4
e4 e5 Nf3 Nf6 Nxe5 d6
e4 e5 Nc3 Nf6
e4 e5 f4 exf4
e4 e5 Nf3 d6 d4 Nf6
e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6
e4 c5 Nf3 Nc6 d4 cxd4 Nxd4
e4 c5 Nf3 e6 d4 cxd4 Nxd4
e4 c5 Nc3 Nc6 g3
e4 c5 c3 Nf6 e5 Nd5
e4 e6 d4 d5 Nc3 Bb4
e4 e6 d4 d5 e5 c5
e4 e6 d4 d5 Nd2 Nf6
e4 c6 d4 d5 Nc3 dxe4 Nxe4 Bf5
e4 c6 d4 d5 e5 Bf5
e4 d5 exd5 Qxd5 Nc3 Qa5
e4 d6 d4 Nf6 Nc3 g6
e4 Nf6 e5 Nd5 d4 d6
e4 g6 d4 Bg7 Nc3 d6
d4 d5 c4 e6 Nc3 Nf6
d4 d5 c4 c6 Nf3 Nf6
d4 d5 c4 dxc4 Nf3 Nf6
d4 d5 Nf3 Nf6 Bf4 e6
d4 Nf6 c4 e6 Nc3 Bb4
d4 Nf6 c4 e6 Nf3 b6
d4 Nf6 c4 g6 Nc3 Bg7 e4 d6
d4 Nf6 c4 g6 Nc3 d5
d4 Nf6 c4 c5 d5 e6
d4 Nf6 c4 e6 g3 d5
d4 f5 g3 Nf6 Bg2 g6
d4 Nf6 Bg5 e6 e4
c4 e5 Nc3 Nf6 Nf3 Nc6
c4 c5 Nc3 Nc6 g3 g6
c4 Nf6 Nc3 e6 e4 d5
Nf3 d5 g3 Nf6 Bg2 e6
Nf3 Nf6 c4 g6 b3 Bg7
e4 e5 Nf3 Nc6 Nc3 Nf6
f4 d5 Nf3 g6
b3 e5 Bb2 Nc6
"""


def hand_openings():
    out = []
    for line in HAND.strip().splitlines():
        b = chess.Board()
        ucis = []
        for san in line.split():
            m = b.parse_san(san)
            ucis.append(m.uci())
            b.push(m)
        out.append(' '.join(ucis))
    return out


def generate(n, seed=12345):
    rng = random.Random(seed)
    eng = chess.engine.SimpleEngine.popen_uci(SF)
    eng.configure({'Threads': 1, 'Hash': 16})
    seen = set()
    out = []
    tries = 0
    while len(out) < n and tries < n * 10:
        tries += 1
        b = chess.Board()
        ok = True
        for ply in range(8):
            infos = eng.analyse(b, chess.engine.Limit(depth=10), multipv=5)
            best = infos[0]['score'].relative.score(mate_score=10000)
            cands = [i['pv'][0] for i in infos
                     if 'pv' in i and best - i['score'].relative.score(mate_score=10000) <= 25]
            if not cands:
                ok = False
                break
            b.push(rng.choice(cands))
        if not ok:
            continue
        key = b.epd()
        if key in seen:
            continue
        ev = eng.analyse(b, chess.engine.Limit(depth=12))['score'].white().score(mate_score=10000)
        if abs(ev) > 50:
            continue
        seen.add(key)
        out.append(' '.join(m.uci() for m in b.move_stack))
    eng.quit()
    return out


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 180
    hand = hand_openings()
    gen = generate(n)
    # drop generated lines that transpose into a hand line
    hand_epd = set()
    for h in hand:
        b = chess.Board()
        for u in h.split():
            b.push_uci(u)
        hand_epd.add(b.epd())
    gen2 = []
    for g in gen:
        b = chess.Board()
        for u in g.split():
            b.push_uci(u)
        if b.epd() not in hand_epd:
            gen2.append(g)
    with open(os.path.join(HERE, 'openings.txt'), 'w') as f:
        for line in hand + gen2:
            f.write(line + '\n')
    print(f'{len(hand)} hand + {len(gen2)} generated openings -> openings.txt')


if __name__ == '__main__':
    main()
