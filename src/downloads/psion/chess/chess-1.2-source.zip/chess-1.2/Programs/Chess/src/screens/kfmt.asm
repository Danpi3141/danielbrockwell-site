; ---------------------------------------------------------------------
; fmt_parts: X = a record entry (from, to, info), D = 12 bytes for three
; length-prefixed parts of up to 3 characters (who, where, what happened)
; in the notation st_notat chooses.
; ---------------------------------------------------------------------
fmt_parts:
        std  fp_out
        ldaa 0,x
        staa fp_f
        ldaa 1,x
        staa fp_t
        ldaa 2,x
        staa fp_i
        ldx  fp_out
        clr  0,x
        clr  4,x
        clr  8,x
        stx  fp_p               ; part 1
        ldaa fp_i
        anda #7
        staa fp_pc
        tst  st_notat
        beq  .san
        ; plain squares: "h4x", "e1#" (a promotion: "e8Q", "+")
        ldaa fp_f
        jsr  fp_sq
        ldaa fp_i
        bita #8
        beq  .p2
        ldaa #'x'
        jsr  fp_c
.p2:    jsr  fp_next
        ldaa fp_t
        jsr  fp_sq
        jsr  fp_isprom
        bcs  .psuf
        jsr  fp_promc
        jsr  fp_next
.psuf:  jmp  fp_suffix
.san:   ldaa fp_pc
        cmpa #PC_K
        bne  .notc
        ldaa fp_f               ; a king moving two files castles: e^g = 2, e^c = 6
        eora fp_t
        anda #7
        cmpa #2
        beq  .cas
        cmpa #6
        bne  .notc
.cas:   ; castling: "O-O", and "-O" for the long side
        ldaa #'O'
        jsr  fp_c
        ldaa #'-'
        jsr  fp_c
        ldaa #'O'
        jsr  fp_c
        jsr  fp_next
        ldaa fp_t
        anda #7
        cmpa #4
        bhs  .cs
        ldaa #'-'
        jsr  fp_c
        ldaa #'O'
        jsr  fp_c
.cs:    jsr  fp_next
        bra  fp_suffix
.notc:  ldaa fp_pc
        cmpa #PC_P
        bne  .piece
        ldaa fp_i               ; a pawn capture names the file it came from
        bita #8
        beq  .where
        ldaa fp_f
        jsr  fp_file
        bra  .where
.piece: ldx  #pchars
        ldab fp_pc
        abx
        ldaa 0,x
        bsr  fp_c
        ldaa fp_i
        bita #$40
        beq  .r
        ldaa fp_f
        jsr  fp_file
.r:     ldaa fp_i
        bita #$80
        beq  .where
        ldaa fp_f
        jsr  fp_rank
.where: bsr  fp_next
        ldaa fp_i
        bita #8
        beq  .w2
        ldaa #'x'
        bsr  fp_c
.w2:    ldaa fp_t
        bsr  fp_sq
        bsr  fp_next
        bsr  fp_isprom
        bcs  fp_suffix
        ldaa #'='
        bsr  fp_c
        bsr  fp_promc
        ; fall through
fp_suffix:
        ldaa fp_i
        bita #$20
        beq  .c
        ldaa #'#'
        bra  fp_c
.c:     bita #$10
        beq  .x
        ldaa #'+'
        bra  fp_c
.x:     rts

; C=0 if the move is a promotion
fp_isprom:
        ldaa fp_pc
        cmpa #PC_P
        bne  .no
        ldaa fp_t
        anda #$70
        beq  .yes
        cmpa #$70
        beq  .yes
.no:    sec
        rts
.yes:   clc
        rts

; the promotion piece's letter
fp_promc:
        ldaa fp_t
        anda #$88
        ldab #'Q'
        cmpa #$08
        bne  .n1
        ldab #'R'
.n1:     cmpa #$80
        bne  .n2
        ldab #'B'
.n2:     cmpa #$88
        bne  .n3
        ldab #'N'
.n3:     tba
        ; fall through
; A = character onto the current part
fp_c:   ldx  fp_p
        ldab 0,x
        cmpb #3
        bhs  .x
        incb
        stab 0,x
        abx
        staa 0,x
.x:     rts
fp_next:
        ldx  fp_p
        ldab #4
        abx
        stx  fp_p
        rts
; A = square: "e4"
fp_sq:  psha
        bsr  fp_file
        pula
fp_rank:
        anda #$70
        lsra
        lsra
        lsra
        lsra
        adda #'1'
        bra  fp_c
fp_file:
        anda #7
        adda #'a'
        bra  fp_c

pchars: fcc  " PNBRQK  pnbrqk "
fp_out    = ZP2+34
fp_f      = ZP2+36
fp_t      = ZP2+37
fp_i      = ZP2+38
fp_pc     = ZP2+39
fp_p      = ZP2+40
