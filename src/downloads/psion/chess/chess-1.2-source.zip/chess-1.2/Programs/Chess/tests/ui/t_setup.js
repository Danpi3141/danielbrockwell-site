'use strict';
// The set-up screen: a refused set-up, cancelling, and a king-and-pawn ending (the KPK
// slices are loaded into the TT's RAM when the computer thinks).
//   node tests/ui/t_setup.js
const L = require('./lib.js');
const { check, keys } = L;
const DIG = { 1: 'U', 2: 'V', 3: 'W', 4: 'O', 5: 'P', 6: 'Q', 7: 'I', 8: 'J' };
const typeMove = (m, mv) => keys(m, [mv[0], DIG[mv[1]], mv[2], DIG[mv[3]]]);
const board = (m) => L.peekSym(m, 'e_board', 128);
const sq = (s) => (s.charCodeAt(1) - 49) * 16 + (s.charCodeAt(0) - 97);

function openSetup(m) {
  keys(m, ['ON']); m.runSeconds(1);
  keys(m, ['S', 'EXE']); m.runSeconds(2);           // SET UP POSITION is the first S item
}

let m = L.start();
L.idle(m);
const ttn0 = m.peekw(L.sym(m, 'e_ttn'));
openSetup(m);
check(m.screen()[0].startsWith('rnbqkbnr8') && m.screen()[1].includes('SET'), 'set-up shows the board', m);

// refused: only a White king
keys(m, ['C', 'DOWN', 'K', 'EXE']);
m.runSeconds(3);
check(m.screenText().includes('TWO KINGS NEEDED'), 'one king: refused with a reason', m);
keys(m, ['ON']);
L.idle(m);
check(board(m)[sq('e2')] === 1 && board(m)[sq('d8')] === 13, 'cancelled: the game is as it was', m);

// king and pawn against king: White Ke1, Pe4, Black Ke8; White (the player) to move
openSetup(m);
keys(m, ['C', 'DOWN', 'K']);                          // e1: White king
for (let i = 0; i < 7; i++) keys(m, ['UP']);
keys(m, ['K', 'K']);                                  // e8: Black king
for (let i = 0; i < 4; i++) keys(m, ['DOWN']);
keys(m, ['P']);                                       // e4: White pawn
keys(m, ['EXE']);
L.idle(m);
let b = board(m);
check(b[sq('e1')] === 6 && b[sq('e8')] === 14 && b[sq('e4')] === 1 && b.filter((x) => x).length === 3, 'KPK position set up', m);
check(L.peekSym(m, 'g_setup')[0] === 1 && L.peekSym(m, 'g_n')[0] === 0, 'game starts from the set-up', m);
// level 3 (2 s) so the test is quick
keys(m, ['ON']); m.runSeconds(1); keys(m, ['L', 'EXE']); m.runSeconds(1);
keys(m, ['LEFT', 'LEFT', 'LEFT', 'LEFT', 'ON']); L.idle(m);
typeMove(m, 'E1D2');
L.idle(m);
check(L.peekSym(m, 'g_n')[0] === 2, 'the computer answered in the KPK ending', m);
// the answer came from the king-and-pawn distance table (ref/kpkroot.js decides the same)
{
  const { Engine } = require('../../ref/search.js');
  const { kpkRoot } = require('../../ref/kpkroot.js');
  const tab = require('fs').readFileSync(require('path').join(L.ROOT, 'data', 'kpkd.bin'));
  const e = new Engine();
  e.setFen('4k3/8/8/8/4P3/8/8/4K3 w - - 0 1'); e.ply = 0;
  e.make(0x04, 0x13); e.ply = 0;                                   // Ke1-d2
  const want = kpkRoot(e, tab);
  const last = L.peekSym(m, 'g_last', 2);
  check(want && last[0] === want[0] && last[1] === want[1], 'the answer is from the table: ' + last.map((x) => x.toString(16)) + ' (' + (want || []).map((x) => x.toString(16)) + ')', m);
  check(m.peekw(L.sym(m, 'e_ttn')) === ttn0, 'the TT keeps its ' + ttn0 + ' entries (nothing is lent any more)', m);
}
console.log('all set-up tests passed');
