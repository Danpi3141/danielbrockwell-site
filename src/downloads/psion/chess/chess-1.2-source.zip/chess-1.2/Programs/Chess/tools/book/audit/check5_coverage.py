"""Check 5: coverage. How often is the Psion still in book at its 4th, 6th and 8th move?

(a) Simulation, both colours: the Psion plays its P moves (uniformly, as the kernel picks), the
    opponent's moves follow the club frequencies of the position (stats.pkl, including moves that
    are not in the book; the share of games playing a rare move, < 10 games, counts as leaving).
    Computed exactly by propagating probabilities through the tree, and also by Monte Carlo.
(b) Raw replay of a random sample of club games (both 1200-1900, >= 3 min) from games.txt:
    the share whose first moves are a path of the book at the Psion's move N, and, of the games in
    which that side's moves so far were all P moves, the share still in book. These games are
    from the month the book was built from, so this is optimistic.

    python -E -P tools/book/audit/check5_coverage.py [--book data/book.bin] [--games 10000] [--mc 20000]
"""
import argparse
import json
import os
import random
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import chess  # noqa: E402
from common import Tree, BOOK, CACHE, GAMES, P, load_stats, log  # noqa: E402

MOVES = (4, 6, 8)


def plies_before(n, colour):
    return 2 * (n - 1) + (0 if colour == chess.WHITE else 1)


def exact(t, stats, colour):
    """-> {plies played: probability that the position is a book group}"""
    cur = {(): 1.0}
    out = {0: 1.0}
    for ply in range(0, 2 * max(MOVES)):
        nxt = {}
        for path, pr in cur.items():
            b = t.board(path)
            g = t.groups[path]
            if b.turn == colour:
                ps = [u for u, fl, r in g if fl & P]
                for u in ps:
                    if path + (u,) in t.groups:
                        nxt[path + (u,)] = nxt.get(path + (u,), 0) + pr / len(ps)
            else:
                n, mv = stats['club'].get(b.epd(), (0, {}))
                for u, c in mv.items():
                    if path + (u,) in t.groups:
                        nxt[path + (u,)] = nxt.get(path + (u,), 0) + pr * c / n
        cur = nxt
        out[ply + 1] = sum(cur.values())
    return out


def monte_carlo(t, stats, colour, n, rng):
    hits = {k: 0 for k in MOVES}
    for _ in range(n):
        path = ()
        for ply in range(2 * max(MOVES)):
            for k in MOVES:
                if ply == plies_before(k, colour):
                    hits[k] += 1
            b = t.board(path)
            g = t.groups[path]
            if b.turn == colour:
                u = rng.choice([u for u, fl, r in g if fl & P])
            else:
                nn, mv = stats['club'].get(b.epd(), (0, {}))
                x = rng.random() * nn if nn else 1
                u = None
                for m, c in mv.items():
                    if x < c:
                        u = m
                        break
                    x -= c
                if u is None:
                    break
            path = path + (u,)
            if path not in t.groups:
                break
    return {k: hits[k] / n for k in MOVES}


def sample_games(n, rng):
    """Reservoir sample of n club games (SAN lists) from games.txt."""
    res = []
    seen = 0
    with open(GAMES, encoding='ascii') as f:
        for line in f:
            w, b, e, mv = line.split(' ', 3)
            w, b = int(w), int(b)
            if 1200 <= w <= 1900 and 1200 <= b <= 1900 and int(e) >= 180:
                seen += 1
                if len(res) < n:
                    res.append(mv)
                else:
                    j = rng.randrange(seen)
                    if j < n:
                        res[j] = mv
    return res, seen


def replay(t, games):
    paths = []
    for g in games:
        b = chess.Board()
        p = []
        for s in g.split()[:16]:
            try:
                m = b.parse_san(s)
            except ValueError:
                break
            p.append(m.uci())
            b.push(m)
        paths.append(tuple(p))
    out = {}
    for colour in (chess.WHITE, chess.BLACK):
        for k in MOVES:
            n = plies_before(k, colour)
            long_enough = [p for p in paths if len(p) >= n]
            inb = [p for p in long_enough if p[:n] in t.groups]
            # games where that side's moves so far were all P moves (as the Psion would have played)
            cons = [p for p in long_enough if all(
                p[:i] in t.groups and (t.flags(p[:i], p[i]) or 0) & P
                for i in range(n) if (i % 2 == 0) == (colour == chess.WHITE))]
            cons_in = [p for p in cons if p[:n] in t.groups]
            out[('w' if colour else 'b', k)] = (len(long_enough), len(inb), len(cons), len(cons_in))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--book', default=BOOK)
    ap.add_argument('--games', type=int, default=10000)
    ap.add_argument('--mc', type=int, default=20000)
    ap.add_argument('--seed', type=int, default=1)
    ap.add_argument('--out', default=os.path.join(CACHE, 'check5.json'))
    a = ap.parse_args()
    rng = random.Random(a.seed)
    t = Tree(a.book)
    stats = load_stats()
    res = {}
    print('(a) simulation: the Psion plays P moves, the opponent club moves (exact | Monte Carlo %d games)' % a.mc)
    for colour, name in ((chess.WHITE, 'White'), (chess.BLACK, 'Black')):
        ex = exact(t, stats, colour)
        mc = monte_carlo(t, stats, colour, a.mc, rng)
        res['sim_' + name] = {k: [ex[plies_before(k, colour)], mc[k]] for k in MOVES}
        print('  Psion as %-5s: ' % name + '   '.join('move %d: %5.1f%% | %5.1f%%' % (
            k, 100 * ex[plies_before(k, colour)], 100 * mc[k]) for k in MOVES))
    log('sampling %d club games' % a.games)
    games, seen = sample_games(a.games, random.Random(a.seed + 1000))   # same games for every book
    rp = replay(t, games)
    print('(b) replay of %d club games sampled from %d (same month as the book: optimistic)' % (len(games), seen))
    for c, name in (('w', 'White'), ('b', 'Black')):
        for k in MOVES:
            n, inb, cons, cin = rp[(c, k)]
            print('  Psion as %-5s move %d: game moves are a book path %5.1f%% (%d/%d); '
                  'games where %s played only P moves so far: %d, of them in book %5.1f%%'
                  % (name, k, 100 * inb / max(n, 1), inb, n, name, cons, 100 * cin / max(cons, 1)))
    res['replay'] = {'%s%d' % k: v for k, v in rp.items()}
    json.dump(res, open(a.out, 'w', encoding='utf-8'))


if __name__ == '__main__':
    main()
