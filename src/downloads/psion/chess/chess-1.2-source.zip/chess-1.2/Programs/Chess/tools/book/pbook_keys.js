// For the position book (build_pbook.py): each line of stdin is a JSON object
// {"path": [uci...], "moves": [uci...]}; each line of stdout is {"key": n, "idx": [i...], "n": count}:
// the engine's 24-bit key after playing the path from the start (as the Psion's e_key), and each
// move's index in the engine's legal-move list there (eng_legal's order, as in lm_buf; -1 if
// not legal). Uses the reference engine, which matches the assembler (t_api checks the order).
'use strict';
const { Engine, legalMoves, parseUci } = require('../../ref/search.js');
const rl = require('readline').createInterface({ input: process.stdin });
const START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
const out = [];
rl.on('line', (line) => {
  if (!line.trim()) return;
  const j = JSON.parse(line);
  const e = new Engine();
  e.setFen(START); e.ply = 0;
  for (const u of j.path) {
    const mv = parseUci(e, u);
    if (!mv) throw new Error('illegal ' + u + ' in ' + j.path.join(' '));
    e.make(mv[0], mv[1]); e.ply = 0;
  }
  const lm = legalMoves(e);
  const idx = j.moves.map((u) => { const mv = parseUci(e, u); return mv ? lm.findIndex(([f, t]) => f === mv[0] && t === mv[1]) : -1; });
  out.push(JSON.stringify({ key: e.key >>> 0, idx, n: lm.length }));
});
rl.on('close', () => process.stdout.write(out.join('\n') + '\n'));
