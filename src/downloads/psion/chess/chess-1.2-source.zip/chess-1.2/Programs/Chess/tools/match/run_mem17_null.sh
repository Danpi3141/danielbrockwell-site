#!/bin/sh
# 17 Nov: null move off (A) against on, self-play at equal nodes (the same speed per node, measured),
# levels 5, 7 and 8 at the speed after the 17 Nov speed-ups (about 73.8 nodes/s with the OS)
M="python -E -P match.py"
O="--opfile openings_big.txt --openings 0:1242 --workers 12"
E="snap_m17a"
$M m17_null_L5 $E:Nodes=221 $E:Nodes=221,NullMove=true $O > logs_m17_null_L5.txt 2>&1
$M m17_null_L7 $E:Nodes=2214 $E:Nodes=2214,NullMove=true $O > logs_m17_null_L7.txt 2>&1
$M m17_null_L8 $E:Nodes=18800 $E:Nodes=18800,NullMove=true $O > logs_m17_null_L8.txt 2>&1
python -E -P analyze.py m17_null_L5 m17_null_L7 m17_null_L8 | grep -v histogram > logs_m17_null_summary.txt 2>&1
echo done >> logs_m17_null_summary.txt
