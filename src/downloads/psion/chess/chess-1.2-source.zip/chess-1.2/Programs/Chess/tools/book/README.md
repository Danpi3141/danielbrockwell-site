# Opening book

Since 16 Nov `data/book.bin` is a **position book**, built by `build_pbook.py` and read on the
Psion by `src/screens/kbook.asm` (and on the PC by `pbook.js`). The tree book it replaced is kept
as `data/book_v2_tree.bin`; its format and builder (`build_book.py`, `book.py`) are described
further down. The position book reuses `build_book.py`'s game statistics, Stockfish cache and
reference-engine pool.

## Position book (as built)

Only positions where the Psion is to move are stored, each with the Psion's move(s). Nothing is
stored for the opponent: after any reply the game looks the new position up by its key, so a
transposition finds its moves too, and the space goes on the Psion's own moves.

- **Key:** the engine's 24-bit position key (`e_key`; Zobrist keys from one key a square, as the
  engine keeps it, including side to move, castling rights and the en-passant file).
- **File:** 257 big-endian words: the offset of each of 256 buckets (by the key's low byte) and of
  the end. Then the buckets: each position is 2 bytes (the key's high 16 bits) and its moves, one
  byte each: the move's index in the engine's legal-move list (`eng_legal`'s order, which is the
  game's `lm_buf`; `tests/engine/t_api.js` checks the order matches the reference move for move),
  bit 7 set when another move follows. A position takes 3 bytes with one move.
- **Choosing positions:** best first by the chance a game reaches the position with the Psion to
  move: the Psion picks among its book moves evenly; club players (1200-1900, games of 3 minutes or
  more, Lichess 2016-01) reply as often as they did, counts merged by position so transpositions add
  up; positions with fewer than 20 club games are not followed. Until the budget (16K by default).
- **The Psion's moves:** as the tree book chose them (strong players' choices within 35 cp of
  Stockfish at depth 16, else Stockfish's), with variety only early: up to 3 moves at its first
  move, 2 at its second, then 1.
- **Post-pass:** every book move checked by Stockfish at depth 22 (more than 50 cp below its best:
  replaced by the best); the 2,500 likeliest positions just past the book played by the capped engine
  (`ref/uci.js` at 2,120 nodes, the game's level 7): where its move loses 100 cp or more (and the
  Psion isn't still 2 pawns up), the position is added with Stockfish's move.
- **Report:** `data/book_report.txt`, with the chance the Psion's n-th move comes from the book.

```
python -E -P tools/book/build_pbook.py [--budget 15800] [--out data/book.bin] [--no-post]
node tests/ui/t_pbook.js        # the Psion's reader against pbook.js, games and a transposition
```

---

# The tree book (until 16 Nov, `data/book_v2_tree.bin`)

`data/book.bin` is the opening book for the Organiser II chess program; it is one tree that serves
both colours. Built by `build_book.py`, read and checked by `book.py`.

## Format (as built)

- Squares: `sq = rank*8 + file`, a1 = 0, b1 = 1, ..., h8 = 63.
- A move is a 16-bit **big-endian** word: `from<<10 | to<<4 | flags`.
  Castling is stored as the king's two-square move (e1g1, e1c1, e8g8, e8c8). No promotions.
- Flags:
  - bit 3 (8) **L**: last move of its group
  - bit 2 (4) **R**: this move has replies (a reply group follows)
  - bit 1 (2) **J**: a 3-byte big-endian length follows the word
  - bit 0 (1) **P**: preferred, a move the engine itself may choose
- Entry: move word; then, if J, a 3-byte length = number of bytes of this move's reply group
  (the whole subtree that follows, not counting the 3 length bytes); then, if R, the reply group.
  J (and the length) is present exactly when the reply group is longer than 256 bytes.
- A group is a run of entries ending with the one that has L. Groups are never empty.
- The file is just the root group (White's moves from the start position) and is consumed exactly.
- Order within a group: P moves first (most preferred first), then the other moves by club popularity.

To find a move: scan the group linearly. To skip an entry with R: if J, jump by the length;
otherwise scan past its reply group recursively (same rule). Every group has at least one P move.

## What is in it

- **P moves** (1-3 per position): the moves strong players (both >= 2000) chose most, each within
  35 cp of Stockfish 19's best (depth 16, 1 thread, 64 MB hash); if none passes, Stockfish's best.
  Mild preference for 1.e4, 1...e5, 2.Nf3 Nc6 (see `PREFER`).
- **Opponent moves**: every move club players (both 1200-1900, games >= 3 min) play in the position
  in >= 30 games and >= 1% of games. Counts are merged by position, so transpositions share statistics.
- Positions are expanded most-likely first (probability of reaching the node when the engine plays
  White plus when it plays Black, engine moves weighted among the P moves, opponent moves by club
  frequency) until about 5,500 moves / 11 KB; depth cap 20 plies (the post-pass may add a ply). A position reached by two common
  move orders appears under both.

- **Post-pass** (added by the audit, 16 Nov; `post_pass()` in `build_book.py`): Stockfish at depth 22
  (cache `cache/sf22.json`) and the Psion's own capped engine (`ref/uci.js`, 2,500 nodes = level 7):
  1. a reachable P move more than 40 cp below the best loses its P flag;
  2. after an opponent mistake (>= 70 cp), the Psion's P answers must be within 15 cp of the best;
  3. where the book ends and the Psion must think (a leaf with the Psion to move, or its last book
     move followed by a club reply with >= 10% share), the capped engine's first move must not lose
     >= 80 cp while leaving the Psion at or below +200 (or more than 15 cp right after a mistake);
     otherwise the line is extended by Stockfish's best move (with the club reply), up to 4 rounds.
  The grown tree is shrunk (3% steps) until the result fits `MAX_BYTES`. The exits depend on the
  reference engine: after an engine change rerun `--stage tree` (a few minutes with warm caches) and
  the audit.

See `data/book_report.txt` for the counts, the main lines and Lichess named-line coverage, and
`docs/audit-book.md` for the independent audit (`tools/book/audit/`).

## Rebuild

```
python -E -P tools/book/build_book.py                    # all stages, cached ones skipped
python -E -P tools/book/build_book.py --stage tree       # only the tree (seconds when sf.json is warm)
python -E -P tools/book/build_book.py --stage stats --force   # recount after changing rating bands
python -E -P tools/book/build_book.py --stage tree --out x.bin   # build elsewhere (report in x.bin.txt)
python -E -P tools/book/build_book.py --stage tree --no-post     # without the post-pass (= the 15 Nov book)
python -E -P tools/book/book.py selftest                 # validate data/book.bin, print counts
python -E -P tools/book/audit/run_all.py                 # the audit (docs/audit-book.md)
python -E -P tools/book/book.py group e4 e5 Nf3          # group after these moves (SAN or UCI)
python -E -P tools/book/book.py pmoves e4 c5             # engine moves for a position
```

Inputs: `ext/lichess/lichess_2016-01.pgn.zst`, `ext/openings/*.tsv`, `ext/stockfish/...`.
Caches in `tools/book/cache/`: `games.txt` (~500 MB, first 24 plies of each game with ratings;
delete it to save space, the extract stage takes ~1 min), `stats.pkl` (position counts),
`sf.json` (Stockfish evaluations; discarded automatically if `SF_DEPTH` changes).
Tuning knobs are the constants at the top of `build_book.py` (`TARGET_MOVES`, `MAX_BYTES`,
`OPP_MIN_*`, `P_*`, `SF_*`). (`-E -P` instead of `-I` because python-chess and zstandard live in
the user site-packages, which `-I` disables.)

In Python: `book.find_group(data, moves)` returns `(board, [(chess.Move, flags), ...])` or `None`
when out of book; `book.p_moves(data, moves)`; `book.validate(data)`; `book.encode_group(entries)`.
