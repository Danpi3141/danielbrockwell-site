"""Independent checks of the solved raw tables with python-chess (and Stockfish).

  python -E -P xcheck.py bellman KEY N SEED   N random legal positions: the stored value must equal
                                             the best over python-chess's legal moves (successors
                                             probed in our tables; mate/stalemate by python-chess)
  python -E -P xcheck.py sf KEY N SEED MS     N random positions (non-trivial: no capture or promotion
                                             available) analysed by Stockfish for MS milliseconds

EGTB_DIR must point at the raw tables (see lib.js for the layout).
"""
import json
import os
import random
import sys

import chess
import chess.engine

DIR = os.environ['EGTB_DIR']
HERE = os.path.dirname(os.path.abspath(__file__))
SF = os.path.join(HERE, '..', '..', 'ext', 'stockfish', 'stockfish', 'stockfish-windows-x86-64-universal.exe')
VAL = {'K': 0, 'Q': 9, 'R': 5, 'B': 3.25, 'N': 3, 'P': 1}
ORD = 'KQRBNP'
PT = {'Q': chess.QUEEN, 'R': chess.ROOK, 'B': chess.BISHOP, 'N': chess.KNIGHT, 'P': chess.PAWN, 'K': chess.KING}
SYM = {v: k for k, v in PT.items()}
_cache = {}


def table(key):
    if key not in _cache:
        with open(os.path.join(DIR, key + '.bin'), 'rb') as f:
            _cache[key] = f.read()
    return _cache[key]


def parse(key):
    w, b = key[1:].split('vK')
    return [(0, 'K'), (1, 'K')] + [(0, c) for c in w] + [(1, c) for c in b]


def srt(s):
    return ''.join(sorted(s, key=ORD.index))


def canonical(w, b):
    a, c = sum(VAL[x] for x in w), sum(VAL[x] for x in b)
    if a != c:
        return a > c
    return srt(w) <= srt(b)


def probe_board(board):
    """value byte of a python-chess board (side to move view); KvK -> 0"""
    pcs = [(0 if p.color else 1, SYM[p.piece_type], sq) for sq, p in board.piece_map().items()]
    stm = 0 if board.turn else 1
    w = [t for c, t, _ in pcs if c == 0 and t != 'K']
    b = [t for c, t, _ in pcs if c == 1 and t != 'K']
    if not w and not b:
        return 0
    if not canonical(w, b):
        pcs = [(c ^ 1, t, q ^ 56) for c, t, q in pcs]
        stm ^= 1
        w, b = b, w
    key = 'K' + srt(w) + 'vK' + srt(b)
    idx = stm
    used = set()
    for c, t in parse(key):
        j = next(j for j, (cc, tt, _) in enumerate(pcs) if j not in used and cc == c and tt == t)
        used.add(j)
        idx = idx * 64 + pcs[j][2]
    return table(key)[idx]


def score(v):
    if v == 0:
        return 0
    p = v - 1
    return 1000 - p if p & 1 else -1000 + p


def back(v):
    s = score(v)
    return 0 if s == 0 else (-s + 1 if s > 0 else -s - 1)


def wdl(v):
    s = score(v)
    return 'W' if s > 0 else 'L' if s < 0 else 'D'


def random_board(key, rng):
    T = table(key)
    pcs = parse(key)
    n = len(pcs)
    while True:
        i = rng.randrange(len(T))
        if T[i] == 255:
            continue
        stm = i >> (6 * n)
        b = chess.Board(None)
        for k in range(n):
            sq = (i >> (6 * (n - 1 - k))) & 63
            c, t = pcs[k]
            b.set_piece_at(sq, chess.Piece(PT[t], c == 0))
        b.turn = (stm == 0)
        b.castling_rights = 0
        b.ep_square = None
        return i, b


def bellman(key, N, seed):
    rng = random.Random(seed)
    bad = 0
    for _ in range(N):
        i, b = random_board(key, rng)
        assert b.is_valid(), b.fen()
        v = table(key)[i]
        moves = list(b.legal_moves)
        if not moves:
            exp = 1 if b.is_check() else 0
        else:
            best = -10 ** 6
            for m in moves:
                b.push(m)
                best = max(best, back(probe_board(b)))
                b.pop()
            exp = 0 if best == 0 else (1000 - best + 1 if best > 0 else best + 1000 + 1)
        if exp != v:
            bad += 1
            if bad <= 5:
                print('MISMATCH', b.fen(), v, exp)
    return {'key': key, 'positions': N, 'mismatches': bad}


def sf(key, N, seed, ms):
    rng = random.Random(seed)
    eng = chess.engine.SimpleEngine.popen_uci(SF)
    eng.configure({'Threads': 1, 'Hash': 64})
    rows = []
    while len(rows) < N:
        i, b = random_board(key, rng)
        if any(b.is_capture(m) or m.promotion for m in b.legal_moves) or b.is_game_over():
            continue
        v = table(key)[i]
        info = eng.analyse(b, chess.engine.Limit(time=ms / 1000))
        sc = info['score'].pov(b.turn)
        rows.append({'fen': b.fen(), 'tb': wdl(v), 'tbPlies': v - 1 if v else None,
                     'mate': sc.mate(), 'cp': sc.score(), 'depth': info.get('depth')})
    eng.quit()
    return rows


if __name__ == '__main__':
    cmd, key = sys.argv[1], sys.argv[2]
    N, seed = int(sys.argv[3]), int(sys.argv[4])
    if cmd == 'bellman':
        print(json.dumps(bellman(key, N, seed)))
    else:
        rows = sf(key, N, seed, int(sys.argv[5]))
        out = os.path.join(DIR, 'sf_%s.json' % key)
        with open(out, 'w', encoding='utf-8') as f:
            json.dump(rows, f, indent=0)
        print(key, len(rows), 'rows ->', out)
