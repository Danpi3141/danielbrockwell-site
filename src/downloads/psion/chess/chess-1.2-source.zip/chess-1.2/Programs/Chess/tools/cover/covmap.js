'use strict';
// Kernel coverage report: which instructions of the resident kernel (build/game/kernel.lst)
// were executed in a run of the UI tests under CHESS_COVER, and which routines are referenced.
//   CHESS_COVER=<dir> node tests/ui/run_all.js      (tools/emu.js writes <dir>/cov_*.json)
//   node tools/cover/covmap.js <dir> [--all]        (report: never-run routines, with references)
// Conservative: a machine that saw several kernel bases counts a hit at every one of them, so
// code can only be over-counted as run, never under-counted.
const fs = require('fs');
const path = require('path');
const ROOT = path.resolve(__dirname, '..', '..');
const BUILD = path.join(ROOT, 'build', 'game');
const dir = process.argv[2];
const showAll = process.argv.includes('--all');
if (!dir) { console.log('usage: node tools/cover/covmap.js <cover dir> [--all]'); process.exit(1); }

const sym = JSON.parse(fs.readFileSync(path.join(BUILD, 'kernel.sym.json'), 'utf8'));
const codeEnd = sym.kv_first[0];

// executed offsets
const ran = new Uint8Array(codeEnd);
let files = 0;
for (const f of fs.readdirSync(dir).filter((f) => /^cov_.*\.json$/.test(f))) {
  const j = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'));
  files++;
  for (const b of j.bases) for (const pc of j.pcs) { const o = pc - b; if (o >= 0 && o < codeEnd) ran[o] = 1; }
}

// the listing: one instruction or data line per row: "OOOO  BYTES  [label:] op args ; comment"
const lines = fs.readFileSync(path.join(BUILD, 'kernel.lst'), 'utf8').split(/\r?\n/);
const items = [];
for (const l of lines) {
  const m = /^([0-9A-F]{4})  ([0-9A-F]*)\s+(.*)$/.exec(l);
  if (!m) continue;
  const off = parseInt(m[1], 16);
  if (off >= codeEnd) continue;
  let rest = m[3].replace(/;.*$/, '').trim();
  let label = null;
  const lm = /^([A-Za-z_.$][\w.$]*):\s*(.*)$/.exec(rest);
  if (lm) { label = lm[1]; rest = lm[2]; }
  const op = (rest.split(/\s+/)[0] || '').toLowerCase();
  const n = m[2].length / 2;
  const data = /^(fcc|fcb|fdb|rmb|fill|db|dw|ds)$/.test(op);
  items.push({ off, n, label, op, text: rest, data });
}

// routines: every relocatable symbol below the variables starts one (labels on their own
// line are not in the listing, so the symbol file is the source of the boundaries)
const starts = Object.entries(sym).filter(([n, v]) => v[1] === 'rel' && v[0] < codeEnd && !n.includes('.'))
  .map(([n, v]) => ({ name: n, start: v[0] })).sort((a, b) => a.start - b.start || a.name.localeCompare(b.name));
const routines = [];
for (const st of starts) { if (routines.length && routines[routines.length - 1].start === st.start) routines[routines.length - 1].name += '=' + st.name; else routines.push({ name: st.name, start: st.start, items: [] }); }
{ let ri = -1; for (const it of items) { while (ri + 1 < routines.length && routines[ri + 1].start <= it.off) ri++; if (ri >= 0) routines[ri].items.push(it); } }

// references to each name in all sources (kernel, screens, engine), not counting its definition
const srcFiles = [];
for (const d of ['src/kernel', 'src/screens', 'src/engine']) {
  for (const f of fs.readdirSync(path.join(ROOT, d))) if (/\.(asm|inc)$/.test(f)) srcFiles.push(path.join(ROOT, d, f));
}
const src = srcFiles.map((f) => ({ f: path.relative(ROOT, f), t: fs.readFileSync(f, 'latin1').split(/\r?\n/).map((l) => l.replace(/;.*$/, '')) }));
function refs(name) {
  const re = new RegExp('(^|[^\\w.$])' + name.replace(/[$.]/g, '\\$&') + '($|[^\\w$])');
  const out = [];
  for (const s of src) s.t.forEach((l, i) => {
    if (!re.test(l)) return;
    if (new RegExp('^\\s*' + name.replace(/[$.]/g, '\\$&') + ':').test(l)) return;   // its definition
    out.push(s.f + ':' + (i + 1));
  });
  return out;
}

let deadBytes = 0, partBytes = 0;
const report = [];
for (const r of routines) {
  const code = r.items.filter((i) => !i.data && i.n > 0);
  const dataB = r.items.filter((i) => i.data).reduce((a, i) => a + i.n, 0);
  const codeB = code.reduce((a, i) => a + i.n, 0);
  const runB = code.filter((i) => ran[i.off]).reduce((a, i) => a + i.n, 0);
  const isEngine = /^(e_|eng_|ev_|g_|tt_|zx_|ef_)/.test(r.name);
  const rf = [].concat(...r.name.split('=').map(refs));
  if (codeB > 0 && runB === 0) deadBytes += codeB; else partBytes += codeB - runB;
  if (showAll || (codeB > 0 && runB === 0) || (codeB === 0 && dataB > 0 && rf.length === 0)) {
    report.push({ name: r.name, at: r.start.toString(16).padStart(4, '0'), codeB, runB, dataB, engine: isEngine, refs: rf });
  }
}
console.log(`coverage files: ${files}; kernel+engine code: ${codeEnd} bytes`);
console.log(`never run: ${deadBytes} bytes of code in whole routines; ${partBytes} more bytes not run inside routines that ran`);
for (const r of report) {
  console.log(`${r.engine ? 'ENG ' : 'KER '}${r.at} ${r.name.padEnd(14)} code ${String(r.codeB).padStart(4)} run ${String(r.runB).padStart(4)} data ${String(r.dataB).padStart(4)}  refs ${r.refs.length}: ${r.refs.slice(0, 4).join(' ')}`);
}
// unrun stretches inside routines that ran (kernel only), for a closer look
if (process.argv.includes('--gaps')) {
  console.log('\nunrun stretches of >= 6 bytes inside routines that ran (kernel):');
  for (const r of routines) {
    if (/^(e_|eng_|ev_|g_|tt_|zx_|ef_)/.test(r.name)) continue;
    const code = r.items.filter((i) => !i.data && i.n > 0);
    if (!code.some((i) => ran[i.off])) continue;
    let run = [];
    const flush = () => { const b = run.reduce((a, i) => a + i.n, 0); if (b >= 6) console.log(`  ${r.name} +${(run[0].off - r.start)}: ${b} bytes: ${run.map((i) => (i.label ? i.label + ': ' : '') + i.text).join(' | ')}`); run = []; };
    for (const i of code) { if (ran[i.off]) flush(); else run.push(i); }
    flush();
  }
}
