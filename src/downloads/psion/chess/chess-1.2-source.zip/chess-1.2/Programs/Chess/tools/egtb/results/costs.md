| table | scheme @ entries/block | bytes on pack | avg bytes read | avg 6303 cycles | avg ms/probe | worst bytes read | worst cycles | worst ms |
|---|---|---|---|---|---|---|---|---|
| KBNvK BTM | HRLE @1024 | 521392 | 105 | 67709 | 79 | 304 | 220930 | 251 |
| KPvKP WTM | HRLEc @4096 | 243389 | 108 | 69432 | 81 | 622 | 492644 | 556 |
| KPvKP WTM W-bit | HRLEc @4096 | 113375 | 56 | 35676 | 42 | 221 | 147662 | 169 |
| KPvKP WTM W-bit | LZH @4096 | 107402 | 55 | 46515 | 54 | 225 | 170320 | 194 |
| KQvKP BTM | HRLEc @4096 | 46129 | 19 | 12818 | 16 | 294 | 195082 | 223 |
| KQvKP BTM | LZH @4096 | 46956 | 20 | 24755 | 30 | 229 | 173040 | 197 |
| KQvKP BTM pawn-7th slice | HRLEc @4096 | 36406 | 78 | 49186 | 58 | 289 | 192130 | 220 |
| KQvKP BTM pawn-7th slice | LZH @4096 | 31273 | 75 | 59520 | 69 | 216 | 164200 | 187 |
| KQvKP WTM | HRLEc @4096 | 9011 | 6 | 4931 | 8 | 156 | 93254 | 108 |
| KRvKB BTM | HRLEc @4096 | 22446 | 20 | 13172 | 17 | 310 | 214152 | 244 |
| KRvKB WTM | HRLEc @4096 | 20600 | 20 | 13371 | 17 | 257 | 179902 | 205 |
| KRvKB WTM | LZH @4096 | 19769 | 19 | 23605 | 28 | 179 | 139040 | 159 |
| KRvKN BTM | HRLEc @4096 | 68045 | 70 | 46586 | 55 | 411 | 323498 | 366 |
| KRvKN WTM | HRLEc @4096 | 46780 | 44 | 28452 | 34 | 253 | 169444 | 194 |
| KRvKN WTM | LZH @4096 | 54133 | 53 | 45160 | 53 | 248 | 185960 | 212 |
| KRvKP BTM | HRLEc @4096 | 149735 | 47 | 29369 | 35 | 541 | 390896 | 443 |
| KRvKP BTM | LZH @4096 | 91468 | 34 | 32805 | 39 | 252 | 188680 | 215 |
| KRvKP BTM pawn-7th slice | HRLEc @4096 | 52987 | 94 | 58802 | 69 | 438 | 323328 | 367 |
| KRvKP BTM pawn-7th slice | LZH @4096 | 32288 | 68 | 54375 | 63 | 241 | 181200 | 206 |
| KRvKP WTM | HRLEc @4096 | 40158 | 17 | 11461 | 15 | 265 | 182856 | 209 |
| KRvKP WTM | LZH @4096 | 51534 | 22 | 25575 | 30 | 213 | 162160 | 185 |
