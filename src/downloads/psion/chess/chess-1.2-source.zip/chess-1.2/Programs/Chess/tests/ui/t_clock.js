'use strict';
// Clock drift over an emulated hour (audit check 4).
//   node tests/ui/t_clock.js [minutes=60] [--profile]
// Plays against the computer with a 30|30 clock (level 7, natural pace, sound on) for the given
// emulated time; the player's moves are random legal moves (python-chess) after 5-40 s. The
// engine thinks, the book and the overlays are read from the pack, and the blips sound, as in a
// real game. Every call of the kernel's `board` with B_CLKSTART / B_CLKMOVED is caught (a
// breakpoint), so each turn's time is known three ways: emulated time (the CPU's cycles /
// 921,600), the OS's frame counter TMW_FRAM (what the game's clocks run on), and what the
// game charged to the clock (its value when the turn started, less its value after the move
// less the increment). Reports the frame counter's drift against emulated time, the clocks'
// against both, and the time between turns that no clock is charged with.
// --profile: also traces every instruction and lists the periods with interrupts masked
// (the OS's 50 ms tick waits until they end, and the OS restarts the tick from there, so a
// masked period of L ms loses L*L/100 ms on average if L < 50, about L - 25 ms if longer).
const { spawnSync } = require('child_process');
const L = require('./lib.js');
const G = require('./glib.js');
const { keys } = L;
const minutes = +(process.argv.find((a) => /^\d+$/.test(a)) || 60);
const profile = process.argv.includes('--profile');
const CLK = 921600;

let m = G.start();
const FRAM = 0x20CB;
let fr = m.peekw(FRAM), frHi = 0;
const frames = () => { const v = m.peekw(FRAM); if (v < fr) frHi += 65536; fr = v; return frHi + v; };
m.onChunk = frames;

// catch board(B_CLKSTART) and board(B_CLKMOVED) without stopping the drivers
const events = [];
const boardAt = L.sym(m, 'board'), gclk = L.sym(m, 'g_clk'), eside = L.sym(m, 'e_side');
const run0 = m.run;
m.run = (cycles) => {
  let left = cycles;
  while (left > 0) {
    const c0 = m.cycles();
    m.dbg.setBp(boardAt);
    const r = run0(left);
    left -= Math.max(1, m.cycles() - c0);
    if (r === boardAt) {
      const a = m.dbg.a();
      if (a === 7 || a === 4) events.push({ e: a === 7 ? 'start' : 'moved', cyc: m.cycles(), fr: frames(), clk: [m.peekw(gclk), m.peekw(gclk + 2)], side: m.peek(eside) ? 1 : 0, n: m.peek(L.sym(m, 'g_n')) });
      continue;
    }
    return r;
  }
  return -1;
};

// masked-interrupt profile
const masked = [];
if (profile) {
  let mStart = -1, mPc = 0;
  m.dbg.setTrace((pc) => {
    const i = (m.dbg.p() & 0x10) !== 0;
    if (i && mStart < 0) { mStart = m.cycles(); mPc = pc; } else if (!i && mStart >= 0) { masked.push([m.cycles() - mStart, mPc]); mStart = -1; }
  });
}

// the frame rate with nothing masked (the game idle at the start, no clock)
const c0 = m.cycles(), f0 = frames();
m.runSeconds(60);
const idleRate = (frames() - f0) / ((m.cycles() - c0) / CLK);
console.log('idle: ' + idleRate.toFixed(4) + ' frames per emulated second (nominal 20)');

G.setting(m, G.SET.CLOCK, ['RIGHT', 'RIGHT', 'RIGHT', 'RIGHT']);   // 30|30
if (L.peekSym(m, 'st_timing')[0] !== 4) throw new Error('clock not 30|30');
G.menu(m, ['N']); G.waitInput(m, 10);
events.length = 0;
const tStart = m.cycles(), fStart = frames();
let games = 1, moves = 0;
const rnd = (() => { let s = 12345; return () => { s = (s * 1103515245 + 12345) & 0x7fffffff; return s / 0x7fffffff; }; })();
while (m.cycles() - tStart < minutes * 60 * CLK) {
  if (!G.waitInput(m, 600)) throw new Error('no input wanted for 10 minutes\n' + m.screenText());
  if (L.peekSym(m, 'g_result')[0]) {                // the game ended: a new one
    console.log('  game ' + games + ' ended (' + L.peekSym(m, 'g_reason')[0] + ') after ' + L.peekSym(m, 'g_n')[0] + ' plies');
    keys(m, ['ON']); G.waitInput(m, 10); keys(m, ['EXE']); G.waitInput(m, 30); games++;
    continue;
  }
  m.runSeconds(5 + rnd() * 35);                    // the player thinks
  const r = spawnSync('python', ['-E', '-P', '-c', 'import chess,sys,random; b=chess.Board(sys.argv[1]); random.seed(int(sys.argv[2])); print(random.choice(list(b.legal_moves)).uci())', G.engFen(m) + ' 1', String(moves)], { encoding: 'utf8' });
  const u = r.stdout.trim();
  if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/.test(u)) throw new Error('no move from python for ' + G.engFen(m) + ': ' + r.stderr + ' / ' + m.screenText());
  G.typeUci(m, u);
  moves++;
}
const tEnd = m.cycles(), fEnd = frames();
m.dbg.setTrace(null);

// ---- turns: start -> moved (charged), moved -> next start (not charged)
let sumTrue = 0, sumFr = 0, sumChg = 0, gapTrue = 0, gapN = 0, turns = 0, worst = 0;
const inc = 600;                                      // 30 s
for (let i = 0; i + 2 < events.length; i++) {
  const a = events[i], b = events[i + 1], c = events[i + 2];
  if (a.e !== 'start' || b.e !== 'moved' || c.e !== 'start' || c.n !== a.n + 1) continue;
  const s = a.side;
  const charged = a.clk[s] - (c.clk[s] - inc);
  const byFr = b.fr - a.fr;
  const byTrue = (b.cyc - a.cyc) / CLK * 20;          // in 50 ms frames
  sumTrue += byTrue; sumFr += byFr; sumChg += charged; turns++;
  worst = Math.max(worst, Math.abs(charged - byFr));
  gapTrue += (c.cyc - b.cyc) / CLK; gapN++;
  if (process.argv.includes('--verbose')) console.log(`  ply ${a.n} ${s ? 'Black' : 'White'}: clock ${a.clk[s]} -> ${c.clk[s]}, charged ${charged}, frames ${byFr}, emulated ${byTrue.toFixed(1)}`);
}
const T = (tEnd - tStart) / CLK;
console.log(`played ${(T / 60).toFixed(1)} emulated minutes: ${games} game(s), ${moves} player moves, ${turns} timed turns`);
console.log(`frame counter: ${fEnd - fStart} frames in ${T.toFixed(1)} s = ${((fEnd - fStart) / T).toFixed(4)} a second; drift ${(((fEnd - fStart) / 20 - T) / T * 3600).toFixed(1)} s per hour against emulated time`);
console.log(`turns: emulated ${(sumTrue / 20).toFixed(1)} s, frame counter ${(sumFr / 20).toFixed(1)} s, charged to the clocks ${(sumChg / 20).toFixed(1)} s`);
console.log(`  clocks against the frame counter: ${((sumChg - sumFr) / 20).toFixed(2)} s in all, worst turn ${worst} frames`);
console.log(`  clocks against emulated time: ${((sumChg - sumTrue) / 20).toFixed(1)} s = ${(((sumChg - sumTrue) / sumTrue) * 3600).toFixed(1)} s per hour of clock time`);
console.log(`between turns (no clock running): ${gapTrue.toFixed(1)} s in ${gapN} gaps, ${(gapTrue / gapN).toFixed(2)} s each`);
if (profile) {
  masked.sort((a, b) => b[0] - a[0]);
  const ms = (c) => (c / CLK * 1000);
  const hist = { '<1ms': 0, '1-5ms': 0, '5-20ms': 0, '20-50ms': 0, '>50ms': 0 };
  let loss = 0;
  const P = 50;
  for (const [c] of masked) {
    const l = ms(c);
    hist[l < 1 ? '<1ms' : l < 5 ? '1-5ms' : l < 20 ? '5-20ms' : l < 50 ? '20-50ms' : '>50ms']++;
    loss += l < P ? l * l / (2 * P) : l - P / 2;
  }
  console.log('masked periods:', JSON.stringify(hist), 'expected tick loss on hardware ' + (loss / 1000).toFixed(2) + ' s in ' + T.toFixed(0) + ' s = ' + (loss / 1000 / T * 3600).toFixed(1) + ' s per hour');
  const by = {};
  for (const [c, pc] of masked) { if (ms(c) < 1) continue; const k = pc.toString(16); by[k] = by[k] || [0, 0, 0]; by[k][0]++; by[k][1] += ms(c); by[k][2] = Math.max(by[k][2], ms(c)); }
  console.log('masked >= 1 ms, by the address masking began (count, total ms, longest ms):');
  for (const [k, v] of Object.entries(by).sort((a, b) => b[1][1] - a[1][1]).slice(0, 15)) console.log('  $' + k + ': ' + v[0] + ', ' + v[1].toFixed(0) + ', ' + v[2].toFixed(1));
}
console.log('base of the array $' + L.base(m).toString(16));
