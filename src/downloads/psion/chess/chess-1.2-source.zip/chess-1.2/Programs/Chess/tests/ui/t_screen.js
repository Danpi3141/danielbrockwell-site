'use strict';
// Screen round trip (audit check 2): the emulator's LCD is read back into a position and
// compared with python-chess's position after every ply of random games.
//   node tests/ui/t_screen.js [--quick | --smoke]   (--smoke: four short games, for run_all)
// Nothing of the game's memory is used to read the screen: the rank numbers in column 8 give
// the ranks shown and whether the board is turned (then the files run h..a); letters give the
// pieces (capitals White), an empty square must show the diamond if dark and a space if light;
// the map's cells are decoded from the glyph bitmaps the LCD holds (a hollow 5x3 block White,
// solid Black, blank empty; upper square in rows 0-2, lower in rows 4-6).
//   letters and map: both halves of the letter view (MODE shows the other) and the map
//   split board: all 64 squares
//   real-board mode shows no position: its text is checked by t_notat.js
// Each layout is played with the board as White sees it and turned (FLIP), so both colours'
// views and both sides to move are covered; the games include promotions and under-promotions.
const L = require('./lib.js');
const G = require('./glib.js');
const { keys } = L;
const smoke = process.argv.includes('--smoke');
const quick = smoke || process.argv.includes('--quick');

let fails = 0, checked = 0;
function soft(cond, msg) { checked++; if (!cond) { fails++; if (fails < 30) console.log('FAIL ' + msg); } return cond; }

const games = G.games('screen', ['--random', quick ? '4' : '12', '--seed', '300', '--maxply', smoke ? '24' : quick ? '60' : '120']).concat(
  G.games('crafted', ['--crafted']).filter((g) => /promotion|black to move|three queens/.test(g.name)));

let m = G.start();
G.twoPlayers(m);

function checkMap(g, i, want, flippedWant) {
  const a = G.decodeMapLayout(m);
  keys(m, ['MODE']); G.waitInput(m, 5);
  const b = G.decodeMapLayout(m);
  keys(m, ['MODE']); G.waitInput(m, 5);
  const letters = Object.assign({}, a.letters, b.letters);
  let got = '';
  for (let q = 0; q < 64; q++) got += letters[q] === undefined ? '?' : letters[q];
  const tag = g.name + ' ply ' + i + (flippedWant ? ' (turned)' : '');
  soft(!a.errors.length && !b.errors.length, tag + ': ' + a.errors.concat(b.errors).join(', '));
  soft(a.flipped === flippedWant && b.flipped === flippedWant, tag + ': the board is ' + (a.flipped ? '' : 'not ') + 'turned');
  soft(got === want, tag + ': letters ' + got + '\n  expected ' + want + '\n' + m.screenText());
  const wantMap = want.split('').map(G.colourOf).join('');
  soft(a.map === wantMap && b.map === wantMap, tag + ': map ' + a.map + '\n  expected ' + wantMap);
}
function checkSplit(g, i, want, flippedWant) {
  const d = G.decodeSplit(m);
  const tag = g.name + ' ply ' + i + (flippedWant ? ' (turned)' : '');
  soft(!d.errors.length && d.flipped === flippedWant, tag + ': split ' + d.errors.join(', ') + ' turned=' + d.flipped);
  soft(d.squares === want, tag + ': split ' + d.squares + '\n  expected ' + want + '\n' + m.screenText());
}
function turnShown(g, i, fen, col) {
  // with no clock the strip's row 3 shows whose turn it is (W / B)
  const t = m.screen()[3].slice(col, col + 3).trim();
  soft(t === (fen.split(' ')[1] === 'w' ? 'W' : 'B'), g.name + ' ply ' + i + ': turn shown "' + t + '"');
}

const runs = [['map', false], ['map', true], ['split', false], ['split', true]];
let gi = 0;
for (const [layout, flipped] of runs) {
  if (layout === 'split' && !flipped) G.setting(m, G.SET.BOARD, ['RIGHT']);
  const set = smoke ? games.slice(gi / 2, gi / 2 + 1) : quick ? games.slice(gi, gi + 2) : games.filter((_, k) => k % 4 === runs.findIndex((r) => r[0] === layout && r[1] === flipped) || /promotion|black to move|three queens/.test(_.name));
  gi += 2;
  for (const g of set) {
    const each = (i, p) => {
      const want = G.fenSquares(p.fen);
      if (layout === 'map') { checkMap(g, i + 1, want, flipped); turnShown(g, i + 1, p.fen, 9); } else { checkSplit(g, i + 1, want, flipped); turnShown(g, i + 1, p.fen, 17); }
    };
    let begun = false;
    const ok = G.playGame(m, g, each, { begin: () => {
      // FLIP turns the board (in two-player mode it changes nothing else)
      const isFlipped = (layout === 'map' ? G.decodeMapLayout(m) : G.decodeSplit(m)).flipped;
      if (isFlipped !== flipped) { G.menu(m, ['F']); G.waitInput(m, 10); }
      begun = true;
    } });
    soft(ok && begun, g.name + ': a move was refused\n' + m.screenText());
    if (!ok) { m = G.start(); G.twoPlayers(m); if (layout === 'split') G.setting(m, G.SET.BOARD, ['RIGHT']); }
  }
  console.log((fails ? 'FAIL ' : 'ok   ') + layout + (flipped ? ', turned' : '') + ': ' + set.length + ' games, ' + set.reduce((a, g) => a + g.plies.length, 0) + ' positions read back');
}
G.setting(m, G.SET.BOARD, ['LEFT']);
console.log(checked + ' checks, ' + fails + ' failures');
if (fails) process.exit(1);
console.log('all screen round-trip tests passed');
