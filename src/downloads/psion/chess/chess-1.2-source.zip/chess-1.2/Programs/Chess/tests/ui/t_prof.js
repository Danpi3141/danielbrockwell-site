// Where a move cycle spends its time (kernel routines timed with breakpoints at entry and return)
const L = require('./lib.js');
const m = L.start(); L.idle(m);
const S = L.syms(); const b = L.base(m);
const names = ['pos_update','ov_load','eng_play','strip_cells','scr_flush'];
const prof = {}; names.forEach(n=>prof[n]={n:0,c:0});
// wrap: trace PC; on entry push (name, cycles, sp); on return when sp back
const entry = {}; names.forEach(n=>{ entry[b+S[n][0]] = n; });
const stack = [];
m.dbg.setTrace((pc)=>{ const n = entry[pc]; if (n) stack.push([n, m.cycles(), m.dbg.sp()]);
  if (stack.length) { const top = stack[stack.length-1]; if (m.peek(pc)===0x39 && m.dbg.sp()===top[2]) { /* rts at same sp */ prof[top[0]].n++; prof[top[0]].c += m.cycles()-top[1]; stack.pop(); } } });
const keys=['E','V','E','O']; const c0=m.cycles();
L.keys(m, keys); L.idle(m);
m.dbg.setTrace(null);
console.log('total', ((m.cycles()-c0)/921600).toFixed(2), 's');
for (const n of names) console.log(n.padEnd(12), prof[n].n, (prof[n].c/921600).toFixed(2)+' s');
