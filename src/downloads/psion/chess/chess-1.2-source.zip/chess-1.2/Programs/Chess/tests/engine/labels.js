'use strict';
// Code labels of the test image (from the listing), for profiles and call counts.
const fs = require('fs'), path = require('path');
function labels(base) {
  const out = [];
  const lst = fs.readFileSync(path.join(__dirname, 'out', 'etest.lst'), 'utf8').split('\n');
  for (const line of lst) {
    const m = line.match(/^([0-9A-F]{4})  \S*\s+([A-Za-z_]\w*):/);
    if (m) out.push([parseInt(m[1], 16) + base, m[2]]);
  }
  out.sort((a, b) => a[0] - b[0]);
  return out;
}
function namer(base) {
  const ls = labels(base);
  return (pc) => { let lo = 0, hi = ls.length - 1, r = '?'; while (lo <= hi) { const m = (lo + hi) >> 1; if (ls[m][0] <= pc) { r = ls[m][1]; lo = m + 1; } else hi = m - 1; } return r; };
}
module.exports = { labels, namer };
