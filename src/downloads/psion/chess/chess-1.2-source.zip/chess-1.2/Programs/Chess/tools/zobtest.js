'use strict';
// Key quality: the current Zobrist keys (384 piece keys) against keys made from 64 square keys
// (a piece's key = its square's key rotated left by type-1 bits; Black bytes rotated as now).
//   node tools/zobtest.js [trees=300] [depth=3]
// 1. Search-tree test: for positions from real games, every distinct position within `depth`
//    plies (what one search meets); count pairs of different positions with the same 24-bit key.
// 2. Whole-sample test: all distinct positions from all trees together.
// Ideal (random keys): pairs = n(n-1)/2 / 2^24.
const fs = require('fs');
const path = require('path');
const S = require('../ref/search.js');
const T = require('../ref/tables.js');
const { Engine, legalMoves } = S;

const sq64 = (s) => (s + (s & 7)) >> 1;
const ROTS = [0].concat((process.env.ROTS || '0,1,2,3,4,5').split(',').map(Number));
const rot24 = (k, r) => (r ? (((k << r) | (k >>> (24 - r))) & 0xFFFFFF) : k);
const brot = (k) => (((k << 8) & 0xFFFFFF) | (k >>> 16));
function keyOf(e, z64) {
  let k = 0;
  for (let s = 0; s < 128; s++) {
    if (s & 0x88) { s += 7; continue; }
    const pc = e.b[s];
    if (!pc) continue;
    let z = z64 ? rot24(T.ZOB64[sq64(s)], ROTS[pc & 7]) : T.ZOB[((pc & 7) - 1) * 64 + sq64(s)];
    if (pc & 8) z = brot(z);
    k ^= z;
  }
  if (e.side) k ^= T.ZOB[384];
  for (let i = 0; i < 4; i++) if (e.castle & (1 << i)) k ^= T.ZOB[385 + i];
  if (e.ep !== 0xFF) k ^= T.ZOB[389 + (e.ep & 7)];
  return k >>> 0;
}
function posId(e) { return Buffer.from(e.b).toString('latin1') + e.side + ',' + e.castle + ',' + e.ep; }

// start positions: random games of 6-45 plies
const trees = +(process.argv[2] || 300), depth = +(process.argv[3] || 3);
const starts = [];
{
  const e = new Engine();
  let seed = +(process.env.SEED || 12345);
  const rnd = (n) => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed % n; };
  for (let g = 0; starts.length < trees; g++) {
    e.setFen('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'); e.ply = 0;
    const n = 6 + rnd(40);
    let ok = true;
    for (let i = 0; i < n; i++) {
      const ms = legalMoves(e);
      if (!ms.length) { ok = false; break; }
      const m = ms[rnd(ms.length)];
      e.make(m[0], m[1]); e.ply = 0;
    }
    if (ok) starts.push({ b: Uint8Array.from(e.b), side: e.side, castle: e.castle, ep: e.ep });
  }
}
function load(e, st) {
  e.b.set(st.b); e.side = st.side; e.castle = st.castle; e.ep = st.ep; e.recompute(); e.ply = 0;
}

function walk(e, d, seen) {
  const id = posId(e);
  if (seen.has(id)) return;
  seen.set(id, [keyOf(e, false), keyOf(e, true)]);
  if (!d) return;
  for (const m of legalMoves(e)) { e.make(m[0], m[1]); walk(e, d - 1, seen); e.unmake(); }
}
function pairs(keys) {
  const c = new Map();
  for (const k of keys) c.set(k, (c.get(k) || 0) + 1);
  let p = 0;
  for (const v of c.values()) p += v * (v - 1) / 2;
  return p;
}

const e = new Engine();
let tot = [0, 0], ideal = 0, nTot = 0;
const all = new Map();
for (const st of starts) {
  load(e, st);
  const seen = new Map();
  walk(e, depth, seen);
  const n = seen.size;
  nTot += n;
  ideal += n * (n - 1) / 2 / 2 ** 24;
  const ks = [...seen.values()];
  tot[0] += pairs(ks.map((k) => k[0]));
  tot[1] += pairs(ks.map((k) => k[1]));
  for (const [id, k] of seen) all.set(id, k);
}
console.log(`search trees: ${starts.length} positions x ${depth} plies, ${nTot} distinct positions`);
console.log(`  same-key pairs within a tree: current ${tot[0]}, 64-key ${tot[1]}, ideal ${ideal.toFixed(1)}`);
const ka = [...all.values()];
const n = ka.length;
console.log(`whole sample: ${n} distinct positions`);
console.log(`  same-key pairs: current ${pairs(ka.map((k) => k[0]))}, 64-key ${pairs(ka.map((k) => k[1]))}, ideal ${(n * (n - 1) / 2 / 2 ** 24).toFixed(1)}`);
