#!/bin/sh
# Level strengths for the audited engine (snap_v4), 16 Nov. Nodes = level seconds x ~70 nodes/s
# (83/s measured before, the audit's quiescence change costs ~18%). Margins from lv_marg.
M="python -E -P match.py"
O="--openings 0:242 --workers 10"
$M lv4_L4_sf1320 snap_v4:Nodes=210,Margin=30 sf:1320 $O > logs_lv4_L4_sf1320.txt 2>&1
$M lv4_L5_sf1320 snap_v4:Nodes=350 sf:1320 $O > logs_lv4_L5_sf1320.txt 2>&1
$M lv4_L6_sf1320 snap_v4:Nodes=700 sf:1320 $O > logs_lv4_L6_sf1320.txt 2>&1
$M lv4_L6_sf1500 snap_v4:Nodes=700 sf:1500 $O > logs_lv4_L6_sf1500.txt 2>&1
$M lv4_L3_L4 snap_v4:Nodes=140,Margin=70 snap_v4:Nodes=210,Margin=30 $O > logs_lv4_L3_L4.txt 2>&1
$M lv4_L2_L3 snap_v4:Nodes=70,Margin=150 snap_v4:Nodes=140,Margin=70 $O > logs_lv4_L2_L3.txt 2>&1
$M lv4_L1_L2 snap_v4:Nodes=70,Margin=300 snap_v4:Nodes=70,Margin=150 $O > logs_lv4_L1_L2.txt 2>&1
$M lv4_L8_sf1700 snap_v4:Nodes=7000 sf:1700 $O > logs_lv4_L8_sf1700.txt 2>&1
$M lv4_L8_sf1800 snap_v4:Nodes=7000 sf:1800 $O > logs_lv4_L8_sf1800.txt 2>&1
for f in logs_lv4_*.txt; do echo "$f: $(tail -1 $f)"; done
