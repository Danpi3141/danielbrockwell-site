'use strict';
// Perft: counts leaf positions to a fixed depth. Known totals catch move-generation bugs.
const { Engine } = require('./engine.js');

function perft(e, depth, ply) {
  if (depth === 0) return 1;
  e.mvTop[ply + 1] = e.mvTop[ply] + e.gen(ply, false);
  let total = 0;
  for (let i = e.mvTop[ply]; i < e.mvTop[ply + 1]; i++) {
    const f = e.mv[i * 3], t = e.mv[i * 3 + 1];
    if (e.make(f, t)) total += perft(e, depth - 1, ply + 1);
    e.unmake();
  }
  return total;
}

const CASES = [
  ['rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', [20, 400, 8902, 197281, 4865609]],
  ['r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1', [48, 2039, 97862, 4085603]],
  ['8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1', [14, 191, 2812, 43238, 674624]],
  ['r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1', [6, 264, 9467, 422333]],
  ['rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8', [44, 1486, 62379, 2103487]],
  ['r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10', [46, 2079, 89890, 3894594]],
];

if (require.main === module) {
  const e = new Engine();
  let bad = 0;
  const maxD = +(process.argv[2] || 5);
  for (const [fen, counts] of CASES) {
    e.setFen(fen);
    e.mvTop[0] = 0;
    for (let d = 1; d <= Math.min(maxD, counts.length); d++) {
      const t0 = Date.now();
      const n = perft(e, d, 0);
      const ok = n === counts[d - 1];
      if (!ok) bad++;
      console.log(`${ok ? 'ok  ' : 'FAIL'} d${d} ${n} (want ${counts[d - 1]}) ${Date.now() - t0}ms  ${fen.slice(0, 30)}`);
    }
  }
  console.log(bad ? `${bad} FAILED` : 'all perft counts match');
  process.exit(bad ? 1 : 0);
}
module.exports = { perft, CASES };
