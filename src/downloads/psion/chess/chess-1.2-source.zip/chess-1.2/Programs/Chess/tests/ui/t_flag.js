'use strict';
// A flag falling (kclock.asm clk_tick, 17 Nov): the other side wins on time, unless it has only
// its king, which cannot mate by any series of moves: then the game is drawn (FIDE 6.9; it won
// before). A king and one minor against more material can mate by some series: a win. Each case:
// a 5|5 clock, a position set up with the player (White) to move, the player's clock run out.
//   node tests/ui/t_flag.js
const L = require('./lib.js');
const G = require('./glib.js');
const { check } = L;

const CASES = [
  // [position, want g_result, g_reason, what]
  ['4k3/8/8/8/8/8/8/3QK3 w - - 0 1', 3, 5, 'Black has only its king: drawn, no mating material'],
  ['r3k3/8/8/8/8/8/8/4K3 w - - 0 1', 2, 7, 'Black has a rook: Black wins on time'],
  ['4k3/8/8/3n4/8/8/4P3/4K3 w - - 0 1', 2, 7, 'Black has a knight, White a pawn: Black wins on time'],
];
for (const [fen, res, why, what] of CASES) {
  const m = G.start();
  G.setting(m, G.SET.CLOCK, ['RIGHT']);              // 5|5
  G.menu(m, ['N']); G.waitInput(m, 10);              // NEW GAME takes the clock
  G.setupFen(m, fen);
  check(L.peekSym(m, 'g_result')[0] === 0 && m.peekw(L.sym(m, 'g_clk')) > 5000, `${fen}: set up, White's clock ${m.peekw(L.sym(m, 'g_clk'))} frames`, m);
  m.runSeconds(330);
  if (!m.isOn()) { m.press('ON', 3, 10); m.runSeconds(2); }
  L.idle(m);
  const got = [L.peekSym(m, 'g_result')[0], L.peekSym(m, 'g_reason')[0]];
  check(got[0] === res && got[1] === why, `${what} (result ${got})`, m);
  check(m.screenText().includes(res === 3 ? 'NO MATING MATERIAL' : 'ON TIME'), 'the result screen: ' + m.screen()[1].trim(), m);
}
console.log('all UI tests passed');
