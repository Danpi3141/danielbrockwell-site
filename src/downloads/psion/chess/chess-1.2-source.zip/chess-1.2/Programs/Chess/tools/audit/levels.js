'use strict';
// The game's levels (src/kernel/kcore.asm: lv_secs = 1,1,2,3,5,10,30,100 s; lv_marg = 300,150,70,30 cp
// for levels 1-4) reproduced on the JS reference: time becomes nodes at NPS nodes a second, the
// engine stops at once when the limit is reached (after depth 1) and starts no new depth after
// half of it (think's `soft` rule, as eng_think with e_tlim). The margin pass is unlimited, as on
// the Psion (e_marg clears the limits).
const path = require('path');
const NPS = +(process.env.AUDIT_NPS || 100);
const SECS = [0, 1, 1, 2, 3, 5, 10, 30, 100];
const MARG = [0, 300, 150, 70, 30, 0, 0, 0, 0];

function levelNodes(lv) { return SECS[lv] * NPS; }
// e: an Engine (ref/search.js or a snapshot); returns think()'s result
function levelThink(e, lv) {
  return e.think(levelNodes(lv), 40, MARG[lv], true);
}
function loadEngine(dir) {
  const d = dir ? path.resolve(dir) : path.join(__dirname, '..', '..', 'ref');
  return require(path.join(d, 'search.js'));
}
module.exports = { NPS, SECS, MARG, levelNodes, levelThink, loadEngine };
