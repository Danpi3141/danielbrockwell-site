// Compress the king-and-pawn distance table (data/kpkd.bin, 48K) into data/kpkdz.bin for the pack.
//
// Entries (4-bit distances as in kpkd.bin) are taken in the order e = (p * 64 + wk) * 64 + sk
// (the pawn, the defending king, then the pawn's side's king) and cut into 96 blocks of 1024.
// Positions that can't occur (kings on the same or next squares, a king on the pawn, the
// defender in check with the pawn's side to move) take the value before them, so runs grow.
// Each block is a list of runs (value, length), byte-aligned, each run a Huffman code for
// (value, length class k) then k extra bits: length = 1 for k = 0, else 2^k + the extra bits.
// One canonical Huffman code serves all blocks; codes and bits are read MSB first.
//
// kpkdz.bin:  0      97 words: the offset of each block's data (and of the end), big-endian
//             194    16 bytes: how many codes of each length 1..16
//             210    the symbols in code order, one byte each: value << 4 | k
//             then   the blocks
// The decoder is ref/kpkroot.js (lookZ) and the Psion's OV_KPK. This checks every entry that
// can occur against kpkd.bin.
//   node tools/kpk/kpkd_pack.js
'use strict';
const fs = require('fs');
const path = require('path');
const DATA = path.join(__dirname, '..', '..', 'data');
const RAW = fs.readFileSync(path.join(DATA, 'kpkd.bin'));
const { lookZ } = require('../../ref/kpkroot.js');
const N = 24 * 64 * 64, BLK = 1024, NB = N / BLK;
const raw = (i) => (i & 1 ? RAW[i >> 1] >> 4 : RAW[i >> 1] & 15);       // kpkd.bin order: (p, sk, wk)
const dist = (a, b) => Math.max(Math.abs((a & 7) - (b & 7)), Math.abs((a >> 3) - (b >> 3)));
function legal(p6, sk, wk) {
  const p = ((p6 >> 2) + 1) * 8 + (p6 & 3);
  if (wk === sk || wk === p || sk === p || dist(wk, sk) < 2) return false;
  if ((wk >> 3) === (p >> 3) + 1 && Math.abs((wk & 7) - (p & 7)) === 1) return false;
  return true;
}
// the sequence in the new order, don't-care filled
const seq = new Uint8Array(N), care = new Uint8Array(N);
let last = 0;
for (let p = 0; p < 24; p++) for (let wk = 0; wk < 64; wk++) for (let sk = 0; sk < 64; sk++) {
  const e = (p * 64 + wk) * 64 + sk;
  if (legal(p, sk, wk)) { last = raw((p * 64 + sk) * 64 + wk); care[e] = 1; }
  seq[e] = last;
}
const CLASS = (n) => { let k = 0; while ((1 << (k + 1)) <= n) k++; return k; };
// runs per block
const blocks = [];
for (let b = 0; b < NB; b++) {
  const runs = [];
  for (let j = b * BLK; j < (b + 1) * BLK;) { let k = j; while (k < (b + 1) * BLK && seq[k] === seq[j]) k++; runs.push([seq[j], k - j]); j = k; }
  blocks.push(runs);
}
// Huffman lengths (limited to 16 by flattening the rarest if needed)
const counts = new Map();
for (const runs of blocks) for (const [v, n] of runs) { const s = (v << 4) | CLASS(n); counts.set(s, (counts.get(s) || 0) + 1); }
function lens(counts) {
  let nodes = [...counts].map(([s, c]) => ({ c, syms: [s] }));
  const len = new Map(nodes.map((n) => [n.syms[0], 0]));
  if (nodes.length === 1) { len.set(nodes[0].syms[0], 1); return len; }
  while (nodes.length > 1) {
    nodes.sort((a, b) => a.c - b.c);
    const a = nodes.shift(), b = nodes.shift();
    for (const s of a.syms.concat(b.syms)) len.set(s, len.get(s) + 1);
    nodes.push({ c: a.c + b.c, syms: a.syms.concat(b.syms) });
  }
  return len;
}
let len = lens(counts);
for (let tries = 0; Math.max(...len.values()) > 16 && tries < 20; tries++) {   // flatten: raise the rarest counts
  for (const [s, c] of counts) counts.set(s, Math.max(c, 1 << tries));
  len = lens(counts);
}
const maxL = Math.max(...len.values());
if (maxL > 16) throw new Error('code lengths over 16');
// canonical codes
const syms = [...len].sort((a, b) => a[1] - b[1] || a[0] - b[0]);
const cnt = new Array(17).fill(0);
for (const [, l] of syms) cnt[l]++;
const code = new Map();
{ let c = 0, prevL = syms[0][1]; for (const [s, l] of syms) { c <<= (l - prevL); prevL = l; code.set(s, [c, l]); c++; } }
// the blocks as bits
const datas = blocks.map((runs) => {
  const bits = [];
  const put = (v, n) => { for (let i = n - 1; i >= 0; i--) bits.push((v >> i) & 1); };
  for (const [v, n] of runs) {
    const k = CLASS(n), [c, l] = code.get((v << 4) | k);
    put(c, l);
    if (k) put(n - (1 << k), k);
  }
  const out = Buffer.alloc(Math.ceil(bits.length / 8));
  bits.forEach((b, i) => { if (b) out[i >> 3] |= 0x80 >> (i & 7); });
  return out;
});
const head = 194 + 16 + syms.length;
const blob = Buffer.alloc(head + datas.reduce((a, d) => a + d.length, 0));
let at = head;
for (let b = 0; b <= NB; b++) {
  blob.writeUInt16BE(at, 2 * b);
  if (b < NB) { datas[b].copy(blob, at); at += datas[b].length; }
}
for (let l = 1; l <= 16; l++) blob[194 + l - 1] = cnt[l];
syms.forEach(([s], i) => { blob[210 + i] = s; });
fs.writeFileSync(path.join(DATA, 'kpkdz.bin'), blob);
// check: every entry that can occur decodes to kpkd.bin's value
let bad = 0, checked = 0;
for (let p = 0; p < 24; p++) for (let sk = 0; sk < 64; sk++) for (let wk = 0; wk < 64; wk++) {
  if (!legal(p, sk, wk)) continue;
  checked++;
  if (lookZ.entry(blob, p, sk, wk) !== raw((p * 64 + sk) * 64 + wk)) bad++;
}
const maxBlock = Math.max(...datas.map((d) => d.length));
console.log(`kpkdz.bin: ${blob.length} bytes (from 49,152): ${syms.length} symbols, codes up to ${maxL} bits, largest block ${maxBlock} bytes`);
console.log(`checked ${checked} entries that can occur: ${bad} wrong`);
// the Psion's buffer for the code table (src/screens/ov_kpk.asm): kk_syms 128
if (syms.length > 128) { console.log('too many symbols for the Psion buffer'); process.exit(1); }
if (bad) process.exit(1);
