'use strict';
// Evaluation and search for the reference engine. Mirrors the assembler step for step:
// the order of every test matters, because node counts are compared.
const E = require('./engine.js');
const T = require('./tables.js');
const { Engine, P, N, B, R, Q, K, BLACK, INF, MATE, MATE_BOUND, MAXPLY, MVCAP, sq64 } = E;

const POP = new Uint8Array(256);
for (let i = 1; i < 256; i++) POP[i] = POP[i >> 1] + (i & 1);
// centre Manhattan distance by sq64
const CMD = new Uint8Array(64);
for (let s = 0; s < 64; s++) {
  const f = s & 7, r = s >> 3;
  CMD[s] = Math.max(3 - f, f - 4) + Math.max(3 - r, r - 4);
}
function dist(a, b) { // king distance between 0x88 squares
  return Math.max(Math.abs((a & 7) - (b & 7)), Math.abs((a >> 4) - (b >> 4)));
}
function mdist(a, b) { // Manhattan distance between 0x88 squares
  return Math.abs((a & 7) - (b & 7)) + Math.abs((a >> 4) - (b >> 4));
}

// TT entry fields (assembler: 7 bytes: key16, from, to, score16, depth<<2 | flag; depth is 1-41, so 6 bits hold it)
const TT_EXACT = 1, TT_LOWER = 2, TT_UPPER = 3;

Object.assign(Engine.prototype, {
  // ---------------- evaluation (score from the side to move's point of view) ----------------
  evaluate() {
    const c = this.cnt, pm = this.pm;
    let mgD = this.mg[0] - this.mg[1];
    let egD = this.eg[0] - this.eg[1];
    // pawn structure
    for (let f = 0; f < 8; f++) {
      const w = pm[f], bl = pm[8 + f];
      if (w) {
        const n = POP[w];
        if (n > 1) { mgD -= 10 * (n - 1); egD -= 20 * (n - 1); }
        const nb = (f > 0 ? pm[f - 1] : 0) | (f < 7 ? pm[f + 1] : 0);
        if (!nb) { mgD -= 10 * n; egD -= 15 * n; }
        const opp = (f > 0 ? pm[8 + f - 1] : 0) | bl | (f < 7 ? pm[8 + f + 1] : 0);
        for (let r = 1; r < 7; r++) {
          if (!(w & (1 << r))) continue;
          if ((opp >> (r + 1)) === 0) { mgD += T.PASS_MG[r]; egD += T.PASS_EG[r]; }
        }
      }
      if (bl) {
        const n = POP[bl];
        if (n > 1) { mgD += 10 * (n - 1); egD += 20 * (n - 1); }
        const nb = (f > 0 ? pm[8 + f - 1] : 0) | (f < 7 ? pm[8 + f + 1] : 0);
        if (!nb) { mgD += 10 * n; egD += 15 * n; }
        const opp = (f > 0 ? pm[f - 1] : 0) | w | (f < 7 ? pm[f + 1] : 0);
        for (let r = 1; r < 7; r++) {
          if (!(bl & (1 << r))) continue;
          if ((opp & ((1 << r) - 1)) === 0) { mgD -= T.PASS_MG[7 - r]; egD -= T.PASS_EG[7 - r]; }
        }
      }
    }
    if (c[B] >= 2) { mgD += 25; egD += 40; }
    if (c[8 + B] >= 2) { mgD -= 25; egD -= 40; }
    // experimental terms (16 Nov), off by default: opts.rookFile = [openMg, openEg, halfMg, halfEg],
    // opts.kingShield = [one rank further back, no pawn] middlegame penalties per file
    if (this.opts.rookFile) {
      const [om, oe, hm, he] = this.opts.rookFile, bd = this.b;
      for (let s = 0; s < 128; s++) {
        if (s & 0x88) { s += 7; continue; }
        const p = bd[s];
        if ((p & 7) !== R) continue;
        const f = s & 7, blk = p & BLACK;
        if (blk ? pm[8 + f] : pm[f]) continue;               // own pawn on the file
        const opp = blk ? pm[f] : pm[8 + f];
        const m = opp ? hm : om, e = opp ? he : oe;
        if (blk) { mgD -= m; egD -= e; } else { mgD += m; egD += e; }
      }
    }
    if (this.opts.kingShield) {
      const [one, none] = this.opts.kingShield;
      for (let col = 0; col < 2; col++) {
        const k = this.ksq[col], r = k >> 4, f = k & 7;
        if ((col ? 7 - r : r) > 1) continue;                 // only a king on its first two ranks
        const a1 = col ? r - 1 : r + 1, a2 = col ? r - 2 : r + 2;
        let pen = 0;
        for (let ff = f > 0 ? f - 1 : 0; ff <= (f < 7 ? f + 1 : 7); ff++) {
          const m = pm[col * 8 + ff];
          if (m & (1 << a1)) continue;
          pen += (m & (1 << a2)) ? one : none;
        }
        if (col) mgD += pen; else mgD -= pen;
      }
    }
    if (mgD > 2000) mgD = 2000; else if (mgD < -2000) mgD = -2000;
    if (egD > 2000) egD = 2000; else if (egD < -2000) egD = -2000;
    const ph = T.PH16[this.phase > 24 ? 24 : this.phase];
    let x = mgD * ph + egD * (16 - ph);
    if (x < 0) x += 15;                       // round towards zero, so colour-flipped twins score alike
    let s = x >> 4;
    s = this.endgame(s);
    if (this.noise) s += ((((this.key ^ this.nseed) & 0xFF) - 128) * this.noise) >> 4;
    return this.side ? -s : s;
  },

  // Endgame rules on a White-point-of-view score.
  endgame(s) {
    const c = this.cnt;
    const wMin = c[N] + c[B], bMin = c[8 + N] + c[8 + B];
    const wMaj = c[R] + c[Q], bMaj = c[8 + R] + c[8 + Q];
    // a side with no pawns and only a lone minor, or two knights, cannot win
    if (s > 0 && c[P] === 0 && wMaj === 0 && (wMin <= 1 || (c[N] === 2 && c[B] === 0))) s = 0;
    if (s < 0 && c[8 + P] === 0 && bMaj === 0 && (bMin <= 1 || (c[8 + N] === 2 && c[8 + B] === 0))) s = 0;
    // bare king: drive it to the edge (or the right corner for B+N), bring the other king near
    const bBare = bMin + bMaj + c[8 + P] === 0, wBare = wMin + wMaj + c[P] === 0;
    if (bBare && !wBare && s > 0) s += this.mopup(1, s);
    else if (wBare && !bBare && s < 0) s -= this.mopup(0, -s);
    if (s > 3000) s = 3000; else if (s < -3000) s = -3000;
    return s;
  },

  // Bonus for the side whose opponent (colour `lc`) has a bare king.
  mopup(lc, s) {
    const lk = this.ksq[lc], wk = this.ksq[lc ^ 1];
    const wc = (lc ^ 1) * 8, c = this.cnt;
    let edge;
    if (c[wc + Q] + c[wc + R] === 0 && c[wc + B] === 1 && c[wc + N] >= 1) {
      // bishop and knight: corner of the bishop's colour
      let bs = 0;
      for (let q = 0; q < 128; q++) { if (q & 0x88) { q += 7; continue; } if (this.b[q] === (B | wc)) { bs = q; break; } }
      const dark = ((bs & 7) + (bs >> 4)) % 2 === 0; // a1 is dark
      const d1 = dark ? Math.min(mdist(lk, 0x00), mdist(lk, 0x77)) : Math.min(mdist(lk, 0x07), mdist(lk, 0x70));
      edge = 7 * (14 - d1) + CMD[sq64(lk)];
    } else {
      edge = CMD[sq64(lk)];
    }
    // weights tuned by tools/audit/tune_mop.js (were 20, 6 and 5): KBNK mates 45% -> ~83%, KQK 88% -> 100%
    return 16 * edge + 20 * (14 - mdist(lk, wk));
  },

  // ---------------- search ----------------
  ttInit(bits) {
    this.ttBits = bits;
    const n = 1 << bits;
    this.ttKey = new Uint16Array(n); this.ttF = new Uint8Array(n); this.ttT = new Uint8Array(n);
    this.ttS = new Int16Array(n); this.ttD = new Int8Array(n); this.ttFlag = new Uint8Array(n);
  },

  isRepOrFifty() {
    if (this.half >= 100) return true;
    const ks = this.keys, n = ks.length;
    const lim = Math.max(0, n - this.half);
    const k16 = this.key >>> 8;   // the Psion keeps the top 16 bits of each key
    for (let i = n - 2; i >= lim; i -= 2) if ((ks[i] >>> 8) === k16) return true;
    return false;
  },

  // in check with no legal move (asked only at the fifty-move mark: a mate there still counts)
  mated(ply) {
    if (!this.inCheck()) return false;
    const start = this.mvTop[ply], end = start + this.gen(ply, false);
    this.mvTop[ply + 1] = end;
    for (let i = start; i < end; i++) {
      const ok = this.make(this.mv[i * 3], this.mv[i * 3 + 1]);
      this.unmake();
      if (ok) return false;
    }
    return true;
  },

  insufficient() {
    const c = this.cnt;
    if (c[P] + c[8 + P] + c[R] + c[8 + R] + c[Q] + c[8 + Q]) return false;
    if (c[N] + c[B] + c[8 + N] + c[8 + B] <= 1) return true;
    if (c[N] + c[8 + N]) return false;
    // (16 Nov) bishops only, either side's: a draw when they all stand on one colour
    let col = -1;
    for (let s = 0; s < 128; s++) {
      if (s & 0x88) { s += 7; continue; }
      if ((this.b[s] & 7) !== B) continue;
      const k = ((s >> 4) + s) & 1;
      if (col < 0) col = k; else if (k !== col) return false;
    }
    return true;
  },

  // pick the best-scored move from i..end, swap it to i
  pick(i, end) {
    const mv = this.mv;
    let best = i, bs = mv[i * 3 + 2];
    for (let j = i + 1; j < end; j++) if (mv[j * 3 + 2] > bs) { bs = mv[j * 3 + 2]; best = j; }
    if (best !== i) {
      for (let k = 0; k < 3; k++) { const x = mv[i * 3 + k]; mv[i * 3 + k] = mv[best * 3 + k]; mv[best * 3 + k] = x; }
    }
  },

  // The limit is not applied until depth 1 has finished: there is always a searched move.
  timeUp() {
    if (this.nodes >= this.nodeLimit && this.depthDone > 0) { this.stop = true; return true; }
    return false;
  },

  qsearch(alpha, beta, ply) {
    this.nodes++;
    if (this.timeUp()) return 0;
    const stand = this.evaluate();
    if (ply >= MAXPLY - 1 || this.mvTop[ply] > MVCAP) return stand;
    if (stand >= beta) return beta;
    if (stand > alpha) alpha = stand;
    const start = this.mvTop[ply];
    const end = start + this.gen(ply, true);
    this.mvTop[ply + 1] = end;
    for (let i = start; i < end; i++) {
      this.pick(i, end);
      const f = this.mv[i * 3], t = this.mv[i * 3 + 1];
      if (!this.make(f, t)) { this.unmake(); continue; }
      // a capture by a higher piece type onto a defended square is not tried (it kept depth 1, which
      // always finishes, from running away: up to 44,000 nodes, minutes on the Psion)
      const u = this.hist[this.hist.length - 1];
      if (u.cap && (u.pc & 7) > (u.cap & 7) && this.attacked(t & 0x77, this.side)) { this.unmake(); continue; }
      const sc = -this.qsearch(-beta, -alpha, ply + 1);
      this.unmake();
      if (this.stop) return 0;
      if (sc > alpha) {
        if (sc >= beta) return beta;
        alpha = sc;
      }
    }
    return alpha;
  },

  search(depth, alpha, beta, ply, allowNull) {
    const pv = beta - alpha > 1;
    if (ply > 0) {
      if (this.half >= 100) return this.mated(ply) ? -MATE + ply : 0;   // (a mate on the 100th half-move counts)
      if (this.isRepOrFifty() || this.insufficient()) return 0;
    }
    const inCheck = this.inCheck();
    if (inCheck && this.opts.checkExt && ply < MAXPLY - 4) depth++;
    if (depth <= 0 || ply >= MAXPLY - 2) return this.qsearch(alpha, beta, ply);
    this.nodes++;
    if (this.timeUp()) return 0;
    if (this.mvTop[ply] > MVCAP) return this.evaluate();

    // transposition table
    const idx = this.key & ((1 << this.ttBits) - 1), kh = this.key >>> 8;
    let ttf = 0, ttt = 0;
    if (this.ttKey[idx] === kh && this.ttFlag[idx]) {
      ttf = this.ttF[idx]; ttt = this.ttT[idx];
      if (ply > 0 && this.ttD[idx] >= depth && (!pv || this.half < 80)) {   // (experiment: every node while the fifty-move count is under 80)
        let sc = this.ttS[idx];
        if (sc > MATE_BOUND) sc -= ply; else if (sc < -MATE_BOUND) sc += ply;
        const fl = this.ttFlag[idx];
        if (fl === TT_EXACT) return sc;
        if (fl === TT_LOWER && sc >= beta) return beta;
        if (fl === TT_UPPER && sc <= alpha) return alpha;
      }
    }

    let stat = 0;
    if (!inCheck) stat = this.evaluate();

    // null move
    const us = this.side >> 3;
    if (this.opts.nullMove && allowNull && !pv && !inCheck && depth >= 3 && ply > 0 && stat >= beta) {
      const c = this.cnt, o = us * 8;
      if (c[o + N] + c[o + B] + c[o + R] + c[o + Q] > 0) {
        this.mvTop[ply + 1] = this.mvTop[ply];     // the null child's moves go where ours would
        this.makeNull();
        const sc = -this.search(depth - 3, -beta, -beta + 1, ply + 1, false);
        this.unmakeNull();
        if (this.stop) return 0;
        if (sc >= beta) return beta;
      }
    }

    const start = this.mvTop[ply];
    const end = start + this.gen(ply, false);
    this.mvTop[ply + 1] = end;
    if (ttf || ttt) {
      for (let i = start; i < end; i++) {
        if (this.mv[i * 3] === ttf && this.mv[i * 3 + 1] === ttt) { this.mv[i * 3 + 2] = 255; break; }
      }
    }

    let legal = 0, bestF = 0, bestT = 0;
    const oldAlpha = alpha;
    for (let i = start; i < end; i++) {
      this.pick(i, end);
      const f = this.mv[i * 3], t = this.mv[i * 3 + 1], ms = this.mv[i * 3 + 2];
      const quiet = this.b[t & 0x77] === 0 && ms < 160 && !((this.b[f] & 7) === P && (t & 0x77) === this.ep);
      const isPromo = (this.b[f] & 7) === P && (((t & 0x70) === 0x70) || ((t & 0x70) === 0));
      if (!this.make(f, t)) { this.unmake(); continue; }
      legal++;
      const q = quiet && !isPromo;
      let gives = false;
      const needGives = q && !inCheck && ((depth === 1 && this.opts.futility) || (depth >= 3 && legal >= 4 && this.opts.lmr && ms < 149));
      if (needGives) gives = this.attacked(this.ksq[us ^ 1], us * 8);
      // futility at the last ply
      if (this.opts.futility && depth === 1 && q && !inCheck && !gives && legal > 1 && stat + 150 <= alpha) {
        this.unmake();
        continue;
      }
      let sc;
      if (legal === 1 || !this.opts.pvs) {
        sc = -this.search(depth - 1, -beta, -alpha, ply + 1, true);
      } else {
        const red = (this.opts.lmr && depth >= 3 && legal >= 4 && q && !inCheck && !gives && ms < 149) ? 1 : 0;
        sc = -this.search(depth - 1 - red, -alpha - 1, -alpha, ply + 1, true);
        if (!this.stop && sc > alpha && red) sc = -this.search(depth - 1, -alpha - 1, -alpha, ply + 1, true);
        if (!this.stop && sc > alpha && sc < beta) sc = -this.search(depth - 1, -beta, -alpha, ply + 1, true);
      }
      this.unmake();
      if (this.stop) return 0;
      if (sc > alpha) {
        alpha = sc; bestF = f; bestT = t;
        if (ply === 0) { this.rootF = f; this.rootT = t; this.rootScore = sc; }
        if (sc >= beta) {
          if (q) {
            const k = ply * 4;
            if (this.killer[k] !== f || this.killer[k + 1] !== t) {
              this.killer[k + 2] = this.killer[k]; this.killer[k + 3] = this.killer[k + 1];
              this.killer[k] = f; this.killer[k + 1] = t;
            }
          }
          break;
        }
      }
    }
    if (legal === 0) return inCheck ? -MATE + ply : 0;

    // store
    let flag = alpha >= beta ? TT_LOWER : (alpha > oldAlpha ? TT_EXACT : TT_UPPER);
    let st = alpha >= beta ? beta : alpha;
    if (st > MATE_BOUND) st += ply; else if (st < -MATE_BOUND) st -= ply;
    this.ttKey[idx] = kh; this.ttFlag[idx] = flag; this.ttD[idx] = depth; this.ttS[idx] = st;
    if (bestF || bestT) { this.ttF[idx] = bestF; this.ttT[idx] = bestT; }
    else { this.ttF[idx] = ttf; this.ttT[idx] = ttt; }
    return alpha >= beta ? beta : alpha;
  },

  // Iterative deepening. Returns {f, t, score, depth, nodes}.
  // margin > 0 (levels 1-4): evaluation noise ((h - 128) * margin) >> 4, h = the key's low byte ^ a
  // seed drawn afresh for each search: within +-8 * margin, the same for a position all through it. (Until 17 Nov a
  // margin pass: every root move searched again, a random one within `margin` of the best.)
  // soft: stop deepening once half the node limit is used (the Psion's time rule: no new depth
  // after half of e_tlim; tools use it with nodes standing in for time). Off by default.
  think(nodeLimit, maxDepth = 40, margin = 0, soft = false) {
    this.nodes = 0; this.nodeLimit = nodeLimit || 0x7FFFFFFF; this.stop = false;
    this.noise = margin;                  // levels 1-4 (17 Nov): evaluation noise mask, new seed each search
    if (margin) this.nseed = this.rand16() & 0xFF;
    this.killer.fill(0);
    this.mvTop[0] = 0;
    if (!this.ttKey || this.ttKey.length !== (1 << this.ttBits)) this.ttInit(this.ttBits);
    const nLegal = this.countLegal();
    if (nLegal === 0) return null;
    let best = null, depthDone = 0;
    this.depthDone = 0;
    for (let d = 1; d <= maxDepth; d++) {
      this.rootF = 0; this.rootT = 0;
      const sc = this.search(d, -INF, INF, 0, true);
      if (this.rootF || this.rootT) best = { f: this.rootF, t: this.rootT, score: this.rootScore };
      if (this.stop) break;
      depthDone = d;
      this.depthDone = d;
      if (best) best.score = sc;
      if (sc > MATE_BOUND || sc < -MATE_BOUND) break;
      if (nLegal === 1) break;
      if (soft && this.nodes * 2 >= this.nodeLimit) break;
    }
    if (!best) {                       // nothing searched in time: the first legal move (as the Psion)
      const lm = legalMoves(this);
      best = { f: lm[0][0], t: lm[0][1], score: 0 };
    }
    best.depth = depthDone; best.nodes = this.nodes;
    return best;
  },

  countLegal() {
    const n = this.gen(0, false);
    let c = 0;
    for (let i = 0; i < n; i++) { if (this.make(this.mv[i * 3], this.mv[i * 3 + 1])) c++; this.unmake(); }
    return c;
  },

  // xorshift16 (7,9,8), same as the assembler; seed must be non-zero
  rand16() {
    let x = this.rnd || 1;
    x ^= (x << 7) & 0xFFFF; x ^= x >> 9; x ^= (x << 8) & 0xFFFF;
    this.rnd = x;
    return x;
  },
});

// ---------------- helpers for tools ----------------
function sqName(s) { return 'abcdefgh'[s & 7] + (1 + (s >> 4)); }
function moveStr(f, t) {
  const promo = ((t >> 3) & 1) | ((t >> 6) & 2);
  return sqName(f) + sqName(t & 0x77);
}
function legalMoves(e) {
  const ply = e.ply;
  const saveTop = e.mvTop[ply];
  e.mvTop[ply] = 0;
  const n = e.gen(ply, false), out = [];
  const list = [];
  for (let i = 0; i < n; i++) list.push([e.mv[i * 3], e.mv[i * 3 + 1]]);
  for (const [f, t] of list) { if (e.make(f, t)) out.push([f, t]); e.unmake(); }
  e.mvTop[ply] = saveTop;
  return out;
}
// UCI move text (e7e8q) -> [f, t] using the legal list
function parseUci(e, s) {
  const f = (s.charCodeAt(1) - 49) * 16 + (s.charCodeAt(0) - 97);
  const t = (s.charCodeAt(3) - 49) * 16 + (s.charCodeAt(2) - 97);
  const pr = s[4] ? 'qrbn'.indexOf(s[4]) : 0;
  const tc = t | ((pr & 1) << 3) | ((pr & 2) << 6);
  for (const m of legalMoves(e)) if (m[0] === f && m[1] === tc) return m;
  return null;
}
// e: engine before the move is made (to tell a promotion from a normal move)
function uciStr(e, f, t) {
  const pr = ((t >> 3) & 1) | ((t >> 6) & 2);
  const promo = (e.b[f] & 7) === P && ((t & 0x70) === 0x70 || (t & 0x70) === 0);
  return sqName(f) + sqName(t & 0x77) + (promo ? 'qrbn'[pr] : '');
}

module.exports = { Engine, sqName, moveStr, uciStr, legalMoves, parseUci, TT_EXACT, TT_LOWER, TT_UPPER, CMD };
