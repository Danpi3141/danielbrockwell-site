'use strict';
// UI soak: whole games in the headless LZ64.
//   node tests/ui/t_soak.js [games=4]
// 1. Against the computer at level 1: the player's moves are random legal moves (python-chess),
//    typed on the keys; after every ply the engine's position must equal python-chess's for the
//    moves so far (the computer's move read from the record), and when the game ends its
//    reason must be python-chess's under the engine's rules (or the computer's resignation).
//    Nothing may hang: every ply must come within 2 emulated minutes.
// 2. Two players: long random games (uniform random moves, up to 250 plies) typed on the keys,
//    every position compared, the end checked.
const { spawnSync } = require('child_process');
const path = require('path');
const L = require('./lib.js');
const G = require('./glib.js');
const { keys } = L;
const N = +(process.argv[2] || 4);

let fails = 0, plies = 0;
const long = [];                                   // positions where it thought more than 2 minutes
function soft(cond, msg, m) { if (!cond) { fails++; console.log('FAIL ' + msg + (m ? '\n' + m.screenText() : '')); } return cond; }
function model(moves, seed) {
  const r = spawnSync('python', ['-E', '-P', path.join(__dirname, 'model.py')], { input: JSON.stringify({ moves, seed }), encoding: 'utf8' });
  if (r.status !== 0) throw new Error('model.py: ' + r.stderr);
  return JSON.parse(r.stdout);
}
const REASON = { mate: 1, stalemate: 2, fifty: 3, rep: 4, material: 5 };
const PROMO = ['q', 'r', 'b', 'n'];
// the computer's move: from, to (with the promotion bits), the promotion piece if a pawn reached the end
function compUci(m, moves) {
  const [f, t] = L.peekSym(m, 'g_last', 3);
  let u = G.sqName(f) + G.sqName(t & 0x77);
  const r = model(moves.concat([u]), 0);
  if (!r.legal) {                                // a promotion needs its letter
    const code = ((t >> 3) & 1) | ((t >> 6) & 2);
    u += PROMO[code];
  }
  return u;
}

let m = G.start();
G.setting(m, G.SET.LEVEL, ['LEFT', 'LEFT', 'LEFT', 'LEFT', 'LEFT', 'LEFT']);   // level 1
const t0 = Date.now();
for (let g = 0; g < N; g++) {
  G.menu(m, ['N']); G.waitInput(m, 30);
  const moves = [];
  let end = '';
  while (moves.length < 160) {
    if (L.peekSym(m, 'g_result')[0]) { end = 'result'; break; }
    const n = L.peekSym(m, 'g_n')[0];
    const q0 = model(moves, g * 1000 + n);           // the player's move
    G.typeUci(m, q0.next);
    moves.push(q0.next);
    // then the computer's reply (or the end): waiting for a key again with the move made
    if (!G.waitInput(m, 120, () => L.peekSym(m, 'g_n')[0] > n)) {
      // still thinking after 2 minutes: note the position, then a key (it must move at once)
      const fen = model(moves, 0).fen;
      const strip = [0, 1, 2].map((r) => m.screen()[r].slice(9, 12)).join('|');
      long.push(`game ${g + 1} ply ${n + 2}: ${fen} (strip ${strip})`);
      keys(m, ['MODE']);
      if (!soft(G.waitInput(m, 30, () => L.peekSym(m, 'g_n')[0] > n), `game ${g + 1}: ply ${n + 2}: no move 30 s after a key`, m)) { end = 'hang'; break; }
    }
    if (L.peekSym(m, 'g_n')[0] === n + 2) moves.push(compUci(m, moves));
    plies += L.peekSym(m, 'g_n')[0] - n;
    const q = model(moves, 0);
    soft(q.legal, `game ${g + 1}: ply ${moves.length} ${moves[moves.length - 1]} is not legal for python-chess`, m);
    const ef = G.engFen(m);
    soft(G.fenMatch(ef, q), `game ${g + 1} ply ${moves.length}: engine ${ef} vs python ${q.fen}`, m);
    const res = L.peekSym(m, 'g_result')[0], why = L.peekSym(m, 'g_reason')[0];
    if (q.status) { soft(why === REASON[q.status], `game ${g + 1}: python says ${q.status}, the game's reason is ${why}`, m); end = q.status; break; }
    if (res) { soft(why === 6, `game ${g + 1}: ended (reason ${why}) where python-chess plays on`, m); end = 'resigned'; break; }
  }
  const reason = L.peekSym(m, 'g_reason')[0];
  console.log(`ok   game ${g + 1} against level 1: ${moves.length} plies, ended: ${end} (reason ${reason})`);
  if (end === 'hang') { m = G.start(); G.setting(m, G.SET.LEVEL, ['LEFT', 'LEFT', 'LEFT', 'LEFT', 'LEFT', 'LEFT']); continue; }
  if (L.peekSym(m, 'g_result')[0]) { keys(m, ['ON']); G.waitInput(m, 10); keys(m, ['ON']); G.waitInput(m, 10); }
}

// ---- two players, long uniform random games
const games = G.games('soak', ['--random', String(N), '--uniform', '--maxply', '250', '--seed', '500']);
G.twoPlayers(m);
for (const g of games) {
  const ok = G.playGame(m, g, (i, p) => {
    plies++;
    const ef = G.engFen(m);
    soft(G.fenMatch(ef, p), `${g.name} ply ${i + 1}: engine ${ef} vs python ${p.fen}`, m);
    if (p.status) soft(L.peekSym(m, 'g_reason')[0] === REASON[p.status], `${g.name}: ended ${p.status}, reason ${L.peekSym(m, 'g_reason')[0]}`, m);
    else soft(!L.peekSym(m, 'g_result')[0], `${g.name} ply ${i + 1}: the game ended (reason ${L.peekSym(m, 'g_reason')[0]}) but python-chess plays on`, m);
  });
  soft(ok, g.name + ': a move was refused', m);
  console.log(`ok   ${g.name} (two players): ${g.plies.length} plies, ${g.plies[g.plies.length - 1].status || 'not ended'}`);
  if (!ok) { m = G.start(); G.twoPlayers(m); }
}
if (long.length) console.log('     thought more than 2 minutes (then a key made it move):', JSON.stringify(long, null, 1));
console.log(`${plies} plies checked in ${((Date.now() - t0) / 1000).toFixed(0)} s, ${fails} failures`);
if (fails) process.exit(1);
console.log('soak passed');
