#!/bin/sh
# 17 Nov: levels 1-4 with evaluation noise k (snap_m17e) against the margin pass they replace
# (snap_m17a), each at its level's nodes (73.8 nodes/s), 2,484 games each
M="python -E -P match.py"
O="--opfile openings_big.txt --openings 0:1242 --workers 12"
for spec in "4 221 30 14" "3 148 70 25" "2 74 150 53" "1 74 300 100"; do
  set -- $spec
  $M lev_L$1_k$4 snap_m17e:Nodes=$2,Margin=$4 snap_m17a:Nodes=$2,Margin=$3 $O > logs_lev_L$1_k$4.txt 2>&1
done
python -E -P analyze.py lev_L4_k14 lev_L3_k25 lev_L2_k53 lev_L1_k100 | grep -v histogram > logs_lev_summary.txt 2>&1
echo done >> logs_lev_summary.txt
