"""Runs the whole book audit in order and prints each check's summary.

    python -E -P tools/book/audit/run_all.py [--book data/book.bin] [--opk pack] [--skip-kernel]

Steps: decode.js (structure), eval_tree.py (Stockfish on the tree), check1/2/3, check5, and
kernel_check.js against a pack holding the same book (default build/game/CHESS.opk; the kernel
check is skipped with a note if that pack holds a different book). Stockfish work is cached in
tools/book/audit/cache/, so a rerun is quick. Do not run two audits at once (they share the cache).
"""
import argparse
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
CHESS = os.path.normpath(os.path.join(HERE, '..', '..', '..'))


def run(cmd):
    print('\n$ ' + ' '.join(cmd), flush=True)
    return subprocess.run(cmd).returncode


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--book', default=os.path.join(CHESS, 'data', 'book.bin'))
    ap.add_argument('--opk', default=os.path.join(CHESS, 'build', 'game', 'CHESS.opk'))
    ap.add_argument('--skip-kernel', action='store_true')
    a = ap.parse_args()
    py = [sys.executable, '-E', '-P']
    rc = {}
    rc['structure'] = run(['node', os.path.join(HERE, 'decode.js'), a.book])
    rc['eval'] = run(py + [os.path.join(HERE, 'eval_tree.py'), '--book', a.book])
    rc['check1'] = run(py + [os.path.join(HERE, 'check1_pmoves.py'), '--book', a.book])
    rc['check2'] = run(py + [os.path.join(HERE, 'check2_punish.py'), '--book', a.book])
    rc['check3'] = run(py + [os.path.join(HERE, 'check3_exits.py'), '--book', a.book])
    rc['check5'] = run(py + [os.path.join(HERE, 'check5_coverage.py'), '--book', a.book])
    if not a.skip_kernel:
        if open(a.book, 'rb').read() in open(a.opk, 'rb').read():
            rc['kernel'] = run(['node', os.path.join(HERE, 'kernel_check.js'), '--opk', a.opk, '--book', a.book,
                                '--lines', '600', '--games', '40'])
        else:
            print('\nkernel check skipped: %s does not hold this book (build a pack with tools/build.py --out DIR)' % a.opk)
    print('\nexit codes (0 = pass):', rc)
    return 1 if any(rc.values()) else 0


if __name__ == '__main__':
    sys.exit(main())
