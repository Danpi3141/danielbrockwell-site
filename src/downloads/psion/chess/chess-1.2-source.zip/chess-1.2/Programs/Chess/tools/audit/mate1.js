'use strict';
// Levels 1-4 (the random-margin levels) must never play a move that allows mate in one when a move
// that doesn't exists. Positions come from self-play at low levels; only positions where some legal
// moves allow a mate in one and others don't are kept. Each position is played at every level with
// several random seeds.
// Usage: node mate1.js [engineDir] [positions] [seeds] [levels e.g. 1,2,3,4,5]
const path = require('path');
const L = require('./levels.js');
const dir = process.argv[2] && process.argv[2] !== '-' ? path.resolve(process.argv[2]) : null;
const { Engine, legalMoves, uciStr } = L.loadEngine(dir);
const NPOS = +(process.argv[3] || 300), SEEDS = +(process.argv[4] || 4);
const LEVELS = (process.argv[5] || '1,2,3,4').split(',').map(Number);

let rng = 99991;
const rnd = (k) => { rng = (Math.imul(rng, 1103515245) + 12345) & 0x7fffffff; return (rng >>> 8) % k; };

// does the move (f,t) let the opponent mate at once?
function allowsMate1(e, f, t) {
  e.make(f, t);
  let mate = false;
  for (const [g, u] of legalMoves(e)) {
    e.make(g, u);
    const n = legalMoves(e).length;
    const chk = e.inCheck();
    e.unmake();
    if (n === 0 && chk) { mate = true; break; }
  }
  e.unmake();
  return mate;
}
function fenOf(e) {
  let s = '';
  for (let r = 7; r >= 0; r--) {
    let k = 0;
    for (let c = 0; c < 8; c++) {
      const p = e.b[r * 16 + c];
      if (!p) { k++; continue; }
      if (k) { s += k; k = 0; }
      const ch = ' pnbrqk'[p & 7];
      s += p & 8 ? ch : ch.toUpperCase();
    }
    if (k) s += k;
    if (r) s += '/';
  }
  let cs = ''; const c = e.castle;
  if (c & 1) cs += 'K'; if (c & 2) cs += 'Q'; if (c & 4) cs += 'k'; if (c & 8) cs += 'q';
  const ep = e.ep === 0xFF ? '-' : 'abcdefgh'[e.ep & 7] + (1 + (e.ep >> 4));
  return `${s} ${e.side ? 'b' : 'w'} ${cs || '-'} ${ep} ${e.half} 1`;
}

// collect positions
const ops = require('fs').readFileSync(path.join(__dirname, '..', 'match', 'openings.txt'), 'utf8').trim().split(/\r?\n/);
// positions are always generated with the pre-audit engine (snap_before), so engines are compared
// on the same set
const G = L.loadEngine(path.join(__dirname, 'snap_before'));
const pos = [];
const g = new G.Engine(); g.ttInit(9);
let games = 0;
while (pos.length < NPOS && games < 5000) {
  games++;
  g.setFen('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
  g.ttInit(9);
  for (const u of ops[rnd(ops.length)].split(' ')) {
    const m = G.legalMoves(g).find(([f, t]) => G.uciStr(g, f, t) === u); g.make(m[0], m[1]); g.ply = 0;
  }
  for (let ply = 0; ply < 160 && pos.length < NPOS; ply++) {
    const ms = G.legalMoves(g);
    if (!ms.length || g.half >= 100) break;
    let bad = 0;
    for (const [f, t] of ms) if (allowsMate1(g, f, t)) bad++;
    if (bad > 0 && bad < ms.length) pos.push(fenOf(g));
    g.rnd = 1 + rnd(65000);
    const r = L.levelThink(g, 1 + rnd(4));
    g.make(r.f, r.t); g.ply = 0;
    if (g.half === 0) g.keys.length = 0;
  }
}

const e = new Engine();
const res = {};
let shown = 0;
for (const lv of LEVELS) res[lv] = { tries: 0, mate1: 0, positions: new Set() };
for (let i = 0; i < pos.length; i++) {
  for (const lv of LEVELS) {
    for (let s = 0; s < SEEDS; s++) {
      e.setFen(pos[i]); e.ttInit(9); e.rnd = 1 + ((i * 7919 + s * 104729 + lv * 31) % 65000);
      const r = L.levelThink(e, lv);
      res[lv].tries++;
      if (allowsMate1(e, r.f, r.t)) {
        res[lv].mate1++; res[lv].positions.add(i);
        if (shown++ < 6) console.log(`  level ${lv} plays ${uciStr(e, r.f, r.t)} (depth ${r.depth}) allowing mate: ${pos[i]}`);
      }
    }
  }
}
console.log(`${pos.length} positions (from ${games} self-play games) where some moves allow mate in one and some don't; ${SEEDS} seeds each`);
let total = 0;
for (const lv of LEVELS) {
  const r = res[lv]; total += r.mate1;
  console.log(`level ${lv}: allowed mate in one in ${r.mate1} of ${r.tries} moves (${r.positions.size} positions)`);
}
console.log(total ? `${total} moves allowed mate in one` : 'no move allowed mate in one');
process.exit(0);
