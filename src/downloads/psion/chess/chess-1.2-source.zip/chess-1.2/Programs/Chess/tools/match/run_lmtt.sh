#!/bin/sh
M="python -E -P match.py"
O="--opfile openings_big.txt --openings 0:1242 --workers 12"
$M lmtt_L7_512 snap_lmtt:Nodes=2214 snap_m17f:Nodes=2214 $O > logs_lmtt_L7_512.txt 2>&1
$M lmtt_L7_128 snap_lmtt:Nodes=2214,HashBits=7 snap_m17f:Nodes=2214,HashBits=7 $O > logs_lmtt_L7_128.txt 2>&1
python -E -P analyze.py lmtt_L7_512 lmtt_L7_128 | grep -v histogram
