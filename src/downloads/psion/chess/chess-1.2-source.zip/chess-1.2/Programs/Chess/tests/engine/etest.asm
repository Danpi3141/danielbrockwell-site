; Engine test image: the engine plus test drivers, run on the bare CPU by tests/engine/harness.js.
T0      = $41
T1      = $42
T2      = $43
T3      = $44
T4      = $45
T5      = $46
T6      = $47
T7      = $48
T8      = $49
T9      = $4A
T10     = $4B
T11     = $4C
ZP1     = $4D                   ; as in src/defs.inc
ZP2     = $CC
ZP3     = $7F
TMW_FRAM = $20CB
ENG_SCRATCH_EXT = 0
ENG_LOW = 0

        include "../../src/engine/engine.asm"

; the kernel's hook: never stop
think_poll: clc
        rts

; t_perft: A = depth (>= 1); adds the leaf count to pf_cnt (4 bytes)
t_perft: psha
        clr  e_caps
        jsr  e_gen
        ldab e_ply
        incb
        aslb
        ldx  #e_mvtop
        abx
        ldd  e_wp
        std  0,x
        ldab e_ply
        aslb
        ldx  #e_mvtop
        abx
        ldx  0,x
.loop:  pshx
        ldab e_ply
        incb
        aslb
        ldx  #e_mvtop
        abx
        ldd  0,x
        pulx
        stx  pf_i
        subd pf_i
        beq  .done
        pshx
        jsr  e_inchk            ; (re-tested each move: the child may have changed e_inck)
        tpa
        anda #1
        staa e_inck
        pulx
        ldaa 0,x
        ldab 1,x
        inx
        inx
        inx
        pshx
        jsr  e_make
        bcs  .skip
        tsx
        ldaa 2,x                ; depth
        cmpa #1
        bne  .deep
        inc  pf_cnt+3
        bne  .skip
        inc  pf_cnt+2
        bne  .skip
        inc  pf_cnt+1
        bra  .skip
.deep:  deca
        jsr  t_perft
.skip:  jsr  e_unmake
        pulx
        bra  .loop
.done:  pula
        rts

; t_reset: engine start-up for the tests (frames, move stack)
t_go:   jsr  eng_init
        rts

        include "../../src/engine/evars.inc"
pf_cnt: rmb  4
pf_i:   rmb  2
t_end:
