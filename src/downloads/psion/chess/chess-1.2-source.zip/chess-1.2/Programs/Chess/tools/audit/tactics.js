'use strict';
// Tactics solved per level (tools/audit/tactics.json from make_tactics.py): mate in 2 (solved when
// the move played is one of the moves that mate in 2 or less) and win a piece (solved when it is the
// single best move). JS reference with each level's limits (levels.js); levels 1-4 pick at random
// within their margin, so each position is tried with SEEDS seeds there.
//   node tactics.js [engineDir|-] [seeds] [asmCount]
// asmCount > 0: also runs that many positions on the assembler (tests/engine/harness.js) at each
// level's node count and margin (a hard node limit; the half-time rule needs the clock) and checks
// move, score, depth and nodes against the JS at the same settings.
const path = require('path');
const L = require('./levels.js');
const dir = process.argv[2] && process.argv[2] !== '-' ? path.resolve(process.argv[2]) : null;
const { Engine, uciStr } = L.loadEngine(dir);
const SEEDS = +(process.argv[3] || 3), ASM = +(process.argv[4] || 0);
const set = require(path.join(__dirname, 'tactics.json'));

const e = new Engine();
const res = {};
for (const kind of ['mate2', 'piece']) for (let lv = 1; lv <= 8; lv++) res[kind + lv] = [0, 0];
for (let i = 0; i < set.length; i++) {
  const p = set[i];
  for (let lv = 1; lv <= 8; lv++) {
    const seeds = L.MARG[lv] ? SEEDS : 1;
    for (let s = 0; s < seeds; s++) {
      e.setFen(p.fen); e.ttInit(9); e.rnd = 1 + ((i * 131 + s * 7919) % 65000);
      const r = L.levelThink(e, lv);
      const u = uciStr(e, r.f, r.t);
      const k = res[p.kind + lv];
      k[1]++; if (p.ok.includes(u)) k[0]++;
    }
  }
}
const n = { mate2: set.filter(p => p.kind === 'mate2').length, piece: set.filter(p => p.kind === 'piece').length };
console.log(`${n.mate2} mate-in-2 and ${n.piece} win-a-piece positions; engine ${dir || 'ref'}; ${L.NPS} nodes a second; levels 1-4 x${SEEDS} seeds`);
console.log('level  nodes  margin   mate in 2        win a piece');
for (let lv = 1; lv <= 8; lv++) {
  const a = res['mate2' + lv], b = res['piece' + lv];
  const pc = (x) => `${x[0]}/${x[1]} (${(100 * x[0] / x[1]).toFixed(0)}%)`;
  console.log(`  ${lv}   ${String(L.levelNodes(lv)).padStart(6)}  ${String(L.MARG[lv]).padStart(4)}    ${pc(a).padEnd(16)} ${pc(b)}`);
}

if (ASM > 0) {
  const { Harness } = require('../../tests/engine/harness.js');
  const h = new Harness();
  const j = new Engine(); j.ttInit(8);
  let bad = 0, runs = 0;
  const step = Math.max(1, Math.floor(set.length / ASM));
  for (let i = 0; i < set.length && runs < ASM * 8; i += step) {
    for (let lv = 1; lv <= 8; lv++) {
      const nodes = L.levelNodes(lv), margin = L.MARG[lv], seed = 1 + i;
      j.rnd = seed;
      h.setFen(set[i].fen); j.setFen(set[i].fen);
      h.call('e_clrtt'); j.ttInit(8);
      h.pokew('e_rnd', seed); j.rnd = seed;
      h.m.write(h.a('e_nlim'), [(nodes >> 16) & 255, (nodes >> 8) & 255, nodes & 255]);
      h.pokew('e_tlim', 0); h.poke('e_maxd', 0); h.pokew('e_margin', margin);
      h.call('eng_think', 0, 0, 921600 * 3600);
      const af = h.peek('e_bestf'), at = h.peek('e_bestt'), as = h.sw('e_score'), ad = h.peek('e_depth');
      const nb = h.bytes('e_nodes', 3), an = (nb[0] << 16) | (nb[1] << 8) | nb[2];
      const r = j.think(nodes, 40, margin);
      runs++;
      if (af !== r.f || at !== r.t || as !== r.score || ad !== r.depth || an !== r.nodes) {
        bad++; console.log(`  asm FAIL level ${lv}: ${uciStr(j, af, at)} ${as} d${ad} n${an} v ${uciStr(j, r.f, r.t)} ${r.score} d${r.depth} n${r.nodes}  ${set[i].fen}`);
      }
    }
  }
  console.log(`assembler spot check: ${runs} thinks (${runs / 8} positions x 8 levels), ${bad} differ from the JS`);
}
