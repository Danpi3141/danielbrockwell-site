'use strict';
// Mop-up weight experiments on the JS reference (not used by the engine): patches mopup() with
// parameters and plays random bare-king endings, both sides by the engine.
//   node tune_mop.js EDGE PROX CORNER [starts] [nodes] [sets]
// EDGE: weight of the edge term (engine 20); PROX: king proximity per step (engine 6);
// CORNER: B+N corner weight per step (engine 5).
const { Engine, legalMoves, CMD } = require('../../ref/search.js');
const [EDGE, PROX, CORNER] = process.argv.slice(2, 5).map(Number);
const KNIGHT = +(process.env.KNIGHT || 0);   // B+N: bonus per step of knight-to-king closeness
const STARTS = +(process.argv[5] || 50), NODES = +(process.argv[6] || 2500);
const SETS = (process.argv[7] || 'KQK,KRK,KBBK,KBNK').split(',');
const sq64 = (s) => (s + (s & 7)) >> 1;
const mdist = (a, b) => Math.abs((a & 7) - (b & 7)) + Math.abs((a >> 4) - (b >> 4));
Engine.prototype.mopup = function (lc) {
  const lk = this.ksq[lc], wk = this.ksq[lc ^ 1], wc = (lc ^ 1) * 8, c = this.cnt;
  let edge;
  if (c[wc + 5] + c[wc + 4] === 0 && c[wc + 3] === 1 && c[wc + 2] >= 1) {
    let bs = 0;
    for (let q = 0; q < 128; q++) { if (q & 0x88) { q += 7; continue; } if (this.b[q] === (3 | wc)) { bs = q; break; } }
    const dark = ((bs & 7) + (bs >> 4)) % 2 === 0;
    const d1 = dark ? Math.min(mdist(lk, 0x00), mdist(lk, 0x77)) : Math.min(mdist(lk, 0x07), mdist(lk, 0x70));
    edge = CORNER * (14 - d1) + CMD[sq64(lk)];
    if (KNIGHT) { let ns = 0; for (let q = 0; q < 128; q++) { if (q & 0x88) { q += 7; continue; } if (this.b[q] === (2 | wc)) { ns = q; break; } } return EDGE * edge + PROX * (14 - mdist(lk, wk)) + KNIGHT * (14 - mdist(lk, ns)); }
  } else edge = CMD[sq64(lk)];
  return EDGE * edge + PROX * (14 - mdist(lk, wk));
};
let rng = +(process.env.SEED || 20261116);
const rnd = (k) => { rng = (Math.imul(rng, 1103515245) + 12345) & 0x7fffffff; return (rng >>> 8) % k; };
function start(set, e) {
  for (;;) {
    const b = new Uint8Array(128);
    const put = (p) => { for (;;) { const s = rnd(8) * 16 + rnd(8); if (b[s]) continue; b[s] = p; return s; } };
    put(6); put(14);
    for (const ch of set.slice(1, -1)) put('PNBRQK'.indexOf(ch) + 1);
    if (set === 'KBBK') { const bs = []; for (let s = 0; s < 128; s++) if (b[s] === 3) bs.push(s); if ((((bs[0] & 7) + (bs[0] >> 4)) & 1) === (((bs[1] & 7) + (bs[1] >> 4)) & 1)) continue; }
    let s = '';
    for (let r = 7; r >= 0; r--) { let k = 0; for (let c = 0; c < 8; c++) { const p = b[r * 16 + c]; if (!p) { k++; continue; } if (k) { s += k; k = 0; } const ch = ' pnbrqk'[p & 7]; s += p & 8 ? ch : ch.toUpperCase(); } if (k) s += k; if (r) s += '/'; }
    const fen = s + ' w - - 0 1';
    e.setFen(fen);
    if (e.attacked(e.ksq[1], 0) || e.inCheck() || !legalMoves(e).length) continue;
    return fen;
  }
}
let tot = 0;
const out = [];
for (const set of SETS) {
  let m = 0, mv = 0;
  for (let i = 0; i < STARTS; i++) {
    const e = new Engine(); e.ttInit(9); e.setFen(start(set, e));
    let ply = 0, res = '';
    for (; ply < 200; ply++) {
      const ms = legalMoves(e);
      if (!ms.length) { res = e.inCheck() ? 'mate' : 'stalemate'; break; }
      if (e.half >= 100 || e.insufficient()) break;
      const r = e.think(NODES);
      e.make(r.f, r.t); e.ply = 0; if (e.half === 0) e.keys.length = 0;
    }
    if (res === 'mate') { m++; mv += ply; }
  }
  tot += m;
  out.push(`${set} ${m}/${STARTS} (${m ? (mv / m / 2).toFixed(1) : '-'} moves)`);
}
console.log(`EDGE ${EDGE} PROX ${PROX} CORNER ${CORNER}: ${out.join(', ')}  total ${tot}`);
