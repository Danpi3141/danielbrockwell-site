'use strict';
// Notation (audit check 3): the move text on the strip, in the move list and in real-board mode
// against python-chess SAN (and the plain-squares text worked out from python-chess's moves).
//   node tests/ui/t_notat.js [--quick | --smoke]   (--smoke: the crafted games, passes 1-2, for run_all)
// Games: the crafted ones of gen_games.py (castling O-O and O-O-O for both colours, with check,
// en passant, promotions =Q =N =R =B with and without capture, mate, file, rank and double
// disambiguation (Qh4e1, Nc2e3), a game where Black moves first) and random games leaning to
// promotions, castling, en passant, captures and checks; without --quick also a 250-ply random
// game (the longest record) whose move list is read to the end, and the 251st move.
// Passes: 1 standard notation, letters-and-map board: the strip after every ply (the three
// parts cell for cell), then the move list read from top to bottom; 2 plain squares: the strip;
// 3 real-board mode, standard notation: "WHITE PLAYED" and "12... Qh4xe1+"; 4 real-board mode,
// plain squares.
const L = require('./lib.js');
const G = require('./glib.js');
const { check, keys } = L;
const smoke = process.argv.includes('--smoke');
const quick = smoke || process.argv.includes('--quick');

let fails = 0, checked = 0;
function soft(cond, msg) { checked++; if (!cond) { fails++; if (fails < 40) console.log('FAIL ' + msg); } return cond; }

let games = G.games('notat', ['--crafted', '--random', smoke ? '0' : quick ? '2' : '8', '--seed', '200']);
if (quick) games = games.filter((g) => /castle|passant|promotion|mate|queens|rooks|knights|black to move|random/.test(g.name));
if (smoke) games = games.filter((g) => !/scholar|stalemate|Nbd2|four knights/.test(g.name));
const long = quick ? [] : G.games('long', ['--random', '1', '--uniform', '--maxply', '250', '--minply', '250', '--seed', '1']);

// the move number and dots of ply i in game g: from the FEN before it
function numbering(g, i) {
  const fen = i ? g.plies[i - 1].fen : (g.start || 'x w - - 0 1');
  const f = fen.split(' ');
  return { n: +f[5], white: f[1] === 'w' };
}

let m = G.start();
G.twoPlayers(m);

// ---- the move list: read every row from the top
function readList(m, g) {
  G.menu(m, ['M']); G.waitInput(m, 30);
  for (let i = 0; i < 140 && !/^1\./.test(m.screen()[0]); i++) { keys(m, ['UP']); G.waitInput(m, 30); }
  const rows = m.screen().slice();
  let guard = 0;
  for (;;) {
    const before = m.screenText();
    keys(m, ['DOWN']); G.waitInput(m, 30);
    if (m.screenText() === before || ++guard > 140) break;
    rows.push(m.screen()[3]);
  }
  keys(m, ['ON']); G.waitInput(m, 10);      // any other key leaves
  return rows.filter((r) => r.trim());
}
function expectList(g) {
  // standard layout: "N.white" from column 0, black from column 11; a game where Black moved
  // first starts "1...." with Black's move in its place
  const rows = [];
  for (let i = 0; i < g.plies.length; i++) {
    const { n, white } = numbering(g, i);
    if (white || i === 0) rows.push({ n, w: white ? g.plies[i].san : '...', b: '' });
    if (!white) rows[rows.length - 1].b = g.plies[i].san;
  }
  return rows.map((r) => ((r.n + '.' + r.w).padEnd(11) + r.b).padEnd(20));
}

// ---- pass 1: standard notation on the strip, then the move list
for (const g of games.concat(long)) {
  const ok = G.playGame(m, g, (i, p) => {
    const want = G.sanParts(p.san).map(G.partCells);
    const got = G.stripCells(m, 9);
    soft(JSON.stringify(got) === JSON.stringify(want), g.name + ' ply ' + (i + 1) + ': strip ' + JSON.stringify(got) + ' for ' + p.san);
  });
  if (!soft(ok, g.name + ': a move was refused\n' + m.screenText())) { m = G.start(); G.twoPlayers(m); continue; }
  const got = readList(m, g), want = expectList(g);
  let bad = 0;
  for (let r = 0; r < Math.max(got.length, want.length); r++) {
    if (got[r] !== want[r] && bad++ < 3) soft(false, g.name + ': move list row ' + (r + 1) + ' "' + got[r] + '" expected "' + want[r] + '"');
  }
  if (!bad) checked++;
  console.log((bad ? 'FAIL ' : 'ok   ') + g.name + ': ' + g.plies.length + ' plies on the strip, move list ' + got.length + ' rows' + (bad ? ' (' + bad + ' rows differ)' : ''));
}

// ---- the record's end: a 251st move is refused with a result
if (long.length) {
  const g = long[0];
  const board = G.engFen(m);
  // any legal move: ask python-chess
  const { spawnSync } = require('child_process');
  const r = spawnSync('python', ['-E', '-P', '-c', 'import chess,sys; b=chess.Board(sys.argv[1]); print(next(iter(b.legal_moves)).uci())', g.plies[g.plies.length - 1].fen], { encoding: 'utf8' });
  const u = r.stdout.trim();
  G.typeUci(m, u); G.waitInput(m, 30);
  soft(m.screenText().includes('THE RECORD IS FULL') && L.peekSym(m, 'g_n')[0] === 250 && G.engFen(m) === board,
    'the 251st move (' + u + ') ends the game: THE RECORD IS FULL, the move not played\n' + m.screenText());
  console.log('ok   the 251st move: ' + m.screen()[0].trim() + ' / ' + m.screen()[1].trim());
  keys(m, ['ON']); G.waitInput(m, 10);            // the result screen: ON is the menu
  keys(m, ['EXE']); G.waitInput(m, 10);           // NEW GAME
}

// ---- pass 2: plain squares
G.setting(m, G.SET.MOVES, ['RIGHT']);
for (const g of games) {
  const ok = G.playGame(m, g, (i, p) => {
    const want = p.plain.map(G.partCells);
    const got = G.stripCells(m, 9);
    soft(JSON.stringify(got) === JSON.stringify(want), g.name + ' ply ' + (i + 1) + ': plain strip ' + JSON.stringify(got) + ' for ' + p.uci + ' ' + JSON.stringify(p.plain));
  });
  soft(ok, g.name + ': a move was refused (plain)');
}
console.log('ok   plain squares: ' + games.length + ' games on the strip');

// ---- passes 3 and 4: real-board mode, both notations (not in --smoke)
G.setting(m, G.SET.BOARD, ['LEFT']);                 // MAP -> REAL BOARD (wraps)
for (const plain of smoke ? [] : [true, false]) {
  for (const g of games) {
    const ok = G.playGame(m, g, (i, p) => {
      const { n, white } = numbering(g, i);
      const s = m.screen();
      const text = plain ? p.plain.join('') : p.san;
      soft(s[0].trim() === (white ? 'WHITE' : 'BLACK') + ' PLAYED', g.name + ' ply ' + (i + 1) + ': real board row 0 "' + s[0] + '"');
      const want = n + (white ? '. ' : '... ') + text;
      soft(s[1].trim() === want, g.name + ' ply ' + (i + 1) + ': real board row 1 "' + s[1].trim() + '" expected "' + want + '"');
    });
    soft(ok, g.name + ': a move was refused (real board)');
  }
  console.log('ok   real-board mode, ' + (plain ? 'plain squares' : 'standard notation') + ': ' + games.length + ' games');
  if (plain) G.setting(m, G.SET.MOVES, ['LEFT']);
}
G.setting(m, G.SET.BOARD, ['RIGHT']);
console.log(checked + ' checks, ' + fails + ' failures');
if (fails) process.exit(1);
console.log('all notation tests passed');
