#!/bin/sh
# 17 Nov: levels 1-4 with evaluation noise (snap_m17d, Margin = the noise mask) against the margin
# pass they replace (snap_m17a, Margin = centipawns), same nodes (73.8 nodes/s), 484 games each
M="python -E -P match.py"
O="--opfile openings_big.txt --openings 0:242 --workers 12"
for spec in "4 221 30 63" "4 221 30 127" "4 221 30 255" "3 148 70 127" "3 148 70 255" "3 148 70 511" "2 74 150 255" "2 74 150 511" "2 74 150 1023" "1 74 300 511" "1 74 300 1023" "1 74 300 2047"; do
  set -- $spec
  $M cal_L$1_m$4 snap_m17d:Nodes=$2,Margin=$4 snap_m17a:Nodes=$2,Margin=$3 $O > logs_cal_L$1_m$4.txt 2>&1
  echo "L$1 mask $4: $(tail -1 logs_cal_L$1_m$4.txt)" >> logs_cal_summary.txt
done
echo done >> logs_cal_summary.txt
