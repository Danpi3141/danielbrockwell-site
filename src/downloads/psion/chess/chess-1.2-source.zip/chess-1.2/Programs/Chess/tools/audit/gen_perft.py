"""Expected perft counts for awkward positions, from python-chess (an independent move generator).
Writes tests/engine/data/perft_extra.json: [[fen, [n1, n2, ...]], ...].
    python -E -P tools/audit/gen_perft.py
Depth is raised until the count passes LIMIT (or MAXD), so each case stays quick."""
import json, os, sys, time
import chess

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '..', '..', 'tests', 'engine', 'data', 'perft_extra.json')
LIMIT, MAXD = 600_000, 6

FENS = [
    # en passant that would expose the king (horizontal and diagonal pins)
    '3k4/3p4/8/K1P4r/8/8/8/8 b - - 0 1',
    '8/8/4k3/8/2p5/8/B2P2K1/8 w - - 0 1',
    '8/8/1k6/2b5/2pP4/8/5K2/8 b - d3 0 1',
    '8/8/8/8/k2Pp2Q/8/8/3K4 b - d3 0 1',
    '8/8/8/2k5/2pP4/8/B7/4K3 b - d3 0 3',
    '8/8/8/1k6/3Pp3/8/8/4KQ2 b - d3 0 1',
    '8/1k6/8/K1pP3r/8/8/8/8 w - c6 0 2',
    '4k3/8/8/r2pP2K/8/8/8/8 w - d6 0 2',
    '8/8/8/K7/1pP4q/8/8/7k b - c3 0 1',
    '7k/8/8/1pP5/8/8/8/K5b1 w - b6 0 2',
    # en passant out of check (the checking pawn is taken) and ep when in check by something else
    '8/8/8/2k5/3Pp3/8/8/4K3 b - d3 0 1',
    '8/8/8/8/2kPp3/8/8/4K3 b - d3 0 1',
    '4k3/8/8/3pP3/4K3/8/8/8 w - d6 0 2',
    # castling: gives check, rights edge cases, through/into/out of check, rook missing or attacked
    '5k2/8/8/8/8/8/8/4K2R w K - 0 1',
    '3k4/8/8/8/8/8/8/R3K3 w Q - 0 1',
    'r3k2r/1b4bq/8/8/8/8/7B/R3K2R w KQkq - 0 1',
    'r3k2r/8/3Q4/8/8/5q2/8/R3K2R b KQkq - 0 1',
    'r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1',
    'r3k2r/8/8/8/8/8/8/1R2K2R b Kkq - 0 1',
    'r3k2r/8/8/8/8/8/8/2R1K2R b Kkq - 0 1',
    'r3k2r/8/8/8/8/8/8/R3K1R1 b Qkq - 0 1',
    '1r2k2r/8/8/8/8/8/8/R3K2R w KQk - 0 1',
    '2r1k2r/8/8/8/8/8/8/R3K2R w KQk - 0 1',
    'r3k1r1/8/8/8/8/8/8/R3K2R w KQq - 0 1',
    '4k2r/8/8/8/8/8/8/4K3 w k - 0 1',
    'r3k3/8/8/8/8/8/8/4K3 w q - 0 1',
    '4k3/8/8/8/8/8/8/4K2R w K - 0 1',
    '4k3/8/8/8/8/8/8/R3K3 w Q - 0 1',
    'r3k2r/8/8/8/8/8/8/R3K2R w - - 0 1',
    'r3k2r/8/8/8/8/8/6p1/R3K2R w KQkq - 0 1',
    'r3k2r/8/8/8/8/8/1p6/R3K2R w KQkq - 0 1',
    'r3k2r/8/8/8/8/8/8/RN2K1NR w KQkq - 0 1',
    'r3k2r/8/8/8/4q3/8/8/R3K2R w KQkq - 0 1',
    'r3k2r/8/8/8/8/8/5n2/R3K2R w KQkq - 0 1',
    '1k6/1b6/8/8/7R/8/8/4K2R b K - 0 1',
    'R6r/8/8/2K5/5k2/8/8/r6R w - - 0 1',
    # promotions, with capture, out of check, giving check, under-promotion
    '2K2r2/4P3/8/8/8/8/8/3k4 w - - 0 1',
    '4k3/1P6/8/8/8/8/K7/8 w - - 0 1',
    '8/P1k5/K7/8/8/8/8/8 w - - 0 1',
    'n1n5/PPPk4/8/8/8/8/4Kppp/5N1N b - - 0 1',
    'n1n5/1Pk5/8/8/8/8/5Kp1/5N1N w - - 0 1',
    '8/PPPk4/8/8/8/8/4Kppp/8 w - - 0 1',
    'r3k2r/1P6/8/8/8/8/1p6/R3K2R w KQkq - 0 1',
    # discovered check, stalemate and mate traps, knights
    '8/8/1P2K3/8/2n5/1q6/8/5k2 b - - 0 1',
    'K1k5/8/P7/8/8/8/8/8 w - - 0 1',
    '8/k1P5/8/1K6/8/8/8/8 w - - 0 1',
    '8/8/2k5/5q2/5n2/8/5K2/8 b - - 0 1',
    'K7/8/2n5/1n6/8/8/8/k6N w - - 0 1',
    '8/1n4N1/2k5/8/8/5K2/1N4n1/8 w - - 0 1',
    '6kq/8/8/8/8/8/8/7K w - - 0 1',
    # a position with 218 legal moves (the maximum known)
    'R6R/3Q4/1Q4Q1/4Q3/2Q4Q/Q4Q2/pp1Q4/kBNN1KB1 w - - 0 1',
    # middlegames from the perft suites
    'r3k2r/p1pp1pb1/bn2Qnp1/2qPN3/1p2P3/2N5/PPPBBPPP/R3K2R b KQkq - 3 2',
    '2kr3r/p1ppqpb1/bn2Qnp1/3PN3/1p2P3/2N5/PPPBBPPP/R3K2R b KQ - 3 2',
    'rnb2k1r/pp1Pbppp/2p5/q7/2B5/8/PPPQNnPP/RNB1K2R w KQ - 3 9',
    'r1bqkbnr/pppppppp/n7/8/8/P7/1PPPPPPP/RNBQKBNR w KQkq - 2 2',
    'rnbqkbnr/pppp1ppp/8/4p3/3P4/8/PPP1PPPP/RNBQKBNR w KQkq e6 0 2',
    'rnbqkb1r/ppppp1pp/7n/4Pp2/8/8/PPPP1PPP/RNBQKBNR w KQkq f6 0 3',
    'r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1',
]

def perft(b, d):
    if d == 1:
        return b.legal_moves.count()
    n = 0
    for m in b.legal_moves:
        b.push(m); n += perft(b, d - 1); b.pop()
    return n

out = []
t0 = time.time()
for fen in FENS:
    b = chess.Board(fen)
    assert b.status() in (chess.STATUS_VALID, chess.STATUS_IMPOSSIBLE_CHECK), (fen, b.status())
    counts = []
    for d in range(1, MAXD + 1):
        n = perft(b, d)
        counts.append(n)
        if n > LIMIT:
            break
    out.append([fen, counts])
    print(fen, counts, f'{time.time() - t0:.0f}s', flush=True)
with open(OUT, 'w', encoding='utf-8') as f:
    json.dump(out, f, indent=0)
print(len(out), 'positions written to', os.path.normpath(OUT))
