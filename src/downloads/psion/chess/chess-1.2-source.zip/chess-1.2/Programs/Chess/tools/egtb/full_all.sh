#!/bin/sh
# All schemes x block sizes for the best orders (snake square order), in parallel.
cd "$(dirname "$0")"
O="$EGTB_DIR/full"; mkdir -p "$O"
SQORDER=snake node compress.js KRvKB w full 3102 > "$O/KRvKB_w.txt" &
SQORDER=snake node compress.js KRvKB b full 1230 > "$O/KRvKB_b.txt" &
SQORDER=snake node compress.js KRvKN w full 0312 > "$O/KRvKN_w.txt" &
SQORDER=snake node compress.js KRvKN b full 3012 > "$O/KRvKN_b.txt" &
SQORDER=snake node compress.js KQvKP w full 0231 > "$O/KQvKP_w.txt" &
SQORDER=snake node compress.js KQvKP b full 0321 > "$O/KQvKP_b.txt" &
PSLICE=4 SQORDER=snake node compress.js KQvKP b full 0321 > "$O/KQvKP_b_slice.txt" &
SQORDER=snake node compress.js KRvKP w full 0123 > "$O/KRvKP_w.txt" &
SQORDER=snake node compress.js KRvKP b full 0231 > "$O/KRvKP_b.txt" &
PSLICE=4 SQORDER=snake node compress.js KRvKP b full 0231 > "$O/KRvKP_b_slice.txt" &
SQORDER=snake node compress.js KPvKP w full 0132 > "$O/KPvKP_w.txt" &
BINARY=1 SQORDER=snake node compress.js KPvKP w full 0132 > "$O/KPvKP_w_bin.txt" &
SQORDER=snake node compress.js KBNvK b full 2301 > "$O/KBNvK_b.txt" &
wait
echo FULLDONE
