'use strict';
// A helper pack for slot C: with small OPL procedures the audit tests use (made with
// Tools/opl2opk.py, which translates them as the LZ's ROM does).
//   FREEP  prints FREE        DIRP  lists the data files on A:       NOP  does nothing
//   LOWxxx LOCAL a%(n) then CHESS: (CHESS run with n*2 bytes less free RAM)
//   FILLA  fills A: with 250-byte records until it is full; DELF deletes that file
//   DUMMY  what the launchers do, without the game: a big array and a USR call
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const L = require('./lib.js');

const DIR = path.join(L.ROOT, 'build', 'test', 'help');
const PROCS = {
  NOP: ['NOP:'],
  FREEP: ['FREEP:', 'PRINT "FREE";FREE', 'GET'],
  DIRP: ['DIRP:', 'LOCAL d$(12),s$(200)', 'd$=DIR$("A:")', 'WHILE d$<>""', 's$=s$+d$+" "', 'd$=DIR$("")', 'ENDWH', 'PRINT "DIR ";s$', 'GET'],
  FILLA: ['FILLA:', 'LOCAL n%', 'ONERR full', 'CREATE "A:ZZFILL",A,B$', 'DO', 'A.B$=REPT$("X",250)', 'APPEND', 'n%=n%+1', 'UNTIL 0',
    'full::', 'ONERR OFF', 'CLOSE', 'PRINT "FILLED";n%', 'GET'],
  DELF: ['DELF:', 'DELETE "A:ZZFILL"'],
  // like the launchers: a big array, a byte of machine code (RTS) called with USR, then back
  DUMMY: ['DUMMY:', 'LOCAL m%(9000),v%(9),i%', 'POKEB ADDR(v%()),57', 'i%=USR(ADDR(v%()),ADDR(m%()))'],
};

// extra: {NAME: [lines], or a Buffer: an .ob3}; returns the .opk path
function make(extra, name) {
  const dir = path.join(DIR, name || 'std');
  fs.rmSync(dir, { recursive: true, force: true });
  fs.mkdirSync(dir, { recursive: true });
  const all = Object.assign({}, PROCS, extra || {});
  for (const [n, lines] of Object.entries(all)) {
    if (Buffer.isBuffer(lines)) fs.writeFileSync(path.join(dir, n + '.ob3'), lines);
    else fs.writeFileSync(path.join(dir, n + '.opl'), lines.join('\n') + '\n', 'latin1');
  }
  const out = path.join(L.ROOT, 'build', 'test', (name || 'std') + '_help.opk');
  const r = spawnSync('python', ['-E', '-P', path.join(L.ROOT, '..', '..', 'Tools', 'opl2opk.py'), '-f', out].concat(Object.keys(all).map((n) => path.join(dir, n + (Buffer.isBuffer(all[n]) ? '.ob3' : '.opl')))), { encoding: 'utf8' });
  if (r.status !== 0) throw new Error('opl2opk failed: ' + r.stdout + r.stderr);
  return out;
}
const low = (words, name) => [(name || 'LOW' + words) + ':', 'LOCAL a%(' + words + ')', 'CHESS:'];

// run a procedure from the top-level menu (C:), return the screen after s seconds
function run(m, name, s, dev) { m.runProc(name, dev || 'C'); m.runSeconds(s || 2); return m.screenText(); }
// back to the top-level menu
function top(m) {
  for (let i = 0; i < 6 && !m.screenText().includes('Find'); i++) { m.press('ON', 3, 10); m.runSeconds(0.7); }
  return m.screenText().includes('Find');
}
function free(m) {
  const t = run(m, 'FREEP', 2);
  const mm = /FREE\s*(\d+)/.exec(t);
  m.press('EXE', 3, 10); m.runSeconds(1); top(m);
  return mm ? +mm[1] : -1;
}
function dir(m) {
  const t = run(m, 'DIRP', 3).replace(/\n/g, '');
  m.press('EXE', 3, 10); m.runSeconds(1); top(m);
  return t.replace(/^DIR /, '').trim();
}
module.exports = { make, low, run, top, free, dir };
