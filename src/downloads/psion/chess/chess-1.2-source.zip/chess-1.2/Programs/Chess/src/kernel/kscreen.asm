; ---------------------------------------------------------------------
; Screen: overlays draw into kv_cells and kv_glyph; scr_flush sends them
; straight to the LCD controller (the ROM's DP$PRNT costs a whole 50 ms
; tick for 80 characters, measured for Phaselock). It sends all 80 cells
; (no copy of the LCD is kept, to save its 80 bytes), in runs: the LCD's
; address moves on by itself, so it is set only where a run breaks.
; ---------------------------------------------------------------------

; the glyphs are resent at the next flush
scr_init:
        ldaa #$FF
        staa kv_gdirty
        ; fall through

; blank the cell buffer, cursor home
scr_cls:
        ldx  #kv_cells
        ldd  #$2000+80          ; spaces, 80 (UT$FILL)
        os   UT$FILL
        clr  kv_cur
        rts

; A = row 0..3, B = column 0..19
scr_at: pshb
        ldab #20
        mul
        pula
        aba
        staa kv_cur
        rts

; A = character at the cursor; the cursor stops at the last cell
scr_putc:
        pshx
        ldab kv_cur
        ldx  #kv_cells
        abx
        staa 0,x
        cmpb #79
        bhs  .x
        inc  kv_cur
.x:     pulx
        rts

; B = count, A = character
scr_fill:
        tstb
        beq  .x
.l:     pshb
        bsr  scr_putc
        pulb
        decb
        bne  .l
.x:     rts

; X = length-prefixed string
scr_puts:
        ldab 0,x
        beq  .x
.l:     inx
        ldaa 0,x
        pshb
        bsr  scr_putc
        pulb
        decb
        bne  .l
.x:     rts

; the length-prefixed string after the jsr; returns after it
scr_pri:
        pulx
        pshx
        bsr  scr_puts
        pulx
        ldab 0,x
        abx
        inx
        jmp  0,x

; clear from the cursor to the end of its row
scr_eol:
        ldaa kv_cur
.l:     cmpa #20
        blo  .r
        suba #20
        bra  .l
.r:     nega
        adda #20
        tab
        ldaa #' '
        bra  scr_fill

; send changed glyphs, then changed cells. Glyphs go first so a picture
; changes all at once; after a glyph write the controller (as Jape models
; it) ignores the next "set address", so a harmless one is sent first.
scr_flush:
        ldaa kv_gdirty
        beq  .cells
        clr  kv_gdirty
        ldx  #kv_glyph
        clrb                    ; glyph number
.g:     lsra
        bcc  .gn
        psha
        pshb
        aslb                    ; CGRAM address command: $40 + 8n
        aslb
        aslb
        orab #$40
        tpa
        psha
        sei
.w3:    tst  LCD_CTRL
        bmi  .w3
        stab LCD_CTRL
        ldab #8
.gd:    ldaa 0,x
.w4:    tst  LCD_CTRL
        bmi  .w4
        staa LCD_DATA
        inx
        decb
        bne  .gd
        pula
        tap
        pulb
        pula
        bra  .gx
.gn:    pshb
        ldab #8
        abx
        pulb
.gx:    incb
        tsta
        bne  .g
        ldab #$80               ; back to display RAM
.w5:    tst  LCD_CTRL
        bmi  .w5
        stab LCD_CTRL
.cells: tpa                     ; the OS's interrupts leave the LCD alone meanwhile
        psha
        sei
        ldx  #kv_cells
        clrb                    ; the cell
        clra
        psha                    ; the address the LCD is at (none yet)
.lp:    stx  kv_t0
        pshb
        ldx  #lcdtab
        abx
        ldab 0,x                ; "set address" command for this cell
        tsx
        cmpb 1,x
        beq  .seq               ; the LCD is there already
.w1:    tst  LCD_CTRL
        bmi  .w1
        stab LCD_CTRL
.seq:   incb
        stab 1,x                ; where it moves on to
        ldx  kv_t0
        ldaa 0,x
.w2:    tst  LCD_CTRL
        bmi  .w2
        staa LCD_DATA
        inx
        pulb
        incb
        cmpb #80
        bne  .lp
        pula
        pula
        tap
        rts

; LCD address commands for the 80 cells, row major (from Phaselock)
lcdtab: fcb  $80,$81,$82,$83,$88,$89,$8A,$8B,$8C,$8D,$8E,$8F,$98,$99,$9A,$9B,$9C,$9D,$9E,$9F
        fcb  $C0,$C1,$C2,$C3,$C8,$C9,$CA,$CB,$CC,$CD,$CE,$CF,$D8,$D9,$DA,$DB,$DC,$DD,$DE,$DF
        fcb  $84,$85,$86,$87,$90,$91,$92,$93,$94,$95,$96,$97,$A0,$A1,$A2,$A3,$A4,$A5,$A6,$A7
        fcb  $C4,$C5,$C6,$C7,$D0,$D1,$D2,$D3,$D4,$D5,$D6,$D7,$E0,$E1,$E2,$E3,$E4,$E5,$E6,$E7

; the map's eight glyphs (the board screen's; sent at the first flush and after
; switch-on). Fixed data since 17 Nov: was rmb, set by the board overlay.
; glyph rows: a square is 5x3 dots, the top one rows 0-2, the bottom 4-6
G_W0    = %11111                ; white: a hollow block
G_W1    = %10001
G_B     = %11111                ; black: a solid block
kv_glyph: fcb  G_B,G_B,G_B,0,G_B,G_B,G_B,0      ; 0 black over black
          fcb  G_B,G_B,G_B,0,G_W0,G_W1,G_W0,0   ; 1 black over white
          fcb  G_B,G_B,G_B,0,0,0,0,0            ; 2 black over empty
          fcb  G_W0,G_W1,G_W0,0,G_B,G_B,G_B,0   ; 3 white over black
          fcb  G_W0,G_W1,G_W0,0,G_W0,G_W1,G_W0,0 ; 4 white over white
          fcb  G_W0,G_W1,G_W0,0,0,0,0,0         ; 5 white over empty
          fcb  0,0,0,0,G_B,G_B,G_B,0            ; 6 empty over black
          fcb  0,0,0,0,G_W0,G_W1,G_W0,0         ; 7 empty over white
