# Test audit (16 Nov 2026)

On the morning of 16 Nov the program was checked against a checklist covering the book, the rules,
the engine, endgames, screens and clocks, and the Organiser. This page answers each item of that
checklist and points to the detailed reports:

- [audit-book.md](audit-book.md): the opening book.
- [audit-engine.md](audit-engine.md): the rules, the engine and endgames.
- [audit-ui.md](audit-ui.md): the screens, the clocks and the Organiser.
- [strength.md](strength.md), section 8: the levels.
- [ui-report.md](ui-report.md), *RAM changes, 16 Nov*: what was done with the RAM.

The reference engine is the JavaScript one in `ref/`; there is no C version. Everything was run in
the emulator and on the PC. Nothing was tried on a real Organiser.

**Final state, all on one build (65.2K pack, 20,919-byte RAM array with a 512-entry table; since then the Zobrist change took the array to 19,975, docs/ui-report.md):**

- **Engine suite:** passes, except `ref/mates.js`, whose fixed bishop + knight start still fails.
  From random starts that mate succeeds about 80% of the time.
- **UI suite:** all 14 test files pass.
- **Long UI runs:** an hour of clock, low memory and the soak all pass.
- **Book:** the Psion's book reader agrees with an independent decoder (394 checks), and
  `book.py selftest` passes.

## The opening book

| Item | Result |
|---|---|
| No terrible moves (> 50 cp below Stockfish's best) | 6 found in the old book (worst −60); 0 in the rebuilt one (worst −49). Stockfish at depth 22, confirmed at 26. |
| Mistakes get punished | Old book: 141 places where the book ended right after a club blunder of 90 cp or more and the engine then missed the refutation (e.g. 5.Nxe5 for 5.Bxf7+, −692 cp). Rebuilt: 2, at −40 and −59. |
| Safe exits (first own move after the book drops ≥ 1 pawn) | Old: 235 of 3,547 exits (5.5% of play). Rebuilt: 1 of 3,009 (0.01%). Lines were extended or cut by a new post-pass in `build_book.py`. |
| Sound structure | An independent decoder (`tools/book/audit/decode.js`) found 0 errors. The 6303 reader agrees with it in the emulator: 394 checks on the final build, 5,259 during the audit. |
| Coverage, still in book at moves 4 / 6 / 8 | As White 69 / 16 / 2%; as Black 33 / 5 / 1% (simulated against club move frequencies). The book is broad, not deep. |

The book went from 11,084 bytes and 5,494 moves to 11,602 bytes and 5,744 moves; the old one is kept
as `data/book_v1.bin`.

## The rules

| Item | Result |
|---|---|
| Move counts on awkward positions | 58 positions, counts from python-chess: all match, in JS and in assembler. |
| Special cases | 76 cases through the engine's API, and 300 random games (39,470 positions), all checked against python-chess: castling through check, en passant exposing the king, under-promotion, stalemate, repetition, the fifty-move rule, insufficient material. **Fixed:** the en-passant square was set after every double push, so a threefold repetition was missed (5 failures; now 0). |
| Take back across each | 156 take-backs compared with an independent model (castling, en passant, promotion, captures, check, game ends, chains): all match. **Fixed:** take back didn't restore the clocks. |

## The engine

| Item | Result |
|---|---|
| Same answers as the reference | Node for node (move, score, depth, nodes) on every parity test, after every change. |
| Mirror test | **Fixed:** a position and its colour-flipped twin differed by 1 cp in 57% of pairs (the phase blend rounded down). Now 0 in 13,708 pairs. |
| Tactics per level | 100 mate-in-2 and 100 win-a-piece positions built with Stockfish. Level 7 solves 97% and 99%; level 1, 24% and 61%. |
| Level order | Each level beats the one below, every interval clear of zero (from +304 for level 2 over 1 to +125 for level 6 over 5). Measured strengths: 450, 650, 900, 1200, 1500, 1550, 1650 and 1850 for levels 1-8; the level menu shows these. |
| Levels 2-4 never allow mate in one | **Fixed:** they allowed it in about 1 move in 7 of the test positions; now never. Level 5 still did once. |
| Soak | 13,552 JS games checked by python-chess with no illegal move, crash or wrong ending, plus 20 assembler games matched move by move. **Fixed:** a level-2 game hung in the random pick; a 1 s limit ran 2.5 s (now 1.09 s); depth 1 could take minutes (now at most about 15 s). |

## Endgames

| Item | Result |
|---|---|
| The pawn table, all 196,608 entries | Agrees with two independent solvers bit for bit (re-run). |
| Basic mates from random starts | Queen 100%, rook reliable, bishop + knight 80% (was 46%) within the fifty-move rule. |
| No stalemating a bare king | None at any level in won endings (fixed for levels 1-4, which could). |

## Screens and clocks

| Item | Result |
|---|---|
| Screen round trip | The screen read back into a position: 6,101 checks over all layouts, both sides, flipped. |
| Notation against a reference library | 6,394 moves against python-chess, including double disambiguation. **Fixed:** queen-side castling showed as Kc1. |
| Clock drift over an hour | The frame counter runs 1.2 s an hour slow in the emulator. On hardware, the screen flush and the beeper masking interrupts should cost about 3 s an hour. The pack reads don't mask. |
| Switch-off at every moment | Every waiting state switches off and resumes exactly. **Fixed:** with a blinking cursor (typed square, pointing, set-up) it never switched off. |

## The Organiser

| Item | Result |
|---|---|
| Leaves nothing behind | Free RAM, the files, the key settings, CAPS and NUM, auto-off, the beep and the clock are as before after every way out. Only A:CHESSAV is new. One display byte changes from 255 to 128; both mean "no clock". |
| Low memory | Every table size, and the message when RAM is short, checked at the exact boundaries. **Fixed:** the message read "NEEDS4BYTES"; a full A: lost the game silently (now CANNOT SAVE: NO ROOM). |

## Other bugs found on the way

- **Wrong side shown after a game:** the turn line showed the wrong side once the game had ended.
- **Set-up positions:**
  - move numbers were one short when Black moved first;
  - the computer played book moves.
- **Custom clocks:** times over 54 minutes wrapped round.
- **Pack removed:** the next screen load ran leftover code.

## What is still open

- **Bishop + knight mates:** they succeed in about 80% of starts, not 100%.
- **Draw rules:**
  - bishops all on one colour aren't scored as a draw;
  - in the search, a mate on the 100th half-move counts as a draw (the game itself gets it right).
- **Level 5** allowed mate in one in one test position.
- **Book depth:** the book is shallow, and leaves most games by move 6.
- **Real hardware:** none of this was tried on a real Organiser (milestone 7). That includes the true
  speed, the LCD glyphs, pack read speed, the clock against a real crystal, and battery behaviour.
