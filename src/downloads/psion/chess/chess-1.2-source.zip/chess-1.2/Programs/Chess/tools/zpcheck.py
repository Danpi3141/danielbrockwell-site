"""Checks the variables placed by hand in the zero page the game borrows (ZP2, src/defs.inc).

The engine's temporaries and each overlay's variables share it, one at a time: within each, none may overlap
another, none may be at ZP2+21 ($E1, which a ringing alarm writes), and none may be past the 42 bytes. Run by build.py.
"""
import os
import re

SRC = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'src')
SIZE = 42
ALARM = 21
WORDS = {'e_t': 8, 'bk_sq': 3, 'in_buf': 4, 'rl_buf': 6}                       # the rest are 1, or 2 if listed here
for n in ('e_fp e_ofp e_pend e_wp e_gpst e_gptr e_sc fp_out fp_p bk_key bk_len sv_rn sv_p pg_sp pg_x dr_p pw_t se_p rv_p rv_sc ib_rn ib_p '
          'kk_kind kk_dptr kk_ix kk_pos kk_n kk_code kk_first kk_lx').split():
    WORDS[n] = 2


def sources(path, seen=None):
    """A source file and what it includes (the engine's and the kernel's own files apart)."""
    seen = seen if seen is not None else []
    if path in seen or not os.path.exists(path):
        return seen
    seen.append(path)
    with open(path, encoding='latin-1') as f:
        for inc in re.findall(r'(?m)^\s+include\s+"([^"]+)"', f.read()):
            if os.path.basename(inc) not in ('defs.inc', 'ids.inc'):
                sources(os.path.join(os.path.dirname(path), inc), seen)
    return seen


def check():
    groups = {'the engine': [os.path.join(SRC, 'engine', 'evars.inc')]}
    d = os.path.join(SRC, 'screens')
    for f in sorted(os.listdir(d)):
        if f.startswith('ov_') and f.endswith('.asm'):
            groups[f] = sources(os.path.join(d, f))
    bad = []
    for g, files in groups.items():
        used = {}
        for p in files:
            with open(p, encoding='latin-1') as f:
                for n, o in re.findall(r'(?m)^(\w+) += ZP2\+(\d+)', f.read()):
                    for k in range(int(o), int(o) + WORDS.get(n, 1)):
                        if k in used:
                            bad.append('%s: %s and %s both at ZP2+%d' % (g, used[k], n, k))
                        if k == ALARM or k >= SIZE:
                            bad.append('%s: %s at ZP2+%d' % (g, n, k))
                        used[k] = n
    return bad


if __name__ == '__main__':
    print(check() or 'ok')
