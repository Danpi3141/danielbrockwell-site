#!/bin/sh
# 16 Nov: level 5 now 3 s (was 5), level 8 now 255 s (was 100); as run_levels_v5.sh otherwise
M="python -E -P match.py"
O="--start 242 --openings 0:242 --workers 12"
E="snap_z64c"
K="Book=true,KPK=true"
$M lv6_L5_sf1320 $E:Nodes=207,$K sf:1320 $O > logs_lv6_L5_sf1320.txt 2>&1
$M lv6_L5_L4 $E:Nodes=207,$K $E:Nodes=207,Margin=30,BookMoves=4,$K $O > logs_lv6_L5_L4.txt 2>&1
$M lv6_L8_sf1800 $E:Nodes=17600,$K sf:1800 $O > logs_lv6_L8_sf1800.txt 2>&1
$M lv6_L8_sf1900 $E:Nodes=17600,$K sf:1900 $O > logs_lv6_L8_sf1900.txt 2>&1
$M lv6_L8_sf2000 $E:Nodes=17600,$K sf:2000 $O > logs_lv6_L8_sf2000.txt 2>&1
python -E -P analyze.py lv6_L5_sf1320 lv6_L5_L4 lv6_L8_sf1800 lv6_L8_sf1900 lv6_L8_sf2000 | grep -v histogram
python -E -P analyze.py --fit lv6_L8_sf1800 lv6_L8_sf1900 lv6_L8_sf2000 | tail -1
