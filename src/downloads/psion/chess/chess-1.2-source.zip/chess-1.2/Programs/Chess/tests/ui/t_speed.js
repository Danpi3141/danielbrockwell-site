const L = require('./lib.js');
const m = L.start();
L.idle(m);
const res = L.sym(m,'kv_res');
L.keys(m, ['E','V','E']); const c0=m.cycles();
m.press('O',3,0);
let t=0; while(t<400){ m.runTicks(1); t++; if (m.peek(res)===1 && m.dbg.sleeping() && L.peekSym(m,'e_side')[0]===0 && t>5) break; }
console.log('player move to player turn (stub reply):', ((m.cycles()-c0)/921600).toFixed(2),'s');
