'use strict';
// King and pawn v king from the distance table (ref/kpkroot.js), both sides played by it, from
// random starts (and every start where one wrong move changes the result): the pawn's side must
// promote safely exactly when the old win/draw table (data/kpk.bin) says it wins, and in exactly
// the table's number of moves (the defender takes the slowest loss); a drawn start stays drawn.
//   node tests/engine/t_kpkroot.js [starts=3000] [--raw]
const path = require('path');
const fs = require('fs');
const { Engine, legalMoves } = require('../../ref/search.js');
const { kpkRoot, look } = require('../../ref/kpkroot.js');
const kpk = require('../../tools/kpk/probe.js');

const TAB = fs.readFileSync(path.join(__dirname, '..', '..', 'data', process.argv.includes('--raw') ? 'kpkd.bin' : 'kpkdz.bin'));   // the pack's compressed table (--raw: kpkd.bin)
const BIT = kpk.load();
const N = +(process.argv.slice(2).find((a) => !a.startsWith('--')) || 3000);
let rng = 12345;
const rnd = (k) => { rng ^= rng << 13; rng >>>= 0; rng ^= rng >>> 17; rng ^= rng << 5; rng >>>= 0; return rng % k; };
const sq88 = (s) => (s >> 3) * 16 + (s & 7);
function fenOf(wk, bk, p, pc, stm) {
  const b = Array(64).fill('');
  b[wk] = 'K'; b[bk] = 'k'; b[p] = pc ? 'p' : 'P';
  const rows = [];
  for (let r = 7; r >= 0; r--) { let s = '', n = 0; for (let f = 0; f < 8; f++) { const c = b[r * 8 + f]; if (!c) n++; else { if (n) s += n; n = 0; s += c; } } if (n) s += n; rows.push(s); }
  return rows.join('/') + (stm ? ' b' : ' w') + ' - - 0 1';
}

let n = 0, bad = 0, wins = 0, draws = 0, slow = 0, nulls = 0;
const fails = [];
while (n < N) {
  const pc = rnd(2), stm = rnd(2), p = 8 + rnd(48), wk = rnd(64), bk = rnd(64);
  if (new Set([p, wk, bk]).size < 3) continue;
  const e = new Engine();
  e.setFen(fenOf(wk, bk, p, pc, stm)); e.ply = 0;
  if (e.attacked(e.ksq[(e.side ^ 8) >> 3], e.side)) continue;   // the side not to move in check
  if (Math.max(Math.abs((wk & 7) - (bk & 7)), Math.abs((wk >> 3) - (bk >> 3))) < 2) continue;
  if (!legalMoves(e).length) continue;
  n++;
  const win = kpk.probe(BIT, wk, bk, p, stm, pc);
  // the table's distance for the start (the pawn's side to move: direct; else the defender's worst)
  const strongToMove = (e.side >> 3) === pc;
  const sk = e.ksq[pc], dk = e.ksq[pc ^ 1], pp = sq88(p);
  let promoted = false, plies = 0, strongMoves = 0;
  for (; plies < 200; plies++) {
    const ms = legalMoves(e);
    if (!ms.length) break;
    let pawns = 0;
    for (let s = 0; s < 128; s++) { if (s & 0x88) { s += 7; continue; } const t = e.b[s] & 7; if (t === 1) pawns++; if (t >= 2 && t <= 5) promoted = true; }
    if (promoted || !pawns) break;
    const mv = kpkRoot(e, TAB);
    if (!mv) { nulls++; break; }                                  // a drawn position, the pawn's side to move
    if (!ms.some((m) => m[0] === mv[0] && (m[1] & 0x77) === (mv[1] & 0x77))) { bad++; fails.push('illegal ' + mv + ' in ' + fenOf(wk, bk, p, pc, stm)); break; }
    if ((e.side >> 3) === pc) strongMoves++;
    e.make(mv[0], mv[1]); e.ply = 0;
  }
  // a promotion counts if the new piece survives the next move and isn't stalemate
  let won = false;
  for (let s = 0; s < 128; s++) { if (s & 0x88) { s += 7; continue; } const t = e.b[s] & 7; if (t >= 2 && t <= 5) promoted = true; }
  if (promoted) {
    const ms = legalMoves(e);
    won = ms.length > 0 ? !ms.some((m) => { const t = e.b[m[1] & 0x77] & 7; return t >= 2 && t <= 5; }) : e.inCheck();   // (none: mate, or stalemate)
  }
  if (won !== (win === 1)) { bad++; if (fails.length < 6) fails.push((win ? 'missed win ' : 'lost draw ') + fenOf(wk, bk, p, pc, stm)); }
  if (win) wins++; else draws++;
  if (won && strongToMove) {                                     // exactly the table's number of moves
    const d0 = look(TAB, sq88(pc ? bk : wk), sq88(pc ? wk : bk), pp, pc ? 8 : 0);
    if (strongMoves !== d0) { slow++; if (fails.length < 6) fails.push('took ' + strongMoves + ' moves, table ' + d0 + ': ' + fenOf(wk, bk, p, pc, stm)); }
  }
}
console.log(`${n} starts: ${wins} won, ${draws} drawn; wrong results ${bad}; wins not in the table's number of moves ${slow}; pawn side to move in a draw (search plays) ${nulls}`);
fails.forEach((f) => console.log('  ' + f));
console.log(bad || slow ? 'FAILED' : 'kpk root ok');
process.exit(bad || slow ? 1 : 0);
