; =====================================================================
; The board overlay (slot A): drawing, move entry, notation, blinking,
; the clocks. Entries (B_* in kcore.asm):
; =====================================================================
        include "../defs.inc"
        include "ids.inc"

        jmp  human_turn         ; 0  A = H_* (H_MOVE: hu_f, hu_t)
        jmp  human_look         ; 1  after the game: A = H_BACK or H_MENU
        jmp  bshow              ; 2  draw and send
        jmp  blink_move         ; 3
        jmp  clk_moved          ; 4  before a move: the mover's clock
        rts                     ; 5  (unused)
        nop
        nop
        rts                     ; 6  (the clocks' reset moved to OV_GAME 13, 17 Nov)
        nop
        nop
        jmp  clk_start          ; 7
        rts                     ; 8  (unused)
        nop
        nop
        jmp  clk_share          ; 9  D = frames
        jmp  pace_wait          ; 10 pw_a
        jmp  set_turn           ; 11
        rts                     ; 12 (the hint's text moved to OV_GAME 14, 17 Nov)
        nop
        nop

        include "kboard.asm"
        include "krnd.asm"
        include "kentry.asm"
        include "kclock.asm"
        include "kmisc.asm"
        include "ovars_b.inc"
