'use strict';
// Leaves nothing behind (audit check 6).
//   node tests/ui/t_leave.js
// The Organiser's state is taken at the top-level menu before CHESS runs and again after it
// has gone, by every way out: SAVE AND LEAVE, after a game has ended, ON/CLEAR and Q pressed
// while it starts, an error (game files damaged, too little RAM, the pack taken out
// while it runs). Compared: FREE, the data files on A: (only A:CHESSAV may appear), the
// system variables ($40-$FF and $2000-$21FF, less the bytes that change by themselves:
// found by running a procedure that does nothing the same way), the eight user-defined
// glyphs (the LZ's top line uses them), and the real-time clock against emulated time.
// Before the first run the key settings are set to unusual values (repeat delay 20, rate 5,
// key click on, auto-off 123 s, CAPS and NUM lock on) to see that they are put back.
const path = require('path');
const fs = require('fs');
const L = require('./lib.js');
const H = require('./help.js');
const { Machine } = require('../../tools/emu.js');

let fails = 0;
function soft(cond, msg, m) { if (!cond) { fails++; console.log('FAIL ' + msg + (m ? '\n' + m.screenText() : '')); } else console.log('ok   ' + msg); return cond; }

const SYS = [[0x40, 0x100], [0x2000, 0x2200]];
// working storage the OS and OPL change in any program (jaapsch.net/psion/sysvars.htm):
// utw_s0-s5 scratch and utw_r0-r6 (OPL uses them), the key buffer's pointers and repeat count, the auto-off count-down,
// the pack and file services' current device, address and record, OPL's run-time
// variables, xxb_xxxx, the SWI scratch, the NMI count, the type-ahead buffer, UT$DISP's
// buffer, the clock's colon count-down and last minute, the run-time buffer rtt_bf
const SCRATCH = new Set();
for (const [a, b] of [[0x41, 0x5b], [0x61, 0x62], [0x73, 0x77], [0x79, 0x7b], [0x7d, 0x7f], [0x8b, 0xa2], [0xa5, 0xc5],
  [0x2069, 0x2070], [0x2096, 0x2097], [0x2098, 0x2099], [0x20af, 0x20c0], [0x20cf, 0x20d6], [0x2187, 0x2200]]) for (let x = a; x < b; x++) SCRATCH.add(x);
// what must be exactly as before (the kernel saves and restores, or must not touch, these)
const KEEP = { 0x77: 'kbb_dlay', 0x78: 'kbb_rept', 0x7b: 'kbb_stat (CAPS, NUM)', 0x7c: 'tmb_swof', 0xa4: 'bzb_mute (beep)', 0x20c0: 'kbb_clik',
  0x20c1: 'kbb_pkof', 0x20cd: 'tmw_tcnt', 0x20ce: 'tmw_tcnt+1', 0x2090: 'dpa_scrn', 0x2091: 'dpa_scrn+1', 0x2092: 'dpb_nlin', 0x2093: 'dpb_wide',
  0x2184: 'dpb_mode', 0x2185: 'kbb_spec', 0x20a6: 'tmb_24f', 0x2062: 'btb_ignm', 0x63: 'dpb_cust (cursor)', 0x71: 'kbw_tdel', 0x72: 'kbw_tdel+1' };
const NAMES = { 0x77: 'KBB_DLAY', 0x78: 'KBB_REPT', 0x7b: 'KBB_STAT', 0x7c: 'TMB_SWOF', 0x7d: 'TMW_TOUT', 0x7e: 'TMW_TOUT+1',
  0x20c0: 'KBB_CLIK', 0x20c1: 'KBB_PKOF', 0x20cb: 'TMW_FRAM', 0x20cc: 'TMW_FRAM+1', 0x20cd: 'TMW_TCNT', 0x20ce: 'TMW_TCNT+1' };
const RTC = 0x20C5;                                     // year, month, day, hour, minute, second
function mem(m) { const out = {}; for (const [a, b] of SYS) for (let x = a; x < b; x++) out[x] = m.peek(x); return out; }
function rtcSecs(m) { const t = m.read(RTC, 6); return ((t[2] * 24 + t[3]) * 60 + t[4]) * 60 + t[5]; }
function diff(a, b, skip) { const d = []; for (const k of Object.keys(a)) if (a[k] !== b[k] && !skip.has(+k)) d.push(+k); return d; }
const hex = (x) => '$' + x.toString(16).padStart(4, '0');
const show = (a, b, d) => d.map((x) => hex(x) + (NAMES[x] ? ' ' + NAMES[x] : '') + ' ' + a[x] + '->' + b[x]).join(', ');

// LOWBIG holds enough that even the smallest launcher is refused (from the build's own figure;
// a fixed 2,000 words stopped being enough when the array shrank on 16 Nov)
const needs0 = JSON.parse(fs.readFileSync(path.join(L.BUILD, 'build.json'), 'utf8')).needs[0];
const helpPk = H.make({ LOWBIG: H.low(Math.ceil((22238 - needs0) / 2) + 300, 'LOWBIG') }, 'leave');
// a damaged copy of the pack: block CHB0 renamed, so the kernel finds no screens
const opk = fs.readFileSync(path.join(L.BUILD, 'CHESS.opk'));
const bad = Buffer.from(opk);
const at = bad.indexOf(Buffer.from('CHB0    '));
bad.write('XHB0', at, 'latin1');
const badPath = path.join(L.ROOT, 'build', 'test', 'CHESS_bad.opk');
fs.writeFileSync(badPath, bad);

function machine(pk) {
  const m = new Machine({ rom: '46a-lz64.rom', ram: 64 });
  m.boot();
  m.insertPack(pk || path.join(L.BUILD, 'CHESS.opk'), 0);
  m.insertPack(helpPk, 1);
  // unusual settings, to see that they come back
  m.poke(0x77, 20); m.poke(0x78, 5); m.poke(0x20c0, 1); m.pokew(0x20cd, 123); m.poke(0x7b, m.peek(0x7b) | 0x30);
  return m;
}
function state(m) { const top = m.cells().slice(0, 20); return { mem: mem(m), udg: m.udgs(), top, free: H.free(m), dir: H.dir(m), rtc: rtcSecs(m), cyc: m.cycles() }; }
// the board's map glyphs (kboard.asm), as the LCD holds them
const GB = [31, 31, 31], GW = [31, 17, 31], GE = [0, 0, 0];
const CHESS_GLYPHS = [[GB, GB], [GB, GW], [GB, GE], [GW, GB], [GW, GW], [GW, GE], [GE, GB], [GE, GW]].map(([t, b]) => JSON.stringify(t.concat([0], b, [0])));

// the bytes that change by themselves or with any OPL program: a procedure that does what
// the launchers do (a 18K array, a USR call) without the game, run the same way, twice
let m = machine();
const v0 = state(m);
H.run(m, 'DUMMY', 3); H.top(m);
m.runSeconds(20);
const v1 = state(m);
H.run(m, 'NOP', 3); H.top(m); H.run(m, 'DUMMY', 3); H.top(m);
m.runSeconds(7);
const v2 = state(m);
const volatile = new Set(diff(v0.mem, v1.mem, new Set()).concat(diff(v1.mem, v2.mem, new Set())));
console.log('     bytes that change by themselves:', [...volatile].map(hex).join(' '));
soft(v0.free === v1.free && v0.dir === v1.dir, 'baseline: FREE ' + v0.free + ', files on A: "' + v0.dir + '"');

function compare(name, a, b, opts) {
  opts = opts || {};
  soft(b.free === a.free, name + ': FREE ' + a.free + ' -> ' + b.free);
  const wantDir = opts.newSave ? (a.dir + ' A:CHESSAV').trim() : a.dir;
  soft(b.dir.split(' ').sort().join(' ') === wantDir.split(' ').sort().join(' '), name + ': files on A: "' + a.dir + '" -> "' + b.dir + '"');
  const keep = Object.keys(KEEP).filter((x) => a.mem[x] !== b.mem[x]);
  soft(!keep.length, name + ': key repeat, click, CAPS/NUM, auto-off, beep, display mode unchanged' + (keep.length ? ': ' + keep.map((x) => KEEP[x] + ' ' + a.mem[x] + '->' + b.mem[x]).join(', ') : ''));
  const d = diff(a.mem, b.mem, new Set([...volatile, ...SCRATCH]));
  soft(!d.length, name + ': no other system variable changed' + (d.length ? ': ' + show(a.mem, b.mem, d) : ''));
  // the top line's clock redefines its glyphs as the time changes: none of the game's may be left
  const left = b.udg.filter((g) => CHESS_GLYPHS.includes(JSON.stringify(g)));
  soft(!left.length && JSON.stringify(b.top) === JSON.stringify(a.top), name + ": the top line drawn with the OS's own glyphs" + (left.length ? ': ' + left.length + " of the game's are left" : ''));
  const el = (b.cyc - a.cyc) / 921600, dt = b.rtc - a.rtc;
  soft(Math.abs(dt - el) <= 1.5, name + ': the clock moved ' + dt + ' s in ' + el.toFixed(1) + ' s');
}

// 1. play a move, SAVE AND LEAVE (the first run makes A:CHESSAV)
m = machine();
let a = state(m);
m.runProc('CHESS', 'B'); m.runSeconds(5);
L.keys(m, ['E', 'V', 'E', 'O']); L.idle(m);
L.keys(m, ['ON']); m.runSeconds(1); L.keys(m, ['S', 'S', 'S', 'EXE']); m.runSeconds(3);
soft(H.top(m), 'SAVE AND LEAVE: back at the top level', m);
compare('save and leave (first run)', a, state(m), { newSave: true });

// 2. again with the save file there; this time a game is played to its end (two players)
a = state(m);
m.runProc('CHESS', 'B'); m._base = null; m.runSeconds(5);
L.keys(m, ['ON']); m.runSeconds(1); L.keys(m, ['S', 'S', 'EXE']); m.runSeconds(1);
for (let i = 0; i < 12; i++) L.keys(m, ['DOWN']);
L.keys(m, ['RIGHT', 'ON']); L.idle(m);
L.keys(m, ['ON']); m.runSeconds(1); L.keys(m, ['EXE']); L.idle(m);   // new game
for (const mv of ['FVFW', 'EIEP', 'GVGO', 'DJHO']) { L.keys(m, mv.split('')); m.runSeconds(2); }
m.runSeconds(3);
soft(m.screenText().includes('CHECKMATE'), 'the game ended', m);
L.keys(m, ['ON']); m.runSeconds(1); L.keys(m, ['S', 'S', 'S', 'EXE']); m.runSeconds(3);
soft(H.top(m), 'left after the game', m);
compare('after a finished game', a, state(m));

// 3. ON/CLEAR and Q pressed many times while it starts (the launcher had a second of poking to stop until 24 Nov)
a = state(m);
m.runProc('CHESS', 'B');
for (let i = 0; i < 20; i++) { m.press('ON', 2, 2); m.press('Q', 2, 2); }
m.runSeconds(3);
const inGame = /[1-8]\s*$/.test(m.screen()[0].slice(0, 9)) || m.screenText().includes('NEW GAME');
if (inGame) { L.keys(m, ['ON']); m.runSeconds(1); if (!m.screenText().includes('NEW GAME')) L.keys(m, ['ON']); m.runSeconds(1); L.keys(m, ['S', 'S', 'S', 'EXE']); m.runSeconds(3); }
soft(H.top(m), 'ON/Q pressed repeatedly while it starts: back at the top level (' + (inGame ? 'it started; left by the menu' : 'stopped') + ')', m);
compare('ON/Q repeatedly while it starts', a, state(m));

// 4. too little RAM: CHESS run from a procedure holding more than the smallest launcher can spare
a = state(m);
const t = H.run(m, 'LOWBIG', 6, 'C');
soft(/NEEDS\s*\d+\s*BYTES/.test(t.replace(/\n/g, '')), 'too little RAM: "' + t.replace(/\n/g, ' ').replace(/\s+/g, ' ').trim() + '"', m);
m.press('EXE', 3, 10); m.runSeconds(1);
soft(H.top(m), 'too little RAM: back at the top level', m);
compare('too little RAM', a, state(m));

// 5. damaged game files
m = machine(badPath);
a = state(m);
m.runProc('CHESS', 'B'); m.runSeconds(5);
soft(m.screenText().includes('GAME FILES DAMAGED'), 'damaged files: "GAME FILES DAMAGED"', m);
m.press('EXE', 3, 10); m.runSeconds(1);
soft(H.top(m), 'damaged files: back at the top level', m);
compare('damaged game files', a, state(m));

// 6. the pack taken out while the game waits, then a key that needs a screen
m = machine();
a = state(m);
m.runProc('CHESS', 'B'); m.runSeconds(5);
L.keys(m, ['E', 'V', 'E', 'O']); L.idle(m);
const pk = m.bus.getPacks()[0];
m.emptyPack(0, 0, 0);
L.keys(m, ['ON']); m.runSeconds(3);
L.keys(m, ['EXE']); m.runSeconds(2);
soft(m.screenText().includes('GAME FILES NOT FOUND'), 'pack out: "GAME FILES NOT FOUND"', m);
m.press('EXE', 3, 10); m.runSeconds(1);
m.bus.setPack(pk, 0);
soft(H.top(m), 'pack out: back at the top level', m);
compare('pack taken out', a, state(m), { newSave: true });
// and the game resumes from A:CHESSAV
m.runProc('CHESS', 'B'); m._base = null; L.idle(m);
soft(L.peekSym(m, 'g_n')[0] === 2, 'pack back: CHESS resumes the saved game (2 plies)', m);

// 7. exactly what the kernel itself leaves: the system variables when the kernel is entered
// and at its last instruction (the RTS in quit), with a move played between
const lst = fs.readFileSync(path.join(L.BUILD, 'kernel.lst'), 'utf8').split(/\r?\n/);
let qi = lst.findIndex((l) => /\squit:/.test(l)); while (!/\srts\b/.test(lst[qi])) qi++;
const QRTS = parseInt(lst[qi].slice(0, 4), 16);
m = machine();
m.runProc('CHESS', 'B'); m.runSeconds(5);
const base = L.base(m);
L.keys(m, ['ON']); m.runSeconds(1); L.keys(m, ['S', 'S', 'S', 'EXE']); m.runSeconds(3); H.top(m);
m.dbg.setBp(base);
m.runProc('CHESS', 'B');
const hitIn = m.runTo(base, 921600 * 10) === base;
m.dbg.setBp(base, false);
const sIn = mem(m);
m.cpu.execute(1); m.runSeconds(4);
L.keys(m, ['D', 'V', 'D', 'O']); L.idle(m);
L.keys(m, ['ON']); m.runSeconds(1); L.keys(m, ['S', 'S', 'S']);
m.keyDown('EXE'); const hitOut = m.runTo(base + QRTS, 921600 * 10) === base + QRTS; m.keyUp('EXE');
const sOut = mem(m);
const dk = diff(sIn, sOut, new Set([...SCRATCH, 0x6d, 0x6e, 0x20ca, 0x20cb, 0x20cc]));      // (dpw_redy counts down by itself)
console.log('     kernel entry -> exit, outside the working storage: ' + (show(sIn, sOut, dk) || 'nothing'));
soft(hitIn && hitOut && dk.every((x) => x === 0x2095), 'the kernel leaves no system variable changed but dpb_clok ($2095, the clock column: 255 -> 128, both mean "clock off")');

if (fails) { console.log(fails + ' failures'); process.exit(1); }
console.log('all leave-nothing-behind tests passed');
