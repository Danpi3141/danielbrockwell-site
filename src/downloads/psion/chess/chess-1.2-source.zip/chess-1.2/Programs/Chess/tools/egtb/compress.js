// Compression experiments on the normalised tables written by norm.js.
//   node compress.js KEY STM [mode]
//     STM: w | b
//     mode: perms  -> HRLE size for all 24 dimension orders x don't-care policies
//           full   -> all schemes for the best orders (default)
// Schemes (all per independent block of BLK entries, block offsets in an index):
//   HRLE   runs of equal values; symbol = (value, length class) static Huffman + extra bits
//   HRLEc  as HRLE but a separate Huffman table per previous value (WDL only)
//   BRLE   one byte per run: vv llllll (len 1..63), escape l=0 + 2-byte length (WDL only)
//   LZSS   byte LZ77 on 2-bit packed (WDL) / byte (DTM) data, window = the block,
//          8 flags per byte, match = 2 bytes (12-bit offset, 4-bit len 3..17; len 18+ via extra byte)
//   HBYTE  static Huffman over the packed bytes
'use strict';
const fs = require('fs'), path = require('path');
const L = require('./lib');
const { SPECS, layout } = require('./norm');

// ---------------------------------------------------------------- data
function loadNorm(key, stm) {
  const base = path.join(L.DATA_DIR, `norm_${key}_${stm}`);
  const sym = new Uint8Array(fs.readFileSync(base + '.sym'));
  const kind = new Uint8Array(fs.readFileSync(base + '.kind'));
  return { sym, kind };
}
// square orders for the 64-square dimensions: ORDERS[name][k] = square visited k-th
const ORDERS = { rank: [...Array(64).keys()], snake: [], hilbert: [] };
for (let r = 0; r < 8; r++) for (let f = 0; f < 8; f++) ORDERS.snake.push(r * 8 + (r & 1 ? 7 - f : f));
(function () {           // 8x8 Hilbert curve
  for (let d = 0; d < 64; d++) {
    let x = 0, y = 0, t = d;
    for (let s = 1; s < 8; s *= 2) {
      const rx = 1 & (t >> 1), ry = 1 & (t ^ rx);
      if (ry === 0) { if (rx === 1) { x = s - 1 - x; y = s - 1 - y; } const tt = x; x = y; y = tt; }
      x += s * rx; y += s * ry; t >>= 2;
    }
    ORDERS.hilbert.push(y * 8 + x);
  }
})();
// relative ordering: REL="x:y" -> the 64-square dim x is enumerated in order of distance
// from the square of dim y (Chebyshev, then Manhattan, then square number)
const RELORD = [];
for (let y = 0; y < 64; y++) {
  const sq = [...Array(64).keys()];
  const dd = s => { const df = Math.abs((s & 7) - (y & 7)), dr = Math.abs((s >> 3) - (y >> 3)); return Math.max(df, dr) * 100 + df + dr; };
  sq.sort((a, b) => dd(a) - dd(b) || a - b);
  RELORD.push(sq);
}
function dimSquare(dims, k, c) {
  if (dims[k] === 64) return c;
  if (dims[k] === 10) return [0, 1, 2, 3, 9, 10, 11, 18, 19, 27][c];
  if (dims[k] === 24) return (1 + (c >> 2)) * 8 + (c & 3);
  return 8 + c;   // 48: second pawn
}
function applyRel(src, dims, rel) {
  const [x, y] = rel.split(':').map(Number);
  const n = src.sym.length, sym = new Uint8Array(n), kind = new Uint8Array(n);
  const strides = []; let s0 = 1;
  for (let k = 3; k >= 0; k--) { strides[k] = s0; s0 *= dims[k]; }
  for (let i = 0; i < n; i++) {
    const cx = Math.floor(i / strides[x]) % 64, cy = Math.floor(i / strides[y]) % dims[y];
    const sqx = RELORD[dimSquare(dims, y, cy)][cx];
    const j = i + (sqx - cx) * strides[x];
    sym[i] = src.sym[j]; kind[i] = src.kind[j];
  }
  return { sym, kind };
}
function permute(src, dims, perm, order) {
  // perm: list of canonical dim numbers, outermost first; order: square order for 64-dims
  if (process.env.REL) for (const r of process.env.REL.split(',')) src = applyRel(src, dims, r);
  if (order && order !== 'rank') {
    const o = ORDERS[order], n0 = src.sym.length;
    const sym = new Uint8Array(n0), kind = new Uint8Array(n0);
    const strides = []; let s0 = 1;
    for (let k = 3; k >= 0; k--) { strides[k] = s0; s0 *= dims[k]; }
    for (let i = 0; i < n0; i++) {
      let j = 0;
      for (let k = 0; k < 4; k++) { let c = Math.floor(i / strides[k]) % dims[k]; if (dims[k] === 64) c = o[c]; j += c * strides[k]; }
      sym[i] = src.sym[j]; kind[i] = src.kind[j];
    }
    src = { sym, kind };
  }
  const n = src.sym.length;
  const sym = new Uint8Array(n), kind = new Uint8Array(n);
  const strides = []; let s = 1;
  for (let k = 3; k >= 0; k--) { strides[k] = s; s *= dims[k]; }
  const pd = perm.map(k => dims[k]), ps = perm.map(k => strides[k]);
  let j = 0;
  for (let a = 0; a < pd[0]; a++) for (let b = 0; b < pd[1]; b++) for (let c = 0; c < pd[2]; c++) {
    const base = a * ps[0] + b * ps[1] + c * ps[2];
    for (let d = 0; d < pd[3]; d++) { const i = base + d * ps[3]; sym[j] = src.sym[i]; kind[j] = src.kind[i]; j++; }
  }
  if (process.env.PSLICE) {   // keep only the first PSLICE values of the outermost dimension
    if (dims[perm[0]] !== 24) throw new Error('PSLICE needs the pawn dimension outermost');
    const m = n / 24 * (+process.env.PSLICE);
    return { sym: sym.subarray(0, m), kind: kind.subarray(0, m) };
  }
  return { sym, kind };
}

// allowed-set test.  policy: 0 = only illegal/duplicate free; 1 = also capture-resolved entries
function allowedFn(dtm, policy) {
  return (kind, sym, v) => {
    if (kind === 0) return v === sym;
    if (kind === 1 || kind === 2) return true;
    if (policy === 0) return v === sym;
    if (kind === 3) return true;
    // kind 4: any value <= draw (draw or a loss)
    if (dtm) return v === 0 || ((v - 1) & 1) === 0;
    return v === 0 || v === 2;
  };
}

// fill free entries to minimise the number of runs (Viterbi over the alphabet)
function fill(d, alphabet, allowed, blk) {
  const n = d.sym.length, A = alphabet.length;
  const out = new Uint8Array(n);
  const INF = 1e9;
  let dp = new Float64Array(A).fill(0), nd = new Float64Array(A);
  const stay = new Uint8Array(n * A);     // 1 = previous value was the same
  const argm = new Uint8Array(n);          // argmin of dp at i-1
  for (let i = 0; i < n; i++) {
    let mi = 0; for (let a = 1; a < A; a++) if (dp[a] < dp[mi]) mi = a;
    argm[i] = mi;
    const brk = (i % blk) === 0;          // a block start always opens a new run
    for (let a = 0; a < A; a++) {
      if (!allowed(d.kind[i], d.sym[i], alphabet[a])) { nd[a] = INF; continue; }
      if (!brk && dp[a] <= dp[mi] + 1) { nd[a] = dp[a]; stay[i * A + a] = 1; }
      else nd[a] = dp[mi] + 1;
    }
    const t = dp; dp = nd; nd = t;
  }
  let a = 0; for (let k = 1; k < A; k++) if (dp[k] < dp[a]) a = k;
  for (let i = n - 1; i >= 0; i--) { out[i] = alphabet[a]; if (!stay[i * A + a]) a = argm[i]; }
  return out;
}

// ---------------------------------------------------------------- Huffman
function huffLens(freq) {
  const syms = []; for (const [s, f] of freq) if (f > 0) syms.push({ f, s, leaf: true });
  if (syms.length === 1) return new Map([[syms[0].s, 1]]);
  let nodes = syms.slice();
  // simple O(n^2) is fine for small alphabets; use sort each time
  while (nodes.length > 1) {
    nodes.sort((a, b) => a.f - b.f);
    const a = nodes.shift(), b = nodes.shift();
    nodes.push({ f: a.f + b.f, kids: [a, b] });
  }
  const lens = new Map();
  (function walk(nd, d) { if (nd.leaf) lens.set(nd.s, d); else { walk(nd.kids[0], d + 1); walk(nd.kids[1], d + 1); } })(nodes[0], 0);
  return lens;
}
// length classes: 1..4 direct, then pairs of classes per doubling
const LCLASS = [];
(function () {
  let base = 1;
  for (let c = 0; c < 4; c++) LCLASS.push({ base: base++, extra: 0 });
  let e = 1;
  while (base < (1 << 20)) {
    for (let k = 0; k < 2; k++) { LCLASS.push({ base, extra: e }); base += 1 << e; }
    e++;
  }
})();
function lclass(len) {
  let c = 0; while (c + 1 < LCLASS.length && LCLASS[c + 1].base <= len) c++;
  return c;
}

function runsOf(vals, blk) {
  // returns array of blocks, each an array of [value, len]
  const blocks = [];
  for (let s = 0; s < vals.length; s += blk) {
    const e = Math.min(vals.length, s + blk), runs = [];
    let v = vals[s], l = 1;
    for (let i = s + 1; i < e; i++) { if (vals[i] === v) l++; else { runs.push([v, l]); v = vals[i]; l = 1; } }
    runs.push([v, l]); blocks.push(runs);
  }
  return blocks;
}

function idxBytes(total) { return total < 65536 ? 2 : 3; }

function hrle(blocks, ctx) {
  // ctx: false -> one table; true -> table per previous value
  const freq = new Map();
  const keyOf = (prev, v, c) => (ctx ? prev * 65536 : 0) + v * 256 + c;
  for (const runs of blocks) { let prev = 255; for (const [v, l] of runs) { const k = keyOf(prev, v, lclass(l)); freq.set(k, (freq.get(k) || 0) + 1); prev = v; } }
  let lens;
  if (!ctx) lens = huffLens(freq);
  else {
    lens = new Map();
    const byPrev = new Map();
    for (const [k, f] of freq) { const p = Math.floor(k / 65536); if (!byPrev.has(p)) byPrev.set(p, new Map()); byPrev.get(p).set(k, f); }
    for (const [, m] of byPrev) for (const [k, l] of huffLens(m)) lens.set(k, l);
  }
  let maxLen = 0; for (const [, l] of lens) if (l > maxLen) maxLen = l;
  const blockBytes = [];
  for (const runs of blocks) {
    let bits = 0, prev = 255;
    for (const [v, l] of runs) { const c = lclass(l); bits += lens.get(keyOf(prev, v, c)) + LCLASS[c].extra; prev = v; }
    blockBytes.push(Math.ceil(bits / 8));
  }
  const table = Math.ceil(lens.size * 2.5);   // symbol id + 4-bit length, roughly
  return { blockBytes, table, maxLen, nsym: lens.size, lens };
}

function brle(blocks) {
  const blockBytes = blocks.map(runs => runs.reduce((a, [, l]) => a + (l <= 63 ? 1 : 3), 0));
  return { blockBytes, table: 0 };
}

function packBlock(vals, s, e, dtm) {
  if (dtm) return vals.subarray(s, e);
  const out = new Uint8Array(Math.ceil((e - s) / 4));
  for (let i = s; i < e; i++) out[(i - s) >> 2] |= vals[i] << (2 * ((i - s) & 3));
  return out;
}

function lzssSize(buf) {
  // greedy parse, hash chains on 3 bytes; returns compressed byte count
  const n = buf.length;
  const head = new Map(); const prevPos = new Int32Array(n).fill(-1);
  let i = 0, tokens = 0, bytes = 0;
  const h = p => (buf[p] << 16) | (buf[p + 1] << 8) | buf[p + 2];
  const insert = p => { if (p + 2 < n) { const k = h(p); prevPos[p] = head.has(k) ? head.get(k) : -1; head.set(k, p); } };
  while (i < n) {
    let bestL = 0;
    if (i + 2 < n) {
      let c = head.has(h(i)) ? head.get(h(i)) : -1, tries = 0;
      while (c >= 0 && tries < 256) {
        let l = 0; while (i + l < n && buf[c + l] === buf[i + l] && l < 273) l++;
        if (l > bestL) bestL = l;
        c = prevPos[c]; tries++;
      }
      // overlapping run from i-1 (offset 1) is covered by the chain when buf[i-1..] matches
    }
    tokens++;
    if (bestL >= 3) { bytes += bestL >= 18 ? 3 : 2; for (let k = 0; k < bestL; k++) insert(i + k); i += bestL; }
    else { bytes += 1; insert(i); i++; }
  }
  return bytes + Math.ceil(tokens / 8);
}

function hbyte(vals, blk, dtm) {
  const freq = new Map(); const packs = [];
  for (let s = 0; s < vals.length; s += blk) {
    const p = packBlock(vals, s, Math.min(vals.length, s + blk), dtm); packs.push(p);
    for (const b of p) freq.set(b, (freq.get(b) || 0) + 1);
  }
  const lens = huffLens(freq);
  const blockBytes = packs.map(p => { let b = 0; for (const x of p) b += lens.get(x); return Math.ceil(b / 8); });
  return { blockBytes, table: Math.ceil(lens.size * 1.5) };
}

function summarise(name, r, blk, bitsPer) {
  const decodedBytes = blk * bitsPer / 8;
  // a block is stored raw if coding does not help
  const bb = r.blockBytes.map(b => Math.min(b, Math.ceil(decodedBytes)));
  const data = bb.reduce((a, b) => a + b, 0);
  const ib = idxBytes(data);
  const total = data + bb.length * ib + (r.table || 0);
  return { scheme: name, blkEntries: blk, decodedBytes, blocks: bb.length, data, index: bb.length * ib,
    table: r.table || 0, total, maxBlock: Math.max(...bb), avgBlock: +(data / bb.length).toFixed(1) };
}

// probe-cost statistics for HRLE: average runs and bits decoded to reach an entry
// (uniform over entries that are not free), plus bytes read (prefix of block up to entry)
function hrleProbeStats(vals, d, blk, lens, ctx, allowedExact) {
  let probes = 0, runsSum = 0, bitsSum = 0, maxRuns = 0;
  for (let s = 0; s < vals.length; s += blk) {
    const e = Math.min(vals.length, s + blk);
    let pos = s, prev = 255, runs = 0, bits = 0;
    while (pos < e) {
      const v = vals[pos]; let l = 1; while (pos + l < e && vals[pos + l] === v) l++;
      const c = lclass(l); runs++;
      bits += lens.get((ctx ? prev * 65536 : 0) + v * 256 + c) + LCLASS[c].extra;
      for (let k = pos; k < pos + l; k++) if (d.kind[k] === 0) { probes++; runsSum += runs; bitsSum += bits; }
      if (runs > maxRuns) maxRuns = runs;
      prev = v; pos += l;
    }
  }
  return { avgRuns: +(runsSum / probes).toFixed(1), avgBits: +(bitsSum / probes).toFixed(0), maxRunsPerBlock: maxRuns };
}

const PERMS = [];
(function gen(a, rest) { if (!rest.length) { PERMS.push(a); return; } for (const x of rest) gen(a.concat([x]), rest.filter(y => y !== x)); })([], [0, 1, 2, 3]);

if (require.main === module) {
  const key = process.argv[2], stm = process.argv[3], mode = process.argv[4] || 'full';
  const order = process.env.SQORDER || 'rank';
  const spec = SPECS[key], lay = layout(spec), dtm = !!spec.dtm;
  const src = loadNorm(key, stm);
  if (process.env.BINARY) {   // win / not-win only (side to move); losses derived by 1-ply
    for (let i = 0; i < src.sym.length; i++) { if (src.sym[i] === 2) src.sym[i] = 0; if (src.kind[i] === 4) src.kind[i] = 0; }
  }
  if (process.env.DTMDIV) {  // coarse DTM bands: band = floor(moves / DTMDIV); stays a loss (even) / win (odd) code
    const k = +process.env.DTMDIV;
    for (let i = 0; i < src.sym.length; i++) { const v = src.sym[i]; if (v > 0 && src.kind[i] !== 1) { const p = v - 1; const mv = p >> 1; src.sym[i] = 2 * Math.floor(mv / k) + (p & 1) + 1; } }
  }
  const alphabet = dtm ? [...new Set(src.sym)].sort((a, b) => a - b) : [0, 1, 2];
  const bitsPer = dtm ? Math.ceil(Math.log2(alphabet.length + 1)) : 2;
  const resFile = path.join(L.DATA_DIR, `cmp_${key}_${stm}_${mode}.json`);
  const results = [];
  if (mode === 'perms') {
    for (const perm of PERMS) for (const policy of [0, 1]) {
      const d = permute(src, lay.dims, perm, order);
      const vals = fill(d, alphabet, allowedFn(dtm, policy), 4096);
      const blocks = runsOf(vals, 4096);
      const r = summarise('HRLE', hrle(blocks, false), 4096, bitsPer);
      const runs = blocks.reduce((a, b) => a + b.length, 0);
      const row = { perm: perm.map(k => spec.names[k]).join('-'), order, rel: process.env.REL || '', policy, runs, total: r.total };
      console.log(JSON.stringify(row)); results.push(row);
    }
  } else {
    const perms = (process.argv[5] || '').split(',').filter(Boolean).map(s => s.split('').map(Number));
    for (const perm of perms) for (const policy of [0, 1]) {
      const d = permute(src, lay.dims, perm, order);
      const blks = dtm ? [256, 512, 1024, 2048] : [1024, 2048, 4096, 8192];
      for (const blk of policy === 0 ? [dtm ? 1024 : 4096] : blks) {
        const vals = fill(d, alphabet, allowedFn(dtm, policy), blk);
        const blocks = runsOf(vals, blk);
        const tag = { perm: perm.map(k => spec.names[k]).join('-'), order, policy };
        const h = hrle(blocks, false);
        const row = [summarise('HRLE', h, blk, bitsPer)];
        Object.assign(row[0], hrleProbeStats(vals, d, blk, h.lens, false), { maxCode: h.maxLen, nsym: h.nsym });
        if (!dtm) {
          const hc = hrle(blocks, true);
          row.push(Object.assign(summarise('HRLEc', hc, blk, bitsPer), hrleProbeStats(vals, d, blk, hc.lens, true), { maxCode: hc.maxLen, nsym: hc.nsym }));
          row.push(summarise('BRLE', brle(blocks), blk, bitsPer));
        }
        const lz = []; for (let s = 0; s < vals.length; s += blk) lz.push(lzssSize(packBlock(vals, s, Math.min(vals.length, s + blk), dtm)));
        row.push(summarise('LZSS', { blockBytes: lz }, blk, bitsPer));
        row.push(summarise('HBYTE', hbyte(vals, blk, dtm), blk, bitsPer));
        for (const r of row) { Object.assign(r, tag); console.log(JSON.stringify(r)); results.push(r); }
      }
    }
  }
  fs.writeFileSync(resFile, JSON.stringify(results, null, 1), 'utf8');
}
module.exports = { ORDERS, loadNorm, permute, allowedFn, fill, runsOf, hrle, lclass, LCLASS, huffLens, PERMS };
