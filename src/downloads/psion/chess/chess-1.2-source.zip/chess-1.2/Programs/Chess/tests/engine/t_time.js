'use strict';
// Time limits with the OS running (interrupts on): eng_think must stop near e_tlim and answer.
const { Harness } = require('./harness.js');
const h = new Harness({ ints: true });
let bad = 0;
for (const [fen, frames] of [['rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', 20], ['r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3', 100], ['8/8/8/4k3/8/8/8/R3K3 w - - 0 1', 60]]) {
  h.setFen(fen); h.call('e_clrtt');
  h.m.write(h.a('e_nlim'), [0, 0, 0]); h.pokew('e_tlim', frames); h.poke('e_maxd', 0); h.pokew('e_margin', 0);
  const r = h.call('eng_think', 0, 0, 921600 * 120);
  const secs = r.cycles / 921600, nb = h.bytes('e_nodes', 3), n = (nb[0] << 16) | (nb[1] << 8) | nb[2];
  const ok = h.peek('e_bestt') !== 0 || h.peek('e_bestf') !== 0;
  const inTime = secs <= frames / 20 + 0.5;
  if (!ok || !inTime) bad++;
  console.log(`${ok && inTime ? 'ok  ' : 'FAIL'} limit ${frames / 20}s: took ${secs.toFixed(2)}s, depth ${h.peek('e_depth')}, ${n} nodes (${Math.round(n / secs)}/s)  ${fen.slice(0, 24)}`);
}
console.log(bad ? `${bad} FAILED` : 'time limits ok');
process.exit(bad ? 1 : 0);
