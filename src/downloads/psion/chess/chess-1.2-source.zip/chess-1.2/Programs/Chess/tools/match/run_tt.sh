#!/bin/sh
# 16 Nov: transposition-table size v the current engine (snap_z64c, 512 entries = HashBits 9)
O="--openings 0:242 --workers 4"
python -E -P match.py tt8_2120 snap_z64c:Nodes=2120,HashBits=8 snap_z64c:Nodes=2120 $O > logs_tt8_2120.txt 2>&1 &
python -E -P match.py tt7_2120 snap_z64c:Nodes=2120,HashBits=7 snap_z64c:Nodes=2120 $O > logs_tt7_2120.txt 2>&1 &
python -E -P match.py tt8_7000 snap_z64c:Nodes=7000,HashBits=8 snap_z64c:Nodes=7000 $O > logs_tt8_7000.txt 2>&1 &
python -E -P match.py tt7_7000 snap_z64c:Nodes=7000,HashBits=7 snap_z64c:Nodes=7000 $O > logs_tt7_7000.txt 2>&1 &
wait
python -E -P analyze.py tt8_2120 tt7_2120 tt8_7000 tt7_7000 | grep -v histogram
