'use strict';
// Which launcher runs on an empty LZ64, the TT size it gets, and FREE afterwards.
const L = require('./lib.js');
const m = L.start();
L.idle(m);
const ttn = m.peekw(L.sym(m, 'e_ttn')), size = m.peekw(L.sym(m, 'kv_size'));
L.check(ttn >= 512, 'empty LZ64, first launch: TT ' + ttn + ' entries, array ' + size + ' bytes', m);
// second launch, with the save file present
L.keys(m, ['ON']); m.runSeconds(1); L.keys(m, ['S', 'S', 'S', 'EXE']); m.runSeconds(3);
m.press('ON', 3, 10); m.press('ON', 3, 10); m.runSeconds(1);
m.runProc('CHESS', 'B'); m._base = null; L.idle(m);
const ttn2 = m.peekw(L.sym(m, 'e_ttn'));
L.check(ttn2 >= 512, 'second launch (save on A:): TT ' + ttn2 + ' entries', m);
