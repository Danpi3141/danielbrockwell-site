"""Summarise the Stockfish spot checks written by xcheck.py sf (sf_KEY.json)."""
import json, os, sys
DIR = os.environ['EGTB_DIR']
def sfclass(r):
    if r['mate'] is not None:
        return 'W' if r['mate'] > 0 else 'L'
    cp = r['cp']
    if cp >= 300: return 'W'
    if cp <= -300: return 'L'
    if abs(cp) <= 100: return 'D'
    return '?'
out = {}
for key in sys.argv[1:]:
    p = os.path.join(DIR, 'sf_%s.json' % key)
    if not os.path.exists(p): continue
    rows = json.load(open(p, encoding='utf-8'))
    m = {}
    for r in rows:
        k = r['tb'] + '/' + sfclass(r)
        m[k] = m.get(k, 0) + 1
    agree = sum(v for k, v in m.items() if k[0] == k[2])
    unclear = sum(v for k, v in m.items() if k[2] == '?')
    out[key] = {'n': len(rows), 'agree': agree, 'unclear': unclear, 'disagree': len(rows) - agree - unclear,
                'matrix_tb/sf': dict(sorted(m.items())),
                'avgDepth': round(sum(r['depth'] or 0 for r in rows) / len(rows), 1)}
    print(key, json.dumps(out[key]))
    if '-v' in os.environ.get('SFV', ''):
        for r in rows:
            c = sfclass(r)
            if c != r['tb']: print('   ', r)

# DTM check: where Stockfish reports a mate, it must not be shorter than the table's DTM
for key in sys.argv[1:]:
    p = os.path.join(DIR, 'sf_%s.json' % key)
    if not os.path.exists(p): continue
    rows = json.load(open(p, encoding='utf-8'))
    n = eq = longer = shorter = 0
    for r in rows:
        if r['mate'] is None or r['tbPlies'] is None: continue
        tbm = (r['tbPlies'] + 1) // 2 if r['tbPlies'] & 1 else r['tbPlies'] // 2
        sfm = abs(r['mate'])
        n += 1
        if sfm == tbm: eq += 1
        elif sfm > tbm: longer += 1
        else: shorter += 1
    print(key, 'SF mates:', n, 'same distance', eq, 'SF longer', longer, 'SF shorter (would be a table error)', shorter)
