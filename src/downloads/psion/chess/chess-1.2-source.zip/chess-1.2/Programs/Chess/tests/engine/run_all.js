'use strict';
// Runs every engine test (assembler on the emulated 6303 against the JS reference).
// Usage: node tests/engine/run_all.js [--quick]
const { execFileSync } = require('child_process');
const path = require('path');
const quick = process.argv.includes('--quick');
const ref = path.join(__dirname, '..', '..', 'ref');
const steps = [
  ['JS perft (move generation, known totals)', ref, 'perft.js', [quick ? '4' : '5']],
  ['assembler perft', __dirname, 't_perft.js', [quick ? '2' : '3']],
  ['UI routines over random games', __dirname, 't_api.js', []],
  ['evaluation', __dirname, 't_eval.js', []],
  ['search, 16 positions', __dirname, 't_search.js', ['600']],
  ['search with the levels 1-4 margin', __dirname, 't_search.js', ['400', '150']],
  ['king and pawn v king from the distance table', __dirname, 't_kpkroot.js', []],
  ['a mate on the 100th half-move counts', __dirname, 't_fifty.js', []],
  ['time limits with the OS running', __dirname, 't_time.js', []],
  ['perft, awkward positions (python-chess)', __dirname, 't_perft2.js', [quick ? '300' : '2000']],
  ['rules v python-chess (UI routines)', __dirname, 't_rules.js', [quick ? '20' : '100']],
  ['colour-flip evaluation symmetry', __dirname, 't_mirror.js', [quick ? '15' : '60']],
  ['castling v python-chess, make/unmake v recompute', __dirname, 't_castle.js', [quick ? '5' : '40']],
  ['key history at its worst case (E_KMAX)', __dirname, 't_khist.js', [quick ? '4' : '12']],
];
if (!quick) {
  steps.push(['random positions', __dirname, 't_fuzz.js', ['40', '3']]);
  steps.push(['a whole rook ending, move by move', __dirname, 't_game.js', ['8/8/8/4k3/8/8/8/R3K3 w - - 0 1', '2500', '80']]);
  steps.push(['mates in self-play (JS)', ref, 'mates.js', ['2500']]);
  steps.push(['assembler games v JS, mixed limits', __dirname, 't_soak_asm.js', ['4', '7', '120']]);
  steps.push(['time overruns with the OS running', __dirname, 't_time2.js', ['6', '5']]);
}
let failed = 0;
for (const [name, dir, file, args] of steps) {
  process.stdout.write(name.padEnd(42));
  try {
    const out = execFileSync('node', [path.join(dir, file), ...args], { cwd: dir, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
    console.log('ok   ' + out.trim().split('\n').pop());
  } catch (e) {
    failed++;
    console.log('FAIL ' + String(e.stdout || e.message).trim().split('\n').slice(-3).join(' | '));
  }
}
console.log(failed ? `${failed} FAILED` : 'all engine tests passed');
process.exit(failed ? 1 : 0);
