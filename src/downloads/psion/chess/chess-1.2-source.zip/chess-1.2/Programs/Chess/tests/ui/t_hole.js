'use strict';
// The launcher's memory on all 14 LZ and LZ64 ROMs (24 Nov): the kernel's lm_buf lies in CHESS's translated text that
// has run, the part it needs again is intact after a game, and OPL gets its memory back.
//   node tests/ui/t_hole.js [rom...]
const fs = require('fs');
const path = require('path');
const L = require('./lib.js');
const H = require('./help.js');
const { Machine } = require('../../tools/emu.js');
const ROMS = { '42-lz.rom': 32, '44-lz.rom': 32, '45-lz.rom': 32, '45-lzi.rom': 32, '45-lzs.rom': 32, '46-lz.rom': 32, '46-lzi.rom': 32,
  '43-lz64.rom': 64, '44-lz64.rom': 64, '45-lz64.rom': 64, '46a-lz64.rom': 64, '46b-lz64.rom': 64, '46-lz64i.rom': 64, '46-lz64s.rom': 64 };
let fails = 0;
function ok(c, msg) { if (!c) { fails++; console.log('FAIL ' + msg); } else console.log('ok   ' + msg); }
const meta = JSON.parse(fs.readFileSync(path.join(L.BUILD, 'build.json'), 'utf8'));
const ob3 = fs.readFileSync(path.join(L.BUILD, 'CHESS.ob3'));
const q = ob3.indexOf(Buffer.from([0x59, 0xB2]));                                // the translated text
const code = [...ob3.slice(q, ob3.length - 2)];                                  // (then the source's length, 0)
const helpPk = H.make({}, 'hole');
for (const rom of process.argv.slice(2).length ? process.argv.slice(2) : Object.keys(ROMS)) {
  const m = new Machine({ rom, ram: ROMS[rom] });
  m.boot();
  m.insertPack(path.join(L.BUILD, 'CHESS.opk'), 0);
  m.insertPack(helpPk, 1);
  try {
    const free0 = H.free(m), dir0 = H.dir(m);
    H.top(m);
    // the zero page the game borrows, as the kernel finds it (a pattern: mostly zeros otherwise) and as it is when the
    // kernel returns (what was there before the pattern is then put back)
    const zp = () => [0x4D, 0x7F, 0xCC].flatMap((a, i) => [...m.read(a, [14, 12, 42][i])]);
    const zaddr = [0x4D, 0x7F, 0xCC].flatMap((a, i) => [...Array([14, 12, 42][i]).keys()].map((k) => a + k)), was = [];
    let zin = null, zout = null, ret = -1;
    const entry = () => m.dbg.setTrace((pc) => {
      if (!zin && pc >= 0x3000 && pc < 0x8000 && m.peek(pc + 3) === 0x43 && m.peek(pc + 4) === 0x48 && m.peek(pc + 5) === 0x4B && m.peek(pc + 6) === 0x31) {   // the kernel's first instruction ("CHK1" at 3)
        zin = zp(); for (let i = 0; i < zin.length; i++) { was.push(zin[i]); zin[i] = (i * 37 + 91) & 255; m.poke(zaddr[i], zin[i]); } ret = m.peekw(m.dbg.sp());
      } else if (zin && !zout && pc === ret) { zout = zp(); was.forEach((v, i) => m.poke(zaddr[i], v)); }
    });
    entry();
    m.runProc('CHESS', 'B'); m.runSeconds(5);
    m._base = null;
    const base = L.base(m), end = base + meta.ktotal, tt = m.peekw(L.sym(m, 'e_tt')), n = m.peekw(L.sym(m, 'e_ttn'));
    const at = end + 3;                                                          // QCODE_GAP
    const hole = meta.hole, lm = L.sym(m, 'lm_buf');
    const keep = () => { for (let i = hole; i < code.length; i++) if (m.peek(at + i) !== code[i]) return i; return -1; };
    const k0 = keep();
    const sp = m.peekw(0xA5);
    ok(n >= 128 && tt + n * 7 === base && sp === tt && lm === at && 2 * 127 <= hole && k0 < 0,
      `${rom.padEnd(13)} TT ${n} at ${tt}, kernel ${base}, CHESS's text at ${at}: the ${code.length - hole} bytes it needs again intact${k0 < 0 ? '' : ' NOT: ' + k0}; lm_buf ${lm}`);
    L.keys(m, ['E', 'V', 'E', 'O']); L.idle(m);                                  // a move, and an answer
    ok(L.peekSym(m, 'g_n')[0] === 2 && keep() < 0 && m.read(lm, 40).some((v) => v), `${rom.padEnd(13)} a move played, the launcher's text still intact`);
    L.keys(m, ['ON']); m.runSeconds(1); L.keys(m, ['S', 'S', 'S', 'EXE']); m.runSeconds(3);
    ok(zin && zout && zin.every((v, i) => v === zout[i]), `${rom.padEnd(13)} the zero page given back` + (zin && zout ? '' : ' (not seen)') + (zin && zout ? zin.map((v, i) => v === zout[i] ? '' : ' ' + i).join('') : ''));
    m.dbg.setTrace(null);
    const top = H.top(m);
    const free1 = H.free(m), dir1 = H.dir(m);
    const save = (ROMS[rom] === 32 ? 1 : 0);                                     // (on a 32K LZ the save file comes off FREE)
    ok(top && dir1 === (dir0 + ' A:CHESSAV').trim() && (save ? free1 < free0 && free0 - free1 < 1500 : free1 === free0), `${rom.padEnd(13)} left: FREE ${free0} -> ${free1}`);
    m.runProc('CHESS', 'B'); m._base = null; m.runSeconds(5);
    ok(L.peekSym(m, 'g_n')[0] === 2, `${rom.padEnd(13)} started again, the game resumed`);
  } catch (e) { ok(false, rom + ' ' + e.message.split('\n').slice(0, 5).join(' | ')); }
}
console.log(fails ? fails + ' failures' : 'all launcher tests passed');
process.exit(fails ? 1 : 0);
