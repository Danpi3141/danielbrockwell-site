; ---------------------------------------------------------------------
; The clocks from the settings (OV_GAME entry 13, G_CLKNEW; in the board
; overlay until 17 Nov). st_timing: 0 none, 1 5|5, 2 10|5, 3 15|10, 4 30|30,
; 5 custom (st_cmin/st_cinc: [0] the player, [1] the computer).
; ---------------------------------------------------------------------
tm_min:   fcb  0,5,10,15,30
tm_inc:   fcb  0,5,5,10,30


; minutes A -> D frames (A * 1200)
min_fr: ldab #120
        mul
        ldx  #10
        jsr  mul16
        rts
; seconds A -> D frames
sec_fr: ldab #20
        mul
        rts

clk_new:
        clr  clk_run
        ldab st_timing
        beq  .x
        cmpb #5
        beq  .cust
        ldx  #tm_min
        abx
        ldaa 0,x
        bsr  min_fr
        std  g_clk
        std  g_clk+2
        ldab st_timing
        ldx  #tm_inc
        abx
        ldaa 0,x
        bsr  sec_fr
        std  g_inc
        std  g_inc+2
.x:     rts
.cust:  ; the player's and the computer's, onto White and Black
        ldx  #g_clk
        ldab g_human
        beq  .w
        ldx  #g_clk+2
.w:     stx  kv_t0
        ldaa st_cmin
        bsr  min_fr
        ldx  kv_t0
        std  0,x
        ldaa st_cinc
        bsr  sec_fr
        ldx  kv_t0
        std  4,x
        ldx  #g_clk+2
        ldab g_human
        beq  .b
        ldx  #g_clk
.b:     stx  kv_t0
        ldaa st_cmin+1
        bsr  min_fr
        ldx  kv_t0
        std  0,x
        ldaa st_cinc+1
        bsr  sec_fr
        ldx  kv_t0
        std  4,x
        rts

