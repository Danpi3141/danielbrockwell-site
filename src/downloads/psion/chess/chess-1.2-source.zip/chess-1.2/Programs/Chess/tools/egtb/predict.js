// "Predict from an earlier entry" variant: within a block, entry i is predicted by entry
// i-STRIDE (i-1 for the first STRIDE entries of a block; first entry predicted as 0).
// Free entries take the predicted value when allowed.  The residual stream
// (0 = as predicted, else the actual value / the DTM difference) is run-length coded with
// the same Huffman (value, length class) scheme as HRLE.  The decoder must rebuild the block
// up to the wanted entry in RAM (it needs the entry STRIDE back), so a probe touches
// on average half a block: this costs RAM (block entries x 2 bits) and time.
//   node predict.js KEY STM PERM STRIDES BLKS     e.g. node predict.js KPvKP w 0132 1,8,64 1024,4096
'use strict';
const path = require('path'), fs = require('fs');
const L = require('./lib');
const { SPECS, layout } = require('./norm');
const C = require('./compress');

function predFill(d, allowed, alphabet, blk, stride, dtm) {
  const n = d.sym.length, out = new Uint8Array(n), res = new Int16Array(n);
  for (let i = 0; i < n; i++) {
    const o = i % blk;
    const pred = o === 0 ? (dtm ? 0 : 0) : (o >= stride ? out[i - stride] : out[i - 1]);
    let v;
    if (allowed(d.kind[i], d.sym[i], pred)) v = pred;
    else if (d.kind[i] === 0 || !allowed(d.kind[i], d.sym[i], d.sym[i])) {
      v = d.sym[i];
      if (!allowed(d.kind[i], d.sym[i], v)) { for (const a of alphabet) if (allowed(d.kind[i], d.sym[i], a)) { v = a; break; } }
    } else v = d.sym[i];
    out[i] = v;
    res[i] = dtm ? v - pred : (v === pred ? 0 : v + 1);   // WDL residual: 0 or 1+value
  }
  return { out, res };
}

function runsOfInt(vals, blk) {
  const blocks = [];
  for (let s = 0; s < vals.length; s += blk) {
    const e = Math.min(vals.length, s + blk), runs = [];
    let v = vals[s], l = 1;
    for (let i = s + 1; i < e; i++) { if (vals[i] === v) l++; else { runs.push([v, l]); v = vals[i]; l = 1; } }
    runs.push([v, l]); blocks.push(runs);
  }
  return blocks;
}

if (require.main === module) {
  const [key, stm, permS, stridesS, blksS] = process.argv.slice(2);
  const spec = SPECS[key], lay = layout(spec), dtm = !!spec.dtm;
  const src = C.loadNorm(key, stm);
  const alphabet = dtm ? [...new Set(src.sym)].sort((a, b) => a - b) : [0, 1, 2];
  const perm = permS.split('').map(Number);
  const d = C.permute(src, lay.dims, perm, process.env.SQORDER || 'rank');
  const allowed = C.allowedFn(dtm, 1);
  for (const blk of blksS.split(',').map(Number)) for (const stride of stridesS.split(',').map(Number)) {
    const { res } = predFill(d, allowed, alphabet, blk, stride, dtm);
    // shift residuals to non-negative ints for the Huffman key (value*256 + class)
    const shifted = Int16Array.from(res, x => x + 128);
    const blocks = runsOfInt(shifted, blk);
    const h = C.hrle(blocks, false);
    const data = h.blockBytes.reduce((a, b) => a + b, 0);
    const ib = data < 65536 ? 2 : 3;
    const total = data + h.blockBytes.length * ib + h.table;
    const row = { key, stm, perm: perm.map(k => spec.names[k]).join('-'), order: process.env.SQORDER || 'rank', scheme: 'PRED-HRLE', stride, blk,
      data, index: h.blockBytes.length * ib, table: h.table, total, nsym: h.nsym, maxCode: h.maxLen };
    console.log(JSON.stringify(row));
    fs.appendFileSync(path.join(L.DATA_DIR, 'predict.jsonl'), JSON.stringify(row) + '\n', 'utf8');
  }
}
module.exports = { predFill };
