'use strict';
// Auto switch-off while the game waits for the player, then ON: the board must come back.
const L = require('./lib.js');
const { check, keys } = L;
let m = L.start(); L.idle(m);
keys(m, ['E', 'V', 'E', 'O']); L.idle(m);
const before = m.screenText();
let off = false;
for (let i = 0; i < 70 && !off; i++) { m.runSeconds(10); off = !m.isOn(); }
check(off, 'it switched itself off while waiting', m);
m.press('ON', 3, 10);
for (let i = 0; i < 6; i++) { m.runSeconds(0.5); console.log(i, m.isOn(), m.screen()[3], m.dbg.pc().toString(16)); }
check(m.isOn(), 'ON switches it back on', m);
console.log(m.screenText());
check(m.screenText() === before, 'the board is back as it was', m);
keys(m, ['D', 'V', 'D', 'O']); L.idle(m);
check(L.peekSym(m, 'g_n')[0] === 4, 'and the game goes on', m);
console.log('switch-off test passed');
