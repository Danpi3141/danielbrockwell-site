"""Stockfish (depth 22) on every position of the book tree: each group's position and each leaf
position. Results go to the audit cache; checks 1-3 read them.

    python -E -P tools/book/audit/eval_tree.py [--book data/book.bin]
"""
import argparse
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import Tree, SF, BOOK, log  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--book', default=BOOK)
    a = ap.parse_args()
    t = Tree(a.book)
    fens = set()
    for g, mv in t.groups.items():
        b = t.board(g)
        fens.add(b.fen())
        for u, fl, r in mv:
            b.push_uci(u)
            fens.add(b.fen())
            b.pop()
    log('tree: %d groups, %d moves, %d distinct positions' % (len(t.groups), t.nmoves, len(fens)))
    sf = SF()
    try:
        sf.evals(sorted(fens), label='tree')
    finally:
        sf.close()
    log('done')


if __name__ == '__main__':
    main()
