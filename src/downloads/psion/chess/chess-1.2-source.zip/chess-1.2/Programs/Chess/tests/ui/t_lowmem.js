'use strict';
// Low memory (audit check 7).
//   node tests/ui/t_lowmem.js [--fill=t1,t2,...]
// 1. CHESS run from a procedure that holds a LOCAL array of n words, so the game sees 2n
//    bytes less free RAM. For each change of outcome (512, 256, 128 TT entries, "NEEDS n
//    BYTES") the exact n is found by bisection, and the game is played at the last n of each
//    outcome (one move out of the book, the engine thinks at level 1) and left; FREE at the
//    top level must be what it was. Any other outcome (an OPL error such as OUT OF MEMORY, a
//    crash) is a failure.
// 2. A: filled so that the free RAM is just above what each launcher needs: whether
//    A:CHESSAV can be made, what the player is told, whether take back and resume behave.
const L = require('./lib.js');
const G = require('./glib.js');
const H = require('./help.js');
const fs = require('fs');
const path = require('path');
const { Machine } = require('../../tools/emu.js');

let fails = 0;
function soft(cond, msg, m) { if (!cond) { fails++; console.log('FAIL ' + msg + (m ? '\n' + m.screenText() : '')); } else console.log('ok   ' + msg); return cond; }
const budget = JSON.parse(fs.readFileSync(path.join(L.BUILD, 'build.json'), 'utf8'));
console.log('     CHESS needs ' + budget.needs.map((n) => n + budget.menu).join(', ') + ' bytes free at the menu (128, 256, 512 entries)');

function machine(helpPk) {
  const m = new Machine({ rom: '46a-lz64.rom', ram: 64 });
  m.boot();
  m.insertPack(path.join(L.BUILD, 'CHESS.opk'), 0);
  if (helpPk) m.insertPack(helpPk, 1);
  return m;
}
function outcome(m) {
  const t = m.screenText();
  if (/NEEDS/.test(t.replace(/\n/g, ''))) return { c: 'need', text: t.replace(/\n/g, '').replace(/\s+/g, ' ').trim() };
  m._base = null;
  let ok = false;
  try { L.sym(m, 'kv_base'); ok = true; } catch (e) { ok = false; }
  if (ok && /[1-8]/.test(t)) {
    return { c: String(m.peekw(L.sym(m, 'e_ttn'))), size: m.peekw(L.sym(m, 'kv_size')) };
  }
  return { c: 'other', text: t };
}
const cache = {};
function probe(n) {
  if (cache[n]) return cache[n];
  const pk = H.make({ ['L' + n]: H.low(n, 'L' + n) }, 'low');
  const m = machine(pk);
  H.run(m, 'L' + n, 8);
  const o = outcome(m);
  o.m = m;
  cache[n] = o;
  return o;
}
const rank = { 512: 0, 256: 1, 128: 2, need: 3 };
// the bisection's upper end: well past the point where even the smallest launcher is refused
// (an empty LZ64 has 22,238 free at the top level; fixed ends of 2000/400 words broke when the
// array shrank on 16 Nov)
const HI = Math.ceil((22238 - budget.needs[0]) / 2) + 400;

// ---- 1. the thresholds
const fillOnly = (process.argv.find((a) => a.startsWith('--fill=')) || '').slice(7);   // --fill=22095,22085: only part 2, at these targets
const found = [];
if (!fillOnly) {
const top0 = (() => { const m = machine(H.make({}, 'low0')); return H.free(m); })();
console.log('     FREE at the top level: ' + top0);
for (const want of ['512', '256', '128']) {
  let lo = 0, hi = HI;                           // outcome(lo) at least as good as want, outcome(hi) worse
  const o0 = probe(lo);
  if (rank[o0.c] === undefined) { soft(false, 'n=' + lo + ': ' + o0.c + ' ' + (o0.text || ''), o0.m); break; }
  while (hi - lo > 1) {
    const mid = (lo + hi) >> 1;
    const o = probe(mid);
    if (rank[o.c] === undefined) { soft(false, 'n=' + mid + ': unexpected outcome: ' + (o.text || o.c), o.m); hi = mid; continue; }
    if (rank[o.c] <= rank[want]) lo = mid; else hi = mid;
  }
  const a = probe(lo), b = probe(hi);
  found.push({ want, lo, hi, a: a.c, b: b.c });
  soft(a.c === want && rank[b.c] === rank[want] + 1, `TT ${want}: up to ${lo} words held (${2 * lo} bytes less) -> ${a.c}; ${hi} words -> ${b.c}` + (b.text ? ' "' + b.text + '"' : ''));
}
// what is left between the OS's memory and the game's at each edge: what FREE keeps (256) and, until A:CHESSAV
// exists, the room for it above the smallest table. Not less (the game would write over the OS's memory, and nothing
// would say so) and not much more (memory wasted). With a save file the room for it is not kept: the edge is there too.
const room = (m) => m.peekw(L.sym(m, 'e_tt')) - m.peekw(0x2040);
for (const f of found) {
  const r = room(probe(f.lo).m), want = 256 + (f.want === '128' ? 0 : budget.reserve);
  soft(r >= want && r < want + 16, `TT ${f.want}: ${r} bytes between the OS's memory and the game's at the edge (${want} wanted)`);
}
{
  const c2 = {};
  const saved = (n) => {
    if (c2[n]) return c2[n];
    const m = machine(H.make({ ['S' + n]: H.low(n, 'S' + n) }, 'low2'));
    m.runProc('CHESS', 'B'); m.runSeconds(5); m._base = null; G.waitInput(m, 10);
    L.keys(m, ['ON']); m.runSeconds(1); L.keys(m, ['S', 'S', 'S', 'EXE']); m.runSeconds(3); H.top(m);
    H.run(m, 'S' + n, 8);
    const o = outcome(m);
    o.m = m;
    return (c2[n] = o);
  };
  for (const [i, f] of found.slice(0, 2).entries()) {
    const lo = f.lo + Math.floor(budget.reserve / 2) - 4, hi = lo + 9;          // the edge is in here
    const a = saved(lo), b = saved(hi);
    soft(a.c === f.want && b.c === ['256', '128'][i], `with a save file: ${lo} words held -> ${a.c}, ${hi} -> ${b.c}`);
    const r = a.c === f.want ? room(a.m) : -1;
    soft(r >= 256 && r < 256 + 32, `with a save file, TT ${f.want}: ${r} bytes between the OS's memory and the game's`);
  }
}

// play at the edge of each outcome: one move out of the book at level 1, then save and leave
for (const f of found) {
  const o = probe(f.lo);
  const m = o.m;
  if (!G.waitInput(m, 10)) { soft(false, 'n=' + f.lo + ': the game is not waiting for a move', m); continue; }
  G.setting(m, G.SET.LEVEL, ['LEFT', 'LEFT', 'LEFT', 'LEFT', 'LEFT', 'LEFT']);
  G.typeUci(m, 'b1a3');               // (out of the book: the only first move it has no answer to)
  const ok = G.waitPly(m, 2, 60);
  soft(ok && G.engFen(m).includes('N'), `n=${f.lo} (TT ${o.c}, array ${o.size}): the engine answers b1a3`, m);
  L.keys(m, ['ON']); m.runSeconds(1); L.keys(m, ['S', 'S', 'S', 'EXE']); m.runSeconds(3);
  H.top(m);
  const fr = H.free(m);
  soft(fr === top0, `n=${f.lo}: left; FREE at the top level ${fr} (was ${top0})`, m);
}
// the last outcome: the message, and nothing changed
{
  const o = probe(found.length ? found[found.length - 1].hi : HI);
  soft(o.c === 'need' && /CHESS NEEDS \d+ BYTES MORE RAM/.test(o.text), 'too little: "' + o.text + '"', o.m);
  o.m.press('EXE', 3, 10); o.m.runSeconds(1); H.top(o.m);
  soft(H.free(o.m) === top0, 'too little: FREE at the top level unchanged', o.m);
}

}
// ---- 2. A: full: free RAM just above what a launcher needs
// fill A: the other RAM banks first (FREE only falls when they are full): A:ZZFILL with
// 250-byte records until one spills into the main RAM (FREE falls), that one erased; then
// A:ZZFILL2 the same with 8-byte records; then A:ZZFILL3 in the main RAM until FREE (as this
// procedure sees it) is just above t
function fillTo(t, name) {
  return [name + ':', 'LOCAL f%', 'ONERR full',
    'CREATE "A:ZZFILL",A,B$', 'f%=FREE', 'WHILE FREE>=f%', 'A.B$=REPT$("X",250)', 'APPEND', 'ENDWH', 'LAST', 'ERASE', 'CLOSE',
    'CREATE "A:ZZFILL2",A,B$', 'f%=FREE', 'WHILE FREE>=f%', 'A.B$="XXXXXXXX"', 'APPEND', 'ENDWH', 'LAST', 'ERASE', 'CLOSE',
    'CREATE "A:ZZFILL3",A,B$',
    'WHILE FREE>' + (t + 260), 'A.B$=REPT$("X",250)', 'APPEND', 'ENDWH',
    'WHILE FREE>' + (t + 12), 'A.B$="XXXXXXXX"', 'APPEND', 'ENDWH',
    'full::', 'ONERR OFF', 'CLOSE'];
}
// (FREE as the filling procedure sees it: about 130 less than at the top level, where CHESS runs)
const at = (k) => budget.needs[k] + budget.reserve;                             // (the edges themselves, and 20 to 120 under them)
const targets = fillOnly ? fillOnly.split(',').map(Number) : [22095, 21900, 21300, at(2) - 70, at(2) - 90, at(2) - 120, at(2) - 150, at(1) - 70, at(1) - 90, at(1) - 120, at(1) - 150, budget.needs[1] + 600, budget.needs[0] - 40, budget.needs[0] - 200];
const table = ['| FREE at the top level | TT entries | A:CHESSAV made | DEL |', '|---|---|---|---|'];
for (const t of targets) {
  const name = 'F' + t;
  const pk = H.make({ [name]: fillTo(t, name) }, 'fill');
  const m = machine(pk);
  H.run(m, name, 200); H.top(m);
  const fr = H.free(m);
  m.runProc('CHESS', 'B'); m.runSeconds(8);
  m._base = null;
  if (!/NEEDS/.test(m.screenText())) G.waitInput(m, 10);
  m._base = null;
  const o = outcome(m);
  if (o.c === 'need' || o.c === 'other') {
    soft(o.c === 'need', `A: full, FREE ${fr}: ${o.text || o.c}`, m);
    const more = +(/NEEDS (\d+)/.exec(o.text || '') || [0, -1])[1];
    soft(fr + more === budget.needs[0] + budget.menu, `the least FREE at the menu is ${fr + more} (the budget: ${budget.needs[0] + budget.menu})`);
    continue;
  }
  const nosv = L.peekSym(m, 'g_nosv')[0];
  const msg = m.screen()[3].trim();
  const dir = (() => { return null; })();
  console.log(`     A: full, FREE ${fr}: TT ${o.c}; save file ${nosv ? 'NOT made' : 'made'}; row 3 "${msg}"`);
  soft(!nosv || o.c === '128', `A: full, FREE ${fr}: a table larger than the smallest only with room for the save file (TT ${o.c})`, m);
  soft(!nosv || msg === 'CANNOT SAVE: NO ROOM', `A: full, FREE ${fr}: ` + (nosv ? 'the player is told the game cannot be saved' : 'the save file was made'), m);
  G.setting(m, G.SET.TWO, ['RIGHT']);
  ['e2e4', 'e7e5', 'g1f3'].forEach((u, i) => { G.typeUci(m, u); G.waitPly(m, i + 1, 30); });
  soft(L.peekSym(m, 'g_n')[0] === 3, `A: full, FREE ${fr}: the game goes on (3 plies)`, m);
  L.keys(m, ['DEL']); G.waitInput(m, 30);
  const n = L.peekSym(m, 'g_n')[0];
  if (nosv) soft(n === 3 && m.screen()[3].includes('CANNOT TAKE BACK'), `A: full, FREE ${fr}: DEL: "CANNOT TAKE BACK", the game unchanged`, m);
  else soft(n === 2 && G.engFen(m).startsWith('rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR w'), `A: full, FREE ${fr}: DEL takes back one ply exactly`, m);
  // leave and come back
  L.keys(m, ['ON']); m.runSeconds(1); L.keys(m, ['S', 'S', 'S', 'EXE']); m.runSeconds(3); H.top(m);
  const dirs = H.dir(m);
  soft(nosv ? !dirs.includes('CHESSAV') : dirs.includes('CHESSAV'), `A: full, FREE ${fr}: files on A: "${dirs}"`, m);
  table.push(`| ${fr} | ${o.c} | ${nosv ? 'no: CANNOT SAVE: NO ROOM' : 'yes'} | ${nosv ? 'CANNOT TAKE BACK' : 'exact'} |`);
  m.runProc('CHESS', 'B'); m._base = null; m.runSeconds(8); G.waitInput(m, 10);
  const n2 = L.peekSym(m, 'g_n')[0];
  soft(nosv ? n2 === 0 : n2 === n, `A: full, FREE ${fr}: run again: ${nosv ? 'a new game (nothing was kept)' : 'the game resumes'} (${n2} plies)`, m);
}

console.log(table.join(String.fromCharCode(10)));
if (fails) { console.log(fails + ' failures'); process.exit(1); }
console.log('all low-memory tests passed');
