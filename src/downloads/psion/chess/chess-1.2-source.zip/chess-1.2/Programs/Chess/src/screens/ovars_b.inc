; board overlay's own variables (gone when the slot is reused)
bk_on     = ZP2+0                    ; blink phase: the squares in bk_sq are drawn empty
bk_sq     = ZP2+1   
bk_n      = ZP2+4   
bk_t      = ZP2+5   
cur_on    = ZP2+6                    ; the cursor's blink phase
dr_top    = ZP2+7   
dr_c      = ZP2+8   
dr_r      = ZP2+9   
dr_col    = ZP2+10  
dr_sq     = ZP2+11  
dr_t      = ZP2+12  
dr_p      = ZP2+13  
in_n      = ZP2+15                  ; characters typed
in_buf    = ZP2+16  
sel       = ZP2+20                  ; the chosen piece's square, $FF none
hu_s      = ZP2+22  
hu_step   = ZP2+23  
hu_tmp:   rmb 12
hu_idle   = ZP2+24                  ; cursor blinks since the last key
clk_tk    = ZP2+25  
pw_t      = ZP2+26  
pw_f      = ZP2+28  
