#!/usr/bin/env python3
"""Cross-check kpk.bin with python-chess as an independent move generator.

1. Full check: for every normalised placement (pawn White, files a-d) build a
   chess.Board, use board.is_valid() for legality and board.legal_moves for the
   move graph, solve by least-fixpoint iteration, compare every bit with kpk.bin.
   Promotions: B/N -> draw; Q/R -> python-chess board after the move: checkmate
   = win, stalemate = draw, any legal king capture of the new piece = draw,
   otherwise win (KQK/KRK always won with White to move; proven by kpk_indep.js).
2. Forward check: depth-limited search (python-chess, no tables) on random
   positions from both colours / all files; every position the search proves
   (win or draw) must agree with kpk.probe.

Usage: python xcheck_chess.py [N_RANDOM=3000] [DEPTH=11]
"""
import random
import sys
import time

import chess

import kpk

IDX = kpk.IDX


def promo_value(board, move):
    if move.promotion in (chess.BISHOP, chess.KNIGHT):
        return 0
    board.push(move)
    try:
        if board.is_checkmate():
            return 1
        if board.is_stalemate():
            return 0
        for m in board.legal_moves:
            if m.to_square == move.to_square:
                return 0
        return 1
    finally:
        board.pop()


def make_board(wk, bk, wp, side, pawn_white=True):
    b = chess.Board(None)
    b.set_piece_at(wk, chess.Piece(chess.KING, chess.WHITE))
    b.set_piece_at(bk, chess.Piece(chess.KING, chess.BLACK))
    b.set_piece_at(wp, chess.Piece(chess.PAWN, chess.WHITE if pawn_white else chess.BLACK))
    b.turn = chess.WHITE if side == 0 else chess.BLACK
    return b


def full_check(table):
    t0 = time.time()
    win = bytearray(1 << 19)
    nodes = []          # (idx, side, succ)
    legal_mismatch = 0
    for side in (0, 1):
        for wp in kpk.pawn_squares():
            for wk in range(64):
                for bk in range(64):
                    if len({wk, bk, wp}) < 3:
                        continue
                    b = make_board(wk, bk, wp, side)
                    valid = b.is_valid()
                    if valid != kpk.legal(side, wp, wk, bk):
                        legal_mismatch += 1
                    if not valid:
                        continue
                    i = IDX(side, wp, wk, bk)
                    succ = []
                    term = None
                    moves = list(b.legal_moves)
                    if not moves:
                        term = 1 if b.is_check() else 0
                    for m in moves:
                        if m.promotion:
                            v = promo_value(b, m)
                            if side == 0 and v == 1:
                                term = 1
                            continue
                        b.push(m)
                        pw = b.pieces(chess.PAWN, chess.WHITE)
                        if not pw:                 # Black captured the pawn
                            b.pop()
                            if side == 1:
                                term = 0
                            continue
                        succ.append(IDX(1 - side, next(iter(pw)),
                                        b.king(chess.WHITE), b.king(chess.BLACK)))
                        b.pop()
                    if term is not None:
                        win[i] = term
                        continue
                    if side == 0 and not succ:
                        continue                   # only losing promotions: draw
                    nodes.append((i, side, succ))
    build = time.time() - t0
    changed = True
    while changed:
        changed = False
        rest = []
        for i, side, succ in nodes:
            if side == 0:
                v = any(win[s] for s in succ)
            else:
                v = all(win[s] for s in succ)
            if v:
                win[i] = 1
                changed = True
            else:
                rest.append((i, side, succ))
        nodes = rest
    packed = kpk.pack(win)
    diff = sum(1 for a, b in zip(packed, table) if a != b)
    print('python-chess full retrograde: graph built in %.1fs, legality mismatches %d, '
          'differing bytes vs kpk.bin %d' % (build, legal_mismatch, diff))
    return legal_mismatch == 0 and diff == 0


def forward(board, depth, tt):
    """1 = proven win for the pawn owner, 0 = proven draw, None = unknown."""
    key = board._transposition_key()
    hit = tt.get(key)
    if hit is not None:
        d0, r0 = hit
        if r0 is not None or d0 >= depth:   # proven results are depth-independent
            return r0
    pawn_white = bool(board.pieces(chess.PAWN, chess.WHITE))
    strong = chess.WHITE if pawn_white else chess.BLACK
    moves = list(board.legal_moves)
    if not moves:
        r = 1 if board.is_check() else 0
        tt[key] = (99, r)
        return r
    strong_to_move = board.turn == strong
    results = []
    for m in moves:
        if m.promotion:
            r = promo_value(board, m)
        elif board.piece_type_at(m.to_square) == chess.PAWN:
            r = 0
        elif depth <= 1:
            r = None
        else:
            board.push(m)
            r = forward(board, depth - 1, tt)
            board.pop()
        results.append(r)
        if strong_to_move and r == 1:
            break
        if not strong_to_move and r == 0:
            break
    if strong_to_move:
        res = 1 if 1 in results else (0 if all(x == 0 for x in results) else None)
    else:
        res = 0 if 0 in results else (1 if all(x == 1 for x in results) else None)
    tt[key] = (depth, res)
    return res


def forward_check(table, n, depth, seed=12345):
    rnd = random.Random(seed)
    stats = {'win': 0, 'draw': 0, 'unknown': 0}
    bad = []
    t0 = time.time()
    done = 0
    tt = {}             # shared: proven values are exact facts
    while done < n:
        wk, bk = rnd.randrange(64), rnd.randrange(64)
        p = rnd.randrange(8, 56)
        col = rnd.randrange(2)
        stm = rnd.randrange(2)
        if len({wk, bk, p}) < 3:
            continue
        b = make_board(wk, bk, p, stm, pawn_white=(col == 0))
        if not b.is_valid():
            continue
        done += 1
        r = forward(b, depth, tt)
        tv = kpk.probe(wk, bk, p, stm, col, table)
        if r is None:
            stats['unknown'] += 1
            continue
        stats['win' if r else 'draw'] += 1
        if r != tv:
            bad.append((b.fen(), r, tv))
    print('forward search depth %d on %d random legal positions (%.1fs): proven win %d, '
          'proven draw %d, unresolved %d, disagreements %d'
          % (depth, n, time.time() - t0, stats['win'], stats['draw'], stats['unknown'], len(bad)))
    for x in bad[:10]:
        print('   ', x)
    return not bad


if __name__ == '__main__':
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 3000
    depth = int(sys.argv[2]) if len(sys.argv) > 2 else 11
    table = kpk.load()
    ok = full_check(table)
    ok = forward_check(table, n, depth) and ok
    print('XCHECK', 'PASSED' if ok else 'FAILED')
    sys.exit(0 if ok else 1)
