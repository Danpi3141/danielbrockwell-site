# Opening book audit (16 Nov 2026)

This audit covers `data/book.bin` and runs the five checks asked for:
1. no terrible moves;
2. mistakes get punished;
3. safe exits;
4. sound structure, including the Psion's own book reader;
5. coverage.

**Books.**

| | file | bytes | moves | groups | P moves |
|---|---|---|---|---|---|
| Before (built 15 Nov 23:43) | `data/book_v1.bin` (kept) | 11,084 | 5,494 | 959 | 1,648 |
| After (built 16 Nov 11:12) | `data/book.bin` | 11,602 | 5,744 | 1,459 | 2,051 |

**What changed.** The new book comes from `build_book.py` with a new post-pass (see *Fixes*). The
tree is grown to 5,018 moves, and the post-pass then adds 726 and removes a few. The format is
unchanged: the old reader and `book.py selftest` accept the new book.

**Scripts.** All the scripts are in `tools/book/audit/`. Each one runs on its own, and `run_all.py`
runs them all in order. Stockfish results are cached in `tools/book/audit/cache/sf_eval.json`, so a
rerun takes minutes. Don't run two audits at once, because they share the cache.

## Method

- **Decoder.** `decode.js` is an independent decoder written in JavaScript. It takes legality from
  the reference engine (`ref/search.js`), and it does not use `book.py` or python-chess. The Python
  checks read the tree from it.
- **Stockfish 19.** 1 thread, 128 MB hash, 12 searches in parallel.
  - **Screening.** The build judged moves at depth 16; the audit screens at **depth 22**. Every
    position in the tree gets one eval: each group's position and each leaf. A move's score is minus
    the eval after it.
  - **Confirmation.** Anything near a threshold is confirmed by **restricted root searches at depth
    26**: the move in question, and Stockfish's own depth-26 best, searched the same way. A move that
    is Stockfish's best therefore loses 0.
  - **Node caps.** Searches are capped at 18 M nodes (depth 22) and 50 M nodes (depth 26). The cap
    was added after one depth-26 search ran for over 15 minutes. Typical searches need 1–3 M and
    5–15 M nodes, so the cap rarely applies.
  - **Mates.** Mate scores are clamped to ±3000 cp.
- **Capped engine.** `ref/uci.js` with `Nodes 2500`, the Psion's level 7. The TT is cleared for each
  position (`ucinewgame`), and the game moves are sent from the start position.
- **Reachable.** A position matters for the Psion playing one colour only if every move of that
  colour on the way to it is a P move. For example, the Psion as White always plays 1.e4, so the P
  moves after 1.d4 d5 are never played.
- **Exit weights.** Exits are weighted by the probability of a game reaching them. The Psion picks
  uniformly among the P moves, as the kernel does. The opponent's moves follow club frequencies in
  `stats.pkl`.

**The reference engine changed under the audit.** Another agent modified `ref/engine.js` at 07:21
and `ref/search.js` at 09:00, so the capped engine's choices changed during the audit. The first
post-pass build (06:33–08:39) straddled the 07:21 change. Its book (11,772 bytes) was audited and
had 24 unpunished mistakes, because the exits had been judged with the old engine's moves. That
book was discarded.

The final book and all the "before/after" numbers below use the engine as of 09:00. With warm caches,
two rebuilds gave byte-identical books. **When the engine's search or evaluation changes again,
rerun `build_book.py --stage tree` (about 5 minutes with warm caches) and checks 2 and 3.**

## 1. No terrible moves

```
python -E -P tools/book/audit/eval_tree.py [--book F]
python -E -P tools/book/audit/check1_pmoves.py [--book F]
```

**What it checks.** Every P move is scored and compared with the best move in its position. A move
losing 30 cp or more in the depth-22 screen is confirmed at depth 26. A move is **flagged** if it
loses more than 50 cp there.

| | old book | new book |
|---|---|---|
| P moves (reachable / unreachable) | 1,648 (1,028 / 620) | 2,051 (1,370 / 681) |
| screen loss for reachable moves: < 10 / 10–29 / 30–49 / 50–99 / ≥ 100 cp | 616 / 323 / 82 / 7 / 0 | 931 / 374 / 63 / 1 / 1 |
| confirmed > 50 cp, reachable | **6** (worst 60 cp) | **0** (worst 49 cp) |
| confirmed > 50 cp, unreachable | 10 | 9 |

None of the old book's moves is terrible: none loses 100 cp, and the worst loses 60 cp. These are
the six reachable moves over 50 cp (Stockfish's move in brackets):
- 1.e4 e5 2.Nf3 Nc6 3.Bb5 Qf6 4.d3: −60 (Nc3).
- 1.e4 e6 2.d4 c6 3.c4: −57 (Nf3).
- 1.e4 e5 2.Nf3 f6 3.d4: −55 (Nxe5). This one also matters for check 2.
- 1.e4 e5 2.Nf3 d6 3.d4 Nd7 4.dxe5: −54 (c4).
- 1.e4 e5 2.Nf3 Nf6 3.Nxe5 Qe7 4.Nf3: −54 (d4).
- Philidor line …6.Bc4: −52 (Qb3).

The unreachable ones go up to −136: 1.e4 e5 2.Nf3 Nc6 3.Bb5 Bc5 4.c3 Qf6. They are never played,
because the Psion never reaches those positions with that colour.

In the new book, one reachable move screens at ≥ 100 cp and one at 50–99 cp, but both are under
50 cp at depth 26.

## 2. Mistakes get punished

```
python -E -P tools/book/audit/check2_punish.py [--book F]
```

**What it checks.**
- A **mistake** is an opponent move in a reachable position that loses at least 90 cp, confirmed at
  depth 26.
- If the book has a reply group after the mistake, every P move in it must be within 30 cp of the
  best (depth 26).
- If the mistake is a leaf, the Psion thinks for itself. Its capped-engine move must meet the same
  30 cp limit.

| | old book | new book |
|---|---|---|
| opponent moves in reachable positions | 3,245 | 3,137 |
| mistakes | 424 (18 with a reply group, **406 leaves**) | 386 (170 with a reply group, 216 leaves) |
| book answers not refuting | 1 | **0** |
| engine answers (at leaves) not refuting | **141** | **2** |

**Old book: the problem was the leaves.** The book recorded club players' blunders but usually
ended right there. The capped engine then often missed the refutation:
- 3.Bc4 h6 4.d4 Na5 (−753): the engine plays 5.Nxe5 and misses 5.Bxf7+ by 692 cp.
- 3.Bc4 Nf6 4.Ng5 Nxe4 (−301): the engine plays 5.Nxf7, 390 cp below 5.Bxf7+.
- 2.Nf3 f6 3.Bc4 h6 and 3.Bc4 g5 (−657 / −524): the engine castles, about 520–575 cp below 4.Nxe5.
- Petrov 3.Nxe5 Nxe4 4.Qe2 Qh4 (−548): the engine plays 5.g3, 527 cp below 5.d3.
- 2.Qh5 Nc6 3.Bc4 g6 4.Qf3 Nf6 5.Qb3 (−595): the engine (as Black) plays 5…Qe7, 418 cp below 5…Nd4.

The one book failure was 1.e4 e5 2.Nf3 f6 (−172). Of its P answers, 3.d4 (−55) lets most of the
gain go and 3.Bc4 (−30) is at the limit; Stockfish plays 3.Nxe5. In the new book that group's P moves
are 3.Bc4 and 3.Nxe5, and 3.d4 has lost its P flag.

**New book.** Two engine answers still miss the 30 cp limit:
- 1.e4 e5 2.Nf3 d5 3.exd5 Qxd5 4.Nc3 Qd8 5.Nxe5: −59 against 5.Bc4.
- 4…Qd7 5.Nxe5: −40 against 5.Bb5.

Both are disagreements between the build's depth 22 and the audit's depth 26. At depth 22, Nxe5 is
best after 4…Qd7, and 4…Qd8 loses only 53 cp, so the build does not count it as a mistake. White
keeps a clear advantage either way.

## 3. Safe exits

```
python -E -P tools/book/audit/check3_exits.py [--book F]
```

**Exit positions.**
- **(a)** A leaf reached by an opponent move, with the Psion to move.
- **(b)** A leaf reached by the Psion's own P move, followed by the opponent's commonest club
  replies there: up to 3 replies, each with at least 10% of the position's games and at least 10
  games.

**Rule.** The capped engine picks its first move at each exit. A move is **flagged** if it is at
least 100 cp below Stockfish's best (screened from 85 cp at depth 22, confirmed at depth 26) and the
Psion is then no better than +200. The +200 condition leaves out a drop from +500 to +380.

| | old book | new book |
|---|---|---|
| exits (a) / (b) | 2,648 / 899 | 2,114 / 895 |
| first move ≥ 100 cp below best | 194 / 54 | 1 / 7 |
| flagged (Psion then ≤ +200) | **182 / 53 = 235** | **1 / 0** |
| flagged share of exit probability (all / White / Black) | 5.5% / 6.1% / 5.0% | 0.01% / 0.00% / 0.02% |

**Worst old exits, by probability of reaching them** (engine move, loss, Psion's score after it;
Stockfish's move last):
- 1.e4 e5 2.Nf3 Nc6 3.d4 exd4 4.Nxd4 Nxd4 5.Qxd4 Nf6: Nc3 −132 (+118); e5.
- 3.Bb5 Nge7 4.c3 a6: Bd3 −161 (−116); Ba4.
- 3.d4 exd4 4.Bc4 Bc5 5.c3 dxc3: Nxc3 −107 (−5); Bxf7+.
- 2.Nf3 Nf6 3.d4 exd4 4.e5 Qe7: Qe2 −148 (−27); Be2.
- 2.Nf3 Nf6 3.d4 exd4 4.e5 Nd5: c3 −148 (0); Qxd4.
- Psion Black, 1.d4 Nf6 2.c4 g6 3.Nc3 d5 4.Nf3: dxc4 −114 (−142); Bg7.
- 2.Nf3 Qf6 3.Nc3 c6 4.d4 exd4: Nxd4 −208 (+160); Bg5.

**Worst old exits, by size of the loss:**
- Psion Black in the Two Knights, …8.Ba4 h6 9.Nf3 e4 10.Ne5: Qd5 −735; Qd4.
- 3.Bc4 h6 4.d4 Na5: Nxe5 −692; Bxf7+.
- French 3.Nc3 dxe4 4.Nxe4 f5: Bd3 −663; Ng3.
- Psion Black, Sicilian Dragon …6.Be3 Nf6 7.f3: Nxe4 −594; O-O.

**Remaining in the new book.**
- Flagged: one exit, 1.d4 Nf6 2.Nf3 e6 3.c3 Bd6 (Psion Black): −101, then −118; Stockfish plays
  d5. It has probability 0.00014 and lost under 80 cp at the build's depth 22.
- Not flagged: seven exits drop ≥ 100 cp while the Psion stays at +236 to +500. Examples are the
  open Ruy Lopez line …7.Re1 Nf6 8.Nxe5 (−119, still +249) and the Caro-Kann 7.Ne5 Bh7 8.Bc4 (−314,
  still +236).

## 4. Sound structure

```
node tools/book/audit/decode.js [book.bin] [--json out]
node tools/book/audit/kernel_check.js --opk PACK --book BOOK [--lines N --games N --seed S]
```

**Decoder.** `decode.js` walks the whole file and checks that:
- every move is legal in its position, with no pawn moves to the last rank (the format has no
  promotions);
- no move appears twice in a group;
- the J flag is set exactly when a reply group exceeds 256 bytes, and its 3-byte length is exact;
- J appears only with R;
- every group ends with an L entry before its parent's end (the J length, else end of file);
- the file is consumed exactly;
- every group has a P move;
- P moves come before the others.

| | old book | new book |
|---|---|---|
| bytes, moves, groups, P, J, leaves | 11,084, 5,494, 959, 1,648, 32, 4,536 | 11,602, 5,744, 1,459, 2,051, 38, 4,286 |
| errors / warnings / groups without P | 0 / 0 / 0 | 0 / 0 / 0 |
| `book.py selftest` | OK | OK |

The decoder was also tested by flipping bits: an L flag on the first move, two extra trailing bytes,
a flag bit inside a J length, and a from-square bit. Each one was caught (unconsumed file, group
overrun, illegal move). One flipped P bit, in a group that still had another P move, was rightly not
an error.

**Max depth is now 21 plies.** It was 20, and the post-pass may add a ply. Nothing in the kernel
limits depth: the reader keeps a single pointer.

**Kernel reader.** The Psion's own reader is `src/screens/kbook.asm`, in the OV_GAME overlay. It was
checked against the decoder in the headless emulator, by playing book lines through the real UI.
- **Two-player mode.** Random walks through the tree, of three kinds: deep, late siblings with J
  skips, and both. Every fourth line leaves the book early, and every line plays 2 legal non-book
  moves after its end. Every third line takes the last ply back, which replays the game from the
  start through the book.
- **What is compared after every ply.** `bk_in` must be 1 exactly when the decoder has a group, and
  `bk_p` must equal the decoder's offset of that group.
- **Against the computer, both colours, level 1.** Each computer move made in book must be one of
  the group's P moves (`bk_pick`).
- **Packs.** The pack was built with `tools/build.py --out` into a scratch folder from a copy of
  `src/` and `tools/`. The project's `build/game` was left alone. The script checks that the pack
  holds exactly the book's bytes.

| run | checks | positions in book (distinct) | out of book | computer picks | J skips | take-backs | failures |
|---|---|---|---|---|---|---|---|
| old book (`build/game/CHESS.opk`) | 1,954 | 869 (*) | 1,001 | 84 | 662 | 100 | **0** |
| first post-pass book | 2,834 | 1,431 (160) | 1,319 | 84 | 862 | 133 | **0** |
| new book (600 lines, 40 games) | 5,259 | 3,225 (774) | 1,944 | 90 | 1,300 | 200 | **0** |

(*) That first run did not yet count distinct positions; by construction its walks were shallow
(about 100 distinct). The last run sends every third line to a book position drawn uniformly from
all groups, which is how it reaches 774 distinct positions. Command:
`node tools/book/audit/kernel_check.js --opk PACK --book data/book.bin --lines 600 --games 40 --seed 11`.

Reading the code also found nothing wrong:
- The key is built correctly from 0x88 squares (promotion bits masked).
- J lengths are followed with the high byte ignored, which is fine below 64 KB.
- A small branch is skipped by recursive scanning, and `bk_fl` is reread only before any recursion.
- `bk_pick` takes up to 8 P moves, picks one at random with `rnd`, checks it is legal with `lm_find`,
  and leaves the book if none is legal.

**Not checked:**
- the kernel reader on promotions (the book has none);
- a book over 64 KB;
- the real Organiser's pack reads (the emulator's pack model was used).

## 5. Coverage

```
python -E -P tools/book/audit/check5_coverage.py [--book F] [--games 10000] [--mc 20000]
```

**(a) Simulation.** The Psion plays its P moves uniformly. The opponent moves by club frequency
(players 1200–1900, games of 3 minutes or more). Moves played in fewer than 10 games, and positions
with no statistics, count as leaving the book. The table shows the probability that the Psion is
still in book when it makes its Nth move, computed exactly, with a 20,000-game Monte Carlo run
agreeing within 1 point.

| | move 4 | move 6 | move 8 |
|---|---|---|---|
| Psion White, old | 65.0% | 11.5% | 1.4% |
| Psion White, new | 68.8% | 15.7% | 1.8% |
| Psion Black, old | 32.0% | 4.0% | 0.9% |
| Psion Black, new | 33.1% | 4.6% | 1.0% |

**(b) Replay.** 10,000 club games were sampled from the 2,193,824 in `games.txt`, and the same games
are used for both books. **These games come from the same month (Lichess 2016-01) that the book was
built from, so the figures are optimistic.**

Columns:
- **path**: the share of games whose moves before the Psion's Nth move are a path in the book.
- **P-only games**: games where the Psion's side played only P moves so far, as the Psion would have.
- **in book**: the share of those games that are still in book.

| | move 4: path | move 4: P-only games → in book | move 6: path | move 6: P-only games → in book | move 8: path | move 8: P-only games → in book |
|---|---|---|---|---|---|---|
| White, old | 25.7% | 2,339 → 78.2% | 2.3% | 462 → 46.5% | 0.2% | 45 → 42% |
| White, new | 26.2% | 2,137 → 80.7% | 2.6% | 451 → 53.9% | 0.2% | 40 → 40% |
| Black, old | 14.9% | 1,652 → 60.4% | 1.2% | 170 → 40.6% | 0.1% | 23 → 61% |
| Black, new | 15.1% | 1,653 → 61.4% | 1.3% | 159 → 47.8% | 0.1% | 22 → 64% |

**What the numbers say.**
- The book is broad and shallow: the mean leaf depth is 7.4 plies.
- As White, the Psion is usually in book for its first 3–4 moves but rarely past move 6.
- As Black, it leaves even sooner, because club players' White first moves are spread out
  (1.e4 1.d4 1.c4 1.Nf3 1.e3 1.g3, and 1.f4, 1.b3, 1.b4 and 1.Nc3 are not in the book at all).
- The move-8 replay samples are tiny (14–45 games).

## Fixes made

All the fixes are in `tools/book/build_book.py`. The format and `book.py` are untouched.

**`post_pass()`.** It runs after the tree is grown, inside the size loop:
- **Stockfish at depth 22.** Uses a new cache, `cache/sf22.json`, with an 18 M node cap.
- **Capped reference engine.** Run through a small pool of processes (`RefPool`).

Its thresholds are a little tighter than the audit's, to leave room for depth-22/26 differences:
1. A reachable P move more than 40 cp below the best loses its P flag. It is kept as an opponent
   move if it is a common club move, else removed. 19 moves were demoted.
2. After an opponent mistake of 70 cp or more, the P answers must be within 15 cp of the best.
   - 5 answers were demoted.
   - 1 group got Stockfish's move as its P move.
   - Leaves after mistakes are handled in step 3 with the 15 cp limit.
3. **Exits.** The rule is "drop ≥ 80 cp while ≤ +200", or "> 15 cp" right after a mistake.
   - A failing exit with the Psion to move gets Stockfish's best move as a new P move (317 times).
   - A failing exit after the Psion's last book move and a club reply gets the reply, then
     Stockfish's move as P (159 times).
   - A new group that has no P move gets Stockfish's best as one (134 times).
   - Up to 4 rounds. The bad exits went 381 → 84 → 11 → 0.

**Other changes to the build.**
- **Size.** The size loop now runs after the post-pass, shrinking the grown tree in 3% steps until
  the book fits `MAX_BYTES` (11,800, unchanged).
  - The tree went 5,500 → 5,335 → 5,174 → 5,018 grown moves, for 11,602 bytes and 5,744 moves.
  - A larger book was possible, up to 11,800 bytes. I kept the existing byte limit rather than raise
    it.
- **Atomic write.** `data/book.bin` is now written to `book.bin.tmp` and then renamed.
- **New options.**
  - `--out FILE` builds elsewhere; the report goes to `FILE.txt`.
  - `--no-post` builds without the post-pass. It reproduces `book_v1.bin` byte for byte (checked).
- **Thread-safety.** The build's Stockfish cache is now updated and saved under a lock; before,
  worker threads could change it while it was being saved.
- **Copies and docs.**
  - The pre-audit script is kept as `tools/book/build_book_v1.py.txt`.
  - `tools/book/README.md` describes the post-pass and the new options.

**After the change, all five checks were rerun:**
- check 1: 0 flagged;
- check 2: 0 book and 2 engine misses, both 40–59 cp and depth-dependent;
- check 3: 1 flagged exit, probability 0.01%;
- check 4: 0 errors, and the kernel reader agrees;
- check 5: coverage slightly up;
- `book.py selftest`: OK.

## Not checked / limits

- Stockfish judges at depth 22/26 on a single thread; borderline cases (±10–20 cp) can flip between
  depths. The thresholds are the ones asked for, applied to the depth-26 confirmation.
- **Exits are judged for the capped engine at 2,500 nodes only.** Lower levels search less and will
  go wrong more often; higher levels less often.
  - The real Psion's level 7 stops on time, not nodes, so its node count varies around 2,500.
- **Exits after a rare opponent move inside the book are not checked.** These are moves below the
  book's 30-game / 1% threshold, played at an internal node. Exits after the opponent's 4th and later
  club replies at a leaf, or after replies under 10%, are not checked either.
- Transpositions are not followed: neither the kernel nor the audit does. A game that reaches a book
  position by an unlisted move order is out of book.
- The kernel-reader comparison ran in the emulator, not on the Organiser. The pack in `build/game`
  was not rebuilt: it still holds the old book until the next `tools/build.py`. The book is now
  518 bytes larger.
- `docs/ui-report.md` and `README.md` still quote the old book size (11,084 bytes / 5,494 moves);
  those files belong to other agents.
