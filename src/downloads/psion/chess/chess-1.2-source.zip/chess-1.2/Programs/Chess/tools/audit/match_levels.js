'use strict';
// Self-play matches on the JS reference, with the game's levels (levels.js) or plain node limits.
//   node match_levels.js NAME SPEC_A SPEC_B [--openings 0:242] [--workers 6] [--maxply 300]
// SPEC: L1..L8 (a level), N2500 (nodes, margin 0), N300M150 (nodes and margin); add @dir for another
// engine folder (e.g. N2500@../match/snap_v3). Each opening of tools/match/openings.txt is played
// with both colours. The TT (512 entries) is kept for the whole game, as on the Psion; each game has
// its own random seed. Results: tools/audit/results/NAME.jsonl (moves included, so the games can be
// checked independently: check_games.py). Prints W/D/L for A, the score and an Elo difference with
// a 95% interval (pentanomial: the two games of an opening as a pair).
const fs = require('fs');
const path = require('path');
const { fork } = require('child_process');
const L = require('./levels.js');

function parseSpec(s) {
  const [main, dir] = s.split('@');
  let m;
  if ((m = /^L([1-8])$/.exec(main))) return { lv: +m[1], dir };
  if ((m = /^N(\d+)(?:M(\d+))?$/.exec(main))) return { nodes: +m[1], margin: +(m[2] || 0), dir };
  throw new Error('bad spec ' + s);
}
const engines = {};
function engineFor(spec) {
  const key = spec.dir || '';
  if (!engines[key]) engines[key] = L.loadEngine(spec.dir ? path.resolve(__dirname, spec.dir) : null);
  return engines[key];
}
function think(e, spec) {
  if (spec.lv) return L.levelThink(e, spec.lv);
  return spec.margin ? e.think(spec.nodes, 40, spec.margin) : e.think(spec.nodes);
}

// status as eng_status: 0 playing, 1 mate, 2 stalemate, 3 fifty, 4 threefold, 5 too little material
function status(E, e) {
  const n = E.legalMoves(e).length;
  if (n === 0) return e.inCheck() ? 1 : 2;
  if (e.half >= 100) return 3;
  let c = 0;
  for (let i = e.keys.length - 2; i >= Math.max(0, e.keys.length - e.half); i -= 2) if ((e.keys[i] >>> 8) === (e.key >>> 8)) c++;
  if (c >= 2) return 4;
  if (e.insufficient()) return 5;
  return 0;
}

function playGame(job) {
  const { opening, aWhite, A, B, maxply, seed } = job;
  const sa = parseSpec(A), sb = parseSpec(B);
  const EA = engineFor(sa), EB = engineFor(sb), ER = engineFor({});
  const START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
  const ea = new EA.Engine(), eb = new EB.Engine(), ref = new ER.Engine();
  for (const e of [ea, eb, ref]) { e.ttInit(9); e.setFen(START); }
  ea.rnd = (seed & 0xFFFF) || 1; eb.rnd = ((seed * 7 + 12345) & 0xFFFF) || 1;
  const moves = [];
  const apply = (u) => {
    for (const [E, e] of [[EA, ea], [EB, eb], [ER, ref]]) {
      const m = E.parseUci(e, u);
      if (!m) throw new Error('illegal move ' + u + ' in ' + moves.join(' '));
      e.make(m[0], m[1]); e.ply = 0;
      if (e.half === 0) e.keys.length = 0;   // the game history forgets before irreversible moves, as the Psion
    }
    moves.push(u);
  };
  for (const u of opening.split(' ')) apply(u);
  const stats = { a: [], b: [] };
  let st = 0, result, error = null;
  try {
    for (;;) {
      st = status(ER, ref);
      if (st) break;
      if (moves.length >= maxply) break;
      const aToMove = (ref.side === 0) === aWhite;
      const [E, e, spec, who] = aToMove ? [EA, ea, sa, 'a'] : [EB, eb, sb, 'b'];
      const r = think(e, spec);
      if (!r) throw new Error('no move');
      const u = E.uciStr(e, r.f, r.t);
      stats[who].push([r.depth, r.nodes]);
      apply(u);
    }
  } catch (x) { error = String(x.stack || x); }
  let sw;   // White's score
  if (error) sw = (ref.side === 0) ? 0 : 1;
  else if (st === 1) sw = ref.side === 0 ? 0 : 1;
  else sw = 0.5;
  result = sw === 1 ? '1-0' : sw === 0 ? '0-1' : '1/2-1/2';
  const reason = error ? 'error' : ['maxply', 'checkmate', 'stalemate', 'fifty', 'threefold', 'insufficient'][st];
  return { opening: job.oi, a_white: aWhite, result, reason, plies: moves.length, score_a: aWhite ? sw : 1 - sw, moves: moves.join(' '), error, depth_a: avg(stats.a, 0), depth_b: avg(stats.b, 0) };
}
function avg(list, k) { return list.length ? +(list.reduce((s, x) => s + x[k], 0) / list.length).toFixed(2) : 0; }

function eloStats(recs) {
  // pentanomial on opening pairs
  const pairs = {};
  for (const r of recs) (pairs[r.opening] = pairs[r.opening] || []).push(r.score_a);
  const ps = Object.values(pairs).filter(p => p.length === 2).map(p => p[0] + p[1]);
  const n = ps.length;
  const all = recs.map(r => r.score_a), N = all.length;
  const s = all.reduce((a, b) => a + b, 0) / N;
  let ci = null;
  if (n > 1) {
    const m = ps.reduce((a, b) => a + b, 0) / n;
    const v = ps.reduce((a, b) => a + (b - m) ** 2, 0) / (n - 1);
    const se = Math.sqrt(v / n) / 2;           // per-game score
    ci = [s - 1.96 * se, s + 1.96 * se];
  }
  const elo = (x) => x <= 0 ? -Infinity : x >= 1 ? Infinity : -400 * Math.log10(1 / x - 1);
  return { N, s, elo: elo(s), lo: ci ? elo(Math.max(1e-6, ci[0])) : null, hi: ci ? elo(Math.min(1 - 1e-6, ci[1])) : null };
}

if (process.send && process.argv[2] === '--worker') {
  process.on('message', (job) => { if (job === 'quit') process.exit(0); process.send(playGame(job)); });
} else if (require.main === module) {
  const args = process.argv.slice(2);
  const opt = (k, d) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : d; };
  const [name, A, B] = args;
  const [lo, hi] = opt('--openings', '0:242').split(':').map(Number);
  const W = +opt('--workers', 6), maxply = +opt('--maxply', 300);
  const ops = fs.readFileSync(path.join(__dirname, '..', 'match', 'openings.txt'), 'utf8').trim().split(/\r?\n/);
  fs.mkdirSync(path.join(__dirname, 'results'), { recursive: true });
  const out = path.join(__dirname, 'results', name + '.jsonl');
  const done = new Set();
  const recs = [];
  if (fs.existsSync(out)) for (const l of fs.readFileSync(out, 'utf8').split('\n')) if (l.trim()) { const r = JSON.parse(l); done.add(r.opening + ':' + r.a_white); recs.push(r); }
  const jobs = [];
  for (let i = lo; i < Math.min(hi, ops.length); i++) for (const aw of [true, false]) if (!done.has(i + ':' + aw)) jobs.push({ oi: i, opening: ops[i], aWhite: aw, A, B, maxply, seed: (i * 2 + (aw ? 0 : 1)) * 7919 + 17 });
  console.log(`${name}: ${A} v ${B}, ${jobs.length} games to play`);
  const t0 = Date.now();
  const fd = fs.openSync(out, 'a');
  let next = 0, fin = 0, errors = 0;
  const tally = [0, 0, 0];
  const finish = () => {
    const st = eloStats(recs);
    const w = recs.filter(r => r.score_a === 1).length, d = recs.filter(r => r.score_a === 0.5).length, l = recs.filter(r => r.score_a === 0).length;
    const reasons = {}; for (const r of recs) reasons[r.reason] = (reasons[r.reason] || 0) + 1;
    console.log(`${name}: ${A} v ${B}: ${st.N} games, A +${w} =${d} -${l}, score ${(100 * st.s).toFixed(1)}%, Elo ${st.elo.toFixed(0)} [${st.lo === null ? '?' : st.lo.toFixed(0)}, ${st.hi === null ? '?' : st.hi.toFixed(0)}]  ends ${JSON.stringify(reasons)}  errors ${recs.filter(r => r.error).length}  ${((Date.now() - t0) / 1000).toFixed(0)}s`);
  };
  if (!jobs.length) { finish(); return; }
  for (let k = 0; k < Math.min(W, jobs.length); k++) {
    const c = fork(__filename, ['--worker']);
    const feed = () => { if (next < jobs.length) c.send(jobs[next++]); else c.send('quit'); };
    c.on('message', (r) => {
      r.a = A; r.b = B;
      fs.writeSync(fd, JSON.stringify(r) + '\n');
      recs.push(r); fin++;
      if (r.error) { errors++; console.log('ERROR', r.error.slice(0, 400)); }
      tally[r.score_a === 1 ? 0 : r.score_a === 0.5 ? 1 : 2]++;
      if (fin % 50 === 0) console.log(`  ${fin}/${jobs.length} +${tally[0]} =${tally[1]} -${tally[2]} ${((Date.now() - t0) / 1000).toFixed(0)}s`);
      if (fin === jobs.length) { fs.closeSync(fd); finish(); }
      feed();
    });
    feed();
  }
}
module.exports = { playGame, parseSpec, status, eloStats };
