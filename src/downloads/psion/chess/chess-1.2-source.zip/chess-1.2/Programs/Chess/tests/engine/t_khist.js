'use strict';
// The key history (e_khist, E_KMAX entries; 17 Nov): the game's part is cleared after an
// irreversible move and capped at E_KCAP entries by eng_play, and a search adds one entry a ply
// up to ply E_MAXPLY-2 (the quiescence search stands pat at E_MAXPLY-1). So it never holds more
// than E_KCAP-1 + E_MAXPLY-1 entries. This drives it to the worst case: positions where most
// moves are reversible, games of up to 99 reversible plies played with eng_play (and past the
// fifty-move mark, as an imported game can be), then deep searches (checks and long capture
// sequences), watching e_kn at every push. Also the repetition and fifty-move statuses against
// the JS reference all the way.
//   node tests/engine/t_khist.js [games=12]
const { Harness } = require('./harness.js');
const { Engine, legalMoves } = require('../../ref/search.js');

const GAMES = +(process.argv[2] || 12);
const h = new Harness();
const SYM = JSON.parse(require('fs').readFileSync(require('path').join(__dirname, 'out', 'etest.json'), 'utf8')).sym;
const KMAX = SYM.E_KMAX, KCAP = SYM.E_KCAP, MAXPLY = SYM.E_MAXPLY;   // (equates: h.a would add the load address)
const kpush = h.a('e_kpush'), knA = h.a('e_kn');
let peak = 0, peakRoot = 0, bad = 0;
h.m.dbg.setTrace((pc) => { if (pc === kpush) { const k = h.m.peek(knA) + 1; if (k > peak) peak = k; } });
const fail = (m) => { bad++; console.log('FAIL', m); };
let statuses = 0;
// the game's status as the engine defines it (as t_api.js)
function jsStatus(e) {
  const n = legalMoves(e).length;
  if (n === 0) return e.inCheck() ? 1 : 2;
  if (e.half >= 100) return 3;
  let c = 0;
  for (let i = e.keys.length - 2; i >= Math.max(0, e.keys.length - e.half); i -= 2) if ((e.keys[i] >>> 8) === (e.key >>> 8)) c++;
  if (c >= 2) return 4;
  if (e.insufficient()) return 5;
  return 0;
}
let rng = 777;
const rnd = (n) => { rng = (rng * 1103515245 + 12345) & 0x7fffffff; return rng % n; };
const FENS = ['4k3/8/8/8/8/8/8/R3K2R w - - 0 1', '2r1k3/8/8/8/8/8/8/1Q2K3 w - - 0 1', 'r3k3/1q6/8/8/8/8/6Q1/R3K3 w - - 0 1',
  '4k3/2n5/8/3b4/8/2B5/8/R3K3 w - - 0 1', 'r1b1k2r/8/8/8/8/8/8/R1B1K2R w - - 0 1', '3qk3/8/8/8/8/8/8/3QK3 w - - 0 1'];
for (let g = 0; g < GAMES; g++) {
  const fen = FENS[g % FENS.length];
  h.setFen(fen);
  const e = new Engine(); e.setFen(fen); e.ply = 0;
  const target = 95 + rnd(30);                     // reversible plies to play (some past 100)
  for (let ply = 0; ply < target; ply++) {
    // a reversible move (no capture, no pawn) when there is one
    const lm = legalMoves(e).filter(([f, t]) => !e.b[t & 0x77] && (e.b[f] & 7) !== 1);
    if (!lm.length) break;
    const [f, t] = lm[rnd(lm.length)];
    h.call('eng_play', f, t);
    e.make(f, t); e.ply = 0;
    if (e.half === 0) e.keys.length = 0;
    const st = h.call('eng_status').a, js = jsStatus(e);
    statuses++;
    if (st !== js) fail(`game ${g} ply ${ply}: status ${st}, the reference ${js} (half ${e.half})`);
    const kn = h.peek('e_kn');
    if (kn > peakRoot) peakRoot = kn;
    if (kn >= KCAP) fail(`game ${g} ply ${ply}: e_kn ${kn} after eng_play (cap ${KCAP})`);
  }
  // deep searches from here (the game's history as it stands)
  h.m.write(h.a('e_nlim'), [0, 0x4E, 0x20]);      // 20,000 nodes
  h.pokew('e_tlim', 0); h.poke('e_maxd', 0); h.pokew('e_margin', 0);
  h.call('e_clrtt');
  h.call('eng_think', 0, 0, 921600 * 3600);
}
console.log(`${statuses} statuses compared with the reference; peak e_kn after eng_play ${peakRoot} (cap ${KCAP}), peak during searches ${peak}; E_KMAX ${KMAX} (bound ${KCAP - 1} + ${MAXPLY - 1} = ${KCAP + MAXPLY - 2})`);
if (peak > KMAX) fail(`the history went past E_KMAX: ${peak}`);
if (bad) { console.log(bad + ' FAILED'); process.exit(1); }
console.log('key history ok');
