#!/usr/bin/env python3
"""KPK (King+Pawn vs King) win/draw bitbase for the Psion chess program.

Commands:
  python kpk.py generate          retrograde-solve KPK and write ../../data/kpk.bin
  python kpk.py selftest          sanity + textbook checks against the written table
  python kpk.py stats             win counts by side to move
  python kpk.py dumprandom N SEED random probe cases (used by probe.js test)

Table format (24,576 bytes):
  Normalised so the pawn is White's and on files a-d (mirror file -> 7-file).
  sq = rank*8 + file (a1 = 0, h8 = 63).
  pawnIdx = (pawnRank-1)*4 + pawnFile   (pawnRank = 0-based rank 1..6)
  slice   = side*24 + pawnIdx           (side 0 = White/pawn side to move, 1 = Black)
  byte    = slice*512 + wk*8 + (bk >> 3), bit = 1 << (bk & 7)
  bit 1 = White (pawn side) wins; 0 = draw or illegal position.

Method: exact least-fixpoint retrograde over all positions of the normalised
pawn files. A promotion (to Q or R) is scored a win iff, after the promoting
move, Black is checkmated, or Black has a legal move and none of its legal moves
captures the new piece. (Every legal KQK/KRK position with White to move is a
win; this, and hence the rule, is verified exhaustively by kpk_indep.js, which
solves KQK and KRK fully and uses those tables instead of the rule.)
Under-promotion to B/N never wins (KBK/KNK are dead draws).
"""
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BIN = os.path.normpath(os.path.join(HERE, '..', '..', 'data', 'kpk.bin'))
SIZE = 24576

# ---------------------------------------------------------------- geometry
KN = [[] for _ in range(64)]          # king neighbours
for s in range(64):
    f, r = s & 7, s >> 3
    for df in (-1, 0, 1):
        for dr in (-1, 0, 1):
            if df or dr:
                ff, rr = f + df, r + dr
                if 0 <= ff < 8 and 0 <= rr < 8:
                    KN[s].append(rr * 8 + ff)
KADJ = [set(n) for n in KN]


def wpawn_attacks(p):
    f, r = p & 7, p >> 3
    out = []
    if r < 7:
        if f > 0:
            out.append(p + 7)
        if f < 7:
            out.append(p + 9)
    return out


WPA = [set(wpawn_attacks(p)) for p in range(64)]

ROOK_DIRS = ((1, 0), (-1, 0), (0, 1), (0, -1))
QUEEN_DIRS = ROOK_DIRS + ((1, 1), (1, -1), (-1, 1), (-1, -1))


def slider_attacks(sq, dirs, blockers):
    out = set()
    f0, r0 = sq & 7, sq >> 3
    for df, dr in dirs:
        f, r = f0 + df, r0 + dr
        while 0 <= f < 8 and 0 <= r < 8:
            t = r * 8 + f
            out.add(t)
            if t in blockers:
                break
            f += df
            r += dr
    return out


def promo_wins(q, wk, bk, dirs):
    """White has just promoted on q (rank 8); Black to move. Exact result
    given that KQK/KRK with White to move is always won."""
    # The black king does not block its own escape along a line (x-ray).
    att = slider_attacks(q, dirs, {wk})
    in_check = bk in att
    has_move = False
    for t in KN[bk]:
        if t in KADJ[wk] or t == wk:
            continue
        if t == q:
            return False                # captures the undefended new piece
        if t in att:
            continue
        has_move = True
    if has_move:
        return True
    return in_check                     # mate = win, stalemate = draw


# ---------------------------------------------------------------- legality
def legal(side, wp, wk, bk):
    r = wp >> 3
    if r < 1 or r > 6:
        return False
    if wk == bk or wk == wp or bk == wp:
        return False
    if bk in KADJ[wk]:
        return False
    if side == 0 and bk in WPA[wp]:     # Black (not to move) in check
        return False
    return True


def IDX(side, wp, wk, bk):
    return (side << 18) | (wp << 12) | (wk << 6) | bk


def pawn_squares():
    for r in range(1, 7):
        for f in range(4):
            yield r * 8 + f


# ---------------------------------------------------------------- solve
def solve():
    win = bytearray(1 << 19)
    wtm = []    # (idx, successors) undecided white-to-move
    btm = []    # (idx, successors) undecided black-to-move
    for wp in pawn_squares():
        for wk in range(64):
            for bk in range(64):
                # White to move
                if legal(0, wp, wk, bk):
                    i = IDX(0, wp, wk, bk)
                    succ = []
                    imm = False
                    for t in KN[wk]:
                        if t == wp or t in KADJ[bk]:
                            continue
                        succ.append(IDX(1, wp, t, bk))
                    s1 = wp + 8
                    if s1 != wk and s1 != bk:
                        if s1 >> 3 == 7:
                            if promo_wins(s1, wk, bk, QUEEN_DIRS) or \
                               promo_wins(s1, wk, bk, ROOK_DIRS):
                                imm = True
                        else:
                            succ.append(IDX(1, s1, wk, bk))
                            s2 = wp + 16
                            if wp >> 3 == 1 and s2 != wk and s2 != bk:
                                succ.append(IDX(1, s2, wk, bk))
                    if imm:
                        win[i] = 1
                    elif succ:
                        wtm.append((i, succ))
                    # else stalemate: draw
                # Black to move
                if legal(1, wp, wk, bk):
                    i = IDX(1, wp, wk, bk)
                    succ = []
                    can_take = False
                    for t in KN[bk]:
                        if t in KADJ[wk] or t in WPA[wp]:
                            continue
                        if t == wp:
                            can_take = True
                            break
                        succ.append(IDX(0, wp, wk, t))
                    if can_take:
                        continue                         # draw
                    if not succ:
                        if bk in WPA[wp]:
                            win[i] = 1                   # checkmate
                        continue                         # stalemate
                    btm.append((i, succ))
    passes = 0
    changed = True
    while changed:
        changed = False
        passes += 1
        nw = []
        for i, succ in wtm:
            for s in succ:
                if win[s]:
                    win[i] = 1
                    changed = True
                    break
            else:
                nw.append((i, succ))
        wtm = nw
        nb = []
        for i, succ in btm:
            for s in succ:
                if not win[s]:
                    nb.append((i, succ))
                    break
            else:
                win[i] = 1
                changed = True
        btm = nb
    return win, passes


def pack(win):
    out = bytearray(SIZE)
    for side in (0, 1):
        for pidx in range(24):
            wp = (pidx // 4 + 1) * 8 + (pidx % 4)
            base = (side * 24 + pidx) * 512
            for wk in range(64):
                for bk in range(64):
                    if win[IDX(side, wp, wk, bk)]:
                        out[base + wk * 8 + (bk >> 3)] |= 1 << (bk & 7)
    return out


# ---------------------------------------------------------------- probe
_TABLE = None


def load(path=BIN):
    global _TABLE
    with open(path, 'rb') as fh:
        data = fh.read()
    if len(data) != SIZE:
        raise ValueError('kpk.bin has %d bytes, expected %d' % (len(data), SIZE))
    _TABLE = data
    return data


def probe(wk, bk, wp, side_to_move, pawn_colour, table=None):
    """Return 1 if the side owning the pawn wins with best play, else 0
    (draw, or illegal/impossible position, or pawn on a back rank).

    wk, bk: white / black king squares; wp: pawn square (0..63, a1=0).
    side_to_move: 0 = White to move, 1 = Black to move.
    pawn_colour : 0 = White's pawn, 1 = Black's pawn.
    """
    t = table if table is not None else (_TABLE or load())
    if pawn_colour:            # flip ranks, strong side becomes "White"
        sk, wkk, p = bk ^ 56, wk ^ 56, wp ^ 56
        stm = side_to_move ^ 1
    else:
        sk, wkk, p = wk, bk, wp
        stm = side_to_move
    if p & 7 >= 4:             # mirror files so the pawn is on a-d
        sk ^= 7
        wkk ^= 7
        p ^= 7
    r = p >> 3
    if r < 1 or r > 6:
        return 0
    sl = stm * 24 + (r - 1) * 4 + (p & 7)
    return (t[sl * 512 + sk * 8 + (wkk >> 3)] >> (wkk & 7)) & 1


# ---------------------------------------------------------------- helpers
def sqn(name):
    return (int(name[1]) - 1) * 8 + (ord(name[0]) - 97)


def stats(table):
    res = {}
    for side in (0, 1):
        legal_n = wins = 0
        for wp in pawn_squares():
            for wk in range(64):
                for bk in range(64):
                    if legal(side, wp, wk, bk):
                        legal_n += 1
                        wins += probe(wk, bk, wp, side, 0, table)
        res[side] = (legal_n, wins)
    return res


def textbook_cases():
    """Return explicit textbook cases with verified expectations."""
    c = []
    A = c.append
    A(('key squares: W Kd6 Pd4 / B Kd8, White to move', 'd6', 'd8', 'd4', 0, 0, 1))
    A(('key squares: W Kd6 Pd4 / B Kd8, Black to move', 'd6', 'd8', 'd4', 0, 1, 1))
    A(('key squares: W Kc6 Pd4 / B Kd8 (c6 is a key square), WTM', 'c6', 'd8', 'd4', 0, 0, 1))
    A(('opposition: W Kd5 Pd4 / B Kd7, White to move = draw', 'd5', 'd7', 'd4', 0, 0, 0))
    A(('opposition: W Kd5 Pd4 / B Kd7, Black to move = win', 'd5', 'd7', 'd4', 0, 1, 1))
    A(('W Ke6 Pe5 / B Ke8, White to move (king on 6th in front)', 'e6', 'e8', 'e5', 0, 0, 1))
    A(('W Ke6 Pe5 / B Ke8, Black to move', 'e6', 'e8', 'e5', 0, 1, 1))
    A(('W Ke5 Pe4 / B Ke7, WTM = draw (Black has the opposition)', 'e5', 'e7', 'e4', 0, 0, 0))
    A(('W Ke5 Pe4 / B Ke7, BTM = win', 'e5', 'e7', 'e4', 0, 1, 1))
    A(('W Ke6 Pd6 / B Kd8, WTM = win (Ke7 / d7)', 'e6', 'd8', 'd6', 0, 0, 1))
    A(('W Kd5 Pd6 / B Kd7 (king in front of 6th-rank pawn), BTM = draw', 'd5', 'd7', 'd6', 0, 1, 0))
    A(('W Ke6 Pd6 / B Kd8, BTM = draw (...Ke8! takes the opposition)', 'e6', 'd8', 'd6', 0, 1, 0))
    A(('7th rank supported: W Kc7 Pd7 / B Ke7, WTM', 'c7', 'e7', 'd7', 0, 0, 1))
    A(('7th rank supported: W Kc7 Pd7 / B Ke7, BTM', 'c7', 'e7', 'd7', 0, 1, 1))
    A(('7th rank blockaded, W king far: W Ka1 Pd7 / B Kd8, WTM', 'a1', 'd8', 'd7', 0, 0, 0))
    A(('rook pawn, B king in corner: W Kb5 Pa4 / B Ka8, WTM', 'b5', 'a8', 'a4', 0, 0, 0))
    A(('rook pawn, B king in corner: W Kb5 Pa4 / B Ka8, BTM', 'b5', 'a8', 'a4', 0, 1, 0))
    A(('rook pawn, W king shut in: W Ka8 Pa7 / B Kc7, WTM (stalemate)', 'a8', 'c7', 'a7', 0, 0, 0))
    A(('rook pawn, W king shut in: W Ka8 Pa7 / B Kc8, BTM', 'a8', 'c8', 'a7', 0, 1, 0))
    A(('rook pawn, W king on b7 controls a8: W Kb7 Pa5 / B Kd7, BTM', 'b7', 'd7', 'a5', 0, 1, 1))
    A(('square rule: W Kh1 Pa4 / B Kf4, WTM (a5 escapes the square)', 'h1', 'f4', 'a4', 0, 0, 1))
    A(('square rule: W Kh1 Pa4 / B Kf4, BTM (Ke5 enters the square)', 'h1', 'f4', 'a4', 0, 1, 0))
    A(('square rule, double step: W Kh1 Pb2 / B Kh5, WTM = win (b4!, b3 draws)', 'h1', 'h5', 'b2', 0, 0, 1))
    A(('square rule, double step: W Kh1 Pb2 / B Kf5, WTM = draw (inside b4 square)', 'h1', 'f5', 'b2', 0, 0, 0))
    A(('black takes the pawn: W Ka1 Pe4 / B Kd5, BTM', 'a1', 'd5', 'e4', 0, 1, 0))
    A(('W Kb6 Pc7 / B Kc8, WTM = draw (Kc6 stalemates, else ...Kxc7)', 'b6', 'c8', 'c7', 0, 0, 0))
    A(('W Kb6 Pc7 / B Kc8, BTM = win (...Kd7 Kb7)', 'b6', 'c8', 'c7', 0, 1, 1))
    A(('under-promotion: W Ka4 Pb7 / B Ka6, WTM = win only by b8=R (b8=Q stalemate)', 'a4', 'a6', 'b7', 0, 0, 1))
    A(('under-promotion: W Ka5 Pc7 / B Ka7, WTM = win only by c8=R', 'a5', 'a7', 'c7', 0, 0, 1))
    A(('black-pawn sample: B Kd4 Pd5(black) / W Kd2, BTM = draw (W has opposition)', 'd2', 'd4', 'd5', 1, 1, 0))
    return c


def selftest():
    t = load()
    ok = True
    print('kpk.bin: %s (%d bytes)' % (BIN, len(t)))
    st = stats(t)
    for side in (0, 1):
        n, w = st[side]
        print('  %s to move: %d legal (pawn files a-d), %d wins (%.3f%%), %d draws'
              % ('White' if side == 0 else 'Black', n, w, 100.0 * w / n, n - w))
    # textbook positions, in all four symmetric guises
    fails = 0
    for desc, a, b, p, col, stm, exp in textbook_cases():
        wk, bk, wp = sqn(a), sqn(b), sqn(p)
        guises = [
            (wk, bk, wp, stm, 0),                                  # as given
            (wk ^ 7, bk ^ 7, wp ^ 7, stm, 0),                      # mirrored files
            (bk ^ 56, wk ^ 56, wp ^ 56, stm ^ 1, 1),               # colours swapped
            (bk ^ 63, wk ^ 63, wp ^ 63, stm ^ 1, 1),               # both
        ]
        vals = [probe(*g, table=t) for g in guises]
        good = all(v == exp for v in vals)
        fails += not good
        print('  [%s] %-80s -> %s (expect %s)' % ('ok' if good else 'FAIL', desc,
              'win' if vals[0] else 'draw', 'win' if exp else 'draw'))
        if not good:
            print('        guises gave', vals)
    # illegal positions must read 0
    bad = 0
    for side in (0, 1):
        for wp in pawn_squares():
            for wk in range(64):
                for bk in range(64):
                    if not legal(side, wp, wk, bk) and probe(wk, bk, wp, side, 0, t):
                        bad += 1
    print('  illegal positions with bit set: %d' % bad)
    ok = ok and fails == 0 and bad == 0
    print('SELFTEST', 'PASSED' if ok else 'FAILED')
    return ok


def dumprandom(n, seed):
    rnd = random.Random(seed)
    out = sys.stdout
    t = load()
    lines = []
    for _ in range(n):
        while True:
            wk, bk = rnd.randrange(64), rnd.randrange(64)
            if rnd.random() < 0.97:
                wp = rnd.randrange(8, 56)
            else:
                wp = rnd.randrange(64)      # includes back-rank pawns -> 0
            if rnd.random() < 0.02 or len({wk, bk, wp}) == 3:
                break
        stm, col = rnd.randrange(2), rnd.randrange(2)
        lines.append('%d %d %d %d %d %d' % (wk, bk, wp, stm, col,
                                            probe(wk, bk, wp, stm, col, t)))
    out.write('\n'.join(lines) + '\n')


def main(argv):
    cmd = argv[1] if len(argv) > 1 else 'help'
    if cmd == 'generate':
        win, passes = solve()
        data = pack(win)
        os.makedirs(os.path.dirname(BIN), exist_ok=True)
        with open(BIN, 'wb') as fh:
            fh.write(data)
        print('wrote %s (%d bytes) after %d passes' % (BIN, len(data), passes))
        for side, (n, w) in stats(data).items():
            print('  side %d: legal %d wins %d (%.3f%%)' % (side, n, w, 100.0 * w / n))
    elif cmd == 'selftest':
        sys.exit(0 if selftest() else 1)
    elif cmd == 'stats':
        for side, (n, w) in stats(load()).items():
            print('side %d: legal %d wins %d draws %d (%.3f%% wins)' % (side, n, w, n - w, 100.0 * w / n))
    elif cmd == 'dumprandom':
        dumprandom(int(argv[2]), int(argv[3]) if len(argv) > 3 else 1)
    elif cmd == 'probe':
        # probe <wk> <bk> <wp> <stm w|b> <pawn colour w|b>, squares in algebraic
        wk, bk, wp = sqn(argv[2]), sqn(argv[3]), sqn(argv[4])
        stm = 0 if argv[5] == 'w' else 1
        col = 0 if argv[6] == 'w' else 1
        print('win' if probe(wk, bk, wp, stm, col) else 'draw')
    else:
        print(__doc__)


if __name__ == '__main__':
    main(sys.argv)
