'use strict';
// eng_think against the JS think() at fixed node limits: same move, score, depth and node count.
// Usage: node t_search.js [nodes] [margin]
const { Harness } = require('./harness.js');
const { Engine, uciStr } = require('../../ref/search.js');

const NODES = +(process.argv[2] || 1500);
const MARGIN = +(process.argv[3] || 0);
const h = new Harness();
const e = new Engine();
e.ttInit(8);                                   // 256 entries, as the harness
const FENS = [
  'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
  'r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3',
  'r1bqkb1r/pppp1ppp/2n2n2/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4',
  '6k1/5ppp/8/8/8/8/5PPP/3R2K1 w - - 0 1',
  'r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1',
  '8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1',
  'r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1',
  'r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10',
  '8/8/8/4k3/8/8/8/R3K3 w - - 0 1',
  '8/8/2k5/8/8/8/8/1BN1K3 w - - 0 1',
  '4k3/8/8/3P4/8/8/8/4K3 w - - 0 1',
  '2r3k1/pp3ppp/8/3q4/8/1B6/PP3PPP/3Q2K1 b - - 0 1',
  'r1b1k2r/ppppnppp/2n2q2/2b5/3NP3/2P1B3/PP3PPP/RN1QKB1R w KQkq - 0 1',
  '6k1/pp4pp/2p5/8/8/2P5/PP4PP/6K1 w - - 0 1',
  'k7/8/1K6/8/8/8/8/7Q w - - 0 1',
  '8/k7/8/1K6/8/8/8/7R w - - 0 1',
];
let bad = 0, cyc = 0, nodes = 0;
for (const fen of FENS) {
  h.setFen(fen); e.setFen(fen);
  h.call('e_clrtt'); e.ttInit(8);
  h.pokew('e_rnd', 0x1234); e.rnd = 0x1234;
  h.m.write(h.a('e_nlim'), [(NODES >> 16) & 255, (NODES >> 8) & 255, NODES & 255]);
  h.pokew('e_tlim', 0); h.poke('e_maxd', 0); h.pokew('e_margin', MARGIN);
  const r = h.call('eng_think', 0, 0, 921600 * 3600);
  const af = h.peek('e_bestf'), at = h.peek('e_bestt'), as = h.sw('e_score'), ad = h.peek('e_depth');
  const nb = h.bytes('e_nodes', 3), an = (nb[0] << 16) | (nb[1] << 8) | nb[2];
  const j = e.think(NODES, 40, MARGIN);
  const ok = j && af === j.f && at === j.t && as === j.score && ad === j.depth && an === j.nodes;
  if (!ok) bad++;
  cyc += r.cycles; nodes += an;
  console.log(`${ok ? 'ok  ' : 'FAIL'} asm ${uciStr(e, af, at)} ${as} d${ad} n${an} | js ${j ? uciStr(e, j.f, j.t) + ' ' + j.score + ' d' + j.depth + ' n' + j.nodes : 'none'} | ${(r.cycles / 921600).toFixed(1)}s ${Math.round(an / (r.cycles / 921600))} nodes/s  ${fen.slice(0, 28)}`);
}
console.log(`average ${Math.round(nodes / (cyc / 921600))} nodes a second at 0.92 MHz`);
console.log(bad ? `${bad} FAILED` : 'search matches');
process.exit(bad ? 1 : 0);
