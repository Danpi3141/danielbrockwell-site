// Re-index a solved raw table into the symmetry-reduced layout used for compression,
// one array per side to move, with a "freedom" code per entry:
//   kind 0 exact; 1 illegal; 2 symmetric duplicate (wk on a1-d4 diagonal, bk above it);
//   3 side to move has a cheap capture (result <= 3 men) that wins -> any value allowed;
//   4 cheap capture that draws and the position is a draw -> any value <= draw allowed.
// Symbols: WDL tables: 0 draw, 1 win, 2 loss (side to move).  DTM table (KBNvK):
//   the raw value byte (0 draw, else plies to mate + 1; odd plies = win).
//   node norm.js KEY      writes <EGTB_DIR>/norm_KEY_{w,b}.{sym,kind} and checks symmetry
'use strict';
const fs = require('fs'), path = require('path');
const L = require('./lib');
const S = require('./solve');

const TRI = [0, 1, 2, 3, 9, 10, 11, 18, 19, 27];   // a1 b1 c1 d1 b2 c2 d2 c3 d3 d4
const SPECS = {
  KRvKB: { type: 'pawnless', names: ['WK', 'BK', 'R', 'B'] },
  KRvKN: { type: 'pawnless', names: ['WK', 'BK', 'R', 'N'] },
  KBNvK: { type: 'pawnless', names: ['WK', 'BK', 'B', 'N'], dtm: true },
  KQvKR: { type: 'pawnless', names: ['WK', 'BK', 'Q', 'R'] },
  KRvKP: { type: 'bpawn', names: ['P', 'WK', 'BK', 'R'] },
  KQvKP: { type: 'bpawn', names: ['P', 'WK', 'BK', 'Q'] },
  KPvKP: { type: 'pp', names: ['WP', 'BP', 'WK', 'BK'] },
};
// canonical dimension sizes and the raw squares [WK, BK, piece2, piece3] of an entry
function layout(spec) {
  if (spec.type === 'pawnless') return { dims: [10, 64, 64, 64],
    squares: (d) => [TRI[d[0]], d[1], d[2], d[3]],
    dup: (d) => { const w = TRI[d[0]]; return (w & 7) === (w >> 3) && (d[1] >> 3) > (d[1] & 7); } };
  if (spec.type === 'bpawn') return { dims: [24, 64, 64, 64],
    squares: (d) => [d[1], d[2], d[3], (1 + (d[0] >> 2)) * 8 + (d[0] & 3)], dup: () => false };
  return { dims: [24, 48, 64, 64],
    squares: (d) => [d[2], d[3], (1 + (d[0] >> 2)) * 8 + (d[0] & 3), 8 + d[1]], dup: () => false };
}

function wdl(v) { if (v === 0) return 0; return ((v - 1) & 1) ? 1 : 2; }

function build(key) {
  const spec = SPECS[key];
  const T = L.loadTable(key);
  const ctx = S.makeCtx(key);
  const lay = layout(spec);
  const n = lay.dims.reduce((a, b) => a * b, 1);
  const out = [];
  const counts = [];
  for (let stm = 0; stm < 2; stm++) {
    const sym = new Uint8Array(n), kind = new Uint8Array(n);
    const c = [0, 0, 0, 0, 0];
    const d = [0, 0, 0, 0];
    for (let i = 0; i < n; i++) {
      let r = i;
      for (let k = 3; k >= 0; k--) { d[k] = r % lay.dims[k]; r = Math.floor(r / lay.dims[k]); }
      const sq = lay.squares(d);
      let idx = stm; for (const s of sq) idx = idx * 64 + s;
      const v = T.val[idx];
      if (v === 255) { kind[i] = 1; c[1]++; continue; }
      if (lay.dup(d)) { kind[i] = 2; c[2]++; sym[i] = spec.dtm ? v : wdl(v); continue; }
      sym[i] = spec.dtm ? v : wdl(v);
      // best cheap capture (exit to <= 3 men)
      S.decode(ctx, idx); S.setOcc(ctx);
      let best = -100000;
      S.genMoves(ctx, idx, stm, (k2, a, men) => {
        if (k2 === 1 && men <= 3) { const s = L.backScore(a); if (s > best) best = s; }
      });
      if (best === -100000) { c[0]++; continue; }
      const cw = best > 0 ? 1 : best === 0 ? 0 : 2, vw = wdl(v);
      if (cw === 1 && vw === 1 && !spec.dtm) { kind[i] = 3; c[3]++; }
      else if (cw === 0 && vw === 0) { kind[i] = 4; c[4]++; }
      else c[0]++;
    }
    out.push({ sym, kind });
    counts.push(c);
  }
  return { spec, lay, n, out, counts };
}

// symmetry check on the raw table
function symCheck(key) {
  const spec = SPECS[key], T = L.loadTable(key);
  const maps = [];
  if (spec.type === 'pawnless') {
    for (let m = 1; m < 8; m++) maps.push(s => {
      let f = s & 7, r = s >> 3;
      if (m & 1) f ^= 7; if (m & 2) r ^= 7; if (m & 4) { const t = f; f = r; r = t; }
      return r * 8 + f;
    });
  } else maps.push(s => s ^ 7);
  let bad = 0, n = 0;
  for (let i = 0; i < T.val.length; i++) {
    const v = T.val[i];
    const stm = i >> 24, sq = [(i >> 18) & 63, (i >> 12) & 63, (i >> 6) & 63, i & 63];
    for (const f of maps) {
      const j = (((stm * 64 + f(sq[0])) * 64 + f(sq[1])) * 64 + f(sq[2])) * 64 + f(sq[3]);
      n++; if (T.val[j] !== v) bad++;
    }
  }
  return { compared: n, mismatches: bad };
}

if (require.main === module) {
  const key = process.argv[2];
  const t0 = Date.now();
  const sc = symCheck(key);
  const r = build(key);
  for (let stm = 0; stm < 2; stm++) {
    const base = path.join(L.DATA_DIR, `norm_${key}_${stm ? 'b' : 'w'}`);
    fs.writeFileSync(base + '.sym', r.out[stm].sym);
    fs.writeFileSync(base + '.kind', r.out[stm].kind);
  }
  const info = { key, dims: r.lay.dims, names: r.spec.names, n: r.n, symmetry: sc,
    kinds: { exact_illegal_dup_capWin_capDraw: r.counts }, secs: (Date.now() - t0) / 1000 };
  console.log(JSON.stringify(info));
  const sf = path.join(L.DATA_DIR, 'norm.json');
  let all = {}; try { all = JSON.parse(fs.readFileSync(sf, 'utf8')); } catch (e) {}
  all[key] = info; fs.writeFileSync(sf, JSON.stringify(all, null, 1), 'utf8');
}
module.exports = { SPECS, layout, TRI };
