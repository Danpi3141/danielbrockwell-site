'use strict';
// Perft on the assembler engine against the known totals, and the incremental state
// (totals, counts, masks, key) against the JS reference after setup.
const { Harness } = require('./harness.js');
const { Engine } = require('../../ref/search.js');
const { CASES } = require('../../ref/perft.js');

const h = new Harness();
console.log('image', h.size, 'bytes');
const maxD = +(process.argv[2] || 3);
let bad = 0;
const e = new Engine();
for (const [fen, counts] of CASES) {
  const r = h.setFen(fen);
  if (r.c) { console.log('setup refused', fen, r.a); bad++; continue; }
  e.setFen(fen);
  // derived state matches
  const st = {
    mg: [h.sw('e_mg'), h.sw('e_mg', 2)], eg: [h.sw('e_eg'), h.sw('e_eg', 2)], ph: h.peek('e_phase'), key: h.key(),
  };
  if (st.mg[0] !== e.mg[0] || st.mg[1] !== e.mg[1] || st.eg[0] !== e.eg[0] || st.eg[1] !== e.eg[1] || st.ph !== e.phase || st.key !== e.key) {
    console.log('STATE MISMATCH', fen, st, { mg: e.mg, eg: e.eg, ph: e.phase, key: e.key });
    bad++;
  }
  for (let d = 1; d <= Math.min(maxD, counts.length); d++) {
    const p = h.perft(d);
    const ok = p.n === counts[d - 1];
    if (!ok) bad++;
    console.log(`${ok ? 'ok  ' : 'FAIL'} d${d} ${p.n} (want ${counts[d - 1]}) ${(p.cycles / 921600).toFixed(1)}s emulated, ${Math.round(p.cycles / p.n)} cycles/leaf, sp ${p.sp.toString(16)}  ${fen.slice(0, 24)}`);
    // state restored after the walk
    const k2 = h.key();
    if (k2 !== e.key || h.sw('e_mg') !== e.mg[0] || h.peek('e_phase') !== e.phase) { console.log('  state not restored after perft'); bad++; }
  }
}
console.log(bad ? `${bad} FAILED` : 'all assembler perft counts match');
process.exit(bad ? 1 : 0);
