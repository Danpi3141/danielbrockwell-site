'use strict';
// Runs the assembled engine (tests/engine/out/etest.bin) on the emulated HD6303 of a booted LZ64
// and exposes its routines to tests. The image is placed at BASE with its fix-ups applied.
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const { Machine } = require('../../tools/emu.js');

const BASE = 0x3000, TRAMP = 0x6FE0, SENT = TRAMP + 3, TT = 0x7000, TT_N = 256;

function build() {
  execSync('python "' + path.join(__dirname, 'build_test.py') + '"', { stdio: 'pipe' });
}

class Harness {
  constructor(opts = {}) {
    if (opts.build !== false) build();
    const out = path.join(__dirname, 'out');
    const img = fs.readFileSync(path.join(out, 'etest.bin'));
    const meta = JSON.parse(fs.readFileSync(path.join(out, 'etest.json'), 'utf8'));
    this.sym = {};
    const abs = new Set(meta.abs);             // (the engine's zero-page variables)
    for (const [k, v] of Object.entries(meta.sym)) this.sym[k] = abs.has(k) ? v : v + BASE;
    const bytes = Uint8Array.from(img);
    for (const f of meta.fix) {
      const v = ((bytes[f] << 8) | bytes[f + 1]) + BASE;
      bytes[f] = (v >> 8) & 255; bytes[f + 1] = v & 255;
    }
    this.size = bytes.length;
    if (BASE + this.size > TRAMP) throw new Error('test image too big: ' + this.size);
    const m = this.m = new Machine();
    m.boot();
    this.stack = m.dbg.sp() - 8;               // below the OS's own stack pointer at the menu
    m.write(BASE, Array.from(bytes));
    for (const [z, n] of [[0x4D, 14], [0xCC, 42], [0x7F, 12]]) m.write(z, new Array(n).fill(0));      // ZP1..ZP3, as kinit clears them
    // trampoline: sei (or cli), jsr 0,x, then the sentinel 'nop; bra *'
    m.write(TRAMP, [0x0F, 0xAD, 0x00, 0x01, 0x20, 0xFE]);
    this.ints = !!opts.ints;
    this.trace = !!(opts.trace || process.env.ETRACE);
    this.ttN = opts.ttN || TT_N;
    this.pokew('e_tt', TT); this.pokew('e_ttn', this.ttN);
    this.call('eng_init');
  }
  a(name) { const v = this.sym[name]; if (v === undefined) throw new Error('no symbol ' + name); return v; }
  peek(name, off = 0) { return this.m.peek(this.a(name) + off); }
  peekw(name, off = 0) { return this.m.peekw(this.a(name) + off); }
  poke(name, v, off = 0) { this.m.poke(this.a(name) + off, v); }
  pokew(name, v, off = 0) { this.m.pokew(this.a(name) + off, v); }
  bytes(name, n, off = 0) { return this.m.read(this.a(name) + off, n); }

  // call a routine: returns {a, b, x, c, cycles}
  call(name, a = 0, b = 0, maxCycles = 921600 * 600) {
    const m = this.m, d = m.dbg;
    m.poke(0x7D, 255);                         // keep auto switch-off away
    m.poke(TRAMP, this.ints ? 0x0E : 0x0F);
    d.setSP(this.stack);
    d.setA(a); d.setB(b);
    d.setX(typeof name === 'number' ? name : this.a(name));
    d.setPC(TRAMP);
    d.wake();
    const c0 = m.cycles();
    let ring = null;
    if (this.trace) { ring = []; d.setTrace(pc => { ring.push(pc); if (ring.length > 80) ring.shift(); }); }
    const hit = m.runTo(SENT, maxCycles);
    if (this.trace) d.setTrace(null);
    if (hit !== SENT) {
      const tail = ring ? ' last: ' + ring.map(p => p >= BASE && p < BASE + this.size ? (p - BASE).toString(16) : '[' + p.toString(16) + ']').join(' ') : '';
      throw new Error(`${name} did not return (pc=${d.pc().toString(16)}, sp=${d.sp().toString(16)})` + tail);
    }
    const cyc = m.cycles() - c0, res = { a: d.a(), b: d.b(), x: d.x(), c: d.p() & 1, sp: d.sp() };
    this.m.cpu.execute(1);                     // step over the sentinel's nop (re-arms the breakpoint)
    res.cycles = cyc;
    return res;
    return { a: d.a(), b: d.b(), x: d.x(), c: d.p() & 1, cycles: m.cycles() - c0, sp: d.sp() };
  }

  // position from FEN
  setFen(fen) {
    const f = fen.trim().split(/\s+/);
    const board = new Array(128).fill(0);
    let r = 7, c = 0;
    for (const ch of f[0]) {
      if (ch === '/') { r--; c = 0; continue; }
      if (ch >= '1' && ch <= '8') { c += +ch; continue; }
      board[r * 16 + c] = ('pnbrqk'.indexOf(ch.toLowerCase()) + 1) | (ch === ch.toLowerCase() ? 8 : 0);
      c++;
    }
    this.m.write(this.a('e_board'), board);
    this.poke('e_side', f[1] === 'b' ? 8 : 0);
    let cs = 0; const s = f[2] || '-';
    if (s.includes('K')) cs |= 1; if (s.includes('Q')) cs |= 2; if (s.includes('k')) cs |= 4; if (s.includes('q')) cs |= 8;
    this.poke('e_castle', cs);
    this.poke('e_ep', f[3] && f[3] !== '-' ? (f[3].charCodeAt(1) - 49) * 16 + (f[3].charCodeAt(0) - 97) : 0xFF);
    this.poke('e_half', +(f[4] || 0));
    return this.call('eng_setup');
  }

  perft(depth) {
    this.m.write(this.a('pf_cnt'), [0, 0, 0, 0]);
    this.call('e_ply0');
    const r = this.call('t_perft', depth);
    const b = this.bytes('pf_cnt', 4);
    return { n: ((b[0] << 24) | (b[1] << 16) | (b[2] << 8) | b[3]) >>> 0, cycles: r.cycles, sp: r.sp };
  }

  // is A = from, B = to (promotion bits included) in eng_legal's list? (the engine's eng_find did
  // this until 17 Nov: nothing in the game called it)
  hasMove(f, t) {
    const n = this.call('eng_legal').b, lm = this.bytes('e_lm', n * 2);
    for (let i = 0; i < n; i++) if (lm[i * 2] === f && lm[i * 2 + 1] === t) return true;
    return false;
  }
  key() { const b = this.bytes('e_key', 3); return (b[0] << 16) | (b[1] << 8) | b[2]; }
  sw(name, off = 0) { const v = this.peekw(name, off); return v & 0x8000 ? v - 0x10000 : v; }
}

module.exports = { Harness, BASE, TT };
