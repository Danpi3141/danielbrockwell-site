"""Snapshot the reference engine (ref/engine.js, search.js, tables.js) into this folder so a
match series is not affected by later edits to ref/, and build a patched copy.

    python make_snap.py v1      (what was done first, 2026-11-15 23:42: snap_asis + snap_fixed)
    python make_snap.py v2      plain copy of the current ref/ into snap_v2 (ref now has the fixes)

  snap_asis/   byte-for-byte copy of ref/
  snap_fixed/  same, with the a1 sentinel bug fixed:
               search.js used 0 (= square a1 in 0x88) as "no move" for rootF and for the TT
               best move, so a best move FROM a1 was never returned by think() (-> bestmove 0000
               when every iteration picks an a1 move; otherwise the previous iteration's move)
               and never stored as the TT move.  Fix: rootF sentinel 0xFF; TT tests use (f|t).
               Also: the null-move child search ran with a stale mvTop[ply+1] (only set after gen),
               so its moves could overwrite an ancestor move list (-> crash in make()).
               Fix: mvTop[ply+1] = mvTop[ply] before makeNull().
"""
import hashlib
import os
import shutil

HERE = os.path.dirname(os.path.abspath(__file__))
REF = os.path.normpath(os.path.join(HERE, '..', '..', 'ref'))
FILES = ['engine.js', 'search.js', 'tables.js']

PATCHES = [
    ('this.rootF = 0; this.rootT = 0;', 'this.rootF = 0xFF; this.rootT = 0;'),
    ('if (this.rootF) best =', 'if (this.rootF !== 0xFF) best ='),
    ('if (bestF) { this.ttF[idx] = bestF;', 'if (bestF | bestT) { this.ttF[idx] = bestF;'),
    ('    if (ttf) {', '    if (ttf | ttt) {'),
    # null-move child searched with a stale mvTop[ply+1] (set only by gen, which comes later),
    # so its move list could overwrite an ancestor's list -> garbage moves -> crash in make()
    ('        this.makeNull();', '        this.mvTop[ply + 1] = this.mvTop[ply];\n        this.makeNull();'),
]


def copy_plain(d):
    os.makedirs(os.path.join(HERE, d), exist_ok=True)
    for f in FILES:
        shutil.copyfile(os.path.join(REF, f), os.path.join(HERE, d, f))
        h = hashlib.md5(open(os.path.join(HERE, d, f), 'rb').read()).hexdigest()
        print(d, f, h)


def main():
    import sys
    if len(sys.argv) > 1 and sys.argv[1] != 'v1':
        copy_plain('snap_' + sys.argv[1])
        return
    for d in ('snap_asis', 'snap_fixed'):
        os.makedirs(os.path.join(HERE, d), exist_ok=True)
        for f in FILES:
            shutil.copyfile(os.path.join(REF, f), os.path.join(HERE, d, f))
    p = os.path.join(HERE, 'snap_fixed', 'search.js')
    s = open(p, newline='').read()
    for a, b in PATCHES:
        assert s.count(a) == 1, a
        s = s.replace(a, b)
    open(p, 'w', newline='').write(s)
    for d in ('snap_asis', 'snap_fixed'):
        for f in FILES:
            h = hashlib.md5(open(os.path.join(HERE, d, f), 'rb').read()).hexdigest()
            print(d, f, h)


if __name__ == '__main__':
    main()
