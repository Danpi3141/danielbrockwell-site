'use strict';
// Whole games on the assembler (both sides), from the match openings, with mixed node limits and
// margins (levels 1-4 style random picks), compared with the JS reference move by move: the same
// move, score, depth and node count, and the same eng_status / eng_check every ply.
// Usage: node t_soak_asm.js [games] [seed] [maxPlies]
const fs = require('fs');
const path = require('path');
const { Harness } = require('./harness.js');
const { Engine, legalMoves, uciStr, parseUci } = require('../../ref/search.js');
const GAMES = +(process.argv[2] || 6), SEED = +(process.argv[3] || 1), MAXP = +(process.argv[4] || 160);
const ops = fs.readFileSync(path.join(__dirname, '..', '..', 'tools', 'match', 'openings.txt'), 'utf8').trim().split(/\r?\n/);
let rng = SEED * 7919 + 1;
const rnd = (k) => { rng = (Math.imul(rng, 1103515245) + 12345) & 0x7fffffff; return (rng >>> 8) % k; };

function jsStatus(e) {
  const n = legalMoves(e).length;
  if (n === 0) return e.inCheck() ? 1 : 2;
  if (e.half >= 100) return 3;
  let c = 0;
  for (let i = e.keys.length - 2; i >= Math.max(0, e.keys.length - e.half); i -= 2) if ((e.keys[i] >>> 8) === (e.key >>> 8)) c++;
  if (c >= 2) return 4;
  if (e.insufficient()) return 5;
  return 0;
}
const h = new Harness();
let bad = 0, plies = 0, cyc = 0;
const ends = {};
for (let g = 0; g < GAMES; g++) {
  const e = new Engine(); e.ttInit(8);
  h.call('eng_reset'); h.call('e_clrtt');
  const seed = 1 + rnd(65000);
  h.pokew('e_rnd', seed); e.rnd = seed;
  // per game: a node limit and a margin (0 half of the time)
  const nodes = [60, 120, 250, 400, 800][rnd(5)], margin = rnd(2) ? 0 : [30, 70, 150, 300][rnd(4)];
  const line = [];
  for (const u of ops[rnd(ops.length)].split(' ')) {
    const [f, t] = parseUci(e, u);
    h.call('eng_play', f, t); e.make(f, t); e.ply = 0; if (e.half === 0) e.keys.length = 0;
    line.push(u);
  }
  let result = 'unfinished', ply = 0;
  for (; ply < MAXP; ply++) {
    const st = h.call('eng_status').a, js = jsStatus(e);
    if (st !== js) { bad++; console.log(`FAIL game ${g} ply ${ply}: status ${st} v ${js}`); break; }
    if ((h.call('eng_check').a !== 0) !== e.inCheck()) { bad++; console.log(`FAIL game ${g} ply ${ply}: check`); break; }
    if (st) { result = ['', 'checkmate', 'stalemate', 'fifty moves', 'threefold', 'too little material'][st]; break; }
    h.m.write(h.a('e_nlim'), [(nodes >> 16) & 255, (nodes >> 8) & 255, nodes & 255]);
    h.pokew('e_tlim', 0); h.poke('e_maxd', 0); h.pokew('e_margin', margin);
    const r = h.call('eng_think', 0, 0, 921600 * 3600);
    cyc += r.cycles;
    const af = h.peek('e_bestf'), at = h.peek('e_bestt'), as = h.sw('e_score'), ad = h.peek('e_depth');
    const nb = h.bytes('e_nodes', 3), an = (nb[0] << 16) | (nb[1] << 8) | nb[2];
    const j = margin ? e.think(nodes, 40, margin) : e.think(nodes);
    if (!j || af !== j.f || at !== j.t || as !== j.score || ad !== j.depth || an !== j.nodes) {
      bad++;
      console.log(`FAIL game ${g} ply ${ply} (nodes ${nodes} margin ${margin}): asm ${uciStr(e, af, at)} ${as} d${ad} n${an} js ${j ? uciStr(e, j.f, j.t) + ' ' + j.score + ' d' + j.depth + ' n' + j.nodes : '-'}`);
      console.log('   ' + line.join(' '));
      break;
    }
    if (!legalMoves(e).some(([f, t]) => f === af && t === at)) { bad++; console.log(`FAIL game ${g}: illegal move`); break; }
    line.push(uciStr(e, af, at));
    h.call('eng_play', af, at); e.make(af, at); e.ply = 0; if (e.half === 0) e.keys.length = 0;
    plies++;
  }
  ends[result] = (ends[result] || 0) + 1;
  console.log(`game ${g}: nodes ${nodes} margin ${margin}: ${ply} plies, ${result}`);
}
console.log(`${GAMES} games, ${plies} engine moves compared, ${(cyc / 921600 / 3600).toFixed(1)} emulated hours of thinking; ends ${JSON.stringify(ends)}`);
console.log(bad ? `${bad} FAILED` : 'assembler games match the reference');
process.exit(bad ? 1 : 0);
