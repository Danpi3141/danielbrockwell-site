#!/bin/sh
# 16 Nov: 64-key Zobrist (snap_z64) and symmetric PSTs (snap_sym) v the current engine (snap_v4)
O="--openings 0:242 --workers 4"
python -E -P match.py z64_v4_2120 snap_z64:Nodes=2120 snap_v4:Nodes=2120 $O > logs_z64_2120.txt 2>&1 &
python -E -P match.py z64_v4_6000 snap_z64:Nodes=6000 snap_v4:Nodes=6000 $O > logs_z64_6000.txt 2>&1 &
python -E -P match.py sym_v4_2120 snap_sym:Nodes=2120 snap_v4:Nodes=2120 $O > logs_sym_2120.txt 2>&1 &
python -E -P match.py sym_v4_2000 snap_sym:Nodes=2000 snap_v4:Nodes=2000 $O > logs_sym_2000.txt 2>&1 &
wait
python -E -P analyze.py z64_v4_2120 z64_v4_6000 sym_v4_2120 sym_v4_2000 | grep -v histogram
