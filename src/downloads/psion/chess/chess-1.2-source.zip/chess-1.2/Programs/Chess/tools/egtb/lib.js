// Endgame-table library: geometry, material keys, generic (unsymmetrised) indexing,
// move generation and probing of solved tables.  Written for tools/egtb only.
//
// Table layout (raw, as solved):  idx = stm*64^N + sq[0]*64^(N-1) + ... + sq[N-1]
//   piece order: [White K, Black K, White non-kings in key order, Black non-kings in key order]
//   sq = rank*8 + file (a1 = 0, h8 = 63); stm 0 = White to move.
// Value byte: 255 illegal; 0 draw; otherwise p = v-1 plies to mate:
//   p odd  -> side to move wins (mates after p plies)
//   p even -> side to move loses (is mated after p plies; p = 0: already mated)
'use strict';
const fs = require('fs');
const path = require('path');

const DATA_DIR = process.env.EGTB_DIR ||
  path.join(process.env.LOCALAPPDATA || '.', 'Temp', 'egtb_raw');

const K = 0, Q = 1, R = 2, B = 3, N = 4, P = 5;
const TCH = 'KQRBNP';
const VALUE = [0, 9, 5, 3.25, 3, 1];

const F = s => s & 7, RK = s => s >> 3;
const onB = (f, r) => f >= 0 && f < 8 && r >= 0 && r < 8;

const KING_N = [], KNIGHT_N = [];
const KADJ = new Uint8Array(64 * 64), NADJ = new Uint8Array(64 * 64);
for (let s = 0; s < 64; s++) {
  const k = [], n = [];
  for (const [df, dr] of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]) {
    const f = F(s) + df, r = RK(s) + dr; if (onB(f, r)) { k.push(r * 8 + f); KADJ[s * 64 + r * 8 + f] = 1; }
  }
  for (const [df, dr] of [[1,2],[2,1],[-1,2],[-2,1],[1,-2],[2,-1],[-1,-2],[-2,-1]]) {
    const f = F(s) + df, r = RK(s) + dr; if (onB(f, r)) { n.push(r * 8 + f); NADJ[s * 64 + r * 8 + f] = 1; }
  }
  KING_N.push(k); KNIGHT_N.push(n);
}
// rays[s][d] = list of squares from s in direction d (0-3 orthogonal, 4-7 diagonal)
const DIRS = [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
const RAYS = [];
for (let s = 0; s < 64; s++) {
  const rs = [];
  for (const [df, dr] of DIRS) {
    const out = []; let f = F(s) + df, r = RK(s) + dr;
    while (onB(f, r)) { out.push(r * 8 + f); f += df; r += dr; }
    rs.push(out);
  }
  RAYS.push(rs);
}
// LINE[a*64+b]: 0 none, 1 orthogonal, 2 diagonal; STEP[a*64+b]: square delta
const LINE = new Uint8Array(4096), STEP = new Int8Array(4096);
for (let a = 0; a < 64; a++) for (let d = 0; d < 8; d++) {
  const st = DIRS[d][1] * 8 + DIRS[d][0];
  for (const b of RAYS[a][d]) { LINE[a * 64 + b] = d < 4 ? 1 : 2; STEP[a * 64 + b] = st; }
}

// ---------------------------------------------------------------- material keys
function parseKey(key) {
  const m = /^K([QRBNP]*)vK([QRBNP]*)$/.exec(key);
  if (!m) throw new Error('bad key ' + key);
  const pcs = [[0, K], [1, K]];
  for (const ch of m[1]) pcs.push([0, TCH.indexOf(ch)]);
  for (const ch of m[2]) pcs.push([1, TCH.indexOf(ch)]);
  return pcs;
}
function sortStr(types) { return types.slice().sort((a, b) => a - b).map(t => TCH[t]).join(''); }
function keyOf(wTypes, bTypes) { return 'K' + sortStr(wTypes) + 'vK' + sortStr(bTypes); }
function sideVal(types) { return types.reduce((a, t) => a + VALUE[t], 0); }
function isCanonical(wTypes, bTypes) {
  const a = sideVal(wTypes), b = sideVal(bTypes);
  if (a !== b) return a > b;
  return sortStr(wTypes) <= sortStr(bTypes);   // ties: lexicographically smaller white string
}

// ---------------------------------------------------------------- table store
const cache = new Map();
function tablePath(key) { return path.join(DATA_DIR, key + '.bin'); }
function loadTable(key) {
  if (cache.has(key)) return cache.get(key);
  const p = tablePath(key);
  if (!fs.existsSync(p)) throw new Error('table ' + key + ' not solved yet (' + p + ')');
  const buf = fs.readFileSync(p);
  const t = { key, pcs: parseKey(key), val: new Uint8Array(buf.buffer, buf.byteOffset, buf.length) };
  t.N = t.pcs.length;
  cache.set(key, t);
  return t;
}

// probe(list of [colour, type, square], stm) -> value byte (see header); KvK and
// lone minor pieces are handled by their tables (KBvK, KNvK solved too); KvK = 0.
function probe(list, stm) {
  const w = [], b = [];
  for (const [c, t] of list) if (t !== K) (c ? b : w).push(t);
  if (w.length === 0 && b.length === 0) return 0;
  let L = list, s = stm;
  if (!isCanonical(w, b)) {
    L = list.map(([c, t, q]) => [c ^ 1, t, q ^ 56]); s = stm ^ 1;
  }
  const key = isCanonical(w, b) ? keyOf(w, b) : keyOf(b, w);
  const T = loadTable(key);
  let idx = s;
  const used = new Uint8Array(L.length);
  for (const [c, t] of T.pcs) {
    let found = -1;
    for (let j = 0; j < L.length; j++) if (!used[j] && L[j][0] === c && L[j][1] === t) { found = j; break; }
    if (found < 0) throw new Error('piece missing in probe ' + key);
    used[found] = 1;
    idx = idx * 64 + L[found][2];
  }
  return T.val[idx];
}

// score from a value byte, side-to-move view: win in p -> 1000-p, loss in p -> -1000+p, draw 0
function score(v) {
  if (v === 0) return 0;
  const p = v - 1;
  return (p & 1) ? 1000 - p : -1000 + p;
}
function valOfScore(s) {
  if (s === 0) return 0;
  return s > 0 ? (1000 - s) + 1 : (s + 1000) + 1;
}
// convert successor value (opponent to move) to mover's score
function backScore(vOpp) {
  const s = score(vOpp);
  return s === 0 ? 0 : (s > 0 ? -s + 1 : -s - 1);
}

module.exports = {
  DATA_DIR, K, Q, R, B, N, P, TCH, F, RK, KING_N, KNIGHT_N, KADJ, NADJ, RAYS, LINE, STEP,
  parseKey, keyOf, isCanonical, loadTable, probe, score, valOfScore, backScore, tablePath, cache,
};
