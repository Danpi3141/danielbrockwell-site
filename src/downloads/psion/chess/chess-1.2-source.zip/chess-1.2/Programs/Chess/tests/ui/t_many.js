'use strict';
// The legal-move list kept for the screens (LM_MAX = 127): a position with 218 legal moves
// keeps 127 of them, and a move late in that list (past the old limit of 80) can be played.
//   node tests/ui/t_many.js
const L = require('./lib.js');
const G = require('./glib.js');
const { check } = L;

const m = L.start();
L.idle(m);
G.twoPlayers(m);
G.setupFen(m, 'R6R/3Q4/1Q4Q1/4Q3/2Q4Q/Q4Q2/pp1Q4/kBNN1KB1 w - - 0 1');    // 218 legal moves for White
const n = L.peekSym(m, 'lm_n')[0];
check(n === 127, '218 legal moves: the list keeps ' + n, m);
const buf = L.peekSym(m, 'lm_buf', 2 * n);
const at = 120;
const name = (q) => 'abcdefgh'[q & 7] + (((q >> 4) & 7) + 1);
const mv = name(buf[2 * at]) + name(buf[2 * at + 1] & 0x77);
G.typeUci(m, mv);
check(G.waitPly(m, 1, 20), 'move ' + (at + 1) + ' of the list (' + mv + ') is accepted', m);
console.log('all UI tests passed');
