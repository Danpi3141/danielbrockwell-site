"""Build a tactics set with Stockfish.
    python -E -P tools/audit/make_tactics.py [n_each] [workers]
Sources: 'win a piece' positions from the Lichess game cache (first 24 plies of real games, plies 8+);
mate-in-2 positions from self-play games of the low levels (tools/audit/results/lv_*.jsonl, the 2-6
plies before each mate), because mates in 2 are rare in the first 24 plies of real games.
Writes tools/audit/tactics.json: [{fen, kind: 'mate2'|'piece', ok: [uci...], best, gap, cp}]
  mate2: Stockfish finds mate in 2 (and no mate in 1); 'ok' = every move that mates in 2 or less.
  piece: one move is >= 300 cp better than every alternative and the best score is 200..2000 cp
         (wins about a piece); 'ok' = that move only.
Screening at depth 10 (MultiPV 2), confirmation at depth 18 (MultiPV 5 for mates, 2 for pieces)."""
import glob, json, os, random, sys
import multiprocessing as mp
import chess, chess.engine

HERE = os.path.dirname(os.path.abspath(__file__))
CHESS = os.path.normpath(os.path.join(HERE, '..', '..'))
SF = os.path.join(CHESS, 'ext', 'stockfish', 'stockfish', 'stockfish-windows-x86-64-universal.exe')
GAMES = os.path.join(CHESS, 'tools', 'book', 'cache', 'games.txt')
OUT = os.path.join(HERE, 'tactics.json')

_eng = None


def init():
    global _eng
    _eng = chess.engine.SimpleEngine.popen_uci(SF)
    _eng.configure({'Threads': 1, 'Hash': 16})


def cp(info):
    s = info['score'].relative
    return s.mate(), s.score()


def examine(fen):
    b = chess.Board(fen)
    if b.is_game_over():
        return None
    infos = _eng.analyse(b, chess.engine.Limit(depth=10), multipv=2)
    if len(infos) < 2:
        return None
    m1, c1 = cp(infos[0]); m2, c2 = cp(infos[1])
    kind = None
    if m1 == 2:
        kind = 'mate2'
    elif m1 is None and m2 is None and 200 <= c1 <= 2000 and c1 - c2 >= 300:
        kind = 'piece'
    if not kind:
        return None
    if kind == 'mate2':
        infos = _eng.analyse(b, chess.engine.Limit(depth=18), multipv=min(8, b.legal_moves.count()))
        m1, _ = cp(infos[0])
        if m1 != 2:
            return None
        ok = [i['pv'][0].uci() for i in infos if cp(i)[0] is not None and 0 < cp(i)[0] <= 2]
        return {'fen': fen, 'kind': kind, 'ok': ok, 'best': ok[0]}
    infos = _eng.analyse(b, chess.engine.Limit(depth=18), multipv=2)
    if len(infos) < 2:
        return None
    m1, c1 = cp(infos[0]); m2, c2 = cp(infos[1])
    if m1 is not None or m2 is not None or not (200 <= c1 <= 2000) or c1 - c2 < 300:
        return None
    best = infos[0]['pv'][0].uci()
    return {'fen': fen, 'kind': kind, 'ok': [best], 'best': best, 'gap': c1 - c2, 'cp': c1}


def positions(seed):
    rng = random.Random(seed)
    with open(GAMES, encoding='utf-8') as f:
        for line in f:
            w = line.split()
            sans = w[3:]
            if len(sans) < 12:
                continue
            b = chess.Board()
            fens = []
            try:
                for s in sans:
                    b.push_san(s)
                    if b.ply() >= 8:
                        fens.append(b.fen())
            except ValueError:
                continue
            for fen in rng.sample(fens, min(3, len(fens))):
                yield fen


def mate_positions(seed):
    rng = random.Random(seed)
    files = sorted(glob.glob(os.path.join(HERE, 'results', 'lv_*.jsonl')))
    out = []
    for p in files:
        with open(p, encoding='utf-8') as f:
            for line in f:
                g = json.loads(line)
                if g['reason'] != 'checkmate':
                    continue
                ms = g['moves'].split()
                b = chess.Board()
                fens = []
                for m in ms:
                    fens.append(b.fen())
                    b.push_uci(m)
                out.extend(fens[-6:-2])
    rng.shuffle(out)
    return out


def main():
    n_each = int(sys.argv[1]) if len(sys.argv) > 1 else 100
    workers = int(sys.argv[2]) if len(sys.argv) > 2 else 4
    found = {'mate2': [], 'piece': []}
    seen = set()
    done = 0
    with mp.Pool(workers, initializer=init) as pool:
        def gen():
            import itertools
            mates = mate_positions(7)
            lich = positions(7)
            for a, b in itertools.zip_longest(mates, lich):
                for fen in (a, b):
                    if fen is None:
                        continue
                    key = ' '.join(fen.split()[:4])
                    if key in seen:
                        continue
                    seen.add(key)
                    yield fen
        for r in pool.imap_unordered(examine, gen(), chunksize=8):
            done += 1
            if r and len(found[r['kind']]) < n_each:
                found[r['kind']].append(r)
                print(r['kind'], len(found['mate2']), len(found['piece']), done, r['fen'], r['ok'], flush=True)
            if all(len(v) >= n_each for v in found.values()):
                pool.terminate()
                break
    data = found['mate2'] + found['piece']
    with open(OUT, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=0)
    print('written', len(found['mate2']), 'mate2 and', len(found['piece']), 'piece positions after', done, 'positions examined')


if __name__ == '__main__':
    main()
