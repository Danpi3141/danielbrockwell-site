// Independent second implementation of the KPK bitbase (Node).
// Differences from kpk.py on purpose:
//   * own move generator written with (file, rank) coordinates;
//   * KQK and KRK are solved exactly by retrograde iteration, and promotions
//     look up those tables (no "promotion rule" shortcut);
//   * the pawn is solved on all 8 files (mirror symmetry is checked, not assumed).
// It then packs files a-d into the kpk.bin layout and compares byte-for-byte.
//
// Usage: node kpk_indep.js [path/to/kpk.bin]
'use strict';
const fs = require('fs');
const path = require('path');

const BIN = process.argv[2] || path.join(__dirname, '..', '..', 'data', 'kpk.bin');
const F = s => s & 7, R = s => s >> 3, SQ = (f, r) => r * 8 + f;
const onB = (f, r) => f >= 0 && f < 8 && r >= 0 && r < 8;
const dist = (a, b) => Math.max(Math.abs(F(a) - F(b)), Math.abs(R(a) - R(b)));
const KD = [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
const RD = KD.slice(0, 4), QD = KD;

function kingTargets(s) {
  const out = [];
  for (const [df, dr] of KD) { const f = F(s) + df, r = R(s) + dr; if (onB(f, r)) out.push(SQ(f, r)); }
  return out;
}
// does slider on `from` (dirs) attack `target`, with occupied squares occ (Set)?
function sliderHits(from, dirs, target, occ) {
  for (const [df, dr] of dirs) {
    let f = F(from) + df, r = R(from) + dr;
    while (onB(f, r)) {
      const s = SQ(f, r);
      if (s === target) return true;
      if (occ.has(s)) break;
      f += df; r += dr;
    }
  }
  return false;
}
function sliderMoves(from, dirs, occ) {
  const out = [];
  for (const [df, dr] of dirs) {
    let f = F(from) + df, r = R(from) + dr;
    while (onB(f, r)) { const s = SQ(f, r); if (occ.has(s)) break; out.push(s); f += df; r += dr; }
  }
  return out;
}

// ------------------------------------------------------------ KQK / KRK
// idx = ((stm*64 + wk)*64 + pc)*64 + bk; value 1 = White wins.
function solveKXK(dirs) {
  const N = 2 * 64 * 64 * 64;
  const val = new Uint8Array(N), legalA = new Uint8Array(N);
  const id = (stm, wk, pc, bk) => ((stm * 64 + wk) * 64 + pc) * 64 + bk;
  const succ = new Array(N);
  for (let wk = 0; wk < 64; wk++) for (let pc = 0; pc < 64; pc++) for (let bk = 0; bk < 64; bk++) {
    if (wk === pc || wk === bk || pc === bk || dist(wk, bk) < 2) continue;
    const checkB = sliderHits(pc, dirs, bk, new Set([wk]));
    // White to move: legal only if Black is not in check
    if (!checkB) {
      const i = id(0, wk, pc, bk); legalA[i] = 1;
      const s = [];
      for (const t of kingTargets(wk)) if (t !== pc && dist(t, bk) >= 2) s.push(id(1, t, pc, bk));
      for (const t of sliderMoves(pc, dirs, new Set([wk, bk]))) s.push(id(1, wk, t, bk));
      succ[i] = s;               // never empty in practice; empty -> stalemate
    }
    // Black to move
    {
      const i = id(1, wk, pc, bk); legalA[i] = 1;
      const s = []; let capture = false;
      for (const t of kingTargets(bk)) {
        if (dist(t, wk) < 2) continue;
        if (t === pc) { capture = true; continue; }
        if (sliderHits(pc, dirs, t, new Set([wk]))) continue;
        s.push(id(0, wk, pc, t));
      }
      if (capture) succ[i] = null;            // Kxpiece -> bare kings, draw
      else if (s.length === 0) { succ[i] = null; if (checkB) val[i] = 1; }  // mate / stalemate
      else succ[i] = s;
    }
  }
  let changed = true;
  while (changed) {
    changed = false;
    for (let i = 0; i < N; i++) {
      if (!legalA[i] || val[i] || !succ[i]) continue;
      const btm = i >= N / 2;
      const s = succ[i];
      let v;
      if (btm) { v = 1; for (const j of s) if (!val[j]) { v = 0; break; } }
      else { v = 0; for (const j of s) if (val[j]) { v = 1; break; } }
      if (v) { val[i] = 1; changed = true; }
    }
  }
  return { val, legalA, id };
}

// ------------------------------------------------------------ KPK (all files)
function solveKPK(KQ, KR) {
  // idx = ((stm*64 + wk)*64 + bk)*64 + wp
  const N = 2 * 64 * 64 * 64;
  const id = (stm, wk, bk, wp) => ((stm * 64 + wk) * 64 + bk) * 64 + wp;
  const val = new Uint8Array(N), legalA = new Uint8Array(N), succ = new Array(N);
  const pawnHits = (wp, t) => R(t) === R(wp) + 1 && Math.abs(F(t) - F(wp)) === 1;
  for (let wk = 0; wk < 64; wk++) for (let bk = 0; bk < 64; bk++) for (let wp = 8; wp < 56; wp++) {
    if (wk === bk || wk === wp || bk === wp || dist(wk, bk) < 2) continue;
    // White to move (Black must not be in check)
    if (!pawnHits(wp, bk)) {
      const i = id(0, wk, bk, wp); legalA[i] = 1;
      const s = []; let promoWin = false;
      for (const t of kingTargets(wk)) if (t !== wp && dist(t, bk) >= 2) s.push(id(1, t, bk, wp));
      const one = wp + 8;
      if (one !== wk && one !== bk) {
        if (R(one) === 7) {
          // Q or R promotion: look up exact KQK / KRK with Black to move
          if (KQ.val[KQ.id(1, wk, one, bk)] || KR.val[KR.id(1, wk, one, bk)]) promoWin = true;
          // B / N promotions: KBK / KNK are draws, never better
        } else {
          s.push(id(1, wk, bk, one));
          const two = wp + 16;
          if (R(wp) === 1 && two !== wk && two !== bk) s.push(id(1, wk, bk, two));
        }
      }
      if (promoWin) { val[i] = 1; succ[i] = null; }
      else succ[i] = s.length ? s : null;   // null and val 0 -> stalemate draw
    }
    // Black to move
    {
      const i = id(1, wk, bk, wp); legalA[i] = 1;
      const s = []; let capture = false;
      for (const t of kingTargets(bk)) {
        if (dist(t, wk) < 2 || pawnHits(wp, t)) continue;
        if (t === wp) { capture = true; continue; }
        s.push(id(0, wk, t, wp));
      }
      if (capture) succ[i] = null;
      else if (!s.length) { succ[i] = null; if (pawnHits(wp, bk)) val[i] = 1; }
      else succ[i] = s;
    }
  }
  let changed = true, passes = 0;
  while (changed) {
    changed = false; passes++;
    for (let i = 0; i < N; i++) {
      if (!legalA[i] || val[i] || !succ[i]) continue;
      const s = succ[i];
      let v;
      if (i >= N / 2) { v = 1; for (const j of s) if (!val[j]) { v = 0; break; } }
      else { v = 0; for (const j of s) if (val[j]) { v = 1; break; } }
      if (v) { val[i] = 1; changed = true; }
    }
  }
  return { val, legalA, id, passes };
}

// ------------------------------------------------------------ main
const t0 = Date.now();
const KQ = solveKXK(QD), KR = solveKXK(RD);
// Verify the promotion rule used by kpk.py against the exact tables.
for (const [name, T, dirs] of [['KQK', KQ, QD], ['KRK', KR, RD]]) {
  let wtmLegal = 0, wtmNotWon = 0, btmLegal = 0, ruleBad = 0;
  for (let wk = 0; wk < 64; wk++) for (let pc = 0; pc < 64; pc++) for (let bk = 0; bk < 64; bk++) {
    const i0 = T.id(0, wk, pc, bk), i1 = T.id(1, wk, pc, bk);
    if (T.legalA[i0]) { wtmLegal++; if (!T.val[i0]) wtmNotWon++; }
    if (T.legalA[i1]) {
      btmLegal++;
      // rule: win iff (no capture of the piece) and (has a move or is in check)
      let cap = false, moves = 0;
      for (const t of kingTargets(bk)) {
        if (dist(t, wk) < 2) continue;
        if (t === pc) { cap = true; continue; }
        if (!sliderHits(pc, dirs, t, new Set([wk]))) moves++;
      }
      const inCheck = sliderHits(pc, dirs, bk, new Set([wk]));
      const rule = !cap && (moves > 0 || inCheck) ? 1 : 0;
      if (rule !== T.val[i1]) ruleBad++;
    }
  }
  console.log(`${name}: WTM legal ${wtmLegal}, not won ${wtmNotWon}; BTM legal ${btmLegal}, promotion-rule mismatches ${ruleBad}`);
}
const P = solveKPK(KQ, KR);
console.log(`KPK solved in ${P.passes} passes, ${(Date.now() - t0) / 1000}s`);

// mirror symmetry check over all 8 files
let mirrorBad = 0;
for (let stm = 0; stm < 2; stm++) for (let wk = 0; wk < 64; wk++) for (let bk = 0; bk < 64; bk++) for (let wp = 8; wp < 56; wp++)
  if (P.val[P.id(stm, wk, bk, wp)] !== P.val[P.id(stm, wk ^ 7, bk ^ 7, wp ^ 7)]) mirrorBad++;
console.log(`mirror-symmetry mismatches: ${mirrorBad}`);

// counts (files a-d and all files)
for (let stm = 0; stm < 2; stm++) {
  let la = 0, wa = 0, l8 = 0, w8 = 0;
  for (let wk = 0; wk < 64; wk++) for (let bk = 0; bk < 64; bk++) for (let wp = 8; wp < 56; wp++) {
    const i = P.id(stm, wk, bk, wp);
    if (!P.legalA[i]) continue;
    l8++; w8 += P.val[i];
    if (F(wp) < 4) { la++; wa += P.val[i]; }
  }
  console.log(`${stm ? 'Black' : 'White'} to move: files a-d legal ${la} wins ${wa} (${(100 * wa / la).toFixed(3)}%); all files legal ${l8} wins ${w8}`);
}

// pack and compare
const out = Buffer.alloc(24576);
for (let stm = 0; stm < 2; stm++) for (let pidx = 0; pidx < 24; pidx++) {
  const wp = SQ(pidx % 4, (pidx >> 2) + 1), base = (stm * 24 + pidx) * 512;
  for (let wk = 0; wk < 64; wk++) for (let bk = 0; bk < 64; bk++)
    if (P.val[P.id(stm, wk, bk, wp)]) out[base + wk * 8 + (bk >> 3)] |= 1 << (bk & 7);
}
const ref = fs.readFileSync(BIN);
let diffBytes = 0, diffBits = 0;
for (let i = 0; i < 24576; i++) if (out[i] !== ref[i]) {
  diffBytes++; let x = out[i] ^ ref[i]; while (x) { diffBits += x & 1; x >>= 1; }
}
console.log(`compare with ${BIN} (${ref.length} bytes): ${diffBytes} differing bytes, ${diffBits} differing bits`);
process.exit(diffBytes || mirrorBad || ref.length !== 24576 ? 1 : 0);
