"""Castling oracle for tests/engine/t_castle.js, from python-chess (independent of the engine).
    python -E -P tools/audit/gen_castle.py [positions=3000] [seed=17]
Writes tests/engine/data/castle_oracle.json: positions built around castling (17 Nov, after the
castling generator was rewritten as one routine for both colours):
  - kings on their home squares (mostly) or not;
  - in each corner our rook, the enemy's rook, another piece, or nothing;
  - pieces of either colour on the squares between king and rook;
  - enemy attackers (N, B, R, Q, P, K) on random squares, so the king's square, the square it
    passes, the square it lands on and b1/b8 (which may be attacked for O-O-O) are attacked or not;
  - castling rights a random subset of KQkq, also rights without king or rook at home (the raw
    FEN is written, so the engine's own clean-up of such rights is tested too);
  - either side to move; positions python-chess calls invalid for other reasons are skipped.
Per position: fen, rights (python-chess's, cleaned), legal (sorted UCI), and for each castling move the position after it (FEN,
with python-chess's castling rights)."""
import json
import os
import random
import sys

import chess

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '..', '..', 'tests', 'engine', 'data', 'castle_oracle.json')
OK_STATUS = chess.STATUS_VALID | chess.STATUS_BAD_CASTLING_RIGHTS


def gen(rng):
    b = chess.Board(None)
    occ = set()

    def put(sq, piece):
        b.set_piece_at(sq, piece)
        occ.add(sq)

    for col, rank in ((chess.WHITE, 0), (chess.BLACK, 7)):
        if rng.random() < 0.85:
            ksq = chess.square(4, rank)
        else:
            ksq = rng.choice([s for s in chess.SQUARES if s not in occ])
        put(ksq, chess.Piece(chess.KING, col))
        for f in (0, 7):
            sq = chess.square(f, rank)
            if sq in occ:
                continue
            r = rng.random()
            if r < 0.70:
                put(sq, chess.Piece(chess.ROOK, col))
            elif r < 0.78:
                put(sq, chess.Piece(chess.ROOK, not col))
            elif r < 0.86:
                put(sq, chess.Piece(rng.choice([chess.KNIGHT, chess.BISHOP, chess.QUEEN]), rng.choice([col, not col])))
        for f in (1, 2, 3, 5, 6):
            sq = chess.square(f, rank)
            if sq not in occ and rng.random() < 0.12:
                put(sq, chess.Piece(rng.choice([chess.KNIGHT, chess.BISHOP, chess.ROOK, chess.QUEEN]), rng.choice([col, not col])))
    for _ in range(rng.randint(0, 4)):          # attackers and other pieces anywhere
        col = rng.choice([chess.WHITE, chess.BLACK])
        pt = rng.choice([chess.KNIGHT, chess.BISHOP, chess.ROOK, chess.QUEEN, chess.PAWN, chess.PAWN])
        free = [s for s in chess.SQUARES if s not in occ and (pt != chess.PAWN or 1 <= chess.square_rank(s) <= 6)]
        put(rng.choice(free), chess.Piece(pt, col))
    rights = ''.join(c for c in 'KQkq' if rng.random() < 0.75) or '-'
    turn = rng.choice(['w', 'b'])
    fen = f'{b.board_fen()} {turn} {rights} - 0 1'
    board = chess.Board(fen)
    if board.status() & ~OK_STATUS:
        return None
    return fen, board


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 3000
    rng = random.Random(int(sys.argv[2]) if len(sys.argv) > 2 else 17)
    out = []
    stats = {'castling moves': 0, 'positions with castling': 0, 'bad rights': 0}
    while len(out) < n:
        g = gen(rng)
        if not g:
            continue
        fen, board = g
        if board.status() & chess.STATUS_BAD_CASTLING_RIGHTS:
            stats['bad rights'] += 1
        legal = sorted(m.uci() for m in board.legal_moves)
        after = {}
        for m in board.legal_moves:
            if board.is_castling(m):
                b2 = board.copy()
                b2.push(m)
                after[m.uci()] = b2.fen()
        stats['castling moves'] += len(after)
        stats['positions with castling'] += bool(after)
        out.append({'fen': fen, 'rights': board.fen().split()[2], 'legal': legal, 'after': after})
    json.dump({'positions': out}, open(OUT, 'w'), indent=0)
    print(len(out), 'positions', stats, '->', os.path.relpath(OUT))


if __name__ == '__main__':
    main()
