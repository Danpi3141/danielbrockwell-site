'use strict';
// UCI front end for a snapshot of the reference engine:  node uci_wrap.js <snap_dir>
// Same protocol and options as ref/uci.js, except: e.ply is reset after every game move applied in
// 'position ... moves', because ref/uci.js lets e.ply grow with the game length and overflows the
// MAXPLY-sized mvTop/killer arrays after ~MAXPLY moves (the move is then reported illegal and the
// search runs on a truncated position).  Engine code itself is untouched.
const path = require('path');
const dir = path.resolve(__dirname, process.argv[2] || 'snap_asis');
const { Engine, uciStr, parseUci, legalMoves } = require(path.join(dir, 'search.js'));

const e = new Engine();
let nodes = 6000, margin = 0, seed = 1, games = 0, fallback = false;
// As the Psion plays (16 Nov): Book = the position book (data/book.bin, as kbook.asm reads it),
// BookMoves n = only for this side's first n moves (levels 1-4: n = the level; 0 = all);
// KPK = king and pawn v king from the distance table at the root (ref/kpkroot.js, as OV_KPK)
let book = false, bookMoves = 0, kpkOn = false, plies = 0, brnd = 1;
const ROOT = path.resolve(__dirname, '..', '..');
const fs = require('fs');
let BOOK = null, KPKZ = null, PB = null, KR = null;
e.ttInit(9);
const rl = require('readline').createInterface({ input: process.stdin });
const out = s => process.stdout.write(s + '\n');

function setPosition(args) {
  let i = 0;
  if (args[0] === 'startpos') { e.setFen('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'); i = 1; }
  else if (args[0] === 'fen') { e.setFen(args.slice(1, 7).join(' ')); i = 7; }
  e.ply = 0;
  plies = 0;
  if (args[i] === 'moves') {
    for (const m of args.slice(i + 1)) {
      plies++;
      const mv = parseUci(e, m);
      if (!mv) { out('info string illegal move ' + m); return; }
      e.make(mv[0], mv[1]);
      e.ply = 0;
    }
  }
  e.ply = 0;
}

rl.on('line', line => {
  const w = line.trim().split(/\s+/);
  switch (w[0]) {
    case 'uci':
      out('id name PsionChess-ref-snap');
      out('id author Psion LZ64 chess project');
      out('option name Nodes type spin default 6000 min 100 max 10000000');
      out('option name HashBits type spin default 9 min 4 max 20');
      out('option name Margin type spin default 0 min 0 max 10000');   // think() margin (levels 1-4)
      out('option name Seed type spin default 1 min 1 max 65535');     // rand16 seed base
      // NullFallback: when think() returns no move (node limit hit before any root move was scored),
      // play the first legal move, as the assembler's think does ('.fall'); reported as depth -1
      out('option name NullFallback type check default false');
      out('option name Book type check default false');
      out('option name BookMoves type spin default 0 min 0 max 99');
      out('option name KPK type check default false');
      for (const [o, k] of [['NullMove', 'nullMove'], ['LMR', 'lmr'], ['Futility', 'futility'], ['CheckExt', 'checkExt'], ['PVS', 'pvs'], ['FailLow', 'failLow'], ['RootOrder', 'rootOrder']]) if (k in e.opts) out(`option name ${o} type check default ${e.opts[k]}`);   // the engine's real defaults (python-chess skips options equal to the advertised default)
      out('uciok');
      break;
    case 'isready': out('readyok'); break;
    case 'setoption': {
      const name = w[2], val = w[4];
      if (name === 'Nodes') nodes = +val;
      else if (name === 'Margin') margin = +val;
      else if (name === 'Seed') seed = +val;
      else if (name === 'NullFallback') fallback = val === 'true';
      else if (name === 'Book') { book = val === 'true'; if (book && !BOOK) { BOOK = fs.readFileSync(path.join(ROOT, 'data', 'book.bin')); PB = require(path.join(ROOT, 'tools', 'book', 'pbook.js')); } }
      else if (name === 'BookMoves') bookMoves = +val;
      else if (name === 'KPK') { kpkOn = val === 'true'; if (kpkOn && !KPKZ) { KPKZ = fs.readFileSync(path.join(ROOT, 'data', 'kpkdz.bin')); KR = require(path.join(ROOT, 'ref', 'kpkroot.js')); } }
      else if (name === 'HashBits') e.ttInit(+val);
      else {
        const key = { NullMove: 'nullMove', LMR: 'lmr', Futility: 'futility', CheckExt: 'checkExt', PVS: 'pvs', FailLow: 'failLow', RootOrder: 'rootOrder' }[name];
        if (key) e.opts[key] = val === 'true';
      }
      break;
    }
    case 'ucinewgame':
      e.ttInit(e.ttBits);
      games++;
      e.rnd = ((seed * 7919 + games * 104729 + process.pid * 31) & 0xFFFF) || 1;
      brnd = (e.rnd * 2654435761) >>> 0 || 1;
      break;
    case 'position': setPosition(w.slice(1)); break;
    case 'go': {
      if (book && (bookMoves === 0 || Math.floor(plies / 2) + 1 <= bookMoves)) {
        const bm = PB.moves(BOOK, e);
        if (bm.length) {
          brnd ^= brnd << 13; brnd >>>= 0; brnd ^= brnd >>> 17; brnd ^= brnd << 5; brnd >>>= 0;
          const mv = bm[brnd % bm.length];
          out('info string book'); out('bestmove ' + uciStr(e, mv[0], mv[1]));
          break;
        }
      }
      if (kpkOn) {
        const mv = KR.kpkRoot(e, KPKZ);
        if (mv) { out('info string kpk'); out('bestmove ' + uciStr(e, mv[0], mv[1])); break; }
      }
      let lim = nodes;
      const ni = w.indexOf('nodes');
      if (ni >= 0) lim = +w[ni + 1];
      const r = margin > 0 ? e.think(lim, 40, margin) : e.think(lim);
      if (!r) {
        const lm = fallback ? legalMoves(e) : [];
        if (lm.length) { out(`info depth -1 nodes ${e.nodes}`); out('bestmove ' + uciStr(e, lm[0][0], lm[0][1])); }
        else out('bestmove 0000');
        break;
      }
      out(`info depth ${r.depth} score cp ${r.score} nodes ${r.nodes}`);
      out('bestmove ' + uciStr(e, r.f, r.t));
      break;
    }
    case 'quit': process.exit(0);
  }
});
