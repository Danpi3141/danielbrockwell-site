'use strict';
// The Auto level (kcore.asm auto_adj; the coverage sweep of 17 Nov found no test ran it): with
// Auto set, the level goes up one after the player wins and down one after a loss, stays after a
// draw, and keeps within 1-8. Each result in its own game:
//   the player resigns (down); the player mates (up; at level 8 it stays); the computer resigns
//   (up: missed until 17 Nov); the player's flag falls (down: missed until 17 Nov); stalemate
//   (no change); at level 1 a loss leaves it at 1.
// Also: choosing Auto in the settings starts it from the level in force (17 Nov).
//   node tests/ui/t_auto.js
const L = require('./lib.js');
const G = require('./glib.js');
const { check, keys } = L;
const { Engine, legalMoves } = require('../../ref/search.js');

const nm = (q) => 'abcdefgh'[q & 7] + ((q >> 4) + 1);
const uci = (mv) => nm(mv[0]) + nm(mv[1] & 0x77);
const lv = (m) => L.peekSym(m, 'st_level')[0];
// a new machine at level n (the settings screen), then Auto chosen in another visit to it: Auto
// starts from level n (17 Nov: it started from the level stepped past to reach it, 8 or 1)
function autoAt(n) {
  const m = G.start();
  const to = n - 7;
  if (to) G.setting(m, G.SET.LEVEL, Array(Math.abs(to)).fill(to < 0 ? 'LEFT' : 'RIGHT'));
  check(lv(m) === n && L.peekSym(m, 'st_auto')[0] === 0, `level ${n} set`, m);
  G.setting(m, G.SET.LEVEL, Array(8 - (n - 1)).fill('RIGHT'));          // on through level 8 to Auto
  check(L.peekSym(m, 'st_auto')[0] === 1 && lv(m) === n, `Auto chosen: it starts from level ${n} (st_level ${lv(m)})`, m);
  return m;
}
// in one visit: from level 3 on through 4-8 to Auto, it starts from 3 (the level when the screen
// opened); and going on past Auto (to level 1) leaves Auto
{
  const m = G.start();
  G.setting(m, G.SET.LEVEL, ['LEFT', 'LEFT', 'LEFT', 'LEFT']);
  check(lv(m) === 3, 'level 3 set', m);
  G.setting(m, G.SET.LEVEL, ['RIGHT', 'RIGHT', 'RIGHT', 'RIGHT', 'RIGHT', 'RIGHT']);
  check(L.peekSym(m, 'st_auto')[0] === 1 && lv(m) === 3, `one visit, level 3 to Auto: it starts from ${lv(m)}`, m);
  G.setting(m, G.SET.LEVEL, ['RIGHT']);
  check(L.peekSym(m, 'st_auto')[0] === 0 && lv(m) === 1, `past Auto: level ${lv(m)}, Auto off`, m);
}
const result = (m) => [L.peekSym(m, 'g_result')[0], L.peekSym(m, 'g_reason')[0]];
const waitResult = (m, s) => G.waitInput(m, s || 60, () => L.peekSym(m, 'g_result')[0] !== 0);

// 1. the player resigns: down
{
  const m = autoAt(7);
  G.menu(m, ['R']); m.runSeconds(2);
  check(result(m).join() === '2,6' && lv(m) === 6, `the player resigns: level 7 -> ${lv(m)}`, m);
}
// 2. the player mates: up; and at level 8 it stays
for (const [from, want] of [[6, 7], [8, 8]]) {
  const m = autoAt(from);
  G.setupFen(m, '6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1');
  G.typeUci(m, 'a1a8');
  waitResult(m);
  check(result(m).join() === '1,1' && lv(m) === want, `the player mates: level ${from} -> ${lv(m)} (want ${want})`, m);
}
// 3. the computer resigns (three moves in a row worse than -9 pawns, forced at resign_chk): up
{
  const m = autoAt(5);
  G.setupFen(m, '4k3/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/4K3 w - - 0 1');
  const rc = L.sym(m, 'resign_chk'), sc = L.sym(m, 'e_score');
  m.dbg.setTrace((pc) => { if (pc === rc) m.pokew(sc, (-2000) & 0xFFFF); });
  const e = new Engine(); e.setFen('4k3/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/4K3 w - - 0 1'); e.ply = 0;
  let n = L.peekSym(m, 'g_n')[0];
  for (let i = 0; i < 3 && !L.peekSym(m, 'g_result')[0]; i++) {
    const mv = legalMoves(e).find(([f, t]) => (e.b[f] & 7) === 1) || legalMoves(e)[0];   // a pawn move
    G.typeUci(m, uci(mv)); e.make(mv[0], mv[1]); e.ply = 0; n++;
    G.waitInput(m, 60, () => L.peekSym(m, 'g_n')[0] >= n + 1 || L.peekSym(m, 'g_result')[0] !== 0);
    if (L.peekSym(m, 'g_result')[0]) break;
    const last = L.peekSym(m, 'g_last', 2); e.make(last[0], last[1]); e.ply = 0; n++;
  }
  waitResult(m);
  m.dbg.setTrace(null);
  check(result(m).join() === '1,6' && lv(m) === 6, `the computer resigns: level 5 -> ${lv(m)} (result ${result(m)})`, m);
}
// 4. the player's flag falls (5|5, no move): down
{
  const m = autoAt(5);
  G.setting(m, G.SET.CLOCK, ['RIGHT']);
  G.menu(m, ['N']); G.waitInput(m, 10);              // NEW GAME takes the clock
  check(L.peekSym(m, 'st_timing')[0] === 1 && m.peekw(L.sym(m, 'g_clk')) === 6000, '5|5 clock running', m);
  m.runSeconds(320);
  if (!m.isOn()) { m.press('ON', 3, 10); m.runSeconds(2); }
  L.idle(m);
  check(result(m).join() === '2,7' && lv(m) === 4, `the player loses on time: level 5 -> ${lv(m)} (result ${result(m)})`, m);
}
// 5. stalemate: no change
{
  const m = autoAt(5);
  G.setupFen(m, '7k/8/6Q1/8/8/8/8/K7 w - - 0 1');
  G.typeUci(m, 'g6f7');
  waitResult(m);
  check(result(m)[0] === 3 && lv(m) === 5, `stalemate: level 5 -> ${lv(m)} (result ${result(m)})`, m);
}
// 6. at level 1 a loss leaves it at 1
{
  const m = autoAt(1);
  G.menu(m, ['R']); m.runSeconds(2);
  check(result(m).join() === '2,6' && lv(m) === 1, `the player resigns at level 1: level ${lv(m)}`, m);
}
console.log('all UI tests passed');
