; ---------------------------------------------------------------------
; move_info: pm_f, pm_t (before the move is made) -> A = the record's
; info byte (piece, capture, disambiguation; check and mate come later)
; ---------------------------------------------------------------------
move_info:
        ldab pm_f
        ldx  #e_board
        abx
        ldaa 0,x
        anda #7
        staa mi_i               ; the piece type
        staa mi_p
        ldab pm_t
        andb #$77
        stab mi_t
        ldx  #e_board
        abx
        tst  0,x
        bne  .cap
        ldaa mi_p
        cmpa #PC_P
        bne  .nocap
        ldaa pm_f               ; a pawn changing file captures (en passant)
        eora pm_t
        anda #7
        beq  .nocap
.cap:   ldaa mi_i
        oraa #8
        staa mi_i
.nocap: ldaa mi_p               ; disambiguation: pieces other than pawns and kings
        cmpa #PC_P
        beq  .x
        cmpa #PC_K
        beq  .x
        clr  mi_f               ; bit 0: another shares the file, 1: the rank, 2: any
        ldab lm_n
        beq  .done
        ldx  #lm_buf
.l:     pshb
        ldaa 0,x
        cmpa pm_f
        beq  .n
        ldaa 1,x
        anda #$77
        cmpa mi_t
        bne  .n
        ldab 0,x                ; same kind of piece?
        pshx
        ldx  #e_board
        abx
        ldaa 0,x
        pulx
        anda #7
        cmpa mi_p
        bne  .n
        ldaa mi_f
        oraa #4
        staa mi_f
        ldaa 0,x
        eora pm_f
        tab
        andb #7
        bne  .nf
        ldab mi_f
        orab #1
        stab mi_f
.nf:    anda #$70
        bne  .n
        ldab mi_f
        orab #2
        stab mi_f
.n:     inx
        inx
        pulb
        decb
        bne  .l
.done:  ldaa mi_f
        bita #4
        beq  .x
        ldab #$40               ; the file tells them apart
        bita #1
        beq  .set
        ldab #$80               ; else the rank
        bita #2
        beq  .set
        ldab #$C0               ; else both
.set:   orab mi_i
        stab mi_i
.x:     ldaa mi_i
        rts

mi_i      = ZP2+0
mi_p      = ZP2+1
mi_t      = ZP2+2
mi_f      = ZP2+3

; B = the square of a piece giving check to the side to move ($FF none)
find_checker:
        ldaa e_side
        eora #8
        staa fc_c               ; the attackers' colour
        ldaa e_side
        oraa #PC_K
        staa fc_p               ; the king to find
        clrb
.k:     bitb #$88
        bne  .kn
        ldx  #e_board
        abx
        ldaa 0,x
        cmpa fc_p
        beq  .kf
.kn:    incb
        cmpb #$78
        bne  .k
        ldab #$FF
        rts
.kf:    stab fc_k
        clrb                    ; each attacker
.a:     bitb #$88
        bne  .an
        ldx  #e_board
        abx
        ldaa 0,x
        beq  .an
        anda #8
        cmpa fc_c
        bne  .an
        stab fc_s
        bsr  attacks
        bcc  .found
        ldab fc_s
.an:    incb
        cmpb #$78
        bne  .a
        ldab #$FF
        rts
.found: ldab fc_s
        rts

; does the piece on fc_s attack fc_k? C=0 yes
attacks:
        ldab fc_s
        ldx  #e_board
        abx
        ldaa 0,x
        anda #7
        staa fc_p
        ldaa fc_k
        suba fc_s
        staa fc_d               ; the difference (as a signed byte)
        ldab fc_p
        cmpb #PC_P
        bne  .n
        ldab #15                ; white pawns attack +15 and +17, black -15 and -17
        tst  fc_c
        beq  .pw
        ldab #-15
        cmpa #-17
        beq  .yes
        bra  .pc
.pw:    cmpa #17
        beq  .yes
.pc:    cba
        beq  .yes
        bra  .no
.n:     cmpb #PC_N
        bne  .k
        ldx  #ndir
        bra  .tab
.k:     cmpb #PC_K
        bne  .sl
        ldx  #kdir
.tab:   ldab #8
.t:     cmpa 0,x
        beq  .yes
        inx
        decb
        bne  .t
.no:    sec
        rts
.yes:   clc
        rts
.sl:    ; a slider: along which line?
        ldx  #kdir
        ldab #8
.dl:    stab fc_n
        ldaa fc_s               ; walk from the attacker in this direction
.st:    adda 0,x
        bita #$88
        bne  .dn
        cmpa fc_k
        beq  .hit
        pshx
        tab
        ldx  #e_board
        abx
        tst  0,x
        pulx
        beq  .st
.dn:    inx
        ldab fc_n
        decb
        bne  .dl
        bra  .no
.hit:   ; the line is clear: is it one this piece moves along?
        ldaa 0,x                ; diagonal steps are odd: -17 -15 15 17
        ldab fc_p
        cmpb #PC_Q
        beq  .yes
        cmpa #1
        beq  .orth
        cmpa #-1
        beq  .orth
        cmpa #16
        beq  .orth
        cmpa #-16
        beq  .orth
        cmpb #PC_B
        beq  .yes
        bra  .no
.orth:  cmpb #PC_R
        beq  .yes
        bra  .no

ndir:   fcb  -33,-31,-18,-14,14,18,31,33
kdir:   fcb  -17,-16,-15,-1,1,15,16,17
fc_c      = ZP2+4
fc_k      = ZP2+5
fc_s      = ZP2+6
fc_p      = ZP2+7
fc_d      = ZP2+8
fc_n      = ZP2+9
