; ---------------------------------------------------------------------
; Sound. BZ$TONE plays D = pitch (921,600 / (78 + 2D) Hz) for X ms and
; stops the processor meanwhile. st_sound: 0 all, 1 blips only, 2 off.
; A sound is a list of notes: pitch (word), ms (byte); pitch 0 ends it.
; Bit 7 of the first byte of a list marks a "full" sound (not a blip).
; ---------------------------------------------------------------------
snd_moved:  fcb  $00                                  ; the engine has moved: one blip
            fdb  191
            fcb  40
            fdb  0
snd_check:  fcb  $00                                  ; check: two rising blips
            fdb  268
            fcb  40
            fdb  191
            fcb  50
            fdb  0
snd_end:    fcb  $80                                  ; mate or draw: a short phrase
            fdb  842
            fcb  90
            fdb  660
            fcb  90
            fdb  549
            fcb  90
            fdb  401
            fcb  180
            fdb  0
snd_buzz:   fcb  $80                                  ; illegal entry: a low buzz
            fdb  3033
            fcb  150
            fdb  0
snd_tick:   fcb  $00                                  ; clock under a minute
            fdb  86
            fcb  4
            fdb  0

; X = sound
snd_play:
        ldab st_sound
        cmpb #2
        beq  .x
        tstb
        beq  .go
        tst  0,x                ; blips only: skip the full sounds
        bmi  .x
.go:    inx
.n:     ldd  0,x
        beq  .x
        pshx
        ldab 2,x
        clra
        pshb
        psha
        ldd  0,x
        pulx                    ; X = ms
        os   BZ$TONE
        pulx
        inx
        inx
        inx
        bra  .n
.x:     rts
