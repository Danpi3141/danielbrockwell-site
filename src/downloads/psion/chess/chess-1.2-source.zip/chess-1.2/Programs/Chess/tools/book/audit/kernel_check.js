'use strict';
// Checks the Psion's own 6303 book reader (src/screens/kbook.asm, in the built game) against the
// independent decoder (decode.js), by playing book lines through the UI in the headless emulator.
//
//   node tools/book/audit/kernel_check.js [--opk build/game/CHESS.opk] [--sym build/game/kernel.sym.json]
//        [--book data/book.bin] [--lines 40] [--games 12] [--seed 1]
//
// Part 1, two-player mode: random walks through the tree (deep walks, walks biased towards later
// siblings and J entries, and every third line first to a group drawn uniformly from the tree),
// then a couple of legal moves past the end of the book, or an out-of-book move in the middle. After every ply: bk_in must be 1 exactly when the decoder has a group for the position,
// and bk_p must equal the decoder's offset of that group.
// Part 2, against the computer (both colours): the player plays book moves (random group members);
// every computer move made while in book must be one of the group's P moves (bk_pick), and
// bk_in / bk_p are checked as in part 1.
// The pack must hold the same book bytes as --book (checked first).
const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFileSync } = require('child_process');
const { Machine } = require('../../../tools/emu.js');
const { Engine, legalMoves, sqName } = require('../../../ref/search.js');

const ROOT = path.resolve(__dirname, '..', '..', '..');
const arg = (n, d) => { const i = process.argv.indexOf('--' + n); return i >= 0 ? process.argv[i + 1] : d; };
const OPK = arg('opk', path.join(ROOT, 'build', 'game', 'CHESS.opk'));
const SYM = arg('sym', path.join(path.dirname(OPK), 'kernel.sym.json'));
const BOOK = arg('book', path.join(ROOT, 'data', 'book.bin'));
const NLINES = +arg('lines', 40), NGAMES = +arg('games', 12);
let seed = +arg('seed', 1);
const rnd = () => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed / 2147483648; };
const pick = (a) => a[Math.floor(rnd() * a.length)];

// ---- the decoder's view
const opk = fs.readFileSync(OPK), book = fs.readFileSync(BOOK);
if (opk.indexOf(book) < 0) { console.log('FAIL: the pack does not contain ' + BOOK); process.exit(1); }
const tmp = path.join(os.tmpdir(), 'book_tree_' + process.pid + '.json');
execFileSync(process.execPath, [path.join(__dirname, 'decode.js'), BOOK, '--json', tmp]);
const tree = JSON.parse(fs.readFileSync(tmp, 'utf8'));
fs.unlinkSync(tmp);
const G = new Map();                       // path string -> group
for (const g of tree.groups) G.set(g.path.join(' '), g);

// ---- the machine
const syms = JSON.parse(fs.readFileSync(SYM, 'utf8'));
const m = new Machine({ rom: '46a-lz64.rom', ram: 64 });
m.boot();
m.insertPack(OPK, 0);
m.runProc('CHESS', 'B');
m.runSeconds(4);
let base = -1;
function sym(n) {
  if (base < 0) { const a = m.find([0x43, 0x48, 0x4B, 0x31], 0x2000, 0x8000); if (a < 0) throw new Error('kernel not found'); base = a - 3; }
  return base + syms[n][0];
}
const peek = (n) => m.peek(sym(n));
const peekw = (n) => m.peekw(sym(n));
function keys(list) { for (const k of list) m.press(k.length > 1 ? k : k.toUpperCase(), 3, 6); }
function idle(s) {
  const res = sym('kv_res');
  let same = 0, last = '';
  for (let i = 0; i < (s || 60) * 4; i++) {
    m.runSeconds(0.25);
    const t = m.screenText();
    if (m.peek(res) === 1 && m.dbg.sleeping && m.dbg.sleeping() && t === last) { if (++same >= 5) return true; } else same = 0;
    last = t;
  }
  return false;
}
const DIG = { 1: 'U', 2: 'V', 3: 'W', 4: 'O', 5: 'P', 6: 'Q', 7: 'I', 8: 'J' };
const typeMove = (u) => keys([u[0], DIG[u[1]], u[2], DIG[u[3]]]);
function settingsLine(n, presses) {
  keys(['ON']); m.runSeconds(1); keys(['S', 'S', 'EXE']); m.runSeconds(1);
  for (let i = 0; i < n; i++) keys(['DOWN']);
  for (const k of presses) keys([k]);
  keys(['ON']); idle();
}
function newGame() { keys(['ON']); m.runSeconds(1); keys(['EXE']); idle(); }
const lastMove = () => { const f = peek('g_last'), t = m.peek(sym('g_last') + 1) & 0x77; return sqName(f) + sqName(t); };

const distinct = new Set();
let takebacks = 0, checks = 0, fails = 0, positions = 0, outPositions = 0, jPassed = 0, picks = 0;
const failures = [];
function verify(pathU, what) {
  const g = G.get(pathU.join(' '));
  const inb = peek('bk_in'), p = peekw('bk_p');
  checks++;
  if (g) { positions++; distinct.add(pathU.join(' ')); } else outPositions++;
  const ok = g ? (inb === 1 && p === g.off) : inb === 0;
  if (!ok) {
    fails++;
    failures.push(`${what}: after [${pathU.join(' ')}] decoder ${g ? 'group at ' + g.off : 'out of book'}, kernel bk_in=${inb} bk_p=${p}`);
  }
  return g;
}
// how many J entries does a lookup of move u in group g pass over (to report coverage of J skips)
function jSkips(g, u) { let n = 0; for (const mv of g.moves) { if (mv.uci === u) break; if (mv.fl & 2) n++; } return n; }
function legalUci(pathU) {
  const e = new Engine();
  for (const u of pathU) {
    const mv = legalMoves(e).find(x => sqName(x[0]) + sqName(x[1] & 0x77) === u);
    e.make(mv[0], mv[1]); e.ply = 0;
  }
  return legalMoves(e).filter(x => !(x[1] & 0x88)).map(x => sqName(x[0]) + sqName(x[1] & 0x77))
    .filter((u, i, a) => a.indexOf(u) === i);
}

idle();
// ---------------- part 1: two players
settingsLine(12, ['RIGHT']);
if (peek('g_mode') !== 1) throw new Error('two-player mode not set');
const t0 = Date.now();
for (let li = 0; li < NLINES; li++) {
  newGame();
  const pathU = [];
  verify(pathU, 'start');
  const leaveEarly = li % 4 === 3 ? 2 + Math.floor(rnd() * 6) : 99;
  // every third line first goes to a book position drawn uniformly from all groups (not yet visited)
  let target = [];
  if (li % 3 === 0) {
    const pool = tree.groups.filter(g => g.path.length && !distinct.has(g.path.join(' ')));
    if (pool.length) target = pick(pool).path;
  }
  let extra = 0;
  for (let ply = 0; ply < 30; ply++) {
    const g = G.get(pathU.join(' '));
    let u;
    if (g && pathU.length < target.length) {
      u = target[pathU.length];
      jPassed += jSkips(g, u);
    } else if (g && pathU.length < leaveEarly) {
      // three kinds of walk: deep (moves with replies), late siblings (long scans, J skips), deep and late
      const kind = li % 3;
      const fresh = (mv) => mv.sub !== null && !distinct.has(pathU.concat([mv.uci]).join(' '));
      const w = g.moves.map((mv, i) => kind === 0 ? (fresh(mv) ? 100 : mv.sub !== null ? 10 : 1)
        : kind === 1 ? 1 + i + 4 * jSkips(g, mv.uci)
          : (mv.sub !== null ? 10 * (1 + i) : 1) + 4 * jSkips(g, mv.uci));
      let r = rnd() * w.reduce((a, b) => a + b, 0), i = 0;
      while (r >= w[i]) { r -= w[i]; i++; }
      u = g.moves[i].uci;
      jPassed += jSkips(g, u);
    } else {
      const legal = legalUci(pathU).filter(x => !(g && g.moves.some(mv => mv.uci === x)));
      if (!legal.length || extra >= 2) break;
      u = pick(legal);
      extra++;
    }
    typeMove(u);
    idle();
    if (lastMove() !== u) { fails++; failures.push(`move ${u} not played after [${pathU.join(' ')}] (screen: ${m.screenText().replace(/\n/g, '|')})`); break; }
    pathU.push(u);
    verify(pathU, 'two-player line ' + li);
  }
  // every third line: take the last ply back (the game is replayed from the start, following the book)
  if (li % 3 === 2 && pathU.length > 1) {
    keys(['DEL']); idle();
    pathU.pop();
    takebacks++;
    if (peek('g_n') !== pathU.length) { fails++; failures.push(`take back failed after [${pathU.join(' ')}]`); }
    else verify(pathU, 'take back, line ' + li);
  }
  if ((li + 1) % 10 === 0) console.log(`  ${li + 1} lines, ${checks} checks, ${fails} failures, ${((Date.now() - t0) / 1000).toFixed(0)} s`);
}

// ---------------- part 2: against the computer (level 1 so out-of-book thinking is short)
settingsLine(12, ['LEFT']);
settingsLine(1, ['LEFT', 'LEFT', 'LEFT', 'LEFT', 'LEFT', 'LEFT', 'LEFT']);
for (let gi = 0; gi < NGAMES; gi++) {
  const psionWhite = gi >= NGAMES / 2;
  if (gi === Math.ceil(NGAMES / 2)) settingsLine(4, ['RIGHT']);     // YOU PLAY: WHITE -> BLACK
  newGame();
  if ((peek('g_human') === 8) !== psionWhite) throw new Error('colour setting not as expected (g_human=' + peek('g_human') + ')');
  const pathU = [];
  for (let ply = 0; ply < 24; ply++) {
    const g = G.get(pathU.join(' '));
    const psionToMove = (pathU.length % 2 === 0) === psionWhite;
    if (psionToMove) {
      idle(90);
      if (peek('g_n') !== pathU.length + 1) break;
      const u = lastMove();
      if (g) {
        picks++;
        checks++;
        const pm = g.moves.filter(mv => mv.fl & 1).map(mv => mv.uci);
        if (!pm.includes(u)) { fails++; failures.push(`computer played ${u} after [${pathU.join(' ')}], P moves ${pm.join(' ')}`); }
      }
      pathU.push(u);
      verify(pathU, 'vs computer game ' + gi);
    } else {
      if (!g) break;
      idle();
      const u = pick(g.moves).uci;
      typeMove(u);
      pathU.push(u);
      if (!G.get(pathU.join(' '))) { idle(90); break; }   // out of book: the computer thinks; stop here
    }
  }
}

console.log(`kernel book reader vs decoder: ${checks} checks (${positions} in book, ${distinct.size} distinct book positions, ${outPositions} out-of-book, ` +
  `${picks} computer book picks, ${jPassed} J skips exercised, ${takebacks} take-backs), ${fails} failures, ${((Date.now() - t0) / 1000).toFixed(0)} s`);
for (const f of failures.slice(0, 20)) console.log('  ' + f);
process.exit(fails ? 1 : 0);
