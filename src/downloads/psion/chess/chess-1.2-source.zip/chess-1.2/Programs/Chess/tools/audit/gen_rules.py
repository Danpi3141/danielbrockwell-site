"""The rules oracle for tests/engine/t_rules.js, from python-chess (independent of the engine).
    python -E -P tools/audit/gen_rules.py [games] [seed]
Writes tests/engine/data/rules_oracle.json:
  cases: hand-made special cases {name, fen, moves, want: {legal, check, status, board, ...}, has, hasnot}
  games: random games biased towards special moves (castling, en passant, promotions, checks) and
         towards repeating positions; per ply [uci played, n legal, fnv32(legal list), status, check].
Status uses the engine's numbering: 0 playing, 1 mate, 2 stalemate, 3 fifty moves, 4 threefold,
5 too little material (the engine's definition: no P/R/Q and at most one minor in all).
'fide_dead' marks positions python-chess calls insufficient material where the engine does not
(e.g. bishops of one colour only)."""
import json, os, random, sys
import chess

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '..', '..', 'tests', 'engine', 'data', 'rules_oracle.json')


def fnv(s):
    h = 0x811C9DC5
    for ch in s.encode():
        h ^= ch
        h = (h * 0x01000193) & 0xFFFFFFFF
    return h


def eng_insuf(b):
    # the engine's rule (e_insuf): at most one minor piece, or (since 16 Nov) only bishops, all on
    # one colour of square (python-chess calls that insufficient too)
    if b.pawns or b.rooks or b.queens:
        return False
    if chess.popcount(b.knights | b.bishops) <= 1:
        return True
    if b.knights:
        return False
    cols = {(chess.square_rank(s) + chess.square_file(s)) & 1 for s in chess.scan_forward(b.bishops)}
    return len(cols) == 1


def status(b):
    if not any(True for _ in b.legal_moves):
        return 1 if b.is_check() else 2
    if b.halfmove_clock >= 100:
        return 3
    if b.is_repetition(3):
        return 4
    if eng_insuf(b):
        return 5
    return 0


def legal_list(b):
    return sorted(m.uci() for m in b.legal_moves)


def want(b):
    return {'legal': legal_list(b), 'check': b.is_check(), 'status': status(b),
            'board': b.board_fen(), 'turn': 'w' if b.turn else 'b',
            'ep': chess.square_name(b.ep_square) if b.ep_square is not None and b.has_legal_en_passant() else '-',
            'castle': b.castling_xfen(), 'half': b.halfmove_clock,
            'fide_dead': b.is_insufficient_material() and not eng_insuf(b)}


START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'
CASTLE = 'r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1'
CASES = [
    # castling
    ('castle both ways allowed', CASTLE, [], ['e1g1', 'e1c1'], []),
    ('castle out of check refused', 'r3k2r/8/8/8/4r3/8/8/R3K2R w KQkq - 0 1', [], [], ['e1g1', 'e1c1']),
    ('castle through check (f1) refused', 'r3k2r/8/8/8/8/8/5r2/R3K2R w KQkq - 0 1', [], ['e1c1'], ['e1g1']),
    ('castle through check (d1) refused', 'r3k2r/8/8/8/8/8/3r4/R3K2R w KQkq - 0 1', [], ['e1g1'], ['e1c1']),
    ('castle into check (g1) refused', 'r3k2r/8/8/8/8/8/6r1/R3K2R w KQkq - 0 1', [], ['e1c1'], ['e1g1']),
    ('castle into check (c1) refused', 'r3k2r/8/8/8/8/8/2r5/R3K2R w KQkq - 0 1', [], ['e1g1'], ['e1c1']),
    ('long castle with b1 attacked allowed', 'r3k2r/8/8/8/8/8/1r6/R3K2R w KQkq - 0 1', [], ['e1c1'], []),
    ('castle with both rooks attacked allowed', '4k3/r6r/8/8/8/8/8/R3K2R w KQ - 0 1', [], ['e1g1', 'e1c1'], []),
    ('castle with b1 occupied refused', 'r3k2r/8/8/8/8/8/8/RN2K2R w KQkq - 0 1', [], ['e1g1'], ['e1c1']),
    ('castle with the rook missing (right still set) refused', 'r3k2r/8/8/8/8/8/8/4K2R w KQkq - 0 1', [], ['e1g1'], ['e1c1']),
    ('castle with an enemy rook on the corner refused', 'r3k2r/8/8/8/8/8/8/r3K2R w KQk - 0 1', [], [], ['e1c1']),
    ('black castle through check refused', 'r3k2r/8/8/8/8/8/8/R2QK2R b KQkq - 0 1', [], ['e8g8'], ['e8c8']),
    ('castling right lost when the rook is captured', 'r3k2r/8/8/8/8/8/6b1/R3K2R b KQkq - 0 1', ['g2h1'], [], ['e1g1']),
    ('castling rights lost after the king moves and returns', CASTLE, ['e1f1', 'e8f8', 'f1e1', 'f8e8'], [], ['e1g1', 'e1c1']),
    ('castling right lost after the rook moves and returns', CASTLE, ['h1h2', 'a8a7', 'h2h1', 'a7a8'], ['e1c1'], ['e1g1']),
    ('castling moves the rook', CASTLE, ['e1g1'], [], []),
    ('black long castling moves the rook', 'r3k2r/8/8/8/8/8/8/R3K2R b KQkq - 0 1', ['e8c8'], [], []),
    # en passant
    ('en passant allowed', 'rnbqkbnr/ppp1pppp/8/8/3p4/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', ['e2e4'], ['d4e3'], []),
    ('en passant only immediately', 'rnbqkbnr/ppp1pppp/8/8/3p4/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', ['e2e4', 'a7a6', 'a2a3'], [], ['d4e3']),
    ('en passant exposing the king (horizontal pin) refused', '8/8/8/8/k2p3R/8/4P3/4K3 w - - 0 1', ['e2e4'], [], ['d4e3']),
    ('en passant exposing the king (rook beyond both pawns) refused', '8/8/8/8/R2p3k/8/4P3/4K3 w - - 0 1', ['e2e4'], [], ['d4e3']),
    ('en passant exposing the king (diagonal pin) refused', '8/1k6/8/8/3Pp3/8/8/4K2B b - d3 0 1', [], [], ['e4d3']),
    ('en passant taking the checking pawn', '8/8/8/2k5/2pP4/8/B7/4K3 b - d3 0 3', [], ['c4d3'], []),
    ('en passant out of check (takes the checking pawn)', '8/8/8/2k5/3Pp3/8/8/4K3 b - d3 0 1', [], ['e4d3'], []),
    ('en passant blocking a check', '8/8/8/1k6/3Pp3/8/8/4KQ2 b - d3 0 1', [], ['e4d3'], []),
    ('en passant not out of check by a piece', '8/8/8/8/k2Pp3/8/8/3K3Q b - d3 0 1', [], [], []),
    ('white en passant out of check', '4k3/8/8/3pP3/4K3/8/8/8 w - d6 0 2', [], ['e5d6'], []),
    ('en passant, pawn pinned on the file', '4r1k1/8/8/3pP3/8/8/8/4K3 w - d6 0 2', [], [], ['e5d6']),
    # promotion
    ('promotion to all four, with and without capture', 'r1n1k3/1P6/8/8/8/8/8/4K3 w - - 0 1', [],
     ['b7b8q', 'b7b8r', 'b7b8b', 'b7b8n', 'b7a8q', 'b7a8r', 'b7a8b', 'b7a8n', 'b7c8q', 'b7c8n'], []),
    ('under-promotion to a knight with capture and check', 'r1n1k3/1P6/8/8/8/8/8/4K3 w - - 0 1', ['b7c8n'], [], []),
    ('under-promotion to a rook', 'r1n1k3/1P6/8/8/8/8/8/4K3 w - - 0 1', ['b7b8r'], [], []),
    ('under-promotion to a bishop with capture', 'r1n1k3/1P6/8/8/8/8/8/4K3 w - - 0 1', ['b7a8b'], [], []),
    ('black under-promotion to a knight with capture', '4k3/8/8/8/8/8/1p6/R1N1K3 b - - 0 1', ['b2c1n'], [], []),
    ('black under-promotion to a rook', '4k3/8/8/8/8/8/1p6/R1N1K3 b - - 0 1', ['b2b1r'], [], []),
    ('black under-promotion to a bishop with capture', '4k3/8/8/8/8/8/1p6/R1N1K3 b - - 0 1', ['b2a1b'], [], []),
    ('black promotion to a queen with capture', '4k3/8/8/8/8/8/1p6/R1N1K3 b - - 0 1', ['b2a1q'], [], []),
    ('promotion out of check (capture or block)', '2K2r2/4P3/8/8/8/8/8/3k4 w - - 0 1', [], ['e7f8q', 'e7f8n', 'e7e8q', 'e7e8r'], []),
    # mate and stalemate
    ('checkmate (back rank)', '6k1/5ppp/8/8/8/8/8/R5K1 w - - 0 1', ['a1a8'], [], []),
    ('checkmate (smothered)', '6rk/6pp/7N/8/8/8/8/6K1 w - - 0 1', ['h6f7'], [], []),
    ('stalemate (king and queen)', '7k/8/6Q1/8/8/8/8/6K1 b - - 0 1', [], [], []),
    ('stalemate after a move', 'k7/2Q5/8/8/8/8/8/6K1 w - - 0 1', ['c7b6'], [], []),
    ('a pinned rook moves only along the pin', '1k6/1r6/8/8/8/8/8/1Q4KR b - - 0 1', [], ['b7b1'], ['b7c7']),
    ('stalemate with a blocked pawn', '8/8/8/8/8/5k2/5p2/5K2 w - - 0 1', [], [], []),
    ('not stalemate: a pawn can move', '7k/8/6Q1/8/8/8/p7/6K1 b - - 0 1', [], [], []),
    # fifty-move rule
    ('fifty moves: 99 half-moves still playing', '7k/8/6K1/8/8/8/8/R7 w - - 99 80', [], [], []),
    ('fifty moves reached on the 100th half-move', '7k/8/6K1/8/8/8/8/R7 w - - 99 80', ['a1b1'], [], []),
    ('mate on the 100th half-move is mate', '7k/8/6K1/8/8/8/8/R7 w - - 99 80', ['a1a8'], [], []),
    ('stalemate on the 100th half-move is stalemate', '7k/8/6K1/8/8/8/8/5Q2 w - - 99 80', ['f1f7'], [], []),
    ('capture on the 100th half-move resets the clock', '7k/8/6K1/8/8/8/r7/R7 w - - 99 80', ['a1a2'], [], []),
    ('pawn move on the 100th half-move resets the clock', '7k/8/6K1/8/8/8/P7/R7 w - - 99 80', ['a2a3'], [], []),
    ('fifty moves with legal moves after 100+', '7k/8/6K1/8/8/8/8/R7 w - - 120 80', [], [], []),
    # threefold repetition
    ('threefold by knight shuffles', START, ['g1f3', 'g8f6', 'f3g1', 'f6g8', 'g1f3', 'g8f6', 'f3g1', 'f6g8'], [], []),
    ('only twice: not yet threefold', START, ['g1f3', 'g8f6', 'f3g1', 'f6g8', 'g1f3', 'g8f6', 'f3g1'], [], []),
    ('same squares, other side to move: not a repetition', '7k/8/8/8/8/8/8/R5K1 w - - 0 1',
     ['a1a2', 'h8g8', 'a2a1', 'g8h8', 'g1h1', 'h8g8', 'h1g1', 'g8h8', 'a1a2'], [], []),
    ('lost castling rights: earlier positions do not count', 'r3k2r/pppppppp/8/8/8/8/PPPPPPPP/R3K2R w KQkq - 0 1',
     ['e1d1', 'e8d8', 'd1e1', 'd8e8', 'e1d1', 'e8d8', 'd1e1', 'd8e8'], [], []),
    ('lost castling rights: threefold from then on', 'r3k2r/pppppppp/8/8/8/8/PPPPPPPP/R3K2R w KQkq - 0 1',
     ['e1d1', 'e8d8', 'd1e1', 'd8e8', 'e1d1', 'e8d8', 'd1e1', 'd8e8', 'e1d1', 'e8d8', 'd1e1', 'd8e8'], [], []),
    ('a capture in between breaks the repetition', '4k3/8/8/8/8/8/p7/R3K3 w - - 0 1',
     ['e1d1', 'e8d8', 'd1e1', 'd8e8', 'a1a2', 'e8d8', 'a2a1', 'd8e8', 'e1d1', 'e8d8', 'd1e1', 'd8e8'], [], []),
    ('threefold counted after a double pawn push with no en passant possible', START,
     ['e2e4', 'g8f6', 'g1f3', 'f6g8', 'f3g1', 'g8f6', 'g1f3', 'f6g8', 'f3g1'], [], []),
    ('first occurrence had en passant possible: not the same position',
     'rnbqkbnr/ppp1pppp/8/8/3p4/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
     ['e2e4', 'g8f6', 'g1f3', 'f6g8', 'f3g1', 'g8f6', 'g1f3', 'f6g8', 'f3g1'], [], []),
    ('threefold after the en passant chance has gone',
     'rnbqkbnr/ppp1pppp/8/8/3p4/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
     ['e2e4', 'g8f6', 'g1f3', 'f6g8', 'f3g1', 'g8f6', 'g1f3', 'f6g8', 'f3g1', 'g8f6', 'g1f3', 'f6g8', 'f3g1'], [], []),
    # insufficient material
    ('king v king', '8/8/8/4k3/8/8/8/4K3 w - - 0 1', [], [], []),
    ('king and knight v king', '8/8/8/4k3/8/8/8/2N1K3 w - - 0 1', [], [], []),
    ('king and bishop v king', '8/8/8/4k3/8/8/8/2B1K3 b - - 0 1', [], [], []),
    ('king and two knights v king: playing', '8/8/8/4k3/8/8/8/1NN1K3 w - - 0 1', [], [], []),
    ('bishop v knight: playing', '8/8/8/4k3/8/8/5n2/2B1K3 w - - 0 1', [], [], []),
    ('bishops on one colour (dead position, engine plays on)', '8/8/8/4k3/8/8/4b3/2B1K3 w - - 0 1', [], [], []),
    ('king and pawn v king: playing', '8/8/8/4k3/8/8/4P3/4K3 w - - 0 1', [], [], []),
    ('capture leaving king v king', '8/8/8/4k3/8/8/4q3/4K3 w - - 0 1', ['e1e2'], [], []),
    ('capture leaving king and bishop v king', '8/8/8/4k3/8/8/3pB3/4K3 w - - 0 1', ['e1d2'], [], []),
    # checks and pins
    ('discovered check', '4k3/8/8/8/8/8/4N3/4RK2 w - - 0 1', ['e2c3'], [], []),
    ('double check: only king moves', '4k3/8/3b4/8/8/8/4N3/4RK2 w - - 0 1', ['e2d4'], [], []),
    ('check by a pawn', '8/8/8/3k4/8/2P5/8/4K3 w - - 0 1', ['c3c4'], [], []),
    ('pinned knight cannot move', '6k1/8/8/8/1b6/8/3N4/4K3 w - - 0 1', [], [], ['d2b3', 'd2f3']),
    ('pinned rook moves along the pin', '4r1k1/8/8/8/8/8/4R3/4K3 w - - 0 1', [], ['e2e8', 'e2e3'], ['e2d2']),
    ('king cannot capture a defended piece (mate)', '4k3/8/8/8/8/8/3qr3/3K4 w - - 0 1', [], [], ['d1d2', 'd1e2']),
    ('king cannot step along the checking line', '4k3/8/8/8/8/8/8/r3K3 w - - 0 1', [], [], ['e1d1', 'e1f1']),
]


def build_cases():
    out = []
    for name, fen, moves, has, hasnot in CASES:
        b = chess.Board(fen)
        for u in moves:
            m = chess.Move.from_uci(u)
            assert m in b.legal_moves, (name, u, b.fen())
            b.push(m)
        w = want(b)
        for u in has:
            assert u in w['legal'], (name, u)
        for u in hasnot:
            assert u not in w['legal'], (name, u)
        out.append({'name': name, 'fen': fen, 'moves': moves, 'want': w, 'has': has, 'hasnot': hasnot})
        print('%-72s status %d, %2d legal%s' % (name, w['status'], len(w['legal']), '  (fide dead)' if w['fide_dead'] else ''))
    return out


def pick(b, rng, hist):
    ms = list(b.legal_moves)
    special = [m for m in ms if b.is_castling(m) or b.is_en_passant(m) or m.promotion]
    if special and rng.random() < 0.8:
        return rng.choice(special)
    # undo the move two plies ago when possible (repetitions)
    if len(b.move_stack) >= 2 and rng.random() < hist:
        last = b.move_stack[-2]
        back = chess.Move(last.to_square, last.from_square)
        if back in ms and not b.is_capture(back):
            return back
    checks = [m for m in ms if b.gives_check(m)]
    if checks and rng.random() < 0.15:
        return rng.choice(checks)
    caps = [m for m in ms if b.is_capture(m)]
    if caps and rng.random() < 0.25:
        return rng.choice(caps)
    pawns = [m for m in ms if b.piece_type_at(m.from_square) == chess.PAWN]
    if pawns and rng.random() < 0.3:
        return rng.choice(pawns)
    return rng.choice(ms)


def build_games(n, seed):
    rng = random.Random(seed)
    games = []
    tally = {}
    for g in range(n):
        b = chess.Board()
        hist = [0.0, 0.3, 0.6][g % 3]
        plies = []
        while True:
            st = status(b)
            leg = legal_list(b)
            rec = [None, len(leg), fnv(' '.join(leg)), st, b.is_check()]
            plies.append(rec)
            if st or len(plies) > 600:
                break
            m = pick(b, rng, hist)
            for k, f in (('castle', b.is_castling), ('ep', b.is_en_passant)):
                if f(m):
                    tally[k] = tally.get(k, 0) + 1
            if m.promotion:
                k = 'promo_' + 'nbrq'[m.promotion - 2]
                tally[k] = tally.get(k, 0) + 1
            rec[0] = m.uci()
            b.push(m)
        tally['end_status%d' % st] = tally.get('end_status%d' % st, 0) + 1
        if b.is_insufficient_material() and not eng_insuf(b):
            tally['fide_dead_end'] = tally.get('fide_dead_end', 0) + 1
        games.append(plies)
    print('games', n, 'positions', sum(len(p) for p in games), tally)
    return games


if __name__ == '__main__':
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 300
    seed = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    data = {'cases': build_cases(), 'games': build_games(n, seed)}
    with open(OUT, 'w', encoding='utf-8') as f:
        json.dump(data, f, separators=(',', ':'))
    print('written', os.path.normpath(OUT))
