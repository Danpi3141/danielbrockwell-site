// Cross-check our KPvK table (WDL) against the project's data/kpk.bin (read only).
'use strict';
const fs = require('fs'), path = require('path');
const L = require('./lib');
const kb = fs.readFileSync(path.join(__dirname, '..', '..', 'data', 'kpk.bin'));
const T = L.loadTable('KPvK');
let n = 0, bad = 0;
for (let side = 0; side < 2; side++) for (let pr = 1; pr <= 6; pr++) for (let pf = 0; pf < 4; pf++) {
  const wp = pr * 8 + pf;
  for (let wk = 0; wk < 64; wk++) for (let bk = 0; bk < 64; bk++) {
    const v = T.val[((side * 64 + wk) * 64 + bk) * 64 + wp];
    if (v === 255) continue;
    const ours = (v !== 0 && ((v - 1) & 1) === (side === 0 ? 1 : 0)) ? 1 : 0; // White wins
    const slice = side * 24 + (pr - 1) * 4 + pf;
    const theirs = (kb[slice * 512 + wk * 8 + (bk >> 3)] >> (bk & 7)) & 1;
    n++; if (ours !== theirs) bad++;
  }
}
console.log(`KPK vs data/kpk.bin: ${n} legal positions (files a-d), ${bad} disagreements`);
