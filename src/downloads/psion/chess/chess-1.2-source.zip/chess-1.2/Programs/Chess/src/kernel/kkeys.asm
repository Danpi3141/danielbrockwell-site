; ---------------------------------------------------------------------
; Keys
; ---------------------------------------------------------------------

; key_wait: A = frames (50 ms) to wait, 0 = until a key. Out: B = key, or 0
; if the time ran out. The packs stay powered for PACK_IDLE frames after
; the last read, so key presses in a menu don't wait for a pack to power
; up (about 50 ms); then they are switched off and the wait carries on
; asleep in KB$GETK, which also switches the Organiser off after its idle
; time and carries on when it comes back on.
PACK_IDLE = 60                  ; 3 s

key_wait:
        staa kv_left
        tst  kv_pkok
        beq  .off               ; packs already off
        ldaa #PACK_IDLE
        tst  kv_left
        beq  .t                 ; forever: time the packs out first
        cmpa kv_left
        bls  .t
        ldaa kv_left            ; a shorter wait than the pack time-out
.t:     psha
        bsr  .timed
        pula
        tstb
        bne  kw_ret             ; a key
        tst  kv_left
        beq  .pkoff             ; waiting forever: switch the packs off and sleep
        nega
        adda kv_left            ; frames still to wait
        staa kv_left
        beq  kw_ret             ; time ran out (B = 0)
.pkoff: os   PK$PKOF
        clr  kv_pkok
.off:   ldaa kv_left
        bne  .tm
        bsr  kw_sleep           ; until a key, switching off after the Organiser's idle time
        bra  kw_ret
.tm:    bsr  .timed
kw_ret: rts                     ; every way out (the test harness stops here)

; wait up to A frames for a key: B = key or 0
key_wait.timed: staa kv_t0
        ldaa TMW_FRAM+1
        staa kv_t0+1
.l:     ldx  TMW_TCNT           ; no switching off in a timed wait (a clock may be running)
        stx  TMW_TOUT
        os   KB$TEST
        tstb
        bne  .got
        ldaa TMW_FRAM+1
        suba kv_t0+1
        cmpa kv_t0
        bhs  .out
        slp                     ; until the next interrupt
        bra  .l
.got:   os   KB$GETK            ; take it out of the buffer
        rts
.out:   clrb
        rts

; Wait for a key with no time limit. The ROM's KB$GETK would switch the
; Organiser off after its idle time, but on switching on again the OS
; puts back its own copy of the screen, not the game's. So the idle time
; (TMW_TCNT seconds, 0 = never) is counted here, BT$SWOF switches off,
; and when it returns (ON pressed) the whole screen and the glyphs are
; sent again. B = the key.
kw_sleep:
        clr  kv_aidle
        clr  kv_aidle+1
        ldaa TMW_FRAM+1
        staa kv_afr
.l:     ldx  TMW_TCNT           ; the OS's own count-down never gets there
        stx  TMW_TOUT
        os   KB$TEST
        tstb
        bne  .key
        slp
        ldaa TMW_FRAM+1
        cmpa kv_afr
        beq  .l
        staa kv_afr
        ldd  kv_aidle           ; frames idle
        addd #1
        std  kv_aidle
        ldx  TMW_TCNT
        beq  .l                 ; never switch off
        xgdx                    ; seconds -> frames: * 20
        asld
        asld
        std  kv_t0
        asld
        asld
        addd kv_t0
        subd kv_aidle
        bhi  .l
        os   BT$SWOF            ; off; back here when ON is pressed
        ldaa #$FF               ; the LCD lost everything: send it all again
        staa kv_gdirty
        jsr  scr_flush
        bra  kw_sleep
.key:   os   KB$GETK
        rts

; B = key; a to z become A to Z
key_upper:
        cmpb #'a'
        blo  .x
        cmpb #'z'
        bhi  .x
        subb #32
.x:     rts
