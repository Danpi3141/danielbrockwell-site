'use strict';
// Whole games on the assembler engine (both sides), compared with the JS reference move by move.
// Usage: node t_game.js "<fen>" nodesPerMove maxPlies
const { Harness } = require('./harness.js');
const { Engine, legalMoves, uciStr } = require('../../ref/search.js');
const fen = process.argv[2] || 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
const NODES = +(process.argv[3] || 300), MAXP = +(process.argv[4] || 80);
const h = new Harness();
const e = new Engine();
e.ttInit(8);
h.setFen(fen); e.setFen(fen);
h.call('e_clrtt');
let bad = 0, ply = 0, result = 'unfinished';
const line = [];
for (; ply < MAXP; ply++) {
  const st = h.call('eng_status').a;
  if (st) { result = ['', 'checkmate', 'stalemate', 'fifty moves', 'threefold', 'too little material'][st]; break; }
  h.m.write(h.a('e_nlim'), [(NODES >> 16) & 255, (NODES >> 8) & 255, NODES & 255]);
  h.pokew('e_tlim', 0); h.poke('e_maxd', 0); h.pokew('e_margin', 0);
  h.call('eng_think', 0, 0, 921600 * 3600);
  const af = h.peek('e_bestf'), at = h.peek('e_bestt');
  const j = e.think(NODES);
  if (af !== j.f || at !== j.t) { bad++; console.log(`FAIL ply ${ply}: asm ${uciStr(e, af, at)} js ${uciStr(e, j.f, j.t)}`); break; }
  line.push(uciStr(e, af, at));
  h.call('eng_play', af, at); e.make(af, at); e.ply = 0;
  if (e.half === 0) e.keys.length = 0;
}
console.log(line.join(' '));
console.log(`${ply} plies, ${result}`);
console.log(bad ? 'FAILED' : 'game matches the reference');
process.exit(bad ? 1 : 0);
