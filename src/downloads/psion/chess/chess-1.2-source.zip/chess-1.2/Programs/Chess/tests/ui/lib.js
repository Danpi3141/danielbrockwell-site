'use strict';
// Shared helpers for the headless UI tests: boot an LZ64, load the game pack, run CHESS.
const path = require('path');
const fs = require('fs');
const { Machine } = require('../../tools/emu.js');

const ROOT = path.resolve(__dirname, '..', '..');
const BUILD = path.join(ROOT, 'build', 'game');

// read once per process, so a rebuild while a long test runs doesn't change them under it
let symCache = null;
function syms() {
  if (!symCache) symCache = JSON.parse(fs.readFileSync(path.join(BUILD, 'kernel.sym.json'), 'utf8'));
  return symCache;
}

// Boots, inserts the pack in B:, runs CHESS and waits for the board.
function start(opts) {
  opts = opts || {};
  const m = new Machine({ rom: '46a-lz64.rom', ram: 64 });
  m.boot();
  m.insertPack(opts.opk || path.join(BUILD, 'CHESS.opk'), 0);
  m.runProc('CHESS', 'B');
  m.runSeconds(opts.wait || 4);
  return m;
}

// The array's address (found from the kernel tag "CHK1" at offset 3). RAM can also hold a stale
// copy of the kernel's start: when A: is in the main RAM and a file can't grow, the OS moves the
// memory above the free gap down and back, leaving a copy of its first bytes in the gap. So the
// real kernel is the copy whose kv_base (set at start-up to the array's address) is its own address.
// While the OS is inside a file call it can have other memory where the array is (its memory
// mover and the LZ64's banks); the kernel never sees that, but a test reading at that moment
// does: so if no copy checks out, run on a little and look again.
function base(m) {
  if (m._base) return m._base;
  const off = syms().kv_base[0];
  for (let tries = 0; tries < 40; tries++) {
    for (let a = 0x2000; ; a++) {
      a = m.find([0x43, 0x48, 0x4B, 0x31], a, 0x8000);
      if (a < 0) break;
      if (m.peekw(a - 3 + off) === a - 3) { m._base = a - 3; return m._base; }
    }
    m.runSeconds(0.05);
  }
  throw new Error('kernel not found in RAM');
}
function sym(m, name) {
  const s = syms()[name];
  if (!s) throw new Error('no symbol ' + name);
  return s[1] === 'abs' ? s[0] : base(m) + s[0];      // (some are in zero page and the OS's buffers)
}
function peekSym(m, name, n) { return m.read(sym(m, name), n || 1); }

// Wait until the screen contains text (or a predicate holds), up to s seconds
function waitFor(m, pred, s) {
  const f = typeof pred === 'string' ? () => m.screenText().includes(pred) : pred;
  for (let i = 0; i < (s || 10) * 10; i++) { if (f()) return true; m.runSeconds(0.1); }
  return false;
}

function check(cond, msg, m) {
  if (!cond) {
    const scr = m ? '\n' + m.screenText() : '';
    throw new Error('FAIL: ' + msg + scr);
  }
  console.log('ok   ' + msg);
}

// type keys: letters/digits; specials as {k:'EXE'}
function keys(m, list, gap) {
  for (const k of list) {
    if (k.length > 1) m.press(k, 3, gap === undefined ? 6 : gap);
    else m.press(k.toUpperCase(), 3, gap === undefined ? 6 : gap);
  }
}

// wait until the game sits in key_wait with the board overlay loaded (the player's turn), up to s seconds
function idle(m, s) {
  const kw = sym(m, 'key_wait');
  const res = sym(m, 'kv_res');
  let same = 0, last = '';
  for (let i = 0; i < (s || 60) * 4; i++) {
    m.runSeconds(0.25);                       // (exactly five 50 ms ticks: the phase never moves, so look a little later if it is
    for (let j = 0; j < 8 && !m.dbg.sleeping(); j++) m.run(4000);      // awake just then)
    const t = m.screenText();
    if (m.peek(res) === 1 && m.dbg.sleeping && m.dbg.sleeping() && t === last) { if (++same >= 5) return true; }
    else same = 0;
    last = t;
  }
  return false;
}

module.exports = { idle, start, base, sym, peekSym, waitFor, check, keys, ROOT, BUILD, syms };
