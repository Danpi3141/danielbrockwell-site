; ---------------------------------------------------------------------
; The resident game core: the main loop, the engine calls, the record,
; take back, the computer's move. Everything else is in slot-A overlays:
; OV_BOARD (drawing, move entry, notation, clocks) and OV_GAME (book,
; saving). The engine's scratch is slot A too, so after any engine call
; that uses it the next ov_call loads the overlay again.
;
; The game record (in the save file, A:CHESSAV) holds 3 bytes a ply: from, to, info (bits 0-2
; piece type, 3 capture, 4 check, 5 mate, 6-7 disambiguation: 1 file,
; 2 rank, 3 both).
; ---------------------------------------------------------------------
MAXPLY  = 250                   ; up to 125 moves by each side
LM_MAX  = 127                   ; legal moves kept for the screens (lm_buf); 2*LM_MAX must stay < 256 (80 until 16 Nov)
SV_VER  = 3                     ; the save file (screens/ksave.asm)
NCHUNK  = 25
CPLY    = 10
HDR_LEN = gs_end-gs_first

R_WHITE = 1                     ; g_result
R_BLACK = 2
R_DRAW  = 3
Y_MATE  = 1                     ; g_reason
Y_STALE = 2
Y_FIFTY = 3
Y_REP   = 4
Y_MAT   = 5
Y_RESIGN = 6
Y_TIME  = 7
Y_AGREED = 8
Y_FULL  = 9

; OV_BOARD entries
B_HUMAN = 0
B_LOOK  = 1
B_SHOW  = 2
B_BLINK = 3
B_CLKMOVED = 4
B_CLKSTART = 7
B_SHARE = 9
B_PACE  = 10
B_TURN  = 11
; OV_GAME entries
G_SAVE  = 0
G_LOAD  = 1
G_FOLLOW = 2
G_PICK  = 3
G_BKRESET = 4
G_NEW   = 5
G_PLY   = 6
G_GETPLY = 7
G_CHUNK = 8
G_STRIP = 9
G_INFO  = 10
G_CLKBACK = 11
G_FLUSH = 12
G_CLKNEW = 13                   ; the clocks from the settings (the board overlay's B_CLKNEW until 17 Nov)
G_HINT  = 14                    ; the hint's text (the board overlay's B_HINT until 17 Nov)

; human_turn's answers
H_MOVE  = 0
H_MENU  = 1
H_BACK  = 2
H_HINT  = 3
H_FLAG  = 4

lv_secs: fcb  1,1,2,3,3,10,30,255   ; (level 5 3 s and level 8 255 s since 16 Nov: were 5 and 100)
lv_marg: fdb  100,53,25,14          ; levels 1-4: evaluation noise k, within +-8k cp (17 Nov; was a margin pass: 300,150,70,30 cp)
tm_maxlv: fcb  8,6,6,7,7,8       ; the highest level each timing allows

; A = OV_BOARD entry
board:  tab
        ldaa #OV_BOARD
        jmp  ov_call
; A = OV_GAME entry
gamex:  tab
        ldaa #OV_GAME
        jmp  ov_call
save:   ldaa #G_SAVE
        bra  gamex
show:   ldaa #B_SHOW
        bra  board

gm_start:
        ldaa #G_LOAD
        bsr  gamex              ; C=0: settings and game loaded
        bcc  .old
        jsr  set_defaults
        jmp  new_game
.old:   jmp  replay

set_defaults:
        ldx  #st_first
        ldd  #st_last-st_first  ; A = 0, B = the count (UT$FILL)
        os   UT$FILL
        ldaa #7
        staa st_level           ; level 7: 30 s a move
        ldaa #1
        staa st_resign
        ldaa #5
        staa st_cmin
        staa st_cmin+1
        rts

new_game:
        ldaa st_colour
        cmpa #2
        bne  .c
        ldaa g_human            ; alternate: the other colour from last time
        eora #8
        bra  .s
.c:     ldab #8
        mul
        tba
.s:     staa g_human
        clr  g_setup
        clr  g_bad
        ldaa #G_CLKNEW
        jsr  gamex
; a game from the start (or g_spos when g_setup): no moves yet
game_from_start:
        clr  g_n
        clr  g_result
        clr  g_reason
        ldaa #G_NEW             ; a fresh save file (the record lives there)
        jsr  gamex
        jmp  replay

; set the engine to the game's start, then play the record's g_n plies
replay: clr  v_flip             ; the board turns with the player's colour
        tst  g_human
        beq  .r0
        inc  v_flip
.r0:    tst  g_setup
        beq  .std
        jsr  spos_copy
        ldx  #eng_setup
        jsr  ecall
        bra  .moves
.std:   ldx  #eng_reset
        jsr  ecall
.moves: ldaa #G_BKRESET
        bsr  gamex
        clr  rp_i
; (game review enters here: rp_i a chunk's first ply, the board at it, g_n the ply to stop at)
rp_loop:
.l:     ldaa rp_i               ; a chunk of the record: read it, follow the book
        cmpa g_n
        beq  .done
        staa sp_i
        ldab rv_on              ; game review: bit 0 keeps the position at the chunk's start,
        bitb #RVF_SNAP          ; bit 2 has the chunk in rp_buf already
        beq  .l1
        ldaa #OV_REVIEW
        ldab #RV_SNAP
        jsr  ov_call
        ldab rv_on
.l1:    bitb #RVF_HELD
        bne  .l2
        ldaa #G_CHUNK
        jsr  gamex
        bcs  .bad
.l2:    ldx  #rp_buf
        stx  rp_p
        ldaa #CPLY
        staa rp_e
.p:     ldx  rp_p               ; then play its plies (the engine overwrites slot A)
        ldd  0,x
        std  g_last
        ldaa 2,x
        staa g_last+2
        ldd  0,x
        ldx  #eng_play
        jsr  ecall
        ldx  rp_p
        inx
        inx
        inx
        stx  rp_p
        inc  rp_i
        ldaa rp_i
        cmpa g_n
        beq  .done
        dec  rp_e
        bne  .p
        bra  .l
.bad:   ldaa rp_i               ; the record is short: keep what was read
        staa g_n
.done:  clrb                    ; show the half of the last move (or the player's own)
        tst  g_n
        beq  .h
        ldab g_last+1
        andb #$77
.h:     jsr  half_of
        ldab rv_on              ; a game review's step: only whether in check (the legal moves
        bitb #RVF_STEP          ; and the status come when it ends; 0.15 s a step)
        beq  .pu
        ldx  #eng_check
        jsr  ecall
        staa g_chk
        bra  .st
.pu:    jsr  pos_update
.st:    ldaa #G_STRIP
        jmp  gamex

; g_spos -> e_board, e_side, e_castle, e_ep, e_half
spos_copy:
        ldx  #e_board
        ldd  #128               ; A = 0, B = 128 (UT$FILL)
        os   UT$FILL
        clrb
.c:     stab rp_i               ; square of n: (n & $38) * 2 + (n & 7)
        tba
        anda #$38
        asla
        andb #7
        aba
        staa rp_e
        ldab rp_i
        ldx  #g_spos
        abx
        ldaa 0,x
        ldab rp_e
        ldx  #e_board
        abx
        staa 0,x
        ldab rp_i
        incb
        cmpb #64
        bne  .c
        ldaa g_spos+64
        staa e_side
        ldaa g_spos+65
        staa e_castle
        ldaa g_spos+66
        staa e_ep
        ldaa g_spos+67
        staa e_half
        rts

; B = square: v_half = the half that holds it, as seen
half_of:
        clra
        cmpb #$40
        blo  .n
        inca                    ; ranks 5-8
.n:     eora v_flip
        staa v_half
        rts

; ---------------------------------------------------------------------
; the main loop
; ---------------------------------------------------------------------
gm_main:
        tst  g_result
        bne  .over
        ldaa g_stat             ; mate, stalemate, a draw by rule
        beq  .play
        jsr  stat_result
        jsr  save
        ldx  #snd_end
        jsr  snd_play
        bra  gm_main
.play:  tst  g_mode             ; 1 = two players: no computer
        bne  .human
        ldaa e_side
        cmpa g_human
        beq  .human
        jsr  comp_move
        bra  gm_main
.human: ldaa #B_HUMAN
        jsr  board              ; A = H_*
        cmpa #H_MOVE
        bne  .h1
        ldaa hu_f
        ldab hu_t
        jsr  play_move
        ldaa #B_BLINK
        jsr  board
        tst  g_chk
        beq  gm_main
        ldx  #snd_check
        jsr  snd_play
        bra  gm_main
.h1:    cmpa #H_MENU
        bne  .h2
        jsr  do_menu
        bra  gm_main
.h2:    cmpa #H_BACK
        bne  .h3
        jsr  take_back
        bra  gm_main
.h3:    cmpa #H_HINT
        bne  .h4
        jsr  hint
        bra  gm_main
.h4:    jsr  save               ; the flag fell
        bra  gm_main
.over:  jsr  show
        ldaa #OV_RESULT
        clrb
        jsr  ov_call            ; A: 0 look at the board, 1 menu
        tsta
        bne  .menu
        ldaa #B_LOOK
        jsr  board              ; A: H_BACK or H_MENU
        cmpa #H_BACK
        bne  .menu
        jsr  take_back
        bra  gm_main
.menu:  jsr  do_menu
        bra  gm_main

; after a move: the legal list (copied to lm_buf), the status, check
pos_update:
        ldx  #eng_legal
        jsr  ecall
        ldab e_lmn
        cmpb #LM_MAX
        bls  .n
        ldab #LM_MAX
.n:     stab lm_n
        aslb                    ; its bytes, into lm_buf with the ROM's UT$CPYB (count in UTW_S0;
        clra                    ; none: nothing done)
        std  T0
        ldx  #e_lm
        ldd  #lm_buf
        os   UT$CPYB
        ldx  #eng_status
        jsr  ecall
        staa g_stat
        ldx  #eng_check
        jsr  ecall
        staa g_chk
        rts

; g_stat -> g_result, g_reason
stat_result:
        ldaa g_stat
        cmpa #1
        bne  .draw
        ldab #R_WHITE           ; checkmate: the side not to move wins
        tst  e_side
        bne  .w
        ldab #R_BLACK
.w:     stab g_result
        ldaa #Y_MATE
        staa g_reason
        bra  auto_adj
.draw:  ldab #R_DRAW
        stab g_result
        adda #Y_STALE-2         ; 2 stalemate .. 5 material -> Y_STALE..Y_MAT
        staa g_reason
        rts

; Auto level: up after the player wins, down after a loss (mate, either side resigning, a
; flag falling; not a draw)
auto_adj:
        tst  st_auto
        beq  .x
        ldab g_result
        cmpb #R_DRAW
        beq  .x
        ldaa #R_WHITE
        tst  g_human
        beq  .h
        ldaa #R_BLACK
.h:     cba
        bne  .down
        ldaa st_level
        cmpa #8
        beq  .x
        inc  st_level
        rts
.down:  ldaa st_level
        cmpa #1
        beq  .x
        dec  st_level
.x:     rts

; hu_f, hu_t: C=0 if legal (any promotion) - lm_buf
lm_find:
        ldab lm_n
        beq  .no
        ldx  #lm_buf
.l:     ldaa 0,x
        cmpa hu_f
        bne  .n
        ldaa 1,x
        anda #$77
        cmpa hu_t
        beq  .yes
.n:     inx
        inx
        decb
        bne  .l
.no:    sec
        rts
.yes:   clc
        rts

; ---------------------------------------------------------------------
; play_move: A = from, B = to (legal). Records it, plays it, follows the
; book, charges the clock, saves.
; ---------------------------------------------------------------------
play_move:
        staa pm_f
        stab pm_t
        ldab g_n
        cmpb #MAXPLY
        blo  .room
        ldaa #R_DRAW
        staa g_result
        ldaa #Y_FULL
        staa g_reason
        rts
.room:  ldaa #G_INFO            ; the notation facts (before the move)
        jsr  gamex
        tst  im_on              ; (not while importing: the clocks start afresh)
        bne  .nclk
        ldaa #B_CLKMOVED        ; the mover's clock
        jsr  board
.nclk:
        ldaa pm_f
        ldab pm_t
        ldx  #eng_play
        jsr  ecall
        jsr  pos_update
        ldaa pm_i               ; check and mate go into the record
        tst  g_chk
        beq  .nc
        oraa #$10
        ldab g_stat
        cmpb #1
        bne  .nc
        oraa #$20
.nc:    staa g_last+2
        staa sp_e+2
        ldaa pm_f
        staa g_last
        staa sp_e
        ldaa pm_t
        staa g_last+1
        staa sp_e+1
        ldaa g_n
        staa sp_i
        inc  g_n
        ldaa #OV_GAME           ; follow it in the book; save it
        jsr  ov_load
        ldaa pm_f
        ldab pm_t
        jsr  SLOTA+3*G_FOLLOW
        ldaa #G_PLY             ; into the save file, with the header
        jsr  gamex
        ldab pm_t               ; the letter view follows the move
        andb #$77
        jsr  half_of
        ldaa #G_STRIP
        jmp  gamex

; ---------------------------------------------------------------------
; the computer's move
; ---------------------------------------------------------------------
comp_move:
        ldd  TMW_FRAM           ; the computer's turn starts (pace_wait counts from here)
        std  cm_t0
        ldaa #B_CLKSTART
        jsr  board
        ldaa #G_PICK
        jsr  gamex              ; C=0: A, B = a book move
        bcs  .kpk
.bk:    staa cm_f
        stab cm_t
        clra                    ; book moves come within a few seconds
        bra  .wait
.kpk:   ldaa #OV_KPK            ; king and pawn v king: the distance table's move
        clrb
        jsr  ov_call
        bcc  .bk
.think: jsr  level_now          ; A = the level in force
        deca
        ldx  #lv_secs
        tab
        abx
        ldab 0,x
        ldaa #20
        mul
        std  e_tlim
        ldaa #B_SHARE           ; D = frames the clock allows (0 = no clock)
        jsr  board
        std  cm_share
        beq  .nolim
        subd e_tlim
        bcc  .nolim
        ldd  cm_share           ; the clock allows less than the level
        std  e_tlim
.nolim: ldd  #0
        std  e_margin
        jsr  level_now
        cmpa #4
        bhi  .m
        deca
        asla
        ldx  #lv_marg
        tab
        abx
        ldd  0,x
        std  e_margin
.m:     jsr  think
        ldaa e_bestf
        staa cm_f
        ldab e_bestt
        stab cm_t
        oraa e_bestt
        bne  .res
        rts                     ; no move (cannot happen: the status said playing)
.res:   jsr  resign_chk
        tst  g_result
        beq  .w1
        rts
.w1:    ldaa #1
.wait:  staa pw_a
        ldaa #B_PACE            ; pw_a: 0 a book move, 1 after thinking
        jsr  board
        tst  g_result           ; (a flag may fall while it waits)
        bne  .x
        ldaa cm_f
        ldab cm_t
        jsr  play_move
        ldaa #B_BLINK
        jsr  board
        ldx  #snd_moved
        tst  g_chk
        beq  .s
        ldx  #snd_check
.s:     jsr  snd_play
        ldaa #B_CLKSTART        ; the player's clock starts after the blink
        jmp  board
.x:     rts

; the level in force: the setting, capped by what the clock allows
level_now:
        ldaa st_level
        ldab st_timing
        ldx  #tm_maxlv
        abx
        cmpa 0,x
        bls  .x
        ldaa 0,x
.x:     rts

; the engine resigns after three moves in a row at worse than -9 pawns (levels 1-4: worse than
; -9 pawns - 8k, as their evaluation noise moves a score by up to 8k; 17 Nov)
resign_chk:
        tst  st_resign
        beq  .x
        ldd  e_margin
        asld
        asld
        asld
        addd #900
        addd e_score            ; score + 900 + 8k >= 0: play on
        bge  .ok
        inc  g_bad
        ldaa g_bad
        cmpa #3
        blo  .x
        ldab #R_WHITE           ; the computer resigns: the player wins
        tst  g_human
        beq  .w
        ldab #R_BLACK
.w:     stab g_result
        ldaa #Y_RESIGN
        staa g_reason
        jsr  auto_adj           ; (Auto: a win; 17 Nov, it was missed)
        jmp  save
.ok:    clr  g_bad
.x:     rts

; e_tlim set (and e_margin): think, showing the depth and seconds
think:  clr  e_nlim
        clr  e_nlim+1
        clr  e_nlim+2
        clr  e_maxd
        ldd  e_tlim             ; a failing-low search may take as long again, but at most an
        std  e_tadd             ; eighth of the side to move's clock (17 Nov)
        tst  st_timing
        beq  .ta
        ldx  #g_clk
        tst  e_side
        beq  .tc
        inx
        inx
.tc:    ldd  0,x
        lsrd
        lsrd
        lsrd
        subd e_tadd
        bcc  .ta
        addd e_tadd
        std  e_tadd
.ta:
        ldd  TMW_FRAM
        std  th_t0
        ldx  #eng_think
        jmp  ecall

; called by the engine every ~256 nodes and after each depth (A = depth
; done). Shows the depth and the seconds in the strip (kv_cells keeps
; the board drawn before); C=1 = stop now (a key). Touches nothing of
; the engine's.
think_poll:
        staa th_d
        ldx  TMW_TCNT           ; auto switch-off is held off while it thinks
        stx  TMW_TOUT
        ldx  #st_p
        ldaa #3
        staa 0,x
        ldd  #$4420             ; "D "
        std  1,x
        ldaa th_d
        cmpa #10
        blo  .one
        ldab th_d
        clra
        jsr  num_str
        ldd  kv_nbuf+1
        std  st_p+2
        bra  .sec
.one:   adda #'0'
        staa 3,x
.sec:   ldd  TMW_FRAM           ; seconds = frames / 20
        subd th_t0
        ldx  #20
        jsr  udiv
        jsr  num_str
        ldx  #st_p+4
        ldab kv_nbuf            ; "12s", "123" or "99+"
        cmpb #3
        bls  .fit
        ldd  #$3939             ; "99"
        std  1,x
        ldaa #'+'
        staa 3,x
        ldaa #3
        staa 0,x
        bra  .tx
.fit:   stab 0,x
        ldaa kv_nbuf+1
        staa 1,x
        ldaa kv_nbuf+2
        staa 2,x
        ldaa kv_nbuf+3
        staa 3,x
        cmpb #3
        beq  .tx
        incb                    ; room for the "s"
        stab 0,x
        abx
        ldaa #'s'
        staa 0,x
.tx:    clr  st_p+8
        jsr  strip_cells
        jsr  scr_flush
        os   KB$TEST
        tstb
        beq  .go
        os   KB$GETK
        sec
        rts
.go:    clc
        rts

; ---------------------------------------------------------------------
; strip_cells: the strip (st_p: three parts and the turn, 4 bytes each,
; length-prefixed) into kv_cells at its column for the layout. A part
; shorter than 3 starts one column in, clear of the rank number.
; ---------------------------------------------------------------------
strip_cells:
        ldab #9
        tst  st_layout
        beq  .c
        ldab #17                ; (split board and real-board mode)
.c:     stab sc_col
        clr  sc_r
        ldx  #st_p
.r:     stx  sc_p
        ldaa sc_r
        ldab #20
        mul
        addb sc_col
        ldx  #kv_cells
        abx
        ldaa #' '
        staa 0,x
        staa 1,x
        staa 2,x
        stx  sc_q
        ldx  sc_p
        ldab 0,x
        beq  .n
        cmpb #3
        bhs  .full
        pshx
        ldx  sc_q
        inx
        stx  sc_q
        pulx
.full:  inx
        ldaa 0,x
        pshx
        ldx  sc_q
        staa 0,x
        inx
        stx  sc_q
        pulx
        decb
        bne  .full
.n:     ldx  sc_p
        ldab #4
        abx
        inc  sc_r
        ldaa sc_r
        cmpa #4
        bne  .r
        rts

; X = length-prefixed text: becomes the message line (padded with spaces)
msg_set:
        pshx                    ; (the ROM's UT$FILL and UT$CPYB since 17 Nov)
        ldx  #msg_t
        ldd  #$2014             ; 20 spaces
        os   UT$FILL
        pulx
        ldab 0,x                ; the text, at most 20
        cmpb #20
        bls  .n
        ldab #20
.n:     clra
        std  T0                 ; (UTW_S0: the count)
        inx
        ldd  #msg_t
        os   UT$CPYB
        ldaa #1
        staa msg_on
        rts

; the length-prefixed message after the jsr; returns after it
msg_pri:
        pulx
        pshx
        bsr  msg_set
        pulx
        ldab 0,x
        abx
        inx
        jmp  0,x

; ---------------------------------------------------------------------
; take back: the player's last move and its reply
; ---------------------------------------------------------------------
take_back:
        ldaa g_n
        beq  .x
        tst  g_nosv             ; no save file: no record to replay
        bne  .x
        clr  g_result
        clr  g_reason
        dec  g_n
        tst  g_mode
        bne  .one
        ; undo until it is the player's turn again
        jsr  replay
        ldaa e_side
        cmpa g_human
        beq  .done
        ldaa g_n
        beq  .done
        dec  g_n
.one:   jsr  replay
.done:  ldaa #G_CLKNEW          ; the clocks as they were when the position came
        jsr  gamex
        ldaa #G_CLKBACK         ; (and the side to move's clock starts)
        jsr  gamex
        jmp  save
.x:     rts

; ---------------------------------------------------------------------
; the menu (overlay), and what it asks for
; ---------------------------------------------------------------------
do_menu:
        ldaa #OV_MENU
        clrb
        jsr  ov_call            ; A = command: M_NEW (1) .. M_LAST, or none
        deca
        cmpa #M_LAST
        bhs  .x
        asla                    ; (a jump table since 17 Nov: was a compare for each, 34 bytes more)
        tab
        ldx  #.tab
        abx
        ldx  0,x
        jmp  0,x
.x:     rts
.tab:   fdb  new_game           ; M_NEW
        fdb  take_back          ; M_BACK
        fdb  hint               ; M_HINT
        fdb  .flip              ; M_FLIP
        fdb  .set               ; M_SETTINGS
        fdb  .list              ; M_LIST
        fdb  .resign            ; M_RESIGN
        fdb  offer_draw         ; M_DRAW
        fdb  .setup             ; M_SETUP
        fdb  .exit              ; M_EXIT
        fdb  .level             ; M_LEVEL
        fdb  .pgn               ; M_PGN
        fdb  im_game            ; M_IMPORT
        fdb  review             ; M_REVIEW
        if   SPEEDTEST
        fdb  sp_test            ; M_SPEED
        endif
.flip:  ldaa g_human            ; play the other colour from here
        eora #8
        staa g_human
        ldaa v_flip
        eora #1
        staa v_flip
        jmp  save
.level: ldab #1                 ; settings, starting at the level
        bra  .s2
.set:   clrb
.s2:    ldaa #OV_SET
        jsr  ov_call
        ldaa #G_STRIP           ; the notation may have changed
        jsr  gamex
        jmp  save
.list:  ldaa #OV_LIST
        clrb
        jmp  ov_call
.pgn:   ldaa #OV_LIST           ; export: the move list's entry 1
        ldab #1
        jmp  ov_call
.resign: ldab #R_BLACK          ; the player resigns
        tst  g_human
        beq  .r
        ldab #R_WHITE
.r:     stab g_result
        ldaa #Y_RESIGN
        staa g_reason
        jsr  auto_adj
        jmp  save
.setup: clrb                    ; entry 0: start from the board
.su:    ldaa #OV_SETUP
        jsr  ov_call            ; C=0: g_spos holds a new position
        bcs  .back
        jsr  spos_copy
        ldx  #eng_setup         ; the engine checks it
        jsr  ecall
        bcc  .sok
        staa rp_e               ; refused: back to the set-up with the reason
        ldab #1
        bra  .su
.back:  jmp  replay             ; given up: the game as it was
.sok:   ldaa #1
        staa g_setup
        jmp  game_from_start
.exit:  jsr  save
        ldab #E_OK
        jmp  quit

; ---------------------------------------------------------------------
; Import a game (A:GAMEn, made by tools/pgn2psion.py): OV_IMPORT chooses
; the file and reads its start; each move is then played as a typed one
; would be, so the record, the move list and take back all have it. The
; player takes over the side to move. A move that isn't legal stops it.
; ---------------------------------------------------------------------
im_game:
        ldaa #OV_IMPORT
        clrb
        jsr  ov_call            ; C=1: cancelled
        bcs  .x
        tst  g_setup
        beq  .new
        jsr  spos_copy
        ldx  #eng_setup         ; the engine checks the position
        jsr  ecall
        bcc  .new
        clr  g_setup            ; refused: a new game instead
        jsr  new_game
        jsr  msg_pri
        fcl  "BAD POSITION IN FILE"
        rts
.new:   ldaa #G_CLKNEW
        jsr  gamex
        clr  g_bad
        jsr  game_from_start
        ldaa #1                 ; plies collect in the TT's RAM (sv_bulk)
        staa im_on
        ldx  e_tt
        ldaa #$FF
        staa 0,x
.l:     tst  g_result
        bne  .end
        tst  g_stat
        bne  .end
        ldaa #OV_IMPORT
        ldab #1
        jsr  ov_call            ; C=0: the next move
        bcs  .end
        jsr  lm_find
        bcs  .ill
        ldaa hu_f
        ldab hu_t
        orab im_pro
        jsr  play_move
        bra  .l
.ill:   jsr  msg_pri
        fcl  "ILLEGAL MOVE IN FILE"
.end:   clr  im_on
        ldaa #G_FLUSH           ; the last chunk, then a clean TT
        jsr  gamex
        ldx  #eng_ttinit
        jsr  ecall
        ldaa e_side             ; the player takes over the side to move
        staa g_human
        clr  v_flip
        tsta
        beq  .s
        inc  v_flip
.s:     jmp  save
.x:     rts

        if   SPEEDTEST
; ---------------------------------------------------------------------
; TEMPORARY (SPEEDTEST): the menu's SPEED TEST, for the first runs on the
; Organiser. From the position on the board: the engine searches 1,000
; positions; then 10 overlay loads from the pack; then 10 book look-ups.
; Each is timed by the 50 ms frame counter; OV_LIST entry 2 shows them.
; ---------------------------------------------------------------------
sp_test:
        clra
        clrb
        std  e_tlim
        std  e_margin
        staa e_maxd
        staa e_nlim             ; 1,000 positions
        ldd  #1000
        std  e_nlim+1
        ldd  TMW_FRAM
        std  sp_t0
        std  th_t0
        ldx  #eng_think
        jsr  ecall
        ldd  TMW_FRAM
        subd sp_t0
        std  sp_eng             ; frames for the search
        ldd  e_nodes+1
        std  sp_nodes
        ldd  TMW_FRAM           ; 10 overlay loads (each from the pack)
        std  sp_t0
        ldab #10
.ov:    pshb
        clr  kv_res
        ldaa #OV_MENU
        jsr  ov_load
        pulb
        decb
        bne  .ov
        ldd  TMW_FRAM
        subd sp_t0
        std  sp_ov
        ldd  TMW_FRAM           ; 10 book look-ups
        std  sp_t0
        ldab #10
.bk:    pshb
        ldaa #G_PICK
        jsr  gamex
        pulb
        decb
        bne  .bk
        ldd  TMW_FRAM
        subd sp_t0
        std  sp_bk
        ldaa #OV_LIST           ; the results
        ldab #2
        jmp  ov_call
        endif

; a draw offer: the engine accepts when it judges the position level or worse
offer_draw:
        jsr  look2
        ldd  e_score            ; (the player's view: 0 or more = the engine is level or worse)
        bmi  .no
        ldaa #R_DRAW
        staa g_result
        ldaa #Y_AGREED
        staa g_reason
        jmp  save
.no:    jsr  msg_pri
        fcl  "DRAW DECLINED"
        jsr  show
        ldaa #40
        jsr  key_wait
        clr  msg_on
        rts

; ---------------------------------------------------------------------
; game review (19 Nov): OV_REVIEW does the keys, the text and the
; snapshots (kept in the table's RAM); this does what needs the engine,
; whose scratch is slot A. OV_REVIEW's RV_KEY says what to do.
; ---------------------------------------------------------------------
review: ldaa #OV_REVIEW
        ldab #RV_START
        jsr  ov_call            ; C=1: nothing to review (a message is left)
        bcs  .x
        jsr  show               ; (READING THE GAME)
        inc  rv_on              ; the replay keeps a snapshot at each chunk's start
        jsr  replay
        clr  rv_on
        ldaa #OV_REVIEW
        ldab #RV_MSG
        jsr  ov_call
.show:  jsr  show
        ldaa #OV_REVIEW
        ldab #RV_KEY
        jsr  ov_call
        tsta
        beq  .end               ; 0 leave (g_n and the table put back)
        deca
        bne  .c2
        ldx  #eng_setup         ; 1 go: a snapshot on the board, rp_i its ply,
        jsr  ecall              ;   g_n the ply to show, rv_on its flags
        jsr  rp_loop
        clr  rv_on
        bra  .show
.c2:    deca
        bne  .c3
        bsr  .tt                ; 2 analyse: the table above the snapshots
        jsr  look2
        ldaa #OV_REVIEW
        ldab #RV_BEST
        jsr  ov_call
        bra  .show
.c3:    deca
        beq  .show              ; 3 the board again (a message)
        bsr  .tt                ; 4 play from here (g_n and the result set), as a take back
        jsr  replay
        ldaa #G_CLKNEW
        jsr  gamex
        ldaa #G_CLKBACK
        jsr  gamex
        jmp  save
.end:   bsr  .tt
        jmp  replay
.tt:    ldx  #eng_ttinit        ; the table set up and cleared
        jmp  ecall
.x:     rts

; a 2-second look at the position (no margin)
look2:  ldd  #40
        std  e_tlim
        ldd  #0
        std  e_margin
        jsr  show
        jsr  think
        ldaa #G_STRIP
        jmp  gamex

; hint: a 2-second search for the player; the move is shown and pointed at
hint:   ldaa #OV_KPK            ; (king and pawn v king: the table's move)
        clrb
        jsr  ov_call
        bcs  .s
        staa e_bestf
        stab e_bestt
        bra  .h
.s:     jsr  look2
.h:     ldaa #G_HINT            ; the text, then the board
        jsr  gamex
        jmp  show
