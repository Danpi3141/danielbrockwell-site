; ---------------------------------------------------------------------
; Pack: the game's blocks CHB0..CHBF are procedures on the device the
; kernel came from; pk_scan finds where each one's data starts.
; ---------------------------------------------------------------------

; seek to kv_pa on the game's device. PK$SETP (which costs most of a
; seek) is only needed when another device may have been selected since:
; anything that uses the OS's file services clears kv_pkok. PK$SADD
; itself powers the packs up again after the OS has switched them off.
pk_seek:
        tst  kv_pkok
        bne  .sel
        clra
        ldab kv_dev
        os   PK$SETP
        inc  kv_pkok
.sel:   ldab kv_pa
        ldx  kv_pa+1
        os   PK$SADD
        rts

; (pk_scan, which finds the blocks once at start, is in kinit.asm since 17 Nov)

; read kv_rlen bytes at kv_roff in block kv_rblk to kv_rdst; leaves the
; pack positioned just after them, so pk_more can carry on.
pk_read:
        ldab kv_rblk
        ldaa #3
        mul
        addd #kv_dir
        xgdx
        ldd  1,x
        addd kv_roff
        std  kv_pa+1
        ldaa 0,x
        adca #0
        staa kv_pa
        bsr  pk_seek
pk_more:
        ldd  kv_rlen
        beq  .x
        ldx  kv_rdst
        os   PK$READ
.x:     rts

; ---------------------------------------------------------------------
; ov_load: A = overlay id (1..). Loads it into slot A unless it is
; there already, and adds the array's address to its fix-ups.
; ---------------------------------------------------------------------
ov_load:
        staa kv_t2              ; id
        cmpa kv_res
        beq  .x                 ; already there
        ldab #3
        mul
        addd #ovtab-3
        xgdx
        ldaa 0,x
        staa kv_rblk
        ldd  1,x
        std  kv_roff
        ldd  #2
        std  kv_rlen
        ldd  #kv_t3
        std  kv_rdst
        bsr  pk_read            ; kv_t3 = code length
        ldd  #SLOTA
        std  kv_t1              ; where it goes
        ldx  kv_t1
        ldd  kv_t3
        beq  .gone              ; the pack is gone (it reads as 0s): leave, the
        cmpa #SLOTA_SIZE/256    ; game is saved; or a length past the slot (to
        bhi  .gone              ; within 255 bytes)
        os   PK$READ            ; the code
        os   PK$RWRD            ; fix-ups (unused: the encoded length says it all)
        os   PK$RWRD
        std  kv_t3              ; encoded bytes left
        clr  kv_fo              ; the offset of the last fix-up
        clr  kv_fo+1
.chunk: ldd  kv_t3
        beq  .done
        subd #16
        bcc  .full
        ldd  kv_t3
        clr  kv_t3
        clr  kv_t3+1
        bra  .rd
.full:  std  kv_t3
        ldd  #16
.rd:    stab kv_t0              ; bytes in this chunk
        ldx  #kv_fix
        os   PK$READ
        ldx  #kv_fix
.ap:    tst  kv_t0
        beq  .chunk
        ldab 0,x
        inx
        dec  kv_t0
        clra
        cmpb #255
        bne  .rel
        ; 255: the gap in two bytes follows, perhaps in the next chunk
        jsr  ov_byte
        psha
        jsr  ov_byte
        tab
        pula
.rel:   addd kv_fo
        std  kv_fo
        addd kv_t1              ; address of the word in the slot
        pshx
        xgdx
        ldd  0,x
        addd kv_base
        std  0,x
        pulx
        bra  .ap
.done:  ldaa kv_t2
        staa kv_res
.x:     rts
.gone:  ldab #E_NOPACK
        jmp  quit

; the next encoded byte: from the chunk, or straight from the pack when the
; chunk has run out (the pack is read in order). A = it; X, kv_t0 move on.
ov_byte: tst  kv_t0
        beq  ov_bpk
        ldaa 0,x
        inx
        dec  kv_t0
        rts
ov_bpk:    pshx
        os   PK$RBYT
        pulx
        tba
        pshb
        ldd  kv_t3              ; one fewer left for later chunks
        subd #1
        std  kv_t3
        pula
        rts
