'use strict';
// PGN export (menu: EXPORT PGN): the file A:PGNn holds the game as PGN, one line a record.
// The records are read straight from the emulated RAM (all banks: A: is in the LZ64's other
// RAM banks) and the text is checked with python-chess: the moves, the tags, the numbering
// when Black moved first, the FEN after a set-up, wrapping, a second export's new name.
//   node tests/ui/t_pgn.js
const { spawnSync } = require('child_process');
const L = require('./lib.js');
const G = require('./glib.js');
const { check } = L;

// every RAM byte, banks included
function ramAll(m) { const a = []; m.mem.getSnapshotData(a); return Buffer.from(a); }
// the records of the data file whose first record starts with "[Event": [len][type][text]
function pgnFiles(m) {
  const r = ramAll(m);
  const files = [];
  let at = 0;
  for (;;) {
    const i = r.indexOf('[Event ', at, 'latin1');
    if (i < 0) break;
    let p = i - 2;
    const type = r[p + 1];
    const lines = [];
    while (p < r.length && r[p] > 0 && r[p] < 255 && r[p + 1] === type) {
      lines.push(r.slice(p + 2, p + 2 + r[p]).toString('latin1'));
      p += 2 + r[p];
    }
    files.push({ type, lines });
    at = i + 1;
  }
  return files;
}
function pyCheck(pgn) {
  const code = [
    'import sys, json, io, chess.pgn',
    'g = chess.pgn.read_game(io.StringIO(sys.stdin.read()))',
    'print(json.dumps({"headers": dict(g.headers), "moves": [m.uci() for m in g.mainline_moves()], "errors": [str(e) for e in g.errors], "fen": g.board().fen()}))',
  ].join('\n');
  const p = spawnSync('python', ['-E', '-P', '-c', code], { input: pgn, encoding: 'utf8' });
  if (p.status !== 0) throw new Error(p.stderr);
  return JSON.parse(p.stdout);
}
function exportPgn(m) {
  G.menu(m, ['E']);
  check(L.waitFor(m, 'PGN SAVED AS', 30), 'export: "' + m.screen()[0].trim() + ' ' + m.screen()[1].trim() + '"', m);
  const name = m.screen()[1].trim();
  m.press('EXE', 3, 10); G.waitInput(m, 10);
  return name;
}

// 1. a two-player game with checks, captures, both castlings, a disambiguation
let m = G.start();
G.twoPlayers(m);
const moves = ['e2e4', 'd7d5', 'e4d5', 'g8f6', 'd2d4', 'd8d5', 'b1c3', 'd5a5', 'c1d2', 'c7c6', 'd1e2', 'c8f5',
  'e1c1', 'e7e6', 'g1f3', 'f8b4', 'h2h3', 'e8g8', 'g2g4', 'f5g6', 'f3e5', 'b8d7', 'e5g6', 'h7g6', 'c3e4', 'f8e8',
  'e4f6', 'd7f6'];
moves.forEach((u, i) => { G.typeUci(m, u); check(G.waitPly(m, i + 1, 30), 'played ' + u, m); });
const n1 = exportPgn(m);
check(n1 === 'A:PGN1', 'the first export is A:PGN1 (' + n1 + ')', m);
let f = pgnFiles(m);
check(f.length === 1, 'one PGN file in RAM (' + f.length + ')', m);
const text = f[0].lines.join('\n') + '\n';
console.log(text.split('\n').map((l) => '     | ' + l).join('\n'));
check(f[0].lines.every((l) => l.length <= 120) && f[0].lines.filter((l) => !l.startsWith('[')).every((l) => l.length <= 79), 'move-text lines are at most 79 characters', m);
let j = pyCheck(text);
check(!j.errors.length, 'python-chess reads it without errors ' + JSON.stringify(j.errors), m);
check(JSON.stringify(j.moves) === JSON.stringify(moves), 'the moves are the game (' + j.moves.length + ' plies)', m);
const h = j.headers;
const want = { Event: 'Psion Organiser II game', Site: 'Psion Organiser II LZ64', Round: '-', White: 'Player', Black: 'Player', Result: '*' };
check(Object.keys(want).every((k) => h[k] === want[k]), 'tags: ' + JSON.stringify(h), m);
check(/^\d{4}\.\d{2}\.\d{2}$/.test(h.Date), 'the date from the Organiser clock: ' + h.Date, m);
check(text.includes('O-O ') && text.includes('O-O-O') && text.includes('Nxf6+') && text.includes('Nbd7') && text.includes('Rfe8') && text.trimEnd().endsWith('*'), 'O-O, O-O-O, check, disambiguation, the result at the end', m);

// 2. a second export gets the next name; both files are kept
const n2 = exportPgn(m);
check(n2 === 'A:PGN2', 'the second export is A:PGN2 (' + n2 + ')', m);
check(pgnFiles(m).length === 2, 'two PGN files in RAM', m);

// 3. a set-up position with Black to move, a promotion with check and a finished game
m = G.start();
G.twoPlayers(m);
G.setupFen(m, '8/P7/8/8/8/8/k6K/8 b - - 0 1');
G.typeUci(m, 'a2a3'); check(G.waitPly(m, 1, 30), 'Black moved first (Ka3)', m);
G.typeUci(m, 'a7a8q'); check(G.waitPly(m, 2, 30), 'a8=Q', m);
exportPgn(m);
f = pgnFiles(m);
const t3 = f[0].lines.join('\n') + '\n';
console.log(t3.split('\n').map((l) => '     | ' + l).join('\n'));
j = pyCheck(t3);
check(!j.errors.length && j.headers.SetUp === '1' && j.headers.FEN === '8/P7/8/8/8/8/k6K/8 b - - 0 1', 'SetUp and FEN tags: ' + j.headers.FEN, m);
check(JSON.stringify(j.moves) === JSON.stringify(['a2a3', 'a7a8q']) && t3.includes('1... Ka3 2. a8=Q+'), 'numbering from Black: "1... Ka3 2. a8=Q+"', m);

// 4. against the computer (level 1), a game resigned: the names and the result
m = G.start();
G.setting(m, G.SET.LEVEL, ['LEFT', 'LEFT', 'LEFT', 'LEFT', 'LEFT', 'LEFT']);
G.typeUci(m, 'f2f3'); G.waitPly(m, 2, 60);
G.menu(m, ['R', 'R']); G.waitInput(m, 10); m.press('EXE', 3, 10); G.waitInput(m, 10);
exportPgn(m);
f = pgnFiles(m);
j = pyCheck(f[0].lines.join('\n') + '\n');
check(j.headers.White === 'Player' && /^Psion LZ64 level [1-8]$/.test(j.headers.Black), 'names: White "' + j.headers.White + '", Black "' + j.headers.Black + '"', m);
check(j.headers.Result === '0-1' && j.moves.length === 2, 'the player resigned: Result 0-1 after 2 plies (' + j.headers.Result + ')', m);
// 4b. a long game (random legal moves, up to 200 plies): wrapping and move numbers far in
{
  const code = ['import chess, random, json', 'random.seed(31)', 'b = chess.Board()', 'ms = []',
    'while len(ms) < 200 and not b.is_game_over(claim_draw=True):',
    '    m = random.choice(list(b.legal_moves))', '    ms.append(m.uci()); b.push(m)', 'print(json.dumps(ms))'].join(String.fromCharCode(10));
  const long = JSON.parse(spawnSync('python', ['-E', '-P', '-c', code], { encoding: 'utf8' }).stdout);
  m = G.start();
  G.twoPlayers(m);
  for (let i = 0; i < long.length; i++) { G.typeUci(m, long[i]); if (!G.waitPly(m, i + 1, 30)) break; }
  const played = L.peekSym(m, 'g_n')[0];
  check(played === long.length || L.peekSym(m, 'g_result')[0] !== 0, 'a long random game: ' + played + ' plies played', m);
  exportPgn(m);
  const fl = pgnFiles(m)[0].lines;
  j = pyCheck(fl.join(String.fromCharCode(10)) + String.fromCharCode(10));
  check(!j.errors.length && JSON.stringify(j.moves) === JSON.stringify(long.slice(0, played)), 'the long game exported exactly (' + j.moves.length + ' plies, ' + fl.length + ' lines)', m);
  check(fl.filter((l) => !l.startsWith('[')).every((l) => l.length <= 79), 'every move-text line at most 79 characters', m);
}

// 5. the move text setting (plain squares) does not change the export, and is kept
m = G.start();
G.twoPlayers(m);
G.setting(m, G.SET.MOVES, ['RIGHT']);
const notat = L.peekSym(m, 'st_notat')[0];
['g1f3', 'g8f6'].forEach((u, i) => { G.typeUci(m, u); G.waitPly(m, i + 1, 30); });
exportPgn(m);
j = pyCheck(pgnFiles(m)[0].lines.join(String.fromCharCode(10)) + String.fromCharCode(10));
check(notat === 1 && L.peekSym(m, 'st_notat')[0] === 1 && JSON.stringify(j.moves) === JSON.stringify(['g1f3', 'g8f6']),
  'plain-squares setting: the export is still standard notation, and the setting is kept', m);

// 6. A: full: no room for the export (the file is deleted), and no save file at all
const H = require('./help.js');
const path = require('path');
const { Machine } = require('../../tools/emu.js');
function fillTo(t, name) {
  return [name + ':', 'LOCAL f%', 'ONERR full',
    'CREATE "A:ZZFILL",A,B$', 'f%=FREE', 'WHILE FREE>=f%', 'A.B$=REPT$("X",250)', 'APPEND', 'ENDWH', 'LAST', 'ERASE', 'CLOSE',
    'CREATE "A:ZZFILL2",A,B$', 'f%=FREE', 'WHILE FREE>=f%', 'A.B$="XXXXXXXX"', 'APPEND', 'ENDWH', 'LAST', 'ERASE', 'CLOSE',
    'CREATE "A:ZZFILL3",A,B$',
    'WHILE FREE>' + (t + 260), 'A.B$=REPT$("X",250)', 'APPEND', 'ENDWH',
    'WHILE FREE>' + (t + 12), 'A.B$="XXXXXXXX"', 'APPEND', 'ENDWH',
    'full::', 'ONERR OFF', 'CLOSE'];
}
// No room for the export: the game is played and saved first, then A: is filled so that, back
// in the game (512-entry table), about 130 bytes are left. (Filling A: first no longer leaves room
// for the save file itself once the table is 512 entries: that is the second case.)
const needs = JSON.parse(require('fs').readFileSync(require('path').join(L.BUILD, 'build.json'), 'utf8')).needs;
for (const [t, first, want] of [[needs[2] - 316, true, 'NO ROOM ON A:'], [needs[2] + 654, false, 'GAME NOT SAVED']]) {
  const name = 'F' + t;
  m = new Machine({ rom: '46a-lz64.rom', ram: 64 }); m.boot();
  m.insertPack(require('path').join(L.BUILD, 'CHESS.opk'), 0); m.insertPack(H.make({ [name]: fillTo(t, name) }, 'fill'), 1);
  const six = () => ['e2e4', 'e7e5', 'g1f3', 'b8c6', 'f1b5', 'a7a6'].forEach((u, i) => { G.typeUci(m, u); G.waitPly(m, i + 1, 30); });
  if (first) {
    m.runProc('CHESS', 'B'); m.runSeconds(8); G.waitInput(m, 10);
    G.twoPlayers(m); six();
    L.keys(m, ['ON']); m.runSeconds(1); L.keys(m, ['S', 'S', 'S', 'EXE']); m.runSeconds(3); H.top(m);
  }
  H.run(m, name, 200); H.top(m);
  m.runProc('CHESS', 'B'); m.runSeconds(8); G.waitInput(m, 10); m._base = null;
  if (!first) { G.twoPlayers(m); six(); }
  check(L.peekSym(m, 'g_n')[0] === 6, 'A: full (' + (first ? 'after the save' : 'before the game') + '): 6 plies, TT ' + m.peekw(L.sym(m, 'e_ttn')), m);
  G.menu(m, ['E']);
  check(L.waitFor(m, 'CANNOT EXPORT', 30) && m.screen()[1].trim() === want, 'A: full: "CANNOT EXPORT: ' + m.screen()[1].trim() + '"', m);
  m.press('EXE', 3, 10); G.waitInput(m, 10);
  check(L.peekSym(m, 'g_n')[0] === 6, 'the game goes on', m);
  L.keys(m, ['ON']); m.runSeconds(1); L.keys(m, ['S', 'S', 'S', 'EXE']); m.runSeconds(3); H.top(m);
  const d = H.dir(m);
  check(!/PGN/.test(d), 'no PGN file left on A: ("' + d + '")', m);
}
console.log('all UI tests passed');
