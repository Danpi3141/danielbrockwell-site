; =====================================================================
; Set up a position (slot A). The board as in the split layout: ranks
; 8-5 on the left, 4-1 on the right; columns 17-19 show the side to move.
;   arrows   move the cursor (the cursor blinks)
;   P N B R Q K   put a White piece there; the same letter again makes it Black
;   DEL      empty the square;  C  clears the whole board
;   MODE     the side to move;  EXE  play from here;  ON/CLEAR  give up
; Entry 0 starts from the position on the board, entry 1 goes on with
; g_spos after a refusal (A = the engine's reason 1-3).
; Out: C=0 and g_spos (a1..h8, side, castle, ep, half) for the kernel to
; check with eng_setup; C=1 nothing changed.
; =====================================================================
        include "../defs.inc"
        include "ids.inc"

        jmp  su_new
        jmp  su_again

letters: fcc  "PNBRQK"
schars: fcc  " PNBRQK  pnbrqk "
reasons: fcl  "TWO KINGS NEEDED"
        fcl  "PAWN ON RANK 1 OR 8"
        fcl  "SIDE NOT TO MOVE IN CHECK"

; from the board: e_board -> g_spos
su_new: clr  su_i
.c:     ldab su_i
        jsr  su_88              ; B = 0x88 square
        ldx  #e_board
        abx
        ldaa 0,x
        ldab su_i
        ldx  #g_spos
        abx
        staa 0,x
        inc  su_i
        ldaa su_i
        cmpa #64
        bne  .c
        ldaa e_side
        staa g_spos+64
        clr  su_msg
        bra  su_go
su_again:
        ldaa rp_e               ; the engine's reason
        staa su_msg
su_go:  ldaa #12                ; the cursor starts on e2
        staa su_c
        clr  su_idle
.draw:  jsr  su_draw
        ldaa #6
        inc  su_idle            ; the cursor blinks for about 77 s after a key, then
        bne  .kw                ; stays and the wait sleeps (the Organiser may
        ldab #1                 ; switch itself off)
        stab su_bl
        jsr  su_draw
        clra
.kw:    jsr  key_wait
        tstb
        bne  .key
        ldaa su_bl
        eora #1
        staa su_bl
        bra  .draw
.key:   clr  su_msg
        clr  su_idle
        ldaa #1
        staa su_bl
        jsr  key_upper
        cmpb #K_ON
        bne  .k1
        sec
        rts
.k1:    cmpb #K_EXE
        bne  .k2
        jmp  su_done
.k2:    cmpb #K_MODE
        bne  .k3
        ldaa g_spos+64
        eora #8
        staa g_spos+64
        bra  .draw
.k3:    cmpb #K_DEL
        bne  .k4
        jsr  su_sq
        clr  0,x
        bra  .draw
.k4:    cmpb #'C'
        bne  .k5
        ldx  #g_spos
        ldab #64
.z:     clr  0,x
        inx
        decb
        bne  .z
        bra  .draw
.k5:    cmpb #K_UP
        blo  .k6
        cmpb #K_RIGHT
        bhi  .k6
        jsr  su_move
        bra  .draw
.k6:    ldx  #letters           ; a piece letter
        clra
.l:     cmpb 0,x
        beq  .pc
        inx
        inca
        cmpa #6
        bne  .l
        bra  .draw
.pc:    inca                    ; the piece type 1..6
        psha
        jsr  su_sq
        pula
        cmpa 0,x                ; the same White piece again: make it Black
        bne  .w
        oraa #8
.w:     staa 0,x
        jmp  .draw

; X = the cursor's square in g_spos
su_sq:  ldab su_c
        ldx  #g_spos
        abx
        rts

; B = n (rank*8+file): B = 0x88 square
su_88:  pshb
        andb #$38
        aslb
        pula
        anda #7
        aba
        tab
        rts

; arrows: up/down by rank, left/right by file (the board stays still)
su_move:
        ldaa su_c
        cmpb #K_UP
        bne  .d
        adda #8
        cmpa #64
        bhs  .x
        bra  .s
.d:     cmpb #K_DOWN
        bne  .l
        suba #8
        bcs  .x
        bra  .s
.l:     cmpb #K_LEFT
        bne  .r
        bita #7
        beq  .x
        deca
        bra  .s
.r:     tab
        andb #7
        cmpb #7
        beq  .x
        inca
.s:     staa su_c
.x:     rts

; the screen: ranks 8-5 and 4-1 side by side, the side to move, any message
su_draw:
        jsr  scr_cls
        clr  su_r
.r:     ldaa su_r
        clrb
        jsr  scr_at
        ldaa #7                 ; left block: rank 7 - r
        suba su_r
        bsr  .rank
        ldaa #7
        suba su_r
        adda #'1'
        jsr  scr_putc
        ldaa #3                 ; right block: rank 3 - r
        suba su_r
        bsr  .rank
        inc  su_r
        ldaa su_r
        cmpa #4
        bne  .r
        ldaa #0                 ; the side to move
        ldab #18
        jsr  scr_at
        ldaa #'W'
        tst  g_spos+64
        beq  .s
        ldaa #'B'
.s:     jsr  scr_putc
        ldaa #1
        ldab #17
        jsr  scr_at
        jsr  scr_pri
        fcl  "SET"
        tst  su_msg             ; a refusal: its reason on row 3
        beq  .f
        ldaa #3
        clrb
        jsr  scr_at
        jsr  scr_eol
        ldaa #3
        clrb
        jsr  scr_at
        ldx  #reasons
        ldaa su_msg
.n:     deca
        beq  .p
        ldab 0,x
        abx
        inx
        bra  .n
.p:     jsr  scr_puts
.f:     jmp  scr_flush
; A = rank: its 8 squares at the cursor
.rank:  asla
        asla
        asla
        staa su_n
        clr  su_f
.q:     ldab su_n
        addb su_f
        stab su_t
        ldx  #g_spos
        abx
        ldaa 0,x
        ldab su_t
        cmpb su_c
        bne  .nc
        tst  su_bl
        beq  .nc
        ldaa #CH_BLOCK
        bra  .put
.nc:    tsta
        bne  .pc
        ldaa su_t               ; empty: the diamond on dark squares
        tab
        lsrb
        lsrb
        lsrb
        aba
        anda #1
        bne  .lt
        ldaa #CH_DIAM
        bra  .put
.lt:    ldaa #' '
        bra  .put
.pc:    ldx  #schars
        tab
        abx
        ldaa 0,x
.put:   jsr  scr_putc
        inc  su_f
        ldaa su_f
        cmpa #8
        bne  .q
        rts

; EXE: castling rights from where the kings and rooks stand, no en passant
su_done:
        clr  g_spos+65
        ldx  #g_spos
        ldaa 4,x                ; e1 king: h1 rook -> O-O, a1 rook -> O-O-O
        cmpa #PC_K
        bne  .b
        ldaa 7,x
        cmpa #PC_R
        bne  .w2
        ldaa #1
        staa g_spos+65
.w2:    ldaa 0,x
        cmpa #PC_R
        bne  .b
        ldaa g_spos+65
        oraa #2
        staa g_spos+65
.b:     ldaa 60,x               ; e8 king
        cmpa #PC_K+PC_BLACK
        bne  .e
        ldaa 63,x
        cmpa #PC_R+PC_BLACK
        bne  .b2
        ldaa g_spos+65
        oraa #4
        staa g_spos+65
.b2:    ldaa 56,x
        cmpa #PC_R+PC_BLACK
        bne  .e
        ldaa g_spos+65
        oraa #8
        staa g_spos+65
.e:     ldaa #$FF
        staa g_spos+66
        clr  g_spos+67
        clc
        rts

su_i:   rmb  1
su_c:   rmb  1
su_bl:  rmb  1
su_msg: rmb  1
su_r:   rmb  1
su_n:   rmb  1
su_f:   rmb  1
su_t:   rmb  1
su_idle: rmb 1
