; =====================================================================
; Engine variables. The kernel includes this inside its variable block
; (cleared at start, not on the pack). See API.md.
;
; Two parts:
;  - the persistent block below (rmb): the position and the game's key
;    history, which must survive between engine calls;
;  - the scratch (ENG_SCRATCH_SIZE bytes at e_scratch): everything else.
;    Any engine routine may overwrite all of it. The kernel may share it
;    with an overlay slot by defining ENG_SCRATCH_EXT (an address) before
;    including this file; 0 = the engine reserves its own.
; =====================================================================
E_MAXPLY  = 24                  ; plies of search frames (must match ref/engine.js MAXPLY)
E_MVMAX   = 400                 ; move stack entries (3 bytes each)
E_MVCAP   = 360                 ; a node with more moves stacked below it is a leaf (ref MVCAP);
                                ; a list that would run past E_MVMAX is cut short
E_FR      = 43+2*E_NULL+E_LMR+E_PVS ; bytes per search frame (F_* in emove.asm; 48 until 17 Nov)
E_QUNS    = 148                 ; an unscored quiet move's score (above every quiet score, 127 at most,
                                ; below the killers' 149 and 150 and every capture, 162 at least)
E_KCAP    = 100                 ; eng_play empties the key history when it holds this many (104 until 17 Nov):
                                ; it is emptied at every irreversible move too, so it holds at most the
                                ; half-move clock, and at 100 the game is over (fifty moves)
E_KMAX    = E_KCAP+E_MAXPLY-2   ; key history entries: the game's at most E_KCAP-1, then one a ply of
                                ; search, moves being made up to ply E_MAXPLY-2 (the quiescence search
                                ; stands pat at E_MAXPLY-1): 122 (136 until 17 Nov; tests/engine/t_khist.js)

; ---- position (the UI may read these; write them only before eng_setup)
e_board:  rmb 128               ; 0x88 board
e_side:   rmb 1                 ; 0 White, 8 Black to move
e_castle: rmb 1                 ; bit0 W O-O, bit1 W O-O-O, bit2 B O-O, bit3 B O-O-O
e_ep:     rmb 1                 ; en passant square or $FF
e_half:   rmb 1                 ; half-move clock
; ---- derived (kept up to date by make/unmake)
e_ksq:    rmb 2                 ; king squares: White, Black
e_mg:     rmb 4                 ; material + PST, middlegame: White word, Black word
e_eg:     rmb 4                 ; same, endgame
e_phase:  rmb 1                 ; N,B = 1, R = 2, Q = 4
e_cnt:    rmb 16                ; piece counts [colour*8 + type]
e_bcol:   rmb 1                 ; e_insuf: the bishops' square colour so far
e_pm:     rmb 20                ; pawn rank masks, bit n = rank n: White file f at 1+f, Black at 11+f
                                ; (bytes 0, 9, 10, 19 stay 0 so neighbouring files need no test)
e_key:    rmb 3                 ; position key (24 bits), big-endian
; ---- think interface
e_tlim:   rmb 2                 ; time limit in 50 ms frames, 0 = none
e_nlim:   rmb 3                 ; node limit, 0 = none
e_tadd:   rmb 2                 ; fail-low: extra frames past e_tlim allowed (the kernel's think sets it)
e_maxd:   rmb 1                 ; maximum depth, 0 = 40
e_margin: rmb 2                 ; levels 1-4: evaluation noise k (its low byte; the levels use 14-100), within +-8k cp (0 none; until 17 Nov a margin pass's cp)
e_nseed:  rmb 1                 ;   and this search's noise seed
e_bestf:  rmb 1                 ; result
e_bestt:  rmb 1
e_score:  rmb 2
e_depth:  rmb 1
e_nodes:  rmb 3
e_rnd:    rmb 2                 ; random state (xorshift16), never 0
e_tt:     rmb 2                 ; transposition table address (set by the kernel)
e_ttn:    rmb 2                 ; entries (power of two, >= 128)
e_ttmask: rmb 2                 ; e_ttn - 1
e_lmn:    rmb 1                 ; eng_legal: count
e_kn:     rmb 1                 ; keys in e_khist
e_khist:  rmb 2*E_KMAX          ; top 16 bits of the key before each move: game since the last
                                ; irreversible move, then the search

; ---- scratch layout (offsets)
S_MVTOP   = 0                           ; move stack start for each ply (addresses)
S_KILL    = S_MVTOP+2*(E_MAXPLY+2)      ; two killers (from,to) per ply
S_TMP     = S_KILL+4*E_MAXPLY           ; temporaries (below; the margin pass's 256-byte score list went 17 Nov)
S_MVS     = S_TMP+113                   ; move stack
S_FRAMES  = S_MVS+3*E_MVMAX             ; search frames
ENG_SCRATCH_SIZE = S_FRAMES+E_FR*(E_MAXPLY+1)

        if   ENG_SCRATCH_EXT
e_scratch = ENG_SCRATCH_EXT
        else
e_scratch: rmb ENG_SCRATCH_SIZE
        endif

e_mvtop   = e_scratch+S_MVTOP
e_killer  = e_scratch+S_KILL
e_mvs     = e_scratch+S_MVS
e_frames  = e_scratch+S_FRAMES
e_lm      = e_mvs+3*E_MVMAX-440     ; eng_legal output: up to 220 moves (from,to), clear of ply 0's list

; temporaries (all in the scratch, at S_TMP)
e_ply     = e_scratch+S_TMP+0       ; current search ply
e_fp      = e_scratch+S_TMP+1       ; current frame address (2)
e_wp      = e_scratch+S_TMP+3       ; move generator: write pointer (2)
e_caps    = e_scratch+S_TMP+5       ; move generator: captures only
e_us      = e_scratch+S_TMP+6       ; move generator: side to move (0/8)
e_them    = e_scratch+S_TMP+7
e_stop    = e_scratch+S_TMP+8       ; search must unwind
e_tstart  = e_scratch+S_TMP+9       ; TMW_FRAM at the start of the think (2)
e_tick    = e_scratch+S_TMP+11      ; nodes until the next poll
e_rootf   = e_scratch+S_TMP+12      ; best root move of the iteration in progress
e_roott   = e_scratch+S_TMP+13
e_rootsc  = e_scratch+S_TMP+14      ; (2)
e_nleg    = e_scratch+S_TMP+16      ; legal root moves
e_top     = e_scratch+S_TMP+17      ; margin pass: best score (2)
e_ncand   = e_scratch+S_TMP+19
e_t       = e_scratch+S_TMP+20      ; scratch words (8)
e_gs      = e_scratch+S_TMP+28      ; move generator: square
e_gpc     = e_scratch+S_TMP+29      ;                 piece
e_gpst    = e_scratch+S_TMP+30      ;                 its PST row (middlegame) (2)
e_gptr    = e_scratch+S_TMP+32      ;                 direction table pointer (2)
e_gcnt    = e_scratch+S_TMP+34      ;                 directions left
e_mf      = e_scratch+S_TMP+35      ; make/unmake: from
e_mt      = e_scratch+S_TMP+36      ;              to (square)
e_mtc     = e_scratch+S_TMP+37      ;              to (with promotion bits)
e_mcap    = e_scratch+S_TMP+38      ;              captured piece
e_mpc     = e_scratch+S_TMP+39      ;              moving piece
e_mnp     = e_scratch+S_TMP+40      ;              piece arriving (promotions)
e_mus     = e_scratch+S_TMP+41      ;              mover (0/8)
e_mrf     = e_scratch+S_TMP+42      ;              castling rook from
e_mrt     = e_scratch+S_TMP+43      ;              castling rook to
e_mrk     = e_scratch+S_TMP+44      ;              the rook
e_mcs     = e_scratch+S_TMP+45      ;              en passant victim's square
e_pv      = e_scratch+S_TMP+46      ; add/remove piece: 0 add, 1 remove
e_ppc     = e_scratch+S_TMP+47      ;                   piece
e_psq     = e_scratch+S_TMP+48      ;                   square
e_pix     = e_scratch+S_TMP+49      ;                   PST index (2)
e_pval    = e_scratch+S_TMP+51      ;                   value (2)
e_emg     = e_scratch+S_TMP+53      ; evaluation: middlegame total (2)
e_eeg     = e_scratch+S_TMP+55      ;             endgame total (2)
e_ef      = e_scratch+S_TMP+57      ;             file
e_ew      = e_scratch+S_TMP+58      ;             pawn mask
e_eo      = e_scratch+S_TMP+59      ;             opposing mask
e_er      = e_scratch+S_TMP+60      ;             rank
e_es      = e_scratch+S_TMP+61      ;             score (2)
e_gives   = e_scratch+S_TMP+63      ; search: the move gives check
e_sc      = e_scratch+S_TMP+64      ;         a child's score (negated) (2)
e_ca      = e_scratch+S_TMP+66      ;         the child's window (2)
e_cb      = e_scratch+S_TMP+68      ;         (2)
e_pend    = e_scratch+S_TMP+70      ;         end of the list being picked from (2)
e_mdep    = e_scratch+S_TMP+72      ; margin pass: depth
e_mi      = e_scratch+S_TMP+73      ;              next move (2)
e_mn      = e_scratch+S_TMP+75      ;              moves scanned
e_msp     = e_scratch+S_TMP+76      ;              score pointer (2)
e_inck    = e_scratch+S_TMP+78      ; e_make: the mover is in check (full legality test)
e_mep     = e_scratch+S_TMP+79      ; e_make: the move took en passant
e_pcv     = e_scratch+S_TMP+80      ; eval's pawn cache: valid
e_pcmg    = e_scratch+S_TMP+81      ;   pawn score, middlegame (2)
e_pceg    = e_scratch+S_TMP+83      ;   pawn score, endgame (2)
e_pcm     = e_scratch+S_TMP+85      ;   the pawn masks it belongs to (16)
e_ofp     = e_scratch+S_TMP+101     ; the parent frame, e_fp - E_FR (2; kept with e_fp)
e_bare    = e_scratch+S_TMP+103     ; eng_think: a side has a bare king (no table cut-offs)
e_flon    = e_scratch+S_TMP+104     ; fail-low: this iteration is failing low (may run past the limit)
e_flused  = e_scratch+S_TMP+105     ;           already used in this search
e_fln     = e_scratch+S_TMP+106     ;           the node limit then: twice e_nlim (3)
e_tfl     = e_scratch+S_TMP+109     ;           the time limit then: e_tlim + e_tadd (2)
e_rootend = e_scratch+S_TMP+111     ; root ordering: the end of the root's kept list (2; 0 = none yet)
