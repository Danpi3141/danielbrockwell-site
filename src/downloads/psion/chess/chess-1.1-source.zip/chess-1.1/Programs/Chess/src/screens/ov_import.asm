; =====================================================================
; Importing a game (slot A). The PC converter (tools/pgn2psion.py) makes
; data files A:GAME1..A:GAME99, one line a record:
;   1   "CHESSGAME"
;   2   a title (up to 40 characters)
;   3   "START", or "S", the 64 squares a1..h8 ('.' empty, PNBRQK White,
;       pnbrqk Black), the side to move ('w' or 'b'), the castling rights
;       (one hex digit: 1 K, 2 Q, 4 k, 8 q), the en-passant square ("e3"
;       or "--") and the half-move clock (two digits): 71 characters
;   4.. the moves as squares ("e2e4 e7e8q"), separated by spaces
; Entry 0 lets the player choose a file and reads its start (g_setup,
; g_spos); C=1 if cancelled. Entry 1 gives the next move (hu_f, hu_t,
; im_pro), C=1 when there are no more (a message is left if the file is
; bad). The moves are played by the kernel (im_game in kcore.asm): that
; needs the engine, whose scratch is this slot, so one move each call.
; =====================================================================
        include "../defs.inc"
        include "ids.inc"

        jmp  im_pick            ; 0
        jmp  im_next            ; 1

; ---------------------------------------------------------------------
; choose a file
im_pick:
        jsr  im_scan            ; which A:GAMEn there are
        ldaa #1
        staa im_g
        ldaa #1                 ; the first file there is, counting up
        bsr  im_seek
        bcc  .show
        jsr  scr_cls
        clra
        clrb
        jsr  scr_at
        jsr  scr_pri
        fcl  "NO GAMES TO IMPORT"
        ldaa #1
        clrb
        jsr  scr_at
        jsr  scr_pri
        fcl  "(A:GAME1 TO GAME99)"
        jsr  scr_flush
        clra
        jsr  key_wait
        sec
        rts
.show:  jsr  im_title
        clra
        jsr  key_wait
        cmpb #K_ON
        bne  .k1
        sec
        rts
.k1:    cmpb #K_UP
        bne  .k2
        dec  im_g               ; the one before
        ldaa #$FF
        bsr  im_seek
        bra  .show
.k2:    cmpb #K_DOWN
        bne  .k3
        ldaa #1                 ; the one after
        inc  im_g
        bsr  im_seek
        bra  .show
.k3:    cmpb #K_EXE
        bne  .show
        jmp  im_start

; A = +1 or -1: from im_g on, the first A:GAMEn that is there (going
; round 99 -> 1), opened. C=1 if there is none at all.
im_seek:
        staa ib_dir
        ldaa #99
        staa ib_cnt
.l:     ldaa im_g
        beq  .lo
        cmpa #100
        blo  .ok
        ldaa #1
        bra  .set
.lo:    ldaa #99
.set:   staa im_g
.ok:    bsr  im_bit
        andb 0,x
        beq  .n
        bsr  im_open
        bcc  .x
.n:     ldaa im_g
        adda ib_dir
        staa im_g
        dec  ib_cnt
        bne  .l
        sec
.x:     rts

; A = n: X = its byte in ib_map, B = its bit
im_bit: tab
        lsrb
        lsrb
        lsrb
        ldx  #ib_map
        abx
        anda #7
        ldab #1
.s:     tsta
        beq  .x
        aslb
        deca
        bra  .s
.x:     rts

; the catalogue of A: (as OPL's DIR$): a bit in ib_map for each A:GAMEn
im_scan:
        ldx  #ib_map
        ldab #13
.z:     clr  0,x
        inx
        decb
        bne  .z
        ldaa #1                 ; 1: from the first file
.l:     clr  kv_pkok
        clrb                    ; A:
        ldx  #ib_buf
        os   FL$CATL
        bcs  .x                 ; no more
        ldaa ib_buf             ; "A:GAMEn" or "A:GAMEnn"
        cmpa #7
        blo  .nx
        cmpa #8
        bhi  .nx
        ldx  #t_gpref
        jsr  im_same
        bcs  .nx
        ldaa ib_buf+7
        suba #'1'
        cmpa #9
        bhs  .nx
        inca                    ; 1..9
        ldab ib_buf
        cmpb #7
        beq  .set
        ldab #10
        mul
        ldaa ib_buf+8
        suba #'0'
        cmpa #10
        bhs  .nx
        aba
.set:   bsr  im_bit
        orab 0,x
        stab 0,x
.nx:    clra                    ; 0: the next file
        bra  .l
.x:     rts

; im_g -> ib_fn = "A:GAMEn"; open it: C=0 there (its type is set)
im_open:
        ldx  #ib_fn+1
        ldd  #$413A             ; "A:"
        std  0,x
        ldd  #$4741             ; "GA"
        std  2,x
        ldd  #$4D45             ; "ME"
        std  4,x
        ldab im_g
        clra
        jsr  num_str
        ldab kv_nbuf
        ldx  #ib_fn+7
        ldaa kv_nbuf+1
        staa 0,x
        ldaa kv_nbuf+2
        staa 1,x
        addb #6
        stab ib_fn
        clr  kv_pkok
        ldx  #ib_fn
        os   FL$OPEN
        bcs  .x
        staa ib_rt
        tab
        os   FL$RECT
        clc
.x:     rts

; D = record number: read it into ib_buf. C=1 if there is none.
im_rec: std  ib_rn
        clr  kv_pkok
        clra
        clrb
        os   FL$SETP            ; A:
        ldab ib_rt
        os   FL$RECT
        ldd  ib_rn
        os   FL$RSET
        bcs  .x
        ldx  #ib_buf
        os   FL$READ
.x:     rts

; the chooser's screen: the file's name and its title (record 2)
im_title:
        jsr  scr_cls
        clra
        clrb
        jsr  scr_at
        jsr  scr_pri
        fcl  "IMPORT "
        ldx  #ib_fn
        jsr  scr_puts
        ldd  #2
        bsr  im_rec
        bcs  .k
        ldab ib_buf             ; the title on two lines of 20
        cmpb #40
        bls  .n
        ldab #40
.n:     stab ib_cnt
        ldaa #1
        clrb
        jsr  scr_at
        clr  ib_dir             ; characters shown
        ldx  #ib_buf+1
.c:     ldaa ib_dir
        cmpa ib_cnt
        beq  .k
        cmpa #20
        bne  .c1
        pshx
        ldaa #2
        clrb
        jsr  scr_at
        pulx
.c1:    ldaa 0,x
        pshx
        jsr  scr_putc
        pulx
        inx
        inc  ib_dir
        bra  .c
.k:     ldaa #3
        clrb
        jsr  scr_at
        jsr  scr_pri
        fcl  "EXE:LOAD  ON:CANCEL"
        jmp  scr_flush

; EXE: check the file and read its start
im_start:
        ldd  #1                 ; "CHESSGAME"
        bsr  im_rec
        bcs  .bad
        ldx  #ib_buf
        ldaa 0,x
        cmpa #9
        blo  .bad
        ldx  #t_magic
        bsr  im_same
        bcs  .bad
        ldd  #3                 ; the start
        bsr  im_rec
        bcs  .bad
        ldaa ib_buf+1
        cmpa #'S'
        bne  .std
        ldaa ib_buf
        cmpa #71
        bhs  .pos
        cmpa #5                 ; "START"
        bne  .bad
.std:   ldx  #t_start
        bsr  im_same
        bcs  .bad
        clr  g_setup
        bra  .go
.pos:   jsr  im_spos
        bcs  .bad
        ldaa #1
        staa g_setup
.go:    ldd  #4                 ; the moves start in record 4
        std  im_rn
        clr  im_off
        clc
        rts
.bad:   jsr  scr_cls
        clra
        clrb
        jsr  scr_at
        jsr  scr_pri
        fcl  "NOT A GAME FILE:"
        ldaa #1
        clrb
        jsr  scr_at
        ldx  #ib_fn
        jsr  scr_puts
        jsr  scr_flush
        clra
        jsr  key_wait
        sec
        rts

; X = text (length-prefixed): C=0 if ib_buf starts with it
im_same:
        ldab 0,x
        stab ib_cnt
        stx  ib_p
        ldx  #ib_buf+1
.l:     ldaa 0,x
        pshx
        ldx  ib_p
        inx
        stx  ib_p
        cmpa 0,x
        pulx
        bne  .no
        inx
        dec  ib_cnt
        bne  .l
        clc
        rts
.no:    sec
        rts

; ib_buf = "S" + position: g_spos. C=1 if a character is wrong.
im_spos:
        clr  ib_cnt             ; the square
.sq:    ldab ib_cnt
        ldx  #ib_buf+2
        abx
        ldaa 0,x
        clrb                    ; the piece code
        cmpa #'.'
        beq  .put
        ldx  #t_pcs
.f:     incb
        cmpb #15
        bhs  .no
        cmpa 0,x
        beq  .put
        inx
        bra  .f
.put:   ldx  #g_spos
        pshb
        ldab ib_cnt
        abx
        pulb
        stab 0,x
        inc  ib_cnt
        ldaa ib_cnt
        cmpa #64
        bne  .sq
        ldaa ib_buf+66          ; the side
        clrb
        cmpa #'w'
        beq  .s
        ldab #8
        cmpa #'b'
        bne  .no
.s:     stab g_spos+64
        ldaa ib_buf+67          ; castling, a hex digit
        suba #'0'
        bcs  .no
        cmpa #10
        blo  .c
        suba #7
        cmpa #16
        bhs  .no
.c:     staa g_spos+65
        ldab #$FF               ; en passant
        ldaa ib_buf+68
        cmpa #'-'
        beq  .e
        ldx  #ib_buf+68
        bsr  im_sq
        bcs  .no
.e:     stab g_spos+66
        ldaa ib_buf+70          ; the half-move clock
        suba #'0'
        ldab #10
        mul
        addb ib_buf+71
        subb #'0'
        stab g_spos+67
        clc
        rts
.no:    sec
        rts

; X = two characters "e3": B = the 0x88 square. C=1 if they aren't one.
im_sq:  ldab 0,x
        subb #'a'
        cmpb #8
        bhs  .no
        ldaa 1,x
        suba #'1'
        cmpa #8
        bhs  .no
        asla
        asla
        asla
        asla
        aba
        tab
        clc
        rts
.no:    sec
        rts

; ---------------------------------------------------------------------
; the next move: hu_f, hu_t (no promotion bits), im_pro (the promotion
; piece's bits, or 0). C=1 at the end of the file, or at a bad entry
; (then the message line says so). Shows the progress.
im_next:
        jsr  scr_cls            ; "IMPORTING A:GAME3" / "MOVE 12"
        clra
        clrb
        jsr  scr_at
        jsr  scr_pri
        fcl  "IMPORTING"
        jsr  im_open
        bcs  .end
        ldaa #1
        clrb
        jsr  scr_at
        ldx  #ib_fn
        jsr  scr_puts
        ldaa #2
        clrb
        jsr  scr_at
        jsr  scr_pri
        fcl  "PLY "
        ldab g_n
        clra
        jsr  num_str
        ldx  #kv_nbuf
        jsr  scr_puts
        jsr  scr_flush
        ldd  im_rn
        jsr  im_rec
        bcs  .end               ; no more records: the end
.l:     ldab im_off             ; skip spaces; at the end of a record, the next
        cmpb ib_buf
        blo  .ch
        ldd  im_rn
        addd #1
        std  im_rn
        clr  im_off
        jsr  im_rec
        bcs  .end
        bra  .l
.ch:    ldx  #ib_buf+1
        abx
        ldaa 0,x
        cmpa #' '
        bne  .mv
        inc  im_off
        bra  .l
.mv:    addb #4                 ; four characters: from, to
        cmpb ib_buf
        bhi  .bad
        pshx
        jsr  im_sq
        pulx
        bcs  .bad
        stab hu_f
        inx
        inx
        pshx
        jsr  im_sq
        pulx
        bcs  .bad
        stab hu_t
        clr  im_pro
        ldab im_off
        addb #4
        stab im_off
        cmpb ib_buf             ; a promotion letter after it?
        bhs  .ok
        inx
        inx
        ldaa 0,x
        cmpa #' '
        beq  .ok
        anda #$DF               ; (either case)
        ldab #$00
        cmpa #'Q'
        beq  .pr
        ldab #$08
        cmpa #'R'
        beq  .pr
        ldab #$80
        cmpa #'B'
        beq  .pr
        ldab #$88
        cmpa #'N'
        bne  .bad
.pr:    stab im_pro
        inc  im_off
.ok:    clc
        rts
.bad:   ldx  #t_badmv
        jsr  msg_set
.end:   sec
        rts

t_gpref:  fcl  "A:GAME"
t_magic:  fcl  "CHESSGAME"
t_start:  fcl  "START"
t_pcs:    fcc  "PNBRQK??pnbrqk"
t_badmv:  fcl  "BAD MOVE IN FILE"

; overlay-local variables (gone when the slot is reused)
ib_dir:   rmb  1
ib_cnt:   rmb  1
ib_rt:    rmb  1
ib_rn:    rmb  2
ib_p:     rmb  2
ib_fn:    rmb  10
ib_map:   rmb  13
ib_buf:   rmb  256
