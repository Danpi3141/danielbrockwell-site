; =====================================================================
; Engine: evaluation (ref/search.js evaluate, endgame, mopup).
; e_eval returns D = score in centipawns from the side to move's view.
; =====================================================================

ev_pop:  fcb 0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4,1,2,2,3,2,3,3,4,2,3,3,4,3,4,4,5
         fcb 1,2,2,3,2,3,3,4,2,3,3,4,3,4,4,5,2,3,3,4,3,4,4,5,3,4,4,5,4,5,5,6
ev_dblm: fcb 0,0,10,20,30,40,50
ev_dble: fcb 0,0,20,40,60,80,100
ev_isom: fcb 0,10,20,30,40,50,60
ev_isoe: fcb 0,15,30,45,60,75,90
ev_pw:   ; White pawn ranks that are passed, by Black mask (index (mask>>1)&63)
        fcb  $7E,$7E,$7C,$7C,$78,$78,$78,$78,$70,$70,$70,$70,$70,$70,$70,$70
        fcb  $60,$60,$60,$60,$60,$60,$60,$60,$60,$60,$60,$60,$60,$60,$60,$60
        fcb  $40,$40,$40,$40,$40,$40,$40,$40,$40,$40,$40,$40,$40,$40,$40,$40
        fcb  $40,$40,$40,$40,$40,$40,$40,$40,$40,$40,$40,$40,$40,$40,$40,$40
ev_pb:   ; Black pawn ranks that are passed, by White mask
        fcb  $7E,$02,$06,$02,$0E,$02,$06,$02,$1E,$02,$06,$02,$0E,$02,$06,$02
        fcb  $3E,$02,$06,$02,$0E,$02,$06,$02,$1E,$02,$06,$02,$0E,$02,$06,$02
        fcb  $7E,$02,$06,$02,$0E,$02,$06,$02,$1E,$02,$06,$02,$0E,$02,$06,$02
        fcb  $3E,$02,$06,$02,$0E,$02,$06,$02,$1E,$02,$06,$02,$0E,$02,$06,$02
ev_cmd:  fcb 6,5,4,3,3,4,5,6,5,4,3,2,2,3,4,5,4,3,2,1,1,2,3,4,3,2,1,0,0,1,2,3
         fcb 3,2,1,0,0,1,2,3,4,3,2,1,1,2,3,4,5,4,3,2,2,3,4,5,6,5,4,3,3,4,5,6

; e_emg / e_eeg += or -= the unsigned byte B
ev_amg:  clra
        addd e_emg
        std  e_emg
        rts
ev_aeg:  clra
        addd e_eeg
        std  e_eeg
        rts
ev_smg:  clra
        std  e_t
        ldd  e_emg
        subd e_t
        std  e_emg
        rts
ev_seg:  clra
        std  e_t
        ldd  e_eeg
        subd e_t
        std  e_eeg
        rts

; B = number of pawns in mask A (ranks 1..6)
ev_n:   lsra
        anda #63
        tab
        ldx  #ev_pop
        abx
        ldab 0,x
        rts

e_eval: tst  e_pcv              ; pawn structure: the same masks as last time?
        beq  .calc
        ldx  #e_pm
        ldd  1,x
        subd e_pcm
        bne  .calc
        ldd  3,x
        subd e_pcm+2
        bne  .calc
        ldd  5,x
        subd e_pcm+4
        bne  .calc
        ldd  7,x
        subd e_pcm+6
        bne  .calc
        ldd  11,x
        subd e_pcm+8
        bne  .calc
        ldd  13,x
        subd e_pcm+10
        bne  .calc
        ldd  15,x
        subd e_pcm+12
        bne  .calc
        ldd  17,x
        subd e_pcm+14
        bne  .calc
        ldd  e_pcmg
        std  e_emg
        ldd  e_pceg
        std  e_eeg
        jmp  .mat
.calc:  ldd  #0                 ; (17 Nov: X kept on the file, the pawns counted only when
        std  e_emg              ;  doubled or isolated needs it; the same result)
        std  e_eeg
        ldx  #e_pm
.file:  stx  e_t+6              ; X+1 White mask, +11 Black, neighbours either side
        ldaa 1,x
        beq  .black
        staa e_ew
        tab                     ; two or more (mask & (mask - 1)): doubled
        decb
        andb e_ew
        beq  .wiso
        jsr  ev_n
        stab e_er               ; n
        ldx  #ev_dblm
        abx
        ldab 0,x
        jsr  ev_smg
        ldab e_er
        ldx  #ev_dble
        abx
        ldab 0,x
        jsr  ev_seg
        ldx  e_t+6
.wiso:  ldaa 0,x
        oraa 2,x
        bne  .wpas
        ldaa e_ew
        jsr  ev_n
        stab e_er
        ldx  #ev_isom
        abx
        ldab 0,x
        jsr  ev_smg
        ldab e_er
        ldx  #ev_isoe
        abx
        ldab 0,x
        jsr  ev_seg
        ldx  e_t+6
.wpas:  ldaa 10,x
        oraa 11,x
        oraa 12,x
        lsra
        anda #63
        tab
        ldx  #ev_pw
        abx
        ldaa 0,x
        anda e_ew
        beq  .bl0
        staa e_eo               ; passed pawns' ranks
        ldab #1
.wr:    stab e_er
        ldx  #e_bit
        abx
        ldaa 0,x
        bita e_eo
        beq  .wn
        ldx  #t_pasmg
        abx
        ldab 0,x
        jsr  ev_amg
        ldab e_er
        ldx  #t_paseg
        abx
        ldab 0,x
        jsr  ev_aeg
.wn:    ldab e_er
        incb
        cmpb #7
        bne  .wr
.bl0:   ldx  e_t+6
.black: ldaa 11,x
        beq  .next
        staa e_ew
        tab
        decb
        andb e_ew
        beq  .biso
        jsr  ev_n
        stab e_er
        ldx  #ev_dblm
        abx
        ldab 0,x
        jsr  ev_amg
        ldab e_er
        ldx  #ev_dble
        abx
        ldab 0,x
        jsr  ev_aeg
        ldx  e_t+6
.biso:  ldaa 10,x
        oraa 12,x
        bne  .bpas
        ldaa e_ew
        jsr  ev_n
        stab e_er
        ldx  #ev_isom
        abx
        ldab 0,x
        jsr  ev_amg
        ldab e_er
        ldx  #ev_isoe
        abx
        ldab 0,x
        jsr  ev_aeg
        ldx  e_t+6
.bpas:  ldaa 0,x
        oraa 1,x
        oraa 2,x
        lsra
        anda #63
        tab
        ldx  #ev_pb
        abx
        ldaa 0,x
        anda e_ew
        beq  .nx0
        staa e_eo
        ldab #1
.br:    stab e_er
        ldx  #e_bit
        abx
        ldaa 0,x
        bita e_eo
        beq  .bn
        ldaa #7                 ; relative rank 7 - r
        suba e_er
        tab
        ldx  #t_pasmg
        abx
        ldab 0,x
        jsr  ev_smg
        ldaa #7
        suba e_er
        tab
        ldx  #t_paseg
        abx
        ldab 0,x
        jsr  ev_seg
.bn:    ldab e_er
        incb
        cmpb #7
        bne  .br
.nx0:   ldx  e_t+6
.next:  inx
        cpx  #e_pm+8
        beq  .pair
        jmp  .file
        ; bishop pair
.pair:  ldx  #e_pm               ; remember this pawn structure and its score
        ldd  1,x
        std  e_pcm
        ldd  3,x
        std  e_pcm+2
        ldd  5,x
        std  e_pcm+4
        ldd  7,x
        std  e_pcm+6
        ldd  11,x
        std  e_pcm+8
        ldd  13,x
        std  e_pcm+10
        ldd  15,x
        std  e_pcm+12
        ldd  17,x
        std  e_pcm+14
        ldd  e_emg
        std  e_pcmg
        ldd  e_eeg
        std  e_pceg
        ldaa #1
        staa e_pcv
.mat:   ldd  e_mg               ; material and PST
        subd e_mg+2
        addd e_emg
        std  e_emg
        ldd  e_eg
        subd e_eg+2
        addd e_eeg
        std  e_eeg
        ldaa e_cnt+3
        cmpa #2
        bcs  .p2
        ldab #25
        jsr  ev_amg
        ldab #40
        jsr  ev_aeg
.p2:    ldaa e_cnt+11
        cmpa #2
        bcs  .p3
        ldab #25
        jsr  ev_smg
        ldab #40
        jsr  ev_seg
.p3:    ldx  #e_emg             ; clamp both to +-2000
        bsr  ev_clamp
        ldx  #e_eeg
        bsr  ev_clamp
        ; blend: (mg*ph + eg*(16-ph)) >> 4
        ldab e_phase
        cmpb #24
        bls  .ph
        ldab #24
.ph:    ldx  #t_ph16
        abx
        ldab 0,x
        stab e_er               ; ph
        ldd  e_emg
        jsr  ev_mul
        std  e_es
        ldaa #16
        suba e_er
        staa e_er
        ldd  e_eeg
        jsr  ev_mul
        addd e_es
        bpl  .tz                ; round towards zero (colour-flipped twins score alike)
        addd #15
.tz:    asra
        rorb
        asra
        rorb
        asra
        rorb
        asra
        rorb
        std  e_es
        jsr  ev_end
        ldd  e_margin           ; levels 1-4 (17 Nov): noise ((h - 128) * k) / 16, k = e_margin,
        beq  .nz                ; h = the key's low byte ^ this search's seed: within +-8k, the
        ldaa e_margin+1         ; same for a position all through one search
        ldab #128
        mul
        std  e_t+2              ; 128 k
        ldaa e_key+2
        eora e_nseed
        ldab e_margin+1
        mul                     ; h k
        subd e_t+2
        asra
        rorb
        asra
        rorb
        asra
        rorb
        asra
        rorb
        addd e_es
        std  e_es
.nz:    ldd  e_es
        tst  e_side
        beq  .r
        coma
        comb
        addd #1
.r:     rts

; clamp the word at X to -2000..2000
ev_clamp: ldd 0,x
        bmi  .neg
        subd #2001
        bmi  .ok
        ldd  #2000
        std  0,x
.ok:    rts
.neg:   addd #2000
        bpl  .ok
        ldd  #-2000
        std  0,x
        rts

; D = D * e_er (D signed, |D| <= 2000, e_er 0..16)
ev_mul: clr  e_t+5              ; sign
        tsta
        bpl  .p
        inc  e_t+5
        coma
        comb
        addd #1
.p:     staa e_t+4              ; high byte
        ldaa e_er
        mul                     ; low byte * m
        std  e_t+2
        ldaa e_t+4
        ldab e_er
        mul                     ; high * m (fits in B)
        tba
        clrb
        addd e_t+2
        tst  e_t+5
        beq  .r
        coma
        comb
        addd #1
.r:     rts

; ---------------------------------------------------------------------
; endgame rules on e_es (White's view)
; ---------------------------------------------------------------------
ev_end: ; White cannot win: no pawns, no rook or queen, and a lone minor or two knights
        ldd  e_es
        ble  .b
        ldaa e_cnt+1
        bne  .b
        ldaa e_cnt+4
        adda e_cnt+5
        bne  .b
        ldaa e_cnt+2
        adda e_cnt+3
        cmpa #2
        bcs  .w0
        ldaa e_cnt+2
        cmpa #2
        bne  .b
        tst  e_cnt+3
        bne  .b
.w0:    ldd  #0
        std  e_es
.b:     ldd  e_es
        bge  .bare
        ldaa e_cnt+9
        bne  .bare
        ldaa e_cnt+12
        adda e_cnt+13
        bne  .bare
        ldaa e_cnt+10
        adda e_cnt+11
        cmpa #2
        bcs  .b0
        ldaa e_cnt+10
        cmpa #2
        bne  .bare
        tst  e_cnt+11
        bne  .bare
.b0:    ldd  #0
        std  e_es
        ; bare kings
.bare:  ldaa e_cnt+10           ; Black bare?
        adda e_cnt+11
        adda e_cnt+12
        adda e_cnt+13
        adda e_cnt+9
        staa e_t                ; 0 if Black has only the king
        ldaa e_cnt+2
        adda e_cnt+3
        adda e_cnt+4
        adda e_cnt+5
        adda e_cnt+1
        staa e_t+1              ; 0 if White has only the king
        tst  e_t
        bne  .wb
        tst  e_t+1
        beq  .clamp
        ldd  e_es
        ble  .clamp
        ldab #1                 ; Black is the loser
        jsr  ev_mop
        addd e_es
        std  e_es
        bra  .clamp
.wb:    tst  e_t+1
        bne  .clamp
        ldd  e_es
        bge  .clamp
        clrb                    ; White is the loser
        jsr  ev_mop
        std  e_t
        ldd  e_es
        subd e_t
        std  e_es
.clamp: ldd  e_es
        bmi  .cn
        subd #3001
        bmi  .cr
        ldd  #3000
        std  e_es
.cr:    rts
.cn:    addd #3000
        bpl  .cr
        ldd  #-3000
        std  e_es
        rts

; D = mop-up bonus for the side whose opponent (colour B: 0 White, 1 Black) has a bare king
ev_mop: stab e_t+2              ; loser
        ldx  #e_ksq
        abx
        ldaa 0,x
        staa e_t+3              ; loser's king
        eorb #1
        ldx  #e_ksq
        abx
        ldaa 0,x
        staa e_t+4              ; winner's king
        aslb
        aslb
        aslb
        stab e_t+5              ; winner's colour (0/8)
        ldx  #e_cnt
        abx
        ldaa 4,x                ; rooks + queens
        adda 5,x
        bne  .edge
        ldaa 3,x
        cmpa #1
        bne  .edge
        ldaa 2,x
        beq  .edge
        ; bishop and knight: find the bishop
        ldaa #3
        oraa e_t+5
        staa e_t+6
        clrb
.fb:    ldx  #e_board
        abx
        ldaa 0,x
        cmpa e_t+6
        beq  .gotb
        incb
        bitb #8
        beq  .fb
        addb #8
        bpl  .fb
        clrb
.gotb:  tba                     ; dark if (file + rank) even
        anda #7
        lsrb
        lsrb
        lsrb
        lsrb
        aba
        anda #1
        bne  .light
        ldaa e_t+3              ; dark: corners a1, h8
        ldab #$00
        bsr  ev_md
        stab e_t+7
        ldaa e_t+3
        ldab #$77
        bra  .min
.light: ldaa e_t+3              ; light: corners h1, a8
        ldab #$07
        bsr  ev_md
        stab e_t+7
        ldaa e_t+3
        ldab #$70
.min:   bsr  ev_md
        cmpb e_t+7
        bcs  .m1
        ldab e_t+7
.m1:    negb                    ; edge = 7 * (14 - d1) + CMD(loser's king)
        addb #14
        ldaa #7
        mul
        stab e_t+7
        ldab e_t+3
        tba
        anda #7
        aba
        lsra
        tab
        ldx  #ev_cmd
        abx
        ldab 0,x
        addb e_t+7
        bra  .tot
.edge:  ldab e_t+3              ; centre Manhattan distance of the loser's king
        tba
        anda #7
        aba
        lsra
        tab
        ldx  #ev_cmd
        abx
        ldab 0,x
.tot:   ldaa #16                ; 16 * edge + 20 * (14 - md(kings)) (tools/audit/tune_mop.js)
        mul
        std  e_t+6
        ldaa e_t+3
        ldab e_t+4
        bsr  ev_md
        negb
        addb #14
        ldaa #20
        mul
        addd e_t+6
        rts

; ---------------------------------------------------------------------
; B = Manhattan distance between 0x88 squares A and B
ev_md:  psha
        pshb
        anda #7
        andb #7
        sba
        bcc  .f
        nega
.f:     staa e_t
        pulb
        pula
        lsra
        lsra
        lsra
        lsra
        lsrb
        lsrb
        lsrb
        lsrb
        sba
        bcc  .r
        nega
.r:     adda e_t
        tab
        rts
