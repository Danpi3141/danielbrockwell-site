# The engine (milestones 0, 2, 4 and part of 6)

The chess engine is 6303 assembler in `src/engine/`, resident in RAM while the game runs. It was
written against a reference engine in JavaScript (`ref/`) and is tested against it routine by
routine: the same moves, the same evaluation, and the same search, node for node.

## What was built

| Part | Files | Status |
|---|---|---|
| Reference engine (in JavaScript, not C: no C compiler on this PC; Node was already there) | `ref/engine.js`, `ref/search.js`, `ref/tables.js`, `ref/uci.js` | done; plays over UCI |
| Move generation check | `ref/perft.js` | 20, 400, 8,902, 197,281, 4,865,609 and five other standard positions: all match |
| Opening book: since 16 Nov a position book (4,887 positions, 15,363 bytes, `tools/book/build_pbook.py`, `tools/book/README.md`; before: the tree book, 5,744 moves, 11,602 bytes after the book audit, docs/audit-book.md) | `tools/book/`, `data/book.bin` | done, validated (every move legal, lengths checked) |
| King and pawn v king: since 16 Nov a distance table (49,152 bytes, `data/kpkd.bin`, `tools/kpk/kpkd.js`), played at the root by the kernel (`ref/kpkroot.js`), replacing the win/draw table below | `tools/kpk/` | the distances agree with the win/draw table on every position; 20,000 play-outs exact (t_kpkroot) |
| (before: King and pawn v king table, 24,576 bytes) | `tools/kpk/`, `data/kpk.bin` | done; agrees with two independent solvers bit for bit; 76.5% of White-to-move positions are wins |
| Engine in assembler | `src/engine/*.asm` | done; matches the reference on every test |
| Strength measurement | `tools/match/`, `docs/strength.md` | see that file and *Strength* below |

## How the engine works

As in the draft, with the changes listed under *Deviations*.

- **Board:** 0x88, 128 bytes. Pieces 1-6 (+8 for Black). Moves are two bytes; promotions to R, B, N
  use the spare bits 7 and 3 of the destination.
- **Generation:** all pseudo-legal moves in a fixed order. Each move carries an ordering score:
  - the table move gets 255;
  - captures get 160 + 8×victim − attacker;
  - promotions come next;
  - then the two killers;
  - quiet moves are scored by their piece-square gain.
- **Legality:** a move is made, then tested. The full attack test runs only when the mover was in check, the king moved, the move was en passant, or the piece left a line through its own king. Otherwise no move can expose the king.
- **Making and unmaking:** each ply has a 48-byte frame. It holds the undo record (captured piece, castling, en passant, half-move clock, key, totals) and the search's locals for that ply, so recursion only puts return addresses on the CPU stack.
- **Key:** 24-bit Zobrist key. Since 16 Nov there is one key a square: a White piece's key is it rotated left by type − 1 bits (pawn 0 … king 5), and a Black piece's has its three bytes rotated as well; with the side, castling and en-passant keys the table holds 77 keys (231 bytes; it was 397 keys, 1,191 bytes). `tools/zobtest.js` found no more same-key pairs than random keys give, in 4.8M positions including whole 3- and 4-ply search trees. The transposition table checks the top 16 bits and indexes by the low bits. Repetition keeps the top 16 bits of the key before each move.
- **Search:** iterative deepening with plain alpha-beta. PVS and late-move reductions are in the code but switched off: at the Psion's node counts they measured no better (see *Strength*). Also:
  - transposition table: 7-byte entries (key 16 bits, move, score, `depth<<2 | flag`), 128 to 512 of them; its score cuts the search off at any node but the root (since 17 Nov; before only with a zero window, which plain alpha-beta hardly ever has), except in a search where a side has a bare king (`e_bare`: with cut-offs the bishop-and-knight mates fell from 80% to 73% of random starts, with stalemates);
  - no null move (removed 17 Nov: with plain alpha-beta it was never tried; docs/strength.md section 13);
  - check extension, and a futility cut at the last ply (margin 150);
  - quiescence: captures and promotions only; a capture by a higher piece type onto a defended square is not tried (audit change 8);
  - killer moves;
  - draws by repetition, fifty moves and too little material (since 16 Nov this includes bishops only, all on one square colour, whoever has them);
  - at the 100th half-move a side that is mated still scores as mated (a mate there ends the game, the fifty-move rule doesn't apply): the node checks for mate before it scores the draw;
  - mate scores carry their distance.
- **Depth 1 always finishes**, whatever the limit, so even level 1 plays a searched move.
- **Move stack:** 400 moves.
  - A node with more than 360 stacked below it is a leaf, and a list that would overflow is cut short.
  - An earlier cap at 180 cost strength (docs/strength.md).
- **Evaluation** (16-bit, centipawns):
  - incrementally kept material and piece-square totals, middlegame and endgame, from PeSTO's tables;
  - doubled, isolated and passed pawns (with a one-entry cache of the pawn score);
  - the bishop pair;
  - a taper between middlegame and endgame by phase;
  - endgame rules: a side with only a lone minor or two knights can't win, and a bare king is driven to the edge (B+N: to the bishop's corner), with the winning king brought close;
  - exact king and pawn v king scores from the table when its slices are loaded.
- **Time:** the engine reads the Organiser's 50 ms frame counter every 32 nodes, and calls the kernel's `think_poll`, which can stop on a key.
  - It stops at once when the limit is reached, or when there is only one legal move.
  - It starts no new depth after half the time is used.
- **Levels 1-4 (since 17 Nov):** noise in the evaluation, ((h - 128) * k) / 16 centipawns, h = the key's low byte xor a seed drawn for each search (so a position keeps its noise all through one search and the table stays consistent); k = 100, 53, 25, 14 for levels 1-4 (within +-800 ... +-112 cp), calibrated to the old levels' strength (docs/strength.md section 13). Until 17 Nov a margin pass: every root move searched again and a random one played within a margin of the best (docs/audit-engine.md).
- **Switches:** `E_NULL`, `E_LMR`, `E_FUT`, `E_CHKEXT` and `E_PVS` in `engine.asm` match `opts` in `ref/search.js`.

## Measured

| Measure | Value |
|---|---|
| Key history (repetitions) | 122 entries of 2 bytes (`E_KMAX`, 136 until 17 Nov): the game's part is emptied at an irreversible move and capped at `E_KCAP` = 100 (the half-move clock bounds it, and at 100 the game is over); a search adds one a ply, and moves are made up to ply `E_MAXPLY`-2 = 22. So at most 99 + 23 = 122; the old 136 was 104 (the old cap) + 32. `tests/engine/t_khist.js` drives it to its worst case: 99 after the game's moves, 108 in searches, statuses all equal to the reference. -28 bytes. |
| Code + tables | 9,737 bytes before the audit, +103 after it (docs/audit-engine.md); about 7.6K of it code (tables: Zobrist 1,191, PSTs 768); 16 Nov: Zobrist 231 bytes (−944 net); 17 Nov speed-ups +147, memory savings -765 (engine) |
| RAM kept between moves | 484 bytes |
| Scratch while thinking (shared with the screens' overlay slot) | 2,527 bytes (2,908 until 17 Nov: the margin pass's score list went, then the search frames went from 48 to 43 bytes) |
| Speed, bare CPU at 0.92 MHz | ~95-140 nodes a second (opening ~95, endings ~130) before the audit; about 18% fewer after its quiescence pruning (t_search's 16 positions: 104 -> 85), which searches deeper per node |
| Speed with the OS running (interrupts) | ~75-120 nodes a second |
| Depth at 30 s (level 7) | typically 3-4 plies in the middlegame, plus checks and captures |
| Mates in self-play at 2,500 nodes a move (30 s) | random starts: KQK 50/50, KRK 50/50, KBBK 50/50, KBNK 38/50 (80/100 on another seed); `ref/mates.js`'s three fixed KBNK starts: 1/3 |

The draft guessed 150-300 positions a second; the measured figure is about 100. So 30 seconds is
about 2,500 nodes, not 6,000.

## Speed-ups (17 Nov)

Profiled with `tools/audit/profile.js` (cycles by routine, eng_think on the bare CPU, 7 middlegame
positions at 1,500 nodes). Each change leaves the search exactly as it was (same moves, scores,
depths and node counts: the whole engine suite passes unchanged), so it is pure speed:

| Change | RAM | Cycles a node | Speed |
|---|---|---|---|
| Before | | 14,629 | 63.0 nodes/s bare |
| 1. The parent frame kept in `e_ofp` (was `e_own`, computed at each use) | +10 | 14,607 | +0.15% |
| 2. Castling rights: `e_make` already skipped the update with none left (the rest is 0.4% of the time) | 0 | | already there |
| 3. The moving piece updated by its PST difference (`e_mvpc`, `pc_key`, `pc_dif`); unmake skips the counts when the same non-pawn piece comes back; the pawn-mask code shared (`u_pm`) | +137 | 13,669 | +6.9% (t_search's 16 positions: 84 -> 90 nodes/s) |
| 4. The table's move tried before generating the rest | not built | | about 2% at best |

Change 4 was measured in the JS reference first: the table's move cuts off before generation at
only about 10% of the full-width nodes (178 of 1,795 at 1,500 nodes), and most generation is in the
quiescence search, which has no table move. It would also need a check that the move is possible
(about 150 bytes) and would change the tree slightly (the move stack's cap), so it was left out.

Strength: +6.9% nodes at the same time is about +8 Elo at levels 5-8 (81-95 Elo a doubling between
levels 6, 7 and 8), less at levels 1-4 (their random pick dominates). The level menu's figures are
rounded to 50, so they stay. Where the time goes now: the attack test 11.6% (mostly the in-check
test at every node), generation about 28%, evaluation 9%, picking moves 7%, the key and PST index
(`pc_key`, with the Zobrist rotation) 6%.

## Memory savings (17 Nov)

Four changes, one at a time; each stage rebuilt to measure it (RAM = the array with the 512-entry
table; pack = the object code on the pack; Elo from docs/strength.md section 13):

| Change | Code | Variables | Shared slot | **RAM** | **Pack** | Elo |
|---|---|---|---|---|---|---|
| Before | 12,243 | 1,194 | 2,908 | 19,929 | 61,494 | |
| E. Castling generator: one routine for both sides | -87 | | | **-87** | **-95** | 0 (same moves) |
| A. Null move removed (`E_NULL = 0`; never tried with plain alpha-beta) | -289 | | | **-289** | **-339** | 0 (same moves) |
| D. Levels 1-4: evaluation noise instead of the margin pass (`e_marg`, `e_mod` and the 256-byte score list in the scratch gone) | -389 | +1 | -34 | **-422** | **-472** | levels 1-4 +1 to +14 (within the noise); levels 5-8 0 |
| C. Shared slot: the map's glyphs are kernel data (no copy routine, no `brd_init`); the clocks' reset moved from the board overlay to OV_GAME (entry 13) | +17 | -65 | -222 | **-270** | **-86** | 0 (same moves) |
| Review fix: the resign test allows for the noise (below) | +6 | | | **+6** | **+7** | |
| **After** | 11,501 | 1,130 | 2,652 | **18,867** | **60,509** | |
| **Total** | -742 | -64 | -256 | **-1,062** | **-985** | |

The shared slot is now the engine's scratch (2,652); the largest screen, the board, is 2,641
(was 2,874). The array is about 2,530 bytes inside what an empty LZ64 allows; with 21,750 bytes
free the game now also has room for its save file. The `psion/` folder is 58,020 bytes (was 59,005);
58,013 after the coverage sweep below.
**Coverage sweep (17 Nov).** The kernel and engine as the game runs them, under `CHESS_COVER`:
the UI suite, the long UI tests (low memory, king and pawn, import, 15 minutes of clock, take back
in full, the soak; 133 coverage files, `tools/cover/covmap.js`), and the engine suite
(`tools/audit/engcover.js`), an instruction counting as unrun only if neither ran it:
- `eng_find` (31 bytes) was never called by the game, only by two engine tests: removed, the tests
  look in `eng_legal`'s list (`harness.js` `hasMove`). -33 RAM, -39 pack.
- The table's score cut-off (`tt_in`) never ran in a game: it was taken only with a zero window,
  which plain alpha-beta hardly ever has (level 7: 22,463 entries deep enough, 77 cut-offs). Now
  taken at every node but the root, in both engines (the zero-window flag `F_PV` is now worked out
  only for the switched-off null move), except while a side has a bare king: everywhere, the mates
  with bishop and knight came off (80% -> 73% of 800 random starts, 4 stalemates); a fifty-move
  limit (no cut-offs past half-move 80) removed the stalemates but not the loss, no cut-off on a
  stored 0 did neither. With the bare-king rule: 641/800 mated (was 636), no stalemates; +2, +9,
  +8 Elo at levels 5, 7, 8 (docs/strength.md section 14).
- The Auto level's adjustment had never run in any test. `tests/ui/t_auto.js` (in run_all) found
  that a win by the computer's resignation and a loss on time did not move it; both now do (+3
  bytes of kernel, +3 in the board overlay, which stays inside the slot).
- Kept: `ov_bpk` (17 bytes: the overlay loader's case of a long fix-up gap split across two reads,
  which no build has made yet), `e_mated` (the rare mate on the 100th half-move), and 64 bytes of
  engine safety paths (nothing searched in time, the move-stack cap, the node counter's third byte,
  the endgame score clamp, the table's mate-score adjustment). 613 bytes inside kernel routines
  that ran are error and rare paths (messages, a full game record, a clock-capped level, the depth
  past 9).

| Change | Code | **RAM** | **Pack** |
|---|---|---|---|
| Before | 11,501 | 18,867 | 60,509 |
| `eng_find` removed | -33 | **-33** | **-39** |
| Table cut-offs at every node (-17), not with a bare king (+36) | +19 | **+19** | **+24** |
| Auto after the computer's resignation and a flag fall | +3 | **+3** | **+8** |
| **After** | 11,490 | **18,856** | **60,502** |

Then two rules fixes in the screens (17 Nov): a flag falling against a side with only its king is
a draw (FIDE 6.9; it was a win: the code's comment said so, the test was never written), in the
board overlay; and choosing Auto in the settings starts it from the level in force (it started
from 8 or 1, the level stepped past to reach Auto). The hint's text moved from the board overlay
to OV_GAME (entry 14) to make room, so the shared slot stays the engine scratch: +3 RAM (18,859),
+41 pack (60,543). Tests `tests/ui/t_flag.js` (new) and `t_auto.js`.


**Review (17 Nov).** Every changed line read again, and new tests:
- `tests/engine/t_castle.js` (in run_all): 3,000 positions built around castling by
  `tools/audit/gen_castle.py` with python-chess (kings at home or not; own, enemy or no rook in
  the corners; pieces between; attackers on the king's square, the square it passes, where it
  lands and b1/b8; any rights, also rights without king or rook at home): the legal moves equal
  python-chess's in all of them, and each of the 1,129 castling moves gives python-chess's board,
  side and rights. Every legal move there and in 40 random games (268,438 moves) is made and
  unmade, and after each make the kept state (king squares, totals, phase, counts, pawn masks,
  key) equals a full recompute, and unmake restores everything. Two deliberate bugs (the passed
  square not tested; the endgame total updated into the middlegame's) were both caught.
- A rule kept as it was: the engine keeps a castling right set without its king and rook at home
  (python-chess drops it). SET UP POSITION and pgn2psion.py never give one, and it can never be
  used: castling needs the king and rook there, and a move onto e1, a1 or h1 (e8, a8, h8)
  clears the rights that go with the square. The test compares the rights as python-chess
  reports them.
- Found and fixed: the computer's resignation (three moves in a row below -9 pawns) read the
  score with levels 1-4's noise in it. Measured over 2,160 looks at positions not lost, level 1
  reported below -9 pawns 14 times (0.65%; the margin pass 0). The test is now below
  -900 - 8k (the noise moves a score by at most 8k): 0 times at every level, and lost positions
  are still seen. `tests/ui/t_resign.js` (in run_all) checks the threshold at both edges for
  every k and that three in a row resign. The draw offer was already safe (a noise-free look).
- Found and fixed (tests only): the JS reference used k in full where the Psion uses its low
  byte, so the soak's old margin values (300) differed; the reference now takes the low byte.
- Also checked: the moved clock reset is only called from resident kernel code; the LCD's eight
  glyphs are right after start-up and after leaving and resuming; an hour of 30|30 clock
  (`t_clock`): drift -1.5 s an hour, at most 2 frames a turn (the audit: -1.3 s, 3 frames);
  longer runs of the random-position test (200) and of whole assembler games v JS (16 games,
  1,369 moves) all match.

**Tried and not taken (17 Nov): the attack test as a loop.** `e_att` is unrolled: 578 bytes, a block
for each pawn and knight jump and each ray. Loops over the existing direction tables (`e_ndir`,
`e_bdir`, `e_rdir`; the same checks in the same order, so the same results: perft and the search
tests matched) were measured with `tools/audit/profile.js` (7 middlegame positions, cycles a node):

| Version | Code | Saves | Cycles a node | Speed |
|---|---|---|---|---|
| Unrolled (kept) | 11,278 | | 13,606 | |
| Pawns and knights as a loop | 11,083 | 195 | 14,320 | -5.0% |
| Rays as a loop | 11,122 | 156 | 14,315 | -5.0% |
| All as loops | 10,928 | 350 | 15,022 | -9.4% |

A loop costs about twice the unrolled code a square: the 6303 has one index register, needed for
the board, so the table pointer and the count go through memory. -9.4% speed is about -12 Elo at
levels 5-8 (the node-count slope); a tighter loop (zero-page pointer, a 0 ending each table) might
halve the loss, still several Elo. Not worth 350 bytes.

## Speed-ups, second round (17 Nov, evening)

Memory saved earlier in the day was traded for speed, keeping only changes that leave the search
exactly as it was: every engine test matches the JS reference unchanged (moves, scores, depths and
node counts), so no change can cost strength. Measured with `tools/audit/profile.js` (7 middlegame
positions at 1,500 nodes, the bare CPU):

| Change | Code | Cycles a node | Speed |
|---|---|---|---|
| Before | 10,993 | 13,593 | 67.8 nodes/s bare |
| 1. Quiet moves scored only when the pick first reaches one: the generator stores 148 (`E_QUNS`, between the quiet scores, 127 at most, and the killers' 149), and `e_pick` meeting it as the best scores every quiet move left (`e_qsc`) and picks again. Only about 30% of full lists ever reach a quiet move | +49 | 13,239 | +2.7% |
| 2. Check worked out from the last move (`e_gchk`): the moved piece giving check (a pawn or knight offset, a slider's line with nothing between) or a line opened through its from-square (one ray, `e_line`); en passant, castling, promotions and plies 0-1 use the full test. The legality test for a piece leaving the king's line scans that one ray. The quiescence search, which ran the full test on every capture, now works out once whether it is in check | +338 | 12,623 | +4.9% |
| 3. The pawn-structure loop: X kept on the file, pawns counted only when doubled or isolated needs the count | +8 | 12,326 | +2.4% |
| 4. `e_pick` keeps the best score in a register; the slider has its own captures-only loop; `g_put` no longer saves A | 0 | 12,077 | +2.1% |
| **Total** | **+395** | **12,077** | **+12.6%: 76.3 nodes/s bare** |

Change 2 was checked against a plain attack test on every call over 13 positions (22,291 check
tests, 39,164 legality answers, all equal). It relies on the position before the last move being
legal; at ply 1 that is the root, which set-up guarantees (`eng_setup`) but the tests' positions
need not, hence the full test there.

Strength: +12.6% nodes at the same time is about +15 Elo at levels 5-8 (12 Elo a 10%), less at
levels 1-4. Where the time goes now: generation 29% (the board scan alone about 4%), making and
unmaking with their piece, key and PST updates 28%, evaluation 10%, picking 7%, the key rotation
and PST index (`pc_key`) 7%, the check and line tests 4.3%, the full attack test 3.6%.

**Fail-low extension (18 Nov).** From depth 2, a first root move 100 or more below the last
depth's score lets the search run on past its limit, to twice it, until a move scores within the
100 or the depth ends, once a search (`E_FAILLOW`, ref `opts.failLow`; `e_flchk`, the limit tests
in `e_node`; the kernel's `think` sets the extra time `e_tadd`: the level's time, at most an eighth
of the clock left; not with a bare king). +36, +12 and +11 Elo at levels 5, 7 and 8 for about 1%
more time on average, 201 bytes; root ordering (`E_ROOTORD`, off) was measured with it and left out
(`docs/strength.md` s.15).

**Measured and not done:**
- *Staged generation* (captures first, quiet moves only if nothing cuts off). A captures-only list
  costs 5,422 cycles and a full one 7,771: the board scan and the rays are most of either, the quiet
  moves only about 2,350. Staging saves that at the 69% of full-width nodes that never reach a
  quiet move, but the other 31% would scan the board twice: about +30 cycles a node in all, and it
  would change the tree (the pick's swaps reorder equal captures), needing a match. Not worth it.
- *Unrolling the key rotation in `pc_key`*: about 40 cycles a node (0.3%) for 40 bytes.
- *A two-squares-at-a-time board scan*: pieces of either colour stop it on most ranks; small.

## Strength

`docs/strength.md` has the full measurement: Stockfish 19 with UCI_LimitStrength, 242 balanced
openings played with both colours, 95% intervals. Its headline, before the changes below, was
about 1625 at 2,500 nodes (30 s), 1700 at 6,000 nodes and 1840 at 15,000 nodes. Those are on
Stockfish's limited-strength scale, not a human rating.

After that report I applied its recommendations and measured again (484 games each, 2,500 nodes):

| Change or check | Result |
|---|---|
| Final engine v the measured one (move-stack fix, PVS and LMR off, depth 1 always finishes) | −14 [−36, +8]: no clear difference |
| Final engine v Stockfish 1600 | 53.2%, +22 [−6, +51] |
| PVS + LMR switched back on, with the move-stack fix | −10 [−36, +16] against off |
| PVS alone switched on | −17 [−43, +10] against off |

**Final engine at 2,500 nodes (30 s a move, level 7): about 1649 ± 17**, fitted over 1,452 games
against Stockfish 1500 (67.7%), 1600 (53.2%) and 1700 (49.1%). That is level with or slightly above
the first measurement (1626 ± 17). It sits at the bottom of the draft's 1500-1700 estimate.

**After the audit (16 Nov, docs/audit-engine.md):** the audited engine at equal time (2,120 nodes,
as it is 18% slower) scored 49.6% against the one above at 2,500 (−3 [−30, +24]) and 56.6% against
Stockfish 1600 (+46 [+19, +74]): about **1646** at level 7. All levels were measured again:
450, 650, 900, 1200, 1500, 1550, 1650, 1850 for levels 1-8 (docs/strength.md section 8; levels 1-3
from a self-play chain).

## Deviations from the draft

- **Reference engine in JavaScript, not C:** no C compiler was installed. Node runs it at about 1.5M nodes a second, plenty for the matches.
- **24-bit keys, not 32-bit, and keys derived from one key a square:** the Zobrist table is 231 bytes, not the draft's 3K. It costs about 1.5% speed (the rotation), and measured −4 to −14 Elo (all intervals include 0; docs/strength.md section 9).
  - The table still checks 16 bits, and repetition compares 16 bits.
  - A false repetition needs two different positions within the last 50 moves sharing the top 16 bits of the key. That is about one chance in 65,000 per comparison.
- **7-byte TT entries, not 6** (8 until 16 Nov): depth and flag share a byte; the index is ×8 − ×1. Six would need the depth or the move squeezed. An empty LZ64 gets 512 entries (3.5K); the launcher falls back to 256 or 128 when there is less RAM.
- **No piece list:** the generator scans the board with a pointer, 14 cycles a square.
- **No rook-on-open-file or castled-king pawn-shield terms:** RAM was the limit.
- **Plain alpha-beta, not PVS + LMR:** see *Strength*. Both are kept behind switches.
- **King and pawn v king (since 16 Nov) is not the engine's:** the kernel plays it from a 48K distance table, compressed to 11,930 bytes on the pack (`tools/kpk/kpkd_pack.js`), at the root, perfectly (the longest win is 19 moves to promote; 4-bit entries, a distance over 15 stored as d - 15). The engine's slice code is gone (327 bytes of code). Before: **the king-and-pawn table was exact for the pawn's current square:** with the 512-entry table, the square ahead's slices are loaded too. Other squares use the normal evaluation, with its steep passed-pawn bonus.
- **B+N mates are not fully reliable:** after the audit's mop-up tuning about 80% of random starts mate within the fifty-move rule (46% before); two of `ref/mates.js`'s three fixed starts still fail (the self-play test reports this as its one failure). Q and R mates are reliable.

## Tests

`node tests/engine/run_all.js` runs everything (about 20 minutes; `--quick` about 8). Each test
assembles the engine (`tests/engine/build_test.py`) and runs it on the emulated 6303 of a booted LZ64
(`tests/engine/harness.js`, using `tools/emu.js`):

| Test | What it checks |
|---|---|
| `t_perft.js` | move counts on the six standard positions, derived state after set-up, state restored after the walk |
| `t_api.js` | the UI routines (legal list, find, play, check, status incl. threefold, set-up refusals) over 30 random games, 4,800 positions, against the JS |
| `t_eval.js` | the evaluation on 7,367 positions from random games and endgame set-ups |
| `t_search.js [nodes] [margin]` | `eng_think` on 16 positions: same move, score, depth and node count as the JS |
| `t_fuzz.js [cases] [seed]` | the same on random positions with random node limits and margins (180 cases run in all: all match) |
| `t_kpkroot.js` | king and pawn v king from the distance table (ref/kpkroot.js), both sides, 3,000 random starts: the result always the old table's, each win in exactly the table's number of moves (it replaced `t_kpk.js`, the slices' test) |
| `t_time.js` | time limits with the OS's interrupts on |
| `t_game.js` | whole games, assembler v itself, compared with the JS move by move (a 120-ply game from the start; a rook ending to mate) |
| `ref/mates.js` | the mates above (JS, both sides played by the engine) |
| `t_perft2.js` | perft on 58 awkward positions, counts from python-chess (audit) |
| `t_rules.js` | the UI routines against python-chess: 76 special cases and 300 random games (audit) |
| `t_mirror.js` | evaluation of colour-flipped twins (audit) |
| `t_castle.js [games]` | castling v python-chess in 3,000 positions (tools/audit/gen_castle.py), and every make v a full recompute, unmake restoring all (17 Nov) |
| `t_soak_asm.js` | whole assembler games with mixed limits and margins v the JS (audit) |
| `t_time2.js` | time-limit overruns with the OS running (audit) |
| `t_prof.js`, `t_calls.js`, `t_trace.js` | tools: cycle profile per routine, calls by caller, node-by-node trace against the JS |

The last full run passed everything except the B+N mates noted above.

Bugs the tests caught on the way include:
- the move generator's direction counter sharing a byte with its pointer;
- a lost carry flag that disabled the check extension;
- the null-move child writing its moves over a live list;
- a test transposition table overlapping the engine (a harness bug);
- the table move being skipped when it started on a1, a bug in the JS reference too.

The strength agent independently found the a1 and null-move bugs in its copy of the reference.
It also found a front-end bug in `ref/uci.js` (game moves counted as search plies), now fixed.
