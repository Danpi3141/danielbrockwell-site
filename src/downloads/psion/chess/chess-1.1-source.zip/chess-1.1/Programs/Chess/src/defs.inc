; =====================================================================
; Chess for the Psion LZ64 - shared definitions
; =====================================================================

; ---- zero-page scratch (UTW_S0..S5). Clobbered by many OS calls.
T0      = $41
T1      = $42
T2      = $43
T3      = $44
T4      = $45
T5      = $46
T6      = $47
T7      = $48
T8      = $49
T9      = $4A
T10     = $4B
T11     = $4C

; ---- system variables and hardware
KBB_DLAY = $77                  ; key repeat delay (ticks)
KBB_REPT = $78                  ; key repeat rate (ticks)
KBB_STAT = $7B
KBB_CLIK = $20C0
TMW_FRAM = $20CB                ; frame counter, +1 every 50 ms
TMW_TOUT = $007D                ; seconds left to auto switch-off
TMW_TCNT = $20CD                ; auto switch-off time in seconds
TMB_SWOF = $007C                ; auto switch-off flag
KBB_PKOF = $20C1                ; KB$TEST switches the packs off when set
LCD_CTRL = $0180
LCD_DATA = $0181

; ---- key codes
K_ON    = 1
K_MODE  = 2
K_UP    = 3
K_DOWN  = 4
K_LEFT  = 5
K_RIGHT = 6
K_DEL   = 8
K_EXE   = 13
K_SPACE = 32

; ---- error codes returned to the launcher in X
E_OK     = 0
E_NOPACK = 1                    ; game files not found
E_FILES  = 2                    ; a block is missing or the wrong version

; ---- pieces (as the engine)
PC_P    = 1
PC_N    = 2
PC_B    = 3
PC_R    = 4
PC_Q    = 5
PC_K    = 6
PC_BLACK = 8

; ---- characters
CH_DIAM = 250                   ; empty dark square
CH_UP   = 169
CH_DOWN = 170
CH_BLOCK = 255

; ---- menu commands (the menu overlay returns one in A)
M_NONE  = 0
M_NEW   = 1
M_BACK  = 2
M_HINT  = 3
M_FLIP  = 4
M_SETTINGS = 5
M_LIST  = 6
M_RESIGN = 7
M_DRAW  = 8
M_SETUP = 9
M_EXIT  = 10
M_LEVEL = 11
M_PGN   = 12                    ; export the game as PGN (the move list's overlay, entry 1)
M_IMPORT = 13                   ; import a game (OV_IMPORT and im_game)
M_REVIEW = 14                   ; game review (OV_REVIEW and review in kcore.asm; 19 Nov)
M_SPEED = 15                    ; the speed test (only when SPEEDTEST)
SPEEDTEST = 0                   ; 0 since 16 Nov (hardware matched the emulator); 1 puts back the menu's SPEED TEST, for the first
                                ; tests on the Organiser; 0 takes it out (menu item, sp_test, OV_LIST entry 2)
M_LAST  = M_REVIEW+SPEEDTEST     ; the last menu command (do_menu's jump table)
; ---- game review's overlay entries (OV_REVIEW)
RV_START = 0
RV_KEY  = 1
RV_BEST = 2
RV_SNAP = 3
RV_MSG  = 4
RVF_SNAP = 1                    ; rv_on: the replay keeps snapshots
RVF_STEP = 2                    ;        a review step (whether in check only)
RVF_HELD = 4                    ;        its chunk already in rp_buf
