'use strict';
// Game review (19 Nov): the menu's GAME REVIEW steps through the game's positions, jumps by
// ten plies, analyses a position (with a table of half the size above its snapshots), plays on
// from any ply, and leaves the game exactly as it was.
//   node tests/ui/t_review.js
const L = require('./lib.js');
const G = require('./glib.js');
const { check, keys } = L;
const { Engine, legalMoves, uciStr } = require('../../ref/search.js');

// the user's level-5 game (pgn/Pgn1.odb): 53 plies, castling, captures, checks, mate at the end
const GAME = ('d2d4 d7d5 c1f4 g8f6 e2e3 c7c5 c2c3 b8c6 g1f3 c5d4 c3d4 c8e6 f1b5 f6e4 e1g1 a7a6 b5a4 a8c8 ' +
  'b1d2 e6f5 a1c1 e7e6 a4c6 c8c6 c1c6 b7c6 d2e4 f5e4 f3g5 f8d6 g5e4 d6f4 e3f4 d5e4 d1a4 e8g8 a4c6 d8d4 ' +
  'c6a6 d4d2 b2b3 d2f4 a6c6 e4e3 f2e3 f4e3 g1h1 f8d8 c6c7 d8d2 c7c8 d2d8 c8d8').split(' ');
const FR = 46080;                                   // cycles a frame (50 ms)
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const row3 = (m) => m.screenText().split('\n')[3] || '';
const S = (m, n) => L.sym(m, n);

const m = G.start();
G.twoPlayers(m);
G.menu(m, ['N']); G.waitInput(m, 10);
const cs = [G.engState(m)];
for (let i = 0; i < GAME.length; i++) {
  G.typeUci(m, GAME[i]);
  G.waitPly(m, i + 1, 30);
  if (m.peek(S(m, 'g_result'))) { keys(m, ['EXE']); G.waitInput(m, 10); }
  cs.push(G.engState(m));
}
const N = GAME.length;
check(m.peek(S(m, 'g_n')) === N && m.peek(S(m, 'g_result')) !== 0, `the game played: ${N} plies, mate`);
const ttn0 = m.peekw(S(m, 'e_ttn')), tt0 = m.peekw(S(m, 'e_tt'));
const before = { st: G.engState(m), tt: tt0, ttn: ttn0 };

// a key, then wait for review to want the next one; seconds from the key until the game waits
// for a key again (key_wait entered: the test's own wait for the processor to sleep can add more)
const KW = L.sym(m, 'key_wait');
function timed(fn) {
  let t = -1, c0 = m.cycles(), armed = false;
  m.dbg.setTrace((pc) => { if (armed && t < 0 && pc === KW) t = m.cycles(); });
  fn(() => { armed = true; c0 = m.cycles(); });
  m.dbg.setTrace(null);
  return t < 0 ? -1 : (t - c0) / FR / 20;
}
function key(k) { return timed((arm) => { arm(); keys(m, [k]); G.waitInput(m, 30); }); }
const tIn = timed((arm) => { keys(m, ['ON']); G.waitInput(m, 5); keys(m, ['G']); arm(); keys(m, ['EXE']); G.waitInput(m, 30); });
check(row3(m).includes('MOVE 27 OF 27') && m.peek(S(m, 'g_n')) === N, `GAME REVIEW opens at the last move: ${row3(m).trim()} (${tIn.toFixed(1)} s for ${N} plies)`, m);

// every ply backwards, then forwards: the engine's position as when it was first reached
let worstBack = 0, worstFwd = 0, bad = 0;
const steps = [];
for (let k = N - 1; k >= 0; k--) {
  const t = key('LEFT'); steps.push(t);
  worstBack = Math.max(worstBack, t);
  const st = G.engState(m);
  const want = k === 0 ? 'START, 27 MOVES' : `MOVE ${Math.floor((k + 1) / 2)} OF 27`;
  if (!same(st.pos, cs[k].pos) || st.g_n !== k || !row3(m).includes(want)) { if (bad++ < 3) console.log(`     ply ${k}: position ${same(st.pos, cs[k].pos)}, g_n ${st.g_n}, "${row3(m).trim()}" (want "${want}")`); }
}
check(bad === 0, 'LEFT through every ply to the start: each position as it was, and its move number');
keys(m, ['LEFT']); G.waitInput(m, 5);
check(m.peek(S(m, 'g_n')) === 0, 'LEFT at the start stays there');
bad = 0;
for (let k = 1; k <= N; k++) {
  const t = key('RIGHT'); steps.push(t);
  worstFwd = Math.max(worstFwd, t);
  if (!same(G.engState(m).pos, cs[k].pos)) bad++;
}
check(bad === 0, 'RIGHT through every ply to the end');
steps.sort((a, b) => a - b);
console.log(`     a step: median ${steps[steps.length >> 1].toFixed(2)} s, slowest back ${worstBack.toFixed(2)} s, forward ${worstFwd.toFixed(2)} s (a new 10-ply chunk read from A:)`);
check(worstBack < 1.5 && worstFwd < 1.5 && steps[0] > 0, 'every step under 1.5 s');

// jumps of ten plies
key('UP'); check(m.peek(S(m, 'g_n')) === N - 10 && same(G.engState(m).pos, cs[N - 10].pos), 'UP: ten plies back');
for (let i = 0; i < 5; i++) key('UP');
check(m.peek(S(m, 'g_n')) === 0 && same(G.engState(m).pos, cs[0].pos), 'UP stops at the start');
key('DOWN'); check(m.peek(S(m, 'g_n')) === 10 && same(G.engState(m).pos, cs[10].pos), 'DOWN: ten plies on');
for (let i = 0; i < 6; i++) key('DOWN');
check(m.peek(S(m, 'g_n')) === N && same(G.engState(m).pos, cs[N].pos), 'DOWN stops at the end');

// analysis: the score as text from White's view, "+0.42", "-1.05", "+M1" (mate in 1)
function scoreText() {
  let s = m.peekw(S(m, 'e_score')); if (s > 32767) s -= 65536;
  if (m.peek(S(m, 'e_side'))) s = -s;
  const a = Math.abs(s), sg = s < 0 ? '-' : '+';
  if (a > 29000) return sg + 'M' + Math.floor((30001 - a) / 2);
  return sg + Math.floor(a / 100) + '.' + String(a % 100).padStart(2, '0');
}
function legalAt(plies) {
  const e = new Engine(); e.setFen('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
  for (let i = 0; i < plies; i++) { const mv = legalMoves(e).find((x) => uciStr(e, x[0], x[1]) === GAME[i]); e.make(mv[0], mv[1]); e.ply = 0; }
  return legalMoves(e).map((x) => uciStr(e, x[0], x[1]).toUpperCase().slice(0, 4));
}
// the position before 25...Rd2?? (49 plies: 25.Qc7)
for (let i = 0; i < 4; i++) key('LEFT');
check(m.peek(S(m, 'g_n')) === 49, 'at 25.Qc7');
const c0a = m.cycles(); keys(m, ['SPACE']); G.waitInput(m, 30);
const ta = (m.cycles() - c0a) / FR / 20;                 // (think_poll calls key_wait: timed the whole way)
const best = (row3(m).match(/BEST ([A-H][1-8][A-H][1-8])/) || [])[1];
check(best && legalAt(49).includes(best) && row3(m).trim().endsWith(' ' + scoreText()),
  `SPACE analyses: "${row3(m).trim()}" (${ta.toFixed(1)} s; the engine's score ${scoreText()})`, m);
check(m.peekw(S(m, 'e_tt')) === tt0 + 880 && m.peekw(S(m, 'e_ttn')) === ttn0 / 2, `the analysis's table above the snapshots: ${ttn0 / 2} entries`);
check(same(G.engState(m).pos, cs[49].pos), 'the position unchanged by the analysis');
for (let i = 0; i < 3; i++) key('RIGHT');                // 26...Rd8: White mates in one
key('SPACE');
check(row3(m).includes('BEST C8D8 +M1'), 'a mate in one: ' + row3(m).trim(), m);

// leave: the game exactly as it was
const tOut = key('ON');
const after = G.engState(m);
check(same(after, before.st) && m.peekw(S(m, 'e_tt')) === tt0 && m.peekw(S(m, 'e_ttn')) === ttn0 && m.peek(S(m, 'msg_on')) === 0,
  `ON leaves review: the game, its key history and the table as before (${tOut.toFixed(1)} s)`);

// play from here, after a "no"
G.menu(m, ['G']); G.waitInput(m, 30);
for (let i = 0; i < 3; i++) key('UP');
for (let i = 0; i < 3; i++) key('LEFT');               // ply 20
key('P');
check(row3(m).includes('PLAY FROM HERE? EXE'), 'P asks: ' + row3(m).trim());
key('MODE');
check(row3(m).includes('MOVE 10 OF 27') && m.peek(S(m, 'g_n')) === 20, 'any other key says no');
key('P'); key('EXE');
const st20 = G.engState(m);
check(st20.g_n === 20 && same(st20.pos, cs[20].pos) && same(st20.khist, cs[20].khist) && m.peek(S(m, 'g_result')) === 0,
  'P, EXE plays on from ply 20: the position and its key history as when reached, the game open again');
check(m.peekw(S(m, 'e_ttn')) === ttn0, 'the table back to its size');
G.typeUci(m, 'a1c1');                                  // 11.Rc1 again: the game goes on
G.waitPly(m, 21, 30);
check(m.peek(S(m, 'g_n')) === 21, 'and a move can be played');

// a 256-entry table: analysis with 128; a 128-entry table: no room
for (const n of [256, 128]) {
  m.pokew(S(m, 'e_ttn'), n); m.pokew(S(m, 'e_ttmask'), n - 1);
  G.menu(m, ['G']); G.waitInput(m, 30);
  key('LEFT');
  key('SPACE');
  if (n === 256) check(/BEST [A-H][1-8][A-H][1-8]/.test(row3(m)) && m.peekw(S(m, 'e_ttn')) === 128, 'a 256-entry table: analysis with 128 entries', m);
  else check(row3(m).includes('MORE RAM TO ANALYSE') && m.peekw(S(m, 'e_ttn')) === 128, 'a 128-entry table: MORE RAM TO ANALYSE', m);
  key('ON');
  check(m.peekw(S(m, 'e_ttn')) === n && m.peek(S(m, 'g_n')) === 21, `left with the table at ${n} entries`);
}
m.pokew(S(m, 'e_ttn'), ttn0); m.pokew(S(m, 'e_ttmask'), ttn0 - 1);

// nothing to review; a set-up with Black to move numbers its moves as the move list does
G.menu(m, ['N']); G.waitInput(m, 10);
G.menu(m, ['G']); G.waitInput(m, 10);
check(row3(m).includes('NOTHING TO REVIEW') && m.peek(S(m, 'g_n')) === 0, 'a new game: NOTHING TO REVIEW', m);
G.setupFen(m, '4k3/8/8/8/8/8/4P3/4K3 b - - 0 1');
for (const [i, u] of ['e8d7', 'e2e4', 'd7e6'].entries()) { G.typeUci(m, u); G.waitPly(m, i + 1, 30); }
G.menu(m, ['G']); G.waitInput(m, 30);
check(row3(m).includes('MOVE 2 OF 2'), 'a set-up with Black to move: ' + row3(m).trim(), m);
key('LEFT'); key('LEFT');
check(row3(m).includes('MOVE 1 OF 2'), 'its first move is move 1: ' + row3(m).trim(), m);
key('ON');
console.log('all UI tests passed');
