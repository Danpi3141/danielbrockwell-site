; =====================================================================
; Game review (slot A; 19 Nov). The kernel's review loop (kcore.asm) does
; what needs the engine, whose scratch is this slot; this does the keys, the
; text and the snapshots. Nothing searches while reviewing, so the snapshots
; live in the transposition table's RAM:
;   TTBASE+0   the table's entries (e_ttn), to put back
;   TTBASE+2   the game's plies (g_n is the ply shown while reviewing)
;   TTBASE+3   1: "play from here?" has been asked
;   TTBASE+4   the record chunk in rp_buf (a step in it reads no file: 0.5 s)
;   TTBASE+5   25 snapshots of 35 bytes, one at each record chunk's first ply
;              (0, 10, 20 ...): a1..h8 4 bits a square, castling | side * 16,
;              en passant, half-move clock
; The analysis puts the table above them at half its size (512 -> 256 entries,
; 256 -> 128); with 128 there is no room: MORE RAM TO ANALYSE.
; Entries (RV_*): 0 start, C=1 if there is nothing to review (a message is
; left); 1 a key -> A = what the kernel does: 0 leave (the table and g_n put
; back), 1 go (a snapshot on the board, rp_i its ply, g_n the ply to show),
; 2 analyse (the table set), 3 show the board (a message), 4 play from here
; (g_n, the result and the table set); 2 the analysis's move and score into
; the message; 3 the board into the snapshot for rp_i (the kernel's replay);
; 4 the move line ("MOVE 12 OF 31") as the message.
; =====================================================================
        include "../defs.inc"
        include "ids.inc"

RV_TTN  = TTBASE
RV_N    = TTBASE+2
RV_ASK  = TTBASE+3
RV_CHK  = TTBASE+4
RV_SNAPS = TTBASE+5
SNAP_SZ = 35
RV_AREA = 5+25*SNAP_SZ          ; 880: the build checks it fits beside a 128-entry table

        jmp  rv_start
        jmp  rv_key
        jmp  rv_best
        jmp  rv_snap
        jmp  mv_msg

t_none: fcl  "NOTHING TO REVIEW"
t_read: fcl  "READING THE GAME"
t_ram:  fcl  "MORE RAM TO ANALYSE"
t_play: fcl  "PLAY FROM HERE? EXE"
t_nomv: fcl  "NO LEGAL MOVES"
t_move: fcl  "MOVE "
t_of:   fcl  " OF "
t_strt: fcl  "START, "
t_mvs:  fcl  " MOVES"
t_best: fcl  "BEST "
t_prom: fcc  "QRBN"

; ---------------------------------------------------------------------
; 0: start
rv_start:
        ldaa g_n
        beq  .none
        tst  g_nosv             ; no save file: no record
        bne  .none
        ldd  e_ttn
        std  RV_TTN
        ldaa g_n
        staa RV_N
        clr  RV_ASK
        deca                    ; the replay's last chunk stays in rp_buf: (plies - 1) / 10
        clrb
.c:     cmpa #10
        bcs  .c1
        suba #10
        incb
        bra  .c
.c1:    stab RV_CHK
        ldx  #t_read            ; (the replay takes about 0.6 s a 10-ply chunk)
        jsr  msg_set
        clc
        rts
.none:  ldx  #t_none
        jsr  msg_set
        sec
        rts

; ---------------------------------------------------------------------
; 1: a key
rv_key: clra
        jsr  key_wait
        jsr  key_upper
        tst  RV_ASK
        beq  .k
        clr  RV_ASK             ; "play from here?": EXE plays, anything else doesn't
        cmpb #K_EXE
        bne  .no
        clr  g_result
        clr  g_reason
        bsr  tt_back
        clr  msg_on
        ldaa #4
        rts
.no:    jsr  mv_msg
        ldaa #3
        rts
.k:     cmpb #K_RIGHT
        beq  .fwd
        cmpb #K_EXE
        beq  .fwd
        cmpb #K_LEFT
        beq  .back
        cmpb #K_DEL
        beq  .back
        cmpb #K_UP
        beq  .up
        cmpb #K_DOWN
        beq  .down
        cmpb #K_MODE
        beq  .mode
        cmpb #K_SPACE
        beq  .ana
        cmpb #'P'
        beq  .ask
        cmpb #K_ON
        bne  rv_key
        ldaa RV_N               ; leave: the game as it was
        staa g_n
        bsr  tt_back
        clr  msg_on
        clra
        rts
.fwd:   ldaa g_n
        cmpa RV_N
        bcc  .buzz
        inca
        bra  go
.back:  ldaa g_n
        beq  .buzz
        deca
        bra  go
.up:    ldaa g_n                ; ten plies back (to the start at most)
        beq  .buzz
        suba #10
        bcc  go
        clra
        bra  go
.down:  ldaa g_n                ; ten plies on (to the end at most)
        cmpa RV_N
        bcc  .buzz
        adda #10
        cmpa RV_N
        bls  go
        ldaa RV_N
        bra  go
.buzz:  ldx  #snd_buzz
        jsr  snd_play
        bra  rv_key
.mode:  ldaa v_half             ; the other half of the board
        eora #1
        staa v_half
        ldaa #3
        rts
.ask:   ldaa #1
        staa RV_ASK
        ldx  #t_play
        jsr  msg_set
        ldaa #3
        rts
.ana:   ldd  RV_TTN             ; the analysis's table above the snapshots, half the size
        subd #256
        bcs  .noram
        ldd  RV_TTN
        lsrd
        std  e_ttn
        ldd  #TTBASE+RV_AREA
        std  e_tt
        ldaa #2
        rts
.noram: ldx  #t_ram
        jsr  msg_set
        ldaa #3
        rts

; the table as it was (the kernel clears it: eng_ttinit)
tt_back:
        ldd  #TTBASE
        std  e_tt
        ldd  RV_TTN
        std  e_ttn
        rts

; A = the ply to show: g_n, the snapshot below it on the board, rp_i its ply
go:     staa g_n
        clrb                    ; B = (ply - 1) / 10, 0 at the start
        tsta
        beq  .s
        deca
.d:     cmpa #10
        bcs  .s
        suba #10
        incb
        bra  .d
.s:     stab rv_s
        ldaa #RVF_STEP          ; a step; its chunk read unless rp_buf has it (none at the start)
        tst  g_n
        beq  .f
        cmpb RV_CHK
        bne  .rd
        ldaa #RVF_STEP+RVF_HELD
        bra  .f
.rd:    stab RV_CHK
.f:     staa rv_on
        ldaa #10
        mul
        stab rp_i
        bsr  snap_x
        stx  rv_p
        ldx  #e_board           ; the board emptied (the 0x88 board's other half too)
        ldd  #128
        os   UT$FILL
        clr  rv_n
.u:     ldx  rv_p               ; two squares a byte
        ldaa 0,x
        inx
        stx  rv_p
        staa rv_b
        ldab rv_n
        bsr  sq88
        lsra
        lsra
        lsra
        lsra
        staa 0,x
        ldab rv_n
        incb
        bsr  sq88
        anda #$0F
        staa 0,x
        ldaa rv_n
        adda #2
        staa rv_n
        cmpa #64
        bne  .u
        ldx  rv_p
        ldaa 0,x
        tab
        anda #$0F
        staa e_castle
        andb #$80
        lsrb
        lsrb
        lsrb
        lsrb
        stab e_side
        ldaa 1,x
        staa e_ep
        ldaa 2,x
        staa e_half
        jsr  mv_msg
        ldaa #1
        rts

; B = square 0..63 -> X = its place on e_board, A = rv_b
sq88:   tba
        anda #$38
        asla
        andb #7
        aba
        tab
        ldx  #e_board
        abx
        ldaa rv_b
        rts

; X = snapshot rv_s
snap_x: ldaa #SNAP_SZ
        ldab rv_s
        mul
        addd #RV_SNAPS
        xgdx
        rts

; ---------------------------------------------------------------------
; 3: the board into the snapshot for rp_i (a chunk's first ply)
rv_snap:
        ldaa rp_i
        clrb
.d:     cmpa #10
        bcs  .s
        suba #10
        incb
        bra  .d
.s:     stab rv_s
        bsr  snap_x
        stx  rv_p
        clr  rv_n
.p:     ldab rv_n
        bsr  sq88
        ldaa 0,x
        asla
        asla
        asla
        asla
        staa rv_b
        ldab rv_n
        incb
        bsr  sq88
        ldaa 0,x
        oraa rv_b
        ldx  rv_p
        staa 0,x
        inx
        stx  rv_p
        ldaa rv_n
        adda #2
        staa rv_n
        cmpa #64
        bne  .p
        ldaa e_side             ; 0 or 8: * 16 = 0 or $80
        asla
        asla
        asla
        asla
        oraa e_castle
        staa 0,x
        ldaa e_ep
        staa 1,x
        ldaa e_half
        staa 2,x
        rts

; ---------------------------------------------------------------------
; the message: "MOVE 12 OF 31" (the move that led here), "START, 31 MOVES"
mv_msg: clr  rv_t
        ldaa g_n
        beq  .st
        ldx  #t_move
        bsr  put_s
        ldaa g_n
        bsr  move_no
        bsr  put_n
        ldx  #t_of
        bsr  put_s
        bra  .tot
.st:    ldx  #t_strt
        bsr  put_s
        ldaa RV_N
        bsr  move_no
        bsr  put_n
        ldx  #t_mvs
        bsr  put_s
        bra  .x
.tot:   ldaa RV_N
        bsr  move_no
        bsr  put_n
.x:     ldx  #rv_t
        jmp  msg_set

; A = plies -> D = the move number of the last of them, as the move list
; numbers them ((plies + 1 + b) / 2, b = 1 when a set-up started with Black)
move_no:
        clrb
        tst  g_setup
        beq  .w
        tst  g_spos+64
        beq  .w
        incb
.w:     aba
        inca
        lsra
        tab
        clra
        rts

; append the length-prefixed text at X to rv_t (at most 20 in all)
put_s:  ldab 0,x
        inx
.l:     tstb
        beq  .x
        ldaa 0,x
        bsr  put_c
        inx
        decb
        bra  .l
.x:     rts
; append D as a number
put_n:  jsr  num_str
        ldx  #kv_nbuf
        bra  put_s
; append the character A
put_c:  pshx
        pshb
        ldab rv_t
        cmpb #20
        bcc  .x
        incb
        stab rv_t
        ldx  #rv_t
        abx
        staa 0,x
.x:     pulb
        pulx
        rts

; ---------------------------------------------------------------------
; 2: the analysis's move and score: "BEST E2E4 +0.45", "BEST A7A8N -M3"
; (White's view; M = mate in so many moves)
rv_best:
        ldaa e_bestf
        oraa e_bestt
        bne  .m
        ldx  #t_nomv
        jmp  msg_set
.m:     clr  rv_t
        ldx  #t_best
        bsr  put_s
        ldaa e_bestf
        bsr  put_sq
        ldaa e_bestt
        bsr  put_sq
        ldab e_bestf            ; a pawn to the last rank: the piece it becomes
        ldx  #e_board
        abx
        ldaa 0,x
        anda #7
        cmpa #1
        bne  .np
        ldaa e_bestt
        anda #$70
        beq  .pr
        cmpa #$70
        bne  .np
.pr:    ldab e_bestt            ; promotion code: bit 3 = 1, bit 7 = 2 (0 = queen)
        clra
        bitb #8
        beq  .p1
        inca
.p1:    bitb #$80
        beq  .p2
        adda #2
.p2:    tab
        ldx  #t_prom
        abx
        ldaa 0,x
        bsr  put_c
.np:    ldaa #' '
        bsr  put_c
        ldd  e_score            ; White's view
        tst  e_side
        beq  .wv
        coma
        comb
        addd #1
.wv:    std  rv_sc
        ldaa #'+'
        tst  rv_sc
        bpl  .sg
        ldd  rv_sc
        coma
        comb
        addd #1
        std  rv_sc
        ldaa #'-'
.sg:    bsr  put_c
        ldd  rv_sc
        subd #E_MB+1
        blt  .cp
        ldd  #E_MATE+1          ; mate in (30000 - score + 1) / 2 moves
        subd rv_sc
        lsrd
        pshb
        psha
        ldaa #'M'
        bsr  put_c
        pula
        pulb
        jsr  put_n
        bra  .x
.cp:    ldd  rv_sc              ; pawns and hundredths
        ldx  #100
        jsr  udiv               ; D = pawns, kv_m3 = hundredths
        jsr  put_n
        ldaa #'.'
        jsr  put_c
        ldaa kv_m3+1
        clrb
.t:     cmpa #10
        bcs  .o
        suba #10
        incb
        bra  .t
.o:     psha
        tba
        adda #'0'
        jsr  put_c
        pula
        adda #'0'
        jsr  put_c
.x:     ldx  #rv_t
        jmp  msg_set

; A = square: "E2"
put_sq: psha
        anda #7
        adda #'A'
        jsr  put_c
        pula
        anda #$70
        lsra
        lsra
        lsra
        lsra
        adda #'1'
        jmp  put_c

; overlay-local variables (gone when the slot is reused)
rv_s:   rmb  1                  ; a snapshot's number
rv_p:   rmb  2                  ; a pointer into it
rv_n:   rmb  1                  ; a square number
rv_b:   rmb  1                  ; a snapshot byte
rv_sc:  rmb  2                  ; the score
rv_t:   rmb  21                 ; the message being built (length-prefixed)
