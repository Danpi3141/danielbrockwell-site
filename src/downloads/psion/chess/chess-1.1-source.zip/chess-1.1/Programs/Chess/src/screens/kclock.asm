; ---------------------------------------------------------------------
; Clocks. st_timing: 0 none, 1 5|5, 2 10|5, 3 15|10, 4 30|30, 5 custom
; (st_cmin/st_cinc: [0] the player, [1] the computer). Times are kept in
; frames (50 ms): g_clk = White, Black (words, at most 54 minutes),
; g_inc = their increments.
; ---------------------------------------------------------------------
; the side to move's clock starts now
clk_start:
        ldd  TMW_FRAM
        std  clk_last
        ldaa #1
        staa clk_run
        rts
; ... unless it is running already
clk_start0:
        tst  clk_run
        beq  clk_start
        rts

; X = the clock of the side to move
clk_ptr:
        ldx  #g_clk
        tst  e_side
        beq  .x
        inx
        inx
.x:     rts

; charge the time since clk_last to the side to move. C=1 if its flag
; fell (the result is set).
clk_tick:
        tst  st_timing
        beq  .ok
        tst  clk_run
        beq  .ok
        tst  g_result
        bne  .ok
        ldd  TMW_FRAM
        subd clk_last
        std  kv_t0
        ldd  TMW_FRAM
        std  clk_last
        bsr  clk_ptr
        ldd  0,x
        subd kv_t0
        bcs  .flag
        beq  .flag
        std  0,x
        ; a tick every ten seconds under a minute (the player's clock)
        ldaa e_side
        cmpa g_human
        bne  .ok
        subd #1200
        bcc  .ok
        ldd  0,x
        ldx  #200
        jsr  udiv
        cmpb clk_tk
        beq  .ok
        stab clk_tk
        ldx  #snd_tick
        jsr  snd_play
.ok:    clc
        rts
.flag:  clr  0,x
        clr  1,x
        clr  clk_run
        ldab #R_WHITE           ; the other side wins ...
        ldx  #e_cnt             ; (its piece counts)
        tst  e_side
        bne  .s
        ldab #R_BLACK
        ldx  #e_cnt+8
.s:     ldaa 1,x                ; ... unless it has only its king: it cannot mate, so the game is
        adda 2,x                ; drawn (FIDE 6.9; 17 Nov, it won before). (A king and one minor
        adda 3,x                ; against a bare king ended the game already, too little material;
        adda 4,x                ; against more it can mate by some series of moves: a win.)
        adda 5,x
        bne  .t
        ldab #R_DRAW
        ldaa #Y_MAT
        bra  .r
.t:     ldaa #Y_TIME
.r:     stab g_result
        staa g_reason
        jsr  auto_adj           ; (Auto: a win or a loss; 17 Nov, it was missed)
        sec                     ; (the kernel saves)
        rts

; before the move is made: the mover (the side to move) is charged and
; gets its increment; the clocks stop
clk_moved:
        tst  st_timing
        beq  .x
        jsr  clk_tick
        bsr  clk_ptr
        ldd  0,x
        addd 4,x
        bcc  .s
        ldd  #$FFFF
.s:     std  0,x
.x:     clr  clk_run
        rts

; D = the frames this move may take by the clock (0 = no clock): the time
; left over the moves expected (40 less those played, at least 10), plus
; the increment
clk_share:
        tst  st_timing
        bne  .c
        ldd  #0
        rts
.c:     ldab g_n
        lsrb
        negb
        addb #40
        bmi  .ten
        cmpb #10
        bhs  .d
.ten:   ldab #10
.d:     clra
        xgdx
        stx  kv_t0
        jsr  clk_ptr
        ldd  0,x
        pshx
        ldx  kv_t0
        jsr  udiv
        pulx
        addd 4,x
        rts

; the side to move's clock as 3 characters into st_p+12: "12'" or "45""
clk_text:
        jsr  clk_ptr
        ldd  0,x
        ldx  #20
        jsr  udiv               ; D = seconds
        std  kv_t0
        subd #60
        bcs  .sec
        ldd  kv_t0              ; minutes, rounded up (4:58 shows 5')
        addd #59
        ldx  #60
        jsr  udiv
        subd #100
        bcs  .m
        ldd  #99
        bra  .m2
.m:     addd #100
.m2:    jsr  num_str
        ldaa #$27               ; '
        bra  .put
.sec:   ldd  kv_t0
        jsr  num_str
        ldaa #$22               ; "
.put:   ldab kv_nbuf
        incb
        stab kv_nbuf
        ldx  #kv_nbuf
        abx
        staa 0,x
        ldx  #st_p+12
        ldab kv_nbuf
        stab 0,x
        ldaa kv_nbuf+1
        staa 1,x
        ldaa kv_nbuf+2
        staa 2,x
        ldaa kv_nbuf+3
        staa 3,x
        rts

; pace_wait: the computer plays to the clock. A = 0 a book or forced
; move (2 to 4 s), 1 after thinking (half to one and a half of its share).
; Only with a clock and the natural pace; a key ends the wait.
pace_wait:
        tst  st_timing
        beq  .x
        tst  st_pace
        bne  .x
        ldaa pw_a
        bne  .share
        ldaa #40
        jsr  rnd
        clra
        addd #40
        bra  .t
.share: ldaa #100               ; share * (50..149) / 100
        jsr  rnd
        clra
        addd #50
        ldx  cm_share
        jsr  mul16x
        ldx  #100
        jsr  udiv
.t:     std  pw_t
.w:     ldd  TMW_FRAM
        subd cm_t0
        subd pw_t
        bcc  .x
        os   KB$TEST
        tstb
        bne  .x
        jsr  clk_tick
        bcs  .x
        jsr  set_turn
        jsr  bshow
        ldaa TMW_FRAM+1
        adda #10
        staa pw_f
.s:     ldaa TMW_FRAM+1
        cmpa pw_f
        beq  .w
        os   KB$TEST
        tstb
        bne  .x
        slp
        bra  .s
.x:     rts

; D = D * X / 1 with a 24-bit product kept as its low 16 bits, but
; saturating: D * X where D < 256
mul16x: stx  kv_m2
        stab kv_m1              ; B * X (B < 256)
        ldaa kv_m2+1
        mul
        std  kv_m3
        ldaa kv_m1
        ldab kv_m2
        mul
        tsta
        bne  .sat
        addb kv_m3
        bcs  .sat
        stab kv_m3
        ldd  kv_m3
        rts
.sat:   ldd  #$FFFF
        rts
