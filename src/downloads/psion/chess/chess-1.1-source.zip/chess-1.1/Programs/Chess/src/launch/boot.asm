; =====================================================================
; Chess bootstrap: poked into the top of the game's array by the launcher CHGn,
; run with  i% = USR(a%, ADDR(v%()))
; It finds the kernel block CHK on B:, C: or A: with the OS's FL$BOPN (until
; 17 Nov it read the packs' directories itself: 145 of its 253 bytes), reads
; the kernel into the game's array m%(), adds the array's address to every
; word in the kernel's fix-up list and jumps to the kernel with D = ADDR(v%()).
;
; v%() layout (bytes): 0 array address  2 array size  4 device (the kernel
; reads these); then the bootstrap's own: 10 kernel length, 13 encoded fix-up
; length.
; Position independent: only relative branches and zero-page scratch; the OS
; uses the zero-page scratch too, so across OS calls everything is on the stack.
; It contains no byte 0, 9, 10 or 13 (an OPL string cannot hold them, and the
; build refuses them): X points one byte below v%() so no field is at offset
; 0, 9, 10 or 13, and constants are added as subtractions.
; Returns X = 1 (E_NOPACK) if no device holds CHK.
; =====================================================================
        include "../defs.inc"

; offsets from X = v%()-1
V_BASE  = 1
V_DEV   = 5
V_KLEN  = 11
V_FIXN  = 14

boot:   addd #$FFFF             ; (dex is byte 9)
        xgdx                    ; X = v%()-1
        pshx
        bsr  .find              ; (pushes the name's address)
.name:  fcb  5
        fcc  "B:CHK"
.find:  ldaa #'B'               ; B:, then C:, then A:
.dev:   pulx                    ; X = the name
        pshx
        staa 1,x                ; its device letter
        psha
        ldab #$83               ; a procedure (a block file of type $83)
        os   FL$BOPN            ; found: the pack address is at its data
        pula
        bcc  .found
        suba #'B'               ; B: -> C: -> A: -> give up
        bne  .nc
        ldaa #'C'
        bra  .dev
.nc:    deca
        bne  .no
        ldaa #'A'
        bra  .dev
.no:    pulx
        pulx
        ldab #1                 ; X = 1: not found
        clra
        xgdx
        rts

; CHK's data: the object length (2) and the RETURN stub (16), then the kernel's
; length and the kernel
.found: pulx                    ; (the name)
        pulx                    ; X = v%()-1
        suba #'A'               ; the device: A: 0, B: 1, C: 2
        staa V_DEV,x
        pshx
        clra
        ldab #18
        os   PK$SKIP
        os   PK$RWRD            ; D = kernel length
        pulx
        std  V_KLEN,x
        pshx
        ldx  V_BASE,x
        os   PK$READ            ; the kernel into m%()
        os   PK$RWRD            ; D = fix-up count (unused)
        os   PK$RWRD            ; D = encoded length
        pulx
        std  V_FIXN,x
        pshx
        pshb
        psha
        ldd  V_KLEN,x
        addd V_BASE,x
        xgdx                    ; X = just after the kernel
        pula
        pulb
        os   PK$READ            ; the encoded list after it
        pulx
        stx  T6                 ; v%()-1
        ldd  V_BASE,x
        std  T0                 ; the array
        addd #$FFFF
        std  T8                 ; the last word fixed, less one: the array - 1
        addd V_KLEN,x
        std  T2                 ; one before the next encoded byte
        addd V_FIXN,x
        std  T4                 ; one before the end
.fx:    ldx  T2
        cpx  T4
        beq  .go
        ldab 1,x                ; a gap: one byte, or 255 then two
        inx
        clra
        cmpb #255
        bne  .rel
        ldd  1,x
        inx
        inx
.rel:   addd T8
        std  T8
        stx  T2
        xgdx                    ; X = the word to fix, less one
        ldd  1,x
        addd T0
        std  1,x
        bra  .fx
.go:    ldx  T0                 ; the kernel's entry is its first byte
        pshx
        ldx  T6
        inx
        xgdx                    ; D = v%()
        rts
