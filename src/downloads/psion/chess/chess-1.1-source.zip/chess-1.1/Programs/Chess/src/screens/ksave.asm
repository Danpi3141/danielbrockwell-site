; ---------------------------------------------------------------------
; The save file A:CHESSAV holds the settings and the whole game, and is
; the only copy of the game record (RAM keeps just the last move). It has
; a fixed size from the start, so it never takes more of the RAM the game
; shares with A:: 25 chunk records (tag 0..24, 10 plies of 3 bytes each,
; then each ply's mover's clock after the move: 2 bytes, for take back)
; and a header record (tag 'H': gs_first..gs_end with a checksum).
; A record is replaced by erasing it and writing it again at the end;
; records are found by their tag. The game never waits for a key while
; saving, so switching off cannot cut a save short.
; Once made, a record is only ever replaced by one of the same size, so a
; save can only fail when the file is made (A: full). Then (or on any failed
; write) the file is deleted, g_nosv is set (no saving, no take back) and
; the message line says so: the game goes on, but is not kept.
; ---------------------------------------------------------------------

; the header: settings and game (not the record) -> A:CHESSAV
sv_save:
        tst  g_nosv
        bne  sv_x
        jsr  sv_open
        bcc  .o
        jmp  sv_new             ; no file yet: make it
.o:     ldaa #'H'
        jsr  sv_find
        bcs  .w
        os   FL$ERAS
.w:     ldaa #SV_VER
        staa gs_ver
        ldd  #HDR_LEN
        std  gs_len
        jsr  sv_sum
        std  gs_sum
        ldaa #HDR_LEN+1
        staa sv_buf
        ldaa #'H'
        staa sv_buf+1
        ldx  #gs_first
        stx  kv_t0
        ldx  #sv_buf+2
        stx  kv_t1
        ldab #HDR_LEN
        jsr  sv_copy
        ldx  #sv_buf
        os   FL$WRIT
        bcs  sv_fail
sv_x:   rts

; a write failed: no file at all rather than half of one
sv_fail:
        ldaa #1
        staa g_nosv
        clr  kv_pkok
        ldx  #fn_main
        os   FL$DELN
        jsr  msg_pri
        fcl  "CANNOT SAVE: NO ROOM"
        rts

; a new file: 25 empty chunks, then the header
sv_new: clr  kv_pkok
        clr  g_nosv
        ldx  #fn_main
        os   FL$DELN
        ldx  #fn_main
        os   FL$CRET
        bcs  sv_fail
        staa sv_rt
        tab
        os   FL$RECT
        ldx  #sv_buf+2
        ldab #5*CPLY
.z:     clr  0,x
        inx
        decb
        bne  .z
        ldaa #5*CPLY+1
        staa sv_buf
        clr  sv_buf+1
.c:     ldx  #sv_buf
        os   FL$WRIT
        bcs  sv_fail
        inc  sv_buf+1
        ldaa sv_buf+1
        cmpa #NCHUNK
        bne  .c
        jmp  sv_save.o

; sp_i = ply, sp_e = its 3 bytes: into the file's chunk, then the header
sv_ply: tst  g_nosv
        bne  .x
        tst  im_on              ; importing: into the chunk kept in the TT's RAM
        beq  .one
        jmp  sv_bulk
.one:   jsr  sv_open
        bcs  .x
        bsr  sv_ckfind          ; A = chunk, B = offset, sv_p = the clock's place
        bcs  .x
        os   FL$ERAS
        ldx  #sv_buf+2
        ldab sv_off
        abx
        ldd  sp_e
        std  0,x
        ldaa sp_e+2
        staa 2,x
        ldx  #g_clk             ; the mover's clock (the side not to move now)
        tst  e_side
        bne  .w
        inx
        inx
.w:     ldd  0,x
        ldx  sv_p
        std  0,x
        ldx  #sv_buf
        os   FL$WRIT
        bcs  sv_fail
        jmp  sv_save.o
.x:     rts

; ---------------------------------------------------------------------
; Importing (im_on): each ply goes into a copy of its chunk record kept at
; e_tt (the TT isn't used while importing; im_game clears it after), and a
; chunk is written when the next one starts and at the end (sv_flush), not
; the header: ten times fewer erases and writes. e_tt+0 = the chunk there
; ($FF none), e_tt+1.. = the record as sv_buf holds it.
; ---------------------------------------------------------------------
sv_bulk:
        jsr  sp_chunk           ; A = chunk, B = 3 * k, sv_off = 2 * k
        pshb
        ldab sv_off
        stab sv_k
        pulb
        stab sv_off
        ldx  e_tt
        cmpa 0,x
        beq  .in
        psha                    ; another chunk: write the one there, read this one
        bsr  sv_flush
        pula
        psha
        jsr  sv_open
        pula
        bcs  .x
        psha
        jsr  sv_find
        pula
        bcs  .x
        ldx  e_tt
        staa 0,x
        ldd  #sv_buf
        std  kv_t0
        ldd  e_tt
        addd #1
        std  kv_t1
        ldab #5*CPLY+2
        jsr  sv_copy
.in:    ldx  e_tt               ; the ply's 3 bytes
        inx
        ldab sv_off
        abx
        ldd  sp_e
        std  2,x
        ldaa sp_e+2
        staa 4,x
        ldx  #g_clk             ; the mover's clock (the side not to move now)
        tst  e_side
        bne  .w
        inx
        inx
.w:     ldd  0,x
        ldx  e_tt
        inx
        pshb
        ldab sv_k
        abx
        pulb
        std  2+3*CPLY,x
.x:     rts

; the chunk kept at e_tt, if any, into the file (G_FLUSH, at the end of an import)
sv_flush:
        ldx  e_tt
        ldaa 0,x
        cmpa #$FF
        beq  .x
        jsr  sv_open
        bcs  .x
        ldx  e_tt
        ldaa 0,x
        jsr  sv_find
        bcs  .x
        os   FL$ERAS
        ldd  e_tt
        addd #1
        std  kv_t0
        ldd  #sv_buf
        std  kv_t1
        ldab #5*CPLY+2
        jsr  sv_copy
        ldx  #sv_buf
        os   FL$WRIT
        bcc  .ok
        jmp  sv_fail
.ok:    ldx  e_tt
        ldaa #$FF
        staa 0,x
.x:     rts

; sp_i = ply (the file open): its chunk into sv_buf; sv_off = its moves'
; offset, sv_p = the address of its clock. C=1 if the file can't give it.
sv_ckfind:
        jsr  sp_chunk           ; A = chunk, B = 3 * k, sv_off = 2 * k
        pshb
        ldab sv_off
        stab sv_k
        pulb
        stab sv_off
        jsr  sv_find
        ldx  #sv_buf+2+3*CPLY
        ldab sv_k
        abx
        stx  sv_p
        rts

; after a take back: each side's clock as it was after its last move
; (G_CLKNEW has set the starting times, for a side with no move yet);
; then the side to move's clock starts (as clk_start)
clk_back:
        ldd  TMW_FRAM
        std  clk_last
        ldaa #1
        staa clk_run
        tst  st_timing
        beq  .x
        ldaa g_n
        suba #1
        bcs  .x
        ldx  #g_clk             ; the last ply: by the side not to move
        tst  e_side
        bne  .a
        inx
        inx
.a:     bsr  .one
        ldaa g_n
        suba #2
        bcs  .x
        ldx  #g_clk             ; the one before: by the side to move
        tst  e_side
        beq  .one
        inx
        inx
; A = ply, X = the clock to set from the file
.one:   staa sp_i
        pshx
        jsr  sv_open
        bcs  .r
        bsr  sv_ckfind
        bcs  .r
        ldx  sv_p
        ldd  0,x
        tsx
        ldx  0,x
        std  0,x
.r:     pulx
.x:     rts

; C=0: the saved settings and game are loaded
sv_load:
        jsr  sv_open
        bcs  .no
        ldaa #'H'
        jsr  sv_find
        bcs  .no
        ldaa sv_buf
        cmpa #HDR_LEN+1
        bne  .bad
        ldx  #sv_buf+2
        stx  kv_t0
        ldx  #gs_first
        stx  kv_t1
        ldab #HDR_LEN
        jsr  sv_copy
        ldaa gs_ver
        cmpa #SV_VER
        bne  .bad
        ldaa g_n
        cmpa #MAXPLY
        bhi  .bad
        jsr  sv_sum
        subd gs_sum
        bne  .bad
        clc
        rts
.bad:   jsr  set_defaults       ; damaged: start again
.no:    sec
        rts

; D = the sum of the header's bytes, gs_sum itself counted as 0
sv_sum: ldd  gs_sum
        pshb
        psha
        clr  gs_sum
        clr  gs_sum+1
        ldx  #gs_first
        clr  kv_t0
        clr  kv_t0+1
        ldaa #HDR_LEN
        staa kv_t1
.l:     ldab 0,x
        clra
        addd kv_t0
        std  kv_t0
        inx
        dec  kv_t1
        bne  .l
        pula
        pulb
        std  gs_sum
        ldd  kv_t0
        rts

; copy B bytes from kv_t0 to kv_t1
sv_copy:
.c:     ldx  kv_t0
        ldaa 0,x
        inx
        stx  kv_t0
        ldx  kv_t1
        staa 0,x
        inx
        stx  kv_t1
        decb
        bne  .c
        rts

; sp_i = the first ply of a chunk: the chunk into rp_buf, and its plies
; (up to g_n) followed in the book. C=1 if the file can't give it.
rd_chunk:
        jsr  sv_open
        bcs  .x
        jsr  sp_chunk
        jsr  sv_find
        bcs  .x
        ldx  #sv_buf+2
        stx  kv_t0
        ldx  #rp_buf
        stx  kv_t1
        ldab #3*CPLY
.c:     ldx  kv_t0
        ldaa 0,x
        inx
        stx  kv_t0
        ldx  kv_t1
        staa 0,x
        inx
        stx  kv_t1
        decb
        bne  .c
        clr  ch_k
.f:     ldaa ch_k
        cmpa #CPLY
        beq  .ok
        adda sp_i
        cmpa g_n
        bhs  .ok
        ldab ch_k
        ldaa #3
        mul
        addd #rp_buf
        xgdx
        ldaa 0,x
        ldab 1,x
        jsr  bk_follow
        inc  ch_k
        bra  .f
.ok:    clc
.x:     rts
