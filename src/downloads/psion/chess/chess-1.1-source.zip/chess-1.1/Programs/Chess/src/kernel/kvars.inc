; ---------------------------------------------------------------------
; Kernel variables and tables (inside the kernel image).
; ovtab is filled in by the build once the overlays are placed.
; ---------------------------------------------------------------------
KEY_DELAY = 8                   ; repeat after 0.4 s
KEY_RATE  = 1                   ; then every 50 ms

; tables the build fills in (part of the image on the pack)
ovtab:    rmb 3*MAX_OVERLAYS    ; per overlay 1..: block, offset (2)

; variables: not on the pack, cleared at start
kv_first:
kv_sp:    rmb 2                 ; the launcher's stack pointer
kv_vars:  rmb 2                 ; ADDR(v%())
kv_base:  rmb 2                 ; ADDR(m%()), the array everything lives in
kv_size:  rmb 2                 ; its size in bytes
kv_dev:   rmb 1                 ; device the game's blocks are on (0 A:, 1 B:, 2 C:)
kv_ksav:  rmb 5                 ; KBB_DLAY, KBB_REPT, KBB_CLIK, KBB_PKOF, KBB_STAT on entry
kv_res:   rmb 1                 ; overlay resident in slot A (0 = none)
kv_rx:    rmb 2
kv_rtgt:  rmb 2
kv_dir:   rmb N_BLOCKS*3        ; pack address of each block CHB0.., $FF.. if missing
kv_pkok:  rmb 1                 ; the game's device is selected and on (see pk_seek)
kv_left:  rmb 1                 ; key_wait: frames still to wait
kv_afr:   rmb 1
kv_aidle: rmb 2
kv_pa:    rmb 3                 ; pack address being read
kv_rblk:  rmb 1                 ; pk_read: block
kv_roff:  rmb 2                 ;          offset in the block
kv_rlen:  rmb 2                 ;          bytes
kv_rdst:  rmb 2                 ;          destination
kv_t0:    rmb 2                 ; kernel scratch, never kept across a call
kv_t1:    rmb 2
kv_t2:    rmb 2
kv_t3:    rmb 2
kv_m1:    rmb 2                 ; mul16 / udiv
kv_m2:    rmb 2
kv_m3:    rmb 2
kv_rnd:   rmb 2
kv_cur:   rmb 1                 ; text cursor, 0..79
kv_gdirty: rmb 1                ; glyphs to send, bit n = glyph n
kv_cells: rmb 80                ; the screen as it should look, row major
kv_nbuf:  rmb 8                 ; number formatting
kv_fix:   rmb 16                ; fix-ups being applied (16 encoded bytes at a time); (17 Nov: kept
kv_fo:    rmb 2                 ; here: in slot A's last 18 bytes take-backs in a clock game went wrong)

; the board screen (what must last between overlay calls)
v_flip:   rmb 1                 ; 1: the board is turned (Black at the bottom)
v_half:   rmb 1                 ; letter view: 0 the near half, 1 the far half
cur_sq:   rmb 1                 ; the cursor's square, $FF none
msg_on:   rmb 1                 ; row 3 shows msg_t
msg_t:    rmb 20
st_p:     rmb 16                ; the strip: three parts and the turn, 4 bytes each
st_p3:    rmb 4                 ; the last move's third part
sc_col:   rmb 1                 ; strip_cells, msg_set
sc_r:     rmb 1
sc_p:     rmb 2
sc_q:     rmb 2
lm_n:     rmb 1                 ; the legal moves (a copy of e_lm, at most LM_MAX)
lm_buf:   rmb 2*LM_MAX

; the game (not saved)
g_stat:   rmb 1                 ; eng_status after the last move
g_chk:    rmb 1                 ; the side to move is in check
g_ckr:    rmb 1                 ; the piece giving it
g_nosv:   rmb 1                 ; 1: A:CHESSAV could not be made: no record, so no take back
hu_f:     rmb 1                 ; the player's move
hu_t:     rmb 1
im_g:     rmb 1                 ; importing: A:GAMEn, the next move's record and offset,
im_rn:    rmb 2                 ; and its promotion bits (OV_IMPORT)
im_off:   rmb 1
im_pro:   rmb 1
im_on:    rmb 1                 ; 1 while importing (the record is saved a chunk at a time)
rv_on:    rmb 1                 ; game review's replay: RVF_* flags (OV_REVIEW)
        if   SPEEDTEST
sp_t0:    rmb 2                 ; the speed test (TEMPORARY): start, then frames for each part
sp_eng:   rmb 2
sp_nodes: rmb 2
sp_ov:    rmb 2
sp_bk:    rmb 2
        endif
rp_i:     rmb 1
rp_p:     rmb 2
rp_buf:   rmb 3*CPLY            ; replay: a chunk of the record
rp_e:     rmb 1
sp_i:     rmb 1                 ; a ply to read or write in the save file
sp_e:     rmb 3
pm_f:     rmb 1
pm_t:     rmb 1
pm_i:     rmb 1
cm_f:     rmb 1
cm_t:     rmb 1
cm_share: rmb 2
cm_t0:    rmb 2
th_t0:    rmb 2
th_d:     rmb 1
pw_a:     rmb 1
clk_last: rmb 2
clk_run:  rmb 1
bk_in:    rmb 1                 ; the book is on (not after a set-up)

; ---- saved (the header record of A:CHESSAV): the settings and the game ----
gs_first:
gs_ver:   rmb 1
gs_len:   rmb 2
gs_sum:   rmb 2
st_first:
st_layout: rmb 1                ; 0 letters beside the map, 1 split board
st_notat: rmb 1                 ; 0 standard notation, 1 plain squares
st_level: rmb 1                 ; 1..8
st_auto:  rmb 1                 ; 1: Auto (the level moves with the results)
st_timing: rmb 1                ; 0 none, 1 5|5, 2 10|5, 3 15|10, 4 30|30, 5 custom
st_cmin:  rmb 2                 ; custom minutes: the player, the computer
st_cinc:  rmb 2                 ; custom increments (seconds)
st_pace:  rmb 1                 ; 0 natural, 1 fast
st_colour: rmb 1                ; 0 White, 1 Black, 2 alternate
st_sound: rmb 1                 ; 0 all, 1 blips only, 2 off
st_blund: rmb 1                 ; blunder check (not used yet)
st_ponder: rmb 1                ; think on your time (not used yet)
st_resign: rmb 1                ; the computer may resign
st_last:
g_human:  rmb 1                 ; the player's colour: 0 White, 8 Black
g_mode:   rmb 1                 ; 0 against the computer, 1 two players
g_setup:  rmb 1                 ; 1: the game started from g_spos
g_result: rmb 1
g_reason: rmb 1
g_bad:    rmb 1                 ; the computer's moves in a row at worse than -9
g_clk:    rmb 4                 ; White, Black (frames)
g_inc:    rmb 4                 ; their increments
g_spos:   rmb 68                ; a set-up position: a1..h8, side, castle, ep, half
g_n:      rmb 1                 ; plies played
g_last:   rmb 3                 ; the last ply: from, to, info (the record is in A:CHESSAV)
gs_end:

; ---- the engine's variables ----
        include "evarsel.inc"
