; ---------------------------------------------------------------------
; Opening book (block BK_BLOCK on the pack; tools/book/build_pbook.py has
; the format): the positions where the Psion is to move, found by the
; position's 24-bit key (e_key). 257 big-endian words first: the offset of
; each of 256 buckets (by the key's low byte) and of the end. A bucket
; holds its positions one after another: the key's high 16 bits, then the
; moves, one byte each: the move's index in lm_buf (the legal moves, in
; eng_legal's order), bit 7 set when another follows. Nothing is kept
; between moves: after any reply the new position is looked up, so a
; transposition finds its moves too.
; ---------------------------------------------------------------------

; at the start of a game: the book is on if the pack has one (not after a
; set-up: the book is for games from the standard start)
bk_reset:
        clr  bk_in
        tst  g_setup
        bne  .x
        ldab #BK_BLOCK*3
        ldx  #kv_dir
        abx
        ldaa 0,x
        cmpa #$FF
        beq  .x
        ldaa #1
        staa bk_in
.x:     rts

; (a move was played: nothing to follow, the next position is looked up)
bk_follow:
        rts

; C=0: A = from, B = to, one of the position's book moves (at random).
; Levels 1-4 use the book for the computer's first n moves only (n = the
; level); levels 5-8 use it all.
bk_pick:
        tst  bk_in
        beq  .no
        jsr  level_now          ; A = the level in force
        cmpa #4
        bhi  .all
        ldab g_n                ; the computer's move number: plies / 2 + 1
        lsrb
        incb
        cba
        bcs  .no                ; past the level's number of book moves
.all:   ldaa #BK_BLOCK          ; the bucket's start and end
        staa kv_rblk
        ldab e_key+2
        clra
        asld
        std  kv_roff
        ldd  #4
        std  kv_rlen
        ldd  #bk_list
        std  kv_rdst
        jsr  pk_read
        ldd  bk_list+2
        subd bk_list
        std  bk_len             ; its bytes
        beq  .no
        ldd  bk_list            ; the reader there (kv_rlen 0: just placed)
        std  kv_roff
        clr  kv_rlen
        clr  kv_rlen+1
        jsr  pk_read
.pos:   ldd  bk_len             ; the next position in the bucket
        subd #3
        bcs  .no                ; (at least a key and a move are left)
        bsr  bk_byte
        stab bk_key
        bsr  bk_byte
        stab bk_key+1
        clr  bk_cnt
.mv:    bsr  bk_byte            ; its moves into bk_list (up to 16)
        stab bk_t1
        ldaa bk_cnt
        cmpa #16
        bhs  .m2
        ldx  #bk_list
        tab
        abx
        ldaa bk_t1
        anda #$7F
        staa 0,x
        inc  bk_cnt
.m2:    tst  bk_t1
        bmi  .mv
        ldd  bk_key             ; this position?
        subd e_key
        bne  .pos
        ldaa bk_cnt             ; yes: one of its moves
        jsr  rnd                ; B = 0..cnt-1
        ldx  #bk_list
        abx
        ldab 0,x                ; its index in the legal list
        cmpb lm_n
        bhs  .no                ; (not a move here: a key clash)
        aslb
        ldx  #lm_buf
        abx
        ldaa 0,x
        ldab 1,x
        clc
        rts
.no:    sec
        rts

; B = the next byte of the bucket (bk_len counts down); X kept
bk_byte:
        pshx
        os   PK$RBYT
        pulx
        pshb
        ldd  bk_len
        subd #1
        std  bk_len
        pulb
        rts
