"""Makes the folder for loading Chess onto a real Organiser with RPBOOT/RPLOAD (Tools/README.md).

    python tools/psion.py [--build build/game] [--out psion]

Takes the built pack image apart (Tools/opk2files.py): the kernel CHK and the data blocks CHB0..
go in as they are, translated procedures with no source. The launchers CHESS and CHG1..CHG3 are
translated again without their source (Tools/opltran.py --no-source), which saves about 1K.
Then Tools/mkrpdata.py writes the file list and the loader. Last, the folder's .OB3 files are put
back into a pack image (Tools/opl2opk.py) and compared with the build's, so what RPLOAD sends is
known to be what the emulator tests ran.
"""
import argparse
import glob
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOOLS = os.path.join(ROOT, '..', '..', 'Tools')


def run(*args):
    r = subprocess.run([sys.executable] + list(args), capture_output=True, text=True)
    if r.returncode:
        sys.exit('failed: %s\n%s%s' % (' '.join(args), r.stdout, r.stderr))
    return r.stdout


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--build', default=os.path.join(ROOT, 'build', 'game'))
    ap.add_argument('--out', default=os.path.join(ROOT, 'psion'))
    a = ap.parse_args()
    opk = glob.glob(os.path.join(a.build, '*.opk'))[0]
    os.makedirs(a.out, exist_ok=True)
    for f in os.listdir(a.out):
        if f.upper().endswith(('.OB3', '.ODB', '.OPL')):
            os.remove(os.path.join(a.out, f))
    with tempfile.TemporaryDirectory() as tmp:
        run(os.path.join(TOOLS, 'opk2files.py'), opk, '-o', tmp)
        for f in sorted(os.listdir(tmp)):
            if f.upper().startswith('CH') and not f.upper().startswith(('CHESS', 'CHG')) and f.lower().endswith('.ob3'):
                shutil.copy(os.path.join(tmp, f), os.path.join(a.out, f.upper()))
        for name in ('CHESS', 'CHG1', 'CHG2', 'CHG3'):
            src = os.path.join(tmp, name + '.opl')
            shutil.copy(os.path.join(a.build, name + '.opl'), src)
            run(os.path.join(TOOLS, 'opltran.py'), '--no-source', '-o', tmp, src)
            shutil.copy(os.path.join(tmp, name + '.ob3'), os.path.join(a.out, name + '.OB3'))
    print(run(os.path.join(TOOLS, 'mkrpdata.py'), a.out, '--title', 'CHESS', '--run', 'CHESS'), end='')
    # the folder's procedures, packed again, must hold the same blocks as the tested image
    with tempfile.TemporaryDirectory() as tmp:
        files = sorted(glob.glob(os.path.join(a.out, 'CH[BK]*.OB3')))
        back = os.path.join(tmp, 'BACK.opk')
        run(os.path.join(TOOLS, 'opl2opk.py'), back, *files)
        d1, d2 = os.path.join(tmp, 'a'), os.path.join(tmp, 'b')
        run(os.path.join(TOOLS, 'opk2files.py'), back, '-o', d1)
        run(os.path.join(TOOLS, 'opk2files.py'), opk, '-o', d2)
        for f in os.listdir(d1):
            if open(os.path.join(d1, f), 'rb').read() != open(os.path.join(d2, f), 'rb').read():
                sys.exit('%s differs from the tested pack image' % f)
    total = 0
    for f in sorted(os.listdir(a.out)):
        n = os.path.getsize(os.path.join(a.out, f))
        total += n
        print('  %-12s %6d' % (f, n))
    print('  %-12s %6d bytes in %s' % ('total', total, a.out))


if __name__ == '__main__':
    main()
