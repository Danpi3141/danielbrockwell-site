; ---------------------------------------------------------------------
; The hint's text (OV_GAME)
; ---------------------------------------------------------------------

; after the engine's 2-second look: "HINT E2E4" on the message line (the kernel then shows
; the board). OV_GAME entry 14, G_HINT; the board overlay's B_HINT until 17 Nov.
hint_show:
        ldaa e_bestf
        oraa e_bestt
        beq  .x
        jsr  msg_pri
        fcl  "HINT"
        ldaa e_bestf
        ldab e_bestt
        ldx  #msg_t+5
        jsr  sq_text
.x:     rts

; A = from, B = to: "E2E4" at X (4 characters)
sq_text:
        pshb
        bsr  .sq
        pulb
        tba
.sq:    tab
        andb #7
        addb #'A'
        stab 0,x
        anda #$70
        lsra
        lsra
        lsra
        lsra
        adda #'1'
        staa 1,x
        inx
        inx
        rts
