; =====================================================================
; Engine: search (ref/search.js search, qsearch, think). The node at
; ply p keeps its locals in frame p (e_fp); a child's arguments are
; written into its frame (F_DEP, F_AL, F_BE, F_NUL) before the call.
; Scores come back in D.
; =====================================================================
E_INF   = 32000
E_MATE  = 30000
E_MB    = 29000                 ; |score| above this is a mate score
TT_EXACT = 1
TT_LOWER = 2
TT_UPPER = 3

; D = -D
neg_d   macro
        coma
        comb
        addd #1
        endm

; ---------------------------------------------------------------------
; e_node: count a node; C=1 if the search must stop (node limit, time,
; a key via think_poll).
; ---------------------------------------------------------------------
e_node: inc  e_nodes+2
        bne  .n1
        inc  e_nodes+1
        bne  .n1
        inc  e_nodes
.n1:    tst  e_depth              ; no limit until depth 1 has finished
        beq  .time
        ldaa e_nlim
        oraa e_nlim+1
        oraa e_nlim+2
        beq  .time
        ldaa e_nodes+2
        suba e_nlim+2
        ldaa e_nodes+1
        sbca e_nlim+1
        ldaa e_nodes
        sbca e_nlim
        bcc  .nlim
.time:  dec  e_tick
        bne  .ok
        ldaa #32                ; poll and read the clock every 32 nodes (~4 times a second)
        staa e_tick
        ldaa e_depth
        jsr  think_poll
        bcc  .tl
        tst  e_depth            ; a key stops the search, once depth 1 is done
        bne  .stop
        bra  .ok
.tl:    tst  e_depth
        beq  .ok
        ldd  e_tlim
        beq  .ok
        ldd  TMW_FRAM
        subd e_tstart
        subd e_tlim
        bcc  .tlim
.ok:    clc
        rts
; past a limit: a failing-low iteration runs on, to twice the node limit or e_tlim + e_tadd
.nlim:
        if   E_FAILLOW
        tst  e_flon
        beq  .stop
        ldaa e_nodes+2
        suba e_fln+2
        ldaa e_nodes+1
        sbca e_fln+1
        ldaa e_nodes
        sbca e_fln
        bcs  .time
        endif
        bra  .stop
.tlim:
        if   E_FAILLOW
        tst  e_flon
        beq  .stop
        ldd  TMW_FRAM
        subd e_tstart
        subd e_tfl
        bcs  .ok
        endif
.stop:  ldaa #1
        staa e_stop
        sec
        rts

; C=1 if the position repeats one since the last irreversible move, or 50 moves have passed
e_rep:  ldaa e_half
        cmpa #100
        bcc  .yes
        ldab e_kn
        subb #2
        bcs  .no
        ldaa e_kn               ; lim = max(0, kn - half)
        suba e_half
        bcc  .l0
        clra
.l0:    staa e_t
.l:     cmpb e_t
        bcs  .no
        stab e_t+1
        aslb
        ldx  #e_khist
        abx
        ldd  0,x
        subd e_key
        beq  .yes
.nx:    ldab e_t+1
        subb #2
        bcc  .l
.no:    clc
        rts
.yes:   sec
        rts

; C=1 if the side to move is in check with no legal move (asked only at
; the fifty-move mark, where a mate on the 100th half-move still counts)
e_mated: jsr e_inchk
        bcc  .no
        ldaa #1
        staa e_inck
        clr  e_caps
        jsr  e_gen
        jsr  e_lists            ; X = the first move, e_pend the end
.l:     cpx  e_pend
        beq  .yes
        ldaa 0,x
        ldab 1,x
        pshx
        jsr  e_make
        bcs  .ill
        jsr  e_unmake           ; a legal move: not mate
        pulx
.no:    clc
        rts
.ill:   jsr  e_unmake
        pulx
        inx
        inx
        inx
        bra  .l
.yes:   sec
        rts

; pick the best-scored move in [X, e_pend) and swap it to X
e_pick: stx  e_t
        stx  e_t+2              ; best so far
        ldab 2,x                ; (its score in B: 17 Nov)
.l:     inx
        inx
        inx
        cpx  e_pend
        beq  .sw
        cmpb 2,x
        bcc  .l
        ldab 2,x
        stx  e_t+2
        bra  .l
.sw:    cmpb #E_QUNS            ; the best is an unscored quiet move: all the quiet moves left
        bne  .sw2               ; are scored now (everything scored higher has gone), and again
        ldx  e_t
        jsr  e_qsc
        ldx  e_t
        bra  e_pick
.sw2:   ldx  e_t+2
        cpx  e_t
        beq  .r
        ldd  0,x                ; save the best move
        std  e_t+6
        ldaa 2,x
        staa e_t+5
        ldx  e_t                ; first -> best's place
        ldd  0,x
        ldx  e_t+2
        std  0,x
        ldx  e_t
        ldaa 2,x
        ldx  e_t+2
        staa 2,x
        ldx  e_t                ; best -> first
        ldd  e_t+6
        std  0,x
        ldaa e_t+5
        staa 2,x
.r:     rts

; the quiet moves from X to e_pend still unscored (E_QUNS): 64 + (pst[to] - pst[from]) / 4 with
; the moving piece's middlegame PST, as g_quiet scored them until 17 Nov. Uses T0..T11.
e_qsc:  stx  T4
.l:     ldx  T4
        cpx  e_pend
        beq  .x
        ldaa 2,x
        cmpa #E_QUNS
        bne  .n
        ldab 0,x                ; the moving piece: its PST row
        ldx  #e_board
        abx
        ldaa 0,x
        staa T6
        anda #7
        deca
        ldab #64
        mul
        addd #t_pmg
        std  T8
        ldx  T4
        ldab 1,x                ; pst[to]
        bsr  .s6
        ldx  T8
        abx
        ldab 0,x
        clra
        tstb
        bpl  .p1
        deca
.p1:    std  T10
        ldx  T4
        ldab 0,x                ; pst[from]
        bsr  .s6
        ldx  T8
        abx
        ldab 0,x
        clra
        tstb
        bpl  .p2
        deca
.p2:    std  T0
        ldd  T10
        subd T0
        asra
        rorb
        asra
        rorb
        addb #64
        ldx  T4
        stab 2,x
.n:     ldx  T4
        inx
        inx
        inx
        stx  T4
        bra  .l
.x:     rts
; B = square -> its s6, turned for Black (the piece in T6)
.s6:    tba
        anda #7
        aba
        lsra
        tab
        ldaa T6
        bita #8
        beq  .w
        eorb #56
.w:     rts

        if   E_ROOTORD
; root ordering (17 Nov): the root move being searched (F_I - 3), now the best, gets 255; the one
; that had 255 gets 254 (ref search(): opts.rootOrder)
e_rord: ldx  e_fp
        ldd  F_END,x
        std  T0
        ldd  F_I,x
        subd #3
        std  T2
        ldx  e_mvtop
.l:     cpx  T0
        beq  .s
        ldaa 2,x
        cmpa #255
        bne  .n
        dec  2,x
.n:     inx
        inx
        inx
        bra  .l
.s:     ldx  T2
        ldaa #255
        staa 2,x
        rts
        endif

        if   E_FAILLOW
; fail-low (17 Nov; ref search(): opts.failLow): a root move has just become the best (e_sc).
; From depth 2: the first move a pawn or more below the last iteration's score (e_score; not a
; mate) sets e_flon, once a search; a later move within the pawn clears it.
E_FLM   = 100
e_flchk: tst e_depth
        beq  .x
        ldd  e_score
        subd #E_FLM
        std  T0                 ; the last iteration's score less a pawn
        ldx  e_fp
        ldaa F_LEG,x
        cmpa #1
        bne  .later
        tst  e_flused
        bne  .x
        tst  e_bare             ; (not with a bare king: 18 Nov, it cost bishop-and-knight mates)
        bne  .x
        ldd  e_score
        subd #E_MB
        bge  .x
        ldd  e_score
        addd #E_MB
        ble  .x
        ldd  e_sc
        subd T0
        bge  .x
        inc  e_flon
        inc  e_flused
.x:     rts
.later: tst  e_flon
        beq  .x
        ldd  e_sc
        subd T0
        blt  .x
        clr  e_flon
        rts
        endif

; X = this ply's move list start, e_pend its end: from e_mvtop[e_ply] and e_wp after e_gen
e_lists: ldab e_ply
        aslb
        ldx  #e_mvtop
        abx
        ldd  e_wp
        std  2,x                ; e_mvtop[ply+1]
        std  e_pend
        ldx  0,x
        rts

; ---------------------------------------------------------------------
; child calls: e_ca/e_cb window, A = depth. The child frame is e_fp
; (the move is made). Result negated in e_sc.
; ---------------------------------------------------------------------
e_child: ldx e_fp
        staa F_DEP,x
        ldd  e_ca
        std  F_AL,x
        ldd  e_cb
        std  F_BE,x
        if   E_NULL
        ldaa #1
        staa F_NUL,x
        endif
        jsr  e_search
        neg_d
        std  e_sc
        rts

; ---------------------------------------------------------------------
; e_search
; ---------------------------------------------------------------------
e_search:
        ldx  e_fp
        if   E_NULL                 ; (a zero window: only the null move asks, since 17 Nov)
        clr  F_PV,x
        ldd  F_BE,x
        subd F_AL,x
        subd #2
        bcs  .np
        inc  F_PV,x
        endif
.np:    tst  e_ply
        beq  .r0
        ldaa e_half             ; the fifty-move mark: a draw, unless this is mate
        cmpa #100
        bcs  .rp
        jsr  e_mated
        bcc  .zero
        clra
        ldab e_ply
        subd #E_MATE
        rts
.rp:    jsr  e_rep
        bcs  .zero
        jsr  e_insuf
        bcs  .zero
.r0:    jsr  e_gchk
        ldx  e_fp
        ldaa #0                 ; (ldaa keeps the carry; clr would not)
        staa F_CHK,x
        bcc  .nc
        inc  F_CHK,x
        if   E_CHKEXT
        ldaa e_ply
        cmpa #E_MAXPLY-4
        bcc  .nc
        inc  F_DEP,x
        endif
.nc:    tst  F_DEP,x
        ble  .qs
        ldaa e_ply
        cmpa #E_MAXPLY-2
        bcs  .go
.qs:    jmp  e_qs
.zero:  ldd  #0
        rts
.go:    jsr  e_node
        bcs  .zero
        ldab e_ply              ; too many moves stacked: a leaf
        aslb
        ldx  #e_mvtop
        abx
        ldd  0,x
        subd #e_mvs+3*E_MVCAP
        bls  .tt
        jmp  e_eval
        ; ---- transposition table
.tt:    ldx  e_fp
        clr  F_TTF,x
        clr  F_TTT,x
        ldd  e_key+1
        anda e_ttmask
        andb e_ttmask+1
        std  F_TTX,x            ; 7-byte entries: index * 8 - index
        asld
        asld
        asld
        subd F_TTX,x
        addd e_tt
        std  F_TTX,x
        xgdx
        ldd  0,x
        subd e_key
        bne  .stat
        tst  6,x                ; depth<<2 | flag: 0 = empty
        beq  .stat
        ldd  2,x
        stx  e_t+6
        ldx  e_fp
        staa F_TTF,x
        stab F_TTT,x
        tst  e_ply              ; a cut-off at any node but the root (17 Nov: was only with a
        beq  .stat              ; zero window, which plain alpha-beta hardly ever has: +3 to +10 Elo),
        tst  e_bare             ; unless a side has a bare king
        bne  .stat
        ldaa F_DEP,x            ; (1-41 here, so 6 bits hold it)
        asla
        asla
        ldx  e_t+6
        cmpa 6,x                ; entry depth >= depth ? (depth<<2 against depth<<2 | flag)
        bhi  .stat
        ldd  4,x                ; score, mate-adjusted to this ply
        bsr  tt_in
        std  e_sc
        ldaa 6,x
        anda #3
        cmpa #TT_EXACT
        bne  .tl
        ldd  e_sc
        rts
.tl:    ldx  e_fp
        cmpa #TT_LOWER
        bne  .tu
        ldd  e_sc
        subd F_BE,x
        blt  .stat
        ldd  F_BE,x
        rts
.tu:    ldd  e_sc
        subd F_AL,x
        bgt  .stat
        ldd  F_AL,x
        rts
        ; ---- static evaluation
.stat:  ldx  e_fp              ; the static score is used only by futility (depth 1)
        ldd  #0                 ; and the null move (depth >= 3, not PV, ply > 0)
        tst  F_CHK,x
        bne  .st1
        ldaa F_DEP,x
        cmpa #1
        if   E_NULL
        beq  .st0
        cmpa #3
        blt  .st2
        tst  F_NUL,x
        beq  .st2
        tst  F_PV,x
        bne  .st2
        tst  e_ply
        beq  .st2
        else
        bne  .st2
        endif
.st0:   jsr  e_eval
        ldx  e_fp
.st1:   std  F_STAT,x
.st2:
        ; ---- null move
        if   E_NULL
        tst  F_NUL,x
        beq  .gen
        tst  F_PV,x
        bne  .gen
        tst  F_CHK,x
        bne  .gen
        ldaa F_DEP,x
        cmpa #3
        blt  .gen
        tst  e_ply
        beq  .gen
        ldd  F_STAT,x
        subd F_BE,x
        blt  .gen
        ldab e_side
        ldx  #e_cnt
        abx
        ldaa 2,x
        adda 3,x
        adda 4,x
        adda 5,x
        beq  .gen
        ldab e_ply              ; the null child's moves go where ours would
        aslb
        ldx  #e_mvtop
        abx
        ldd  0,x
        std  2,x
        jsr  e_mnull
        ldx  e_ofp              ; own frame (the parent of e_fp)
        ldd  F_BE,x             ; child window (-beta, -beta+1)
        neg_d
        std  e_ca
        addd #1
        std  e_cb
        ldaa F_DEP,x
        suba #3
        ldx  e_fp
        staa F_DEP,x
        ldd  e_ca
        std  F_AL,x
        ldd  e_cb
        std  F_BE,x
        clr  F_NUL,x
        jsr  e_search
        neg_d
        std  e_sc
        jsr  e_unull
        tst  e_stop
        bne  .zero2
        ldx  e_fp
        ldd  e_sc
        subd F_BE,x
        blt  .gen
        ldd  F_BE,x
        rts
.zero2: ldd  #0
        rts
        endif
        ; ---- moves
.gen:
        if   E_ROOTORD
        tst  e_ply              ; the root after its first iteration: the kept list, its
        bne  .gn                ; 254s (the last iteration's other bests) now 253s
        ldd  e_rootend
        beq  .gn
        std  e_wp
        jsr  e_lists
        stx  e_t
.dm:    cpx  e_pend
        beq  .dm2
        ldaa 2,x
        cmpa #254
        bne  .dm1
        dec  2,x
.dm1:   inx
        inx
        inx
        bra  .dm
.dm2:   ldx  e_fp
        ldd  e_t
        std  F_I,x
        ldd  e_pend
        std  F_END,x
        bra  .g2
.gn:
        endif
        clr  e_caps
        jsr  e_gen
        jsr  e_lists
        stx  e_t
        ldx  e_fp
        ldd  e_t
        std  F_I,x
        ldd  e_pend
        std  F_END,x
        if   E_ROOTORD
        tst  e_ply
        bne  .gk
        std  e_rootend
.gk:
        endif
        ldd  F_TTF,x            ; the table's move first (none if both bytes are 0)
        beq  .g2
        ldx  e_t
.g1:    cpx  e_pend
        beq  .g2
        cmpa 0,x
        bne  .g1n
        cmpb 1,x
        bne  .g1n
        ldaa #255
        staa 2,x
        bra  .g2
.g1n:   inx
        inx
        inx
        bra  .g1
.g2:    ldx  e_fp
        clr  F_LEG,x
        clr  F_BF,x
        clr  F_BT,x
        ldd  F_AL,x
        std  F_OA,x
        ; ---- the move loop
.loop:  ldx  e_fp
        ldd  F_END,x
        std  e_pend
        ldd  F_I,x
        subd F_END,x
        bne  .l1
        jmp  .done
.l1:    ldx  F_I,x
        jsr  e_pick
        ldx  e_fp
        ldx  F_I,x
        ldd  0,x
        std  e_t                ; f, t
        ldaa 2,x
        staa e_t+2              ; ms
        inx
        inx
        inx
        stx  e_t+4
        ldx  e_fp
        ldd  e_t+4
        std  F_I,x
        if   E_LMR
        ldaa e_t+2
        staa F_MS,x
        endif
        ; quiet: nothing on the target, score < 160, not a promotion
        clr  F_Q,x
        ldab e_t+1
        andb #$77
        ldx  #e_board
        abx
        tst  0,x
        bne  .mk
        ldaa e_t+2
        cmpa #160
        bcc  .mk
        ldab e_t
        ldx  #e_board
        abx
        ldaa 0,x
        anda #7
        cmpa #1
        bne  .qy
        ldaa e_t+1
        anda #$70
        beq  .mk
        cmpa #$70
        beq  .mk
.qy:    ldx  e_fp
        inc  F_Q,x
.mk:    ldx  e_fp
        ldaa F_CHK,x
        staa e_inck
        ldaa e_t
        ldab e_t+1
        jsr  e_make
        bcc  .legal
        jsr  e_unmake
        bra  .loop
.legal: ldx  e_ofp              ; own frame (the parent of e_fp)
        inc  F_LEG,x
        ; gives check? only when futility or a reduction could use it
        clr  e_gives
        tst  F_Q,x
        beq  .fut
        tst  F_CHK,x
        bne  .fut
        ldaa F_DEP,x
        cmpa #1
        beq  .ng
        if   E_LMR
        cmpa #3
        blt  .fut
        ldaa F_LEG,x
        cmpa #4
        bcs  .fut
        ldaa F_MS,x
        cmpa #149
        bcc  .fut
        else
        bra  .fut
        endif
.ng:    jsr  e_gchk             ; the side now to move is in check
        bcc  .fut
        inc  e_gives
        ; futility at the last ply
.fut:   ldx  e_ofp              ; own frame (the parent of e_fp)
        if   E_FUT
        ldaa F_DEP,x
        cmpa #1
        bne  .srch
        tst  F_Q,x
        beq  .srch
        tst  F_CHK,x
        bne  .srch
        tst  e_gives
        bne  .srch
        ldaa F_LEG,x
        cmpa #2
        bcs  .srch
        ldd  F_STAT,x
        addd #150
        subd F_AL,x
        bgt  .srch
        jsr  e_unmake
        jmp  .loop
        endif
        ; ---- search the move
.srch:
        if   E_PVS
        ldaa F_LEG,x
        cmpa #1
        bne  .pvs
        endif
        ldd  F_BE,x             ; full window
        neg_d
        std  e_ca
        ldd  F_AL,x
        neg_d
        std  e_cb
        ldaa F_DEP,x
        deca
        jsr  e_child
        bra  .back
        if   E_PVS
.pvs:   clr  F_RED,x            ; reduction?
        if   E_LMR
        ldaa F_DEP,x
        cmpa #3
        blt  .nw
        ldaa F_LEG,x
        cmpa #4
        bcs  .nw
        tst  F_Q,x
        beq  .nw
        tst  F_CHK,x
        bne  .nw
        tst  e_gives
        bne  .nw
        ldaa F_MS,x
        cmpa #149
        bcc  .nw
        inc  F_RED,x
        endif
.nw:    bsr  .null              ; null window (-alpha-1, -alpha)
        ldaa F_DEP,x
        deca
        suba F_RED,x
        jsr  e_child
        tst  e_stop
        bne  .back
        ldx  e_ofp              ; own frame (the parent of e_fp)
        ldd  e_sc
        subd F_AL,x
        ble  .back
        tst  F_RED,x
        beq  .full
        bsr  .null
        ldaa F_DEP,x
        deca
        jsr  e_child
        tst  e_stop
        bne  .back
        ldx  e_ofp              ; own frame (the parent of e_fp)
        ldd  e_sc
        subd F_AL,x
        ble  .back
.full:  ldd  e_sc
        subd F_BE,x
        bge  .back
        ldd  F_BE,x
        neg_d
        std  e_ca
        ldd  F_AL,x
        neg_d
        std  e_cb
        ldaa F_DEP,x
        deca
        jsr  e_child
        bra  .back
; window (-alpha-1, -alpha) from the own frame at X; keeps X
.null:  ldd  F_AL,x
        neg_d
        std  e_cb
        subd #1
        std  e_ca
        rts
        endif
        ; ---- back from the child
.back:  jsr  e_unmake
        tst  e_stop
        beq  .b1
        ldd  #0
        rts
.b1:    ldx  e_fp
        ldd  e_sc
        subd F_AL,x
        bgt  .better
        jmp  .loop
.better: ldd e_sc
        std  F_AL,x
        ldaa F_F,x
        staa F_BF,x
        ldab F_T,x
        stab F_BT,x
        tst  e_ply
        bne  .b2
        staa e_rootf
        stab e_roott
        ldd  e_sc
        std  e_rootsc
        if   E_ROOTORD
        jsr  e_rord
        endif
        if   E_FAILLOW
        jsr  e_flchk
        endif
        ldx  e_fp
.b2:    ldd  e_sc
        subd F_BE,x
        bge  .cut
        jmp  .loop
.cut:   tst  F_Q,x              ; a quiet move that cuts: killer
        beq  .done
        ldab e_ply
        aslb
        aslb
        ldx  #e_killer
        abx
        stx  e_t
        ldx  e_fp
        ldaa F_BF,x
        ldab F_BT,x
        ldx  e_t
        cmpa 0,x
        bne  .k1
        cmpb 1,x
        beq  .done
.k1:    std  e_t+2
        ldd  0,x
        std  2,x
        ldd  e_t+2
        std  0,x
        ; ---- after the loop
.done:  ldx  e_fp
        tst  F_LEG,x
        bne  .store
        tst  F_CHK,x
        beq  .stale
        clra                    ; mated: -MATE + ply
        ldab e_ply
        subd #E_MATE
        rts
.stale: ldd  #0
        rts
.store: ldd  F_AL,x             ; flag and value
        subd F_BE,x
        blt  .s1
        ldaa #TT_LOWER
        staa e_t
        ldd  F_BE,x
        bra  .s3
.s1:    ldaa #TT_EXACT
        staa e_t
        ldd  F_AL,x
        subd F_OA,x
        bgt  .s2
        ldaa #TT_UPPER
        staa e_t
.s2:    ldd  F_AL,x
.s3:    std  e_sc               ; value returned
        jsr  tt_out
        std  e_t+2
        ldaa F_BF,x             ; move: the best, else keep the table's
        ldab F_BT,x
        bne  .s4
        tsta
        bne  .s4
        ldaa F_TTF,x
        ldab F_TTT,x
.s4:    std  e_t+4
        ldaa F_DEP,x            ; depth<<2 | flag in one byte
        asla
        asla
        oraa e_t
        ldx  F_TTX,x
        staa 6,x
        ldd  e_key
        std  0,x
        ldd  e_t+4
        std  2,x
        ldd  e_t+2
        std  4,x
        ldd  e_sc
        rts

; mate scores: from the table to this ply (D in, D out) and back
tt_in:  std  e_t
        subd #E_MB+1
        blt  .lo
        ldd  e_t
        subb e_ply
        sbca #0
        rts
.lo:    ldd  e_t
        addd #E_MB+1
        bgt  .r
        ldd  e_t
        addb e_ply
        adca #0
        rts
.r:     ldd  e_t
        rts
tt_out: std  e_t+6
        subd #E_MB+1
        blt  .lo
        ldd  e_t+6
        addb e_ply
        adca #0
        rts
.lo:    ldd  e_t+6
        addd #E_MB+1
        bgt  .r
        ldd  e_t+6
        subb e_ply
        sbca #0
        rts
.r:     ldd  e_t+6
        rts

; ---------------------------------------------------------------------
; e_qs: quiescence at the current ply (F_AL, F_BE in the frame)
; ---------------------------------------------------------------------
e_qs:   jsr  e_node
        bcc  .q0
        ldd  #0
        rts
.q0:    jsr  e_eval
        ldx  e_fp
        std  F_STAT,x
        ldaa e_ply
        cmpa #E_MAXPLY-1
        bcc  .stand
        ldab e_ply
        aslb
        ldx  #e_mvtop
        abx
        ldd  0,x
        subd #e_mvs+3*E_MVCAP
        bhi  .stand
        ldx  e_fp
        ldd  F_STAT,x
        subd F_BE,x
        blt  .q1
        ldd  F_BE,x
        rts
.stand: ldx  e_fp
        ldd  F_STAT,x
        rts
.q1:    ldd  F_STAT,x
        subd F_AL,x
        ble  .q2
        ldd  F_STAT,x
        std  F_AL,x
.q2:    ldaa #1
        staa e_caps
        jsr  e_gen
        clr  e_caps
        jsr  e_lists
        stx  e_t
        ldx  e_fp
        ldd  e_t
        std  F_I,x
        ldd  e_pend
        std  F_END,x
.ql:    ldx  e_fp
        ldd  F_END,x
        std  e_pend
        ldd  F_I,x
        subd F_END,x
        beq  .qa
        ldx  F_I,x
        jsr  e_pick
        ldx  e_fp
        ldx  F_I,x
        ldd  0,x
        std  e_t
        inx
        inx
        inx
        stx  e_t+4
        ldx  e_fp
        ldd  e_t+4
        std  F_I,x
        ldaa F_CHK,x            ; in check? (from e_search: known; from e_qs: $FF until the
        bpl  .qh                ; first move made here, then worked out from the last move)
        jsr  e_gchk
        ldx  e_fp
        ldaa #0
        adca #0
        staa F_CHK,x
.qh:    staa e_inck
        ldaa e_t
        ldab e_t+1
        jsr  e_make
        bcc  .qm
.qx:    jsr  e_unmake
        bra  .ql
.qm:    ldaa e_mpc              ; a higher piece type taking on a defended square: not tried
        anda #7
        ldab e_mcap
        beq  .qk
        andb #7
        cba
        bls  .qk
        ldab e_mt
        ldaa e_side
        jsr  e_att
        bcs  .qx
.qk:    ldx  e_ofp              ; own frame (the parent of e_fp)
        ldd  F_BE,x
        neg_d
        ldx  e_fp
        std  F_AL,x
        ldx  e_ofp              ; own frame (the parent of e_fp)
        ldd  F_AL,x
        neg_d
        ldx  e_fp
        std  F_BE,x
        ldaa #$FF               ; its check state: not worked out yet
        staa F_CHK,x
        jsr  e_qs
        neg_d
        std  e_sc
        jsr  e_unmake
        tst  e_stop
        beq  .qb
        ldd  #0
        rts
.qb:    ldx  e_fp
        ldd  e_sc
        subd F_AL,x
        ble  .ql
        ldd  e_sc
        subd F_BE,x
        blt  .qc
        ldd  F_BE,x
        rts
.qc:    ldd  e_sc
        std  F_AL,x
        bra  .ql
.qa:    ldx  e_fp
        ldd  F_AL,x
        rts

; ---------------------------------------------------------------------
; eng_think (see API.md)
; ---------------------------------------------------------------------
eng_think:
        clr  e_pcv
        clr  e_nodes
        clr  e_nodes+1
        clr  e_nodes+2
        clr  e_stop
        ldaa #32                ; first clock read after 32 nodes (it was 256: a slow depth 2
        staa e_tick             ; could run past a 1 s limit by 1.5 s)
        clr  e_depth
        clr  e_bestf
        clr  e_bestt
        ldd  #0
        std  e_score
        ldd  e_margin           ; levels 1-4: this search's evaluation noise seed
        beq  .nsd
        jsr  e_rand
        ldab e_rnd+1
        stab e_nseed
.nsd:   clr  e_bare             ; a bare king on either side: no table cut-offs in this search
        ldx  #e_cnt             ; (17 Nov: with them the mates with bishop and knight came off
.bk:    ldaa 1,x                ; 80% -> 73% of random starts, with stalemates)
        adda 2,x
        adda 3,x
        adda 4,x
        adda 5,x
        bne  .bn
        inc  e_bare
.bn:    cpx  #e_cnt+8
        beq  .bd
        ldab #8
        abx
        bra  .bk
.bd:
        if   E_FAILLOW
        clr  e_flon             ; fail-low: limits of twice the nodes, e_tlim + e_tadd
        clr  e_flused
        ldd  e_nlim+1
        asld
        std  e_fln+1
        ldaa e_nlim
        rola
        staa e_fln
        ldd  e_tlim
        addd e_tadd
        bcc  .tf
        ldd  #$FFFF
.tf:    std  e_tfl
        endif
        if   E_ROOTORD
        ldd  #0                 ; root ordering: no kept list yet
        std  e_rootend
        endif
        ldx  #e_killer
        ldab #4*E_MAXPLY
.k:     clr  0,x
        inx
        decb
        bne  .k
        ldd  TMW_FRAM
        std  e_tstart
        jsr  eng_legal          ; count the legal moves
        stab e_nleg
        bne  .go
        rts
.go:    ldaa #1
        staa e_t+7              ; depth
.it:    clr  e_rootf
        clr  e_roott
        jsr  e_ply0
        ldx  e_fp
        ldaa e_t+7
        staa F_DEP,x
        ldd  #-E_INF
        std  F_AL,x
        ldd  #E_INF
        std  F_BE,x
        if   E_NULL
        ldaa #1
        staa F_NUL,x
        endif
        ldaa e_t+7
        psha
        jsr  e_search
        std  e_t+4              ; the iteration's score
        if   E_FAILLOW
        clr  e_flon
        endif
        pulb
        stab e_t+7
        ldd  e_rootf
        beq  .nr
        staa e_bestf
        stab e_bestt
        ldd  e_rootsc
        std  e_score
.nr:    tst  e_stop
        bne  .end
        ldaa e_t+7
        staa e_depth
        ldd  e_bestf
        beq  .ns
        ldd  e_t+4
        std  e_score
.ns:    ldd  e_t+4              ; a mate found: stop
        subd #E_MB+1
        bge  .end
        ldd  e_t+4
        addd #E_MB+1
        ble  .end
        ldaa e_nleg
        cmpa #1
        beq  .end
        ldd  e_tlim             ; more than half the time used: no new depth
        beq  .poll
        ldd  TMW_FRAM
        subd e_tstart
        asld
        subd e_tlim
        bcc  .end
.poll:  ldaa e_t+7
        jsr  think_poll
        bcs  .end
        ldaa e_t+7
        inca
        staa e_t+7
        ldab e_maxd
        bne  .md
        ldab #40
.md:    cba
        bhi  .end
        jmp  .it
.end:
.fall:  ldd  e_bestf            ; nothing searched: the first legal move
        bne  .r
        jsr  eng_legal
        ldd  e_lm
        staa e_bestf
        stab e_bestt
.r:     rts

; xorshift16 (7, 9, 8): e_rnd
e_rand: ldd  e_rnd
        std  e_t+6              ; x ^= x << 7
        ldaa #7
        staa e_t+5
.s7:    asl  e_t+7
        rol  e_t+6
        dec  e_t+5
        bne  .s7
        ldd  e_rnd
        eora e_t+6
        eorb e_t+7
        std  e_rnd
        tab                     ; x ^= x >> 9
        lsrb
        clra
        eorb e_rnd+1
        stab e_rnd+1
        ldaa e_rnd+1            ; x ^= x << 8
        eora e_rnd
        staa e_rnd
        rts
