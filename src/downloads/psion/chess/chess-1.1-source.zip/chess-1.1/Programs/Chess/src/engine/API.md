# Engine interface (contract between src/engine and the kernel/screens)

The engine is resident 6303 code assembled into the kernel image (`include "../engine/engine.asm"`),
written for `tools/asm.py`. It owns only the files in `src/engine/`. Everything below is the
fixed interface; internal labels may change.

## Board encoding
- `e_board`: 128 bytes, 0x88 layout: square = rank*16 + file, a1 = $00, h1 = $07, a8 = $70, h8 = $77.
  A square is off the board when `sq & $88` is non-zero.
- Pieces: 1 P, 2 N, 3 B, 4 R, 5 Q, 6 K; +8 for Black. 0 = empty.
- `e_side`: 0 White to move, 8 Black. `e_castle`: bit0 White O-O, bit1 White O-O-O, bit2 Black O-O,
  bit3 Black O-O-O. `e_ep`: en-passant target square (0x88) or $FF. `e_half`: half-move clock (byte).
- A move is two bytes `from, to`. `to & $77` is the destination. For a promotion, bits 7 and 3 of
  `to` give the piece: code = bit3 + 2*bit7: 0 queen, 1 rook, 2 bishop, 3 knight.
  Castling is the king's two-square move (E1G1). En passant is the pawn's diagonal move.

## Routines (all clobber A, B, X and T0..T11 unless stated)
| Routine | In | Out |
|---|---|---|
| `eng_init` | — | one-time set-up at launch (after `e_tt`/`e_ttn` are set). Then `eng_reset`. |
| `eng_reset` | — | start position, game history cleared |
| `eng_setup` | caller has written `e_board`, `e_side`, `e_castle`, `e_ep`, `e_half` | derived state recomputed, game history cleared. C=1 if the position is illegal (A = reason: 1 king count wrong, 2 pawn on rank 1/8, 3 side not to move in check) |
| `eng_legal` | — | legal moves for the side to move in `e_lm` (pairs from,to), B = `e_lmn` = count |
| `eng_play` | A = from, B = to (must be legal) | the move is made on the game board and added to the game history |
| `eng_check` | — | A ≠ 0 if the side to move is in check |
| `eng_status` | — | A = 0 playing, 1 checkmate, 2 stalemate, 3 fifty moves, 4 threefold repetition, 5 too little material |
| `eng_think` | `e_tlim` (word, 50 ms frames, 0 = none), `e_nlim` (3 bytes, nodes, 0 = none), `e_maxd` (byte, 0 = 40), `e_margin` (word, centipawns, 0 = play the best), `e_tadd` (word, frames: the extra time a failing-low search may take past `e_tlim`; the kernel's `think` sets it) | `e_bestf`, `e_bestt` (0,0 if no legal move), `e_score` (word, side to move's view, centipawns; mates are ±(30000 - plies)), `e_depth`, `e_nodes` (3 bytes) |

`eng_think` calls the kernel routine **`think_poll`** (provided by the kernel, not the engine) every
32 nodes (3-4 times a second) and once after each finished depth, with A = depth finished so far. `think_poll`
may update the display (it must not touch the engine's variables or scratch) and returns C=1 to
stop the search now (a key was pressed). The engine reads `TMW_FRAM` itself for its time limit:
it stops at the end of a depth when more than half of `e_tlim` is used, and at once when `e_tlim`
runs out or only one move is legal.

Fail-low (17 Nov, `E_FAILLOW`; ref `opts.failLow`): from depth 2, when the first root move (the last
depth's best) scores 100 or more below the last depth's score (neither a mate), the search may run
past the limits, to twice `e_nlim` and to `e_tlim` + `e_tadd`, until a root move scores within the
100 again or that depth ends. Once a search; not while a side has a bare king (`e_bare`). The kernel sets `e_tadd` to `e_tlim`, at most an
eighth of the side to move's clock.

Root ordering (17 Nov, `E_ROOTORD`, **off**: measured, it cost bishop-and-knight mates, docs/strength.md s.15; ref `opts.rootOrder`): the root's move list is generated once
a search and kept; each root move that becomes the best gets the score 255 (the one before it 254;
254s become 253 at the next depth), so each depth searches the last depth's best first, then the
moves that were best during it.

Margin pass (levels 1-4, `e_margin` > 0): every root
move is searched again one ply shallower (at depth 0 with a probe that finds a mate in one by the
reply, a mate by the move, and a stalemate or other draw by the move), on
a fresh budget of 8 times `e_tlim` / `e_nlim` (eng_think multiplies them in place: set them again
before each call, as the kernel does). If that budget runs out, or `think_poll` stops it, the pick
is made among the moves scored so far (the deepening's move if none). `e_nodes` then counts the pass's nodes only.

## Memory
- `e_tt` (word): address of the transposition table; `e_ttn` (word): number of 7-byte entries (key16, from, to, score16, depth<<2 | flag), a power
  of two (minimum 256). Set by the kernel before `eng_init`, from the RAM it has.
- The engine's scratch (search move stack, undo stack) is `ENG_SCRATCH_SIZE` bytes at the label
  `e_scratch` (defined by the engine inside its variable block). `eng_legal`, `eng_status`,
  `eng_think` use it. (`eng_find`, a check that a move is in the legal list, went on 17 Nov:
  nothing in the game called it; the tests look in `e_lm` themselves.)
- Engine variables are in `src/engine/evars.inc`; the kernel includes that inside its variable block
  (cleared at start).

## Assembling
`engine.asm` includes its parts by bare name (`include "emove.asm"`), so the build must put
`src/engine` on the assembler's include path (`incdirs`). It needs `T0`..`T11` and `TMW_FRAM`
defined (as in Drakeloft's defs.inc).

## King and pawn against king (added)
King and pawn v king is not the engine's any more (16 Nov): the kernel plays it at the root from
the distance table on the pack (`src/screens/ov_kpk.asm`, reference `ref/kpkroot.js`) and only
calls `eng_think` there when the pawn's side is to move in a draw.
