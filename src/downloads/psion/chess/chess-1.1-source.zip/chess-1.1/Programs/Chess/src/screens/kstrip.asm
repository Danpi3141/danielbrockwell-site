; ---------------------------------------------------------------------
; Game-overlay entries for the strip and the record (formatting lives here).
; ---------------------------------------------------------------------
; the last move into the strip (empty at the start)
strip_last:
        ldx  #st_p
        clr  0,x
        clr  4,x
        clr  8,x
        tst  g_n
        beq  .x
        ldx  #g_last
        ldd  #st_p
        jsr  fmt_parts
.x:     ldab #$FF               ; the piece giving check, for the blink
        tst  g_chk
        beq  .k
        jsr  find_checker
.k:     stab g_ckr
        ldd  st_p+8             ; part 3 kept for the board's row 2 while nothing is typed
        std  st_p3
        ldd  st_p+10
        std  st_p3+2
        rts
; pm_f, pm_t: pm_i = the record's info byte (before the move is made)
g_info: jsr  move_info
        staa pm_i
        rts

