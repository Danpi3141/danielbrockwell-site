; =====================================================================
; The menu (slot A). Returns A = command (M_*), M_NONE for ON/CLEAR.
; UP/DOWN choose (and wrap round), EXE takes it, a letter jumps to the item it starts.
; =====================================================================
        include "../defs.inc"
        include "ids.inc"

        jmp  menu

        if   SPEEDTEST
N_ITEMS = 15
        else
N_ITEMS = 14
        endif
items:  fcb  M_NEW
        fcl  "NEW GAME"
        fcb  M_LEVEL
        fcl  "LEVEL"
        fcb  M_BACK
        fcl  "TAKE BACK"
        fcb  M_HINT
        fcl  "HINT"
        fcb  M_FLIP
        fcl  "FLIP (PLAY OTHER)"
        fcb  M_LIST
        fcl  "MOVE LIST"
        fcb  M_REVIEW
        fcl  "GAME REVIEW"
        fcb  M_PGN
        fcl  "EXPORT PGN"
        fcb  M_IMPORT
        fcl  "IMPORT GAME"
        fcb  M_SETUP
        fcl  "SET UP POSITION"
        fcb  M_SETTINGS
        fcl  "SETTINGS"
        fcb  M_DRAW
        fcl  "OFFER A DRAW"
        fcb  M_RESIGN
        fcl  "RESIGN"
        fcb  M_EXIT
        fcl  "SAVE AND LEAVE"
        if   SPEEDTEST
        fcb  M_SPEED            ; (last: S S S still reaches SAVE AND LEAVE)
        fcl  "SPEED TEST"
        endif

; A = item number: X = its entry
item:   ldx  #items
.l:     tsta
        beq  .x
        ldab 1,x
        abx
        inx
        inx
        deca
        bra  .l
.x:     rts

menu:   clr  mn_i
        clr  mn_top
.draw:  jsr  scr_cls
        clr  mn_r
.row:   ldaa mn_r
        adda mn_top
        cmpa #N_ITEMS
        bhs  .shown
        psha
        ldaa mn_r
        clrb
        jsr  scr_at
        pula
        psha
        ldab #' '
        cmpa mn_i
        bne  .m
        ldab #'>'
.m:     tba
        jsr  scr_putc
        pula
        bsr  item
        inx
        jsr  scr_puts
        inc  mn_r
        ldaa mn_r
        cmpa #4
        bne  .row
.shown: jsr  scr_flush
        clra
        jsr  key_wait
        jsr  key_upper
        cmpb #K_ON
        bne  .k1
        ldaa #M_NONE
        rts
.k1:    cmpb #K_EXE
        bne  .k2
        ldaa mn_i
        bsr  item
        ldaa 0,x
        rts
.k2:    cmpb #K_UP              ; UP at the top goes to the bottom, DOWN at the
        bne  .k3                ; bottom to the top (20 Nov)
        ldaa mn_i
        bne  .u
        ldaa #N_ITEMS
.u:     deca
        bra  .set
.k3:    cmpb #K_DOWN
        bne  .k4
        ldaa mn_i
        inca
        cmpa #N_ITEMS
        bne  .set
        clra
.set:   staa mn_i
        bra  .fit
.k4:    ; a letter: the next item that starts with it
        stab mn_k
        ldaa mn_i
        staa mn_r
.f:     inc  mn_r
        ldaa mn_r
        cmpa #N_ITEMS
        blo  .f1
        clr  mn_r
.f1:    ldaa mn_r
        cmpa mn_i
        beq  .draw
        bsr  item
        ldaa 2,x
        cmpa mn_k
        bne  .f
        ldaa mn_r
        staa mn_i
.fit:   ldaa mn_i               ; keep the choice on screen
        cmpa mn_top
        bhs  .f2
        staa mn_top
.f2:    suba #3
        bcs  .dr
        cmpa mn_top
        bls  .dr
        staa mn_top
.dr:    jmp  .draw

mn_i:   rmb  1
mn_top: rmb  1
mn_r:   rmb  1
mn_k:   rmb  1
