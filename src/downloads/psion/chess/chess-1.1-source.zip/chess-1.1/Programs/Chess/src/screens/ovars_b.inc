; board overlay's own variables (gone when the slot is reused)
bk_on:    rmb 1                 ; blink phase: the squares in bk_sq are drawn empty
bk_sq:    rmb 3
bk_n:     rmb 1
bk_t:     rmb 1
cur_on:   rmb 1                 ; the cursor's blink phase
dr_top:   rmb 1
dr_c:     rmb 1
dr_r:     rmb 1
dr_col:   rmb 1
dr_sq:    rmb 1
dr_t:     rmb 1
dr_p:     rmb 2
in_n:     rmb 1                 ; characters typed
in_buf:   rmb 4
sel:      rmb 1                 ; the chosen piece's square, $FF none
hu_s:     rmb 1
hu_step:  rmb 1
hu_tmp:   rmb 12
hu_idle:  rmb 1                 ; cursor blinks since the last key
clk_tk:   rmb 1
pw_t:     rmb 2
pw_f:     rmb 1
