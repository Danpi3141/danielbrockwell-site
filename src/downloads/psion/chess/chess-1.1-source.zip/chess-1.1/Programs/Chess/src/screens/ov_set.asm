; =====================================================================
; Settings (slot A). Entry 0 starts at the top, entry 1 at the level.
; UP/DOWN choose a line, LEFT/RIGHT (or EXE) change it, ON/CLEAR leaves.
; Each line: label, the setting's address, its highest value, and the
; names of its values (or 0: shown as a number, first value 1).
; =====================================================================
        include "../defs.inc"
        include "ids.inc"

        jmp  set_top
        jmp  set_lv

N_LINES = 13

lines:  fdb  l_lay,st_layout,v_lay
        fcb  2
        fdb  l_lev,se_lv,v_lev
        fcb  8
        fdb  l_clk,st_timing,v_clk
        fcb  5
        fdb  l_pace,st_pace,v_pace
        fcb  1
        fdb  l_col,st_colour,v_col
        fcb  2
        fdb  l_not,st_notat,v_not
        fcb  1
        fdb  l_snd,st_sound,v_snd
        fcb  2
        fdb  l_ymin,st_cmin,0
        fcb  54                 ; (a clock is a word of 50 ms frames: 54 minutes at most)
        fdb  l_yinc,st_cinc,0
        fcb  60
        fdb  l_cmin,st_cmin+1,0
        fcb  54
        fdb  l_cinc,st_cinc+1,0
        fcb  60
        fdb  l_res,st_resign,v_off
        fcb  1
        fdb  l_two,g_mode,v_off
        fcb  1

l_lay:  fcl  "BOARD"
l_lev:  fcl  "LEVEL"
l_clk:  fcl  "CLOCK"
l_pace: fcl  "PACE"
l_col:  fcl  "YOU PLAY"
l_not:  fcl  "MOVES"
l_snd:  fcl  "SOUND"
l_ymin: fcl  "CUSTOM: YOU MIN"
l_yinc: fcl  "CUSTOM: YOU +SEC"
l_cmin: fcl  "CUSTOM: IT MIN"
l_cinc: fcl  "CUSTOM: IT +SEC"
l_res:  fcl  "IT RESIGNS"
l_two:  fcl  "TWO PLAYERS"

v_lay:  fcl  "MAP"
        fcl  "SPLIT"
        fcl  "REAL BOARD"
v_lev:  fcl  "1 450"              ; measured 16 Nov with the position book (docs/strength.md 11, 12); 1-3 by a self-play chain from 4
        fcl  "2 650"
        fcl  "3 950"
        fcl  "4 1200"
        fcl  "5 1450"
        fcl  "6 1550"
        fcl  "7 1700"
        fcl  "8 1950"
        fcl  "AUTO"
v_clk:  fcl  "NONE"
        fcl  "5|5"
        fcl  "10|5"
        fcl  "15|10"
        fcl  "30|30"
        fcl  "CUSTOM"
v_pace: fcl  "NATURAL"
        fcl  "FAST"
v_col:  fcl  "WHITE"
        fcl  "BLACK"
        fcl  "ALTERNATE"
v_not:  fcl  "STANDARD"
        fcl  "SQUARES"
v_snd:  fcl  "ALL"
        fcl  "BLIPS"
        fcl  "OFF"
v_off:  fcl  "OFF"
        fcl  "ON"

set_lv: ldaa #1
        bra  set_go
set_top:
        clra
set_go: staa se_i
        clr  se_top
        ldaa st_level           ; the level line: 0..7 levels, 8 Auto
        staa se_l0              ; (the level in force: Auto starts from it)
        deca
        tst  st_auto
        beq  .l
        ldaa #8
.l:     staa se_lv
        jsr  se_fit
.draw:  jsr  scr_cls
        clr  se_r
.row:   ldaa se_r
        adda se_top
        cmpa #N_LINES
        bhs  .done
        staa se_n
        ldaa se_r
        clrb
        jsr  scr_at
        ldaa #' '
        ldab se_n
        cmpb se_i
        bne  .m
        ldaa #'>'
.m:     jsr  scr_putc
        ldaa se_n
        jsr  line
        ldx  0,x
        jsr  scr_puts
        jsr  scr_eol
        ; the value, right-aligned in the line
        ldaa se_n
        jsr  vtext              ; X = length-prefixed text
        stx  se_p
        ldaa se_r
        ldab #20
        subb 0,x
        jsr  scr_at
        ldx  se_p
        jsr  scr_puts
        inc  se_r
        ldaa se_r
        cmpa #4
        bne  .row
.done:  jsr  scr_flush
        clra
        jsr  key_wait
        cmpb #K_ON
        beq  .out
        cmpb #K_UP
        bne  .k1
        tst  se_i
        beq  .draw
        dec  se_i
        bsr  se_fit
        bra  .draw
.k1:    cmpb #K_DOWN
        bne  .k2
        ldaa se_i
        cmpa #N_LINES-1
        beq  .draw
        inc  se_i
        bsr  se_fit
        bra  .draw
.k2:    cmpb #K_LEFT
        bne  .k3
        ldaa se_i
        jsr  line
        ldx  2,x
        ldaa 0,x
        beq  .wrapl
        dec  0,x
        bra  .chg
.wrapl: ldaa se_i
        jsr  line
        ldaa 6,x
        ldx  2,x
        staa 0,x
        bra  .chg
.k3:    cmpb #K_RIGHT
        beq  .inc
        cmpb #K_EXE
        bne  .draw
.inc:   ldaa se_i
        jsr  line
        ldab 6,x
        ldx  2,x
        ldaa 0,x
        cba
        bhs  .wrapr
        inc  0,x
        bra  .chg
.wrapr: clr  0,x
.chg:   jsr  se_apply
        jmp  .draw
.out:   jsr  se_apply
        rts

; the level line back into st_level / st_auto
se_apply:
        clr  st_auto
        ldaa se_lv
        cmpa #8
        blo  .n
        ldaa #1
        staa st_auto
        ldaa se_l0              ; Auto starts from the level in force when the screen opened
        staa st_level           ; (17 Nov: it was the one stepped past to reach Auto, 8 or 1)
        rts
.n:     inca
        staa st_level
        rts

; keep the chosen line on screen
se_fit: ldaa se_i
        cmpa se_top
        bhs  .a
        staa se_top
.a:     suba #3
        bcs  .x
        cmpa se_top
        bls  .x
        staa se_top
.x:     rts

; A = line: X = its entry (7 bytes)
line:   ldab #7
        mul
        addd #lines
        xgdx
        rts

; A = line: X = the text of its value
vtext:  bsr  line
        stx  se_p
        ldx  2,x
        ldab 0,x                ; the value
        ldx  se_p
        ldx  4,x
        beq  .num
.f:     tstb
        beq  .x
        pshb
        ldab 0,x
        abx
        inx
        pulb
        decb
        bra  .f
.x:     rts
.num:   clra
        jsr  num_str
        ldx  #kv_nbuf
        rts

se_i:   rmb  1
se_top: rmb  1
se_r:   rmb  1
se_n:   rmb  1
se_lv:  rmb  1
se_l0:  rmb  1
se_p:   rmb  2
