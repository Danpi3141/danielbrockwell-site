; ---------------------------------------------------------------------
; Reading the game record from A:CHESSAV (ksave.asm has the layout).
; Shared by the game overlay and the move list. Needs sv_buf (the
; largest record, the header, fits), sv_tag, sv_off.
; ---------------------------------------------------------------------
fn_main: fcl "A:CHESSAV"

; open the save file: C=0 if it is there
sv_open:
        clr  kv_pkok            ; the file services select A:
        ldx  #fn_main
        os   FL$OPEN
        bcs  .x
        staa sv_rt              ; its record type
        tab
        os   FL$RECT
        clc
.x:     rts

; A = tag: find the record that starts with it, read into sv_buf, and
; make it the current one (for FL$ERAS). C=1 if there is none. Each
; record is reached by its number, as OPL's POSITION does: FL$NEXT is
; not to be trusted after an erase.
sv_find:
        staa sv_tag
        ldd  #1
        std  sv_rn
.l:     clra
        clrb
        os   FL$SETP            ; A:
        ldab sv_rt
        os   FL$RECT
        ldd  sv_rn
        os   FL$RSET
        bcs  .no
        ldx  #sv_buf
        os   FL$READ
        bcs  .no
        ldab sv_buf
        beq  .no
        ldaa sv_buf+1
        cmpa sv_tag
        beq  .yes
        ldd  sv_rn
        addd #1
        std  sv_rn
        bra  .l
.yes:   clc
        rts
.no:    sec
        rts

; sp_i: A = its chunk, B = its offset in the chunk (bytes)
sp_chunk:
        clra
        ldab sp_i
.d:     cmpb #CPLY
        blo  .r
        subb #CPLY
        inca
        bra  .d
.r:     pshb
        aslb
        pulb
        pshb
        aslb
        stab sv_off
        pulb
        addb sv_off             ; offset = 3 * (ply mod 10)
        rts

; sp_i = ply: sp_e = its 3 bytes. C=1 if the file can't give it.
rd_ply: jsr  sv_open
        bcs  .x
        bsr  sp_chunk
        stab sv_off
        bsr  sv_find
        bcs  .x
        ldx  #sv_buf+2
        ldab sv_off
        abx
        ldd  0,x
        std  sp_e
        ldaa 2,x
        staa sp_e+2
        clc
.x:     rts

