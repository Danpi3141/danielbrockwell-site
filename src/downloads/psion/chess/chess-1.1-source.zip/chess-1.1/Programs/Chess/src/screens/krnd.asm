; ---------------------------------------------------------------------
; rnd: B = a random number 0..A-1 (A > 0). 16-bit LCG.
; ---------------------------------------------------------------------
rnd:    psha
        ldd  kv_rnd
        ldx  #25173
        jsr  mul16              ; D = D * X (low 16 bits)
        addd #13849
        std  kv_rnd
        tab                     ; the high byte is the better one
        pula
        mul                     ; A = B * A / 256
        tab
        rts

; D = D * X, low 16 bits (X kept); the ROM's UT$UMUL since 17 Nov
mul16:  pshx
        os   UT$UMUL            ; D = the high word, X = the low word
        xgdx
        pulx
        rts

