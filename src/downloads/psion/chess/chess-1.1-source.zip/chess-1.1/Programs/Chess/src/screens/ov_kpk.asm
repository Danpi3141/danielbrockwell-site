; =====================================================================
; King and pawn v king from the distance table (slot A), at the root, in
; place of a search. ref/kpkroot.js is the reference: the same candidates
; in the same order, the same ties (the first best).
;
; The table (tools/kpk/kpkd.js: for each position with the pawn's side to
; move, its moves to a safe promotion, 0 = a draw, 4 bits, a distance over
; 15 stored as d - 15) is on the pack compressed (data/kpkdz.bin, block
; KPK_BLOCK, tools/kpk/kpkd_pack.js): entries (p * 64 + wk) * 64 + sk (the
; pawn made White and put on files a-d; p = (rank - 2) * 4 + file; squares
; 0-63) in 96 blocks of 1024, each a list of runs in one canonical Huffman
; code. A look-up decodes its block (read from the pack a byte at a time)
; into one of two buffers, unless one holds it already (the other, least
; recently used, is replaced: a decision then decodes 2 blocks on average,
; at most 6), and reads the entry; the code table is read once a call.
;
; Entry 0: C=0 and A = from, B = to (0x88; promotion bits in to) when the
; position is K+P v K and the table decides; C=1 otherwise (not that
; ending, or the pawn's side to move in a draw: the engine searches).
; Uses only the engine's lasting variables (board, side, kings, counts)
; and pk_read, so the engine's scratch (this slot) is not needed.
; =====================================================================
        include "../defs.inc"
        include "ids.inc"

        jmp  kk_root

KK_NONE = 99

kk_root:
        ldx  #e_cnt+2           ; no knight, bishop, rook or queen
.n:     tst  0,x
        bne  .no
        tst  8,x
        bne  .no
        inx
        cpx  #e_cnt+6
        bne  .n
        ldaa e_cnt+PC_P         ; one pawn
        adda e_cnt+8+PC_P
        cmpa #1
        bne  .no
        ldx  #e_board           ; find it
        clrb
.p:     ldaa 0,x
        anda #7
        cmpa #PC_P
        beq  .fp
        inx
        incb
        bpl  .p
.no:    sec
        rts
.fp:    stab kk_p
        jsr  kk_head            ; the code table; no block decoded yet
        ldx  #e_board
        ldab kk_p
        abx
        ldaa 0,x
        anda #8
        staa kk_pc              ; its colour: 0 or 8
        ldab #16                ; forward
        tsta
        beq  .w
        ldab #$F0
.w:     stab kk_fwd
        ldx  #e_ksq             ; sk = the pawn's side's king, wk = the other
        tsta
        beq  .k
        inx
.k:     ldaa 0,x
        staa kk_sk
        ldx  #e_ksq+1
        tst  kk_pc
        beq  .k2
        dex
.k2:    ldaa 0,x
        staa kk_wk
        ldaa e_side
        cmpa kk_pc
        beq  kk_strong
        jmp  kk_weak

; ---- the pawn's side to move
kk_strong:
        ldaa kk_sk
        ldab kk_wk
        jsr  kk_look            ; A = this position's distance
        tsta
        bne  .w
        sec                     ; a draw: the search plays it
        rts
.w:     cmpa #1
        bne  .moves
        ldaa kk_p               ; 1: promote now
        adda kk_fwd
        staa kk_q
        jsr  kk_promo           ; B = the piece's bits
        orab kk_q
        ldaa kk_p
        clc
        rts
.moves: ldaa #KK_NONE
        staa kk_best
        clr  kk_i               ; the king's steps
.kl:    ldab kk_i
        ldx  #kk_dir
        abx
        ldaa 0,x
        adda kk_sk
        staa kk_t
        bita #$88
        bne  .kn
        cmpa kk_p
        beq  .kn
        ldab kk_wk
        jsr  kk_adj
        bcs  .kn
        ldaa kk_t               ; (the king on t, the pawn where it is)
        ldab kk_p
        ldx  #0
        jsr  kk_cand            ; from sk to t
.kn:    inc  kk_i
        ldaa kk_i
        cmpa #8
        bne  .kl
        ldaa kk_p               ; the pawn: one step, not onto the last rank
        adda kk_fwd
        staa kk_t
        cmpa kk_sk
        beq  .done
        cmpa kk_wk
        beq  .done
        anda #$70
        beq  .done              ; (rank 1: a Black pawn's last)
        cmpa #$70
        beq  .done
        ldaa kk_sk
        ldab kk_t
        ldx  #1
        jsr  kk_cand            ; from p to t
        ldaa kk_p               ; two steps from the start
        anda #$70
        ldab #$10
        tst  kk_pc
        beq  .s
        ldab #$60
.s:     cba
        bne  .done
        ldaa kk_t
        adda kk_fwd
        staa kk_t
        cmpa kk_sk
        beq  .done
        cmpa kk_wk
        beq  .done
        ldaa kk_sk
        ldab kk_t
        ldx  #1
        jsr  kk_cand
.done:  ldaa kk_best
        cmpa #KK_NONE
        bne  .ok
        sec
        rts
.ok:    ldaa kk_mf
        ldab kk_mt
        clc
        rts

; a candidate: A = the pawn's side's king, B = the pawn, after it; X = 0 a
; king move (sk -> kk_t), 1 a pawn move (p -> kk_t). Kept if the
; defender's worst reply is a win nearer than the best so far.
kk_cand:
        stx  kk_kind
        jsr  kk_def             ; A = distance, 0 = a draw
        tsta
        beq  .x
        cmpa kk_best
        bhs  .x
        staa kk_best
        ldaa kk_sk
        tst  kk_kind+1
        beq  .f
        ldaa kk_p
.f:     staa kk_mf
        ldaa kk_t
        staa kk_mt
.x:     rts

; the defender to move, the pawn's side's king A, the pawn B (the other
; king kk_wk): the worst of its replies for the pawn's side (distance),
; 0 if any reply draws (taking the pawn, a drawn position) or none is legal
kk_def: staa kk_dsk
        stab kk_dp
        clr  kk_worst
        clr  kk_any
        clr  kk_j
.l:     ldab kk_j
        ldx  #kk_dir
        abx
        ldaa 0,x
        adda kk_wk
        staa kk_u
        bita #$88
        bne  .n
        ldab kk_dsk
        jsr  kk_adj
        bcs  .n
        ldaa kk_u
        ldab kk_dp
        jsr  kk_guard
        bcs  .n
        ldaa kk_u
        cmpa kk_dp
        beq  .draw              ; takes the pawn
        inc  kk_any
        ldaa kk_dsk
        ldab kk_u
        psha
        ldaa kk_dp              ; (kk_look takes the pawn from kk_lp)
        staa kk_lp
        pula
        jsr  kk_lookp
        tsta
        beq  .draw
        cmpa kk_worst
        bls  .n
        staa kk_worst
.n:     inc  kk_j
        ldaa kk_j
        cmpa #8
        bne  .l
        tst  kk_any
        beq  .draw              ; stalemate
        ldaa kk_worst
        rts
.draw:  clra
        rts

; ---- the defender to move: the first move that keeps the draw, else the
; one that loses slowest
kk_weak:
        clr  kk_best            ; (0: none yet; distances are 1 or more)
        clr  kk_j
.l:     ldab kk_j
        ldx  #kk_dir
        abx
        ldaa 0,x
        adda kk_wk
        staa kk_u
        bita #$88
        bne  .n
        ldab kk_sk
        jsr  kk_adj
        bcs  .n
        ldaa kk_u
        ldab kk_p
        jsr  kk_guard
        bcs  .n
        ldaa kk_u
        cmpa kk_p
        beq  .take
        ldaa kk_p
        staa kk_lp
        ldaa kk_sk
        ldab kk_u
        jsr  kk_lookp
        tsta
        beq  .take              ; a draw: this one
        cmpa kk_best
        bls  .n
        staa kk_best
        ldaa kk_u
        staa kk_mt
.n:     inc  kk_j
        ldaa kk_j
        cmpa #8
        bne  .l
        tst  kk_best
        bne  .ok
        sec
        rts
.ok:    ldaa kk_wk
        ldab kk_mt
        clc
        rts
.take:  ldaa kk_wk
        ldab kk_u
        clc
        rts

; A, B = squares: C=1 if they are next to each other (or the same)
kk_adj: sba
        bpl  .p
        nega
.p:     cmpa #1
        bls  .y
        cmpa #15
        blo  .no
        cmpa #17
        bls  .y
.no:    clc
        rts
.y:     sec
        rts

; A = square, B = the pawn: C=1 if the pawn guards it
kk_guard:
        addb kk_fwd
        incb
        cba
        beq  .y
        subb #2
        cba
        beq  .y
        clc
        rts
.y:     sec
        rts

; the table: A = the pawn's side's king, B = the other king, the pawn kk_p
; (kk_lookp: the pawn kk_lp): A = the distance, 0 a draw
kk_look:
        psha
        ldaa kk_p
        staa kk_lp
        pula
kk_lookp:
        bsr  kk_s64
        staa kk_a
        tba
        bsr  kk_s64
        staa kk_b
        ldaa kk_lp
        bsr  kk_s64
        tst  kk_pc              ; a Black pawn: ranks flipped
        beq  .f
        eora #56
        psha
        ldaa kk_a
        eora #56
        staa kk_a
        ldaa kk_b
        eora #56
        staa kk_b
        pula
.f:     bita #4                 ; files e-h: mirrored
        beq  .m
        eora #7
        psha
        ldaa kk_a
        eora #7
        staa kk_a
        ldaa kk_b
        eora #7
        staa kk_b
        pula
.m:     tab                     ; p = (rank - 1) * 4 + file
        lsrb
        lsrb
        lsrb
        stab kk_r               ; the rank, 1..6
        decb
        aslb
        aslb
        anda #7
        aba
        asla                    ; its block: p * 4 + wk / 16
        asla
        ldab kk_b
        lsrb
        lsrb
        lsrb
        lsrb
        aba
        jsr  kk_get             ; kk_dptr = that block, decoded
        ldaa kk_b               ; the entry in it: (wk & 15) * 64 + sk, two a byte
        anda #15
        ldab #32
        mul                     ; D = (wk & 15) * 32
        pshb
        ldab kk_a
        lsrb
        stab kk_off
        pulb
        addb kk_off
        adca #0
        addd kk_dptr
        xgdx
        ldaa 0,x
        ldab kk_a               ; (sk odd: the high nibble)
        lsrb
        bcc  .lo
        lsra
        lsra
        lsra
        lsra
.lo:    anda #15
        beq  .x
        ldab kk_r               ; the pawn moves still needed: 7 - rank, 5 from rank 2
        cmpb #1
        bne  .r
        ldab #5
        bra  .c
.r:     ldab #7
        subb kk_r
.c:     cba                     ; less than that: a distance over 15, stored as d - 15
        bhs  .x
        adda #15
.x:     rts

; A = block: kk_dptr = its buffer, decoded (the one used last is kept)
kk_get: cmpa kk_cb0
        bne  .n0
        clr  kk_mru
        ldx  #kk_dbuf0
        bra  .x
.n0:    cmpa kk_cb1
        bne  .n1
        ldab #1
        stab kk_mru
        ldx  #kk_dbuf1
        bra  .x
.n1:    staa kk_cb              ; neither: into the one not used last
        tst  kk_mru
        bne  .b0
        staa kk_cb1
        ldab #1
        stab kk_mru
        ldx  #kk_dbuf1
        bra  .d
.b0:    staa kk_cb0
        clr  kk_mru
        ldx  #kk_dbuf0
.d:     stx  kk_dptr
        jmp  kk_block
.x:     stx  kk_dptr
        rts

; the code table into kk_cnt (16 counts) and kk_syms; no block decoded
kk_head:
        ldaa #$FF
        staa kk_cb0
        staa kk_cb1
        clr  kk_mru
        ldab #KPK_BLOCK
        stab kv_rblk
        ldd  #194
        std  kv_roff
        ldd  #16+KK_SYMS
        std  kv_rlen
        ldd  #kk_cnt
        std  kv_rdst
        jmp  pk_read

; block kk_cb into kk_dptr's buffer (1024 entries, two a byte, low nibble
; first), its bytes read from the pack as the bits are needed
kk_block:
        ldab kk_cb              ; its offset
        clra
        asld
        std  kv_roff
        ldab #KPK_BLOCK
        stab kv_rblk
        ldd  #2
        std  kv_rlen
        ldd  #kk_ix
        std  kv_rdst
        jsr  pk_read
        ldd  kk_ix
        std  kv_roff
        ldd  #0                 ; (just placed there: kk_bit reads on)
        std  kv_rlen
        jsr  pk_read
        clr  kk_bm
        ldd  #0
        std  kk_pos
.run:   jsr  kk_sym             ; A = value << 4 | k
        tab
        andb #15
        stab kk_k
        lsra
        lsra
        lsra
        lsra
        staa kk_v
        ldd  #1                 ; the length: 1, then each of k bits after it
        std  kk_n
.len:   tst  kk_k
        beq  .fill
        jsr  kk_bit
        ldd  kk_n
        rolb
        rola
        std  kk_n
        dec  kk_k
        bra  .len
.fill:  ldd  kk_pos             ; kk_n entries of kk_v from kk_pos
        lsrd
        addd kk_dptr
        xgdx
.f:     ldab kk_pos+1
        lsrb
        bcs  .hi
        ldaa kk_v               ; the low nibble (the high one comes next)
        staa 0,x
        bra  .nx
.hi:    ldaa kk_v
        asla
        asla
        asla
        asla
        oraa 0,x
        staa 0,x
        inx
.nx:    ldd  kk_pos
        addd #1
        std  kk_pos
        ldd  kk_n
        subd #1
        std  kk_n
        bne  .f
        ldd  kk_pos
        subd #1024
        bcs  .run
        rts

; the next code: A = its symbol (canonical Huffman, codes up to 16 bits)
kk_sym: ldd  #0
        std  kk_code
        std  kk_first
        clr  kk_index
        ldx  #kk_cnt
        stx  kk_lx
.l:     jsr  kk_bit             ; code = code + the bit
        ldd  kk_code
        adcb #0
        adca #0
        std  kk_code
        ldx  kk_lx
        ldaa 0,x
        staa kk_n2              ; codes of this length
        ldd  kk_code
        subd kk_first
        tsta
        bne  .nx
        cmpb kk_n2
        bhs  .nx
        addb kk_index
        ldx  #kk_syms
        abx
        ldaa 0,x
        rts
.nx:    ldab kk_index
        addb kk_n2
        stab kk_index
        ldd  kk_first           ; first = (first + n) * 2, code = code * 2
        addb kk_n2
        adca #0
        asld
        std  kk_first
        ldd  kk_code
        asld
        std  kk_code
        ldx  kk_lx
        inx
        stx  kk_lx
        cpx  #kk_cnt+16
        bne  .l
        clra                    ; (cannot happen with a good table)
        rts

; the next bit: C (a new byte from the pack when the last is used up)
kk_bit: tst  kk_bm
        bne  .h
        pshx
        os   PK$RBYT
        pulx
        stab kk_byte
        ldaa #$80
        staa kk_bm
.h:     ldab kk_byte
        andb kk_bm
        lsr  kk_bm
        tstb
        beq  .z
        sec
        rts
.z:     clc
        rts

; A = a 0x88 square: 0-63
kk_s64: psha
        anda #7
        staa kk_tmp
        pula
        anda #$70
        lsra
        oraa kk_tmp
        rts

; a promotion on kk_q: B = 0 (a queen), or the rook's bits when a queen
; would stalemate (as the table assumes: the generator's promoWins)
kk_promo:
        clr  kk_rook
.pc:    clr  kk_any             ; the defender's moves
        clr  kk_j
.l:     ldab kk_j
        ldx  #kk_dir
        abx
        ldaa 0,x
        adda kk_wk
        staa kk_u
        bita #$88
        bne  .n
        cmpa kk_sk
        beq  .n
        ldab kk_sk
        jsr  kk_adj
        bcs  .n
        ldaa kk_u
        cmpa kk_q
        beq  .ok                ; it could take the piece: a move
        jsr  kk_hit
        bcs  .n
.ok:    inc  kk_any
.n:     inc  kk_j
        ldaa kk_j
        cmpa #8
        bne  .l
        tst  kk_any
        bne  .fine
        ldaa kk_wk              ; no move: fine only if it is check
        jsr  kk_hit
        bcs  .fine
        tst  kk_rook
        bne  .q                 ; (neither: a queen, as the reference)
        inc  kk_rook            ; the queen stalemates: a rook
        bra  .pc
.fine:  tst  kk_rook
        beq  .q
        ldab #$08
        rts
.q:     clrb
        rts

; A = square: C=1 if the new piece on kk_q (a queen, or a rook when kk_rook)
; or the pawn's side's king attacks it
kk_hit: staa kk_h
        ldab kk_sk
        jsr  kk_adj
        bcs  .y
        clr  kk_hd
.d:     ldab kk_hd
        ldx  #kk_dir
        abx
        ldaa 0,x
        staa kk_step
        ldaa kk_q
.r:     adda kk_step
        bita #$88
        bne  .nd
        cmpa kk_h
        beq  .y
        cmpa kk_sk
        bne  .r
.nd:    inc  kk_hd
        ldaa kk_hd
        ldab #8                 ; a queen: all eight lines; a rook: the first four
        tst  kk_rook
        beq  .q
        ldab #4
.q:     cba
        bne  .d
        clc
        rts
.y:     sec
        rts

kk_dir: fcb  1,$FF,16,$F0,17,15,$F1,$EF

; overlay-local variables
kk_p:     rmb  1
kk_pc:    rmb  1
kk_fwd:   rmb  1
kk_sk:    rmb  1
kk_wk:    rmb  1
kk_q:     rmb  1
kk_t:     rmb  1
kk_u:     rmb  1
kk_i:     rmb  1
kk_j:     rmb  1
kk_best:  rmb  1
kk_mf:    rmb  1
kk_mt:    rmb  1
kk_kind:  rmb  2
kk_dsk:   rmb  1
kk_dp:    rmb  1
kk_worst: rmb  1
kk_any:   rmb  1
kk_lp:    rmb  1
kk_a:     rmb  1
kk_b:     rmb  1
kk_r:     rmb  1
kk_off:   rmb  1
kk_byte:  rmb  1
kk_tmp:   rmb  1
kk_rook:  rmb  1
kk_h:     rmb  1
kk_hd:    rmb  1
kk_step:  rmb  1
kk_cb:    rmb  1                ; the block being decoded
kk_cb0:   rmb  1                ; the blocks in the two buffers ($FF none)
kk_cb1:   rmb  1
kk_mru:   rmb  1                ; the one used last
kk_dptr:  rmb  2
kk_ix:    rmb  2
kk_bm:    rmb  1
kk_pos:   rmb  2
kk_n:     rmb  2
kk_k:     rmb  1
kk_v:     rmb  1
kk_code:  rmb  2
kk_first: rmb  2
kk_index: rmb  1
kk_n2:    rmb  1
kk_lx:    rmb  2
KK_SYMS = 128                   ; the most symbols kpkd_pack.js may use
kk_cnt:   rmb  16
kk_syms:  rmb  KK_SYMS
kk_dbuf0: rmb  512              ; two blocks decoded
kk_dbuf1: rmb  512
