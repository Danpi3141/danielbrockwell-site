; ---------------------------------------------------------------------
; Kernel variables and tables (inside the kernel image).
; ovtab is filled in by the build once the overlays are placed.
; ---------------------------------------------------------------------
KEY_DELAY = 8                   ; repeat after 0.4 s
KEY_RATE  = 1                   ; then every 50 ms

; tables the build fills in (part of the image on the pack)
ovtab:    rmb 3*MAX_OVERLAYS    ; per overlay 1..: block, offset (2)

; variables: not on the pack, cleared at start. Those at MENUBUF+n and SCREEN4 (24 Nov) are in the
; OS's own buffers, not in the array; MENUBUF+186 on keeps ZP1's old contents (kinit.asm, quit)
MB_USED   = 186
kv_first:
kv_sp:    rmb 2                 ; the launcher's stack pointer
kv_vars:  rmb 2                 ; ADDR(v%())
kv_base:  rmb 2                 ; the kernel's address
kv_size:  rmb 2                 ; the table's size in bytes
kv_dev:   rmb 1                 ; device the game's blocks are on (0 A:, 1 B:, 2 C:)
kv_ksav:  rmb 5                 ; KBB_DLAY, KBB_REPT, KBB_CLIK, KBB_PKOF, KBB_STAT on entry
kv_res:   rmb 1                 ; overlay resident in slot A (0 = none)
kv_rx:    rmb 2
kv_rtgt:  rmb 2
kv_dir    = HOLE+2*LM_MAX       ; (N_BLOCKS*3, in the launcher's used code) pack address of each block CHB0.., $FF.. if missing
kv_pkok:  rmb 1                 ; the game's device is selected and on (see pk_seek)
kv_left:  rmb 1                 ; key_wait: frames still to wait
kv_afr:   rmb 1
kv_aidle: rmb 2
kv_pa:    rmb 3                 ; pack address being read
kv_rblk:  rmb 1                 ; pk_read: block
kv_roff:  rmb 2                 ;          offset in the block
kv_rlen:  rmb 2                 ;          bytes
kv_rdst:  rmb 2                 ;          destination
kv_t0:    rmb 2                 ; kernel scratch, never kept across a call
kv_t1:    rmb 2
kv_t2:    rmb 2
kv_t3:    rmb 2
kv_m1:    rmb 2                 ; mul16 / udiv
kv_m2:    rmb 2
kv_m3:    rmb 2
kv_rnd:   rmb 2
kv_cur:   rmb 1                 ; text cursor, 0..79
kv_gdirty: rmb 1                ; glyphs to send, bit n = glyph n
kv_cells  = SCREEN4              ; the screen as it should look, row major (80)
kv_nbuf:  rmb 8                 ; number formatting
kv_fix    = RTT_BF+240                ; fix-ups being applied (16 encoded bytes at a time); (17 Nov: kept
kv_fo:    rmb 2                 ; here: in slot A's last 18 bytes take-backs in a clock game went wrong)

; the board screen (what must last between overlay calls)
v_flip    = MENUBUF+0    ; 1: the board is turned (Black at the bottom)
v_half    = MENUBUF+1    ; letter view: 0 the near half, 1 the far half
cur_sq    = MENUBUF+2    ; the cursor's square, $FF none
msg_on    = MENUBUF+3    ; row 3 shows msg_t
msg_t     = MENUBUF+4    
st_p      = MENUBUF+24   ; the strip: three parts and the turn, 4 bytes each
st_p3     = MENUBUF+40   ; the last move's third part
sc_col    = MENUBUF+44   ; strip_cells, msg_set
sc_r      = MENUBUF+45   
sc_p      = MENUBUF+46   
sc_q      = MENUBUF+48   
lm_n:     rmb 1                 ; the legal moves (a copy of e_lm, at most LM_MAX)
lm_buf    = HOLE                ; 2*LM_MAX, in the launcher's code that has run (24 Nov: boot.asm)
HOLE_USED = 2*LM_MAX+N_BLOCKS*3
        if   HOLE_USED>HOLE_LEN
        error "lm_buf does not fit the launcher's used code"
        endif

; the game (not saved)
g_stat:   rmb 1                 ; eng_status after the last move
g_chk:    rmb 1                 ; the side to move is in check
g_ckr:    rmb 1                 ; the piece giving it
g_nosv:   rmb 1                 ; 1: A:CHESSAV could not be made: no record, so no take back
hu_f:     rmb 1                 ; the player's move
hu_t:     rmb 1
im_g:     rmb 1                 ; importing: A:GAMEn, the next move's record and offset,
im_rn:    rmb 2                 ; and its promotion bits (OV_IMPORT)
im_off:   rmb 1
im_pro:   rmb 1
im_on:    rmb 1                 ; 1 while importing (the record is saved a chunk at a time)
rv_on:    rmb 1                 ; game review's replay: RVF_* flags (OV_REVIEW)
        if   SPEEDTEST
sp_t0:    rmb 2                 ; the speed test (TEMPORARY): start, then frames for each part
sp_eng:   rmb 2
sp_nodes: rmb 2
sp_ov:    rmb 2
sp_bk:    rmb 2
        endif
rp_i:     rmb 1
rp_p:     rmb 2
rp_buf    = MENUBUF+156  ; replay: a chunk of the record
rp_e:     rmb 1
sp_i:     rmb 1                 ; a ply to read or write in the save file
sp_e:     rmb 3
pm_f:     rmb 1
pm_t:     rmb 1
pm_i:     rmb 1
cm_f:     rmb 1
cm_t:     rmb 1
cm_share: rmb 2
cm_t0:    rmb 2
th_t0:    rmb 2
th_d:     rmb 1
pw_a:     rmb 1
clk_last: rmb 2
clk_run:  rmb 1
bk_in:    rmb 1                 ; the book is on (not after a set-up)

; ---- saved (the header record of A:CHESSAV): the settings and the game ----
gs_first  = MENUBUF+50
gs_ver    = MENUBUF+50   
gs_len    = MENUBUF+51   
gs_sum    = MENUBUF+53   
st_first  = MENUBUF+55
st_layout = MENUBUF+55   ; 0 letters beside the map, 1 split board
st_notat  = MENUBUF+56   ; 0 standard notation, 1 plain squares
st_level  = MENUBUF+57   ; 1..8
st_auto   = MENUBUF+58   ; 1: Auto (the level moves with the results)
st_timing = MENUBUF+59   ; 0 none, 1 5|5, 2 10|5, 3 15|10, 4 30|30, 5 custom
st_cmin   = MENUBUF+60   ; custom minutes: the player, the computer
st_cinc   = MENUBUF+62   ; custom increments (seconds)
st_pace   = MENUBUF+64   ; 0 natural, 1 fast
st_colour = MENUBUF+65   ; 0 White, 1 Black, 2 alternate
st_sound  = MENUBUF+66   ; 0 all, 1 blips only, 2 off
st_blund  = MENUBUF+67   ; blunder check (not used yet)
st_ponder = MENUBUF+68   ; think on your time (not used yet)
st_resign = MENUBUF+69   ; the computer may resign
st_last   = MENUBUF+70
g_human   = MENUBUF+70   ; the player's colour: 0 White, 8 Black
g_mode    = MENUBUF+71   ; 0 against the computer, 1 two players
g_setup   = MENUBUF+72   ; 1: the game started from g_spos
g_result  = MENUBUF+73   
g_reason  = MENUBUF+74   
g_bad     = MENUBUF+75   ; the computer's moves in a row at worse than -9
g_clk     = MENUBUF+76   ; White, Black (frames)
g_inc     = MENUBUF+80   ; their increments
g_spos    = MENUBUF+84   ; a set-up position: a1..h8, side, castle, ep, half
g_n       = MENUBUF+152  ; plies played
g_last    = MENUBUF+153  ; the last ply: from, to, info (the record is in A:CHESSAV)
gs_end    = MENUBUF+156

; ---- the engine's variables ----
        include "evarsel.inc"
