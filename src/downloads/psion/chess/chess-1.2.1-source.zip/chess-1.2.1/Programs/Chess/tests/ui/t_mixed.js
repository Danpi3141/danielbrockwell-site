'use strict';
// Two versions of Chess on two packs (24 Nov: a real Organiser showed TRAP 0007 7E80 with an older Chess in B: and the
// new one run from C:. The launcher looks on B: first, and loaded the other version's kernel). Each must run its own
// game, or say what is wrong: never crash.
//   node tests/ui/t_mixed.js
const fs = require('fs');
const path = require('path');
const L = require('./lib.js');
const G = require('./glib.js');
const { Machine } = require('../../tools/emu.js');
const meta = JSON.parse(fs.readFileSync(path.join(L.BUILD, 'build.json'), 'utf8'));
const NEW = path.join(L.BUILD, 'CHESS.opk'), OLD = path.join(__dirname, 'old', 'chess-1.1.opk');
const ROMS = { '46a-lz64.rom': 64, '43-lz64.rom': 64, '42-lz.rom': 32 };
let fails = 0;
function ok(c, msg) { if (!c) { fails++; console.log('FAIL ' + msg); } else console.log('ok   ' + msg); }

// the build's number (big-endian) in a block's data, after its name's record, the long record's header, the object length
// and the stub: changed, the block is another build's
const tmp = path.join(L.ROOT, 'build', 'test');
fs.mkdirSync(tmp, { recursive: true });
function other(name, blocks) {
  const d = fs.readFileSync(NEW);
  for (const b of blocks) {
    const at = d.indexOf(Buffer.from(b.padEnd(8)));
    if (at < 0) throw new Error('no ' + b);
    const id = d.indexOf(Buffer.from([0x59, 0xB2, 0x7B, meta.build >> 8, meta.build & 255]), at);
    if (id < 0 || id - at > 60) throw new Error('no build number in ' + b);
    d[id + 4] ^= 0x55;
  }
  const p = path.join(tmp, 'mixed_' + name + '.opk');
  fs.writeFileSync(p, d);
  return p;
}
const ANOTHER = other('all', ['CHK2', 'CHB0', 'CHB1', 'CHB2']);                  // a whole other build's data
const BADB0 = other('b0', ['CHB0']), BADB1 = other('b1', ['CHB1']);

function run(rom, b, c, from) {
  const m = new Machine({ rom, ram: ROMS[rom] });
  m.boot();
  if (b) m.insertPack(b, 0);
  if (c) m.insertPack(c, 1);
  let low = false;
  m.dbg.setTrace((pc) => { if (pc < 0x40) low = true; });
  m.runProc('CHESS', from);
  m.runSeconds(6);
  m.dbg.setTrace(null);
  m._base = null;
  m._low = low;
  return m;
}
// the new version is running, its blocks are on device dev
function plays(m, tag, dev) {
  try {
    if (m._low) throw new Error('crashed');
    if (!G.waitInput(m, 10)) throw new Error('not waiting for a move');
    const d = L.peekSym(m, 'kv_dev')[0];
    G.typeUci(m, 'b1a3');
    ok(G.waitPly(m, 2, 60) && d === dev, `${tag} the new game runs, from ${'ABC'[d]}:`);
  } catch (e) { ok(false, tag + ' ' + e.message.split('\n')[0] + ' | ' + m.screenText().replace(/\n/g, '|').slice(0, 60)); }
}
for (const rom of Object.keys(ROMS)) {
  plays(run(rom, OLD, NEW, 'C'), `${rom} 1.1 in B:, the new one run from C::`, 2);
  plays(run(rom, NEW, OLD, 'B'), `${rom} the new one in B:, 1.1 in C:, run from B::`, 1);
  plays(run(rom, ANOTHER, NEW, 'C'), `${rom} another build in B:, this one run from C::`, 2);
  plays(run(rom, NEW, ANOTHER, 'B'), `${rom} this one in B:, another build in C::`, 1);
  plays(run(rom, NEW, NEW, 'C'), `${rom} the same build in both, run from C::`, 1);
  plays(run(rom, null, NEW, 'C'), `${rom} only in C::`, 2);
  for (const v of ['1.2', '1.0']) {                                              // the other released versions that are here
    const P = path.join(__dirname, 'old', `chess-${v}.opk`);
    if (!fs.existsSync(P)) continue;
    plays(run(rom, P, NEW, 'C'), `${rom} ${v} in B:, the new one run from C::`, 2);
    plays(run(rom, NEW, P, 'B'), `${rom} the new one in B:, ${v} in C:, run from B::`, 1);
    for (const [b, c, from] of [[NEW, P, 'C'], [P, NEW, 'B']]) {
      const m = run(rom, b, c, from), alone = run(rom, from === 'B' ? P : null, from === 'C' ? P : null, from);
      ok(!m._low && m.screenText() === alone.screenText() && /RNBQKBNR/.test(m.screenText()), `${rom} ${v} run from ${from}: with the new one on the other pack: as it is alone`);
    }
  }
  // 1.1's own launcher, with the new version on the other pack: 1.1 must run as it does alone
  for (const [b, c, from] of [[NEW, OLD, 'C'], [OLD, NEW, 'B']]) {
    const m = run(rom, b, c, from), alone = run(rom, from === 'B' ? OLD : null, from === 'C' ? OLD : null, from);
    ok(!m._low && m.screenText() === alone.screenText() && /RNBQKBNR/.test(m.screenText()), `${rom} 1.1 run from ${from}: with the new one on the other pack: as it is alone`);
  }
  for (const [pk, what, want] of [[ANOTHER, 'only another build\'s data', /GAME FILES NOT FOUND/], [BADB0, 'another build\'s CHB0', /GAME FILES DAMAGED/]]) {
    const m = run(rom, pk, null, 'B');
    ok(!m._low && want.test(m.screenText().replace(/\n/g, '').replace(/ +/g, ' ')), `${rom} ${what}: ${m.screenText().replace(/\s+/g, ' ').trim().slice(0, 40)}`);
    m.press('EXE', 3, 10); m.runSeconds(1);
    ok(/Find|Save|Edit/.test(m.screenText()) || (m.press('ON', 3, 10), m.runSeconds(1), /Find|Save|Edit/.test(m.screenText())), `${rom} ${what}: back at the menu`);
  }
  plays(run(rom, BADB1, null, 'B'), `${rom} another build's book: plays without it`, 1);
}
console.log(fails ? fails + ' failures' : 'all mixed-version tests passed');
process.exit(fails ? 1 : 0);
