# Hardware test plan (first tests on a real Organiser)

Everything so far ran in the emulator (Jape's sources under Node, the LZ64 ROM). This is the list
for the first session on the real machine, with the emulator's figure for each so the two can be
compared. Fill in the "Organiser" column; anything that differs a lot, or fails, is what to send
back. Test 3 is done (16 Nov): the Organiser matched the emulator, and the SPEED TEST has been taken out of the build (`SPEEDTEST = 1` in `src/defs.inc` puts it back).

## Before the session

1. Build and make the delivery folder:

   ```
   python tools/build.py
   python tools/psion.py
   ```

   `psion/` then holds the game (5 files, 54,643 bytes) and RPBOOT's loader.
2. A Rampak or Flashpak of 64K or more for B: (or C:). A: needs some free space for the save file
   (`A:CHESSAV`, about 1.5K) and for PGN exports.
3. Free RAM: the game takes the largest table that fits. An empty LZ64 has 22,238 bytes free; the
   512-entry table needs 18,117 (the 256-entry one 16,325, the 128-entry one 15,429); the first two want
   1,445 more until the save file exists.
4. Psi2Win (or Psion's CL) with its folder set to `psion`, and the Comms Link plugged in.
5. A watch with seconds, and a PC chess program that opens PGN files.

## The session

| # | Test | How | Emulator | Organiser |
|---|---|---|---|---|
| 1 | Loading | RPBOOT on the Organiser (see README, *Load onto the Organiser*); note the time and any message | (not measurable: no Comms Link) | |
| 2 | Start | Prog → Run → B:CHESS. Board shown? Which table (the SPEED TEST screen doesn't show it: note any "NEEDS n BYTES" message instead) | board after about 2.2 s | |
| 3 | **Speed test** | New game (menu NEW GAME), then menu → SPEED TEST (the last item: S four times). Write down all four lines | POSITIONS/S 98; SEARCH 10150 MS; OVERLAY 15 MS; BOOK 15 MS | 98; 10200 MS; 15 MS; 15 MS (16 Nov: one 50 ms frame from the emulator). 20 Nov, a middle game: 71; 14000 MS; 20 MS; 40 MS (the emulator, the current engine, from positions of the Pgn1 game: start 124 / 8050 ms, ply 8 91, ply 30 71 / 13950 ms, ply 49 49; overlay 15 to 20 ms, book 15 to 35 ms) |
| 4 | The screen | Is each square readable in the letters-and-map view? Can the hollow and solid map blocks be told apart? Also SETTINGS → BOARD: split board and real-board mode | (Jape's LCD) | |
| 5 | Keys | Type E2E4 without SHIFT; point with the arrows and EXE; DEL takes back; MODE shows the other half; SPACE gives a hint | all work | |
| 6 | The book | As White and as Black (FLIP): the computer's first replies come at once, without the depth display | at once (about 15 ms + the pace wait) | |
| 7 | Level times | Out of the book (1.Na3 is the only first move it has no answer to), time a few moves at each level with the watch. The most each may take: 1, 1, 2, 3, 3, 10, 30, 255 s | within the limits | |
| 8 | Levels 1-4 and the book | At level 2, the computer's first 2 moves from the book, the 3rd searched (the depth shows) | so | |
| 9 | King and pawn | SET UP POSITION: White Ke1, Pe4, Black Ke8, White to move; play on. Time the computer's moves and a hint (SPACE) | 0.5-1.5 s a hint | |
| 10 | Clock | A 30\|30 clock game for an hour (or as long as you can): the game's clock against the watch | 1.2 s an hour slow; on the Organiser about 3 s an hour slow is expected | |
| 11 | Save and resume | Menu SAVE AND LEAVE, then run CHESS again: the same position, settings and clock | so | |
| 12 | Switching off | Leave it waiting: it should switch off after the Organiser's auto-off time (also with a square typed, the pointing cursor, the menu). ON brings it back as it was. At level 8 it must not switch off while it thinks | so | |
| 13 | Pack out | While it waits for a move, take the pack out, press a key: "GAME FILES NOT FOUND". Put it back, run CHESS: the game resumes | so | |
| 14 | Export PGN | Menu EXPORT PGN: "PGN SAVED AS A:PGN1". Send A:PGN1 to the PC as a data file (Comms Link), rename it .pgn, open it in the chess program | the file reads back in python-chess | |
| 15 | Import | On the PC: `python -E -P tools/pgn2psion.py some.pgn --out import`; send GAME1.ODB to the Organiser as A:GAME1 (data file); menu IMPORT GAME, EXE; time it per ply; then the move list and DEL | about 0.5 s a ply | |
| 16 | Leaving | After SAVE AND LEAVE: key click, CAPS/NUM, the auto-off time and FREE as before running CHESS (only A:CHESSAV and any PGN files are new) | so | |
| 17 | Battery | A long game at level 8: note the battery before and after | (none) | |
| 18 | An alarm | Set an alarm (or a diary entry with one) for a few minutes ahead, then play: let it ring once while the game waits for your move and once while it thinks. ON stops it: the board comes back and the game goes on | so | |
| 19 | Start-up from each kind of pack | The launcher now runs its machine code where it lies in CHESS's own translated text: run CHESS from a Flashpak, and from a Rampak if you have one, and leave and start it again | about 2.2 s to the board | |
| 20 | **Two versions** | Chess 1.1 in B:, this one in C:: run C:CHESS, leave, run B:CHESS (and the other way round if you can). Both start; no TRAP | so | 24 Nov, before the fix: TRAP 0007 7E80 from C:CHESS |

## What the numbers are for

- **Positions a second (test 3)** sets every level's real strength. The level times were measured as
  "seconds × about 69 positions a second" (the engine with the operating system running, in the
  emulator); the speed test's start position runs faster than a middle game (98 there). If the
  Organiser's figure is close to 98, nothing changes. If it is, say, 20% lower, the levels are a
  little weaker than their labels and I can re-measure them at the real speed (or lengthen the times).
- **Overlay and book times** show the pack's read speed. Each move loads several overlays; at 15 ms
  each that is hardly noticed. At 100 ms or more, moving would feel slow and I'd look at loading less.
- **The king-and-pawn hint time** checks the compressed table's decoding at the real pack speed.
- **The Comms Link tests (14, 15)** are the first real transfers of these files: line endings,
  record lengths and names are the things that could differ from the emulator.

## The speed test (taken out 16 Nov)

Done: `SPEEDTEST = 0` in `src/defs.inc` removed the menu item, its code (131 bytes of RAM: the
array went from 19,913 to 19,782) and its screen; `tests/ui/t_speedtest.js` reports that the build
has none and passes. To run it again, set `SPEEDTEST = 1`, then `python tools/build.py` and
`python tools/psion.py`.
