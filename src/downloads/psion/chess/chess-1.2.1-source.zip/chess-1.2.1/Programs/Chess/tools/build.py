#!/usr/bin/env python3
"""Builds the chess game: kernel (with the engine), overlay screens, book and endgame
blocks, the launchers and the pack image.

    python tools/build.py [--engine auto|real|stub] [--out build/game]

The game's memory holds: the TT | the kernel and engine (code, tables, variables) | slot A.
Slot A holds the overlay screens and, while the engine works, the engine's scratch.
The launcher CHESS picks the largest TT the free RAM allows; its bootstrap (src/launch/boot.asm)
takes the memory from under OPL's stack, so there is no array.
"""
import argparse
import json
import os
import subprocess
import sys
import zlib

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import asm   # noqa: E402
import pack  # noqa: E402
import zpcheck  # noqa: E402

BLOCK_MAX = 32000
LAUNCH_MARGIN = 8              # FREE CHESS wants beyond the game's memory (its own frame is already there when it asks)
MENU_OVER = 377                # what CHESS's own text and frame take: FREE at the menu less FREE as CHESS sees it (tests/ui/t_lowmem.js)
QCODE_GAP = 3                  # from RTA_SP as the bootstrap sees it to the start of CHESS's translated text (all 14 LZ ROMs; tests/ui/t_hole.js)
SAVE_RESERVE = 1445            # FREE the save file A:CHESSAV takes where it shares the game's RAM: the 32K LZ, and an LZ64 whose
                               # other banks are full of A: files (the only way its FREE gets low). Measured 24 Nov 2026 (1,437 is
                               # too little); 1,375 until then, when the launcher's own estimate had 70 to spare. Without it the
                               # launcher picked a table with no room left to save (CANNOT SAVE: NO ROOM)
TT_ENTRIES = (128, 256, 512)
OVERLAYS = [('OV_BOARD', 'ov_board.asm'), ('OV_GAME', 'ov_game.asm'), ('OV_MENU', 'ov_menu.asm'), ('OV_SET', 'ov_set.asm'), ('OV_LIST', 'ov_list.asm'),
            ('OV_RESULT', 'ov_result.asm'), ('OV_SETUP', 'ov_setup.asm'), ('OV_IMPORT', 'ov_import.asm'), ('OV_KPK', 'ov_kpk.asm'),
            ('OV_REVIEW', 'ov_review.asm')]
N_BLOCKS = 4                   # 0 overlays, 1 book, 2 the king-and-pawn distance table (compressed), 3 spare
BK_BLOCK, KPK_BLOCK = 1, 2


class BuildError(Exception):
    pass


def encode_fixups(fix):
    out = bytearray()
    prev = 0
    for f in sorted(fix):
        d = f - prev
        if 0 <= d < 255:
            out.append(d)
        else:
            out += bytes([255, d >> 8, d & 255])
        prev = f
    return len(out).to_bytes(2, 'big') + bytes(out)


def align(n, a=1):   # was 16 until 16 Nov: nothing needs the kernel or the slot aligned (the array itself starts anywhere)
    return (n + a - 1) // a * a


def engine_choice(choice):
    if choice != 'auto':
        return choice
    ready = os.path.join(ROOT, 'src', 'engine', 'READY.txt')
    if os.path.exists(ready) and os.path.exists(os.path.join(ROOT, 'src', 'engine', 'engine.asm')):
        t = open(ready).read()
        if all(r in t for r in ('eng_reset', 'eng_legal', 'eng_play', 'eng_check', 'eng_status')):
            return 'real'
    return 'stub'


class Launcher:
    """CHESS: OPL with the bootstrap in a string constant, put there after translating.
    Its translated text is, in order: what runs before the bootstrap; a GOTO round the constant; the
    constant (the bootstrap: `load`, then `boot`, its entry and what the kernel returns to); the USR call and
    the messages. So everything before `boot` is one area that never runs again: the hole."""

    def __init__(self, out, assemble):
        self.out, self.assemble = out, assemble
        self.ob3 = os.path.join(out, 'CHESS.ob3')
        self.opl = os.path.join(out, 'CHESS.opl')
        self.boot_at, self.boot = self.bootstrap(0)
        self.k = 0
        obj = self.translate([0x7001, 0x7002, 0x7003], 0x7004)     # (numbers of the same size in the code)
        q = obj.index(bytes([0x59, 0xB2]))
        self.hole = obj.index(b'Q' * len(self.boot)) - q + self.boot_at
        self.k = self.offset(obj)

    def bootstrap(self, ktotal, build=0):
        b = self.assemble(os.path.join(ROOT, 'src', 'launch', 'boot.asm'), 0, {'KTOTAL': (ktotal, 'abs'), 'BUILD': (build, 'abs')}, 'boot')
        if b.fix:
            raise BuildError('the bootstrap must be position independent')
        return b.sym['boot'][0], bytes(b.out)

    def offset(self, obj):       # from the PEEKW's op-code (RTA_PC when it runs) to `boot`
        at = obj.index(bytes([0x22, 0x00, 0xA9, 0x9C])) + 3
        return obj.index(b'Q' * len(self.boot)) + self.boot_at - at

    def translate(self, needs, ktotal):
        # r% is FREE less the save file's room while A:CHESSAV doesn't exist yet ((EXIST(..)=0) is -1 then), so a
        # table is only chosen if the save still fits; the smallest starts without it (unsaved)
        n = TT_ENTRIES
        lines = ['CHESS:',
                 'LOCAL v%(6),r%',
                 'IF FREE<%d :PRINT "CHESS NEEDS",%d-FREE,"BYTES MORE RAM" :GET :RETURN :ENDIF' % (needs[0], needs[0]),
                 'r%%=FREE+%d*(EXIST("A:CHESSAV")=0)' % SAVE_RESERVE,
                 'v%%(2)=%d-%d*(r%%>=%d)-%d*(r%%>=%d)' % (n[0] * 7, (n[1] - n[0]) * 7, needs[1], (n[2] - n[1]) * 7, needs[2]),
                 'GOTO go::',
                 'PRINT "' + 'Q' * len(self.boot) + '"',
                 'go::',
                 'r%%=USR(PEEKW($A9)%+d,ADDR(v%%()))' % self.k,
                 'IF r% :PRINT "GAME FILES ";MID$("NOT FOUNDDAMAGED",9*r%-8,9) :GET :ENDIF']
        with open(self.opl, 'w', encoding='latin-1', newline='\n') as f:
            f.write('\n'.join(lines) + '\n')
        r = subprocess.run([sys.executable, os.path.join(ROOT, '..', '..', 'Tools', 'opltran.py'), '--no-source', '-o', self.out, self.opl],
                           capture_output=True, text=True)
        if r.returncode:
            raise BuildError('CHESS: ' + r.stdout + r.stderr)
        with open(self.ob3, 'rb') as f:
            return f.read()

    def make(self, ktotal, needs, build):
        at, boot = self.bootstrap(ktotal, build)
        obj = self.translate(needs, ktotal)
        marks = b'Q' * len(boot)
        if obj.count(marks) != 1 or at != self.boot_at or len(boot) != len(self.boot) or self.offset(obj) != self.k:
            raise BuildError('the launcher changed size')
        with open(self.ob3, 'wb') as f:
            f.write(obj.replace(marks, boot))


def build(out, engine='auto', share=True):
    clash = zpcheck.check()
    if clash:
        raise BuildError('zero page: ' + '; '.join(clash))
    engine = engine_choice(engine)
    gen = os.path.join(out, 'gen')
    os.makedirs(gen, exist_ok=True)
    ids = ['; generated by tools/build.py', 'MAX_OVERLAYS = %d' % len(OVERLAYS), 'N_BLOCKS = %d' % N_BLOCKS,
           'BK_BLOCK = %d' % BK_BLOCK, 'KPK_BLOCK = %d' % KPK_BLOCK, 'ENGINE_REAL = %d' % (engine == 'real')]
    ids += ['%s = %d' % (n, i + 1) for i, (n, _) in enumerate(OVERLAYS)]
    with open(os.path.join(gen, 'ids.inc'), 'w') as f:
        f.write('\n'.join(ids) + '\n')
    with open(os.path.join(gen, 'engsel.inc'), 'w') as f:
        f.write('        include "%s"\n' % ('engine/engine.asm' if engine == 'real' else 'stub/engine.asm'))
    with open(os.path.join(gen, 'evarsel.inc'), 'w') as f:
        f.write(('ENG_SCRATCH_EXT = %s\nENG_LOW = RTT_BF\n' % ('SLOTA' if share else '0')) +
                '        include "%s"\n' % ('engine/evars.inc' if engine == 'real' else 'stub/evars.inc'))
    incdirs = [gen, os.path.join(ROOT, 'src'), os.path.join(ROOT, 'src', 'kernel'),
               os.path.join(ROOT, 'src', 'engine'), os.path.join(ROOT, 'src', 'stub'), os.path.join(ROOT, 'src', 'screens')]

    def assemble(path, origin, imports, what):
        try:
            return asm.assemble(path, origin=origin, imports=imports, incdirs=incdirs)
        except asm.AsmError as e:
            raise BuildError('%s: %s' % (what, e))

    # the launcher first: where its code that has run will be (HOLE: the kernel's variables lm_buf)
    launch = Launcher(out, assemble)
    kpath = os.path.join(ROOT, 'src', 'kernel', 'kernel.asm')

    init_len = [0]               # the start-up code's length (src/kernel/kinit.asm), for the kernel's entry

    def imports(kmax, slot):
        # TTBASE: the last 896 bytes of the table, just below the kernel (there whatever its size)
        return {'SLOTA': (kmax, 'rel'), 'TTBASE': (-TT_ENTRIES[0] * 7, 'rel'), 'SLOTA_SIZE': (slot, 'abs'), 'INIT_LEN': (init_len[0], 'abs'),
                'HOLE': (kmax + slot + QCODE_GAP, 'rel'), 'HOLE_LEN': (launch.hole, 'abs')}

    # first pass: the sizes of the overlays and of the engine's scratch
    k = assemble(kpath, 0, imports(0x4000, 4096), 'kernel')
    scratch = k.sym.get('ENG_SCRATCH_SIZE', (0, 'abs'))[0]
    ksym = dict(k.sym)
    ksym.update(imports(0x4000, 4096))
    ovsize = 16
    for n, fn in OVERLAYS:
        u = assemble(os.path.join(ROOT, 'src', 'screens', fn), 0x4000, ksym, n)
        ovsize = max(ovsize, len(u.out))
    slot = align(max(ovsize, scratch if share else 0))
    kmax = 0
    for _ in range(6):
        k = assemble(kpath, 0, imports(kmax, slot), 'kernel')
        need = align(len(k.out))
        if need == kmax:
            break
        kmax = need
    else:
        raise BuildError('kernel size did not settle')
    if bytes(k.out[3:7]) != b'CHK1':
        raise BuildError('kernel does not start with its tag')
    ksym = dict(k.sym)
    ksym.update(imports(kmax, slot))
    # the start-up code (17 Nov): assembled at the table's base, stored after the kernel's code (where
    # the variables go), copied up by the kernel's entry and run once there before the engine clears
    # the table. The kernel is assembled again with its length (the same size: an operand).
    ksym['BUILD'] = (0, 'abs')                   # (the number comes when everything is assembled: below)
    kin = assemble(os.path.join(ROOT, 'src', 'kernel', 'kinit.asm'), -TT_ENTRIES[0] * 7, ksym, 'kinit')
    init_len[0] = len(kin.out)
    k2 = assemble(kpath, 0, imports(kmax, slot), 'kernel')
    if len(k2.out) != len(k.out) or any(k2.sym[n] != v for n, v in k.sym.items() if n != 'INIT_LEN'):
        raise BuildError('the kernel moved when given the length of the start-up code')
    k = k2
    ksym = dict(k.sym)
    ksym.update(imports(kmax, slot))
    if init_len[0] > TT_ENTRIES[0] * 7:
        raise BuildError('the start-up code (%d bytes) is bigger than the smallest table' % init_len[0])

    # overlays into block 0
    blocks = [bytearray() for _ in range(N_BLOCKS)]
    ovtab = {}
    report = []
    for i, (n, fn) in enumerate(OVERLAYS):
        u = assemble(os.path.join(ROOT, 'src', 'screens', fn), kmax, ksym, n)
        if len(u.out) > slot:
            raise BuildError('overlay %s is %d bytes, over slot A (%d)' % (n, len(u.out), slot))
        if 'RV_AREA' in u.sym:       # game review's snapshots (19 Nov): in the smallest table, and beside a 128-entry one in a 256-entry table
            area = u.sym['RV_AREA'][0]
            if area > TT_ENTRIES[0] * 7 or area + 128 * 7 > 256 * 7:
                raise BuildError('game review needs %d bytes of the table: too many' % area)
        img = len(u.out).to_bytes(2, 'big') + bytes(u.out) + encode_fixups(u.fix)
        ovtab[n] = (0, len(blocks[0]))
        blocks[0] += img
        report.append((n, len(u.out), len(u.fix)))
        with open(os.path.join(out, n.lower() + '.lst'), 'w') as f:
            f.write(u.listing_text())
    # the book and the king-and-pawn table, when built
    data = {}
    # the king-and-pawn distance table, compressed (tools/kpk/kpkd_pack.js: 48K -> about 12K)
    kpkd = os.path.join(ROOT, 'data', 'kpkdz.bin')
    if os.path.exists(kpkd):
        b = open(kpkd, 'rb').read()
        blocks[KPK_BLOCK] += b
        data['kpkdz.bin'] = len(b)
    for blk, fn in ((BK_BLOCK, 'book.bin'),):
        p = os.path.join(ROOT, 'data', fn)
        if os.path.exists(p):
            b = open(p, 'rb').read()
            if len(b) > BLOCK_MAX:
                raise BuildError('%s is %d bytes, over a block' % (fn, len(b)))
            blocks[blk] += b
            data[fn] = len(b)

    image = bytearray(k.out)
    base = k.sym['ovtab'][0]
    for i, (n, _) in enumerate(OVERLAYS):
        b, off = ovtab[n]
        image[base + 3 * i:base + 3 * i + 3] = bytes([b, off >> 8, off & 255])
    vstart = k.sym['kv_first'][0]
    if any(image[vstart:]):
        raise BuildError('kernel variables are not all zero')
    if any(f >= vstart for f in k.fix):
        raise BuildError('a fix-up in the kernel variables')
    # the build's number: at the head of the kernel's block and of each data block, and in the launcher and the start-up
    # code, which pass over any other build's (another version on another pack: until 24 Nov that crashed)
    build_id = zlib.crc32(bytes(image) + bytes(kin.out) + b''.join(bytes(b) for b in blocks)) & 0xFFFF or 1
    ksym['BUILD'] = (build_id, 'abs')
    kin2 = assemble(os.path.join(ROOT, 'src', 'kernel', 'kinit.asm'), -TT_ENTRIES[0] * 7, ksym, 'kinit')
    if len(kin2.out) != len(kin.out) or kin2.fix != kin.fix:
        raise BuildError('the start-up code changed when given the build')
    kin = kin2
    idb = build_id.to_bytes(2, 'big')
    image = image[:vstart] + bytes(kin.out)          # the start-up code after the kernel's code
    kblock = idb + len(image).to_bytes(2, 'big') + bytes(image) + encode_fixups(list(k.fix) + [vstart + f for f in kin.fix])
    with open(os.path.join(out, 'kinit.lst'), 'w') as f:
        f.write(kin.listing_text())
    ktotal = kmax + slot
    if len(kblock) - 8 > ktotal:   # the kernel, then its encoded fix-ups after it
        raise BuildError('kernel and its fix-ups do not fit their memory during loading')
    with open(os.path.join(out, 'kernel.lst'), 'w') as f:
        f.write(k.listing_text())
    with open(os.path.join(out, 'kernel.sym.json'), 'w') as f:
        json.dump({n: v for n, v in k.sym.items()}, f, indent=0)

    # the launcher
    needs = [ktotal + n * 7 + LAUNCH_MARGIN for n in TT_ENTRIES]
    launch.make(ktotal, needs, build_id)

    img = pack.PackImage('flashpak', 256)
    img.add_proc_ob3(launch.ob3)
    img.add_data('CHK2', kblock)
    for i, blk in enumerate(blocks):
        if blk:
            img.add_data('CHB%X' % i, idb + bytes(blk))
    opk = os.path.join(out, 'CHESS.opk')
    size_k, used = img.write(opk)

    K = 1024
    eng = {n: v[0] for n, v in k.sym.items()}
    e_code = eng.get('eng_end', 0) - eng.get('eng_start', 0) if 'eng_end' in eng and 'eng_start' in eng else None
    lines = ['Engine: %s' % engine,
             'Pack (%dK flashpak)          bytes' % size_k,
             '  launcher+records       %7d' % (used - len(kblock) - sum(len(x) for x in blocks)),
             '  kernel+engine block    %7d' % len(kblock),
             '  screens (block 0)      %7d' % len(blocks[0]),
             '  book (block 1)         %7d' % len(blocks[1]),
             '  KPK table (block 2)    %7d' % len(blocks[2]),
             '  total                  %7d of %d (object code budget 256K)' % (used, size_k * K),
             'RAM                             bytes',
             '  kernel+engine code     %7d' % vstart,
             '  variables              %7d' % (kmax - vstart),
             '  slot A (screens/scratch)%6d  (largest screen %d, engine scratch %d%s)' % (slot, ovsize, scratch, ', shared' if share else ''),
             '  without the TT         %7d' % ktotal,
             '  (and in the launcher\'s used code %d of %d)' % (k.sym['HOLE_USED'][0], launch.hole)]
    if e_code is not None:
        lines.append('  (engine code+tables    %7d)' % e_code)
    for i, n in enumerate(TT_ENTRIES):
        lines.append('  TT %4d entries: memory %5d, %5d free at the menu' % (n, ktotal + n * 7, needs[i] + MENU_OVER))
    lines.append('Overlays')
    for n, ln, nf in report:
        lines.append('  %-10s %5d bytes, %3d fix-ups' % (n, ln, nf))
    text = '\n'.join(lines)
    with open(os.path.join(out, 'budget.txt'), 'w') as f:
        f.write(text + '\n')
    meta = {'engine': engine, 'kmax': kmax, 'slot': slot, 'ktotal': ktotal, 'hole': launch.hole, 'needs': needs, 'reserve': SAVE_RESERVE, 'menu': MENU_OVER, 'build': build_id, 'opk': opk,
            'blocks': [len(x) for x in blocks], 'ovtab': ovtab}
    with open(os.path.join(out, 'build.json'), 'w') as f:
        json.dump(meta, f, indent=1)
    if needs[0] + SAVE_RESERVE > 22246:
        raise BuildError('the smallest launcher needs %d bytes free, more than an empty LZ64 has\n%s' % (needs[0], text))
    return text, meta


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--engine', default='auto', choices=('auto', 'real', 'stub'))
    ap.add_argument('--out', default=None)
    ap.add_argument('--no-share', action='store_true', help='give the engine scratch its own RAM')
    a = ap.parse_args()
    out = os.path.abspath(a.out) if a.out else os.path.join(ROOT, 'build', 'game')
    os.makedirs(out, exist_ok=True)
    try:
        text, _ = build(out, a.engine, not a.no_share)
    except (BuildError, pack.opl2opk.PackError) as e:
        sys.exit('build failed: %s' % e)
    print(text)


if __name__ == '__main__':
    main()
